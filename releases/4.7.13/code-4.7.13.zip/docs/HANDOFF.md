# HANDOFF — yeshiva-shorts tool: everything an assistant needs to maintain it

Written 2026-10-20 so that **any** assistant (a person, or an AI such as Claude, ChatGPT, Gemini)
can fix and extend this tool without access to the chats that built it. The owner's Claude
subscription may end; this file and the repo are the memory.

> **The user is not a programmer and reads only Hebrew.** Explain everything to him in plain
> Hebrew, step by step ("click here, then here"). File names, code and commands may stay in English.
> He works on a Windows 11 PC; all the code runs inside **WSL Ubuntu**.

Repo: `git@github.com:<owner>/yeshiva-shorts-skill.git` (private, owner `<owner>`;
HTTPS: https://github.com/<owner>/yeshiva-shorts-skill). Commit with a message that says *why*;
push after verifying (standing permission from the owner).

---------------------------------------------------------------------------------------------------

## 1. What this is

The owner publishes **YouTube Shorts from Torah lessons of the Beit El yeshiva** (many rabbis).
Input: a YouTube lesson link. Output: vertical 1080x1920 clips (usually 10–60 s) with burned
Hebrew karaoke subtitles, a logo, normalized voice, background music, plus a title/description
text to copy into YouTube. Audience is religious Jewish: **editorial correctness matters more
than speed** (see §6).

Two ways to use the code:
1. **The tool ("התוכנה")** — a local web page the owner runs himself, no AI needed. This is the
   main way from now on. `make_short_app.py` + `make_short.py`.
2. **The skill** (`SKILL.md`) — the older flow driven by an AI agent (Claude Code), step by step.
   Still valid; the tool re-implements it. If the tool misbehaves, `SKILL.md` is the
   reference for what *should* happen.

## 2. Architecture (where each piece is)

All paths are inside WSL unless stated. `~` = `/home/<user>`.

```
~/yeshiva-shorts-skill/            ← this repo
  shorts.sh                        ← THE gate: sets PATH, venv, ffmpeg, deno, loads config.env. Always go through it.
  install.sh                       ← per-user installer (venv, libs, ffmpeg, deno). No sudo.
  windows/                         ← Windows-side one-click installer + launcher (see §8)
  drive_backup.sh                  ← mirror of finished shorts to Google Drive (rclone)
  backup_extras.sh                 ← backup/restore of what is NOT in git (music, settings, logo, guidelines)
  setup/ (setup.py doctor.py state.py)  ← first-run wizard + `shorts.sh doctor`
  assets/ fonts, face model (yunet onnx), default guidelines, logo/ & music/ (empty on purpose)
  docs/HANDOFF.md                  ← this file; docs/מדריך-העברה-למחשב-אחר.md (Hebrew, for the owner)
  SKILL.md, README.md, CHANGELOG.md
  pipeline/scripts/
    make_short.py            ← prepare / finish / rebuild / swap  (the engine of the tool)
    make_short_app.py        ← HTTP server on http://localhost:8790 (localhost only) + make_short_page.html (the page)
    make_short_pick.py       ← automatic segment picking (Gemini, or "copy to chat" and paste back)
    make_short_settings.py   ← advanced settings (DEFAULTS, reset/undo, rules_text for the picker)
    make_short_music.py      ← music library manager (remove/restore/upload/approve)
    tool_finder.py           ← finds/validates ffmpeg, ffprobe, yt-dlp, Deno, ASR engines, OS (see §11); stdlib only
    make_short_health.py     ← start-up health banner (ffmpeg, yt-dlp, cookies, Drive, Modal spend, disk) + scrub() for secrets
    make_short_update.py, make_short_chat.py ← update box (apply/rollback) + the block for a Claude chat (§8b, §8c)
    asr.py, modal_asr.py     ← transcription (Modal cloud GPU, or local faster-whisper)
    multi_piece_clip.py      ← build one short from several pieces of the lesson
    build_clean_video.py     ← cut on silence + face-tracked virtual camera + logo
    face_track.py, camera_sim.py, check_framing.py, camera_path.py (crop exits + zippy, 4n)
    karaoke_ass.py (teal karaoke subs), build_ass.py, align_clean_text.py, check_subs.py
    mix_music.py (music mix), music_library.py (index, rate, used), add_music.py (old)
    write_clip_meta.py, export_clips.py, series_cards.py, ask_gemini_*.py, gemini_verify_audio.py, ...
```

### The tool's flow (what the owner does in the page)

1. **New lesson**: paste a YouTube link. Either type rough times, or press "בחר קטעים לבד"
   (auto-pick, `make_short_pick.py`): whole-lesson transcript → rules from settings + his
   `guidelines.txt` → Gemini (if the key works) **or** "copy to chat": the page copies the
   transcript+instructions, he pastes into any free chatbot and pastes the answer back. Every
   opening/closing quote is fuzzy-matched to the transcript (green ✓ / yellow ~ / red ✗).
   (21/10) A short may be **several pieces** ("a-b, c-d"): the model skips stutters, repetitions and
   side remarks, one reason per skip; the page shows skipped text in grey and he can cancel or add
   a skip (setting "דילוגים אוטומטיים", default on; off = one continuous span). Playlist picking
   reads a **Modal turbo transcript of every lesson** (≈5¢ each, cost shown first; only a run that would cross
   the daily cap `modal_day_cap` needs a click — 4k; settings `modal_all_lessons`, `modal_missing`); YouTube captions stay as a second
   reading and a quote they hear differently gets a ⚠ "uncertain" mark.
2. **prepare** (`make_short.py prepare spec.json`): download, snap each boundary to *measured*
   silence, build the clean video (face-tracked camera), transcribe with **two ears**, write
   `<project>/לעריכה/clipN.txt` with `[ear1 / ear2]` wherever the ears disagree, YouTube
   captions beside it for reference.
3. **The human decides** the doubts in the page (play the spot, choose the word, fix punctuation).
4. **finish** (`make_short.py finish <project>`): align text → coverage gate → teal karaoke → logo →
   loudnorm -14 → music mix → metadata + credit — a **draft in the work folder only** (21/10/2026).
   A clip whose `finish_key` (edit file + color/logos/music settings + clean video) is unchanged and
   whose video is whole is skipped. **save** (`make_short.py save <project>`, page "💾 שמור לתיקייה")
   = `export_clips.py --to <rabbi>/<series> --known work/export_known.json` → one folder PER SHORT named after
   its title (4i, card 16; videos + «תיאור להעתקה.txt» only; re-save replaces in place, stale files move to
   `work/replaced_*`, never a second copy) → saved at once;
   it only marks `drive_pending.json`, and the window's background worker mirrors Drive later (4f, card 13).
   `st["saved"].snap` vs `snapshot()` = "יש שינויים שלא נשמרו". Lessons exported before 21/10 count as saved.
4a. **Resume** (21/10/2026): every job writes `<project>/progress.json` (`make_short_progress.py`): job
   argv + pid + status, plan, per-step state, data (video info, snapped cuts, built-clip keys, finish keys).
   status=running with a dead pid = interrupted → the page offers "▶ המשך מאיפה שעצרתי" = the same argv
   again; finished steps are skipped after `media_ok()` (ffprobe + decode the last second — a cut-off
   encode leaves an mp4 without moov). wav cuts and finish outputs are written to `*.part.*` then renamed.
   Tested by killing the job mid-build (twice) and the whole server mid-finish.
4b. **Durable work queue** (21/10/2026; since the same day for ALL heavy jobs, not only playlists:
   `QUEUE_KINDS` = prepare, finish, retime, restyle with color/camera, rebuild — music-only swap, save, pick
   scans stay immediate). `enqueue()` creates the job record at once as "queued" (`start_job(deferred=True)`,
   so the page's job polling keeps working) and `kick_queue()` launches one at a time in the queue order he
   sets in the side panel "📋 תור העבודה" (drag, ▲▼, ⏫ next, ✕ remove; `POST /api/queue/edit` actions
   up/down/top/to/remove/retry). Tab order is NOT priority. Items: kind + args (make_short.py argv) + project.
   `BUILD_Q` is written atomically (tmp + fsync + rename) to
   `~/.local/share/yeshiva-shorts/build_queue.json` (`build_queue_test.json` in test mode; `MAKE_SHORT_QUEUE`
   overrides) on every change. The lesson's project folder is fixed at queue time and written into its spec,
   so a restart knows where to continue. On start `queue_load()` restores it: an item that was running is
   settled from its progress.json (done / failed / still alive → wait / else back to waiting = resume), and
   `queue_watch` starts one lesson at a time even with no page open; no internet → items wait. Failed
   because the net dropped → back to waiting. Idle exit and "restart" never happen while items wait.
   Page: "📋 תור הכנה" card (▲▼ ✕, 🔁 retry), queued tabs `q:<id>`. Tab colors: grey pulsing = working,
   grey = queued, amber = needs him, light blue = only saving left, green = saved, red = failed (reason on
   hover). Tests use MAKE_SHORT_JOB_STUB (a fake job speaking the progress.json protocol).
4b. **drop / restore / drop_saved** ("🗑️ ויתרתי"): a dropped clip's draft moves to `work/dropped_*`, it
   leaves the save and the per-lesson count; a saved one's export copy goes to the Windows Recycle Bin via
   `win_recycle.py` (copy to C:\…\Temp\ys_recycle, verify, SendToRecycleBin, confirm in the bin, only then
   remove) and Drive is mirrored by the background worker. **retime** = new start/end from the page slider → snap → rebuild →
   two ears → `merge_text()` keeps his corrected text, adds only the new words. **context** = words with
   lesson times around a clip (pick transcript, else a short Modal turbo of the edges).
5. `rebuild` = rebuild with smoothed camera (before finish); `swap` = replace the music track.
   After finish, the page's per-clip "⚡ הגדרות מהירות" window previews first, then applies:
   `preview <project> <clip> music <uuid|off> | camera <default|smooth>` (15 s mix / 10 s 540x960 clip,
   seconds) and `restyle <project> <clip> [--color=RRGGBB] [--camera=..] [--music=swap|back|off|on --uuid=..]`
   (re-burn / rebuild / re-mix — since 21/10 the **draft only**; it reaches the folder on save). The color preview is
   drawn in the page over the clean video from `/api/sub_lines` (same chunking as karaoke_ass).
6. The server (`make_short_app.py`) exits by itself ~60 s after the last page closes (`/api/alive` is an
   open event-stream), never while a job, queued lesson or preview runs; `MAKE_SHORT_IDLE_EXIT=0` disables.
   The launcher pauses only on a non-zero exit. App icon: `assets/app/` (`make_icon.py` regenerates).

4c. **Big playlists in two stages** (21/10/2026, card 11). Setting `playlist_mode` (auto/each/strong; auto = "each"
   up to `playlist_auto_max`=15 lessons, "strong" above; his switch on the playlist screen = `mode_user`, wins). `mode`
   lives in the playlist's pick.json. *each* = old flow (one clip per lesson, Modal for all). *strong*: **stage A** =
   YouTube captions only for ALL lessons (free, ~3 s each, 4 parallel) → `series_cards.py` cards (now with a closing
   snippet) → `rank_prompt()`: ONE-THREE requests (cards packed by `gemini_chunk_chars` / `chat_chunk_chars`, ids
   `rg1` / `rc1…`, `st["rchunks"]`) → `parse_ranking`/`add_rank_answer` → `rank_score`/`rank_why` per lesson → ranking
   table (sortable, top `playlist_top_n`=3 pre-ticked, ticks persist as `rank_tick`). **Stage B** = `make_short_pick.py
   stageb <dir> 3,7 [--yes]`: Modal turbo only for the ticked lessons (`modal_step(only=…)`, estimate; crossing
   today's `modal_day_cap` → `modal_plan.needs_confirm`), then normal per-lesson prompts (`build_prompt(multi=True)`: several
   clips, skips, quote checks, `preselect()` per lesson). Lessons with `stage_b` only enter `make_chunks`.
   **"🔍 חפש קטעים אחרים"** (`request_more`): an extra one-lesson chunk `cx<k>`/`gx<k>` in `st["more"]` whose prompt lists
   the pieces he dropped (`exclude`); its answer is *appended*, overlaps with dropped ones are flagged and never pre-selected.
   **One tab per playlist**: built lessons are sub-tabs. The link is `pick.json lessons[i].project`
   (`link_playlist_lessons` at build time; `migrate_playlist_links` at startup finds old ones from `app_specs/spec_*_<pid>_<n>.json`);
   `lessons()` returns `parent`/`n`; the page shows `SUB[playlistKey]` = "table" or a lesson key; playlist tab colour =
   most urgent of its lessons (need > fail > almost > work/queue > done). Closing a playlist hides its lessons; opening one
   of its lessons un-hides it. **Word selection** (`edit_words`/`retarget`/`revert_pick`): the page renders the clip's
   words as spans (`ctx_words` → `[idx, word, start, end, 1 in / 2 skip / 0 out]`), right-click → add/remove →
   boundaries at the middle of the pause, opening/closing quotes re-taken from the transcript and `verify_pick` again;
   first edit stores `p["orig"]` for "↺ revert to Gemini". **Fidelity gate** = a "שים לב" list (his 4 questions with the
   model's own answer; red only for "no" or a quote not found; one confirm before build only when red) — no checkboxes.
   Page: sort control (localStorage `ys_pl_sort`), accordion details, queue items named lesson · clip «title» · kind
   (`queue_what`), setting `tab_layout` rows/rail.
4d. **Updating while working** (21/10/2026, `make_short_snap.py`). Every job (`SNAP_KINDS`) runs from an immutable
   snapshot of `pipeline/` + `shorts.sh` copied to `~/.local/share/yeshiva-shorts/snapshots/<sha1-12>/` at launch
   (`launch()` rewrites the script paths in its command; `assets/` etc. are symlinks), so mid-job sub-script calls never
   see new code; new jobs snapshot the new code — but only if it passed the self-check (otherwise the last good
   snapshot, `SNAP_BOOT`). `code_watch()` thread: file signature changes → settle `CODE_SETTLE` s → content hash ≠ the one
   loaded at boot → `make_short_update.py selfcheck` → `CODE["pending"]` (banner "עודכן — ייכנס לתוקף כשהעבודה תסתיים")
   or `CODE["failed"]` (banner with the log; nothing is applied). When `server_idle()` (no job, empty queue, no preview —
   unsaved drafts do NOT block, they are on disk) → `RESTARTING` (new jobs are refused for `RESTART_GRACE` s; the page
   autosaves typed text and the screen to `localStorage ys_resume`) → `os.execv`. The page notices a new code hash in
   `/api/lessons.code`, reloads, and returns to the same lesson / sub-tab / clip with the typed text. The "עדכון תוכנה"
   box can now apply during jobs (it does not run from a snapshot). Snapshots no live process uses (looked up in
   `/proc/*/cmdline`) and that are not the current one are deleted after jobs, every 5 min and at start.
   Test hook (test mode only): `POST /api/test/probe {secs}` runs `make_short_snap.py probe`. Test from a COPY of the repo
   (editing the real repo would make a running real server update itself).
4e. **Per-clip jobs, offline prep, line layout, badge** (21–22/10/2026, card 12).
   - *Per-clip jobs*: every job on ONE clip (retime, restyle color/camera/subs, rebuild, single finish `finish <p>
     --clips=clipN`, music swap) is a queue item with `clip`; `busy(project, clip)` blocks only that clip and whole-lesson
     jobs. Music swap is `LIGHT_KINDS`: in the queue (named in the side panel) but launched at once, in parallel with a heavy
     job, with `MAKE_SHORT_NO_PROGRESS=1` so it never overwrites the heavy job's record in progress.json (whose read-modify-
     write is now under a flock). `/api/project` returns `clip_jobs` (per clip: state/progress/step/ended_ts, from the
     persisted queue) — the page draws a bar inside that clip's card and detects "ended" from it (the job-24 bug: a swap
     finished and the card stayed "מתעדכן…" because the page polled a job id the restarted server no longer knew; unknown
     `/api/job` ids now return `gone`). Only prepare and finish-all use the full "בעבודה" screen.
   - *Edit versions + merge*: every write of `לעריכה/clipN.txt` (atomic) keeps a copy `work/edit_versions/<clip>_<md5-12>.txt`;
     the page sends `ver` with each save; if the file changed meanwhile (retime wrote new text), `save_edits` does a word-level
     3-way merge (`merge3`) — his edits applied onto the new text, edits whose words vanished are reported, never guessed.
     `retime` re-reads the edit file just before `merge_text` (he keeps typing during the build) and stores `retime_note`.
   - *Reviewed*: `st["reviewed"]` (opened + edited / doubts resolved / watched ≥5 s / manual). Finish-all with unreviewed clips
     or open `[א / ב]` asks first, naming them.
   - *Doubt chips*: resolving keeps a "הוכרע: X ↶ בטל" chip (positions tracked through every edit, localStorage
     `ys_res|<project>|<clip>`); undo restores the exact bracket, or says it can't find the spot. "✏️ משהו אחר" = typed
     replacement. Replacements go through `execCommand` so Ctrl+Z works. `align_clean_text`: a replace opcode copies the ASR
     words' times (N→N) or spreads over their span — no more interpolated half-second-late words.
   - *Offline prep*: queue flag `net_only` ("⏸ הכן לעבודה בלי אינטרנט", saved in the queue file): prepare items run with
     `--net-only` (info, download, refine/snap ASR, both ears on `source_clip_wav` = the clip audio cut straight from the lesson
     with the same 0.18 s acrossfade joins, captions) → PR data `net_ready` → lesson state `offline_ready`; local items wait
     while network items remain. "▶ המשך בלי אינטרנט" queues `prepare <spec> --local` (`offline_ok`, runs offline; any missing
     network step stops with an explanation). `MAKE_SHORT_ASR_NO_CPU=1` in both modes: never a silent CPU transcription.
     Measured 21/10: the source-cut wav and the built clip's audio are sample-identical (cross-correlation 1.000, offset 0.0 ms).
   - *Line layout*: `make_short_layout.py` — `work/subtitles/<clip>_layout.json` (normalized words + chunks of rows of word
     positions). `karaoke_ass.build(rows_layout=)` (NOT `layout`, that name is the emphasis variable inside the loop) uses it
     with every chunk "hard" so polish never re-merges; after re-align `apply()` keeps chunks whose words still match and
     auto-chunks the rest. `finish_key` includes the layout file; `restyle --subs` re-burns. Page "📐 פריסת שורות" on finished
     clips (results card, and edit card of a clip that has a draft).
   - *Notifications*: top-bar 🔔/🔊 toggles = `localStorage ys_notif`. Badge: a lesson entering amber/light-blue/red while the
     window is not visible+focused → `navigator.setAppBadge()` (installed app only) + a dot drawn on the favicon; cleared on focus.
     Installable: manifest `id: "/"`, `/sw.js` (no caching). The launcher opens `msedge --app-id=bjoljknpfoccfpojifilpppoedcoahck`
     (= Chromium id of `http://127.0.0.1:8790/`) when `…\Edge\User Data\Default\Web Applications\Manifest Resources\<id>` exists.
   - Tests: `pipeline/tests/test_clip_jobs.py` (stub jobs `job_stub.py`, isolated temp dir: swap seen "done" ≤3 s after it
     ends, light swap parallel to a rebuild, gone job ids, merge on stale ver, single-clip finish) and `test_layout_align.py`.
     Run with `shorts.sh py ../tests/<file>`.
4f. **Background Drive backup, per-clip music volume, ❤ / heard / disabled, smart pick** (22/10/2026, card 13).
   - *Backup is never part of a job*: `save` / `drop_saved` export, verify, mark saved, and only call
     `mark_drive_pending(why)` (`drive_pending.json`: n, rev, since, last_change). `drive_watch` in the app (one thread)
     runs `drive_backup.sh` for the WHOLE Shorts folder `MAKE_SHORT_DRIVE_DEBOUNCE` (90 s) after the last change, 15 s
     after start if something was left from last time, at once when `net_watch` sees the internet return (`kick`), and
     on "☁ … — לנסות שוב" (`POST /api/drive/now`). It waits while a save/drop_saved is writing. A run that saw a new
     `rev` appear meanwhile leaves the newer mark pending. Failure → `drive_status.json` (error, fail_since), auto-retry
     every `MAKE_SHORT_DRIVE_RETRY` (300 s). `drive_backup.sh` takes a flock (`logs/drive_backup.lock`): exit 5 = another
     backup running (not a failure). Top bar `☁` = `drive_view()` in `/api/lessons` → ok / running / pending N / failed
     (click = details, retry, reconnect); hidden when Drive is off. Successful syncs are never announced (his rule).
     Idle auto-close waits up to 2 min for a running backup and starts no new one (`DRIVE_Q.closing`); the rest runs
     at next start. Measured: save → "נשמר" in ~2 s while the indicator went pending → running → ok.
   - *Per-clip music volume*: `c["music_db"]` (−8…+6 dB, relative to `music_level`; total capped at +6 by
     `SET.music_levels(clip_db=)`), used by finish/"צור שוב" (`finish_key` includes it when non-zero), preview
     (`preview … music <uuid> --db=N`, levels in the file name, mode `keep` = same track) and `restyle --db=N`
     (light "swap" queue item, ≈5 s).
   - *❤ / heard / disabled* live in his `music-feedback.json` (never in index.json — the share package does not ship the
     feedback, so a receiver starts clean): ❤ = rating `good` with note `LIKE_NOTE` (also approves the track); heard =
     `heard_at` (≥5 s of a preview in the library or a clip card, or a saved short) or a use after `heard_reset_at` /
     `heard_cleared_at`; disabled = `disabled` (file stays in tracks/, status "disabled", out of `pick_pool` and of the
     page's ‹ › `pool()`). "איפוס כל הלייקים" clears ❤ + heard, snapshot in `music-feedback.json.likes-undo.json` for "בטל".
   - *Smart pick* (`smart_music`, default on): `pick_pool` keeps every old exclusion; when every ACTIVE track is heard and
     at least one has ❤ (`MUS.smart_ready`), `pick_track` draws weighted (❤ 3, others 1) instead of least-used. The ❤
     condition matters: on 22/10 all 27 active tracks already counted as heard (used in shorts) — without it he'd have
     got blind random.
   - Tests: `pipeline/tests/test_music_likes.py` (temp copy of his feedback; 200 picks ❤≈2.7× per track, all 27 still
     drawn; disabled never; undo restores the file byte-for-byte as JSON).

4g. **Correct after burn, settings snapshots, audit + selftest, share zip kept current** (22/10/2026, card 14).
   - *Doubts in the box*: `wireHL(x)` = a mirror `<div class="hlm">` behind the transparent textarea (same font,
     padding, scrollbar width; `scrollTop` synced; repainted on every input, deferred 120 ms above 15k chars). Every
     `[...]` gets an amber `<mark>`. Chips / undo / Ctrl+Z unchanged (they still work on the textarea).
   - *Correct after burn*: a clip with a draft shows the BURNED video in the edit card with a "🎬 צרוב | מקורי" switch
     (`VIEWSEL[P|clip]`, kept in `ys_resume` together with `EDITBACK`, so a self-update reload stays on the edit screen).
     "✏️ תיקון טקסט" on a result card = `CLIPTAB[P]=clip; backToEdit()`. "✓ החל את התיקון" = the existing per-clip finish.
   - *Skip text check* (`skip_text_check`, default off): `queue_job_ended` → `wants_auto_finish(q, job)` (prepare ok,
     not `--net-only`, the prepare's settings SNAPSHOT says so) → `auto_finish()` marks `st["text_unchecked"]` and
     enqueues finish (ear 1 for every bracket — the brackets stay in the edit file). Clips without title/desc are skipped
     (`st["auto_finish"]`). The page sends `text_ok` (edited / resolved / marked reviewed / re-burnt) → removed from
     `text_unchecked`; "💾 שמור" confirms while any is left.
   - *Settings snapshot per job*: `enqueue()` writes `job_settings[_test]/<qid>.json` (`settings_snapshot`), `_job_for`
     sets `MAKE_SHORT_SETTINGS` + `MAKE_SHORT_SETTINGS_SNAP` for the job; `job_begin` records it in progress.json and
     `resume()` reuses it. Snapshots no queue item references are deleted after 14 days (at start).
   - *Audit guards*: all tracks disabled / empty library → finish builds without music + "⚠️ אין אף מנגינה פעילה"
     (was a failure); `/api/drop` → `drop_clip_jobs` (waiting items for that clip leave the queue; a clip or lesson job
     that is running → refused); `random_off` (finish draws from the allowed default colours by file hash; all off →
     teal + report line; the page's 🎲 the same with a toast); settings greys out music level / smart pick when music
     is off, says when both logos are off or no track is active; self-update also waits for the package check.
   - *Selftest*: `make_short_selftest.py [matrix|package|all] [--json] [--keep]` — see its docstring. matrix ≈ 70 s,
     package ≈ 10 s. Everything in a temp dir; `drive_on` false for its save (the test-mode Drive files are shared).
   - *Share zip current*: `share_watch` (every 60 s, only when `server_idle()`): new code hash → `share_check_run()` =
     `make_short_selftest.py package --json` → `logs/share_check.json` (red alert in settings → מערכת when it fails —
     e.g. an untracked or uncommitted runtime file, which a zip built from HEAD would not contain). `SHARE.stale_info()`
     = newest zip's `package.json` commit vs HEAD → "קובץ השיתוף ישן (גרסה X) — בנה מחדש" (`build --prune`: older zips
     → `_old/<stamp>/` → Recycle Bin via `win_recycle`; test mode keeps them in `_old`). `share_auto_rebuild` does it
     by itself. `SHARE.scan` also refuses music-feedback / settings / queue / drive / tabs json and `.git-credentials`.
   - *Meters*: `/api/modal_meter[?refresh=1]` (only `HEALTH.check_modal()`), after every prepare/retime/pick (now and
     +240 s) and every 10 min from the page; 🔄 next to both meters, tooltip "נבדק לאחרונה: HH:MM".
   - *Notification sound*: `notif_sound` (7 WebAudio sounds in `SOUNDS`, ▶ preview); 🔊 still toggles.
   - Test switches: `MAKE_SHORT_NO_SHARE_CHECK=1`, `MAKE_SHORT_SHARE_WATCH_DELAY=<s>`, `MAKE_SHORT_NO_MODAL_METER=1`.

4h. **🔠 Enlarged words — only as his opt-in, + subtitle preview before burning** (22/10/2026, card 15).
   History: the ×1.3 "word the rabbi lingered on" (karaoke `--emphasis`) was default 12–15/10 and CANCELLED by him on
   15/10 (the automatic pick hit the wrong words). On 22/10 he asked for it back ONLY as a switch he controls, with the
   words proposed by the language model and editable by him. Claude's own shorts workflow stays WITHOUT enlarge.
   - *Proposal, always*: `build_prompt` asks for `emphasis: [{word, quote}]` (0–2 per ~7-word subtitle line, the word
     carrying the meaning — not merely the one he lingered on); `parse_answer` → `p["emphasis"]` (`EM.clean_picks`:
     strings, `"...*word*..."`, dicts); `add_answer(src=gemini|chat)`; `/api/pick/build` carries `emphasis` + `emph_src`
     into the spec; `prepare` writes `work/subtitles/<clip>_emph.json` = `{on, picks|null, proposed|null, src}` once
     (`on` = setting `emph_default`, default false). No model pick (manual times / old lessons) → `ensure_proposal` =
     karaoke's old `plan_emphasis` heuristic on the current aligned text, labelled "הצעה אוטומטית".
   - *Anchoring* (`make_short_emph.resolve`, mirrored in the page as `emResolve`): a pick is TEXT (`w`, quote `q`,
     relative position `at`), never an index. Exact normalized word first; else prefix/suffix or similar (≥0.7) together;
     the occurrence whose ±6 neighbours share the most DISTINCT quote words wins, then nearest `at`. Not found → `lost`
     (shown in the page, reported by finish, never burned). Picks the user marks are rebuilt from what is resolved now
     (so lost ones drop at his next edit).
   - *Burn*: `emph_for_burn` → `KA.build(..., emph_idx=set)`; None (switch off) = byte-identical .ass to before (tested
     against a stored clip). `plan_from_idx`: ≤2 per subtitle (`EMPH_PER_SUB`, extra → report); `emphasized_layout` now
     takes several words; if two big words don't fit the 960 px line, the first alone; still per-word events (bidi).
     `finish_key` includes the emph file only when on (off keeps old keys → no needless rebuilds).
   - *Page (edit card = also the post-burn correction view)*: "🔠 הגדלת מילים" checkbox beside the text box; on →
     blue background + underline in the `.hlm` mirror (`x._emr()`), legend with source, ⚠ for lost words,
     "↺ חזרה להצעה של Gemini/הצ'אט/התוכנה" when edited. Right-click on 1–2 selected words → «🔠 הגדל» / «בטל הגדלה»
     (`e._emph` keeps the card-11 document handler from closing the menu); adding is checked against the REAL chunking
     (`/api/sub_preview` `over` count) and refused with a toast when a subtitle would get a 3rd. Saved by `/api/emph`
     (no burn); the clip's "✓ החל" re-burns it.
   - *Preview before burning*: "▶ תצוגה מקדימה לכתוביות" under the player → `/api/sub_preview` (unsaved textarea text →
     `plain_text` (first option of each doubt) → `ACT.align` to ear 1 → `_lines` = same chunks/rows/layout overrides/big
     words as the burn) → drawn on the CLEAN video (`subsHTML`, `.subov .big{font-size:1.3em}`) in the clip's colour
     (`preview_rgb` mirrors finish's choice); refreshed 0.9 s after typing; warns on coverage <90% (finish would stop).
   - *Results card*: quick row 🔠 כבוי / הגדלת מילים (pending `q.emph`, preview via `/api/sub_lines?emph=on|off`,
     "✓ החל" → `restyle --emph=on|off` → re-burn) and "▶ כתוביות" (same drawn preview, no colour change needed).
4i. **Flat export layout + clean rabbi/series names** (22/10/2026, card 16). His words: "אני לוחץ מלא פעמים על
   התיקיות עד שאני מגיע לתוצר... שהכותרות שם כבר יהיו קשורות למה שהיה בתוכנה". For the tool AND Claude's exports:
   `~/Videos/Shorts/<rabbi>/<series>/<short title>/` holding only `<title   rabbi>.mp4` + «תיאור להעתקה.txt»
   (was `<rabbi>/<series>/<date>_<slug>/shorts/clipN_<title>/`). Rules live in ONE module, `shorts_layout.py`:
   - `clean_rabbi` ("הרה"ג X שליט"א" → "הרב X"; quotes, double spaces), `clean_series` (Windows-illegal chars:
     בש"ס → בשס), `name_key`/`match_dir`/`resolve_names` = a name equal to an existing folder ignoring quotes,
     gershayim, honorifics and spaces JOINS that folder (no duplicate rabbi/series). `guess_names`/`existing_folder`
     in make_short use it (prepare, finish, save; playlists too); the page mirrors `name_key` as `nkey` (change both)
     for the series datalist and the "📁 נשמר לתיקייה הקיימת / סדרה חדשה / רב חדש" hint under the rabbi/series fields;
     `/api/project` carries fresh `folders` (a rabbi created by a save shows up at once).
   - `short_dir`: folder = title before "|", sanitized, ≤80 chars and trimmed until the Windows path (`\\wsl.localhost\…`)
     is ≤250; taken by ANOTHER short → " (2)"… A short that already owns "X (2)" stays there even if "X" frees up.
   - `export_flat` (export_clips): `--known {clipN: dir}` (tool state) + the ledger's `clips` (Claude re-exports) =
     dirs this clip owns; title changed → `old.rename(new)` (same disk, never two copies); stale files → project
     `work/replaced_*`; rabbi/series changed → moves too, empty old series/rabbi folders pruned (`prune_empty`, rmdir
     only). Prints `EXPORT_DIRS=<json>`; ledger line gets `layout: short, clips: {...}`. `--to` relative = under the
     Shorts root, and the first two parts are cleaned/matched; depth <2 → refused. `--layout lesson`/`--into` = old way.
   - Tool state: `export_dirs` {clip: dir}, `export_target` = the series folder, `export_layout: "short"`.
     `drop_saved` recycles `export_dirs[clip]` (then prunes empties). A lesson saved in the OLD layout and not yet
     reorganized (export_target has `shorts/`, no export_dirs) keeps saving with `--into` — so a re-save never leaves
     an old + new copy.
   - `reorganize_exports.py --plan` → Hebrew `C:\Users\<user>\yeshiva-shorts\תוכנית סידור תיקיות.txt` (every short →
     new path; his own grouping folders like "א. בקשה ישירה…" that would flatten; files he renamed; leftovers like
     gemini/, *.wav, "מה יש כאן.txt" that stay — so their folders stay). Title = the title part of the FILE name
     ("כותרת   הרב") — he renamed some to his YouTube title — else the project's meta.json. `--apply` (ONLY with his
     OK): os.rename + size check, prune empties, ledger `event: reorganize` lines, tool states → new dirs, then
     `drive_backup.sh --allow-delete <moved files>` (Drive: old paths → Drive trash, new uploaded ≈3 GB).
   - Tests: `pipeline/tests/test_export_layout.py` (names, near-duplicates, new rabbi/series, twins, rename, long path,
     reorganize plan+apply on a fake tree); selftest save checks depth 4. Selftest/tests now write their ledger to
     `SHORTS_EXPORT_LEDGER` (before 22/10 the selftest appended "הרב בדיקה" lines to the real exports.jsonl).
4j. **"✓ הועלה" + "🧹 נקה" — he cleans uploaded shorts himself** (22/10/2026, card 17). Before this he asked Claude
   to delete each uploaded lesson with all its work files (no hidden leftovers). Now, in the tool only:
   - Mark: `/api/uploaded {project, clip?, on}` → `clip["uploaded"]=date` (saved shorts only, mark only, undoable).
     All live shorts uploaded and nothing unsaved → lesson state `uploaded` (purple `c-up` in tabs/past/legend).
   - Clean: `make_short_clean.py` — `plan(items)` (no side effects: which shorts, export dirs, work bytes, not-uploaded
     list, `too_big` > 12GB = Recycle-Bin cap, `MAKE_SHORT_CLEAN_MAX_GB`) and `run(items)` (a `clean` job, project "").
     One short = `export_dirs[clip]` (old layout: `<lesson>/shorts/clipN*`) + only files whose path has a `clipN`
     component (`(^|_)clipN(?=$|[_.\s])` — never clip21; not לעריכה/, not source/), moved into
     `<lesson>/_ys_clean_<clip>_<ts>/` then ONE recycle (moved back if the bin step fails); state → `dropped+cleaned`,
     out of export_dirs/saved; restore refused. The last live short (or no clip given) = the WHOLE lesson: its export
     dirs (old layout: the lesson folder, only if it holds just `shorts/clipN*`), its app_specs (moved inside first),
     then `projects/תוכנה/<lesson>` itself. Every removal = `win_recycle.recycle` (copy → verify → SendToRecycleBin →
     confirm in bin → rmtree); guards: inside projects/תוכנה or the export root, depth ≥2/3, never a root.
     `prune_empty` after each export dir. Ledger line `event: clean` per lesson.
   - Drive: `mark_drive_pending(why, allow_delete=N)` accumulates the exact number of export files removed;
     `run_drive_backup` passes `--allow-delete N` when N > 10 and subtracts what that run consumed.
   - App guards: no clean while the lesson has a running/queued job, a running preview, or another clean
     (`clean_blockers`); a playlist folder only after all its linked lessons are gone; `CLEANING` set blocks new jobs
     (start_job/enqueue) on it; after the job (`clean_ended`) a removed lesson leaves the queue, closed-tab list and
     its settings snapshots. Never touches Claude-made projects (outside projects/תוכנה) — those stay "ask Claude".
   - Page: per result card "✓ הועלה"/"בטל סימון" + "🧹 נקה"; lesson card "🟣 כל השורטס הועלו → 🧹 נקה את השיעור"
     or "סמן את כולם"; dialog "יימחקו: N שורטס ו-X קבצי עבודה" + per-lesson list + bin/Drive-trash restore line +
     blockers + required tick for not-uploaded shorts → progress per lesson; past lessons show size, 🧹 per row and
     "🧹 נקה את כל מה שהועלה". Restore = manual, from the Windows Recycle Bin.
   - Tests: `pipeline/tests/test_clean.py` (fake bin via `MAKE_SHORT_FAKE_BIN`, temp dirs; incl. >10 Drive deletes).
4k. **Settings review fixes** (22/10/2026, card 18 — he reviewed the advanced settings).
   - **Fix actions re-check at once**: after "עדכן עכשיו" (yt-dlp) succeeded the banner stayed and he pressed again.
     `HEALTH.run_one(id)` + app `recheck(ids)` after every fix (yt-dlp job end, cookies upload, Drive reconnect —
     rclone writes `drive_reconnect.done`, tool choice, Gemini key save/check). `HEALTH_STATE` has `ver`, `actions`
     (result shown in place of the button: "עודכן ל-X ✓" / error) and rides on `/api/lessons` → the page redraws by
     itself; buttons lock while running and a 2nd press returns the same job. Test hooks (test mode only):
     `MAKE_SHORT_FAKE_YTDLP=<file>`, `MAKE_SHORT_FAKE_RECONNECT=0`.
   - **Theme**: visible 3-option switch (☀️ בהיר · 🖥️ לפי המחשב · 🌙 כהה) in settings → מערכת (`localStorage.theme`).
   - **Transcription engine** `asr_engine` = `modal` (default, "מומלץ") | `cpu` ("רק כגיבוי — איטי ופחות מדויק"),
     settings → 🎙️ תמלול. Modal failing mid-job **never** falls back to the CPU silently: `asr()` raises (message contains
     "💻 תמלול במחשב") → failure card / queue row offer "💻 תמלול במחשב (הפעם)" → `resume(allow={cpu})` / queue retry
     with `allow` → env `MAKE_SHORT_ASR_ALLOW_CPU=1`. Picking with cpu = YouTube captions (CPU only if none); playlists
     never CPU-transcribe. The old radio in "כלים במחשב" (it wrote `SHORTS_ASR`, which is Claude's skill setting) is
     now display-only.
   - **Modal cap per DAY** (his request): `modal_confirm_usd` (per request) → `modal_day_cap` (default $1; old value
     migrated in `SET._read`). `make_short_modal_day.py`: ledger `modal_day.json` (test: `modal_day_test.json`,
     `MAKE_SHORT_MODAL_DAY`); spent today = max(sum of estimates recorded when jobs start, Modal's billing report
     `--for today` read with the meter, free). Within cap → no question; a crossing job asks with
     "היום כבר: $X · הפעולה: ~$Y · התקרה: $Z" (playlist `modal_step`, stage B, single-lesson pick → `modal_plan`;
     clip ears/retime → `MD.gate` raises `OverCap` before anything is sent → "✓ אשר והמשך" = `allow={modal_ok}` →
     `MAKE_SHORT_MODAL_OK=1`). `MD.cap()` always reads the LIVE settings, even inside a settings snapshot.
   - **Editing rules** in three sentence rows (רגיל / קליף קצר / פלייליסט), ↺ per field.
   - **Live alerts**: Gemini is a health item built only from `gemini_status()` (🚨 never a generateContent request —
     `test_live_alerts.py` spies on urlopen); `precheck(kind)` at job launch (cookies before prepare/pick, Gemini before
     pick, Modal before Modal jobs); `health_watch` every 30 min (`MAKE_SHORT_HEALTH_EVERY`); `job_end_alerts()` maps a
     failed job's log ("Sign in to confirm"/cookies, HTTP 403/nsig/format, Modal auth/payment) to `JOB_ALERTS[id]`
     (replaces the generic item, "עלה מהעבודה", cleared by the matching fix or a later good job). Pick jobs re-read
     the Gemini counter at the end. `MAKE_SHORT_GEMINI_USAGE` = other counter file (tests).
   - "התקנה כאפליקציה" hint line; meter refresh = SVG icon inside each chip (Gemini local-only, Modal free billing call).
   - Tests: `test_modal_day.py`, `test_live_alerts.py`; `job_stub.py` gains `STUB_ASK=cpu|cap`, `STUB_FAIL_MSG`.
4l. **Card 20 (28/10/2026) — fixes after his real use 22–26/10.**
   - **One colour per clip.** `subtitle_terms.fix_words(color=False)` in karaoke_ass / `_lines`: the old gold `{\c}`
     for subtitles with Latin letters ("D9", RPG) sat on both karaoke layers → that line came out gold. Clips burned
     before get `color_glitch` in /api/project → "🔧 תקן את השורט הזה" (restyle `--subs`, same colour; save is his).
   - **Subtitle styles** (`karaoke_ass.SUB_STYLES`, `; ys-style: <name>` line in the .ass, settings `STYLE_TOKENS`):
     `karaoke` (as always) and `plain` = "ללא צבע" (token `PLAIN` wherever an RRGGBB colour goes: sub_color `plain`,
     `random_off`, `sub_rgb_user`, /api/restyle). Plain = white, no running highlight; with 🔠 on the marked words are
     the only coloured words (`\clip` on the measured word box for the whole subtitle, never an inline colour tag),
     colour = `em_rgb_for(ass path)` from `SET.em_pool()`. ONE place picks/burns: `make_short.clip_choice` +
     `build_subs` (finish, restyle, previews). New style = a SUB_STYLES entry + a token + JS `SUB_STYLES`.
   - **Per-clip independence.** "סיים את כולם" / auto finish = one queued finish PER CLIP (`finish_clips`, clip=…).
     `save --clips=` + `export_clips --only` ("💾 שמור את הקליף הזה"); `save_start` saves all non-busy clips and
     reports `skipped`; saved snap merged per clip; `unsaved_clips` in /api/project. Page: results = per-clip cards
     (burned / building / ✏️ editor inside the card — `CLIPVIEW`, kept in localStorage), names card always at top.
   - **Previews** = clean video + burn-exact overlay + the draft's audio (or the music preview) in a synced `Audio`
     (`pvAudio`/`pvSync`), labelled "▶ תצוגה מקדימה"; same in the edit card's subtitle preview.
   - **Skip text check** (bug): titles "נושא | הרב X" have no series → auto_finish used to refuse the whole draft.
     Drafts no longer need rabbi/series (save does; `refresh_meta` rewrites meta.json when `names` changed). The
     decision honours the live setting too (turned on after "הכן").
   - **`auto_burn` "🤖 אוטומטי עד הצריבה"** (default off): `auto_burn_after_pick` after a pick job — Gemini picks
     (`emph_src=="gemini"`) not `bad` are prepared with `auto_burn=True` → auto finish; bad ones listed in pick.json
     `auto_note`; clips get `auto_picked` → "⚠ נבחר אוטומטית". No Gemini picks → note, normal flow.
   - **"📜 הקטע והסביבה שלו"** in every clip editor: `/api/scene` (`scene_words`: lesson transcript or edge windows +
     ear1 mapped to lesson time; skips + `orig` from spec/pick.json); right-click ➕/➖, ↺ Gemini, "החל" = retime.
   - **Text-box highlights**: mirror copies every font/wrap property, repaints after fonts load; legend under the box.
   - **Installed Edge app**: Edge's id is NOT a hash of the URL (his = iboagkmlcmmfaeilbkogjlpleldijjba); the
     launcher reads `%LOCALAPPDATA%\YeshivaShorts\app_id.txt`. `windows/app_link.ps1` (run by the installer) finds
     the id in Edge's shortcuts, repoints them to the launcher, registers `yeshivashorts://` (HKCU). The service
     worker serves `/offline.html` ("התוכנה מתחילה…") when the server is down; it opens `yeshivashorts://start/`
     (launcher arg → `minnowin`: server only) and reloads when /api/home answers. A Windows 11 taskbar pin has no
     .lnk — only this fallback covers it. 🚨 The assistant's safety check blocks running app_link from a session and a
     launcher that runs it with ExecutionPolicy Bypass — the owner runs it (installer / one command).
   - Selftest: D9-style one-colour after finish/restyle/text fix; ללא צבע burn = page preview; auto_burn on/off;
     missing series still drafts.

4m. **Card 21 (28/10/2026) — "🧠 העורך החכם": text quality like a Claude session.** His complaint: Claude-made shorts
   need a word fixed now and then; tool shorts needed fixes in almost every clip. Cause: Claude *adjudicates* the two
   ears with understanding; the tool only showed `[א / ב]` and fell back to ear 1. Baseline (his 3 last corrected
   lessons, 6 clips): 44 words changed out of ~690 (6.4%).
   - `make_short_editor.py`: ONE Gemini request for all clips of one or more lessons — each clip's audio inline
     (mp3 16k mono 32kbps, `audio_bytes`, ≤11MB/≤14 clips per request, else split), ear 1 + ear 2 texts, YouTube
     captions, title/rabbi/series/clip title, `RULES` (exact words, no dropped sentences, nothing invented, verses
     /Chazal in original wording, honorifics, Aramaic/idioms, acronyms, punctuation = line breaks, short words by
     listening not voting), the personal glossary. Answer JSON: final text with real doubts as `[best / other]`
     + per doubt `more` (≤5) and `why`. `check()`: coverage ≥90% of ear 1, no dropped run >3s, no ≥7 added words
     that no ear/caption heard — else that clip keeps today's text (state `partial`/`failed` + Hebrew msg).
     `apply_clip` merges anything he typed meanwhile (`editor_base` version + `merge3`), sets doubt times
     (`times_for`), `doubt_more`, `delivered_<clip>.txt`. Thinking capped (`thinking=4096`; uncapped, 6 clips did not
     return within 10 min). PICK.gemini_call got `parts=`, `temperature=`, `thinking=` (same counting/stops).
   - Status in make_short.json `editor`: pending → sending → done/partial/failed/chat/skipped; `after` = an automatic
     draft waits for it. prepare sets `pending` (setting `smart_editor`, default on) and records `ear2`, `editor_base`.
   - **Batch window** (app `editor_tick`, every 4 s, `editor_decide` is pure + selftested): lessons on the way = queued/
     running prepare items (not net-only) + running pick scans when auto_burn is on. Others on the way → wait for them
     (cap `editor_cap_min`, 20); none → wait `editor_window_min` (3; 0 = never); a waited-for lesson that fails/leaves
     the queue stops counting → send at once. "שלח עכשיו" = force. One `editor` job (`projects` list; `busy()` knows
     it). Gemini unusable (no key/blocked/quota) → sent at once → `chat`. Restart mid-send → back to pending.
     Server never idle-exits while a wait has an end time.
   - Same window for **picking**: a single-lesson scan with `MAKE_SHORT_PICK_HOLD=1` sets `gemini_hold` instead of
     asking; `pick_tick` → `make_short_pick.py together P1 P2…` = one request (`build_prompt(mixed=True)`, lessons
     renumbered, answer split by `lesson`). Playlists unchanged. Pick screen: "⏳ … · שאל עכשיו".
   - Automation: after prepare, `editor_after` parks the auto draft in `editor.after`; `editor_ended` → `editor_continue`
     → `auto_finish`. auto_burn + editor unusable → `auto_stop` notice, NO burn ("📋 העתק לצ'אט" / "צרוב בלי העורך").
     skip_text_check alone → burns with today's text. Manual "סיים" while pending → editor skipped (never overwrites).
   - Page: editor line in the edit card + results ("ממתין לשיעור X כדי לשלוח יחד · שלח עכשיו · דלג", sending, chat
     box with copy + paste, failed + retry); per doubt "💬 why", collapsed "עוד הצעות (N)", and per clip
     "🔍 חפש הצעות אחרות" = ONE request for all open doubts (`ED.alts`: ±3 s audio window each, all known options
     sent as excluded; confirm shows the counter). Settings → כתוביות → ✍️: switch, two minute fields, 📖 glossary
     (remove = never relearn, add, reset + undo) and 📏 quality meter (avg words fixed per clip, with/without editor).
   - **Glossary** `~/.config/yeshiva-shorts/glossary.json` (no secrets; `MAKE_SHORT_GLOSSARY` in tests): on every
     save `on_saved` diffs delivered vs saved text → `learn_pairs` (1–3 word replacements; not punctuation, deletions,
     prefix-only or function words). Fed to the editor prompt and, as whisper `--prompt` (modal_asr got `--prompt`),
     to ear 1 only; `hint_suspect` compares with ear 2 (no hint) and re-transcribes ear 1 without the hint if the start/
     end was swallowed or <85% of the words (the 9/2026 "prompted run lost 15 s" lesson).
   - **Quality meter**: `on_saved` → clip `quality` {changed, words, src} + `text_quality.jsonl` (`MAKE_SHORT_QUALITY`);
     result card "📏 תוקנו N מילים"; settings average per source. Retime keeps `delivered` aligned (merge_text).
   - **Per-step key / chat (his request, same day; commit 4f99e5c).** Settings `gm_pick`, `gm_playlist`, `gm_rank`,
     `gm_editor`, `gm_alts` = "key" (default) / "chat"; `PICK.step_direct(step)`. Chat = the step never sends on its
     own (`ask_gemini(auto=True)` skips those chunks, `gemini_stop.kind="chat_mode"`; his click on "Gemini" still
     asks); the editor goes straight to `chat`; "🔍 חפש הצעות אחרות" returns `chat_needed` + a self-contained block
     (`ED.alts_chat`, no audio, excluded options), `/api/editor/alts_paste` applies it through the same parser.
     Any GeminiStop (no key / blocked / quota / margin) on these steps also lands in copy-to-chat — never a dead end.
     auto_burn: a chat step pauses (`auto_pause` in pick.json, or editor `chat` + `after`) → `row.pause` → one page
     notification; pasting the pick answer resumes the automatic build (`auto_burn_after_pick(srcs=gemini+chat)`).
   - **Early stop before the daily limit** (`gemini_margin`, default 2; 0 = only Google's stop): `margin_left()` =
     limit (Google-calibrated, else 20) − margin − used; `gemini_call` raises `quota_margin` (Hebrew msg + reset time)
     before sending (not for a typed test key); the editor refuses a batch whose requests don't all fit; meter shows
     "עצר לפני הגבול 📋". Loop audit: every request comes from a step or a click; stops never re-queue; `together`
     drops `gemini_hold` and saves BEFORE asking. Old `gemini_verify_audio.py` (Claude's manual path) keeps its own
     5-try retry — the tool never calls it.
   - 🚨 Parser lesson: `_json_chunks` tries `[...]` first — on `{"doubts":[{"options":[…]}]}` it returned the inner
     list. `ED._json_obj(text, key)` prefers an object holding the key (selftest caught it on a fenced chat answer).
   - 🚨 28/10 evening: Google answered **503 "high demand" to every request with audio** (flash-latest, 3.6, 3.8; inline
     and Files API) while a text request on gemini-3.6-flash succeeded — the key works. The before/after evaluation is
     in `side-session-notes` / his summary; rerun `make_short_editor.py run <copies>` when Google recovers.

4m2. **4.1.1 (19/11/2026) — smart editor never blocks the text, and is skipped when Gemini is known down.** He reported
   (a) while "🧠 working" he could not even look at the text; (b) Gemini had been 503/timing out for days and the editor ran anyway.
   *Root cause (a):* the editor job (`kind="editor"`) was not in the page's `QUICK_KINDS`, so `_refresh` treated it as a heavy
   whole-lesson job and replaced the edit screen with the "בעבודה" card. Fix: `"editor"` added to `QUICK_KINDS` — the text stays
   open; the existing merge (`apply_clip`: `editor_base` + `MS.merge3`, his words win) makes "what you fix meanwhile is saved" true;
   `edReload` saves `DIRTY` first. *(b):* `PICK.gemini_unusable(P)` = (kind, Hebrew msg) | None: no key / key blocked / step set to
   chat / model blocked (quota day/minute) / margin stop / `recent_fail()` (busy 5xx or timeout within `gemini_recent_fail_min`=15,
   0=off) / the lesson's own `pick.json gemini_stop` (now stamped with `ts`) of a Gemini kind within that window. The failure is
   recorded in `gemini_usage.json` as `last_fail {kind, at, msg}` (atomic, no secrets; preserved over the day reset; any real
   answer clears it) by `gemini_call` (new `GeminiStop` kind `"timeout"`). `editor_gate()` (called first in `editor_tick`) writes
   `status="chat", skipped=True, msg="העורך החכם לא הופעל כי …"` for those lessons — no process, no 3-minute pending window — and
   calls `editor_continue(p,"skip")` so "אוטומטי עד הצריבה" goes on instead of waiting (decision: continues with the ear-1 text;
   `chat_mode` is the exception — he chose it, so it still stops before burning). `EDITOR["manual"]` (set by "🔁 נסה עם Gemini"
   = `/api/editor/again`, and "שלח עכשיו") bypasses the gate; `gemini_call` still refuses blocked/quota by itself. Never switches
   model. *Timeouts:* editor request was `timeout=900` → `editor_timeout_sec` (default 240; settings 30–900); 503/timeout = no retry,
   one request, then `chat/skipped`. The 3-minute pending window (`editor_window_min`) is only a batching wait and is not started
   when Gemini is unusable. *Stop:* `/api/editor/stop` → `editor_stop()` SIGTERMs the job's pid (`job["stopped"]`; also handled if the
   pid isn't up yet), `editor_ended` → `status="skipped"` "עצרת את העורך…", text untouched; shared batch stops for all its lessons.
   Tests: `editor_checks` in `make_short_selftest.py` (each condition, fast-fail with a fake `urlopen`, gate + auto-burn, manual
   bypass, stop kills a real `sleep`, edit-during-sending merge, page markers).
4m3. **4.1.2 (19/11/2026) — tests must never touch his real config.** Evidence: `rabbis/הרב_בדיקה*.json` created in the real
   folder and `make_short_settings.json` rewritten during selftest runs. Root cause: `test_env` set `MAKE_SHORT_SETTINGS` but not
   `SHORTS_CONFIG_DIR` / `MAKE_SHORT_RABBIS` (module paths are computed at import time), and `his_state()` only hashed settings +
   guidelines + logos. Fix: `test_env` now isolates config (copy of brand/guidelines only, never secrets), rabbis, gemini usage;
   `main()` sets os.environ before importing any app module; `make_short_guard.py` (`assert_not_real_config`, real dir by `pwd`,
   not `$HOME`; active when `MAKE_SHORT_NO_EXPORT=1` or `MAKE_SHORT_TEST_GUARD=1`) is called by settings `_write`, rabbis, glossary,
   `music_library.save_json`, share profiles; `his_state()` hashes the whole real config dir (secrets: size+mtime only). Manifest:
   `make_short_manifest.py write` regenerates `pipeline/tests/feature_manifest.json`; only add to `removed_on_request` with the
   owner's date + quote. Settings safety: `SET.snapshot_history()` (daily copy, 14 days, plus `pre-reset`), `reset()` keeps the
   earliest undo values over repeated resets. Not done: `HOME=<tmp>` for the selftest (it would hide the real music library the
   tests read); live-app rewrites during a run can still trip the config-dir check — close the app for a full run.
4m4. **4.1.3 (19/11/2026) — save/restyle race, alert loops, self-update only from a committed+tagged tree.** (1) `restyle()` in
   make_short.py re-resolves `final_video(name)` + reloads meta right before writing (save may rename `clip1`→`clip1_<title>`
   mid-build); `busy_clips()` compares resolved paths and also counts waiting `BUILD_Q` items, so `save_start` refuses.
   (2) Page: `window.alert` → dismissible banner (`banner()`), same text suppressed 60 s (`SEENMSG`); network failure in `api()` →
   one sticky "התוכנה התעדכנה או נסגרה" banner + auto-reconnect (`srvDown`). (3) `code_tree_ready()` (git clean + HEAD exactly
   tagged; no `.git` = receiver install = old behaviour; `MAKE_SHORT_UPDATE_GATE=off` for tests) gates `code_check_now` and the
   restart; `CODE["held"]` is re-checked every 15 s by `code_watch`; page posts `/api/focus` every 8 s while visible+focused and
   `FOCUS["at"]` defers the restart 30 s. Workflow note: **edit in a clone, then commit+tag+pull into the live repo** so the owner's
   running app never sees half-edited files. Tests: `v413_checks` + the race test in the matrix section of the selftest.
4m5. **4.2.0 (19/11/2026) — per-lesson queue lane + preview priority.** `save` is now a queue kind (`enqueue("save", …)`,
   in `LIGHT_KINDS`, so it never waits behind other lessons' heavy builds). `lane_blocker(q)` (BUILD_Q order = arrival order):
   a save waits for any earlier/running item of the same project with overlapping clip (clip "" = whole lesson); any other item
   waits for a running/earlier save. `enqueue` puts a new save before *waiting* same-lesson items (priority) but never before a
   running one. `queue_view` adds `after` ("ממתין בתור (אחרי: …)"); waiting items are cancelled with the existing ✕
   (`queue_edit remove`). `save_start` no longer refuses/skips busy clips. Previews (`start_preview.work`) call `pause_heavy()`:
   SIGSTOP of every running heavy job's pid + descendants (`/proc` walk), `resume_heavy()` in `finally`, refcounted for
   overlapping previews, `PAUSE_MAX_SEC=180` watchdog (`pause_watch`), crash recovery `pause_recover()` from `paused_pids.json`
   at server start; job gets `paused` → page shows "⏸ עצרה לרגע בשביל התצוגה". RAM caveat: SIGSTOP keeps memory, so a preview
   waits ≤40 s for MemAvailable ≥ 800 MB. Never run two heavy renders truly in parallel. Tests: `v420_checks` (real ffmpeg is
   frozen, resumed and decoded cleanly; kill-between-STOP-and-CONT recovery).
   **VERSION POLICY (owner, 19/11/2026): the number reflects the SIZE of the change.** Weight points per item: 1 tiny (text/visual),
   2 real fix, 3–5 important fix (data safety/race/security) or multi-area. PATCH += sum of points since the last tag. A new
   owner-visible capability (button/setting/screen/queue behaviour) → MINOR +1, patch → 0. MAJOR only for a change of the tool's
   face/architecture. Every CHANGELOG entry carries a "משקל" table so the jump is explainable. Never rewrite/move published tags.
4n. **Card 22 (28/10/2026) — the rabbi leaves OUR crop: detection + fix offer + adaptive "זריזה" camera.** In
   הרב יוחאי פרלמן "מהות התפילה" the rabbi moved so much that for seconds he was entirely outside the 9:16 crop (still
   inside YouTube's frame). `check_framing` could not see it: it runs on the BUILT clip, where a face that left is just
   "no face" → the sample is dropped. He wanted a systemic fix, not just that clip.
   - `camera_path.py` measures on the **raw** (full frame) against the camera path computed by the SAME code as the
     build (`per_piece_camera` moved here unchanged from multi_piece_clip; `apply_env`/`cam_env` = one source for
     CAM_SMOOTH/CAM_ZIPPY). Sim vs the built clip: median |diff| 1–2% of output width. "Out" = face centre past the
     crop edge; **warning = runs ≥1 s with >¼ of the face outside** (box ≈ 0.85×height), times mapped raw→clip with
     the 0.18 s crossfades (`_raw_to_edited`). Face detections cached `work/clips/<clip>_raw_faces.json` (keyed by raw
     size+mtime); result `work/clips/<clip>_exits.json` = {key, camera, cur, zippy (only if cur warns)} — a separate
     file so the page can compute it in the background without racing jobs that write make_short.json.
     CLI: `camera_path.py compare <clip>` (table for all cameras) / `status <clip> <camera>` / `exits`.
   - `face_track.ZIPPY` (`CAM_ZIPPY=1`): identical to the normal camera while the face is comfortably inside (test:
     calm + short lean → byte-identical arrays). It looks 1.5 s ahead; if the face will be >0.085 (27% of output width)
     from the camera it starts at once (no 1.3 s trigger) toward the extreme ahead, cap 0.10/s (~340 px/s vs 130), K 0.8;
     back inside the dead zone → normal ease and stop. Measured on Perlman (warn s / peak px/s / % still):
     clip1 normal 6.0/130/49, smooth 6.5/130/51, **zippy 0/341/59**; clip2 normal 18.5/130/43, smooth 16.0/130/60,
     **zippy 0/341/42**. 0.16/K1.2 also reached 0 but peaked at 546 — the calmer value won. Zoom-out fallback NOT
     built (zippy reached 0 s on both clips) — build it only if a lesson shows zippy still missing him.
   - Tool: `check_framing(video, camera)` also returns `exits`; prepare logs it; setting `exit_fix` offer (default) /
     auto (prepare rebuilds a warning clip in zippy only if zippy measures better; `camera_auto` in progress data for
     resume); `camera_default` default/smooth/zippy for new clips (default keeps the old build path and bkey).
     `CAMERAS` has zippy (quick settings 3-way, restyle `--camera=zippy`, `rebuild <p> <clip> [smooth|zippy]`,
     `/api/rebuild {camera}`). `preview … camera zippy --at=SEC` = 10 s from 2 s before the exit, hstacked with the
     current clean clip ("לפני | אחרי", 1080x960, `MPC_PREVIEW_AT` → `build_clean(preview_at=)`). App `clip_exits()`
     overlays `c.exits` on /api/project from the cache, computes missing ones in a background thread (`EXITS_BUSY`,
     failures remembered per run). Page: `xBox` in result + edit cards (warning, clickable times seek the card player,
     "בנה שוב במצלמה זריזה" → before/after → "✓ החל" = restyle via `applyQs` for burned clips, `/api/rebuild` before
     burn); when exits warn the old "smooth" suggestion is hidden (smooth measured worse here).
   - Verified: default build frame-md5 identical old vs new code (both Perlman clips); `pipeline/tests/test_camera_exits.py`.
   - **Same card, his anger: "Leave site? Changes may not be saved" on closing the window.** The `beforeunload` prompt
     (born 20/10 in 1d050a7 for unsaved text; since the 21/10 explicit-save flow it fired for every lesson with a draft
     not yet saved to the folder — nearly always, though drafts are on disk) is GONE. Rule: **never ask on close**.
     `flushAll()` on pagehide / beforeunload / visibilitychange-hidden: edit text → `sendBeacon("/api/save")` (survives
     the page dying; the 1.5 s debounced autosave stays), a settings number/text still being typed → beacon
     `/api/settings`, and `resumeSave()` (also every 5 s) → `ys_resume` now kept 7 days (was 10 min, update-only) with
     the screen/tab, new-lesson form, paste boxes (`KEEP_IDS` chatWhat/updText/edPaste + pasteBox), pending quick
     settings (`qs`), retime slider (`RTD`). `RESTORED` guard: nothing writes ys_resume before it was read. Tested:
     navigate away 0.1 s after typing → text on disk; reopen → same lesson/clip/text; pending colour + "החל" bar back.
     Note: the Browser pane's tab-close kills the page without pagehide (only the debounced save ran) — a real Edge
     window close fires pagehide.

Heavy builds are serialized by a `flock` on `~/.local/share/yeshiva-shorts/heavy_build.lock`
(`heavy()` in make_short.py) — also holds when run from a terminal.

Work folders of the tool: `~/.local/share/yeshiva-shorts/projects/תוכנה/<date>_<slug>/`
(Claude-made lesson projects live one level up, in `projects/`).
Pick results: `…/projects/תוכנה/<date>_auto-<videoid>/pick.json` and `<date>_playlist-<listid>/pick.json`.

### Test mode
`MAKE_SHORT_NO_EXPORT=1` (no export / Drive / "music used" bookkeeping) plus
`MAKE_SHORT_SETTINGS=/tmp/x.json` (separate settings file) and another port (8766) let you test
without touching the owner's real state. `.claude/launch.json` in his project folder has an example.
`MAKE_SHORT_TEST_EXPORT=/tmp/dir` = "save" writes there (never his Shorts folder; no Drive);
`MAKE_SHORT_OFFLINE=1` = pretend there is no internet (banner, prepare/pick refused, Drive queued).
Card 13: in test mode the Drive files are `drive_pending_test.json` / `drive_status_test.json`, and the backup runs only
with `MAKE_SHORT_TEST_DRIVE_DST=<local dir>` (same drive_backup.sh, `DRIVE_SRC`/`DRIVE_DST` = test export → that dir;
`_test` log/lock). `MAKE_SHORT_OFFLINE_FILE=<path>` = offline while that file exists (drop + reconnect without a restart).
`SHORTS_MUSIC_FEEDBACK=<file>` = likes/heard/disabled go to a copy, never his real feedback.
🚨 A Browser-pane tab left open on the test port keeps the server "alive" (idle exit never fires) — close the tab first.

4o. **30/10/2026 — two more subtitle styles: "מרקר" (marker box) and "ריחוף מילים" (word float).** Teal karaoke stays the
   default; nothing existing changed (default build byte-identical). Prototype = `חומרים\סגנונות כתוביות\אב-טיפוס\gen_v3.py` (the
   approved look; do not redesign).
   - Code: `karaoke_styles.py` (palettes, fonts, builders); `karaoke_ass.SUB_STYLES` has `marker`/`float` (`"module": True` →
     `build()` delegates; CLI `--mode=marker|float --rgb= --opacity=`); the `.ass` carries `; ys-style:`, `; ys-rgb:`, `; ys-opacity:`.
   - **The per-clip choice is ONE string** (same field as RRGGBB / PLAIN): `MARKER:RRGGBB`, `FLOAT`, `FLOAT:RRGGBB`
     (`make_short_settings.parse_choice/valid_choice/choice_name`). Everything that validated "RRGGBB or PLAIN" now asks
     `SET.valid_choice`. Settings: `sub_color` may be those values (default style); `marker_opacity` 0–100 (default 94 = the
     approved example), `marker_off` (palette colours hidden from the picker). They are NOT in `STYLE_TOKENS`, so 🎲 random never picks them.
   - Marker: fonts `assets/fonts/YSMarkerBold.ttf` (Open Sans Hebrew Bold) / `YSFloatHeebo.ttf` (Heebo ExtraBold) — own family
     names, copied from the owner's font folder so the pipeline never depends on it. Box = `\p1` drawing with `\an7` at the
     top-left corner (with `\an5` + negative coords it drifts), `\clip` run+fold 0.09 s, centred on the *body* of the letters with
     `mid = base_y − body/2 + 0.075·size` (measured on real frames). Yellow FFD300 / mint 7CF5C4 → text 111111 as an extra
     clipped layer (`Dark` style, layer 2). 🚨 The palette is NOT `HIGHLIGHT_RGB` (explicit instruction).
   - Float: each word its own event (`\an2 \move … \fad(260,110)`), position from the measured full line; emphasis colour = `\1c` in
     that single-word event; marked words (🔠) get COLOUR in float+colour, nothing in marker / float-without-colour — never enlarged.
     `emph_for_burn(..., choice)`: picking `FLOAT:RRGGBB` switches 🔠 on once (`c["emph_forced"]`), he can switch it off.
   - **Editable colours (his addition, same day):** any hex works in `MARKER:`/`FLOAT:` choices; settings `marker_palette`,
     `float_palette` (lists he can add to / change / remove in the settings card), `marker_off` (hide), `marker_text`
     (`{hex: dark|light}` override). Text on the box = `karaoke_styles.dark_text` (WCAG contrast) unless overridden; written to
     the .ass as `; ys-text:`. Opacity applies to every colour. Claude: `--rgb=<any hex> --text= --opacity=`.
   - **After his first look (30/10): the page's CSS drawing of these styles was a poor approximation** (words just popped,
     font looked distorted) — he judged the style by it. Now `make_short.py preview <P> <clip> subs <choice> [--emph=on|off]`
     burns the REAL .ass with libass on the clean clip (first 20 s, 540x960, no audio, ~6–10 s; `/api/preview kind=subs`),
     and the page shows that video (no CSS drawing) for marker/float; unchanged clips just show the burned file. The CSS
     `subsHTML` branch for marker/float is now unused (kept for the settings demo only). Burned output was always right.
   - **Random = style first, then colour** (his suggestion): `SET.random_groups/random_pick` — karaoke(colours+"ללא צבע") /
     marker(palette minus marker_off) / float, equal weight per style; `random_off` accepts `MARKER:RRGGBB`/`FLOAT[:RRGGBB]`;
     float is dropped from the draw for a clip faster than 2 words/s. Page 🎲 does the same (`rndPickOf`). `finish_key`
     now uses `c["sub_rgb"]` to include marker opacity/text when random picked a marker.
   - Warning, not a block: `karaoke_styles.speech_rate` (words/s), `MS.clip_rate`, `c["wps"]` in /api/project, `float_max_wps`=2.
   - Page: `parseSty/markKind/swStyle/qsColors` + `subsHTML` draw an approximation (box = background of the current word; float =
     words appear at their time); fonts via `/font/ysmarker`, `/font/ysfloat`. Settings card "🖍️ מרקר · 🪶 ריחוף מילים".
   - Tests: `make_short_selftest.py` `style_checks` (matrix). Centring check: `חומרים\...\אב-טיפוס\centermeasure.py` (use only stable frames).
   - A new style = SUB_STYLES entry + choice prefix in `parse_choice` + JS `parseSty`.
   - **Superseded by 4p (31/10):** `marker_off` / `random_off` above were merged into one `colors_off` ("disabled").
4p. **Card 23 (31/10/2026) — colours active/disabled per style, clean-up in the background, "✓ הועלה" from past lessons.**
   - **Colours: two states only.** Setting `colors_off` = list of full choices (`RRGGBB` karaoke, `PLAIN`, `MARKER:RRGGBB`, `FLOAT`,
     `FLOAT:RRGGBB`). Active = offered for manual choice (clip ⚡ picker, default row in settings) AND in 🎲; disabled = hidden from both,
     kept saved, one click restores (↺ = all back). Replaces `random_off` (only random) and `marker_off` (only picker): `SET.migrate_off`
     moves both into `colors_off` inside `_read` (also inside a pending undo), so what he disabled stays disabled. A clip already burned
     in a colour that gets disabled keeps it (nothing re-burns); the settings default keeps a disabled current choice, labelled "(מושבת)".
     Disabling everything is allowed — 🎲 falls back to teal, as before.
   - **Three separate lists** (`SET.style_lists`, sent to the page as `style_lists`): 🎤 karaoke (4 defaults + colours he added for
     karaoke + "ללא צבע"; "הוסף צבע קריוקי") · 🖍️ marker (box colours, `marker_palette`) · 🪶 float ("בלי הדגשה" + `float_palette`) —
     float got its own active/disabled too. Karaoke colours he added are now also in 🎲 on the server (before: only the page's 🎲).
   - **Clean-up in the background:** the 🧹 dialog keeps all its safety (summary, required tick, bin cap, blockers) but after "נקה" the
     buttons become "⤵ המשך ברקע" — the dialog closes, the job continues. `queue_view()["cleans"]` (`clean_jobs_view`: running / ok for 1 h /
     failed until ✕ `/api/clean/dismiss`) → items at the top of the side "📋 תור העבודה" panel, and "🧹 מנקה…" / "❌ ניקוי" on the 📋 pill.
     `cleanTick` (every poll) sends ONE notification per job at the end (ok or failed; `ys_cleans` in localStorage so a reload does not
     repeat it) and moves off a tab whose lesson vanished.
   - **"✓ הועלה" without opening the lesson:** `/api/past` rows carry `clips` (saved / uploaded); "🟣 N/M ▾" opens per-short ✓/בטל and
     "✓ סמן שכל השיעור הועלה" / "בטל את הסימון של כל השיעור". `/api/uploaded` accepts `only_saved` (marks what was saved, returns
     `skipped` = unsaved, shown to him) and `items` (several at once); refused while that lesson is cleaning; unknown clip refused.
     The clean dialog gets `mark_items` (saved, not-uploaded shorts) → "✓ הוא/הם הועלו — סמן ונקה" (all markable → marks then cleans)
     or "✓ N השמורים הועלו — סמן" (some unsaved → marks and re-plans; the tick is still needed for the rest).
   - Tests: `pipeline/tests/test_card23.py` (real server, fake bin); selftest colour matrix uses `colors_off` + an old-format case;
     the one-colour check now disables marker/float (since 30/10 🎲 could pick a marker by the temp path → flaky).
   - Gotcha seen while testing: editing code on disk makes a running server self-update (page reloads) — a click in flight is lost.
4q. **Card 25 (1/11/2026) — "🎯 מה לחפש" (free-text request) + per-rabbi profile.** (The brief said "card 24"; 24 was the styles session's.)
   His scope correction: ONLY what was already agreed — no new analysis of any rabbi; Perlman has NO profile (one lesson where he stood).
   - **Request** (`make_short_pick.request_text`): box under the link ("🎯 מה לחפש?", optional) → `st["request"]` in pick.json (single lesson
     and playlist; one request applies to every lesson — per-lesson requests only exist for `together`, where each lesson dict carries its own).
     Block added to the pick prompt (Gemini and copy-to-chat get the SAME text via `chunk_prompt`/`build_prompt(request=)`); empty =
     byte-identical prompt (test). Rules inside: requested part first with `"for_request": true` (shown "📝 לפי הבקשה שלכם"), a number in the
     request ("עוד שני קטעים") overrides the usual ceiling, otherwise the usual max-2/3; **if it is not in the transcript the model must
     return `{"not_found": true, "lesson", "note"}`** → `parse_answer(text, notes)` → `st["request_notes"]` → yellow "🔎 לא מצאתי: …" (a
     not_found-only answer is not an error and counts as "answered"). Quote verification / skips / fidelity gate unchanged.
     Pick screen card "🎯 מה לחפש" (not in big-playlist stage A — ranking ignores it; stage B proposals get it): edit + "🔍 חפש שוב" →
     `/api/pick/request` → `PICK.set_request` (changed or `again`: picks he did not edit/drop go out — auto-preselect does NOT count as
     touched —, notes/more/stop cleared, chunks pending) → Gemini job only if per-step setting `gm_pick`="key" and a working key, else
     "העתק לצ'אט" with the new text.
   - **Profiles** (`make_short_rabbis.py`): defaults in code `SEEDS` (shipped in the share zip, no secrets) + `~/.config/yeshiva-shorts/
     rabbis/<rabbi>.json` written only when he edits/learns (`MAKE_SHORT_RABBIS` in tests; one `.prev.json` step for "↶ בטל"; reset = delete
     file; `backup_extras.sh` backs up `rabbis/` and, found missing, `glossary.json`). Match = `SL.name_key(rabbi=True)` after dropping
     single-letter initials, so "הרב ש. יוסף וייצן" = וייצן and **הרב יהודה מלמד ≠ הרב זלמן ברוך מלמד**. Fields: `sub_gap`, `dedupe_repeats`,
     `camera{trigger_sec,max_pan}`, `words`, learning counters. Seeds: sub_gap 1.5 for בן שושן, גנץ, אוריאל, וייצן, יעקובי, יהודה מלמד, כץ;
     בן שושן camera 0.8/0.055; כץ dedupe on.
   - Where each part reads it: **subtitle gap** `make_short.use_rabbi()` → `RB.apply_gap` sets `build_ass.GAP_THRESHOLD` at the start of
     prepare/finish/restyle/rebuild/retime/preview and `_lines` (preview/sub_lines; `cam=False` there so the server never exports
     `CAM_RABBI`); `finish_key` includes the gap only for rabbis that have one (others keep their old key). **Camera**: env `CAM_RABBI`
     → `camera_path.apply_env` sets `face_track.TRIGGER_SEC/MAX_PAN_RATE` (`_reset` restores), so build, preview and the exits
     measurement compute the same path; the saved `_exits.json` carries `prof` and is re-measured when the profile changes.
     **Interaction with card 22 "זריזה"**: זריזה = the profile's normal camera until the face nears the edge, then its own emergency constants
     (`Z_PAN_RATE` 0.10 etc.) take over — so בן שושן's zippy build still starts with 0.8/0.055 and still uses 0.10 in an emergency
     (never made slower by the profile). **Words**: `ED.glossary_prompt(rabbis=)` (editor + alts, own block), `ED.asr_hint(rabbi=)` (ear 1;
     profile words first), `build_prompt` (pick). **Learning**: `ED.on_saved` → `RB.note_corrections(rabbi, pairs, where=lesson/clip)`; the
     same pair at 2 DIFFERENT places for one rabbi → page offer "להוסיף לפרופיל של הרב X?" (lesson screen + settings card), his click only;
     "לא" is remembered. Settings → 🖥️ glossary area → "📇 פרופיל לכל רב" (edit fields, words box, save / reset / ↶ undo, add rabbi).
   - **Repeats** (`make_short_repeats.py`, only `dedupe_on` rabbis — כץ): in prepare's snap step, from the turbo transcript of each piece's window
     (no extra ASR), an immediate identical word is removed **from the audio too**: the piece is split in two at the centre of a measured quiet
     run (≥0.36 s = 2×0.18 crossfade) on both sides of one of the two words; no such silence → the word STAYS and is listed ("⚠️ נשארה
     חזרה"). Never touched: words in `KEEP_REPEATS` (מאוד/ממש/לא/כן/נכון/מה…), a first word ending `? ! . : ;`, pairs within 0.6 s of the
     piece edge, a cut leaving a piece <3 s (opening piece <6 s). Records in `progress.json["dedupe"]` → `clip["repeats"]` → card lines
     "✂️ הוסרה חזרה … ↩ בטל" (`make_short.py undo_repeat` = rejoin the hole + `retime`, queued as a retime job). Real data: in one real כץ lesson (31 min, אור החיים
     חיי שרה) there were only 5 identical adjacent words and **none** had a clean 0.36 s silence on both sides (Whisper gaps 0.0–0.77 s) →
     all kept+flagged. So expect it to fire rarely; a second tier (splice between two identical words on voiced audio) was NOT built —
     it needs his ears. Tests: `pipeline/tests/test_rabbis.py`.

## 3. Where everything lives (and what is NOT in git)

| What | Where | In git? | Backed up |
|---|---|---|---|
| Code | `~/yeshiva-shorts-skill` | yes | GitHub |
| **Secrets**: `GEMINI_API_KEY`, `MODAL_CONFIG_PATH`, `SHORTS_MODEL`, `SHORTS_ASR`… | `~/.config/yeshiva-shorts/config.env` (mode 600) | **never** | 4.6: only `GEMINI_API_KEY`, inside the password-encrypted vault (§8r) — once he creates one |
| YouTube cookies | `~/.config/yeshiva-shorts/youtube_cookies.txt` (600) | **never** | never (go stale) |
| Modal token | Windows file `C:\Users\<user>\.modal.toml` (config.env has `MODAL_CONFIG_PATH=/mnt/c/Users/<user>/.modal.toml`) | never | 4.6: in the vault; restored to WSL `~/.modal.toml` and `MODAL_CONFIG_PATH` re-wired |
| rclone / Drive login | `~/.config/rclone/rclone.conf` (600), remote name `gdrive:` | never | 4.6: only the own `client_id`/`client_secret` in the vault — **never the token** (one browser login on a new PC) |
| Vault + restore folder (4.6) | `~/.config/yeshiva-shorts/vault.enc` (600) + `~/.local/share/yeshiva-shorts/restore_kit/` | never (`*.enc` in .gitignore, blocked in packages) | Drive "גיבוי תוכנה/שחזור למחשב חדש" (daily, mirror) |
| Tool settings (incl. 📝 org/footer/subscribe/fixed tags, 3.4) | `~/.config/yeshiva-shorts/make_short_settings.json` | no | Drive "גיבוי תוכנה" (daily) |
| Claude memory (rules learned with him) | Windows `C:\Users\<user>\.claude\projects\*\memory\*.md`, `.claude\CLAUDE.md`, `yeshiva-shorts\CLAUDE.md` | no | Drive "גיבוי תוכנה/claude" (daily, whitelist; §8j) |
| Logo | `~/.config/yeshiva-shorts/brand/logo.png` (`SHORTS_LOGO`) | no | Drive |
| Gemini guidelines (personal) | `~/.config/yeshiva-shorts/guidelines.txt` — **always pass this, never `assets/guidelines/shorts_default.txt`** (the default carries another client's social links) | no | Drive |
| Setup wizard state | `~/.config/yeshiva-shorts/state.json` | no | – |
| Music library | `~/.local/share/yeshiva-shorts/music/` : `tracks/*.mp3` + `*.mp3.license.json`, `index.json`, `_rejected/*.license.json`, `_refs/mix.py` (original mixer), `~/.config/yeshiva-shorts/music-feedback.json` | no | Drive |
| Venv, ffmpeg, deno | `~/.local/share/yeshiva-shorts/{venv,bin,deno}` | no | rebuilt by install.sh |
| Work folders | `~/.local/share/yeshiva-shorts/projects/` | no | – |
| Logs / ledger | `~/.local/share/yeshiva-shorts/logs/` (`exports.jsonl` = what was produced, `make_short_app.log`, `drive_backup.log`) | no | – |
| Gemini daily counter | `~/.local/share/yeshiva-shorts/gemini_usage.json` | no | – |
| **Finished clips** | `~/Videos/Shorts/<רב>/<סדרה>/<…>/` (Windows: `\\wsl$\Ubuntu\home\<user>\Videos\Shorts`) | no | Google Drive folder `שורטסים מוכנים` (mirror) |
| Windows launcher | `C:\Users\<user>\yeshiva-shorts\יצירת שורטס.bat` (opens `http://localhost:8790`) | copy in `windows/` | – |

**Rule: every file for this work stays under `C:\Users\<user>\yeshiva-shorts\` on Windows** (his
inputs in `חומרים\`, shortcut `שורטסים מוכנים.lnk` to the finished clips). Nothing in Downloads/Desktop.

**Never print or paste secrets** (config.env, cookies, rclone.conf, tokens). The health module has
`scrub()`; the "copy details for the assistant" button uses it. If you need to know whether a key
exists, test for the variable's presence, never echo it.

## 4. Running things

Always through the gate; commands as **script files**, not inline quoting:

```
wsl -d Ubuntu -- bash /mnt/c/.../script.sh        # from Windows PowerShell
~/yeshiva-shorts-skill/shorts.sh py make_short_app.py     # the tool's server
~/yeshiva-shorts-skill/shorts.sh doctor                   # environment check
~/yeshiva-shorts-skill/shorts.sh yt-dlp ...|ffmpeg ...|env|where
```
- Inline `wsl -- bash -lc '... $VAR ...'` from PowerShell **loses variables** (nested quoting).
  Write a `.sh` with the Write tool (not `Set-Content -Encoding utf8`: a BOM breaks bash's first line).
- `;` and `>` passed through `cmd.exe /c start ... bash -lc` hang; use a script file.
- `nohup … &` inside a `wsl -- bash script` dies when the wsl call returns; run the whole wsl call in the background instead.
- Never `export SHORTS_LIB=…/pipeline`. `SHORTS_LIB` must be `~/yeshiva-shorts-skill/assets` (shorts.sh sets it). Wrong value ⇒ face model unreadable ⇒ the build runs **without face tracking** silently.
- The launcher `.bat` must stay **ASCII-only** (cmd + `chcp 65001` misreads UTF-8 lines).

## 5. Technical rules (hard-won)

- **Camera**: stabilization is OFF (`SHORTS_STABILIZE=0`): lessons are shot on tripods and vidstab
  mistook gestures for shake. The virtual camera must **never be locked/frozen** — the owner wants
  a calm camera that visibly homes in on the rabbi's face. Approved tracker settings:
  DEAD_OUT 0.045, TRIGGER_SEC 1.3, MAX_PAN_RATE 0.038, EASE_K 0.45. If he says "moves too fast",
  check stabilization and measure the background before touching the tracker. Speakers who sway
  (e.g. הרב חיים בן שושן, sometimes הרב חיים כץ) pass `check_framing` only with 0.8/0.055
  (even 0.5/0.08); set per clip, not as a new default. Multi-piece clips: per-piece camera restart,
  pieces <6 s are grouped (`CAM_MIN_PIECE`) to avoid jumps; `CAM_SMOOTH=7` for swayers (not default).
- **Cut on measured silence, never on Whisper word boundaries.** Find the real low-RMS valley
  (10 ms hops). Traps: a short (<0.2 s) low run inside a word is a stop-consonant closure (ת, ט, ק…)
  or a ש fricative — the clip then opens/ends on a word fragment. Leave ≥0.3 s of quiet before each
  piece's onset (the join is a 0.18 s acrossfade that eats edges). A word appearing twice at a join
  ⇒ re-check that cut. Do not end a clip where the sentence continues.
- **Two ears, always.** Never ship subtitles from a single transcription. Ears: Modal
  `large-v3` + Modal `ivrit-ai/whisper-large-v3-turbo-ct2` (explicit `--model`), plus YouTube's
  Hebrew auto-captions as the truly independent third ear (Whisper models share biases).
  When only YouTube hears extra words and RMS shows speech there, trust YouTube. A word that
  **all** engines agree on but is not a word ⇒ it is a doubt (Aramaic/yeshivish idiom): ask the owner.
  `ivrit-ai/yi-whisper-*` is **Yiddish** — never use. `asr.py` with `SHORTS_ASR=local` runs large-v3
  on CPU (hung 17 min on 39 s) and **silently falls back to turbo** on load failure ⇒ "two ears" can be
  identical; the tool therefore calls Modal first and checks the `model` field.
- **Subtitles**: `karaoke_ass.py --style=teal` default (whole line visible, spoken word coloured;
  one random colour per video from the pool teal/yellow/purple/green). Lines end at punctuation or
  a >0.3 s pause (`SHORTS_SUB_GAP=1.5` for slow speakers who pause mid-sentence), up to ~7 words,
  two rows when needed. Bottom-anchored. **Enlarge-word emphasis is CANCELLED** (default off). Subtitle
  the rabbi's *actual* words — no paraphrase, no "correcting" to the source text; tidy only stumbles
  and tics ("כן?"); fix an obvious tense slip to its meaning; **sages get their full honorific**
  (רבן שמעון בן גמליאל). Set phrases beat a Whisper majority (רבותינו ז"ל). When he says a spelling
  (e.g. "אשה" without yud in a letters-derasha) it applies everywhere in that clip.
- **Logo** burned at the top with an even soft white halo (`LOGO_GLOW_GAIN` 0.8).
- **Loudness**: pipeline itself never normalized voice (clips varied -11…-38 LUFS). Fixed: loudnorm
  **I=-14, TP=-1.5, LRA=11** after burn, *before* music. Quiet speakers (הרב אליהו ברין): two-pass
  linear loudnorm (LRA 20) and a final `volume=+Δ,alimiter` to land on -14; limit only if peak > -0.5 dBFS.
- **Music: always, one track per clip** from the library, via `mix_music.py` (copy of `_refs/mix.py`):
  VAD → gain envelope; music under speech -13 dB, in short pauses -9, long pauses (≥1.5 s) swell to -3;
  attack 150 ms / release 700 ms, fades 1.2/1.8 s. Per-track fix: `mix_gain_db` in the track's
  `.license.json` (Isolated = +9). Judge a mix in the >200 Hz band, not full-band. **Credit line**
  `מוזיקה: …` (from `credit_line` in the track's license json — CC BY requires naming it) is appended to the description.
  Export folder holds **only the music version**; keep the no-music base in `work/plain/` or
  `work/clipN_nomusic.mp4` for swaps.
  - Library brief: major, alive, hopeful, instrumental, slow (60–90 BPM), no drum beats, nothing
    childish/comic/church/Christmas/Wagner, nothing whose **name** reads badly in a credit line
    under a Torah lesson. 30 tracks (Kevin MacLeod + Scott Buckley, all CC BY 4.0; his own picks:
    Cheery Monday, Heartwarming, Isolated, Two Together, Water Droplets on the River).
    He wants ≥60 eventually. Leads not yet tried: Chosic, Audionautix, Alexander Nakarada, Keys of Moon
    (verify license is CC BY/CC0, no NC/SA). Dead ends: Openverse (anonymous limits), FreePD (closed).
  - **Rejected, never bring back**: Beyond These Walls, A Dragon's Lullaby, The Long Dark, At The End Of
    All Things, Incredulity, Undertow (dark/cinematic Buckley — "אין לי עניין במנגינות אימה"), the old
    54 names from the first library (Easy Lemon, Look Busy, Senbazuru, Reunited, Guzheng City, Thinking of
    You, Off to Osaka, The Forest and the Trees, Ranz des Vaches, …) and all Christian/church/Wagner/Christmas tracks.
    Their `.license.json` stay in `music/_rejected/` and `index.json` flags them so `fetch` skips them.
    Do not trust `music_library.py suggest` for never-used dark Buckley tracks.
- **Length/count**: clips **<60 s** (hard); try 30–45 s; 10–20 s clips are welcome when a segment
  stands alone. **At most 2 shorts per lesson** (standing default 14/10); **one short (10–20 s) clip
  unlocks a 3rd**, never more than 3. In playlist scans each lesson keeps its single pick. No long
  "special" clips, even for a great story. Mention dropped candidates in the summary.
- **Titles/descriptions**: title = a short, striking phrase, often the rabbi's own words (he rewrote
  question-style titles). **Description stops at the curiosity and never resolves it** (he deletes the
  closing sentence every time). No "hook" in the copied texts. **Rabbi's name only from the YouTube video
  title** (Gemini invents names in tags: replace). Layout of `תיאור להעתקה.txt`: description → `לצפייה בשיעור המלא ◄ <link>`
  → subscribe line → series line (`מתוך סדרת השיעורים X | <org>`) + fixed footer lines → tags → music credit.
  **Since 3.4 (16/11) the subscribe line, org name, footer lines and fixed tags are settings** (📝 תיאור ותגיות:
  `subscribe_text`, `org_name`, `footer_lines`, `fixed_tags`; defaults empty/generic so a receiver of the share zip never
  publishes Beit El's links). His values live only in his `make_short_settings.json` (his exact wording "ערוץ השיעורים
  החדש", his org name, his two site links). Never put them back into code. File name: `<title>   <rabbi>` with **three spaces**
  where `|` would go; the `--title` passed to export must be `"<title> | <rabbi>"`.
- **Export layout**: `~/Videos/Shorts/<הרב>/<הסדרה>/<YYYY-MM-DD>_<slug>/` (no `"` in Windows folder names;
  clip folder names drop the rabbi, ≤40 chars — Windows 260-char path limit). Weekly-parsha:
  `<הרב>/פרשת השבוע/<parsha>/`. Scanned series: `א. בקשה ישירה …` vs `ב. מסריקת הפלייליסט/…` + `מה יש כאן.txt`.
  Final folder holds **only the video + `תיאור להעתקה.txt`** (no info.txt, meta.json, להעלאה.md, no-music copy,
  no .wav/.raw leftovers). Full-quality files only — never compressed previews.
- **Drive mirror**: after every export and every deletion run `drive_backup.sh` (in the tool this is the background
  worker, 4f — never put it back inside a save/finish job; a manual run while the worker runs exits 5). It is a mirror: a clip
  deleted locally is deleted in Drive (Drive trash keeps 30 days). Cap of 10 deletes per run; for a
  deliberate larger delete: `--dry-run`, check every planned delete belongs to what the owner named, then
  `--allow-delete <exact count>`. Exit 3 = cap abort (a trailing `| tail` hides it), exit 4 = size mismatch
  (usually someone reorganizing during the sync — rerun). Runs silently in the background; report only if it fails for >1 day.
- **Deletes**: **never inline** (`bash -c "…rm/find -delete"` once lost its path variable, ran in his
  Windows project folder and wiped his style-example videos, bypassing the Recycle Bin). Only script
  files with `set -euo pipefail`, an absolute path, a guard `[ -d "$P/expected-subdir" ] || exit 1`,
  `find "$P" …` (never bare), print before delete. Anything of his goes through the **Windows Recycle
  Bin** (copy to a short Windows temp path → verify counts/sizes → `Microsoft.VisualBasic.FileIO.FileSystem
  ::DeleteDirectory(…, SendToRecycleBin)` → confirm → only then remove the WSL original). A `\\wsl` path
  can't go to the bin directly. A lesson's work media (full video, cuts, no-music base) stays until he
  names that lesson. Keep series folders that will get new lessons.
- **Cost / quota**: Modal — $30/month credit with a $30 hard limit; spend ≤$1–2 per day, ask before more.
  Measured: a 30-min lesson on T4 ≈ $0.045 (turbo ≈ 131 s per 33 min); ~5–7¢ per lesson incl. clips; the
  picker's 10-min-parts large-v3 pass on a long lesson ≈ 60¢. A whole-lesson large-v3 call on a 42-min lesson hit Modal's 900 s function timeout ⇒ for long
  lessons transcribe in parts (the picker does 10-min parts in parallel). Gemini free tier: 20 requests/day
  **per model**, shared by every session, resets midnight Pacific (≈10:00 Israel). On a 429 do **not** loop:
  read `quotaId`; `…PerDay` ⇒ stop until reset. Never switch models silently.
- **RAM**: the PC has 7.7 GB; WSL gets ~3.7 GB. Run **one heavy job at a time**. Parallel renders + local
  whisper made WSL crash ("Catastrophic failure E_UNEXPECTED") and corrupt mp4s. Local whisper large-v3 OOMs
  (exit 137) — `SHORTS_MODEL=ivrit-ai/whisper-large-v3-turbo-ct2` is set in config.env. Don't raise the WSL cap.
  After a crash wait 1–3 min and retry; never `wsl --shutdown` while a job runs.
- **Live-stream replays**: the audio-only `-f 140` m4a starts its clock at 10.01 s; the wav loses it ⇒ every cut ~10 s early.
  Extract audio from `source/full_video.mp4` itself, or measure the offset first.
- **`asr.py` writes `<stem>.txt` into `--out-dir`** and can overwrite hand-written text; keep hand text as `clipN_final.txt`.
  `asr.py --media` is `nargs="+"` — all files after ONE `--media`.
- `while read … ffmpeg` loops need `ffmpeg -nostdin`.

## 6. Editorial rules (the owner's taste — these are why he is happy or annoyed)

- Hebrew for every message to him, including short status lines.
- Quality over quantity: exported ≠ published; a weak second clip should not be made.
- Look in Torah-content lessons for sharp chiddushim / punchlines / a parable; trim what every viewer
  already knows from the parsha. Avoid fumbling, "asking the room", repeats (cut them out, multi-piece).
- He knows the verses: if a clip opens mid-verse check the seconds before. He answers doubts quickly —
  flag open doubts instead of voting them away; his ear beats any engine.
- Gemini is **not** needed: segments can be chosen from YouTube captions / the Modal transcript.
- Gemini's description wording comes from the personal `guidelines.txt`; the fixed parts (links, org, subscribe line,
  fixed tags) come from the 📝 settings (3.4) — his Beit El values live only in his settings file.
- Faithfulness gate: no out-of-context clips.
- Enlarged words (×1.3): cancelled by him 15/10 as an automatic feature; back 22/10 ONLY as his per-clip opt-in in the
  tool, with model-proposed words he can edit (4h). Never turn it on for him; Claude's own shorts stay without it.
- Playlists/series: scan by captions only (2.6 s/lesson), rank by the series' **core idea**, not funniest
  stories; deliver as a table. List playlists with `--cookies` explicitly or scheduled videos are hidden.

## 7. Known failure modes and fixes

| Symptom | Cause | Fix |
|---|---|---|
| Download "succeeds" but only storyboards / "Only images are available" / 360p | yt-dlp outdated, or no JS runtime (Deno) for the `n` challenge, or scheduled/private video needs cookies | Page button "עדכן עכשיו" (= `pip install -U "yt-dlp[default]"`; `[default]` brings yt-dlp-ejs). Ensure `~/.local/share/yeshiva-shorts/deno/bin/deno` exists (install.sh). For 360p on scheduled videos: `--cookies … --extractor-args youtube:player_client=web_safari` lists 720p HLS (format 95). `shorts.sh yt-dlp` tries without cookies first and falls back to them. YouTube changes every few weeks — **update yt-dlp first** for any download problem. A "fragment 403 / Skipping fragment" warning is usually harmless. |
| Cookies stop working (login errors on scheduled/private videos) | the export went stale (Studio export, or logged out) | Re-export: Chrome **incognito** window → log in to youtube.com (NOT studio) → go to `https://www.youtube.com/robots.txt` → extension "Get cookies.txt LOCALLY" → Export → **close the window without logging out** → page button "העלה קובץ עוגיות". Public lessons work without cookies. Renew roughly every few weeks. |
| Gemini 403 "Your project has been denied access" on every call | account/project block (since 10/10/2026; Google enforced 2-step verification; AI Studio billing tier "Unavailable"). Not quota | Only the owner can fix: new key in a new project, or Google support. Meanwhile use "העתק לצ'אט" (free chatbot) or YouTube captions. Key goes in via advanced settings "שמור ובדוק" (stored in config.env, 600, backup config.env.bak) |
| Gemini 429 | quota (20/day/model) or per-minute | read `quotaId`: `PerDay` ⇒ wait for midnight Pacific; `PerMinute` ⇒ retryDelay. Never loop (it burned a day's quota in minutes) |
| Modal error `Please add a payment method to use T4 GPU functions` | no card / credit gone | card is on file since 22/9 ($30/mo, hard limit $30). If credit/token gone, transcription falls back to local CPU (slow; large-v3 OOM ⇒ turbo). Token lives in `C:\Users\…\.modal.toml`; new PC: `modal token new` |
| Modal run times out (900 s) | whole 40-min lesson in one call | transcribe in parts (picker already does); or window transcription around candidates |
| Modal transcript missing first seconds / swallowed verse into one long word | Modal quirks | rerun without `--prompt`; compare first/last words with local turbo; splice turbo timings where a word is >1.5 s long |
| Local transcription hangs/killed | large-v3 on CPU / OOM | use turbo; one job at a time |
| rclone / Drive "failed" or banner "shared client_id retiring" | rclone's shared Google client_id is being retired during 2026 | Create **own client_id** (https://rclone.org/drive/#making-your-own-client-id), `rclone config` edit `gdrive` (scope **drive.file**), `rclone config reconnect gdrive:`. Page button "חבר מחדש את הדרייב" opens the reconnect in a console window (browser authorisation). Drive free tier 15 GB — warn when it fills. 🚨 **Scope trap:** with `drive.file` an rclone remote only sees files created by the *same OAuth client*. A new own client_id therefore cannot see the existing `שורטסים מוכנים` / `גיבוי תוכנה` folders: before switching, either re-upload from the machine (`rclone sync` after the new login — it re-creates everything, ~2.5 GB+), or temporarily use scope `drive` (full) to move the folders. Back up extras first (`backup_extras.sh backup`) |
| Drive sync exit 3 / 4 | delete cap / mismatch during reorganization | see §5 "Drive mirror" |
| Clip has no face tracking, build "works" | wrong `SHORTS_LIB` | unset it; use shorts.sh |
| Framing gate fails (face at edge) | swaying speaker | per-clip `TRIGGER_SEC/MAX_PAN_RATE` 0.8/0.055 → 0.5/0.08; or page button "בנה שוב במצלמה חלקה" |
| Rabbi leaves the crop for seconds ("🎥 הרב יוצא מהמסגרת") | he moves faster than the calm camera | page button "בנה שוב במצלמה זריזה" (before/after first); `camera_path.py compare <clip>` for numbers (§2 4n) |
| Subtitle line of one word | speaker pauses mid-sentence | `SHORTS_SUB_GAP=1.5`; or put a comma only where he really pauses |
| WSL "Catastrophic failure" | OOM from parallel jobs | wait, retry; one heavy job at a time |
| Disk full (C: is small) | WSL `ext4.vhdx` never shrinks | delete only work-folder media of lessons he names; `wsl -u root -- fstrim -v /` → `wsl --shutdown` (only when no job runs) → diskpart compact (elevated, he must click Yes). Never touch `~/Videos/Shorts`, `~/.cache/huggingface`, `music/` |
| Page shows nothing / port busy | server not running or another copy | close the black window; rerun the launcher; log in `~/.local/share/yeshiva-shorts/logs/make_short_app.log` |
| Hebrew text reversed in a window | Tk/consoles don't do RTL | that is why the UI is a browser page |

## 8. Installing on another computer

See `windows/התקנה.bat` (+ `install_windows.ps1`) and the owner-facing Hebrew guide
`docs/מדריך-העברה-למחשב-אחר.md`. In short: WSL Ubuntu → clone repo → `install.sh` → restore music/settings/
logo/guidelines from Drive (`backup_extras.sh restore`) → launcher → `shorts.sh doctor`. Manual because personal:
GitHub access, Modal token, rclone Drive login, Gemini key, YouTube cookies.

Tested 20/10/2026 on the owner's PC (Ubuntu already present): steps 2–3 and 8 of the PowerShell installer,
a clean `install.sh` run into a sandbox data dir (venv, libs, static ffmpeg, Deno), `backup_extras.sh backup` and
`restore` (into a temp dir: 30 tracks + license jsons + index + logo + guidelines), `setup/newpc.py`. **Not tested on a
truly clean Windows** (the `wsl --install`, first-user creation, GitHub-token and interactive Drive/Modal login paths) —
if the installer misbehaves there, fix `windows/install_windows.ps1` and record it here.
Installer switches for testing: `-SkipDrive -SkipModal -SkipGit -SkipInstall -NoPause -ProjDir <dir>`.

`install.sh` installs: yt-dlp[default], numpy, opencv-python-headless, requests, faster-whisper (its VAD
`faster_whisper.vad.get_speech_timestamps` is used by the tool — required even if ASR is on Modal),
modal, tzdata (zoneinfo for the Pacific-day Gemini counter), google-api libs (optional, upload plan dropped);
static ffmpeg (BtbN build with libass/vidstab — Debian's apt ffmpeg 5.1 **fails on the filtergraph**); Deno.

### 8a. Share package — one zip, no GitHub (21/10/2026)

Settings → 🖥️ מערכת → **"📦 צור קובץ שיתוף"** (`make_short_share.py build [--drive] [--out DIR]`) writes
`C:\Users\<him>\yeshiva-shorts\שיתוף\יצירת שורטס <version> - YYYY-MM-DD.zip` (~200 MB; `SHORTS_SHARE_DIR` overrides). Inside:
`code/` (= `git archive HEAD` — uncommitted changes are NOT included, the dialog warns), `extras/music/` (tracks +
license jsons + index.json + `_refs/mix.py` + rejected licenses), `extras/config/brand/logo.png` (the Beit El logo —
the receiver can replace it in settings), `extras/config/guidelines.txt`, top-level `התקנה.bat`
(from `windows/package_setup.bat.txt`, ASCII; shows a Hebrew message box if run from inside the zip unextracted),
`קרא אותי.txt`, `package.json` (date, commit, flags — no secrets). **His tuned settings are not included**: the receiver
starts from `make_short_settings.DEFAULTS`.

**No accounts in the package.** config.env, the Gemini key, the Modal token (`MODAL_CONFIG_PATH` toml), YouTube cookies
and rclone are never read into it; after writing, every entry is decompressed and scanned for key/token/cookie patterns
and for his real values — any hit deletes the zip and fails the build. (21/10 he asked to *include* his Modal + Gemini
encrypted so it "works the same for everyone"; the assistant's safety system blocked bundling credentials for
distribution as data exfiltration, so this is pending his decision — see §10. Do not add it silently.)
The "Drive" checkbox only makes the receiver's installer *offer to connect the receiver's own Drive*; unticked =
`drive_on: false` written for the receiver (only if they have no settings file yet).

Installer **package mode** (`install_windows.ps1`, automatic when `..\..\package.json` + `..\..\extras` exist):
step 3 copies `code/` into `~/yeshiva-shorts-skill` as a local git repo with a `.from_package` marker (re-install over a
previous package: commit the old state, remove its tracked files, copy the new version — so deleted files go; a checkout
with a GitHub `origin` is never touched); no GitHub prompt; step 5 Drive only if offered and the receiver types כ;
step 6 copies extras with no-overwrite (receiver's music/logo/guidelines win); steps 4/7/8 as usual (Modal login and
Gemini key are the receiver's own, guided in Hebrew). **`-DryRun`** (package mode only): writes code + extras into
`/tmp/ys_dry_*`, verifies (git commit, executable scripts, every .py compiles, 30 tracks + licenses + index, logo,
guidelines, settings, no secret-looking files) and skips WSL install/apt/install.sh/Drive/Modal/shortcuts.
Tested 21/10 on his PC: build, negative scan (fake cookie line, fake AIza key, a config.env entry → all caught),
Windows `Expand-Archive` + `-DryRun` → passed. **Not tested on a clean Windows.**

**Recipient profiles (3.5, 16/11/2026).** Same section, "👤 בשביל מי החבילה?": a select (always reset to "בלי פרופיל"
when the settings page opens — the no-profile package is byte-for-byte the pre-3.5 recipe: his logo + his
`guidelines.txt`) plus a list of profiles (➕ new / ✏️ edit / 🗑️ delete). A profile = name, PNG logo, `footer_lines`,
`org_name`, optional `subscribe_text` (empty → not written → receiver keeps `GENERIC_SUBSCRIBE`), `auto_rebuild`
(default off). Stored in `~/.config/yeshiva-shorts/share_profiles/<p+10hex>/{profile.json,logo.png}`
(`SHORTS_SHARE_PROFILES` overrides, used by the selftest); backed up by `backup_extras.sh` (minus `_deleted/`).
Delete = move to `share_profiles/_deleted/<ts>_<id>/` then `win_recycle` to the Windows Recycle Bin (test mode: stays
in `_deleted`). API: `GET /api/share/profiles`, `GET /share_profile_logo?id=`, `POST /api/share/profile/{save,auto,delete}`,
`POST /api/share/build {profile}`. CLI: `make_short_share.py build --profile ID [--prune]`, `profiles`,
`apply-profile <profile.json> <settings.json>`.
- Profile package: `extras/config/brand/logo.png` = the profile's logo (none → none; **never** falls back to his),
  `extras/config/guidelines.txt` = `assets/guidelines/shorts_default.txt` (made neutral in 3.5 — the client's social
  links that were there are gone), `extras/config/profile.json` (name + the three keys), `package.json.profile =
  {id,name}`, zip name `יצירת שורטס <ver> - <profile> - <date>.zip`.
- After the usual secret scan, `identity_scan` fails the build (zip deleted) if any non-mp3 entry equals a hash of any
  PNG in his `brand/` / `logo_path` / `logo2_path` / `SHORTS_LOGO`, or contains one of `his_strings()` = his
  settings' footer lines, org name, non-generic subscribe sentence + a fixed base64-encoded list (so the code shipped
  in `code/` never contains them in clear).
- Installer step 6: after the `drive_on` stub, `python3 …/make_short_share.py apply-profile` writes only keys absent
  from the receiver's `make_short_settings.json` (4.0: plus `profile_from` = the profile's name, if absent); logo/guidelines keep `cp -n`.
  **4.0:** then, always in package mode (with or without a profile), `receiver-init` writes `view_mode: simple` +
  `first_steps_seen: false` if absent → the receiver starts in 🙂 simple view and sees "🧭 צעדים ראשונים" once (§8k). So a reinstall never overwrites
  what the receiver changed (but a receiver who already got the Beit El logo from an earlier no-profile package keeps it).
- Regular vs profile zips share the `שיתוף` folder; `zip_list/stale_info/prune(…, profile)` filter by
  `package.json.profile`, so the regular stale/rebuild/prune never sees profile zips. `share_watch`: regular
  `share_auto_rebuild` unchanged; otherwise `share_profile_autorebuild` rebuilds one stale profile zip that has
  `auto_rebuild` on, only when idle. Profiles with no zip are never built automatically; profile zips are never pruned
  except by that profile's own rebuild.

### 8b. Update box — applying an update written by any AI (21/10/2026)

For when Claude Code is unavailable. Settings → 🖥️ מערכת → **"🛠️ עדכון תוכנה"**. "📋 העתק הוראות לעוזר" copies
`make_short_update.FORMAT_RULES` + the current version + every tracked file with its line count; the owner pastes that
into any chatbot, adds his request, and pastes the answer back. **The one accepted format:**

1. optional first line `תיאור: <one sentence>` (goes into the history)
2. one or more blocks, either a unified diff in a ```` ```diff ```` fence (paths with `a/` `b/`; new file `--- /dev/null`,
   deleted `+++ /dev/null`; applied with `git apply --recount`, so wrong hunk line counts are tolerated, but context
   lines must match), or a full-file block:
   ```
   === קובץ: pipeline/scripts/example.py ===      (or: === FILE: path ===)
   <entire new content>
   === סוף קובץ ===                               (or: === END FILE ===)
   ```

`make_short_update.py check` refuses: absolute/`..`/`.git`/gitignored/symlink paths, config-key-cookie names
(`config.env *.env *cookie* *token* *secret* *.toml rclone.conf *.key *.pem *credential* *.vault state.json`), binary
patches, diffs that don't apply. The page shows the files (+/−) and a coloured preview; "✅ החל" runs
`apply` as a job: snapshot commit ("לפני עדכון: …", includes any uncommitted work) → apply → commit ("עדכון: …") →
self-check (compile every tracked .py, `bash -n` every .sh, parse every .json, page `<script>`s parsed with deno/node,
a test server on a free port in test mode with a temp settings copy must answer `/` and `/api/home`) → on failure
`git reset --hard` to the snapshot and a clear Hebrew message. "↩ בטל עדכון אחרון" = `git revert` of that commit +
self-check. History: `~/.local/share/yeshiva-shorts/updates.json` (`MAKE_SHORT_UPDATES` overrides, for tests).
"🔄 הפעל מחדש את התוכנה" = `/api/restart` → `os.execv` of the same server (refused while a job runs); the page
reconnects. Tested 21/10 on a copy of the repo: good diff, new file, syntax-error file, server-won't-start import,
broken page JS → the three broken ones rolled back automatically; forbidden/mismatch/no-update texts refused; undo.
Commits made by the box use the identity "עדכון מהתיבה (יצירת שורטס)" — a later `git push` from his PC includes them.

### 8c. Working with a Claude chat (claude.ai) — "💬 עבודה עם צ'אט (Claude)" (27/10/2026)

Why: the owner trusts Claude most for code and wants to save his Claude Code usage — the chat only *writes* the change;
the box above tests and applies it. The old "העתק הוראות לעוזר" sent no code, so a chat could only guess.
Settings → 🖥️ מערכת → 🛠️ עדכון תוכנה → card "💬 עבודה עם צ'אט (Claude)". Two buttons, each = ONE text block (`make_short_chat.py`):
- **🐞 מצאתי באג** + "מה קרה?" → FORMAT_RULES, chat instructions, HANDOFF §1–§2 (read live from this file), versions, the
  last failed job (kind, error, log — paths made repo-relative *before* `HEALTH.scrub`, which otherwise eats long paths),
  health results, the latest selftest (`selftest_last.json`, written by every `make_short_selftest.py` run;
  `MAKE_SHORT_SELFTEST_LAST` overrides), recent update-box history, the full file index, and code.
- **➕ אני רוצה שינוי** + "מה לשנות?" → the same without the failure context.
- File choice: `TOPICS` (Hebrew words → files + focus terms; single words match at word start, so "תור" ≠ "כפתור"),
  traceback paths (snapshots mapped back to repo paths) and `KIND_FILES` for bugs, plus token hits weighted by rarity
  (a word in every file counts ~0). "🔍 אילו קבצים ייכנסו?" shows the choice as a checklist; ticking/unticking re-plans.
- Budget: setting `chat_code_chars` (default 150 000 chars, 30k–1M). Small files go whole; big ones (the page is ~265k
  chars, the server ~150k) only as the relevant sections `[שורות a–b]` + a map of the file. The block tells the chat it may
  answer ONLY `צריך קבצים: path, path:120-300, path#func` — `UPD.parse` detects that (`needs`), and the box offers
  "📋 העתק את הקבצים שהעוזר ביקש" (`/api/chat/files` → `CHAT.followup`).
- 🔒 `CHAT.guard` runs on every block: his real key values (from config.env/env) and key patterns → `[הוסתר]`; anything
  left → the block is refused. Forbidden/ignored files never enter. Selftest + `pipeline/tests/test_chat_update.py` assert it.
- Answer format, now forgiving of claude.ai formatting: new **"חפש והחלף"** block (`=== החלפה: path ===` /
  `<<<<<<< לפני` / `=======` / `>>>>>>> אחרי` / `=== סוף החלפה ===`, English EDIT/SEARCH/REPLACE too) — exact match first,
  then line-wise ignoring trailing spaces, bidi marks, copied line numbers and a whole-block indent shift; unchanged lines
  keep the file's exact bytes (karaoke_ass.py has REAL U+202B marks mid-line — never strip bidi globally). Markers are
  recognised through `**`, backticks and leading RTL/LTR marks; CRLF; NBSP at the start of diff lines; diffs retry with
  `--ignore-whitespace`, then `--unidiff-zero`. A full-file block without its end line = "the answer was cut" error.
- Failures go back to the chat in one click: "📋 העתק לצ'אט מה לא התאים" (check errors + the REAL code ±12 lines around the
  closest line) and "📋 העתק לצ'אט מה נכשל" (apply log after the automatic rollback) — `/api/chat/retry`.
- After apply, `make_short_update.py` now also runs `make_short_selftest.py quick` (static rules + default-settings finish of
  a 4 s clip + save/drop/restore + server checks, ~10 s); failure = rollback like the self-check.
  `MAKE_SHORT_UPDATE_NO_SELFTEST=1` skips it (tests only).
Tested 27/10 on a repo copy (port 8766, own empty config — no keys): plan/checklist/copy in the page, a claude.ai-styled
correct answer applied (self-check + quick selftest passed, server self-updated), a broken one rolled back, the bug block
picked the traceback file, "צריך קבצים" → follow-up, mismatch → retry block. NOT tested: a real claude.ai conversation.

### 8d. External review fixes (29/10/2026)

The owner sent the code to Gemini for a review; each finding was checked against the real code and he
approved all verified fixes. Commits 73df08a, 4eaac0e, a8c708d, 3adead7, 47f439e.

- **Local server refuses foreign websites** (`make_short_app.py`, `H.refused()`, called first in `do_GET`/`do_POST`).
  `Host` must be `127.0.0.1|localhost|[::1]:<PORT>` (blocks DNS rebinding, GET too). POST: `Content-Type:
  application/json` only (a `text/plain` form body used to parse as JSON), `Origin` — when sent — must be our own
  page, `Sec-Fetch-Site: cross-site` refused. A plain cross-site *navigation* to `/` still opens the page; the
  API never answers a foreign site. Callers without `Origin` (urllib, the launcher's PowerShell probe, the
  update-box test server, tests) pass. **Any new client that POSTs must send `Content-Type: application/json`.**
  The page's `api()` and `beacon()` already do; sendBeacon on close was verified in a real browser.
  Test: `pipeline/tests/test_local_guard.py` (also in `make_short_selftest.py`).
- **Drive backup cannot hang forever** (`drive_backup.sh`, `make_short.py:run_drive_backup`). Every rclone call
  runs under `timeout`; the sync limit = 1 h + folder size at 0.3 MB/s (`DRIVE_LIMIT_SEC` overrides; the
  slowest logged run was ~1.8 h for 2.7 GB / 161 uploads), plus `--contimeout 60s --timeout 5m`. Exit 124 =
  timeout (a normal failure → 5-min retry, ☁ indicator). A lock whose holder (pid file `drive_backup.pid`:
  pid, start, limit) is older than its limit + 10 min is recovered: the processes holding the lock file
  (found via `/proc/*/fd`) are stopped. The server runs the script in its own process group with a backstop
  timeout (`drive_limit()` — same formula, change both) and kills the whole group. `drive_backup.log` rotates
  at 5 MB. Test: `pipeline/tests/test_drive_timeout.py` (fake rclone, temp HOME).
  rclone remote checked 29/10: **no personal `client_id`** (rclone's shared key) → the 7-day refresh-token
  expiry of a Google Cloud app in "Testing" does not apply today. When he follows the banner's "own client_id"
  fix, the OAuth consent screen **must be published to Production**, or the backup stops every 7 days.
- **Pinned libraries** — `requirements-pinned.txt` at the repo root is the ONE list of known-good versions
  (faster-whisper, modal and their deps, numpy, opencv, requests, google libs). `install.sh` passes it as pip
  constraints (`-c`) and falls back to an unpinned install only if a pin cannot install on that Python.
  yt-dlp is deliberately absent (its "עדכן עכשיו" also uses `-c`, so its deps stay pinned). Models are not
  libraries — model choice stays in settings.
- **"נסה מנוע חדש יותר"** (`make_short_engine.py`, health id `engine`). PyPI checked at most daily
  (`~/.local/share/yeshiva-shorts/engine_check.json`). A transcription job (prepare/retime/pick) that fails with
  a library-looking error (`ENGINE_RX`) while a newer faster-whisper/modal exists → red alert with the button.
  Otherwise, if newer exists → a quiet blue ℹ️ note (level `note`, not counted as an alert), "סגור" hides it for
  30 days. The button: refused while any job runs or waits, and blocks new jobs while it runs; snapshot
  (`engine_snapshots/`) → `pip install --upgrade faster-whisper modal` → self-check in a fresh process
  (imports, VAD, tiny transcription only if the local model is already cached, Modal volume lookup — no
  compute cost) → fail: reinstall the previous versions, "הוחזרה הקודמת"; pass: rewrite the changed lines in
  `requirements-pinned.txt` and commit locally. CLI: `make_short_engine.py status|selfcheck|upgrade`.
  Test: `pipeline/tests/test_engine_upgrade.py` (fake pip).
- **mix_music.py**: a corrupt/empty track exits with a Hebrew message naming it and what to do; a failed final
  mux exits non-zero (it used to print and return 0). Test: `pipeline/tests/test_mix_corrupt.py`.
- **make_short_app.log** capped at 2 MB: old → `.1`, new starts with the last 300 lines.
- Skipped on purpose: the review's note on `youtube_upload.py` description truncation (upload feature dropped 13/10).
- Not tested: the engine button for real (only with fake pip), the tiny local transcription (model not
  cached on his PC → step skips), a timeout against the real Drive, a new-PC install on another Python.

### 8e. Second review fixes (31/10/2026)

- **`yeshivashorts:` handler is no longer injectable.** It was registered as `"<bat>" "%1"`: a URL with `"` then `&`
  broke out of the quoting and ran another command. Now `app_link.ps1` registers `"<bat>" protocol` (no `%1`), and
  `launcher.bat.txt` treats the exact word `protocol` as "start the server, no second window" (`minnowin`). The old
  `xyeshivashorts:` prefix test stays only as a legacy path for a not-yet-re-registered handler (it only compares).
  The `set "A1=x%~1"` line is the single place the argument is expanded; it now only ever sees our own words
  (`min`, `minnowin`, `protocol`, empty). **The registry value changes only when `app_link.ps1` is re-run** (the
  installer does it; Claude must not run it for him — safety check) — until then the old registration is still
  exposed. The live launcher `יצירת שורטס.bat` in the project folder is rewritten by the installer from `launcher.bat.txt`
  (ASCII, CRLF) and was patched by hand with the same edit on 31/10. Test: `static_checks` in `make_short_selftest.py`.
- **`{` / `}` in subtitle words** (Gemini/editor/his edits) opened an ASS override block in libass → the word vanished.
  The single funnel is `subtitle_terms.fix_words` (used by burn, marker, float, plain and `/api/sub_preview` via
  `make_short._lines`): braces become full-width `｛ ｝`, so word counts, alignment and layout are unchanged.
- **Preview cleanup.** `make_short_app.prune_previews()` (called from `start_preview`): finished `PREVIEWS` entries
  not polled/streamed for 1 h are dropped and their mp4 under `<lesson>/work/preview/` deleted (plain unlink —
  generated cache with deterministic names, rebuilt on demand; never a running entry, never a file a kept entry uses,
  never a path outside `work/preview`). `seen` is refreshed by `preview_view` and `/preview_file`.
- **Windows path length.** `shorts_layout.fit_file_name(folder, name)` shortens the FILE name too (keeps extension,
  cuts from the end, min 20 chars, room for the `.part` temp) and `export_clips.export_flat` uses it for the copy;
  `folder_name` still shortens only the folder. Also found while testing a 250-char title: `sanitize_filename` allowed
  150 letters = 300 bytes in Hebrew → ext4 `ENAMETOOLONG` in the project's own rename; now capped at 200 bytes.
  Tests: `pipeline/tests/test_export_layout.py` §5.
- Verified, no change: "סיים את כל N הקליפים" (page, card 12) already exists as the big button — no "mark all reviewed".

### 8f. Subtitle styles round 3 — float height, float shadow, "קופסה" (card 24, 31/10/2026)
Rule kept: every new setting at its default → existing styles' `.ass` byte-identical to HEAD (checked: teal, plain, marker ×3,
float ×2 on a real clip, plus `shadow=(True,50,3)` == no shadow arg; and a selftest check).
1. **Float height (report only, nothing moved).** Measured with a flat word (no descenders) rendered by libass at 1080x1920:
   baseline of the last row — teal y=1565 (81.5 % of 1920, 355 px from the bottom), marker y=1491 (77.7 %, 429 px),
   float y=1481 (77.1 %, 439 px). So marker is 74 px (3.9 %) and float 84 px (4.4 %) higher than teal. **Intentional:**
   `MV = 400` is copied from the approved prototype `gen_v3.py` (line 18), the comment in `karaoke_styles.py` says
   "higher than teal, like the prototype"; teal's margin is 320. Not a bug; if he wants them level, change `MV` (but then the
   marker/float centring constants were measured at 400 — re-run `centermeasure.py`).
2. **Float shadow.** Settings `float_shadow` (on), `float_shadow_opacity` (50), `float_shadow_size` (3). Default tuple
   `KS.FLOAT_SHADOW_DEFAULT` = the old look exactly (hard shadow depth 3, back `&H80000000`). Anything else → `shadow_plan`
   returns a *soft* shadow: an extra layer-0 event per word (black `\1c`, `\1a` from opacity, `\blur` = 0.8·size, offset
   0.35/0.7·size, same `\move`/`\fad`) and style shadow 0; off → style shadow 0, no layer. `SET.float_shadow(cfg)` is None
   for the default; `MS._style_sig` adds the tuple to `finish_key` only for FLOAT clips (like marker opacity), and the
   preview `sig`. CLI: `--shadow=on|off --shadow-opacity= --shadow-size=`. Sheets: `דוגמאות לבדיקה\float_shadow_before/after.png`
   (after = 75 %, size 6). Settings card has a live strip on a light background. Per-clip: none (global, same as marker opacity).
3. **"קופסה" = choice `BOX` / `BOX:RRGGBB`** (RRGGBB = colour of the spoken word, default teal 1AC8A8). One rounded box
   (radius 34, pad 38) around the whole 1–2 row chunk, fixed (no `\move`/`\clip` on it), same `MV=400` height as marker/float,
   Marker font (YSMarkerBold 103). Layers: 0 box (`\p1`, `\an7`), 1 full white text, 2 `Hi` style = same text in the word
   colour clipped (`\clip`) to the measured word rect (Hebrew RTL safe: no colour tag inside the line). Settings `box_color`
   (000000), `box_opacity` (60), `box_palette` (4 word colours, editable, per-colour active/disabled via `colors_off`
   `BOX:RRGGBB`). Light box colour → base text 111111 (`dark_text`). `.ass` tags `ys-style: box / ys-rgb / ys-opacity /
   ys-boxcolor`; `clip_rgb` reads `BOX:RRGGBB` back; marked words (🔠) do nothing (like marker). Joined: `parse_choice`,
   `choice_name`, `style_lists` (→ 🎲 now draws among FOUR styles, equal weight — a clip rebuilt by random may pick differently
   than before), settings validation, `sub_color`, page `parseSty/colorName/swStyle/qsColors` + quick-style row 🔲,
   real-libass preview (same as marker/float), `/api/sub_preview` and `{ }` sanitising (shared `fix_words`).
   Sheets: `דוגמאות לבדיקה\box_overview.png`, `box_sequence.png`.
- Tests: `style_checks` (shadow default byte-identity, soft/off shadow, box events/colours/height vs marker, settings flow into
  the burn, restyle --subs, preview, braces in box, random now 4 styles) — all in `make_short_selftest.py`.
- Not tested: a full real-lesson build with BOX/shadow through the page UI end-to-end (only through `restyle`/preview and
  the settings page in the test app); box over bright backgrounds on other rabbis.

### 8g. Undo in the scene editor, select-to-act bar, styles off the 🎲 (1/11/2026)

* **Undo** (`make_short_page.html`, 📜 scene editor): `SCN[key].hist/redo` = stacks of JSON `cuts` (max 60). `scPush` before every
  add/remove/"back to suggestion"/cancel; `scUndo(n, redo)`; buttons ↶ בטל (count) / ↷ החזר; Ctrl+Z / Ctrl+Y (Shift+Ctrl+Z) when
  focus is not in an input/textarea (those keep the browser's own undo). `loadScene` keeps an unapplied edit (and its history) if the
  card is re-opened and the server's cuts did not change. Edits are still in-memory only until "✓ החל" (as before).
* **Select-to-act bar**: `selBarCheck` after mouseup (40 ms, left button only) / Shift+arrows (450 ms) dispatches a *synthetic*
  `contextmenu` event at the end of the selection — the existing listeners (scene editor, `.ctx.sel` proposals text, 🔠 textarea)
  build the same menu, shown with class `selbar` (compact row). No duplicated logic: any selection menu that listens to
  `contextmenu` gets the bar for free. Closes on mousedown elsewhere / Escape / scroll / typing; `mousedown` on the bar is prevented
  so the selection survives. Right-click works as before.
* **`styles_off`** (setting, default `[]`): keys of `make_short_settings.STYLE_KEYS` (karaoke/plain/marker/float/box). Only the 🎲
  random skips them (`random_groups` → `random_pool`, `clip_choice`, `em_pool`); manual choice and the default `sub_color` still work.
  Page: per-style checkboxes (settings → colours, "🎲 הסגנונות שהאקראי בוחר מהם"); `rndPool` filters it for the per-clip 🎲;
  unchecking the default's style asks first; all off → teal fallback + notice (existing `rfb` path). Reset/undo/share defaults are
  generic (`DEFAULTS`). Tests: selftest (settings + styles_off block).
* Test-browser gotcha: the pane may keep a service worker from an earlier visit (`/sw.js`) and loop on `offline.html`; unregister it
  (`navigator.serviceWorker.getRegistrations()`) and clear `caches`.

### 8h. 🎬 Hook opening (6/11/2026, approved after sample round on `yeshiva-shorts\דוגמאות הוק\`)

The strongest 1–3 s of a short are played first (with subtitles), then a white flash, then the short from its real start —
*including that moment again*. Engine: `pipeline/scripts/hook_clip.py` (shared by Claude's skill pipeline and the make-short tool).

* **Look (his decisions):** white flash only (`FLASH_RGB` warm white, no gold, **no zoom**), soft whoosh at the flash (`hook_sfx`,
  −22 dB, starts only after the hook voice ends), music from the very start (normal mix over the whole video).
  **The hook must be heard to the end:** after the last word a natural tail `TAIL=0.14 s` fades out (hsin), only then the flash
  fades in over `GAP=0.10 s` and is fully white at the cut `Tc = Th + GAP`; flash fades out 0.32 s into the short. (Round 2 cut
  mid-word in continuous speech — "היישוב" — he heard it clipped; never cut at the ASR word end without the tail.)
* **Pieces:** `find_span` (quote → word indices, exact or ≥85% fuzzy), `suggest` (heuristic fallback: whole sentence of 4–11 words,
  1.3–3.5 s, not in the first 5 s, `?`/`!`/contrast words win, stutter loses), `plan` (cuts on measured quiet 20 ms), `combine`
  (hook words from 0 + all words shifted by `Tc`; last hook word gets a "." only to end the caption), `shift_layout`/`shift_idx`
  (manual line layout + 🔠 indexes shift by K), `trim_ass` (hook captions end at the cut), `build_video` (two `-i clean` inputs —
  **never `trim` + `concat` on one input: the whole video is buffered, WSL died of memory**), `prepare` (all of it).
* **Tool:** settings `hook_on` (default **True**) / `hook_sfx`; per clip `c["hook_on"]` (None = follow settings), `c["hook"]`
  `{i0,i1,text,src: gemini|auto|user}`, `c["hook_quote"]` (model proposal from the pick prompt: new field `hook_quote`, verified
  against the final aligned words by `find_span` — not found → heuristic), `c["hook_built"]`, `c["hook_extra"]` (=Tc, for the
  resume check). `make_short.hook_prep()` is called from `finish()` and `restyle()` (burn source = `work/hook/<clip>_clean.mp4`,
  ASS built from `work/hook/<clip>_words.json`; `work/subtitles/<clip>_words.json` stays the plain aligned words, so the layout
  editor / 🔠 / rate checks are untouched). `finish_key` includes the hook only when active (off ⇒ old keys). `restyle --hook=on|off|redo`
  (old clips are NOT given a hook by a colour change unless asked: `hook_built`). Server: `GET/POST /api/hook`
  (`MS.hook_view` / `MS.hook_set`; set does not burn), `/api/restyle` takes `hook`. Page: 🎬 row in "⚡ הגדרות מהירות"
  (בלי הוק / הוק, "✏️ הרגע" = click the first and last word, "↺ להצעה", "✓ בחר רגע זה" → apply bar), settings card.
* **Skill (Claude's own shorts):** SKILL.md §6ב — `hook_clip.py build` on the clean video + final words, `karaoke_ass` on
  `hook_words.json`, `hook_clip.py trim`, burn `hook_clean.mp4`, loudnorm, music as usual.
* **Not done / honest limits:** no animated preview before applying (the apply bar rebuilds in ~1 min and the draft shows the
  result); the heuristic is a *suggestion* (he edits via the 🎬 row); the Gemini pick prompt field is untested against the live model.
* Tests: `pipeline/tests/test_hook.py` (synthetic 8 s clip: lengths, white frame at the cut, voice heard / silence before the
  flash), selftest.

### 8i. 🛠️ "תקן שורט זה בצ'אט" — a one-off repair of ONE finished clip by a regular claude.ai chat (card 27, 12/11/2026)

Why: a small glitch in a finished clip (part of the subtitles in another colour — the D9 bug; a click in the audio) should not mean
"discard the clip". Same idea as §8c but per clip and about a MEDIA file, not the tool's code. The owner uploads the video to the chat
himself (the tool cannot attach files — the UI says so), pastes ONE context block, and pastes the chat's answer back; the tool runs it
isolated, shows before/after, and only "✓ אשר" swaps. Engine `pipeline/scripts/make_short_fix.py`; server `fix_api` / `fix_state` /
`fix_media` in `make_short_app.py` (`/api/fix/<files|block|bug|review|reveal|check|apply|accept|discard|undo|state>`, `/fix_video`, `/fix_frame`);
page: button "🛠️ תקן שורט זה בצ'אט" on every finished-clip card and in the inline text-edit card → panel `.fixbox` (JS block `fixToggle …`).
* **Panel:** defect text + optional timestamp (`⏱ סמן מקום בנגן` takes the player time; final-video time, includes the hook), tick list of what goes
  into the prompt (facts / ASS excerpt / whole ASS / words / final text / pipeline), the clip's files with `📂 הצג בתיקייה` (Explorer `/select`) and
  `📋 העתק נתיב` (Windows path), `📦 עותק קטן לסקירה` (540x960, crf 30 — never replaces the original; offered more loudly when the video is >30 MB),
  `📋 העתק פרומפט`, `🐞 תקלה חוזרת?` (= the card-19 bug block with the clip + defect in front, `/api/fix/bug`).
* **Prompt block** (`build_block`, ≤ ~90k chars, `CHAT.guard` over the whole thing — real key values + key patterns): request + his words, HARD RULES
  (1080x1920, -14 LUFS, fonts only via `assets/fonts`, **never SHORTS_LIB**, exact spoken words, change only the reported defect, no network/deletes,
  "if it looks like a tool bug answer `זה באג בתוכנה: …`"), the answer format, measured clip facts (ffprobe, ebur128, style/colour, camera, hook Tc,
  track + mix levels, logos, 🔠, previous chat fixes), file list, the exact pipeline order with the real ffmpeg/loudnorm/mix commands, an ASS **colour
  summary** (every `\c`/`\1c` override with count + times — the D9 defect shows up there at once), the ASS excerpt ±3 s around the timestamp, words+times, final text.
* **Answer format** (`parse`): `=== תיקון קליפ ===` containing either (A) `=== החלפה: subtitles.ass ===` search/replace (`<<<<<<< לפני / ======= / >>>>>>> אחרי`,
  same tolerant parser as the update box — chat formatting, fences, bidi at line start; first line `@all` = literal replace-all, `@regex` = `re.subn` with `\g<1>`)
  — **no code at all**: the tool re-burns exactly like `restyle` (burn source = `work/hook/<clip>_clean.mp4` when `hook_built`, else the clean clip; logos from
  current settings; `loudnorm`; same track + `music_db`); or (B) `=== סקריפט: fix.py ===` Python for glitches that are not in the subtitles. Script contract:
  env `IN_DIR` (copies, ASCII names: final.mp4 plain.mp4 clean.mp4 subtitles.ass words.json info.json), `OUT_DIR`, `FFMPEG`, `FFPROBE`, `FONTS_DIR`; must write
  `OUT_DIR/plain.mp4` (no music) — the tool loudnorms and mixes the same music itself. Sandbox: static scan (`BAD_SCRIPT`: sockets/urllib, deletes, eval/exec,
  os.system/shell=True, curl/rm…, config/keys/SHORTS_LIB, `../` and absolute paths), `unshare -rn` (no network; falls back with a warning), clean env (no keys),
  scratch dir `work/fix/<id>/`, 15 min timeout, and a manifest of the clip's own files compared before/after (a script that touched them is rejected).
  Also: question → "answer in the same chat"; `זה באג בתוכנה:` → button to copy the general bug block; truncated script → clear error.
* **Never touches the draft until accept.** Job `fixapply` (plain `start_job`, `clip=`, `busy()` blocks other jobs on that clip; the burn takes the heavy lock) →
  `work/fix/<id>/{answer.txt,result.json,plain_new.mp4,final_new.mp4,subtitles_new.ass,before.jpg,after.jpg}`; self-check `verify`: has A/V, same size,
  fps ±0.6, duration ±0.75 s, h264+aac, **5 sample frames not black** (hard), loudness −16.5…−11.5 and peak ≤ −0.5 (soft warnings). Page shows both videos, both
  frames at the marked second, the check list. `accept` (refuses if the clip changed meanwhile) keeps `work/fix/versions/<clip>/<id>_{final,plain,ass}_before.*`,
  replaces final+plain(+ass), records `c["chat_fixes"]` (card badge "🛠️ תוקן בצ'אט"); `undo` restores them byte-exactly (or re-mixes from the restored plain if music/level
  changed since); `discard` drops a ready/failed one. A restyle with colour/camera/hook/text rebuilds from the source and so drops the fix (the card says so); a
  music-only swap keeps it (it mixes from the fixed plain). Saving to the Shorts folder is the usual "💾 שמור" (the draft's signature changed → "unsaved").
* Tested 12/11 on an isolated copy (`~/ys27_test`, port 8766, `MAKE_SHORT_FIX_NO_EXPLORER=1`, real Browser pane click-through incl. before/after + accept + undo):
  `pipeline/tests/test_fix_chat.py` (block contents + secret guard, parser variants, script scan, D9-style gold-colour injection → fix → undo ×2 with sha equality and
  real pixel counts, scripts: ok / writes outside / wrong size, hook clip, all HTTP endpoints). NOT tested: a real claude.ai conversation (the answer format is
  written to be copy-able from chat output, but no real chat has produced one yet), Windows Explorer `/select` (env flag stubs it), a real hook clip of his,
  clips > 60 s, very large videos (claude.ai's upload limits are the chat's, not ours).

### 8j. Version 3.4 — versions, 📝 description settings, Drive source fix, Claude-memory backup (16/11/2026)

- **Versions.** One source of truth: `VERSION` at the repo root (`tool_version()` in `make_short_app.py` and
  `make_short_share.py`). Shown small beside the title ("גרסה 3.4"), in "העתק פרטים לעוזר", in the share zip name
  (`יצירת שורטס <version> - <date>.zip`) and `package.json` `version`. Annotated tags `v1.0 … v3.3.2` were added after the
  fact (index in CHANGELOG — 2.1/2.2 boundary moved: the share zip came before resume/draft in git), `v3.4` for this one.
  **Every change from now on: bump `VERSION`, a CHANGELOG section under that number, tag `vX.Y.Z`, push tags.**
- **📝 תיאור ותגיות** (settings section `desc`): `org_name`, `footer_lines`, `subscribe_text`, `fixed_tags`
  (`IDENTITY_KEYS` — "אפס הכול" skips them). `make_short.desc_settings/footer_for/write_meta` build the series line
  (`מתוך סדרת השיעורים X | org`; no org → no ` | …`; no series → org alone; neither → no line) + footer lines; tags =
  Gemini's + rabbi, org, series, fixed (the old order). `write_clip_meta.py --subscribe` is always passed by the tool;
  without the flag it reads the setting (so the skill path matches). `meta.json` gets `desc_sig`; `refresh_meta`
  rewrites a draft whose sig differs (drafts without a sig — pre-3.4 — are left alone). Gemini prompts use
  `SET.channel_phrase()` / `make_short_editor.org_text()`; empty org → "שיעורי תורה". His values were written to his
  settings file (backup `make_short_settings.json.bak-3.4-<ts>`) and a regenerated description for an existing export
  was **byte-identical** (Perlman, "סברות שאין להן…", 997 bytes, tag order too). The selftest compares against a frozen
  copy of the old formula, and the package test scans the zip's code for his three strings (read from his settings file —
  the selftest itself never contains them). `assets/guidelines/shorts_default.txt` still carries another client's links
  (unchanged, his decision; neutral package guidelines are 3.5).
- **Drive backup source** = `DRIVE_SRC` → `SHORTS_EXPORT_DIR` (env, or that single line of `config.env` when the script runs
  without `shorts.sh`) → `~/Videos/Shorts`; `drive_limit` the same. ⚠️ Not fixed: `windows/install_windows.ps1` (~l.394) creates
  the "שורטסים מוכנים" shortcut to `~/Videos/Shorts` and `mkdir -p ~/Videos/Shorts` before the setup wizard asks for a folder —
  a user who picks another folder gets a shortcut to an empty folder.
- **"גיבוי תוכנה" daily + Claude memory.** `backup_extras.sh backup` (and new `memory`) also copies, by whitelist only,
  `<win home>/.claude/CLAUDE.md`, `<win home>/.claude/projects/*/memory/*.md`, `<win home>/yeshiva-shorts/CLAUDE.md` to
  `גיבוי תוכנה/claude/` (`.credentials*` excluded explicitly; after copying, anything not `.md` or secret-looking ⇒ exit 2).
  Win home = `CLAUDE_WIN_HOME` or `%USERPROFILE%`; none ⇒ skipped silently (receivers). `restore` brings them back (`--update`).
  `EXTRAS_REMOTE=/local/path` works without Drive (selftest). The app runs `backup` once a day (`extras_watch`, status in
  `~/.local/share/yeshiva-shorts/backup_extras_status.json`, log line in the app log); health item `extras` warns only after
  >1 day of failures. Never in the share package (the package takes only logo/guidelines/music).

### 8k. Version 4.0 — 🙂 simple view + "🧭 צעדים ראשונים" (16/11/2026)

The owner shares the tool; receivers found the window too complex. **The owner's experience must not change.**

**Simple view = a view, not a program.** Settings `view_mode` (`simple`/`advanced`). The page puts class `simple` on
`<body>` (`applyView()`, called at start and in `renderSettings`); the only rule is `body.simple .adv{display:none!important}`
(+ `body:not(.simple) .simponly` for two short simple-only hints). No logic reads `view_mode` — a hidden setting keeps its
value and keeps working. Toggle: `#viewBtn` in the top bar → `toggleView()` → `setS({view_mode})`.
- To hide something in simple: add class `adv` to it (static HTML or a JS template). To keep it: don't.
  **A new setting (`data-k`) must be added to `SIMPLE_KEYS` or `ADV_KEYS` in `make_short_selftest.py`** — the selftest
  fails otherwise (it parses the page and compares the visible/hidden `data-k` sets exactly).
- Hidden: see CHANGELOG 4.0. Settings nav: `ADVSEC` (`tabs`,`rules`,`camera`) disappear; `showSec` falls back to `system`.
  Clip card: `📜` scene panel always `adv`; the no-warning "המצלמה מקפצת? בנה במצלמה חלקה" link `adv`; the 🎥 row in
  "⚡" is `adv` unless the clip has exits or a pending camera change; real warnings (exits, off-centre) never `adv`.
  The health alert "אין קובץ עוגיות" (static check only, not `from_job`) is `adv` (`quietAl`).
- **Who gets which default** (`make_short_settings`): DEFAULTS = `simple`, `first_steps_seen: False` (= fresh install).
  `_read()`: a settings file that **exists** but has no `view_mode` is pre-4.0 (the owner, or an old receiver) → in memory
  `advanced` + `first_steps_seen: True`; the app writes it at start (`ensure_view()`, logged). `_write()` adds
  `view_mode: simple` to a brand-new file so a fresh install's first setting change isn't mistaken for pre-4.0.
  The package installer (step 6, package mode only) runs `make_short_share.py receiver-init <settings>` → writes
  `simple` + `first_steps_seen: false` **only if absent** (reinstall never resets a receiver who moved to advanced).
  `reset()` ("אפס הכול") skips `VIEW_KEYS` (`view_mode`, `first_steps_seen`, `profile_from`).

**"🧭 צעדים ראשונים"** = overlay `#fsDlg` (`openFirst/renderFirst/closeFirst`). Opens by itself when
`first_steps_seen === false`, and the page immediately sets it `true` (a reload never reopens it). Buttons: top bar `#fsBtn`,
Settings → 🖥️ `#fsBtn2`. Status is live (re-rendered every 2.5 s, not while typing): Modal/cookies/Drive from the health
results (`hres(id)`; "🩺 בודק…" until the first check returns), Gemini from `GEM`. Actions reuse existing paths:
`modal_connect` (new `/api/action` id → `modal_connect()` in the app: black window with `<venv>/bin/modal token new`, same
as installer step 7, then `recheck(["modal"])`), `/api/gemini/key`, `upload_cookies`, `drive_reconnect` (its script now runs
`rclone config create gdrive drive scope drive.file` when there is no `gdrive:` remote yet — like installer step 5),
`/api/upload_logo` (left slot), `setS` for the four 📝 keys. Profile notice: `profile_from` (written by `apply_profile`
with the profile name, only if absent) **and** `org_name`/`footer_lines` non-empty → "הפרטים האלה הגיעו מוכנים עם התוכנה
(פרופיל «X») — אפשר לשנות אותם כאן"; otherwise the short explanation with empty fields (empty profile or none).
Tested 16/11: selftest (`view_checks`, package + profile package installs), browser preview of both views on port 8766
(`make-short-v40` in his `.claude/launch.json`: isolated config/settings), screenshots in `yeshiva-shorts\צילומי מסך גרסה 4.0\`.
**Not tested:** `modal token new` from the window on a machine without Modal (the owner is connected), a clip card in
simple view in the browser (no test lesson; covered by the selftest's template checks).
**4.0.1:** `#viewBtn` is a sliding switch (`.vsw`, `role=switch`, `aria-checked` = advanced; class `on-adv` moves the
`::before` knob). The top bar has class `bar` and compact rules (`.top.bar …`) so it fits one row (~913 px measured at a
960 px window; main is capped at 1060 px). 🧭 is icon-only (`.ibtn`, full name in `title`); Gemini meter drops "היום",
Drive meter shows a short state with the sentence in `title`. When adding a top-bar item, re-measure one row at 960 px.
**4.0.5 (Drive own key, interrupted attempts):** markers next to rclone.conf — `.before_own_key` (backup), `.own_key_pending`,
`.own_key_ok` (`make_short_health.own_key_paths`). `check_drive` green for own key only with `.own_key_ok` or no backup
(hand-configured). `own_key_recover(conf, busy)` (startup thread `own_key_startup`, also before every new attempt):
backup without ok → same client_id = nothing to do; new client_id + same token = interrupted → restore + delete backup;
new token = finished → write ok. Waits while `rclone config reconnect/create gdrive` still runs (`rclone_busy`, pgrep).
Never reads values out loud — compares in memory only. Tested with a fake rclone (`own_key_checks`).
**4.0.2:** app icon `<img class="applogo" src="/icon-192.png">` before `.ttlblk` (h1 + `#verTag` stacked); `#fsBtn` has its
label back (`.blbl`), hidden only under 1100 px (`@media`); `#setBtn` larger. Measured one row at 1280 (bar 1028 px, ~22 px
spare in test mode with the 🧪 badge) and at 960 px.

### 8l. Version 4.1.0 — fixes from an independent code review (17/11/2026)

Three read-only reviewers, every finding re-verified against the code; full list in CHANGELOG 4.1.0. What to know when touching these areas:
- **Music paths.** `index.json` stores `path` as written by whoever built it. **Always read it with `music_library.load_index()`**
  (never `load_json(index_path())`): it resolves any path (relative `tracks/x.mp3`, or an absolute path of another machine) to the
  local music dir. The share build writes a *portable* index (`make_short_share.portable_index`: relative paths, no `removed_from`).
  Re-install merges new tracks (`make_short_share.merge_music`, run by the installer) and replaces `_refs/mix.py`.
- **Package contents.** `make_short_share.package_member` decides per file: `PACKAGE_EXCLUDE` (CHANGELOG, owner's migration guide) is
  dropped, HANDOFF loses §10, `windows/install_windows.ps1` loses the region between `# <GITHUB-FLOW-BEGIN>`/`# <GITHUB-FLOW-END>`
  (keep both markers when editing the installer), identity strings are replaced (`neutralize`). Needles are built by concatenation /
  base64 so the code that ships doesn't contain them — **never write the owner's GitHub name / user name / "Beit El" literally in code
  or tests** (the build fails with "🚨 … פרטים מזהים"). `identity_scan(zip, profile)` runs for every package; profile adds Beit El and
  the pixel-level logo check (needs PIL; without it only the exact file hash). `zip_list`/`prune` touch only zips whose `package.json`
  has `format`+`commit`.
- **Drive own key** (`make_short_app.drive_own_key`, `make_short_health`): `OWN_KEY` lock + `active` flag (pauses `drive_watch` and
  `extras_watch`), refuses on running backup (`backup_running`), open black window, running attempt. The secret is written by
  `HEALTH.conf_update` (in-process, atomic, 0600) — **never put it in argv**. `HEALTH.write_private` for any file holding config
  copies. State machine in `own_key_state` (none/same/done/interrupted/broken/unknown) — compares the whole `[gdrive]` section.
  `drive_reconnect` writes a per-attempt `drive_reconnect_<id>.done`; after rc 0 it retries `lsf` `RECONNECT_TRIES` times and never rolls
  back a connection whose token already changed. Black windows are started by `launch_black_window` (cmd.exe-safe path).
- **Fix-in-chat sandbox** (`make_short_fix._sandbox_cmd`): bubblewrap, empty tmpfs root; no bwrap → the script does not run (`NO_SANDBOX_MSG`).
  `shorts.sh doctor` has a check. The regex scan (`scan_script`) is advisory only.
- **Local API:** `MS.check_url` for every URL that reaches yt-dlp + `--` before it (the selftest walks the AST of
  `make_short.py`/`make_short_pick.py`/`auto_pipeline.py` and fails when a `"yt-dlp"` call has no `"--"`); body cap `MAX_BODY`,
  `b64_limited` per upload kind, `err_text` scrubs home paths, `same_origin_only()` for GETs that act. `make_short_update.diff_paths`
  returns the whole header line, `path_problem` rejects quotes/whitespace.
- **backup_extras.sh:** see its header (history in `_old/<date>`, `flock`, key scan of the memory `.md`, anchored leak check).
- **Tests:** `make_short_selftest_410.py` (called from `make_short_selftest.py`; `selftest.py units` runs only the small checks, no
  videos), `pipeline/tests/test_local_guard.py` (section 6), `pipeline/tests/test_fix_chat.py` (sections 5/5א). **Never upload a real PNG
  to `/api/upload_logo` in a test against a server started without a private `BRAND` dir — it writes into the owner's real
  `~/.config/yeshiva-shorts/brand/`** (happened once while building 4.1.0; the stray file was removed).
- Known and not part of this version: `test_fix_chat.py` section 4/8 "gold subtitle" pixel checks fail (they assume a karaoke style the
  fixture doesn't pin); they did not run at HEAD before 4.1.0 either.

### 8m. Version 4.3.0 — signed internet updates, one button, publish screen (19/11/2026)

**Pieces.** `make_short_release.py` (shared + receiver), `make_short_publish.py` (owner), glue in `make_short_app.py`
(`rel_*`, `/api/release/*`, `/api/publish/*`, `rel_watch`), page block "4.3" (button `#updBtn`, popover `#updPop`, `#relSet`, `#pubSet`),
`assets/release_source.json` (`{"base","pubkey"}` — empty until the owner approves a public repo), `shorts.sh` recovery block
(`# <UPDATE-RECOVER-BEGIN>`), `backup_extras.sh` (encrypted key only). Tests: `tests/test_release_update.py` (100 checks, in selftest
`units`/`quick`/`all`), `tests/e2e_update_app.py` (manual, real app as receiver vs a fake remote: check → apply → restart → rollback).

**Release format.** Public repo (a neutral name — never the owner's GitHub identity; `P.setup` refuses it) holds only
`latest.json` (`format`, `latest`, `releases:[{version,previous,must_not_skip,path}]`) and `releases/X.Y.Z/{manifest.json,manifest.sig,code-X.Y.Z.zip}`.
Manifest = sorted JSON: `format, version, date, previous, min_required, must_not_skip, notes[] (plain Hebrew), key_id,
archive{name,size,sha256}, files{path:{sha256,size,mode}}`. `manifest.sig` = base64 Ed25519 over the exact manifest bytes.
**Why Ed25519 + pure-Python verify:** the receivers' venv does not necessarily have `cryptography`; RFC-8032 verify is ~50 lines
(`ed25519_verify`, rejects small-order points, tested against `cryptography`). Signing (owner only) uses `cryptography`
(pinned in `requirements-pinned.txt`). Archive = `git archive HEAD` through `make_short_share.package_member` (same neutral
packaging: no CHANGELOG / personal guide, HANDOFF without §10), then the **same** `scan()` + `identity_scan(profile=False)`;
`assets/release_source.json` is NOT neutralised (a silent rewrite would break the URL) so an owner identity inside it blocks the build.
Receivers never get music/logo/settings — code only; settings/config/projects live outside the repo and are never touched.

**Private key.** `~/.config/yeshiva-shorts/release_key.enc` (mode 600): scrypt(n=2^15,r=8,p=1) → AES-GCM; the public key sits in
clear in the file. Passphrase (≥10 chars) typed in the window, held in RAM only during a publish. `backup_extras.sh` uploads ONLY
this file, and only if it parses as encrypted (`kdf=scrypt`, has `ct`, no `seed`); restore is `down_file`. Losing the passphrase =
a new key = every receiver needs a fresh package (nothing can fix that remotely) — said in the key-creation text.

**Receiver apply (git-based, why):** receivers are local git repos (package install). Each version = commit "עדכון לגרסה X" + tag
`rel-X`; keep the 3 newest tags (`KEEP_TAGS`). Chosen over snapshot dirs: rollback is `git reset --hard rel-prev`, no duplicate code
on disk, and the existing update box/selfcheck already live on git. Steps in `apply_release`: verify (sig → archive sha → each file sha
→ member set == manifest, safe paths, no secret-looking names, VERSION inside == manifest) → journal (`release_updates/pending.json` +
`pending.sha` = `base-sha\nrepo\npid`) → save local changes as `local_changes/<ts>_<from>_לפני_<to>.patch` (diff vs `rel-<installed>`, or HEAD
if untagged; colliding untracked files copied) → write `.name.ysnew` temp files then a tight `os.replace` loop → delete removed files →
`git add -f <files>`, `git rm --cached`, commit, tag → verify hashes + VERSION + light selfcheck (compile .py, parse .json, `bash -n`)
+ the app's `code_selfcheck` → verify again → clear journal. Any exception → `git reset --hard base`, remove added files, delete tag.
`SimulatedCrash` (env `MAKE_SHORT_UPDATE_CRASH_AT=before_rename|mid_rename|before_commit|after_commit`) is a BaseException so tests
can leave the journal. **Recovery** = `recover()` at app start (before anything) and the bash block at the top of `shorts.sh`
(runs before the half-written Python could even start); both only act on a journal whose pid is dead (or older than 20 min) —
🚨 found by the e2e test: the selfcheck's test server also starts `recover()` and used to revert the update in progress.
`run_updates`: ordered (smallest version > installed, `min_required` ≤ installed), stops after a `must_not_skip` release or a newer
manifest `format` (so the new code loads and checks the next step); a failed step leaves the earlier ones installed (each was good).
Manual rollback `rollback_previous`: reset to the previous `rel-` tag, delete the newer tag, add the version to `state.json.skip`
(not re-offered automatically; a newer one is).

**Modes** (`update_mode`): `owner` = `.git` + `origin` and no `.from_package` → informational only (label "🛠️ גרסת פיתוח"); `receiver` =
`.from_package` (or no origin); `none` = no git. Env `MAKE_SHORT_UPDATE_MODE` overrides (tests). Background check: 25 s after start, then
daily, silent on failure; not in test mode (`MAKE_SHORT_REL_WATCH=1` enables); `--skip-update` argument disables it for that run.
Apply/rollback need `server_idle()` (`RELS["applying"]` also blocks `start_job`/`code_watch`), explicit `confirm`, and the page flushes
its autosave first. After success: `restart_soon()` (execv — the existing launcher path); the page reloads on the new code hash and shows
"מה השתנה" from `state.json.just_updated` until `/api/release/seen`.

**Publish screen** (`Publisher`, thread; visible when the key or remote exists): preflight (key, remote, `release_source` has base and OUR
public key, notes present, tree clean, HEAD tagged `vX.Y.Z`, version > latest in the clone's `latest.json`, passphrase OK) → ⏸ confirm
"what will be published" → build + scans → selftest (`make_short_selftest.py units`; env `MAKE_SHORT_PUBLISH_SELFTEST` JSON cmd, `[]` skips) →
sign → push commit 1 (release dir only; clone in `~/.local/share/yeshiva-shorts/release_work/`, neutral git identity, `BatchMode` SSH, no
tokens) with cleanup marker `release_work/cleanup.json` written first → download back by commit-pinned raw URL (`base_for_ref`), verify sig +
bytes + archive → ⏸ final confirm → (no cancel from here) commit 2 = `latest.json` → push → read index back. Cancel/failure before the flip →
`undo_upload` (revert commit, no force-push); a crash leaves the marker → "🧹 נקה אותה". Setup after the owner approves a repo name:
`shorts.sh py make_short_publish.py setup <git@github.com:ORG/REPO.git> <https://raw.githubusercontent.com/ORG/REPO/main>` writes the
remote into `release.json` (config dir) and base + public key into `assets/release_source.json` → commit + tag → that version is the first
one receivers' packages can verify (so the key must exist BEFORE the package that ships it is built).

**4.3.1 additions.** *Progress:* `run_updates(progress=, cancel=)` emits `{stage: checking|downloading|verifying|applying, label, pct, done/total
bytes, step/steps, cancellable}`; `fetch(progress=)` reports per 256 KB chunk and may raise `UpdateCancelled`; `apply_release(prog=)` reports
5/35/55/70/80/97%. Cancel is honoured only before `apply_release` starts (last safe point) — the app's `/api/release/cancel` refuses otherwise.
App: `RELS["prog"]`, `rel_prog()`; page `updProg()` draws the popover while applying, the button shows "מוריד 45%". Error text always ends with
"חזרנו לגרסה X, הכול עובד." `RELS["applying"]` stays true until the exec restart (so the page never shows "idle" in between).
Publisher: `_step/_sub/_save` → `release_work/publish_state.json` on every change (`saved_state()` serves it after a refresh/restart; a saved
"running" becomes "נקטע"); `_push()` parses git's `--progress` stderr; verify download reports bytes. *Past lessons:* `past_clips()` now returns
`title` (via `CLEAN.clip_title` — state field, else the edit file's title field), `seconds`, `state` (draft/saved/uploaded/working); rows show only
the short's own title (never "lesson — short"). *Return to place:* `cleanDialog(items, all, {back})` calls `back()` on every close path (backdrop,
✕/"המשך ברקע", plan failure); `fillPast` passes `back()` = reopen `openPast(scrollTop)` with `PAST_SHUT` (collapsed lessons) kept in memory.
Tests: `test_release_update.py` 6ב + publisher-state + `clip_title`; selftest `past_ui_checks()` (static) — verified manually in the preview
(fake lessons, 800 px and 400 px).

**Top bar.** One row at 1280/1366/1920, both views, light/dark (measured in the preview: centre-Y spread 0 with every pill shown).
Moved: Modal meter → 🎙️ תמלול (both views — spend matters to anyone with their own Modal; alerts are banners and fire anywhere), 🔔/🔊 quick
toggles → 🔔 התראות (both views; same `ys_notif` settings as the checkboxes), `#muteBadge` 🔕 appears in the bar only while both are off.
All ids kept (feature manifest: additions only).

**Gotchas:** editing files over the `\\wsl.localhost` path resets the exec bit (`shorts.sh`) — `chmod +x` before committing;
never write the owner's GitHub name/user name literally in code or tests (build fails the identity scan).

### 8n. Version 4.4.0 — proposals / ideas / bugs to the manager over ntfy (19/11/2026)

Code: `pipeline/scripts/make_short_proposals.py` (stdlib only; core for BOTH sides), app glue in `make_short_app.py` (`prop_*`, routes
`/api/proposals/...`, `prop_watch` thread every 5 min), UI = `#propCard` (receiver, simple+advanced, tab 🖥️ מערכת) and `#propOwner`
(adv + `hidden` unless `PROP.owner_visible()` = signing key exists; every `/api/proposals/owner/*` route re-checks server-side).
Tests: `tests/test_proposals.py` (126 checks, fake server `tests/fake_ntfy.py`; test mode REFUSES any non-loopback server) wired into the selftest
as `proposals_checks`.

**ntfy facts (checked 19/11/2026, docs.ntfy.sh):** body ≤ 4096 bytes; server cache 12 h (ntfy.sh); attachments ≤ 15 MB but expire after 3 h →
NOT used; 60-request burst then 1/5 s; topics = letters/digits/`_`/`-` ≤ 64; JSON publish = POST to server root; poll = `GET /<t1,t2>/json?poll=1&since=`.

**Design:**
- *Channel* = two random topics (`inbox` carries the data, `alert` is what the owner's phone subscribes to; 192-bit each) + server + epoch.
  Owner master copy: `~/.config/yeshiva-shorts/proposals_owner.json` (600, never in the repo). `channel_file_bytes()` is injected into the SIGNED release
  archive (`build_release`) and into new share packages as `assets/proposals_channel.json` — NOT into the working tree (a dirty tree blocks self-update).
  No file ⇒ feature off ("עוד לא פעיל"). Receivers built before 4.4 cannot get it unless they self-update (needs 4.3+) — documented.
  Honest limit: the topic ships inside public code, so spam protection = quotas + filtering + rotation (`rotate()`: epoch+1, old inbox topics still polled).
- *Wire:* payload JSON (`v,pid,kind,sender_id,reply{topic,key},text,diag,patch,selftest,...`) → zlib → urlsafe-b64 → parts `YSP1 <pid> <i> <n> <digest16> <b64>` (≤3200 chars each,
  ≤64 000 total). Owner reassembles in `partials/`, verifies digest, decodes with a 600 KB decompression cap, re-validates every field (`validate_payload`).
- *Send:* `prepare()` builds a DRAFT (scrub: `HEALTH.scrub` + `CHAT.guard` + personal paths; patch refused if it contains a key) → preview text that includes every field
  → `confirm(draft, digest)` re-hashes the draft file; only then queued + sent. Alert (phone) only on the first successful send. Outbox `data/proposals/outbox/<pid>.json`.
- *Gaps:* sender re-sends parts every 12 h (max 12×) while status is only "sent"; owner answers a duplicate by re-publishing the current status. Owner `fetch_inbox` uses `since=<last time>`
  + a seen-id list; first run `since=all`.
- *Replies (4.4; replaced by signed YSR2 in 8p):* `YSR1 <pid> <hmac16..> <b64 {status,text,ts}>` on the proposal's own reply topic; HMAC-SHA256 with the proposal's reply key. Status rank never goes down; ts must increase and not be >1 day ahead.
- *Owner actions:* accept (collected in the "next release" list — it does NOT publish), reject (+text), reply, handled. Patch check: `check_patch` → temp `git archive` of the sender's version tag (`vX` / `rel-X`) → bwrap
  (`--unshare-all`, tmpfs home, no config) → `git apply` + `selftest units`. A patch with problems (`validate_patch`) is never run. Risk words (socket, subprocess, config.env…) are only highlighted.
- *First real send:* nothing real is created by the code. The owner must (1) click "🔔 צור ערוץ התראות" (local only), (2) subscribe his phone to the shown alert topic, (3) press "שלח התראת בדיקה" (first
  real network call to ntfy.sh), (4) publish a release (or build a package) that carries the channel.
- Not built (owed / ideas): QR code for the phone subscription (text + `ntfy://` link shown instead), 4.5 re-applying personal patches after official updates, a self-hosted ntfy walkthrough
  (the server URL is already a field in `proposals.json`: `server`).
### 8o. Personal changes survive official updates (4.5.0)
Module `pipeline/scripts/make_short_personal.py` (imported as `PERS` in the app; `R`=release module). Receiver installs only (`update_mode()=="receiver"`; owner tree excluded).
- *Registry:* `~/.local/share/yeshiva-shorts/local_changes/registry.json` (+ `personal/<pc-NNNN>/{orig,change}.patch`, optional `untracked/`). Same folder as 4.3's `*.patch` backups (kept; names listed in `seen`).
  States: applied · conflict · incompatible · waiting · disabled · archived · absorbed. `OFF_STATES` = not re-applied. Each change also has `refs/personal/<id>` → its commit in the local repo (parent = the state before it) so
  `git cherry-pick --no-commit` does a real 3-way merge; legacy/manual changes (no ref) fall back to `git apply --3way --index`.
- *Hooks:* update box (`make_short_update.py`): `before_box` (ensures `rel-X` base tag), `after_box` (register; `[מיזוג pc-N]` in the description archives the replaced change), `after_undo` (→ disabled).
  `R.save_local_changes` → `capture_manual` (uncommitted hand edits → "manual" change) + `note_backup_file`; `R.run_updates` → `PC.reapply` once after the last applied version (stage `personal`, label "… (2 מתוך 3)"),
  result in `res["personal"]` → `just_updated.personal` shown by the page; `R.rollback_previous` → reapply on the older version; `R.recover` also runs `PC.recover`.
- *Engine:* `_rebuild(repo, mutate, check_fn, kind)` = reset to the official commit (`rel-<installed>`), stack all enabled changes in `seq` order, verify (compile light check + `default_check` = selfcheck + `selftest quick`);
  on failure re-stack one by one to blame only the culprit (→ incompatible). Registry saved only at the end; `reapply_pending.json` journal (`head_before`, `stamp`; `registry.last_done==stamp` ⇒ already complete).
  Toggle/give-up/restore use the same function and refuse on a dirty tree. NEVER raises into the official update (`reapply` catches; failure → entries `waiting`, retried by `pc_watch` at app start when idle).
- *UI/API:* card `#pcSet` in the system tab (visible in simple view only when ≥1 change), GET `/api/personal/status`, POST `/api/personal/{enable,giveup,restore,retry,rename,block,patch,dismiss}`;
  `rel_status().personal` brief; 🧩 on `#updBtn` when attention; ops guarded by `pc_begin` (idle only, `PCS["busy"]` counted in `server_idle`). Proposals: `personal_id` in `/api/proposals/prepare`.
- *Tests:* `tests/test_personal.py` (engine), `tests/test_personal_app.py` (real server on a clone). Pitfall: two changes touching adjacent lines conflict by design — keep test edits apart.

### 8p. 4.5.61 — fixes for the external review of 4.3–4.5 (23/11/2026)

Three independent reviewers; every finding fixed and tested (CHANGELOG 4.5.61 has the A/B/C list + weights). What changed for the next assistant:

- **Proposals wire v2 (`make_short_proposals.py`).** `YSP2 <pid> <i> <n> <digest16> <b64>`, b64 = `seal(zlib(json))`: ephemeral X25519 →
  HKDF-SHA256(salt = eph_pub‖owner_pub, info "yeshiva-shorts proposal seal v2") → ChaCha20-Poly1305 (AAD "YSP2"). Only the owner decrypts
  (`decode()` needs `_owner_keys()`). Payload `reply` = `{topic}` only (no key). Replies `YSR2 <pid> <ed25519 sig b64url> <b64 {pid,topic,status,text,ts}>`,
  signed over `"YSR2|<pid>|<body_b64>"` with the owner's Ed25519 key, verified with `REL.ed25519_verify` against `rec.sign_pubs` (stored at send time)
  + the current channel's `sign_pub`. Owner private keys: `~/.config/yeshiva-shorts/proposals_owner.key` (`{"x25519","ed25519"}` raw b64url, 0600 from creation,
  never in the repo/packages — name matches the release FORBIDDEN `*.key`). Channel file v2 = `v,server,inbox,alert,epoch,enc_pub,sign_pub`; a 4.4 channel
  gets the keys in `channel_file_bytes()`. `load_channel()` returns None (feature off) without both public keys. Senders need `cryptography` (pinned).
  YSP1/YSR1 are dropped (never published).
- **Inbox paging:** `poll_page()` reads NDJSON line by line within `CAPS["resp"]`, returns `(events, more)`; `fetch_inbox` loops ≤ `CAPS["pages"]` pages
  with `since=<last message id>` and saves the cursor after every page (`res["more"]` = still behind). Opener refuses redirects (`_NoRedirect`).
- **Quotas:** only the total cap (`OWNER_TOTAL_DAY` valid decrypted proposals / 24 h); the per-sender cap is gone (sender_id is attacker-chosen).
  Duplicate part 1 of a known pid → re-publish status at most every `REPUBLISH_EVERY` (6 h, `meta.republished_at`). Drops counted in
  `proposals_owner.json` `drops{day,quota,invalid}` → `owner_status().drops` → shown in the owner inbox. Sender quota from `sent_log.json` (forget() keeps it).
- **Patch check:** one bwrap run: tree read-only at `/src/tree`, copied into a size-capped tmpfs `/work`; `git apply --check`/`apply` (exit 91/92);
  then the CHECK MACHINERY (`make_short_personal.CHECK_MACHINERY`: selftest(s), update.py, guard.py, `pipeline/tests/`) is copied back from the base
  version (`/src/pristine`) before `make_short_selftest.py` runs. rlimits via `preexec_fn` (AS 3 GB, FSIZE 256 MB, CPU, NPROC = user procs + 256, CORE 0);
  `--size` caps on /tmp, $HOME, /work when bwrap ≥ 0.10; output to a temp file, last 1500 chars kept. Result always `untrusted: True` + "לא מחייבת".
- **Privacy:** `privacy()` also hides Windows user names (`/mnt/c/Users/*`, `%USERNAME%`, test override `MAKE_SHORT_WIN_USERS`) and runs on name, patch,
  selftest text. Phone alert text has links replaced by "[קישור]"; owner card shows `push_warning`.
- **Owner-only routes** raise `OwnerOnly` → HTTP 403 (was 400).
- **Updater (`make_short_release.py`):** `proc_ident()` = `<boot_id>:<start time>`; journals (`pending.json`, `pending.sha` line 4, PC `reapply_pending.json`)
  store it; `owner_alive()` compares it (old journals: old pid+20 min rule). `hard_reset()` = unlock stale `index.lock` (no live git on THIS tree) →
  reset → `read-tree --reset -u` → move a broken index aside + `read-tree` + `checkout-index -a -f` + `update-ref`; failure = `UpdateError`, journal kept,
  shown in the page (`recovered` + `rec_fail`). Same logic in the bash block of `shorts.sh` (`_ys_unlock`, `_ys_reset`; failure → `release_updates/recover_failed`).
  Rollback journal (`kind: rollback`) never deletes a tag. `effective_skip()`: a skipped version stays skipped only while it is the newest;
  `check()` returns `skip`/`skip_note`, `run_updates` saves them; non-offline auto-check errors → `RELS.auto_err` → page flash.
- **Trial start (B7):** after an update the app writes `release_updates/trial` (`versions`, pre-update commit, repo, count 0) before `execv`; the app
  deletes it after 30 s alive. `shorts.sh py make_short_app.py` (the launcher) counts starts while it exists: 1 → adds `--skip-update`
  (page: "↩ חזור לגרסה הקודמת"); 2 → resets to the pre-update commit, deletes the new `rel-` tags, writes `trial_failed`; `REL.startup_notes()` turns that
  into a page message + skip entry. A second click while THIS install's app runs is not counted.
- **Personal changes:** `register_manual()` (box apply/undo, installer `register-manual`, and — tracked files only — every `_rebuild`) commits hand edits
  as an "applied" manual change; `snapshot()` is `git add -u`; the box commits only its own paths. `_register_unaccounted()` turns any commit in
  `rel-X..HEAD` that no change explains (not a change commit/ref, not empty, not a revert of a known commit) into a waiting change with a ref
  (in `_rebuild` and `capture_manual`). `load()` of a corrupt registry → backup `registry.bad-<hash>.json` + `_corrupt` → every save refuses;
  new ids are above every `personal/pc-*` dir. `_stack`: when the stacked check fails, the official base is checked alone first (fails → all
  `waiting`, reason "בעיה בסביבה"). `startup_consistency()` (first loop of `pc_watch`): missing `rel-X` → tag a clean HEAD; "applied" whose commit is not
  between the base and HEAD → waiting. `default_check` uses `pristine_checks` (temp copy with official check files) when the changes touch them.
  Absorbed changes are re-stacked on update/rollback/retry; failed update/rollback re-apply marks every enabled change waiting.

**Remaining known risks (honest):**
- The ntfy topics are still public (they ship in public releases): anyone can SPAM the inbox and the owner's phone (quota + rotation only); they can no
  longer read proposals or forge replies. Push notifications are unauthenticated — never tap links/actions in them.
- A malicious sender still knows the owner's public key and can send well-formed encrypted junk up to the daily cap (counted, shown).
- Losing `proposals_owner.key` = proposals in flight cannot be read; a new channel + key must ship in a release. Back it up like `release_key.enc`.
- The patch check runs untrusted code in bubblewrap with limits; a patched module imported by the pristine selftest can still influence its own
  result — that is why the result is labelled untrusted and the owner reads the diff.
- `default_check` and the box checks are not a security boundary either (a change can alter code the checks import).
- `ntfy since=<id>` with an expired id returns everything cached (the seen-id list dedupes) — verified only against the fake server.
- Nothing is public yet: no public repo, no signing key, `assets/release_source.json` empty, no channel created. All of the above was tested only locally.

### 8q. 4.5.106 — fixes for the whole-system check and the non-programmer guides audit (24/11/2026)

Two read-only reports on 4.5.61; every finding verified in code, fixed or recorded (CHANGELOG 4.5.106 has the list, weights and what is unverified). What changed for the next assistant:

- **Selftest on a receiver install.** `.from_package` in the repo root = receiver tree: `test_personal_app.py` uses `git tag -f`; `test_proposals.py` skips the identity-string scan (the test file itself is neutralized, `<user>`); `make_short_selftest_410.all_checks` skips the owner-tree share-package group. `make_short_selftest.package()` now runs `selftest units` INSIDE the temporary receiver install — keep it, it is the only thing that catches "works on the owner tree, fails at the receiver".
- **Trial marker (`release_updates/trial`) has 5 lines:** versions, pre-update commit, repo, count, **official commit** of the pre-update version (`REL.official_commit()`, taken in `rel_apply_run` before `run_updates` because a 3-version update prunes that tag). `shorts.sh` on the 2nd failed start resets to the pre-update commit, deletes the new `rel-*` tags and puts `rel-<VERSION at that commit>` back on line 5. A trial whose version list does not contain the current `VERSION` is stale (package installed over it) → deleted, never reverts. The installer deletes `trial*`/`pending.*`/`recover_failed`. `run_updates(on_installed=…)` writes trial + `just_updated` BEFORE the personal re-apply.
- **`shorts.sh` recovery** (`pending.sha`) also removes the half-applied update's `rel-<target>` tag (not for `kind: rollback`) and `.*.ysnew` files; `2>/dev/null` goes BEFORE `< file` redirects (otherwise `/proc/N/cmdline` noise).
- **Personal changes (`make_short_personal.py`):** `QUIET_GIT` (no `advice.*` hints), `_reason()` (Hebrew, never raw git text), `_failed()` = after a failed merge: `_already_included()` (hunk added-lines contiguous in the file + significant lines ≥ `MIN_SIGNIF`=20 chars; short lines prove nothing) → `absorbed`; else conflict with "built on top of «X»" when an earlier change touching the same files is off/failed. `startup_consistency`: no HEAD tagging when HEAD itself is a personal commit — `_infer_official()` walks first-parent down to the official commit (VERSION must equal the installed one); `conflict/waiting/incompatible` whose commit is between base and HEAD → `applied`. Known limit (git): a real conflict in adjacent lines stays a conflict.
- **App:** `code_tree_ready()` — receiver: no tag needed, only not `PCS.busy`/`RELS.applying` (owner tree keeps the 4.1.3 gate). `pc_begin` refuses when `external_pipeline_running()`. Enable/disable messages say the app restarts itself when idle (`PC_RESTART_NOTE`). Proposals from a personal change: `app_version = base_version of that change` (`PERS.proposal_base_version`), no general selftest text.
- **Owner key backup:** `PROP.backup_encrypt(passphrase)` → `~/.config/yeshiva-shorts/proposals_owner.enc` (`{v,kind,kdf:scrypt,n,r,p,salt,nonce,ct,made,src}`, AES-GCM, AAD `yeshiva-shorts-proposals-owner-v1`; plaintext = `{key, owner}` = `proposals_owner.key` + `.json`); `backup_restore` (never overwrites), `backup_status` (`stale` when the key file hash changed). `/api/proposals/owner/backup`; card `#propBackup` in the owner screen; `backup_extras.sh` uploads ONLY the `.enc` (refuses one that looks unencrypted: has `x25519`/`key`/…) + `release.json`, restores both. When the planned encrypted vault is built this file becomes one of its items (same password/template).
- **Page:** `relJust(j, pre)` shows the "recovered" note together with "what changed" (+ rollback button for receivers with a previous version; `relRollback` also writes into the popup because `#relSet` is hidden in the simple view).
- **Guides (`make_short_health.py`, page cards, installer, readme):** `COOKIE_STEPS` (store link, incognito, look-alike warning…), `COOKIE_REJECT_NOTE`, `BOT_NOTE`; `job_alert("cookies")` splits "not a bot" from login-required; Drive own-key steps use Google Sites for the home page (unverified) + Test-users plan B; package installer no longer connects Drive (shared rclone key retiring) and offers an explicit Modal skip. **Unverified (needs the owner's login / a real Windows run):** Hebrew labels in Google Cloud/Chrome, Google accepting a Sites URL as home page, the changed installer lines on a real Windows PowerShell (syntax-parsed only).

### 8r. 4.6.0 — encrypted vault + restore program for a new PC (24/11/2026)

His decisions (final): non-secret data stays in the plain Drive backup (restorable with no password); the five secrets go into ONE
password-encrypted file; the password is typed in the window and never stored (he keeps it in Google Keep + on paper); no server of any kind.

- **Vault** `pipeline/scripts/make_short_vault.py`, file `~/.config/yeshiva-shorts/vault.enc` (0600). Format `{v:1, kind:"yeshiva-shorts-vault",
  kdf:"scrypt", n:2^17, r:8, p:1, salt, nonce, made, items:[ids], ct}`; AES-GCM with AAD = `yeshiva-shorts-vault-v1|` + canonical JSON of the
  header minus `ct` (changing `items`/`made`/`n` → does not open). Plaintext `{items:{id:{...}}, made}`. Items (`ITEMS`): `signing`
  (`release_key.enc` as-is — still also protected by the signing password), `proposals` (`proposals_owner.key` + `.json` = ntfy topics/inbox/alert),
  `gemini` (`GEMINI_API_KEY` from config.env), `modal` (the toml at `MODAL_CONFIG_PATH`/`~/.modal.toml`, or `MODAL_TOKEN_ID/SECRET` env pair),
  `drive_client` (rclone `[gdrive]` `client_id` + `client_secret`, **not** the token). Opt-in per item (checkboxes; default = all present).
  `create()` writes a 0600 temp file, re-decrypts it and compares, then `os.replace` (crash points `half_written`/`before_replace` in tests);
  leftover `vault.enc.tmp*` cleaned on the next create. `DATA/vault_state.json` = HMAC fingerprints with a random local salt → "something changed
  since" (`status().stale/new`) without storing secrets or plain hashes. `restore()` puts each item back with 0600, never overwrites a different
  existing value unless `overwrite` (then keeps `<file>.before-vault-<ts>`), re-wires Modal to WSL `~/.modal.toml` + `MODAL_CONFIG_PATH` (+ `SHORTS_ASR=modal`
  if it was local), writes a `[gdrive]` section (type drive, scope drive, client id/secret) when there is none, and checks each piece only locally
  (key file parses + key_id, toml has token fields, …). Reports never contain values. CLI `restore --file X` reads the password with `getpass`
  (3 tries; empty = skip, exit 3). `VaultError` is a `ValueError` (the app maps it to 400).
- **Why the Drive client id/secret is inside (my call):** they are not a login (useless without his browser consent), but without them a new PC
  means redoing the whole Google Cloud own-key guide (15 min of English screens). With them: one browser click. Residual risk (someone imitating
  his OAuth app in a consent screen) is small and covered by the vault encryption anyway.
- **Owner-only UI:** settings card `#vaultSet` (class `set adv`, hidden unless `REL.vault_visible`) — explanation (what is inside, what it protects
  from and NOT from (account takeover: password in Keep of the same account), password loss = new signing key + one reinstall per receiver, leaked
  signing key hurts receivers), items checkboxes, password ×2 → "🔐 גבה לכספת", "🔓 שחזר מהכספת" (Drive copy if Drive is on, else local),
  "☁️ עדכן את תיקיית השחזור". `/api/vault/{status,create,restore,kit}` → `vault_api`; `vault_visible()` = owner tree (`update_mode=="owner"`) OR signing
  key OR a local `vault.enc` (a PC he restored to); others get 403 (`OwnerOnly`). 🩺 `HEALTH.EXTRA["vault"]`: warn only when a signing key exists and
  there is no vault; non-owners get no line (`run_all` skips `None`). 🧭 card `data-fs="vault"` for the owner.
- **Restore folder ("kit")** `DATA/restore_kit/` → Drive `גיבוי תוכנה/שחזור למחשב חדש` (`backup_extras.sh kit`, also inside the daily `backup`; `rclone sync`
  with `_old/<date>` history; refuses a `vault.enc` with unknown header fields). Contents: `kit/code-<ver>.zip` + `manifest.json` (+ `manifest.sig`),
  `kit/kit.json` (`version, head, signed, pub, key_id, manifest_sha256`), `restore_kit.py`, `restore.ps1`, `שחזור למחשב חדש.bat`, `קרא אותי - שחזור.txt`,
  `vault.enc`. `build_kit()`: if `release_work/releases/<VERSION>` holds a published release whose signature verifies (trusted keys from
  `release_source.json`/the signing key's pub) → copied = **signed kit**; otherwise the same packing via `build_release(key=None, include_channel=False)`
  = **unsigned kit** (integrity only; said so on screen). Rebuilt only when VERSION/HEAD/signed-state change. So: publishing a release → the next daily
  backup ships a signed kit.
- **New-PC flow** (`windows/restore/`): `restore.bat.txt` (ASCII; refuses to run from inside the zip) → `restore.ps1` = template + the
  `# <SHARED-WSL-A/B-BEGIN>` blocks cut from `install_windows.ps1` (same WSL/Ubuntu/user code, no drifting copy) → `python3 -I restore_kit.py verify`
  (stdlib only; Ed25519 block is a byte-identical copy of `make_short_release`'s — a test enforces it; checks manifest hash, archive hash/size, every
  file hash, no extra files/unsafe paths, signature + that the signing key is one the code itself trusts) → `stage` into `%LOCALAPPDATA%\yeshiva-shorts-restore\pkg`
  (package layout) → `install_windows.ps1 -Restore -SkipDrive -SkipModal` (package mode without receiver extras/receiver-init/final check) →
  vault (`Wsl-Tty`, so getpass has a real console) → `drive-state` / `drive-login` (`rclone config reconnect gdrive:` with the browser shim) →
  `backup_extras.sh restore` → optional `rclone copy "gdrive:שורטסים מוכנים"` (if he says no, `drive_on=false` so the mirror cannot delete Drive
  shorts) → `newpc.py` → "what is left" list (also `yeshiva-shorts\מה נשאר אחרי השחזור.txt`). Re-runnable: `compare` skips the install when the
  same/newer version is installed. Chicken-and-egg avoided: he downloads the folder with a normal browser (Drive login), the vault inside gives the
  Drive client id, one browser click connects rclone.
- **Trust boundary (say it plainly):** everything comes from the same Drive folder. The signature proves "exactly a published release" and catches
  corruption/partial swaps; it does not help against someone who controls his Google account (they could replace kit.json+pub too). The real anchor
  later = the public releases repo key embedded in installed code. The trust model stays extensible: `restore_kit.verify` accepts any key in the
  code's `release_source.json` list, so a second (emergency) signing key — proposed, NOT decided — can be added later via a signed update.
- **New PC = receiver update mode** (`.from_package`), owner screens via the restored signing key / local vault. The private GitHub repo (SSH) is
  NOT restored (programmer-only).
- **Tests:** `pipeline/tests/test_vault.py` (~140 checks, ~30 s; in `selftest all/quick`, not `units`): round trip, wrong password, tamper
  (ct/items/made/n/truncated), interrupted writes, 0600, no secret in vault/state/report/CLI/logs/kit/fake Drive/installed code, `*.enc` blocked
  (packages, personal changes, git), kit unsigned + signed + forgeries, stage/compare, end-to-end old PC → `backup_extras.sh backup` to a fake Drive
  folder → verify/stage → the installer's real package-mode bash block → vault restore with the installed code → `backup_extras.sh restore` → owner
  screens visible; app probe (403, health, create/restore through `vault_api`). **Unverified:** a real run of `restore.ps1` past step 3 on a fresh
  Windows PC (WSL install, reboot, `install_windows.ps1 -Restore`, getpass through `wsl.exe`), Google's consent/`rclone config reconnect` questions
  for a section without a token, Drive's folder-download zip naming. Steps 0–3 were run for real on this PC (WSL already present → verify →
  "already installed"); both .ps1 files parse in Windows PowerShell 5.1.

### 8s. 4.7.0 — settings tab "🔄 עדכונים וגיבויים" (24/11/2026)

Owner: "the settings screen is crowded, I can't follow". HTML-only move in `make_short_page.html`: the one long card inside `data-sec="system"`
(share / send-to-manager / updates / vault / personal changes / proposals inbox / publish / update box) became **four `.card data-sec="updates"`**:
`🔄 עדכוני תוכנה` (adv: relSet, updSet incl. chatCard) · `📨 שינויים אישיים והצעות` (propCard, pcSet, propOwner) · `📦 שיתוף ופרסום` (adv: shareSet,
pubSet) · `☁️ גיבוי וכספת` (drive_on set — moved from the removed `backup` tab — and vaultSet). New entry in `SECS` after `system`; `showSec` falls
back to `system` for an unknown saved tab (old `ys_setsec=backup`); `pcOpen` and the owner-mode update popup call `showSec("updates")`.
No id/`data-k` removed or renamed; `SIMPLE_KEYS`/`ADV_KEYS` unchanged (drive_on stays simple). Simple view shows only propCard, pcSet (when it has
changes) and the Drive switch; owner cards keep `class="set adv" … hidden`.

### 8t. 4.7.13 — first-public-release preparation (25/11/2026; nothing published)

- **`assets/release_source.json` is now real**: `{"base": "https://raw.githubusercontent.com/<owner-account>/shorts-tool-releases/main",
  "pubkey": <44-char Ed25519 public key of the owner's signing key>, "account_approved": true}`. Written by
  `shorts.sh py make_short_publish.py setup <git@github.com:ACC/REPO.git> <base> --allow-owner-account` (the public key is read from the clear
  `pub` field of `release_key.enc` — **no passphrase needed**, the private key is never touched; the CLI form does not write `release.json`).
  **This version is the first whose packages can verify updates; packages built earlier (empty base/pubkey) cannot self-update.**
- **Owner decision (25/11): the public repo lives in his own GitHub account.** `setup()` still refuses an owner identity in the address unless
  `allow_account=True` AND the address has exactly the shape `raw.githubusercontent.com/<acc>/<repo>/main` + SSH `git@github.com:<acc>/<repo>.git`
  AND the repo name is neutral. It then writes the flag `account_approved`. `SH.identity_scan` calls `_scrub_release_source` for
  `assets/release_source.json` ONLY: it removes the base string when the flag is set and the pattern matches (otherwise the file is scanned like any
  other, and a missing flag blocks as before — tested). The account name in any other file still blocks the build/share package.
- **Publish remote is derived from the code** (`P.derived_remote(base)`, `P.effective_remote()` = manual `release.json` remote, else derived) —
  screen status and preflight use it; no separate "save address" step. `suggested_baseline()` pre-fills the first-publish "מגרסה" field with the previous tag.
- **Dry run**: `pipeline/tests/dry_run_first_publish.py <report.md> [repo]` (venv python; manual, not in selftest). Isolated temp HOME/config; clone of HEAD;
  local repo with `receive.denyCurrentBranch=updateInstead` as fake "GitHub + raw"; TEST key; fake ntfy + channel; runs preflight → plan confirm → build +
  scans → sign → upload → download-back verify → final confirm → `latest.json`; then a 2nd fake release (ordered chain), a 3rd cancelled at the final
  confirm (revert, `latest.json` untouched), and a receiver at the previous tag doing the signed ordered update. Writes a plain-Hebrew report of exactly
  what would be public. Checks the report itself against the identity needles. The owner copy lives in `yeshiva-shorts\בדיקות\מה יתפרסם בפעם הראשונה.md`.
- **First-publish gating (unchanged, verified in the dry run):** two in-window confirmations (`plan`, `final`), cancel until the flip, nothing runs without
  «📤 התחל פרסום» + passphrase typed in the window; the standing rule is also his explicit OK in chat first. The vault exists (`vault.enc` local + in the Drive
  restore folder), so the "back up before the first publish" reminder is satisfied.
- **Known, shown to the owner:** the yeshiva's name is mentioned incidentally (code comments, HANDOFF, test fixtures) in ~9 files of the archive — no links,
  logo or guidelines. Decision left to him (remove before publish = small safe change).

## 9. Debugging recipe for an assistant

1. In the page press **"📋 העתק פרטים לעוזר"** (or "+ מדריך מלא") — it copies repo URL, version, package
   versions, health check, last failed job log and the app log, secrets scrubbed.
2. `~/yeshiva-shorts-skill/shorts.sh doctor` and `git -C ~/yeshiva-shorts-skill log --oneline -10`.
3. Reproduce in test mode (§2). Read the module docstrings: each `make_short_*.py` starts with *why* it exists.
4. Fix, commit with a *why* message, push. Tell the owner in Hebrew what changed and what he should click.
5. Update this file if you learn a new rule or failure mode.

## 11. External tools: reuse what the user already has, and what runs where (21/10/2026)

**Why:** someone who receives the tool may already own ffmpeg / yt-dlp / Deno; the tool must not force a second
copy, but must not trust a bad one either (Debian's apt ffmpeg 5.1 *fails the filtergraph*: no vidstab/libass).

`pipeline/scripts/tool_finder.py` (stdlib only; also `shorts.sh tools`):
- **Finds** candidates per tool: our private copy (`~/.local/share/yeshiva-shorts/{bin,venv,deno}`), the env var
  (`FFMPEG`/`FFPROBE`), PATH, and known dirs (`/usr/bin /usr/local/bin /opt/homebrew/bin /snap/bin ~/.local/bin ~/bin`,
  Linuxbrew). **Validates** each by running it: ffmpeg must have `libass` + `libx264` (else ❌) and
  `vidstabdetect/vidstabtransform/xfade/overlay` (else ⚠️ stabilisation/transitions break); yt-dlp must print a version
  (⚠️ if > 90 days old); Deno must run (Node = ⚠️, yt-dlp enables only Deno by default).
- **Choice per tool** (page: הגדרות מתקדמות ← 🧰 כלים במחשב; CLI: `shorts.sh tools set <ffmpeg|ffprobe|ytdlp|deno|asr> <auto|builtin|system|custom> [path]`).
  Modes: `auto` (default — **exactly the old behaviour**: our private copy first, else the first valid one found),
  `builtin`, `system` (first valid from PATH/known dirs), `custom` (a path; it is probed before it is saved —
  a tool that cannot run, or lacks libass, is refused with a Hebrew message). Nothing is ever deleted or replaced.
- **Storage:** `~/.config/yeshiva-shorts/tools.json` (the choice). `apply_prefs()` renders it to `tools.env`
  (`FFMPEG`, `FFPROBE`, `SHORTS_YTDLP`, `SHORTS_DENO`), which `shorts.sh` sources right after `config.env`.
  **No choice ⇒ no `tools.env` ⇒ `shorts.sh` is unchanged.** `shorts.sh yt-dlp` runs `$SHORTS_YTDLP` if set,
  else `venv python -m yt_dlp`; a chosen Deno/Node is symlinked into `~/.local/share/yeshiva-shorts/jsrt` and put first on PATH.
  The running app re-reads FFMPEG/FFPROBE after a change (`tool_finder.reload_env`); yt-dlp/Deno are re-read per call by the gate.
- **ASR engine** (`modal` | `local`) is the existing `SHORTS_ASR` in `config.env` (only the value is written; the
  file is never printed). The screen shows whether Modal (module + token) and faster-whisper (+ GPU?) are usable.
- **Page API:** `GET /api/tools` (scan), `POST /api/tools/set {tool, mode, path}`. `shorts.sh doctor` prints the
  OS/runtime check, the chosen source+version of every tool, and ASR engines.
- `install.sh` now reuses any ffmpeg that is *usable* (vidstab **and** libass) from `$FFMPEG`/PATH/known dirs and
  any existing Deno (private, `~/.deno`, PATH); it downloads only when nothing usable exists. It still installs
  yt-dlp into the private venv (cheap; the health check and the default path use it).

**Where it can run (investigated 21/10):**

| OS | Status | Notes |
|---|---|---|
| Windows 11 + **WSL Ubuntu** | ✅ the tested way | launcher `.bat`, `windows/התקנה.bat` |
| **Linux** (native) | ✅ expected to work, **not tested** | everything is bash + python + `fcntl`; only the "open from Windows" step is irrelevant. Run `install.sh`, then `shorts.sh py make_short_app.py` and open http://localhost:8790. Only the page's "reconnect Drive" button (`drive_reconnect()` in `make_short_app.py`) opens a Windows console via `/mnt/c/Windows/System32/cmd.exe` — WSL-only; elsewhere run `rclone config reconnect gdrive:` by hand |
| **macOS** | ⚠️ expected, **not tested** | `install.sh` has no static ffmpeg for Darwin: needs `brew` ffmpeg **with libvidstab and libass** (tool_finder will say if it lacks them — without them stabilisation is lost, without libass there are no subtitles) |
| **Windows without WSL** | ❌ not supported | blockers: `shorts.sh` and all launchers are bash; `fcntl.flock` (heavy-build lock in `make_short.py`, `make_short_pick.py`) does not exist; venv layout (`Scripts\python.exe`) and paths (`~/.local/share`, `/mnt/c`) are POSIX-assumed. A port = replace the gate with a Python launcher, `msvcrt.locking` for the lock, and Windows binary names. Not started: too large for "reuse what exists". Git-for-Windows bash alone is *not* enough (fcntl). |

`doctor` / the page's "🧰" card report this per machine (`tool_finder.runtime()`): `ok` needs bash **and** `fcntl`.

Tested 21/10 on the owner's PC (WSL): scan, `set` with bad path (refused), custom ffmpeg (tools.env written, `shorts.sh ffmpeg`
used it), `auto` (tools.env removed), ASR switch, page card renders in the test app, doctor green. **Not tested:** a machine
with a *different* valid system ffmpeg/yt-dlp (none here besides our own), Linux-native, macOS.