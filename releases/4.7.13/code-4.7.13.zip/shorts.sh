#!/usr/bin/env bash
# shorts.sh — the single entry point to the shorts pipeline.
#
# Why a gate and not direct invocation: ffmpeg may live in a private
# prefix (no sudo needed), python is a venv, yt-dlp needs Deno on PATH,
# and the API keys live in a config file outside this repo. Shell rc
# files are NOT sourced by cron/nohup, so anything that relies on PATH
# "just being there" breaks silently. This file assembles the
# environment on every call.
#
#   shorts.sh setup                       first-run wizard (keys, folders)
#   shorts.sh doctor                      end-to-end environment check
#   shorts.sh new <slug>                  new project folder (prints the path)
#   shorts.sh py <script> [args...]       run a pipeline script
#   shorts.sh export <project> [args]     export finished clips to your folder
#   shorts.sh ffmpeg|ffprobe|yt-dlp ...   the tools themselves
#   shorts.sh tools [set <tool> <mode> [path]]  find/choose ffmpeg, yt-dlp, deno, ASR
#   shorts.sh env                         what is configured (never prints secrets)
#   shorts.sh where                       print the resolved paths
set -euo pipefail

# --- where am I -------------------------------------------------------------
SELF="${BASH_SOURCE[0]}"
while [ -L "$SELF" ]; do
  d="$(cd -P "$(dirname "$SELF")" && pwd)"; SELF="$(readlink "$SELF")"
  [[ $SELF != /* ]] && SELF="$d/$SELF"
done
SKILL_HOME="$(cd -P "$(dirname "$SELF")" && pwd)"

# --- user-owned locations (never inside the repo) ---------------------------
CONFIG_DIR="${SHORTS_CONFIG_DIR:-${XDG_CONFIG_HOME:-$HOME/.config}/yeshiva-shorts}"
DATA_DIR="${SHORTS_DATA_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/yeshiva-shorts}"
VENV="$DATA_DIR/venv"
PRIVBIN="$DATA_DIR/bin"

# <UPDATE-RECOVER-BEGIN>
# 4.3: an internet update that was cut in the middle (power loss, kill) leaves release_updates/pending.sha = "<last good commit>\n<repo path>".
# Go back to that commit BEFORE anything else runs — the half-written code may not even start. Only for THIS checkout; never fatal.
_J="$DATA_DIR/release_updates/pending.sha"
_ys_unlock() {   # 4.5.x: .git/index.lock left by a git that died mid-commit; never while a git works on THIS tree
  local lk="$SKILL_HOME/.git/index.lock" d cwd
  [ -f "$lk" ] || return 0
  for d in /proc/[0-9]*; do
    [ "$(cat "$d/comm" 2>/dev/null)" = "git" ] || continue
    cwd="$(readlink "$d/cwd" 2>/dev/null || true)"
    case "$cwd" in "$SKILL_HOME"|"$SKILL_HOME"/*) return 0 ;; esac
    if tr '\0' ' ' 2>/dev/null < "$d/cmdline" | grep -qF "$SKILL_HOME"; then return 0; fi
  done
  rm -f "$lk"
}
_ys_reset() {    # $1 = commit. reset --hard, or rebuild index + files from that commit when the index is broken
  _ys_unlock
  if git -C "$SKILL_HOME" reset --hard -q "$1" >/dev/null 2>&1; then return 0; fi
  _ys_unlock
  if git -C "$SKILL_HOME" read-tree --reset -u "$1" >/dev/null 2>&1 && git -C "$SKILL_HOME" update-ref HEAD "$1" >/dev/null 2>&1; then return 0; fi
  if [ -f "$SKILL_HOME/.git/index" ]; then mv -f "$SKILL_HOME/.git/index" "$SKILL_HOME/.git/index.broken-$$" 2>/dev/null || true; fi
  if git -C "$SKILL_HOME" read-tree "$1" >/dev/null 2>&1 && git -C "$SKILL_HOME" checkout-index -a -f >/dev/null 2>&1 \
     && git -C "$SKILL_HOME" update-ref HEAD "$1" >/dev/null 2>&1; then return 0; fi
  return 1
}
if [ -s "$_J" ]; then
  _sha="$(sed -n 1p "$_J")"; _rp="$(sed -n 2p "$_J")"; _pid="$(sed -n 3p "$_J")"; _id="$(sed -n 4p "$_J")"
  # an update that is running RIGHT NOW is not touched. 4.5.x: "alive" = same boot + same process start time
  # (a pid number reused after a reboot is not the writer); old journals without the id keep the old rule.
  _alive=0
  if [[ "$_pid" =~ ^[0-9]+$ ]] && kill -0 "$_pid" 2>/dev/null; then
    if [ -n "$_id" ]; then
      _st="$(sed 's/^.*) //' "/proc/$_pid/stat" 2>/dev/null | awk '{print $20}')"
      if [ "$(cat /proc/sys/kernel/random/boot_id 2>/dev/null):$_st" = "$_id" ]; then _alive=1; fi
    elif [ -n "$(find "$_J" -mmin -20 2>/dev/null)" ]; then _alive=1; fi
  fi
  if [ "$_alive" = 1 ]; then _rp=""; fi
  if [ "$_rp" = "$SKILL_HOME" ] && [[ "$_sha" =~ ^[0-9a-f]{7,64}$ ]] && [ -d "$SKILL_HOME/.git" ]; then
    if _ys_reset "$_sha"; then
      # 4.5.62: the half-applied update leaves its version tag and .ysnew temp files; clear them now so a pipeline run from a
      # plain terminal (no app started) sees a clean tree. A rollback journal keeps its tag (it names the PREVIOUS good version).
      _jj="$DATA_DIR/release_updates/pending.json"
      if [ -f "$_jj" ] && ! grep -q '"kind": *"rollback"' "$_jj" 2>/dev/null; then
        _tg="$(sed -n 's/.*"target": *"\([0-9][0-9.]*\)".*/\1/p' "$_jj" | head -1)"
        if [ -n "$_tg" ]; then git -C "$SKILL_HOME" tag -d "rel-$_tg" >/dev/null 2>&1 || true; fi
      fi
      find "$SKILL_HOME" -path "$SKILL_HOME/.git" -prune -o -type f -name '.*.ysnew' -print0 2>/dev/null | xargs -0 -r rm -f -- 2>/dev/null || true
      rm -f "$_J"
    else printf 'git\n' > "$DATA_DIR/release_updates/recover_failed" 2>/dev/null || true; fi   # the app shows it in the page
  fi
fi
# 4.5.x (B7): first starts of a freshly installed version. The app clears release_updates/trial once it has run healthy
# for 30s. Still there at the next start = the new version failed once → start with --skip-update (no update loop; the
# page offers "↩ חזור לגרסה הקודמת"); failed twice → go back to the commit from before the update by itself.
_T="$DATA_DIR/release_updates/trial"
if [ "${1:-}" = "py" ] && [ "${2:-}" = "make_short_app.py" ] && [ -s "$_T" ]; then
  _running=0
  for c in /proc/[0-9]*/cmdline; do     # a second click while THIS install's app already runs is not a failed start
    if [ "${c%/cmdline}" != "/proc/$$" ] && tr '\0' ' ' 2>/dev/null < "$c" | grep -qF "$SKILL_HOME/pipeline/scripts/make_short_app.py"; then
      _running=1; break
    fi
  done
  if [ "$_running" = 0 ]; then
    _tv="$(sed -n 1p "$_T")"; _tp="$(sed -n 2p "$_T")"; _tr="$(sed -n 3p "$_T")"; _tn="$(sed -n 4p "$_T")"; _to="$(sed -n 5p "$_T")"
    if ! [[ "$_tn" =~ ^[0-9]+$ ]]; then _tn=0; fi
    _tn=$((_tn + 1))
    # 4.5.62: a trial marker is only about THIS update. If the code now installed is not one of the versions it names (a package
    # was installed over it, or the tree was changed some other way) the marker is stale — drop it, never revert fresh code.
    _cur="$(cat "$SKILL_HOME/VERSION" 2>/dev/null | tr -d '[:space:]')"; _hit=0
    for _v in $_tv; do if [ "$_v" = "$_cur" ]; then _hit=1; fi; done
    if [ "$_hit" = 0 ]; then
      rm -f "$_T"
    elif [ "$_tr" = "$SKILL_HOME" ] && [[ "$_tp" =~ ^[0-9a-f]{7,64}$ ]] && [ -d "$SKILL_HOME/.git" ]; then
      if [ "$_tn" -ge 2 ]; then
        if _ys_reset "$_tp"; then
          for _v in $_tv; do git -C "$SKILL_HOME" tag -d "rel-$_v" >/dev/null 2>&1 || true; done
          # 4.5.62: the commit before the update may carry the user's personal changes — the official base tag of that version
          # (pruned by a multi-version update) is put back on the official commit, so the register and the code keep agreeing
          if [[ "$_to" =~ ^[0-9a-f]{7,64}$ ]] && git -C "$SKILL_HOME" cat-file -e "$_to^{commit}" >/dev/null 2>&1; then
            _fv="$(cat "$SKILL_HOME/VERSION" 2>/dev/null | tr -d '[:space:]')"
            if [ -n "$_fv" ]; then git -C "$SKILL_HOME" tag -f "rel-$_fv" "$_to" >/dev/null 2>&1 || true; fi
          fi
          printf '%s\n' "$_tv" > "$DATA_DIR/release_updates/trial_failed"; rm -f "$_T"
        fi
      else
        printf '%s\n%s\n%s\n%s\n%s\n' "$_tv" "$_tp" "$_tr" "$_tn" "$_to" > "$_T"
        set -- "$@" --skip-update
      fi
    else
      rm -f "$_T"
    fi
  fi
fi
# <UPDATE-RECOVER-END>
mkdir -p "$CONFIG_DIR" "$DATA_DIR" "$PRIVBIN"
chmod 700 "$CONFIG_DIR" 2>/dev/null || true

# Deno must be on PATH: yt-dlp solves YouTube's "n" challenge in an external
# JS engine. Without it a download "succeeds" but returns storyboards only,
# and the sole clue is a WARNING that is easy to miss.
export PATH="$PRIVBIN:$VENV/bin:$DATA_DIR/deno/bin:$HOME/.deno/bin:$HOME/.local/bin:$PATH"
export PYTHONPATH="$SKILL_HOME/pipeline/scripts${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8

# --- secrets: a separate 600 file, outside every repo ------------------------
# shellcheck disable=SC1090
[ -f "$CONFIG_DIR/config.env" ] && set -a && . "$CONFIG_DIR/config.env" && set +a
# Tool choices made in the page (advanced settings → כלים) or by tool_finder.py.
# The file exists only when the user picked something other than "auto", so without
# it everything below behaves exactly as before.
# shellcheck disable=SC1091
[ -f "$CONFIG_DIR/tools.env" ] && . "$CONFIG_DIR/tools.env"
# A chosen Deno/Node goes first on PATH (yt-dlp looks for "deno" by name).
if [ -n "${SHORTS_DENO:-}" ] && [ -x "$SHORTS_DENO" ]; then
  mkdir -p "$DATA_DIR/jsrt"
  ln -sfn "$SHORTS_DENO" "$DATA_DIR/jsrt/$(basename "$SHORTS_DENO")"
  export PATH="$DATA_DIR/jsrt:$PATH"
fi

pick() { for c in "$@"; do [ -x "$c" ] && { echo "$c"; return; }; done
         command -v "$1" >/dev/null 2>&1 && command -v "$1" || echo "$1"; }
export FFMPEG="${FFMPEG:-$(pick "$PRIVBIN/ffmpeg" /usr/bin/ffmpeg /usr/local/bin/ffmpeg /opt/homebrew/bin/ffmpeg)}"
export FFPROBE="${FFPROBE:-$(pick "$PRIVBIN/ffprobe" /usr/bin/ffprobe /usr/local/bin/ffprobe /opt/homebrew/bin/ffprobe)}"

export SHORTS_SKILL_HOME="$SKILL_HOME"
export SHORTS_LIB="${SHORTS_LIB:-$SKILL_HOME/assets}"
export SHORTS_ROOT="$DATA_DIR"
export SHORTS_SECRETS="$CONFIG_DIR"
export SHORTS_CONFIG_DIR="$CONFIG_DIR"
export SHORTS_DATA_DIR="$DATA_DIR"
export SHORTS_PROJECTS="${SHORTS_PROJECTS:-$DATA_DIR/projects}"
# Where finished clips land on this machine. setup.py writes this; the
# default is the OS media folder, resolved in python so it is right on
# Linux / macOS / WSL alike.
export SHORTS_EXPORT_DIR="${SHORTS_EXPORT_DIR:-}"

PY="$VENV/bin/python"
[ -x "$PY" ] || PY="$(command -v python3 || command -v python || echo python3)"

# --- עדיפות מעבד ------------------------------------------------------------
# העיבוד (תמלול, ייצוב, קידוד) לוקח את כל הליבות, והמחשב נתקע למשתמש
# באמצע עבודה אחרת. `nice` מוריד את **העדיפות**, לא את הכמות: כשאף אחד לא
# צריך את המעבד הריצה רצה במהירות מלאה, וכשהמשתמש פותח דפדפן הוא מקבל
# קדימות. זה בדיוק ההבדל מהגבלת ליבות, שמאטה תמיד.
# SHORTS_NICE=0 מבטל לגמרי. 5 = מתון; 19 = "רק כשהמחשב פנוי".
NICE=()
if [ "${SHORTS_NICE:-5}" != "0" ] && command -v nice >/dev/null 2>&1; then
  NICE=(nice -n "${SHORTS_NICE:-5}")
fi

need_venv() {
  [ -x "$VENV/bin/python" ] && return 0
  echo "הסביבה עדיין לא הותקנה. הרץ:  $SKILL_HOME/install.sh" >&2
  exit 3
}

cmd="${1:-}"; shift || true

case "$cmd" in
  setup)
    exec "$PY" "$SKILL_HOME/setup/setup.py" "$@"
    ;;

  doctor)
    exec "$PY" "$SKILL_HOME/setup/doctor.py" "$@"
    ;;

  tools)
    # tools            → JSON of what was found (ffmpeg/ffprobe/yt-dlp/deno/ASR/OS)
    # tools set <ffmpeg|ffprobe|ytdlp|deno|asr> <auto|builtin|system|custom> [path]
    exec "$PY" "$SKILL_HOME/pipeline/scripts/tool_finder.py" "$@"
    ;;

  new)
    slug="${1:?usage: shorts.sh new <slug>}"
    d="$SHORTS_PROJECTS/$(date +%F)_${slug}"
    mkdir -p "$d"/{source,gemini,shorts,verify,work/{clips,subtitles,transcripts,qc}}
    echo "$d"
    ;;

  py)
    need_venv
    s="${1:?usage: shorts.sh py <script.py> [args] · or shorts.sh py - <<EOF}"; shift || true
    # "-" = code on stdin. The skill documents this form for short one-off
    # snippets; without the guard it becomes "$SCRIPTS/-" and dies.
    [ "$s" = "-" ] || [ -f "$s" ] || s="$SKILL_HOME/pipeline/scripts/$s"
    exec "${NICE[@]}" "$VENV/bin/python" "$s" "$@"
    ;;

  export|deliver)
    need_venv
    exec "$VENV/bin/python" "$SKILL_HOME/pipeline/scripts/export_clips.py" --project "$@"
    ;;

  asr)
    need_venv
    exec "$VENV/bin/python" "$SKILL_HOME/pipeline/scripts/colab_asr.py" "$@"
    ;;

  ffmpeg)  exec "${NICE[@]}" "$FFMPEG" "$@" ;;
  ffprobe) exec "$FFPROBE" "$@" ;;   # מטא-דאטה בלבד, מסתיים מיד — בלי nice

  yt-dlp)
    # SHORTS_YTDLP (from tools.env) = a yt-dlp the user chose; empty = the one in the private venv.
    if [ -n "${SHORTS_YTDLP:-}" ] && [ -x "$SHORTS_YTDLP" ]; then YTDLP=("$SHORTS_YTDLP"); else need_venv; YTDLP=("$VENV/bin/python" -m yt_dlp); fi
    # Cookies are a fallback, not the default. They exist for videos that
    # need the account (scheduled/private uploads, or YouTube blocking a
    # data-centre IP with "not a bot"). They go stale within weeks, and a
    # stale set breaks even public videos ("The page needs to be reloaded") —
    # measured 2026-09-22: same public video failed with cookies, worked
    # without. So: try plain first, and retry with cookies only when the
    # error says a login is needed. An explicit --cookies/--no-cookies from
    # the caller always wins.
    ck="$CONFIG_DIR/youtube_cookies.txt"
    if [ ! -f "$ck" ] || printf '%s\n' "$@" | grep -q -- 'cookies'; then
      exec "${YTDLP[@]}" "$@"
    fi
    err=$(mktemp)
    # `|| rc=$?` — the script runs under `set -e`; a bare failing call would
    # kill it here, swallowing both the error text and the retry.
    rc=0
    "${YTDLP[@]}" "$@" 2>"$err" || rc=$?
    cat "$err" >&2
    if [ $rc -ne 0 ] && grep -qiE 'private video|sign in|log in|members|not a bot|unavailable|not available' "$err"; then
      rm -f "$err"
      echo "↻ נדרשת התחברות — מנסה שוב עם העוגיות של החשבון" >&2
      exec "${YTDLP[@]}" --cookies "$ck" "$@"
    fi
    rm -f "$err"
    exit $rc
    ;;

  where)
    echo "skill    = $SKILL_HOME"
    echo "config   = $CONFIG_DIR"
    echo "data     = $DATA_DIR"
    echo "projects = $SHORTS_PROJECTS"
    echo "export   = ${SHORTS_EXPORT_DIR:-(not set — run: shorts.sh setup)}"
    ;;

  env)
    echo "skill       = $SKILL_HOME"
    echo "ffmpeg      = $("$FFMPEG" -version 2>/dev/null | head -1 || echo 'חסר ✗')"
    echo "python      = $("$PY" -V 2>/dev/null || echo 'חסר ✗')"
    echo "GEMINI_API_KEY = $([ -n "${GEMINI_API_KEY:-}" ] && echo 'מוגדר ✓' || echo 'חסר ✗')"
    echo "export dir  = ${SHORTS_EXPORT_DIR:-'(לא הוגדר)'}"
    ;;

  *)
    sed -n '2,21p' "$0" | sed 's/^# \{0,1\}//'
    exit 1
    ;;
esac
