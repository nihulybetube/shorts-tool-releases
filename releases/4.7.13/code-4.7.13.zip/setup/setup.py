# -*- coding: utf-8 -*-
"""אשף ההתקנה הראשונה — מחבר את המפתחות שלך ובוחר לאן התוצרים יישמרו.

    shorts.sh setup              # שואל רק על מה שעוד לא הוגדר או נדחה
    shorts.sh setup --all        # שואל שוב על הכל, כולל מה שדילגת עליו
    shorts.sh setup --redo gemini
    shorts.sh setup --show       # מה מוגדר, מה דולג ומתי — בלי לשאול כלום
    shorts.sh setup --non-interactive   # רק מדפיס מה חסר, לא שואל

עקרון: **דילוג הוא החלטה שנשמרת.** שלב שאינו קריטי שדילגת עליו לא יישאל
שוב, עד ש-`--all` או `--redo <שלב>` יבקשו במפורש. שלב קריטי אפשר לדחות
להרצה הבאה, אבל הוא ייענה שוב — בלעדיו הפייפליין לא רץ.
"""

import argparse
import urllib.parse
import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import state  # noqa: E402

G = "\033[32m"; Y = "\033[33m"; R = "\033[31m"; B = "\033[1m"; D = "\033[2m"; N = "\033[0m"
if not sys.stdout.isatty() or os.environ.get("NO_COLOR"):
    G = Y = R = B = D = N = ""

TTY = sys.stdin.isatty()


def say(s=""):
    print(s, flush=True)


def ask(prompt, default=""):
    if not TTY:
        return default
    try:
        v = input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        say()
        raise SystemExit(130)
    return v or default


def ask_yes(prompt, default=True):
    d = "כן" if default else "לא"
    v = ask("%s [%s] " % (prompt, d), d).lower()
    return v[:1] in ("y", "כ", "1") or (v == d.lower() and default)


# --- לאן התוצרים נשמרים ------------------------------------------------------

def default_export_dir() -> Path:
    home = Path.home()
    sysname = platform.system()
    if sysname == "Darwin":
        base = home / "Movies"
    elif sysname == "Windows":
        base = Path(os.environ.get("USERPROFILE", home)) / "Videos"
    else:
        # לינוקס: מכבדים XDG אם המשתמש הגדיר תיקיית וידאו משלו, גם בעברית.
        base = home / "Videos"
        cfg = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config")) / "user-dirs.dirs"
        if cfg.exists():
            try:
                for line in cfg.read_text(encoding="utf-8").splitlines():
                    if line.startswith("XDG_VIDEOS_DIR="):
                        raw = line.split("=", 1)[1].strip().strip('"')
                        base = Path(os.path.expandvars(raw.replace("$HOME", str(home))))
            except OSError:
                pass
    return base / "Shorts"


def step_export_dir(force=False):
    cur = state.read_env().get("SHORTS_EXPORT_DIR", "")
    say(B + "לאן הסרטונים המוכנים יישמרו אצלך במחשב" + N)
    say(D + "  בסוף כל ריצה הקליפים המוכנים מועתקים לתיקייה הזאת, כל פרויקט" + N)
    say(D + "  בתיקייה משלו עם הכותרת, התיאור והתגיות לצד הווידאו." + N)
    default = cur or str(default_export_dir())
    path = ask("  נתיב [%s]: " % default, default)
    p = Path(os.path.expanduser(path))
    try:
        p.mkdir(parents=True, exist_ok=True)
        probe = p / ".write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as e:
        say(R + "  ✗ אי אפשר לכתוב לשם (%s). נסה נתיב אחר." % e.strerror + N)
        return "pending"
    state.write_env({"SHORTS_EXPORT_DIR": str(p)})
    say(G + "  ✓ נשמר: %s" % p + N)
    return "done"


# --- ג'מיני ------------------------------------------------------------------

def probe_gemini(key: str):
    """בדיקה חיה מול ה-API. מפתח שנכתב עם רווח או ציטוט נראה תקין בקובץ
    ונכשל רק שלושה שלבים אחר כך, בתוך ריצה שכבר הורידה וידאו של גיגה."""
    url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + urllib.parse.quote(key, safe="")
    req = urllib.request.Request(url, headers={"User-Agent": "yeshiva-shorts-setup"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode("utf-8"))
        names = [m.get("name", "") for m in data.get("models", [])]
        return True, "%d מודלים זמינים" % len(names)
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            pass
        if e.code in (400, 403):
            return False, "המפתח נדחה על ידי גוגל" + (" — %s" % body if body else "")
        return False, "שגיאה %d מגוגל%s" % (e.code, (" — %s" % body) if body else "")
    except urllib.error.URLError as e:
        return False, "אין חיבור לגוגל (%s)" % e.reason
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def step_gemini(force=False):
    say(B + "מפתח Gemini — המנוע שבוחר את הקליפים" + N)
    say(D + "  ג'מיני צופה בשיעור, מציע אילו קטעים יעבדו כשורט, וכותב כותרת" + N)
    say(D + "  ותיאור. הוא גם המאזין השני שמצליב את התמלול. בלעדיו אין ריצה." + N)
    say("  איפה משיגים: " + B + "https://aistudio.google.com/apikey" + N +
        " → Create API key → העתק")
    say(D + "  חינם בשכבת ה-flash. המפתח נשמר רק אצלך, ב-%s" % state.env_path() + N)
    cur = state.read_env().get("GEMINI_API_KEY", "")
    if cur and not force:
        ok, msg = probe_gemini(cur)
        if ok:
            say(G + "  ✓ המפתח הקיים עובד (%s)" % msg + N)
            return "done"
        say(Y + "  ! המפתח השמור לא עבר: %s" % msg + N)
    key = ask("  הדבק מפתח (Enter = לדלג להרצה הזאת): ").strip().strip('"').strip("'")
    if not key:
        say(Y + "  → נדחה. הפייפליין לא ירוץ עד שיהיה מפתח." + N)
        return "pending"
    ok, msg = probe_gemini(key)
    if not ok:
        say(R + "  ✗ %s" % msg + N)
        if not ask_yes("  לשמור בכל זאת?", False):
            return "pending"
    else:
        say(G + "  ✓ המפתח עובד (%s)" % msg + N)
    state.write_env({"GEMINI_API_KEY": key})
    return "done"


# --- תמלול -------------------------------------------------------------------

def modal_ready():
    home = Path.home()
    for p in (home / ".modal.toml", Path(os.environ.get("MODAL_CONFIG_PATH", "/nonexistent"))):
        if p.exists():
            return True
    return bool(os.environ.get("MODAL_TOKEN_ID"))


def step_asr(force=False):
    say(B + "תמלול — איך הדיבור הופך לכתוביות" + N)
    say(D + "  שתי דרכים. אם יש לך כרטיס מסך (GPU) — מקומי, בחינם ובלי חשבון." + N)
    say(D + "  אם אין — Modal מריץ את אותו מודל עברי על GPU בענן, אגורות לריצה." + N)
    say("  1) " + B + "מקומי" + N + " — faster-whisper על המחשב הזה (איטי בלי GPU, אבל עובד)")
    say("  2) " + B + "Modal" + N + " — ענן. הרשמה ב-https://modal.com (קרדיט חינמי 30$ בחודש; Modal דורש כרטיס אשראי להרשמה) — [סקריפט לבעלים/עוזר טכני]")
    cur = state.read_env().get("SHORTS_ASR", "")
    default = cur or ("2" if modal_ready() else "1")
    choice = ask("  בחר 1 או 2 [%s]: " % default, default)
    if choice == "2":
        if not modal_ready():
            say(Y + "  צריך פעם אחת להתחבר. פתח טרמינל חדש והרץ:" + N)
            say("    " + B + "modal token new" + N + "   (נפתח דפדפן, לחיצה אחת)")
            say(D + "  או, אם יש לך טוקן מ-modal.com → Settings → API Tokens:" + N)
            say("    modal token set --token-id <ID> --token-secret <SECRET>")
            if not ask_yes("  לסמן כמוגדר בכל זאת?", False):
                state.write_env({"SHORTS_ASR": "modal"})
                return "pending"
        state.write_env({"SHORTS_ASR": "modal"})
        say(G + "  ✓ תמלול בענן (Modal)" + N)
    else:
        state.write_env({"SHORTS_ASR": "local"})
        say(G + "  ✓ תמלול מקומי" + N)
        say(D + "  המודל (~1.5GB) יורד לבד בריצה הראשונה." + N)
    return "done"


# --- לוגו --------------------------------------------------------------------

def step_logo(force=False):
    say(B + "לוגו — נצרב בפינה של כל קליף" + N)
    say(D + "  קובץ PNG עם רקע שקוף, רצוי לבן. אם אין לך — אפשר לדלג," + N)
    say(D + "  והקליפים ייצאו בלי מיתוג." + N)
    dst_dir = Path(state.config_dir()) / "brand"
    cur = state.read_env().get("SHORTS_LOGO", "")
    if cur and Path(cur).exists() and not force:
        say(G + "  ✓ מוגדר: %s" % cur + N)
        return "done"

    # מי שמחלק את הסקיל הלאה שם את הלוגו ב-assets/logo/ ומצפה שזה יספיק.
    # בלי זה הוא היה מקבל בשקט קליפים בלי מיתוג: הפייפליין קורא רק
    # `$SHORTS_LOGO` או `logo.png` של הריצה, ולא סורק את התיקייה הזאת.
    bundled = sorted(f for f in (Path(__file__).resolve().parent.parent / "assets" / "logo").glob("*")
                     if f.suffix.lower() in (".png", ".webp"))
    prompt, default = "  נתיב לקובץ הלוגו (Enter = לדלג): ", ""
    if bundled:
        say(G + "  נמצא לוגו בחבילה: %s" % bundled[0].name + N)
        prompt, default = "  Enter = להשתמש בו, או נתיב אחר (- = בלי לוגו): ", str(bundled[0])

    src = ask(prompt, default).strip().strip('"').strip("'")
    if src == "-" or not src:
        return "skipped"
    p = Path(os.path.expanduser(src))
    if not p.exists():
        say(R + "  ✗ לא נמצא קובץ בנתיב הזה." + N)
        return "pending"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / p.name
    shutil.copy2(p, dst)
    state.write_env({"SHORTS_LOGO": str(dst)})
    say(G + "  ✓ הועתק ל-%s" % dst + N)
    return "done"


# --- מוזיקה ------------------------------------------------------------------

def step_music(force=False):
    say(B + "מוזיקת רקע (לא חובה)" + N)
    say(D + "  הפייפליין מייצר גרסה שנייה עם מוזיקה לצד הרגילה." + N)
    say("  1) " + B + "להוריד ספרייה חינמית" + N + " — ~500 יצירות של Kevin MacLeod,")
    say(D + "     ממוינות לפי אופי (רגוע / מרומם / פנימי / כבד). הכלי גם זוכר" + N)
    say(D + "     מה עבד ומה לא, ומעדיף בפעם הבאה את מה שאהבת." + N)
    say(Y + "     ⚠️  הרישיון מחייב שורת קרדיט בתיאור — היא נכתבת אוטומטית." + N)
    say("  2) " + B + "תיקייה משלי" + N + " — mp3 שכבר יש לך, באחריותך על הרישיון")
    say("  3) " + B + "לדלג" + N)

    cur = state.read_env().get("SHORTS_MUSIC_DIR", "")
    if cur and Path(cur).exists() and not force:
        say(G + "  ✓ מוגדר: %s" % cur + N)
        return "done"

    choice = ask("  בחר 1/2/3 [1]: ", "1").strip()
    if choice == "3":
        return "skipped"
    if choice == "1":
        return _music_download()

    src = ask("  נתיב לתיקיית המוזיקה (Enter = לדלג): ").strip().strip('"').strip("'")
    if not src:
        return "skipped"
    p = Path(os.path.expanduser(src))
    if not p.is_dir():
        say(R + "  ✗ זו לא תיקייה קיימת." + N)
        return "pending"
    state.write_env({"SHORTS_MUSIC_DIR": str(p)})
    say(G + "  ✓ נשמר (%d קבצים)" % len(list(p.glob("*.mp3"))) + N)
    return "done"


def _music_download():
    """מריץ את music_library דרך הפייתון של הסביבה.

    הוא יושב ב-pipeline/scripts ומייבא לפי sys.path של ההרצה, ולכן
    מופעל כתת-תהליך עם ה-cwd הזה ולא מיובא לתוך האשף."""
    n = ask("  כמה טראקים להוריד? [20]: ", "20").strip()
    try:
        n = max(5, min(100, int(n)))
    except ValueError:
        n = 20
    scripts = str(Path(__file__).resolve().parent.parent / "pipeline" / "scripts")
    for args in (["sync"], ["fetch", "--count", str(n)]):
        r = subprocess.run([sys.executable, "music_library.py"] + args, cwd=scripts)
        if r.returncode != 0:
            say(R + "  ✗ ההורדה נכשלה. אפשר לנסות שוב: setup --redo music" + N)
            return "pending"
    say(G + "  ✓ הספרייה מוכנה. `shorts.sh py music_library.py list` מראה מה יש." + N)
    return "done"


# --- עוגיות יוטיוב -----------------------------------------------------------

def step_cookies(force=False):
    say(B + "עוגיות יוטיוב (לא חובה — רק אם ההורדה נחסמת)" + N)
    say(D + "  ממחשב ביתי ההורדה בדרך כלל עובדת בלי זה. משרת בענן יוטיוב" + N)
    say(D + '  חוסם ומחזיר "Sign in to confirm you\'re not a bot" — ואז צריך' + N)
    say(D + "  קובץ עוגיות מדפדפן שמחובר ליוטיוב." + N)
    say("  איך: התקן בדפדפן תוסף " + B + "Get cookies.txt LOCALLY" + N +
        ", היכנס ל-youtube.com,")
    say("  לחץ על התוסף → Export → שמור את הקובץ, ותן כאן את הנתיב אליו.")
    dst = Path(state.config_dir()) / "youtube_cookies.txt"
    if dst.exists() and not force:
        say(G + "  ✓ קיים כבר: %s" % dst + N)
        return "done"
    src = ask("  נתיב לקובץ (Enter = לדלג): ").strip().strip('"').strip("'")
    if not src:
        return "skipped"
    p = Path(os.path.expanduser(src))
    if not p.exists():
        say(R + "  ✗ לא נמצא." + N)
        return "pending"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dst)
    os.chmod(dst, 0o600)
    say(G + "  ✓ הותקן. `shorts.sh yt-dlp` ישתמש בו לבד." + N)
    return "done"


# --- העלאה ליוטיוב -----------------------------------------------------------

def step_youtube_upload(force=False):
    say(B + "העלאה אוטומטית ליוטיוב (לא חובה)" + N)
    say(D + "  בלי זה הכל עובד — פשוט תעלה את הקבצים ידנית מתיקיית הייצוא." + N)
    say(D + "  עם זה, `youtube_upload.py` מעלה את הקליפים כ-private לערוץ שלך." + N)
    say("  דורש פרויקט Google Cloud משלך עם YouTube Data API v3, וקובץ")
    say("  OAuth client secret (Desktop app) — כ-10 דקות הגדרה חד-פעמית.")
    dst = Path(state.config_dir()) / "client_secret.json"
    if dst.exists() and not force:
        say(G + "  ✓ קיים כבר." + N)
        return "done"
    src = ask("  נתיב ל-client_secret.json (Enter = לדלג): ").strip().strip('"').strip("'")
    if not src:
        return "skipped"
    p = Path(os.path.expanduser(src))
    if not p.exists():
        say(R + "  ✗ לא נמצא." + N)
        return "pending"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dst)
    os.chmod(dst, 0o600)
    say(G + "  ✓ הותקן. ההרשאה עצמה תתבקש בהעלאה הראשונה." + N)
    return "done"


# --- הנחיות תוכן -------------------------------------------------------------

def step_guidelines(force=False):
    say(B + "הנחיות התוכן (לא חובה)" + N)
    say(D + "  הטקסט שמסביר לג'מיני אילו קטעים לבחור ואיך לנסח כותרת." + N)
    say(D + "  יש ברירת מחדל שעובדת. אם תרצה לשנות אותה — נעתיק עותק אישי" + N)
    say(D + "  שתוכל לערוך, והפייפליין ישתמש בו במקום." + N)
    src = Path(os.environ.get("SHORTS_LIB", "")) / "guidelines" / "shorts_default.txt"
    dst = Path(state.config_dir()) / "guidelines.txt"
    if dst.exists() and not force:
        say(G + "  ✓ יש לך עותק אישי: %s" % dst + N)
        return "done"
    if not ask_yes("  ליצור עותק אישי לעריכה?", False):
        return "skipped"
    if not src.exists():
        say(R + "  ✗ קובץ ברירת המחדל לא נמצא (%s)" % src + N)
        return "pending"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    state.write_env({"SHORTS_GUIDELINES": str(dst)})
    say(G + "  ✓ נוצר. ערוך אותו מתי שתרצה: %s" % dst + N)
    return "done"


STEPS = [
    ("export_dir", "תיקיית הפלט", True, step_export_dir),
    ("gemini", "מפתח Gemini", True, step_gemini),
    ("asr", "תמלול", True, step_asr),
    ("logo", "לוגו", False, step_logo),
    ("music", "מוזיקת רקע", False, step_music),
    ("cookies", "עוגיות יוטיוב", False, step_cookies),
    ("youtube_upload", "העלאה ליוטיוב", False, step_youtube_upload),
    ("guidelines", "הנחיות תוכן", False, step_guidelines),
]
BY_ID = {s[0]: s for s in STEPS}


def show():
    st = state.load()["steps"]
    say(B + "מצב ההגדרה" + N + D + "  (%s)" % state.state_path() + N)
    for sid, title, critical, _ in STEPS:
        rec = st.get(sid) or {}
        s = rec.get("status", "")
        tag = {"done": G + "מוגדר  ", "skipped": Y + "דולג   "}.get(s, R + "חסר    ")
        when = D + rec.get("at", "") + N if rec.get("at") else ""
        flag = "" if critical else D + " (לא חובה)" + N
        say("  %s%s  %s%s  %s" % (tag, N, title, flag, when))
    say()
    say(D + "  לשנות משהו שדילגת עליו:  shorts.sh setup --redo <שלב>" + N)
    say(D + "  שמות השלבים: %s" % ", ".join(s[0] for s in STEPS) + N)


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--all", action="store_true", help="לשאול שוב על הכל, כולל מה שדולג")
    ap.add_argument("--redo", action="append", default=[], help="לשאול שוב על שלב אחד")
    ap.add_argument("--show", action="store_true", help="להציג מצב בלבד")
    ap.add_argument("--non-interactive", action="store_true", help="רק לדווח מה חסר")
    a = ap.parse_args()

    if a.show:
        show()
        return 0

    for r in a.redo:
        if r not in BY_ID:
            say(R + "אין שלב בשם %s. השלבים: %s" % (r, ", ".join(BY_ID)) + N)
            return 2
        state.forget(r)

    missing = [s for s in STEPS if s[2] and state.status_of(s[0]) != "done"]
    if a.non_interactive or not TTY:
        show()
        if missing:
            say(R + "חסר: %s — הרץ `shorts.sh setup` בטרמינל." % ", ".join(s[1] for s in missing) + N)
            return 1
        return 0

    say()
    say(B + "═══ הגדרה ראשונה — הפקת שורטס ═══" + N)
    say(D + "  שמונה שאלות, חמש מהן אפשר לדלג. מה שתדלג עליו לא יישאל שוב." + N)
    say(D + "  שום דבר לא נשלח לאף אחד: המפתחות נשמרים רק אצלך, ב-" + N)
    say(D + "  %s (הרשאות 600)." % state.env_path() + N)
    say()

    for sid, title, critical, fn in STEPS:
        # `--redo x` פירושו "רק x". שלב קריטי שעדיין חסר ייענה בהרצה
        # הרגילה הבאה; לשאול עליו כאן היה הופך בקשה ממוקדת לשאלון מלא,
        # וגרוע מזה — התשובה שהמשתמש התכוון לתת ל-x נכנסת לשאלה אחרת.
        if a.redo and sid not in a.redo:
            continue
        prev = state.status_of(sid)
        if not a.all and sid not in a.redo:
            if prev == "done":
                say("%s✓%s %s — כבר מוגדר" % (G, N, title))
                continue
            if prev == "skipped":
                say("%s–%s %s — דילגת על זה בעבר (`--redo %s` כדי לשנות)" % (Y, N, title, sid))
                continue
        say()
        res = fn(force=(a.all or sid in a.redo))
        if res in ("done", "skipped"):
            state.mark(sid, res)
        # "pending" נשאר בלי סימון — כלומר יישאל שוב בהרצה הבאה.

    say()
    still = [s[1] for s in STEPS if s[2] and state.status_of(s[0]) != "done"]
    if still:
        say(Y + "עדיין חסר כדי להריץ: %s" % ", ".join(still) + N)
        say(D + "הרץ שוב `shorts.sh setup` כשיהיה לך." + N)
        return 1
    say(G + B + "הכל מוכן." + N)
    say("  בדיקה מלאה:      " + B + "shorts.sh doctor" + N)
    say("  ריצה ראשונה:     בקש מקלוד " + B + '"תכין שורטס מהקישור הזה: <קישור>"' + N)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
