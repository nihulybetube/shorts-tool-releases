# -*- coding: utf-8 -*-
"""מצב ההתקנה — מה כבר הוגדר, ומה המשתמש בחר לדלג עליו.

למה קובץ מצב ולא רק `config.env`: דילוג הוא **החלטה**, לא היעדר ערך.
בלי לזכור אותו, כל הרצה של האשף הייתה שואלת שוב על אותם דברים
אופציונליים שהמשתמש כבר החליט לוותר עליהם — וזה בדיוק מה שגורם לאנשים
להפסיק להריץ בדיקות סביבה.

הקובץ יושב אצל המשתמש (`~/.config/yeshiva-shorts/state.json`), לא בריפו.
"""

import json
import os
import time
from pathlib import Path

VERSION = 1


def config_dir() -> Path:
    p = os.environ.get("SHORTS_CONFIG_DIR")
    if p:
        return Path(p)
    base = os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config")
    return Path(base) / "yeshiva-shorts"


def state_path() -> Path:
    return config_dir() / "state.json"


def load() -> dict:
    p = state_path()
    if not p.exists():
        return {"version": VERSION, "steps": {}}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {"version": VERSION, "steps": {}}
    d.setdefault("steps", {})
    return d


def save(d: dict) -> None:
    p = state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, p)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass


def mark(step_id: str, status: str, note: str = "") -> None:
    """status: done | skipped"""
    d = load()
    d["steps"][step_id] = {
        "status": status,
        "at": time.strftime("%Y-%m-%d %H:%M"),
        "note": note,
    }
    save(d)


def status_of(step_id: str) -> str:
    return (load()["steps"].get(step_id) or {}).get("status", "")


def forget(step_id: str) -> None:
    d = load()
    d["steps"].pop(step_id, None)
    save(d)


# --- config.env -------------------------------------------------------------

def env_path() -> Path:
    return config_dir() / "config.env"


def read_env() -> dict:
    p = env_path()
    out = {}
    if not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def write_env(updates: dict) -> None:
    """מיזוג, לא דריסה. ערך None מוחק מפתח.

    🚨 הקובץ נכתב 600 לפני שנכנס אליו תוכן — לא אחרי. קובץ שנוצר 644
    ונסגר רגע אחר כך הוא חלון שבו המפתח של המשתמש קריא לכל תהליך במכונה.
    """
    cur = read_env()
    for k, v in updates.items():
        if v is None:
            cur.pop(k, None)
        else:
            cur[k] = str(v)
    p = env_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(p.parent, 0o700)
    except OSError:
        pass
    tmp = p.with_suffix(".tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write("# yeshiva-shorts — המפתחות שלך. הקובץ הזה אישי ולא נכנס לשום ריפו.\n")
        fh.write("# נוצר על ידי `shorts.sh setup`. מותר לערוך ביד.\n\n")
        for k in sorted(cur):
            fh.write("%s=%s\n" % (k, cur[k]))
    os.replace(tmp, p)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
