#!/bin/bash
# 4.0.4 — "xdg-open" for WSL: opens a link in the WINDOWS default browser.
# Why: WSL Ubuntu has no xdg-open / wslview / $BROWSER, so rclone ("reconnect gdrive:") and
# `modal token new` only printed a link in the black window, and Ctrl+C (to copy it) stopped
# the whole flow. Installed as $DATA_DIR/bin/xdg-open (install.sh, and on demand by the app).
# The URL goes to PowerShell through an environment variable (WSLENV), never on a command
# line — so & ? = ; and quotes in OAuth links cannot be misread (the cmd.exe `start` trap).
u="${1:-}"
case "$u" in http://*|https://*) ;; *) echo "xdg-open: only http(s) links" >&2; exit 2 ;; esac
if [ -n "${YS_OPEN_LOG:-}" ]; then echo "$u" >> "$YS_OPEN_LOG"; exit 0; fi   # selftest: record, don't open
PS=/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe
if [ ! -x "$PS" ]; then
  # not WSL (or no PowerShell): hand over to a real opener further down PATH, if any
  me="$(readlink -f "$0")"
  IFS=: ; for d in $PATH; do
    c="$d/xdg-open"; [ -x "$c" ] && [ "$(readlink -f "$c")" != "$me" ] && exec "$c" "$u"
  done
  echo "xdg-open: no browser opener — open this link by hand: $u" >&2; exit 3
fi
YS_URL="$u" WSLENV="YS_URL${WSLENV:+:$WSLENV}" "$PS" -NoProfile -NonInteractive -Command 'Start-Process -FilePath $env:YS_URL' \
  </dev/null >/dev/null 2>&1 &
exit 0
