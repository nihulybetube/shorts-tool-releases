# -*- coding: utf-8 -*-
"""
newpc.py — הצעד האחרון של ההתקנה במחשב חדש (20/10/2026).

מה זה עושה, ובשפה פשוטה: אחרי שהקוד הותקן והמוזיקה/הלוגו/ההגדרות שוחזרו מ-Drive, כאן
כותבים ל-config.env את ברירות המחדל שהכלי צריך (תיקיית הפלט, הלוגו, כיבוי הייצוב,
מודל התמלול), מסמנים באשף ההגדרה מה כבר קיים, ומריצים את "בדיקת המערכת" של החלון —
אותה אחת שהחלון מציג בפתיחה — ומדפיסים תוצאה קצרה.

כללים:
  - לא דורס ערך שכבר קיים ב-config.env (מפתח Gemini, נתיב Modal... נשארים כמו שהם).
  - לא מדפיס שום סוד.
  - אפשר להריץ כמה פעמים.

שימוש:  shorts.sh py ../setup/newpc.py [--check-only]      (או: venv/bin/python setup/newpc.py)
יציאה: 0 = הכול תקין או אזהרות בלבד; 1 = יש בדיקה שנכשלה (bad).
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "pipeline" / "scripts"))
import state  # noqa: E402


def main():
    check_only = "--check-only" in sys.argv
    cfg = state.config_dir()
    env = state.read_env()
    if not check_only:
        defaults = {
            "SHORTS_EXPORT_DIR": str(Path.home() / "Videos" / "Shorts"),
            "SHORTS_STABILIZE": "0",     # מחצובה: ייצוב מזיז את הפריים (16/9/2026)
            "SHORTS_MODEL": "ivrit-ai/whisper-large-v3-turbo-ct2",   # large-v3 מקומי נהרג מחוסר זיכרון
        }
        logo = cfg / "brand" / "logo.png"
        if logo.exists():
            defaults["SHORTS_LOGO"] = str(logo)
        added = {k: v for k, v in defaults.items() if not env.get(k)}
        if added:
            state.write_env(added)
            print("נכתבו ברירות מחדל ל-config.env:", ", ".join(sorted(added)))
        Path(added.get("SHORTS_EXPORT_DIR") or env.get("SHORTS_EXPORT_DIR") or defaults["SHORTS_EXPORT_DIR"]).mkdir(parents=True, exist_ok=True)
        # תמלול: ענן אם יש חשבון Modal שעובד, אחרת מקומי
        if not env.get("SHORTS_ASR"):
            state.write_env({"SHORTS_ASR": "local"})
        for step, ok in (("asr", True), ("export_dir", True), ("logo", logo.exists()), ("music", (Path(os.environ.get("SHORTS_DATA_DIR") or Path.home() / ".local/share/yeshiva-shorts") / "music" / "tracks").exists())):
            if ok:
                state.mark(step, "done", "הותקן במחשב חדש")
        for step in ("gemini", "cookies", "youtube_upload", "guidelines"):
            if step not in state.load()["steps"]:
                state.mark(step, "skipped", "נקבע מהחלון (הגדרות מתקדמות) — לא בהתקנה")

    import make_short_health as H
    res = H.run_all(drive_enabled=True)
    worst = 0
    print("בדיקת מערכת:")
    for r in res["results"]:
        icon = {"ok": "✓", "warn": "!", "bad": "✗"}.get(r["level"], "?")
        print("  %s %s" % (icon, r["title"]))
        if r["level"] != "ok":
            if r.get("detail"):
                print("      " + r["detail"])
            for s in r.get("steps", []):
                print("      · " + s)
        worst = max(worst, {"ok": 0, "warn": 0, "bad": 1}.get(r["level"], 0))
    return worst


if __name__ == "__main__":
    sys.exit(main())
