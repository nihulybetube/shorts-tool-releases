# -*- coding: utf-8 -*-
"""בדיקת סביבה מקצה לקצה — `shorts.sh doctor`.

הרעיון: הפייפליין נשען על שרשרת ארוכה (ffmpeg עם vidstab ו-libass, פונט
עברי, מפתח ג'מיני, מודל זיהוי פנים, נתיב תמלול). כשחוליה בה נשברת,
הסימפטום מופיע באמצע ריצה ארוכה ונראה כמו בעיה אחרת לגמרי. עדיף שתי
דקות בדיקה לפני, מ-40 דקות רינדור שנופלות על פונט חסר.

🚨 הבדיקה המרכזית היא **רינדור אמיתי של כתובית עברית** — "libass נטען"
לא אומר שהעברית יצאה, ושורה הפוכה או ריקה נראית תקינה בכל בדיקה אחרת.

שלב שהמשתמש דילג עליו ב-setup מוצג כ"דולג" ולא ככשל — אחרת כל הרצה
הייתה מציגה שני ❌ שאיש לא מתכוון לתקן, ואז מפסיקים להסתכל בפלט בכלל.
"""

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import state  # noqa: E402
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "pipeline" / "scripts"))
import tool_finder  # noqa: E402

LIB = Path(os.environ.get("SHORTS_LIB", Path(__file__).resolve().parent.parent / "assets"))
DATA = Path(os.environ.get("SHORTS_DATA_DIR",
                           Path.home() / ".local" / "share" / "yeshiva-shorts"))
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")

OK, WARN, BAD, SKIP = "✅", "⚠️ ", "❌", "⏭️ "
results = []


def check(name, fn):
    try:
        status, detail = fn()
    except Exception as e:  # noqa: BLE001
        status, detail = BAD, "%s: %s" % (type(e).__name__, str(e)[:180])
    results.append((status, name, detail))
    print("%s %-26s %s" % (status, name, detail), flush=True)


class _Missing:
    """תוצאה של פקודה שאין בכלל במכונה.

    🚨 `subprocess.run` על בינארי חסר **זורק** ולא מחזיר קוד יציאה, ולכן
    בדיקה שנועדה להחזיר אזהרה על כלי אופציונלי חסר מחזירה במקום זה
    FileNotFoundError אדום — כלומר בדיוק ההפך מהכוונה."""
    returncode = 127
    stdout = ""
    stderr = "not found"


def sh(cmd, **kw):
    try:
        return subprocess.run([str(c) for c in cmd], capture_output=True, text=True,
                              errors="replace", **kw)
    except (OSError, ValueError):
        return _Missing()


def c_ffmpeg():
    r = sh([FFMPEG, "-hide_banner", "-version"])
    if r.returncode:
        return BAD, "ffmpeg לא נמצא. התקן: install.sh, או apt/brew install ffmpeg"
    ver = r.stdout.splitlines()[0].split()[2]
    f = sh([FFMPEG, "-hide_banner", "-filters"]).stdout
    missing = [x for x in ("vidstabdetect", "vidstabtransform", "xfade", "ass ", "overlay ")
               if x not in f]
    if "ass " in missing:
        return BAD, "%s — בלי libass אין כתוביות בכלל" % ver
    if missing:
        return WARN, "%s — חסר: %s (הייצוב יידלג)" % (ver, ", ".join(x.strip() for x in missing))
    return OK, "%s · vidstab+libass" % ver


def c_font():
    p = LIB / "fonts" / "Heebo900.ttf"
    if not p.exists():
        return BAD, "Heebo900.ttf חסר ב-%s" % p.parent
    return OK, "%.0fKB" % (p.stat().st_size / 1024)


def c_render():
    """הבדיקה היחידה ששווה משהו: מרנדר כתובית עברית ומוודא שיצאו פיקסלים."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        ass = td / "t.ass"
        ass.write_text(
            "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
            "[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, "
            "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, "
            "Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
            "Style: Default,Heebo900,122,&H00FFFFFF,&H00101010,&H00000000,0,0,0,0,"
            "100,100,0,0,1,8,0,2,60,60,320,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, "
            "MarginV, Effect, Text\n"
            "Dialogue: 0,0:00:00.00,0:00:02.00,Default,,0,0,0,,"
            "‫שלום עולם, זה מבחן.‬\n",
            encoding="utf-8-sig")
        png = td / "frame.png"
        r = sh([FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi",
                "-i", "color=c=black:s=1080x1920:d=1",
                "-vf", "ass=%s:fontsdir=%s" % (ass, LIB / "fonts"),
                "-frames:v", "1", str(png)])
        if r.returncode or not png.exists():
            return BAD, "רינדור נכשל: %s" % (r.stderr or "")[-160:]
        sig = sh([FFMPEG, "-hide_banner", "-i", str(png), "-vf",
                  "signalstats,metadata=print:key=lavfi.signalstats.YMAX",
                  "-frames:v", "1", "-f", "null", "-"])
        ymax = 0.0
        for line in (sig.stderr or "").splitlines():
            if "YMAX" in line:
                try:
                    ymax = float(line.split("=")[-1])
                except ValueError:
                    pass
        if ymax < 200:
            return BAD, "הכתובית לא צוירה (YMAX=%s) — libass לא מצא את Heebo900" % ymax
        return OK, "כתובית עברית צוירה · YMAX=%.0f" % ymax


def c_python():
    have, miss = [], []
    for m in ("yt_dlp", "cv2", "numpy"):
        try:
            __import__(m)
            have.append(m)
        except ImportError:
            if m == "yt_dlp" and os.environ.get("SHORTS_YTDLP"):
                continue                      # נבחר yt-dlp חיצוני — המודול בסביבה לא נחוץ
            miss.append(m)
    if miss:
        return BAD, "חסרים מודולים: %s — הרץ install.sh שוב" % ", ".join(miss)
    return OK, ", ".join(have)


def c_gemini():
    key = os.environ.get("GEMINI_API_KEY") or state.read_env().get("GEMINI_API_KEY")
    if not key:
        return BAD, "אין מפתח — הרץ `shorts.sh setup`"
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from setup import probe_gemini  # noqa: PLC0415
    ok, msg = probe_gemini(key)
    return (OK, msg) if ok else (BAD, msg)


def c_asr():
    mode = state.read_env().get("SHORTS_ASR", "")
    if mode == "modal":
        if (Path.home() / ".modal.toml").exists() or os.environ.get("MODAL_TOKEN_ID"):
            try:
                import modal  # noqa: F401
                return OK, "Modal (ענן) · מוגדר"
            except ImportError:
                return BAD, "modal לא מותקן — pip install modal"
        return BAD, "Modal נבחר אבל אין טוקן — הרץ `modal token new`"
    if mode == "local":
        try:
            import faster_whisper  # noqa: F401
            return OK, "faster-whisper (מקומי)"
        except ImportError:
            return BAD, "faster-whisper לא מותקן — הרץ install.sh"
    return BAD, "לא נבחר נתיב תמלול — הרץ `shorts.sh setup`"


def c_face():
    """🚨 הכשל של זה **שקט**: `build_clean` נופל חזרה למעקב תנועה ומוציא
    קליף שהדובר בו לא במרכז, בלי שום שגיאה. לכן נבדק כאן."""
    model = LIB / "models" / "face_detection_yunet_2023mar.onnx"
    if not model.exists():
        return BAD, "חסר מודל YuNet — המיסגור ייפול למעקב תנועה"
    try:
        import cv2
    except ImportError:
        return BAD, "אין cv2 — pip install opencv-python-headless"
    cv2.FaceDetectorYN.create(str(model), "", (320, 320), score_threshold=0.5)
    return OK, "YuNet נטען · cv2 %s" % cv2.__version__


def c_export():
    d = os.environ.get("SHORTS_EXPORT_DIR") or state.read_env().get("SHORTS_EXPORT_DIR", "")
    if not d:
        return BAD, "לא נבחרה תיקיית פלט — הרץ `shorts.sh setup`"
    p = Path(d)
    try:
        p.mkdir(parents=True, exist_ok=True)
        t = p / ".write-test"
        t.write_text("ok", encoding="utf-8")
        t.unlink()
    except OSError as e:
        return BAD, "%s — אין הרשאת כתיבה (%s)" % (p, e.strerror)
    return OK, str(p)


def c_runtime():
    """איפה רצים: WSL / לינוקס / מק נתמכים; Windows בלי bash — לא (HANDOFF §11)."""
    rt = tool_finder.runtime()
    return (OK if rt["ok"] else BAD), "%s · python %s — %s" % (rt["kind"], rt["python"], rt["detail"])


_SCAN = {}


def _tool_status(tool_id):
    """מקור וגרסה של הכלי שנבחר בפועל (מובנה / מהמחשב / נתיב של המשתמש) + הערות."""
    if not _SCAN:
        _SCAN.update(tool_finder.scan())
    for t in _SCAN["tools"]:
        if t["id"] == tool_id:
            return t
    return None


def c_tool(tool_id, label):
    def fn():
        t = _tool_status(tool_id)
        cur = t and t["current"]
        if not cur:
            others = len(t["candidates"]) if t else 0
            return BAD, "%s: לא נמצא כלי תקין (%d מועמדים נבדקו) — הרץ install.sh או בחר נתיב בהגדרות ← כלים" % (label, others)
        src = {"builtin": "מובנה", "system": "מהמחשב", "env": "ממשתנה סביבה",
               "custom": "נתיב שבחרת"}[cur["source"]]
        note = ("; " + "; ".join(cur["issues"])) if cur.get("issues") else ""
        lvl = {"ok": OK, "warn": WARN, "bad": BAD}[cur["level"]]
        return lvl, "%s · %s · %s%s" % (cur["version"] or "?", src, cur["path"], note)
    return fn


def c_asr_engines():
    s = _SCAN or tool_finder.scan()
    if not _SCAN:
        _SCAN.update(s)
    eng = {e["id"]: e for e in s["asr"]["engines"]}
    sel = s["asr"]["selected"]
    desc = ", ".join("%s %s" % (e["name"].split(" (")[0], "✓" if e["ok"] else "✗") for e in eng.values())
    if sel in eng and not eng[sel]["ok"]:
        other = [e for k, e in eng.items() if k != sel and e["ok"]]
        return WARN, "נבחר %s אבל הוא לא מוכן (%s)%s" % (
            sel, "; ".join(eng[sel]["issues"]), " — %s כן זמין" % other[0]["name"] if other else "")
    return OK, desc

def c_deno():
    """בלי Deno ההורדה נכשלת **בשקט**: yt-dlp פותר את אתגר ה-n של יוטיוב
    במנוע JS חיצוני, ובלעדיו `-F` מחזיר רק storyboards ושורת WARNING."""
    for exe in ("deno", "node"):
        r = sh([exe, "--version"])
        if r.returncode == 0:
            return OK, "%s %s" % (exe, (r.stdout or "").split("\n")[0])
    return WARN, "אין Deno/Node — הורדות מיוטיוב עלולות להחזיר רק storyboards"


def c_cookies():
    if state.status_of("cookies") == "skipped":
        return SKIP, "דילגת על זה (`setup --redo cookies` כדי להוסיף)"
    p = Path(state.config_dir()) / "youtube_cookies.txt"
    if not p.exists():
        return WARN, "אין קובץ עוגיות — צריך רק אם ההורדה נחסמת"
    age_d = (Path(p).stat().st_mtime)
    import time as _t
    days = (_t.time() - age_d) / 86400
    if days > 21:
        return WARN, "קיים אבל בן %.0f ימים — עוגיות יוטיוב מתיישנות" % days
    return OK, "קיים · בן %.0f ימים" % days


def c_optional(step_id, label, present_fn):
    def fn():
        if state.status_of(step_id) == "skipped":
            return SKIP, "דילגת על זה (`setup --redo %s` כדי להוסיף)" % step_id
        ok, detail = present_fn()
        return (OK if ok else WARN), detail
    fn.__name__ = "c_" + step_id
    return fn


def _logo():
    p = state.read_env().get("SHORTS_LOGO", "")
    if p and Path(p).exists():
        return True, p
    return False, "לא מוגדר — הקליפים ייצאו בלי מיתוג"


def _music():
    # שני מקורות: הספרייה שהכלי מוריד, או תיקייה של המשתמש. השאלה
    # היחידה שמעניינת היא האם יש **קובץ מנוגן** — אינדקס בלי mp3 הוא
    # ספרייה ריקה שנראית מלאה.
    data = os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts")
    tracks = Path(data) / "music" / "tracks"
    n = len(list(tracks.glob("*.mp3"))) if tracks.is_dir() else 0
    if n:
        missing = [f for f in tracks.glob("*.mp3") if not Path(str(f) + ".license.json").exists()]
        if missing:
            # 🚨 קובץ בלי רישיון ליד הוא בדיוק מה שאי אפשר להגן עליו
            # בתלונת זכויות יוצרים. עדיף לדעת עכשיו ולא אחרי הערעור.
            return False, "%d טראקים, אבל ל-%d אין קובץ רישיון" % (n, len(missing))
        return True, "%d טראקים בספרייה" % n
    d = state.read_env().get("SHORTS_MUSIC_DIR", "")
    if d and Path(d).is_dir():
        return True, "%d קבצים (תיקייה שלך)" % len(list(Path(d).glob("*.mp3")))
    return False, "לא מוגדר — לא תיווצר גרסה עם מוזיקה"


def _yt():
    if (Path(state.config_dir()) / "client_secret.json").exists():
        return True, "client_secret מותקן"
    return False, "לא מוגדר — העלאה ליוטיוב תהיה ידנית"


def c_sandbox():
    """4.1.0: «תקן שורט זה בצ'אט» עם סקריפט דורש bubblewrap. בלעדיו רק תיקוני כתוביות (החלפת טקסט) עובדים — לא תקלה."""
    exe = shutil.which("bwrap")
    if not exe:
        return WARN, "bubblewrap לא מותקן — תיקון בצ'אט באמצעות סקריפט לא יפעל (תיקון כתוביות כן). להתקנה (דורש סיסמת מנהל): sudo apt install bubblewrap"
    try:
        r = subprocess.run([exe, "--unshare-all", "--ro-bind", "/usr", "/usr", "--symlink", "usr/lib", "/lib", "--symlink", "usr/lib64", "/lib64",
                            "--symlink", "usr/bin", "/bin", "/usr/bin/true"], capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        return WARN, "bubblewrap קיים אבל לא רץ: %s" % e
    return (OK, "bubblewrap תקין (בידוד לסקריפט של הצ'אט)") if r.returncode == 0 else \
        (WARN, "bubblewrap קיים אבל לא מצליח לבנות בידוד כאן: %s" % (r.stderr or "").strip()[:100])


def c_disk():
    DATA.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(str(DATA)).free / 1e9   # לא statvfs: עובד גם בלי POSIX
    return (OK if free > 10 else WARN), "%.0fGB פנוי" % free


def main():
    print("בדיקת סביבה — הפקת שורטס\n")
    check("מערכת הרצה", c_runtime)
    check("ffmpeg", c_ffmpeg)
    check("פונט Heebo900", c_font)
    check("רינדור כתובית עברית", c_render)
    check("מודולי פייתון", c_python)
    check("מפתח Gemini", c_gemini)
    check("תמלול", c_asr)
    check("מעקב פנים (מיסגור)", c_face)
    check("תיקיית הפלט", c_export)
    check("Deno (אתגר n)", c_deno)
    check("כלי: ffmpeg נבחר", c_tool("ffmpeg", "ffmpeg"))
    check("כלי: ffprobe נבחר", c_tool("ffprobe", "ffprobe"))
    check("כלי: yt-dlp נבחר", c_tool("ytdlp", "yt-dlp"))
    check("כלי: Deno נבחר", c_tool("deno", "Deno"))
    check("מנועי תמלול", c_asr_engines)
    check("עוגיות יוטיוב", c_cookies)
    check("לוגו", c_optional("logo", "לוגו", _logo))
    check("מוזיקת רקע", c_optional("music", "מוזיקה", _music))
    check("העלאה ליוטיוב", c_optional("youtube_upload", "יוטיוב", _yt))
    check("בידוד לתיקון בצ'אט", c_sandbox)
    check("מקום בדיסק", c_disk)

    bad = [r for r in results if r[0] == BAD]
    warn = [r for r in results if r[0] == WARN]
    skip = [r for r in results if r[0] == SKIP]
    print("\n%d תקינים · %d אזהרות · %d דולגו · %d כשלים"
          % (len(results) - len(bad) - len(warn) - len(skip), len(warn), len(skip), len(bad)))
    for _, n, d in bad:
        print("  ❌ %s — %s" % (n, d))
    for _, n, d in warn:
        print("  ⚠️  %s — %s" % (n, d))
    if bad:
        print("\nרוב הכשלים נסגרים בהרצה אחת:  shorts.sh setup")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
