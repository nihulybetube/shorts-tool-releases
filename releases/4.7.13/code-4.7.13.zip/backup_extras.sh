#!/bin/bash
# backup_extras.sh — גיבוי (ושחזור) של מה שאין בגיט: ספריית המוזיקה, ההגדרות, הלוגו וההנחיות.
#
# למה: הקוד שמור ב-GitHub, וההפקות המוכנות ב-drive_backup.sh. אבל כדי שהכלי יעבוד אחרי
# מעבר למחשב אחר צריך גם את מה שנאסף לאורך הזמן — 30 קטעי מוזיקה עם הרישיונות והדירוגים
# (כולל רשימת הנפסלים, כדי שלא יחזרו), ההגדרות שבחר, הלוגו, וקובץ ההנחיות האישי.
#
# 🚨 סודות לא עוברים כאן לעולם: config.env, עוגיות, טוקנים, rclone.conf. הסינון קשיח בקובץ
# הזה (ולא "מי שזוכר לא לשים") — ואם קובץ כזה בכל זאת נמצא בעץ הגיבוי, הריצה נעצרת.
#
#   backup_extras.sh backup     # מהמחשב → ל-Drive (תיקייה "גיבוי תוכנה", בצד של "שורטסים מוכנים")
#   backup_extras.sh restore    # מה-Drive → למחשב (לא דורס קובץ חדש יותר שכבר קיים)
#   backup_extras.sh list       # מה יש ב-Drive ובאיזה גודל
#   backup_extras.sh memory     # רק הזיכרון של Claude (3.4) — גם חלק מ-backup
#   backup_extras.sh kit        # 4.6: רק תיקיית "שחזור למחשב חדש" (קוד + תוכנית שחזור + הכספת המוצפנת) — גם חלק מ-backup
#
# זה העתקה ולא מראה: קובץ שנמחק כאן לא נמחק ב-Drive (מוזיקה שנפסלה נשמרת כרישיון בלבד).
#
# 16/11 (3.4, באישורו): גם הזיכרון של Claude — כל הכללים שנלמדו בעבודה איתו — לתיקייה claude/:
# רק רשימה סגורה: <בית ווינדוס>/.claude/CLAUDE.md, <בית>/.claude/projects/*/memory/*.md,
# <בית>/yeshiva-shorts/CLAUDE.md. שום דבר אחר מתוך .claude (לא .credentials.json, לא שיחות, לא הגדרות).
# הבית בווינדוס: CLAUDE_WIN_HOME, אחרת %USERPROFILE%. אין תיקיית .claude (מי שקיבל את התוכנה) — מדלג בשקט.
# התוכנה מריצה backup פעם ביום ברקע (make_short_app.extras_watch); מודיעה רק אם נכשל יותר מיום.
set -uo pipefail
export PATH="$HOME/.local/bin:$PATH"

CONFIG="${SHORTS_CONFIG_DIR:-${XDG_CONFIG_HOME:-$HOME/.config}/yeshiva-shorts}"
DATA="${SHORTS_DATA_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/yeshiva-shorts}"
MUSIC="$DATA/music"
REMOTE="${EXTRAS_REMOTE:-gdrive:גיבוי תוכנה}"
LOG="$DATA/logs/backup_extras.log"
mkdir -p "$DATA/logs"
# 4.1.0: יומן שלא גדל בלי סוף — מעל 1MB הוא עובר ל-.1 (ישן נמחק)
if [ -f "$LOG" ] && [ "$(stat -c %s "$LOG" 2>/dev/null || echo 0)" -gt 1048576 ]; then mv -f "$LOG" "$LOG.1"; fi
# 4.1.0: שתי הרצות במקביל (ידנית + היומית) היו דורסות זו את זו — רק אחת רצה, השנייה יוצאת בשקט (קוד 75)
case "${1:-}" in backup|restore|memory|kit)
  command -v flock >/dev/null && { exec 9>"$DATA/backup_extras.lock"; flock -n 9 || { echo "גיבוי אחר כבר רץ עכשיו — מדלג" >&2; exit 75; }; } ;;
esac
DAY="$(date +%F)"

command -v rclone >/dev/null || { echo "rclone חסר (~/.local/bin/rclone)" >&2; exit 1; }
# יעד מקומי (EXTRAS_REMOTE=/נתיב — הבדיקה העצמית) לא צריך את הדרייב
case "$REMOTE" in /*) ;; *) rclone lsd gdrive: >/dev/null 2>&1 || { echo "אין חיבור ל-Drive (gdrive:) — לחבר מחדש: rclone config reconnect gdrive:" >&2; exit 1; } ;; esac

# מה שלעולם לא עובר (בנוסף לכך שאנחנו מעתיקים רק רשימה מפורשת של נתיבים)
SECRET_FILTER=(--filter '- *.env' --filter '- *.env.bak' --filter '- *cookie*' --filter '- *token*'
               --filter '- *secret*' --filter '- *credential*' --filter '- rclone.conf' --filter '- *.toml'
               --filter '- *.pem' --filter '- *.key')

# 4.1.0: כל דריסה ב-Drive שומרת את הגרסה הקודמת ב-_old/<תאריך>/<יעד> (בלי היסטוריה, גיבוי תקול היה מוחק את הטוב)
cp_up() {   # cp_up <מקור> <יעד-ב-Drive> [פילטרים...]  — קובץ או תיקייה
  local src="$1" dst="$2"; shift 2
  [ -e "$src" ] || { echo "  (אין $src — מדלג)"; return 0; }
  local hist=(--backup-dir "$REMOTE/_old/$DAY/$dst")
  if [ -L "$src" ]; then echo "  (⚠ $src הוא קישור סמלי — לא מגבה, כדי לא לצאת מהתיקייה)"; return 0
  elif [ -d "$src" ]; then
    rclone copy "$src" "$REMOTE/$dst" "${SECRET_FILTER[@]}" "${hist[@]}" "$@" --log-file "$LOG" --log-level INFO
  elif [ -f "$src" ]; then
    rclone copyto "$src" "$REMOTE/$dst" "${hist[@]}" --log-file "$LOG" --log-level INFO
  else echo "  (⚠ $src אינו קובץ רגיל — מדלג)"; fi
}
# 4.1.0: לפני שחזור — קובץ מקומי חדש יותר ושונה מזה שב-Drive לא נדרס, אבל נשמר גם כ-<שם>.bak
bak_newer_local() {   # bak_newer_local <תיקייה ב-Drive> <תיקייה מקומית> [שם קובץ יחיד]
  rclone lsjson -R --files-only --no-mimetype --hash "$1" 2>/dev/null | python3 -c '
import json, os, re, sys, shutil, hashlib, datetime
loc, only = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else "")
try: items = json.load(sys.stdin)
except ValueError: items = []
for it in items:
    rel = it["Path"]
    if only and rel != only: continue
    p = os.path.join(loc, rel)
    if not os.path.isfile(p) or os.path.islink(p): continue
    try:
        ts = re.sub(r"(\.\d{6})\d+", r"\1", it["ModTime"].replace("Z", "+00:00"))   # rclone נותן עד 9 ספרות
        rm = datetime.datetime.fromisoformat(ts).timestamp()
    except Exception: continue
    if os.path.getmtime(p) <= rm + 2: continue
    h = (it.get("Hashes") or {}).get("md5")
    same = (hashlib.md5(open(p, "rb").read()).hexdigest() == h) if h else (os.path.getsize(p) == it.get("Size"))
    if not same:
        shutil.copy2(p, p + ".bak"); print("  נשמר גם עותק: " + rel + ".bak")
' "$2" "${3:-}"
}
down_dir() {   # down_dir <תיקייה ב-Drive> <יעד מקומי>
  if rclone lsf "$REMOTE/$1" >/dev/null 2>&1; then
    mkdir -p "$2"; bak_newer_local "$REMOTE/$1" "$2"
    rclone copy "$REMOTE/$1" "$2" --update --backup-dir "$DATA/restore_old/$DAY/$1" "${SECRET_FILTER[@]}" --log-file "$LOG" --log-level INFO
  else echo "  (אין ב-Drive: $1 — מדלג)"; fi
}
down_file() {  # down_file <קובץ ב-Drive> <יעד מקומי>
  if rclone lsf "$(dirname "$REMOTE/$1")" --files-only 2>/dev/null | grep -Fxq "$(basename "$1")"; then
    mkdir -p "$(dirname "$2")"; bak_newer_local "$(dirname "$REMOTE/$1")" "$(dirname "$2")" "$(basename "$1")"
    rclone copyto "$REMOTE/$1" "$2" --update --backup-dir "$DATA/restore_old/$DAY/$1" --log-file "$LOG" --log-level INFO
  else echo "  (אין ב-Drive: $1 — מדלג)"; fi
}
win_home() {   # תיקיית המשתמש בווינדוס כנתיב WSL (/mnt/c/Users/...), או כלום
  if [ -n "${CLAUDE_WIN_HOME:-}" ]; then echo "$CLAUDE_WIN_HOME"; return 0; fi
  [ -x /mnt/c/Windows/System32/cmd.exe ] || return 0
  local w; w="$(cd /mnt/c && /mnt/c/Windows/System32/cmd.exe /c 'echo %USERPROFILE%' 2>/dev/null | tr -d '\r' | tail -1)"
  [ -n "$w" ] && wslpath -u "$w" 2>/dev/null
  return 0
}
# רשימה לבנה בלבד (הסדר חשוב: קודם הסודות החוצה, אחר כך רק שני הדפוסים, וכל השאר החוצה)
MEM_FILTER=(--filter '- .credentials*' --filter '+ /CLAUDE.md' --filter '+ /projects/*/memory/*.md' --filter '- **')
# 4.1.0: מעוגן לסוף השם — "x.environment.mp3" כבר לא נחשב דליפה. (שמות עם token/secret נסננים ומדווחים, ראו report_dropped)
LEAK_RE='cookie|token|secret|credential|(^|/)rclone\.conf$|\.(env|env\.bak|toml|pem|key)$'
# 4.1.0: תוכן שנראה כמו מפתח בתוך קובץ .md של הזיכרון — הקובץ לא עולה (אזהרה בלבד)
KEY_RE='AIza[0-9A-Za-z_-]{20,}|GOCSPX-|\bsk-[A-Za-z0-9_-]{16,}|MODAL_TOKEN[A-Z_]*[[:space:]]*[=:][[:space:]]*["'"'"']?[A-Za-z0-9_-]{8,}|-----BEGIN'
key_filters() {   # key_filters <שורש> <קבצים יחסיים...> — מדפיס פילטרי החרגה לקבצים עם מפתח
  local root="$1" f; shift
  for f in "$@"; do
    [ -f "$root/$f" ] && grep -Eaq "$KEY_RE" "$root/$f" 2>/dev/null && { echo "  ⚠ $f נראה כמו שמכיל מפתח או סיסמה — לא הועלה" >&2; echo "- /$f"; }
  done
}
report_dropped() {   # report_dropped <תיקייה> [פילטרים...] — קבצים שנשארו מחוץ לגיבוי בגלל שם שנראה כמו סוד; ובדיקה: מה שיעלה לא דולף
  local d="$1"; shift
  [ -d "$d" ] || return 0
  local all kept
  all="$(rclone lsf -R --files-only "$d" "$@" 2>/dev/null | LC_ALL=C sort)"
  kept="$(rclone lsf -R --files-only "$d" "${SECRET_FILTER[@]}" "$@" 2>/dev/null | LC_ALL=C sort)"
  local hard; hard="$(echo "$kept" | grep -Ei '(^|/)rclone\.conf$|\.(env|env\.bak|toml|pem|key)$|cookie|credential' || true)"
  [ -z "$hard" ] || { echo "🚨 לפני ההעלאה: בקבצים שעומדים לעלות יש שם שנראה כמו סוד ($d):" >&2; echo "$hard" >&2; return 2; }
  local drop; drop="$(LC_ALL=C comm -23 <(echo "$all") <(echo "$kept") | grep -v '^$' || true)"
  [ -z "$drop" ] || { echo "  ⚠ לא הועלו (השם נראה כמו סוד; אם הקובץ תקין — לשנות לו שם): $(echo "$drop" | head -5 | tr '\n' ' ')" | tee -a "$LOG" >&2; }
  return 0
}
backup_memory() {
  local wh; wh="$(win_home)"
  if [ -z "$wh" ] || [ ! -d "$wh/.claude" ]; then echo "  (אין תיקיית Claude במחשב — מדלג על הזיכרון)"; return 0; fi
  local keyf=() line rel
  while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    while IFS= read -r line; do [ -n "$line" ] && keyf+=(--filter "$line"); done < <(key_filters "$wh/.claude" "$rel")
  done < <(cd "$wh/.claude" && { [ -f CLAUDE.md ] && echo CLAUDE.md; ls projects/*/memory/*.md 2>/dev/null; })
  report_dropped "$wh/.claude" "${keyf[@]}" "${MEM_FILTER[@]}" || return $?
  rclone copy "$wh/.claude" "$REMOTE/claude" "${SECRET_FILTER[@]}" "${keyf[@]}" "${MEM_FILTER[@]}" --max-depth 4 \
    --backup-dir "$REMOTE/_old/$DAY/claude" --log-file "$LOG" --log-level INFO || return 1
  if [ -z "$(key_filters "$wh/yeshiva-shorts" CLAUDE.md)" ]; then
    cp_up "$wh/yeshiva-shorts/CLAUDE.md" "claude/yeshiva-shorts/CLAUDE.md" || return 1
  fi
  # בדיקת ביטחון: בתיקיית הזיכרון ב-Drive רק קבצי .md, ושום שם שנראה כמו סוד
  local bad; bad="$(rclone lsf -R --files-only "$REMOTE/claude" 2>/dev/null | grep -Eiv '\.md$' ; \
                    rclone lsf -R "$REMOTE/claude" 2>/dev/null | grep -Ei "$LEAK_RE" || true)"
  [ -z "$bad" ] || { echo "🚨 בתיקיית הזיכרון ב-Drive יש קובץ שלא אמור להיות שם:" >&2; echo "$bad" >&2; return 2; }
  echo "  זיכרון Claude: $(rclone lsf -R --files-only "$REMOTE/claude" 2>/dev/null | wc -l) קבצים ב-Drive"
}
restore_memory() {
  local wh; wh="$(win_home)"
  if [ -z "$wh" ] || [ ! -d "$wh" ]; then echo "  (לא מצאתי את תיקיית המשתמש בווינדוס — מדלג על הזיכרון)"; return 0; fi
  if rclone lsf "$REMOTE/claude" >/dev/null 2>&1; then
    mkdir -p "$wh/.claude"; bak_newer_local "$REMOTE/claude" "$wh/.claude"
    rclone copy "$REMOTE/claude" "$wh/.claude" --update --backup-dir "$DATA/restore_old/$DAY/claude" "${SECRET_FILTER[@]}" "${MEM_FILTER[@]}" --log-file "$LOG" --log-level INFO
    down_file "claude/yeshiva-shorts/CLAUDE.md" "$wh/yeshiva-shorts/CLAUDE.md"
  else echo "  (אין ב-Drive: claude — מדלג)"; fi
}
# 4.6: ערכת השחזור למחשב חדש → "$REMOTE/שחזור למחשב חדש" (מראה: רק הגרסה האחרונה; הקודמת נשמרת ב-_old/<תאריך>).
# הכספת עולה רק אם היא באמת מוצפנת (יש ct, kdf=scrypt, ורק שדות הכותרת המוכרים). ערכה שלא נבנתה לא מפילה את הגיבוי הרגיל.
KIT_NAME="שחזור למחשב חדש"
upload_kit() {
  local here py kit="$DATA/restore_kit"
  here="$(cd "$(dirname "$0")" && pwd)"
  py="$DATA/venv/bin/python"; [ -x "$py" ] || py=python3
  "$py" "$here/pipeline/scripts/make_short_vault.py" kit --quiet || { echo "  ⚠ ערכת השחזור לא נבנתה" >&2; return 4; }
  [ -f "$kit/kit/kit.json" ] || return 4
  if [ -f "$kit/vault.enc" ] && ! python3 -c '
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
ok = d.get("v") == 1 and d.get("kind") == "yeshiva-shorts-vault" and d.get("ct") and d.get("kdf") == "scrypt"
sys.exit(0 if ok and set(d) <= {"v", "kind", "kdf", "n", "r", "p", "salt", "nonce", "made", "items", "ct"} else 1)
' "$kit/vault.enc"; then
    echo "🚨 vault.enc לא נראה מוצפן — לא מעלה את ערכת השחזור" >&2; return 2
  fi
  rclone sync "$kit" "$REMOTE/$KIT_NAME" "${SECRET_FILTER[@]}" --backup-dir "$REMOTE/_old/$DAY/$KIT_NAME" \
    --log-file "$LOG" --log-level INFO || return 1
  echo "  ערכת שחזור: $(rclone lsf -R --files-only "$REMOTE/$KIT_NAME" 2>/dev/null | wc -l) קבצים ב-Drive"
}
case "${1:-}" in
  memory)
    echo "=== $(date '+%F %T') memory" >>"$LOG"
    backup_memory; exit $?
    ;;
  kit)
    echo "=== $(date '+%F %T') kit" >>"$LOG"
    upload_kit; exit $?
    ;;
  backup)
    echo "=== $(date '+%F %T') backup" >>"$LOG"
    backup_memory || exit $?
    # 4.1.0: בדיקה לפני ההעלאה (לא אחריה): שמות חשודים מדווחים, ואם משהו שנראה כמו סוד עומד לעלות — עוצרים
    for d in "$MUSIC/tracks" "$CONFIG/rabbis" "$CONFIG/share_profiles"; do report_dropped "$d" || exit $?; done
    cp_up "$MUSIC/tracks"        "music/tracks"
    cp_up "$MUSIC/_rejected"     "music/_rejected"   --filter '+ *.license.json' --filter '- *'
    cp_up "$MUSIC/index.json"    "music/index.json"
    cp_up "$MUSIC/_refs/mix.py"  "music/_refs/mix.py"
    cp_up "$CONFIG/music-feedback.json"       "config/music-feedback.json"
    cp_up "$CONFIG/make_short_settings.json"  "config/make_short_settings.json"
    cp_up "$CONFIG/guidelines.txt"            "config/guidelines.txt"
    cp_up "$CONFIG/brand/logo.png"            "config/brand/logo.png"
    cp_up "$CONFIG/glossary.json"             "config/glossary.json"
    cp_up "$CONFIG/rabbis"                    "config/rabbis"   --filter '- *.prev.json'   # כרטיס 25: פרופיל לכל רב
    # 3.5: פרופילים למקבלים של חבילת השיתוף (בלי פח המחיקה ובלי קבצי ביניים)
    [ -d "$CONFIG/share_profiles" ] && cp_up "$CONFIG/share_profiles" "config/share_profiles" \
      --filter '- _deleted/**' --filter '- *.tmp'
    # 4.3: מפתח החתימה של העדכונים — רק העותק המוצפן (release_key.enc), ורק אם הוא באמת מוצפן (יש בו "ct" ואין בו גרעין גלוי)
    if [ -f "$CONFIG/release_key.enc" ] && python3 -c '
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
sys.exit(0 if d.get("v") == 1 and d.get("ct") and d.get("kdf") == "scrypt" and not any(k in d for k in ("seed", "private", "priv")) else 1)
' "$CONFIG/release_key.enc"; then
      cp_up "$CONFIG/release_key.enc"         "config/release_key.enc"
    elif [ -f "$CONFIG/release_key.enc" ]; then
      echo "🚨 release_key.enc לא נראה מוצפן — לא מעלה אותו ל-Drive" >&2; exit 2
    fi
    # 4.5.62: כתובת הריפו הציבורי של העדכונים (לא סוד) + מפתח ההצעות של הבעלים — רק העותק המוצפן (proposals_owner.enc),
    # ורק אם הוא באמת מוצפן. proposals_owner.key עצמו לעולם לא עולה (SECRET_FILTER חוסם *.key).
    [ -f "$CONFIG/release.json" ] && cp_up "$CONFIG/release.json" "config/release.json"
    if [ -f "$CONFIG/proposals_owner.enc" ] && python3 -c '
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
sys.exit(0 if d.get("v") == 1 and d.get("ct") and d.get("kdf") == "scrypt" and not any(k in d for k in ("x25519", "ed25519", "key", "private", "seed")) else 1)
' "$CONFIG/proposals_owner.enc"; then
      cp_up "$CONFIG/proposals_owner.enc"     "config/proposals_owner.enc"
    elif [ -f "$CONFIG/proposals_owner.enc" ]; then
      echo "🚨 proposals_owner.enc לא נראה מוצפן — לא מעלה אותו ל-Drive" >&2; exit 2
    fi
    upload_kit; kr=$?
    [ "$kr" = 2 ] && exit 2                  # רק "נראה לא מוצפן" עוצר; ערכה שלא נבנתה/עלתה — הגיבוי הרגיל ממשיך (נרשם ביומן)
    # ספירה: כל מה שבמוזיקה המקומית עלה (סינון הסודות לא "אכל" שם של קטע)
    n_loc=$(rclone lsf --files-only "$MUSIC/tracks" "${SECRET_FILTER[@]}" 2>/dev/null | wc -l); n_rem=$(rclone lsf "$REMOTE/music/tracks" 2>/dev/null | wc -l)
    [ "$n_loc" = "$n_rem" ] || { echo "🚨 במוזיקה המקומית $n_loc קבצים ובדרייב $n_rem" >&2; exit 3; }
    # בדיקת ביטחון: שום דבר שנראה כמו סוד לא נמצא בעץ הגיבוי
    leaked="$(rclone lsf -R "$REMOTE" --exclude '/_old/**' 2>/dev/null | grep -Ei "$LEAK_RE" || true)"
    [ -z "$leaked" ] || { echo "🚨 נמצא ב-Drive קובץ שנראה כמו סוד:" >&2; echo "$leaked" >&2; exit 2; }
    echo "גיבוי הושלם. מה יש ב-Drive:"
    rclone size "$REMOTE" 2>/dev/null
    ;;
  restore)
    echo "=== $(date '+%F %T') restore" >>"$LOG"
    down_dir  "music/tracks"        "$MUSIC/tracks"
    down_dir  "music/_rejected"     "$MUSIC/_rejected"
    down_file "music/index.json"    "$MUSIC/index.json"
    down_file "music/_refs/mix.py"  "$MUSIC/_refs/mix.py"
    down_file "config/music-feedback.json"       "$CONFIG/music-feedback.json"
    down_file "config/make_short_settings.json"  "$CONFIG/make_short_settings.json"
    down_file "config/guidelines.txt"            "$CONFIG/guidelines.txt"
    down_file "config/brand/logo.png"            "$CONFIG/brand/logo.png"
    down_file "config/glossary.json"             "$CONFIG/glossary.json"
    down_dir  "config/rabbis"                    "$CONFIG/rabbis"
    down_dir  "config/share_profiles"            "$CONFIG/share_profiles"   # 3.5
    down_file "config/release_key.enc"           "$CONFIG/release_key.enc"  # 4.3 (מוצפן — צריך את הסיסמה כדי לפתוח)
    down_file "config/release.json"              "$CONFIG/release.json"     # 4.5.62
    down_file "config/proposals_owner.enc"       "$CONFIG/proposals_owner.enc"   # 4.5.62 (מוצפן — מפתח ההצעות של הבעלים)
    restore_memory
    echo "שוחזר. ספירה: $(ls "$MUSIC/tracks" 2>/dev/null | grep -c '\.mp3$') קטעי מוזיקה"
    ;;
  list)
    rclone lsf -R --max-depth 3 "$REMOTE" 2>&1 | head -80
    rclone size "$REMOTE" 2>&1
    ;;
  *) sed -n 2,24p "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
