# -*- coding: utf-8 -*-
"""4.6 — בודק ומכין את ערכת השחזור במחשב חדש. פייתון רגיל בלבד (בלי ספריות): רץ ב-Ubuntu טרייה לפני שמשהו הותקן.

נקרא מתוך restore.ps1 (תוכנית השחזור שבתיקייה "שחזור למחשב חדש" ב-Drive):
  python3 -I restore_kit.py verify  <תיקיית הערכה>              → בודק לפני כל התקנה; קוד 0 = תקין
  python3 -I restore_kit.py stage   <תיקיית הערכה> <יעד>         → בודק שוב, ומחלץ לתבנית של חבילה (code/ + package.json + extras/)
  python3 -I restore_kit.py compare <תיקיית הערכה> <בית לינוקס>  → newer / same / older / none  (האם הקוד שבערכה חדש מהמותקן)

מה נבדק: (1) הגיבוב (sha256) והגודל של ארכיון הקוד = מה שכתוב במניפסט; (2) כל קובץ בארכיון = הגיבוב שלו במניפסט, ואין
קבצים עודפים או נתיבים מסוכנים; (3) בערכה חתומה — חתימת Ed25519 על המניפסט במפתח שבערכה, והמפתח הזה הוא גם המפתח
שהקוד עצמו סומך עליו (assets/release_source.json). ערכה לא חתומה (עוד אין מפתח חתימה) — רק (1)+(2), ונאמר זאת במפורש.
גבול האמון: הכול מגיע מאותה תיקייה ב-Drive שלו. החתימה מוודאת שזה בדיוק קוד שפורסם — לא מגינה ממי שהשתלט על החשבון.
"""
import base64
import hashlib
import json
import os
import re
import sys
import zipfile
from pathlib import Path

MAX_ARCHIVE = 120 << 20

# ─────────────────────────── Ed25519 (RFC 8032) — אימות בפייתון טהור ───────────────────────────
# <ED25519-COPY-BEGIN> (העתק מדויק מ-make_short_release.py; בדיקה עצמית מוודאת שהם זהים)
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _inv(x):
    return pow(x, _P - 2, _P)


def _xrecover(y):
    xx = (y * y - 1) * _inv(_D * y * y + 1)
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if x % 2:
        x = _P - x
    return x


_BY = 4 * _inv(5) % _P
_B = (_xrecover(_BY) % _P, _BY)


def _add(a, b):
    x1, y1 = a
    x2, y2 = b
    t = _D * x1 * x2 * y1 * y2
    return ((x1 * y2 + x2 * y1) * _inv(1 + t) % _P, (y1 * y2 + x1 * x2) * _inv(1 - t) % _P)


def _mul(pt, e):
    r, q = (0, 1), pt
    while e:
        if e & 1:
            r = _add(r, q)
        q = _add(q, q)
        e >>= 1
    return r


def _decode(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= _P:
        return None
    x = _xrecover(y)
    if (-x * x + y * y - 1 - _D * x * x * y * y) % _P:
        return None
    if x == 0 and sign:
        return None
    if x & 1 != sign:
        x = _P - x
    return (x, y)


def ed25519_verify(pub, msg, sig):
    """True רק אם sig (64 בתים) היא חתימה תקפה של msg ע"י המפתח הציבורי pub (32 בתים). אף פעם לא זורק."""
    try:
        if len(pub) != 32 or len(sig) != 64:
            return False
        a, r = _decode(pub), _decode(sig[:32])
        s = int.from_bytes(sig[32:], "little")
        if a is None or r is None or s >= _Q:
            return False
        if _mul(a, 8) == (0, 1) or _mul(r, 8) == (0, 1):        # נקודות מסדר קטן — חתימה "מקרית" שמתאימה לכל הודעה
            return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _Q
        return _mul(_B, s) == _add(r, _mul(a, h))
    except Exception:
        return False
# <ED25519-COPY-END>


def _safe(p):
    if not isinstance(p, str) or not p or p.startswith("/") or "\\" in p or "\x00" in p:
        return False
    parts = p.split("/")
    return not any(x in ("", ".", "..", ".git") for x in parts)


def _key_id(pub_b64):
    return hashlib.sha256(base64.b64decode(pub_b64)).hexdigest()[:8]


def verify(kit_dir):
    """{"ok", "msg", "version", "signed", "key_id"} — msg בעברית פשוטה."""
    d = Path(kit_dir)
    bad = lambda m: {"ok": False, "msg": m, "version": "", "signed": False, "key_id": ""}  # noqa: E731
    try:
        k = json.loads((d / "kit" / "kit.json").read_text(encoding="utf-8"))
        raw = (d / "kit" / "manifest.json").read_bytes()
        m = json.loads(raw.decode("utf-8"))
    except (OSError, ValueError):
        return bad("חסרים קבצים בערכה (kit). לחלץ שוב את כל ה-zip שהורד מה-Drive ולנסות שוב.")
    if hashlib.sha256(raw).hexdigest() != k.get("manifest_sha256"):
        return bad("המניפסט שבערכה השתנה או נפגם — לא מתקינים. להוריד שוב את התיקייה מה-Drive.")
    ver = str(k.get("version") or "")
    if not re.fullmatch(r"\d{1,4}\.\d{1,4}\.\d{1,4}", ver) or m.get("version") != ver:
        return bad("מספר הגרסה בערכה לא תקין או לא תואם למניפסט.")
    a = m.get("archive") or {}
    zp = d / "kit" / str(a.get("name") or "")
    if a.get("name") != "code-%s.zip" % ver or not zp.is_file():
        return bad("ארכיון הקוד חסר בערכה (kit/code-%s.zip)." % ver)
    if zp.stat().st_size != a.get("size") or zp.stat().st_size > MAX_ARCHIVE:
        return bad("ארכיון הקוד לא בגודל הנכון — כנראה לא הורד עד הסוף. להוריד שוב מה-Drive.")
    h = hashlib.sha256()
    with open(zp, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    if h.hexdigest() != a.get("sha256"):
        return bad("ארכיון הקוד שונה ממה שנבנה (הגיבוב לא תואם) — לא מתקינים. להוריד שוב מה-Drive.")
    files = m.get("files") or {}
    signed, kid = bool(k.get("signed")), ""
    try:
        with zipfile.ZipFile(zp) as z:
            names = [i.filename for i in z.infolist() if not i.is_dir()]
            if sorted(names) != sorted(files):
                return bad("רשימת הקבצים בארכיון לא תואמת למניפסט — לא מתקינים.")
            for n in names:
                if not _safe(n) or hashlib.sha256(z.read(n)).hexdigest() != (files.get(n) or {}).get("sha256"):
                    return bad("קובץ בארכיון לא תואם למניפסט (%s) — לא מתקינים." % n[:80])
            trusted = []
            if "assets/release_source.json" in names:
                try:
                    src = json.loads(z.read("assets/release_source.json").decode("utf-8"))
                    trusted = [x.strip() for x in str(src.get("pubkey") or "").split(",") if x.strip()]
                except ValueError:
                    trusted = []
    except zipfile.BadZipFile:
        return bad("ארכיון הקוד פגום — להוריד שוב מה-Drive.")
    if signed:
        pub = str(k.get("pub") or "")
        try:
            sig = base64.b64decode((d / "kit" / "manifest.sig").read_text(encoding="ascii").strip(), validate=True)
            ok = ed25519_verify(base64.b64decode(pub), raw, sig)
        except (OSError, ValueError):
            ok = False
        if not ok:
            return bad("החתימה על הערכה לא תקינה — לא מתקינים.")
        if trusted and pub not in trusted:
            return bad("הערכה חתומה במפתח שהקוד עצמו לא מכיר — לא מתקינים.")
        kid = _key_id(pub)
        msg = "✓ הערכה תקינה וחתומה (גרסה %s, מפתח %s)" % (ver, kid)
    else:
        if (d / "kit" / "manifest.sig").exists():
            return bad("בערכה יש חתימה אבל היא מסומנת כלא חתומה — לא מתקינים.")
        msg = "✓ הערכה שלמה (גרסה %s). היא לא חתומה — עוד לא פורסמה גרסה חתומה; נבדקה שלמות כל הקבצים." % ver
    return {"ok": True, "msg": msg, "version": ver, "signed": signed, "key_id": kid}


def stage(kit_dir, dest):
    """אחרי verify: מחלץ את הקוד ל-<dest>/code (עם הרשאות הרצה), כותב package.json ו-extras/ ריקה — התבנית של חבילת שיתוף,
    כך ש-install_windows.ps1 (עם ‎-Restore) מתקין אותו. מחזיר את תוצאת verify."""
    r = verify(kit_dir)
    if not r["ok"]:
        return r
    d, dest = Path(kit_dir), Path(dest)
    code = dest / "code"
    if dest.exists():
        import shutil
        shutil.rmtree(dest)
    code.mkdir(parents=True)
    (dest / "extras").mkdir()
    m = json.loads((d / "kit" / "manifest.json").read_text(encoding="utf-8"))
    with zipfile.ZipFile(d / "kit" / ("code-%s.zip" % r["version"])) as z:
        for n in z.namelist():
            if n.endswith("/"):
                continue
            t = code / n
            if not str(t.resolve()).startswith(str(code.resolve()) + os.sep):
                return dict(r, ok=False, msg="נתיב מסוכן בארכיון — לא מחלצים.")
            t.parent.mkdir(parents=True, exist_ok=True)
            t.write_bytes(z.read(n))
            try:
                os.chmod(t, 0o755 if (m["files"].get(n) or {}).get("mode") == 0o755 else 0o644)
            except OSError:
                pass
    (dest / "package.json").write_text(json.dumps({"format": 1, "made": json.loads((d / "kit" / "kit.json").read_text(encoding="utf-8")).get("made", ""),
                                                   "commit": r["version"], "restore": True}, ensure_ascii=False), encoding="utf-8")
    return r


def _vt(v):
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except ValueError:
        return None


def compare(kit_dir, home):
    try:
        k = json.loads((Path(kit_dir) / "kit" / "kit.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "none"
    vf = Path(home) / "yeshiva-shorts-skill" / "VERSION"
    if not (Path(home) / "yeshiva-shorts-skill" / "shorts.sh").is_file() or not vf.is_file():
        return "none"
    a, b = _vt(str(k.get("version") or "")), _vt(vf.read_text(encoding="utf-8"))
    if not a or not b:
        return "none"
    return "newer" if a > b else ("same" if a == b else "older")


def main(argv):
    if len(argv) >= 3 and argv[1] == "verify":
        r = verify(argv[2])
        print(r["msg"])
        return 0 if r["ok"] else 1
    if len(argv) >= 4 and argv[1] == "stage":
        r = stage(argv[2], argv[3])
        print(r["msg"])
        return 0 if r["ok"] else 1
    if len(argv) >= 4 and argv[1] == "compare":
        print(compare(argv[2], argv[3]))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
