@echo off
rem Double-click launcher for the installer. ASCII-only on purpose (cmd + UTF-8 pitfalls).
rem Real work is in install_windows.ps1 (UTF-8 with BOM, Hebrew messages).
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_windows.ps1"
pause
