﻿# install_windows.ps1 — התקנה של כלי יצירת השורטס במחשב ווינדוס חדש, בצעדים, עם בדיקה אחרי כל צעד.
#
# מפעילים אותו מ-"התקנה.bat" (לחיצה כפולה). אפשר להריץ שוב ושוב: מה שכבר הותקן מדולג.
# הקובץ נשמר ב-UTF-8 עם BOM (בלי זה PowerShell 5.1 מקלקל עברית).
#
# מה אוטומטי: WSL+Ubuntu, חבילות מערכת, העתקת הקוד, install.sh (פייתון, ספריות, ffmpeg, Deno,
#   rclone), שחזור מוזיקה/הגדרות/לוגו/הנחיות מ-Drive, קיצור הפעלה, בדיקת מערכת.
# מה נשאר ידני (אישי, אי אפשר לעשות במקומו): חיבור Google Drive, חיבור Modal, ובחלון עצמו —
#   מפתח Gemini (לא חובה) וקובץ עוגיות יוטיוב (רק לשיעורים מתוזמנים). כל אחד מודרך ונבדק.
#
# 🚨 לא נוגע בשום דבר מחוץ לתיקיית הפרויקט ול-WSL. לא מדפיס ולא שומר מפתחות בשום יומן.
#
# מצב חבילה (21/10/2026, "שיתוף תוכנה" — make_short_share.py): כשהקובץ הזה יושב ב-code\windows\ של
# zip שחולץ (יש ..\..\package.json), הקוד, המוזיקה, הלוגו וההנחיות באים מתוך החבילה — בלי GitHub
# ובלי Drive. התקנה מעל התקנה קיימת שומרת הגדרות, מפתחות ומוזיקה של המקבל.
# -DryRun (רק במצב חבילה): בדיקה בלי לגעת במחשב — מעתיק קוד ותוספות לבית זמני /tmp/ys_dry_*,
#   בודק אותם, ומדלג על WSL/חבילות/install.sh/חיבורים/קיצורים.
# -Restore (4.6, רק במצב חבילה): נקרא מתוך תוכנית השחזור למחשב חדש — בלי התוספות של מקבל (מוזיקה/פרופיל/תצוגה פשוטה) ובלי
#   בדיקת המערכת בסוף: את אלה תוכנית השחזור עושה אחרי הכספת וה-Drive.
param([switch]$SkipDrive, [switch]$SkipModal, [switch]$SkipGit, [switch]$SkipInstall, [string]$ProjDir = '', [switch]$NoPause, [string]$Distro = '', [switch]$DryRun, [switch]$Restore)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$OutputEncoding = [Text.Encoding]::UTF8
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $Here                       # windows\ יושבת בתוך הריפו
$Proj = if ($ProjDir) { $ProjDir } else { Join-Path $env:USERPROFILE 'yeshiva-shorts' }   # תיקיית הפרויקט (כל הקבצים שלו כאן — לא ב-Downloads)
$PkgRoot = Split-Path -Parent $RepoRoot                     # בחבילה: התיקייה שחולצה (code\ + extras\ + package.json)
$Pkg = (Test-Path (Join-Path $PkgRoot 'package.json')) -and (Test-Path (Join-Path $PkgRoot 'extras'))
$PkgMeta = $null
if ($Pkg) { $PkgMeta = Get-Content -Raw -Encoding UTF8 (Join-Path $PkgRoot 'package.json') | ConvertFrom-Json }
if ($DryRun -and -not $Pkg) { Write-Host "  -DryRun עובד רק מתוך חבילת שיתוף שחולצה." -ForegroundColor Red; exit 1 }
$TgtHome = ''                                               # ריק = הבית האמיתי ב-Ubuntu; ב-DryRun — תיקייה זמנית
# 4.6: הקטעים SHARED-WSL-A/B מועתקים כמו שהם לתוכנית השחזור למחשב חדש (restore.ps1, make_short_vault.compose_restore_ps1)
# <SHARED-WSL-A-BEGIN>
# איזו לינוקס להשתמש: אם כבר מותקנת במחשב Ubuntu (כל גרסה) או Debian — משתמשים בה במקום
# להתקין עוד אחת (כמה GB). העדפה: "Ubuntu" עצמה ← Ubuntu-XX.XX החדשה ביותר ← Debian.
# רק משפחת apt, כי צעד 2 מתקין חבילות עם apt-get. אין כלום ← מתקינים "Ubuntu". -Distro X גובר על הכול.
if (-not $Distro) {
    $have = @()
    if (Get-Command wsl.exe -ErrorAction SilentlyContinue) {
        $have = ((& wsl.exe -l -q 2>$null | Out-String) -replace "`0", '') -split "`r?`n" |
                ForEach-Object { $_.Trim() } | Where-Object { $_ }
    }
    $Distro = @(
        $have | Where-Object { $_ -eq 'Ubuntu' }
        $have | Where-Object { $_ -match '^Ubuntu-\d' } | Sort-Object { [version]($_ -replace '^Ubuntu-', '') } -Descending
        $have | Where-Object { $_ -match '^Debian' }
        'Ubuntu'
    )[0]
}

function Say($t)  { Write-Host ""; Write-Host $t -ForegroundColor Cyan }
function Ok($t)   { Write-Host "  [V] $t" -ForegroundColor Green }
function Warn($t) { Write-Host "  [!] $t" -ForegroundColor Yellow }
function Stop-Here($t) { Write-Host ""; Write-Host "  [X] $t" -ForegroundColor Red; Write-Host ""; if (-not $NoPause) { Read-Host "לחצו Enter לסגירה" }; exit 1 }
function Pause-Step($t) { Write-Host ""; Write-Host "  $t" -ForegroundColor White; [void](Read-Host "  כשסיימתם — לחצו Enter") }

function Wsl-Run([string]$Script, [string[]]$ScriptArgs = @(), [string]$User = '') {
    # הפקודות בקובץ סקריפט, לא בשורת הפקודה: ציטוטים ומשתנים הולכים לאיבוד בהעברה דרך PowerShell
    $tmp = Join-Path $env:TEMP ("ys_" + [guid]::NewGuid().ToString('N') + ".sh")
    [IO.File]::WriteAllText($tmp, ($Script -replace "`r`n", "`n"), (New-Object Text.UTF8Encoding $false))
    $p = (& wsl.exe -d $Distro -- wslpath -a ($tmp -replace '\\', '/') | Out-String).Trim()
    if ($User) { & wsl.exe -d $Distro -u $User -- bash $p @ScriptArgs | Out-Host }
    else       { & wsl.exe -d $Distro -- bash $p @ScriptArgs | Out-Host }
    $script:RC = $LASTEXITCODE
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}
function Wsl-Out([string]$Script, [string[]]$ScriptArgs = @(), [string]$User = '') {
    $tmp = Join-Path $env:TEMP ("ys_" + [guid]::NewGuid().ToString('N') + ".sh")
    [IO.File]::WriteAllText($tmp, ($Script -replace "`r`n", "`n"), (New-Object Text.UTF8Encoding $false))
    $p = (& wsl.exe -d $Distro -- wslpath -a ($tmp -replace '\\', '/') | Out-String).Trim()
    if ($User) { $o = & wsl.exe -d $Distro -u $User -- bash $p @ScriptArgs | Out-String }
    else       { $o = & wsl.exe -d $Distro -- bash $p @ScriptArgs | Out-String }
    $script:RC = $LASTEXITCODE
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    return $o.Trim()
}
# PowerShell 5.1 משמיט ארגומנט ריק בדרך לתוכנה חיצונית — לכן "-" במקום "הבית הרגיל"
function TgtArg { if ($TgtHome) { $TgtHome } else { '-' } }
function Distro-Installed {
    $l = (& wsl.exe -l -q 2>$null | Out-String) -replace "`0", ''
    return ($l -split "`r?`n" | ForEach-Object { $_.Trim() }) -contains $Distro
}
# <SHARED-WSL-A-END>

Clear-Host
Write-Host "=== התקנת כלי יצירת השורטס ===" -ForegroundColor White
Write-Host "  אפשר לעצור בכל רגע ולהריץ שוב — מה שכבר הותקן מדולג."

# ---------------------------------------------------------------- 0. בדיקות מקדימות
Say "0/8  בודק את הקבצים"
if ($Pkg) {
    Ok "חבילת שיתוף מ-$($PkgMeta.made) (גרסה $($PkgMeta.commit))"
    if ($DryRun) { Warn "מצב בדיקה (DryRun): שום דבר לא מותקן במחשב הזה" }
}
if ($Pkg -and -not (Test-Path (Join-Path $RepoRoot 'install.sh'))) {
    Stop-Here "החבילה לא שלמה (חסר code\install.sh). לחלץ שוב את כל קובץ ה-zip (לחיצה ימנית ← חלץ הכול) ולנסות שוב."
}
if (-not (Test-Path (Join-Path $RepoRoot 'install.sh'))) {
    Stop-Here "התיקייה הזאת לא מכילה את כל הקוד (חסר install.sh). צריך להוריד את כל הריפו כקובץ ZIP מ-GitHub (Code ← Download ZIP), לפתוח, ולהריץ את התקנה.bat מתוך התיקייה windows שבפנים."
}
Ok "הקוד נמצא ב-$RepoRoot"

# ---------------------------------------------------------------- 1. WSL + Ubuntu
Say "1/8  WSL ו-Ubuntu (התוכנה רצה בתוך לינוקס שבתוך ווינדוס)"
# <SHARED-WSL-B-BEGIN>
if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) { Stop-Here "ווינדוס הזה לא מכיר WSL. צריך ווינדוס 10 (גרסה 2004 ומעלה) או ווינדוס 11." }
if ($DryRun -and -not (Distro-Installed)) { Stop-Here "בדיקה (DryRun) צריכה WSL מותקן ($Distro)." }
if (-not (Distro-Installed)) {
    $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $admin) {
        Warn "Ubuntu לא מותקן. ההתקנה שלו דורשת הרשאת מנהל — ייפתח חלון אישור של ווינדוס; ללחוץ 'כן'."
        $pr = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList '-NoProfile','-Command',"wsl.exe --install -d $Distro --no-launch; Write-Host ''; Read-Host 'לחצו Enter'"
    } else {
        & wsl.exe --install -d $Distro --no-launch | Out-Host
    }
    if (-not (Distro-Installed)) {
        Stop-Here "ווינדוס צריך הפעלה מחדש כדי לסיים את התקנת WSL. מפעילים את המחשב מחדש, ואז לוחצים שוב על התקנה.bat — ההתקנה ממשיכה מאותו מקום."
    }
}
# אתחול ראשון של ההפצה בלי לחכות לשם משתמש ידני: root זמני, ואז משתמש רגיל
$who = ((& wsl.exe -d $Distro -u root -- whoami 2>$null) | Out-String).Trim()
if ($who -ne 'root') {
    Warn "Ubuntu עדיין לא אותחל. מנסה לאתחל אוטומטית..."
    foreach ($exe in 'ubuntu.exe', 'ubuntu2404.exe', 'ubuntu2204.exe', 'debian.exe') {
        if (Get-Command $exe -ErrorAction SilentlyContinue) { & $exe install --root | Out-Host; break }
    }
}
$who = ((& wsl.exe -d $Distro -- whoami 2>$null) | Out-String).Trim()
if (-not $who) { Stop-Here "אי אפשר להפעיל את Ubuntu. לנסות: להפעיל את המחשב מחדש; לפתוח מתפריט התחל את 'Ubuntu', לבחור שם משתמש וסיסמה, לסגור — ולהריץ שוב." }
if ($who -eq 'root') {
    Warn "אין משתמש רגיל ב-Ubuntu — יוצר משתמש 'shorts' (בלי סיסמה, רק למחשב הזה)."
    Wsl-Run @'
set -e
id shorts >/dev/null 2>&1 || useradd -m -s /bin/bash shorts
printf '[user]\ndefault=shorts\n' > /etc/wsl.conf
'@ -User root
    & wsl.exe --terminate $Distro | Out-Null
    $who = ((& wsl.exe -d $Distro -- whoami) | Out-String).Trim()
}
Ok "$Distro מוכן, משתמש: $who"
# <SHARED-WSL-B-END>

# ---------------------------------------------------------------- 2. חבילות מערכת
Say "2/8  חבילות מערכת (python, git, curl...)"
if ($DryRun) { Warn "בדיקה: מדלג"; $script:RC = 0 } else { Wsl-Run @'
set -e
export DEBIAN_FRONTEND=noninteractive
# אם התקנה קודמת נקטעה (קריסת WSL, כיבוי באמצע) dpkg מסרב להמשיך עד שמסיימים אותה
dpkg --configure -a >/dev/null 2>&1 || true
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip git curl xz-utils unzip ca-certificates fontconfig >/dev/null
echo "חבילות מערכת: תקין"
'@ -User root }
if ($script:RC -ne 0) { Stop-Here "התקנת חבילות המערכת נכשלה (אינטרנט?). בדקו חיבור ונסו שוב." }
Ok "חבילות מערכת מותקנות"

# ---------------------------------------------------------------- 3. הקוד
Say "3/8  מעתיק את הקוד אל Ubuntu"
$srcWsl = (& wsl.exe -d $Distro -- wslpath -a ($RepoRoot -replace '\\', '/') | Out-String).Trim()
if ($DryRun) {
    $TgtHome = Wsl-Out 'd=$(mktemp -d /tmp/ys_dry_XXXXXX) && echo "$d"'
    Warn "בדיקה: הכול נכתב אל $TgtHome (לא לבית האמיתי)"
}
if ($Pkg) {
    # חבילה: אין GitHub. התקנה ראשונה = העתקה + git מקומי (לתיבת "עדכון תוכנה": גיבוי לפני כל עדכון
    # וביטול). מעל התקנה קודמת מחבילה = הגרסה החדשה במקום הישנה (הקוד בלבד — הגדרות ומפתחות בחוץ).
    # קוד שמחובר ל-GitHub (המחשב של הבעלים, או מי שהתקין משם) — לא נוגעים בו.
    Wsl-Run @'
set -e
SRC="$1"; H="$2"; [ "$H" = "-" ] && H="$HOME"; DST="$H/yeshiva-shorts-skill"; VER="$3"
G() { git -C "$DST" -c user.name="yeshiva-shorts installer" -c user.email="installer@localhost" "$@"; }
if [ -d "$DST/.git" ] && git -C "$DST" remote get-url origin >/dev/null 2>&1; then
  echo "הקוד ב-$DST מחובר ל-GitHub — לא מחליף אותו (מעדכנים אותו משם)"; exit 0
fi
mkdir -p "$DST"
if [ -f "$DST/.from_package" ] && [ -d "$DST/.git" ] && [ -f "$DST/shorts.sh" ]; then
  # גרסה קודמת מחבילה: שומרים אותה ב-git ומסירים את קבצי הקוד שלה, כדי שקובץ שנמחק בגרסה החדשה לא יישאר
  # 4.5.x (C7): hand edits are registered as a personal change first (re-applied after the install, never lost)
  "$DST/shorts.sh" py make_short_personal.py register-manual >/dev/null 2>&1 || true
  G add -A &&{ G commit -q -m "לפני התקנת חבילה חדשה ($VER)" || true; }
  G ls-files -z | (cd "$DST" && xargs -0 -r rm -f --)
  echo "גרסה קודמת נשמרה בהיסטוריה (git) והוחלפה"
fi
cp -a "$SRC/." "$DST/"
find "$DST" -name '*.sh' -exec chmod +x {} +
echo "$VER" > "$DST/.from_package"
# 4.5.62: a package install replaces the code; a leftover "first start of an update" marker (trial) or interrupted-update journal
# belongs to code that is gone - it would send shorts.sh back to the OLD version on the first start and cancel this install
RU="$H/.local/share/yeshiva-shorts/release_updates"
rm -f "$RU/trial" "$RU/trial_failed" "$RU/pending.json" "$RU/pending.sha" "$RU/recover_failed" 2>/dev/null || true
[ -d "$DST/.git" ] || git -C "$DST" init -q -b main
grep -qx '.from_package' "$DST/.git/info/exclude" 2>/dev/null || echo '.from_package' >> "$DST/.git/info/exclude"
G add -A && { G commit -q -m "התקנה מחבילת שיתוף ($VER)" || true; }
# 4.5.x (C7): the installed code is the official base of its version (rel-X) - personal changes are re-applied on top of it
V="$(tr -d '[:space:]' < "$DST/VERSION" 2>/dev/null || true)"
if [ -n "$V" ]; then G tag -f "rel-$V" HEAD >/dev/null; fi
echo "הועתק אל $DST ($(G rev-parse --short HEAD))"
'@ -ScriptArgs @($srcWsl, (TgtArg), "$($PkgMeta.commit)")
} else { Wsl-Run @'
set -e
SRC="$1"; DST="$HOME/yeshiva-shorts-skill"
if [ -f "$DST/shorts.sh" ]; then echo "הקוד כבר קיים ב-$DST — משאיר כמו שהוא"; exit 0; fi
mkdir -p "$DST"; cp -a "$SRC/." "$DST/"
chmod +x "$DST"/*.sh
echo "הועתק אל $DST"
'@ -ScriptArgs @($srcWsl) }
if ($script:RC -ne 0) { Stop-Here "העתקת הקוד נכשלה." }
Ok "הקוד ב-~/yeshiva-shorts-skill"


# ---------------------------------------------------------------- 4. install.sh
Say "4/8  מתקין את הספריות והכלים (כמה דקות — פייתון, תמלול, ffmpeg, Deno, rclone)"
if ($SkipInstall -or $DryRun) { $script:RC = 0; Warn "מדלג על install.sh (בדיקה)" } else { Wsl-Run @'
set -e
cd ~/yeshiva-shorts-skill
./install.sh --no-setup --asr=local
'@ }
if ($script:RC -ne 0) { Stop-Here "install.sh נכשל — ראו את השורה האדומה למעלה. אפשר להריץ שוב את התקנה.bat." }
Ok "הכלים מותקנים וכל הספריות נטענות"

# ---------------------------------------------------------------- 5. Google Drive
Say "5/8  חיבור ל-Google Drive (משם משחזרים מוזיקה/הגדרות, ואליו מגבים שורטס)"
# בחבילה: המוזיקה כבר בפנים, והדרייב הוא רק לגיבוי — של המקבל עצמו, ורק אם רוצה.
# בלי דרייב: הגיבוי כבוי בהגדרות (אחרת כל שורט היה מסתיים באזהרה). הגדרה קיימת שלו — לא נוגעים.
$DriveOff = $false
if ($Pkg -and -not $SkipDrive) {
    # 4.5.62: בחבילה לא מחברים דרייב בהתקנה — החיבור כאן היה דרך המפתח המשותף של rclone, שנסגר במהלך 2026 (כל מקבל חדש היה
    # מתחיל עם אזהרה). חיבור עם מפתח אישי מודרך מתוך חלון התוכנה: 🧭 צעדים ראשונים ← ☁️ גיבוי לדרייב.
    $SkipDrive = $true; $DriveOff = $true
    if (-not $DryRun) {
        Warn "גיבוי ל-Google Drive: לא מחברים בהתקנה. אם תרצו — אחרי הפתיחה, בחלון התוכנה: '🧭 צעדים ראשונים' ← '☁️ גיבוי לדרייב' (מודרך, כ-15 דקות). בלי זה הכול עובד, השורטסים נשמרים במחשב."
    }
}
if ($SkipDrive) { if (-not $Pkg) { Warn "מדלג (לפי בקשה)." } } else {
    $have = Wsl-Out 'export PATH="$HOME/.local/bin:$PATH"; rclone listremotes 2>/dev/null | grep -qx "gdrive:" && echo yes || echo no'
    if ($have -ne 'yes') {
        Write-Host @"

  עכשיו מחברים את חשבון הגוגל (הדרייב). מה שיקרה:
    1. אם יופיעו שאלות באנגלית — לענות Enter (ברירת המחדל מספיקה; הכול נעשה אוטומטית).
    2. יודפס קישור שמתחיל ב-http://127.0.0.1:53682 — להעתיק אותו ולפתוח בדפדפן (כרום).
    3. לבחור את חשבון הגוגל של הערוץ ולאשר.
    4. לחזור לכאן — ההתקנה תמשיך.
"@
        Wsl-Run @'
export PATH="$HOME/.local/bin:$PATH"
rclone config create gdrive drive scope drive.file
'@
    }
    $chk = Wsl-Out 'export PATH="$HOME/.local/bin:$PATH"; rclone lsf gdrive: --dirs-only 2>/dev/null'
    if ($script:RC -ne 0) {
        Warn "החיבור ל-Drive עדיין לא עובד. אפשר להמשיך בלי Drive ולחבר אחר כך מהחלון (הגדרות ← חבר מחדש את הדרייב)."
    } else {
        Ok "Drive מחובר. תיקיות: $($chk -replace "`n", ', ')"
        if (-not $Pkg -and $chk -notmatch 'גיבוי תוכנה') { Warn "לא נמצאה תיקיית 'גיבוי תוכנה' — כנראה זה חשבון אחר מזה שבו נעשה הגיבוי. המוזיקה לא תשוחזר אוטומטית." }
    }
}

# ---------------------------------------------------------------- 6. שחזור
if ($Pkg -and $Restore) {
Say "6/8  מוזיקה, הגדרות, לוגו והנחיות"
Warn "שחזור למחשב חדש: הם יחזרו מה-Drive בשלב הבא של תוכנית השחזור."
} elseif ($Pkg) {
Say "6/8  מעתיק מהחבילה: מוזיקה, לוגו והנחיות"
# לא דורס כלום שכבר יש למקבל (cp -n): המוזיקה, הלוגו וההנחיות שלו נשארים. ההגדרות — ברירת מחדל
# של התוכנה (לא נמצאות בחבילה בכלל).
$extWsl = (& wsl.exe -d $Distro -- wslpath -a ((Join-Path $PkgRoot 'extras') -replace '\\', '/') | Out-String).Trim()
Wsl-Run @'
set -e
SRC="$1"; H="$2"; [ "$H" = "-" ] && H="$HOME"; DRIVE_OFF="$3"
CFG="$H/.config/yeshiva-shorts"; DATA="$H/.local/share/yeshiva-shorts"
mkdir -p "$CFG/brand" "$DATA/music"
chmod 700 "$CFG"
# "לא לדרוס": --update=none בגרסאות חדשות של cp (שם -n מדפיס אזהרה), -n בישנות
cpn() { cp --update=none "$@" 2>/dev/null || cp -n "$@"; }
[ -d "$SRC/music" ] && cpn -r "$SRC/music/." "$DATA/music/"
# 4.1.0: התקנה מחדש — קטעים חדשים נכנסים לאינדקס של המקבל (הלייקים שלו בקובץ נפרד ולא נוגעים בהם), ו-mix.py מתעדכן
[ -d "$SRC/music" ] && python3 "$H/yeshiva-shorts-skill/pipeline/scripts/make_short_share.py" merge-music "$SRC/music" "$DATA/music"
[ -f "$SRC/config/guidelines.txt" ] && cpn "$SRC/config/guidelines.txt" "$CFG/guidelines.txt"
[ -f "$SRC/config/brand/logo.png" ] && cpn "$SRC/config/brand/logo.png" "$CFG/brand/logo.png"
if [ "$DRIVE_OFF" = "1" ] && [ ! -f "$CFG/make_short_settings.json" ]; then
  printf '{"values": {"drive_on": false}}\n' > "$CFG/make_short_settings.json"
fi
# 3.5: חבילה עם פרופיל — השורות בסוף התיאור, שם הישיבה ומשפט ההרשמה נכתבים רק אם עוד אין לו ערך משלו
if [ -f "$SRC/config/profile.json" ]; then
  python3 "$H/yeshiva-shorts-skill/pipeline/scripts/make_short_share.py" apply-profile "$SRC/config/profile.json" "$CFG/make_short_settings.json"
fi
# 4.0: מקבל = תצוגה פשוטה + "צעדים ראשונים" פעם אחת (רק אם עוד אין לו בחירה משלו)
python3 "$H/yeshiva-shorts-skill/pipeline/scripts/make_short_share.py" receiver-init "$CFG/make_short_settings.json"
echo "מוזיקה: $(ls "$DATA/music/tracks" 2>/dev/null | grep -c '\.mp3$') מנגינות · לוגו: $([ -f "$CFG/brand/logo.png" ] && echo יש || echo אין) · הנחיות: $([ -f "$CFG/guidelines.txt" ] && echo יש || echo אין)"
'@ -ScriptArgs @($extWsl, (TgtArg), $(if ($DriveOff) { '1' } else { '0' }))
if ($script:RC -ne 0) { Stop-Here "ההעתקה מהחבילה נכשלה." }
Ok "התוספות מהחבילה הועתקו"
} else {
Say "6/8  משחזר מוזיקה, הגדרות, לוגו והנחיות מה-Drive"
}
if ($Pkg) { } elseif ($SkipDrive) { Warn "מדלג." } else {
    Wsl-Run @'
cd ~/yeshiva-shorts-skill
./backup_extras.sh restore 2>&1 | grep -v NOTICE
'@
    $n = Wsl-Out 'ls ~/.local/share/yeshiva-shorts/music/tracks 2>/dev/null | grep -c "\.mp3$"'
    if ([int]$n -ge 1) { Ok "$n קטעי מוזיקה בספרייה" } else { Warn "אין מוזיקה. בלי מוזיקה הכלי לא יסיים שורט — לשחזר מהדרייב (אחרי חיבורו) עם: ~/yeshiva-shorts-skill/backup_extras.sh restore (פקודה לבעלים/עוזר טכני; אצל מקבל חבילה המוזיקה כבר בפנים)" }
}

# ---------------------------------------------------------------- 7. Modal
Say "7/8  חיבור ל-Modal (תמלול מהיר בענן; בלעדיו התמלול איטי מאוד אבל עובד)"
if ($DryRun) { $SkipModal = $true; Warn "בדיקה: מדלג" }
if ($SkipModal) { if (-not $DryRun) { Warn "מדלג (לפי בקשה)." } } else {
    $mok = Wsl-Out '~/.local/share/yeshiva-shorts/venv/bin/modal profile current 2>/dev/null | head -1'
    if (-not $mok) {
        Write-Host @"

  עכשיו מחברים את חשבון Modal (החשבון שבו יש הקרדיט החודשי). מה שיקרה:
    1. יודפס קישור — להעתיק אותו (לסמן בעכבר, קליק ימני) ולפתוח בדפדפן, להתחבר ל-Modal ולאשר (Approve).
    2. לחזור לכאן.
  אין לכם חשבון Modal? לא נורא: הקלידו כ ואז Enter כדי לדלג — התמלול יעבוד על המחשב (איטי יותר), ואפשר לחבר אחר כך
  מהחלון: '🧭 צעדים ראשונים' ← '☁️ Modal'. (כדי לפתוח חשבון: modal.com ← Sign up; האתר באנגלית; הוא דורש כרטיס אשראי,
  והקרדיט החינמי הוא 30$ בחודש.)
"@
        $skipM = Read-Host "  לחבר את Modal עכשיו? (Enter = כן, יש לי חשבון · כ = לדלג)"
        if ($skipM -and $skipM.Trim() -match '^(כ|y|s)') { Warn "מדלג על Modal." } else {
        Wsl-Run '~/.local/share/yeshiva-shorts/venv/bin/modal token new' }
        $mok = Wsl-Out '~/.local/share/yeshiva-shorts/venv/bin/modal profile current 2>/dev/null | head -1'
    }
    if ($mok) {
        Ok "Modal מחובר (חשבון: $mok)"
        Wsl-Run 'cd ~/yeshiva-shorts-skill && ~/.local/share/yeshiva-shorts/venv/bin/python - <<EOF
import sys; sys.path.insert(0, "setup"); import state
if not state.read_env().get("SHORTS_ASR") or state.read_env().get("SHORTS_ASR") == "local":
    state.write_env({"SHORTS_ASR": "modal"})
EOF'
    } else { Warn "Modal לא מחובר — התמלול ירוץ על המחשב (איטי). אפשר לחבר אחר כך: venv/bin/modal token new" }
}

# ---------------------------------------------------------------- 8. קיצור הפעלה ובדיקה
Say "8/8  קיצור הפעלה ובדיקת מערכת"
if ($DryRun) {
    # בדיקה: מה הותקן בבית הזמני — קוד שלם (git, סקריפטים שנטענים), תוספות, ושום סוד
    Wsl-Run @'
H="$1"; D="$H/yeshiva-shorts-skill"; ok=0
echo "  בית זמני: $H"
echo "  קוד: $(git -C "$D" log -1 --format='%h %s' 2>/dev/null || echo 'אין git ✗') · קבצים: $(git -C "$D" ls-files 2>/dev/null | wc -l)"
[ -x "$D/shorts.sh" ] && [ -x "$D/install.sh" ] && echo "  סקריפטים ניתנים להרצה ✓" || { echo "  ✗ shorts.sh / install.sh לא ניתנים להרצה"; ok=1; }
for f in "$D"/pipeline/scripts/*.py; do python3 -c "import sys; compile(open(sys.argv[1], encoding='utf-8').read(), sys.argv[1], 'exec')" "$f" || ok=1; done
echo "  כל קבצי הפייתון נטענים: $([ $ok = 0 ] && echo ✓ || echo ✗)"
echo "  מוזיקה: $(ls "$H/.local/share/yeshiva-shorts/music/tracks" | grep -c '\.mp3$') מנגינות · רישיונות: $(ls "$H/.local/share/yeshiva-shorts/music/tracks" | grep -c '\.license\.json$') · index.json: $([ -f "$H/.local/share/yeshiva-shorts/music/index.json" ] && echo ✓ || echo ✗)"
echo "  לוגו: $([ -f "$H/.config/yeshiva-shorts/brand/logo.png" ] && echo ✓ || echo ✗) · הנחיות: $([ -f "$H/.config/yeshiva-shorts/guidelines.txt" ] && echo ✓ || echo ✗) · הגדרות: $(cat "$H/.config/yeshiva-shorts/make_short_settings.json" 2>/dev/null || echo 'ברירת מחדל')"
bad=$(find "$H" \( -name 'config.env' -o -name '*cookie*' -o -name '*.toml' -o -name 'rclone.conf' -o -name '*.vault' \) 2>/dev/null)
[ -z "$bad" ] && echo "  אין קבצי סודות ✓" || { echo "  ✗ נמצאו קבצים רגישים: $bad"; ok=1; }
exit $ok
'@ -ScriptArgs @($TgtHome)
    $dr = $script:RC
    Write-Host ""
    if ($dr -eq 0) { Write-Host "=== בדיקת החבילה עברה ✓ (שום דבר לא הותקן במחשב) ===" -ForegroundColor Green }
    else { Write-Host "=== בדיקת החבילה מצאה בעיה (✗ למעלה) ===" -ForegroundColor Yellow }
    Write-Host "  אפשר למחוק את תיקיית הבדיקה: $TgtHome"
    if (-not $NoPause) { Read-Host "לחצו Enter לסגירה" }
    exit $dr
}
New-Item -ItemType Directory -Force -Path $Proj, (Join-Path $Proj 'חומרים') | Out-Null
# הקיצור מפעיל את אותה לינוקס שהותקנה (השם שלה נכתב לתוכו; הקובץ נשאר ASCII)
$launcher = [IO.File]::ReadAllText((Join-Path $Here 'launcher.bat.txt')) -replace 'wsl -d Ubuntu ', "wsl -d `"$Distro`" "
$launcher = $launcher -replace "`r?`n", "`r`n"    # 4.7.4: cmd wants CRLF; the file in the package/repo has LF only
[IO.File]::WriteAllText((Join-Path $Proj 'יצירת שורטס.bat'), $launcher, (New-Object Text.ASCIIEncoding))
Ok "נוצר: $Proj\יצירת שורטס.bat  (לחיצה כפולה פותחת את הכלי)"
# הסמל של התוכנה (21/10/2026) ליד הקיצור, וקיצור על שולחן העבודה שמשתמש בו
$ico = Join-Path $Proj 'יצירת שורטס.ico'
foreach ($src in @((Join-Path $Here '..\assets\app\icon.ico'), "\\wsl.localhost\$Distro\home\$who\yeshiva-shorts-skill\assets\app\icon.ico")) {
    if (Test-Path $src) { Copy-Item $src $ico -Force; break }
}
try {
    $desk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'יצירת שורטס.lnk'))
    $desk.TargetPath = (Join-Path $Proj 'יצירת שורטס.bat')
    $desk.WorkingDirectory = $Proj
    $desk.WindowStyle = 7
    if (Test-Path $ico) { $desk.IconLocation = "$ico,0" }
    $desk.Save()
    Ok "נוצר קיצור על שולחן העבודה: יצירת שורטס"
} catch { Warn "לא נוצר קיצור על שולחן העבודה ($($_.Exception.Message))" }
# 28/10/2026: אחרי "התקן כאפליקציה" ב-Edge — הסמלים ש-Edge יצר מפעילים את החלון בלי השרת. app_link.ps1 מכוון
# אותם לקובץ ההפעלה, רושם את yeshivashorts:// (לדף "התוכנה מתחילה…") ושומר את מספר האפליקציה. להריץ שוב את
# ההתקנה אחרי התקנת האפליקציה ב-Edge (או: powershell -ExecutionPolicy Bypass -File app_link.ps1 -Bat <הקובץ>)
try {
    $al = Join-Path $Here 'app_link.ps1'
    if (Test-Path $al) {
        $aid = & $al -Bat (Join-Path $Proj 'יצירת שורטס.bat')
        if ($aid) { Ok "האפליקציה המותקנת ב-Edge מחוברת לקובץ ההפעלה (כל הסמלים מפעילים את התוכנה)" }
        else { Ok "yeshivashorts:// נרשם. אחרי התקנת הדף כאפליקציה ב-Edge — להריץ את ההתקנה שוב, כדי לחבר גם את הסמלים שלה" }
    }
} catch { Warn "לא חוברו סמלי האפליקציה ($($_.Exception.Message))" }
try {
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $Proj 'שורטסים מוכנים.lnk'))
    $lnk.TargetPath = "\\wsl.localhost\$Distro\home\$who\Videos\Shorts"
    $lnk.Save()
    Ok "נוצר קיצור: שורטסים מוכנים"
} catch { Warn "לא נוצר קיצור ל'שורטסים מוכנים' ($($_.Exception.Message))" }
if ($Restore) {
    Write-Host ""
    Write-Host "=== הקוד והכלים הותקנו — ממשיכים בשחזור ===" -ForegroundColor Green
    exit 0
}
Wsl-Run @'
set -e
mkdir -p ~/Videos/Shorts
cd ~/yeshiva-shorts-skill
./shorts.sh py ~/yeshiva-shorts-skill/setup/newpc.py 2>&1 | grep -v NOTICE
'@
$check = $script:RC

Write-Host ""
if ($check -eq 0) {
    Write-Host "=== ההתקנה הסתיימה ===" -ForegroundColor Green
} else {
    Write-Host "=== ההתקנה הסתיימה, אבל בדיקת המערכת מצאה בעיה (✗ למעלה) ===" -ForegroundColor Yellow
    Write-Host "  בחלון הכלי יש כפתור 'העתק פרטים לעוזר' — שולחים אותו למי שעוזר (או לכל צ'אט בינה מלאכותית)."
}
Write-Host @"

  מה נשאר (אם צריך) — את כל החיבורים מסביר המסך '🧭 צעדים ראשונים' שנפתח לבד בפעם הראשונה בחלון של הכלי:
    - מפתח Gemini (לא חובה): בכרטיס '🔑' ← "שמור ובדוק".
    - עוגיות יוטיוב (רק לשיעורים מתוזמנים/פרטיים): בכרטיס '🍪' או בהתראה בחלון ← "העלה קובץ עוגיות".
    - גיבוי ל-Google Drive (לא חובה): בכרטיס '☁️ גיבוי לדרייב'.
  להפעלה:  לחיצה כפולה על  $Proj\יצירת שורטס.bat
"@
if (-not $NoPause) { Read-Host "לחצו Enter לסגירה" }
