# app_link.ps1 - 28/10/2026. Run by the installer (install_windows.ps1; run the installer again after installing the
# page as an Edge app). Idempotent. Keep this file ASCII-only (PowerShell 5 misreads UTF-8 without BOM).
#
# Why: when the page is installed as an Edge app, Edge creates its own shortcuts (desktop / Start menu /
# taskbar pin) that run msedge_proxy.exe --app-id=... directly. They open the window but never start the
# server in WSL, so the app showed nothing unless the server already ran (his report, 26/10).
#  1. Find the app id (from those shortcuts, cached in %LOCALAPPDATA%\YeshivaShorts\app_id.txt because
#     after step 2 the shortcuts no longer carry it).
#  2. Repoint every such shortcut to the launcher .bat (same icon) - so each icon starts the server first.
#  3. Register yeshivashorts:// (HKCU only) -> the launcher. The app's offline page ("starting...") opens it
#     when a pin we cannot repoint (a Windows 11 taskbar pin has no .lnk) opens the window first.
# The launcher reads the cached id (it does not run this script). Prints the app id (or nothing).
param([string]$Bat = $env:YS_BAT, [switch]$NoProtocol)
$ErrorActionPreference = 'SilentlyContinue'
$url = 'http://127.0.0.1:8790'
$cacheDir = Join-Path $env:LOCALAPPDATA 'YeshivaShorts'
$cache = Join-Path $cacheDir 'app_id.txt'
$res = Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Web Applications\Manifest Resources'
$sh = New-Object -ComObject WScript.Shell

$id = ''
if (Test-Path $cache) { $id = (Get-Content $cache -TotalCount 1).Trim() }
if ($id -and -not (Test-Path (Join-Path $res $id))) { $id = '' }        # app was uninstalled / reinstalled

$dirs = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'),
          [Environment]::GetFolderPath('CommonDesktopDirectory'),
          (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'),
          (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu'))
$fixed = 0
foreach ($d in $dirs) {
    if (-not $d -or -not (Test-Path -LiteralPath $d)) { continue }
    foreach ($f in Get-ChildItem -LiteralPath $d -Recurse -Filter *.lnk) {
        $l = $sh.CreateShortcut($f.FullName)
        $a = [string]$l.Arguments
        $m = [regex]::Match($a, '--app-id=([a-p]{32})')
        $ours = $a -match [regex]::Escape("--app-url=$url") -or ($id -and $m.Success -and $m.Groups[1].Value -eq $id)
        if (-not $ours -or -not $m.Success) { continue }
        if (-not $id) { $id = $m.Groups[1].Value }
        if (-not $Bat -or -not (Test-Path -LiteralPath $Bat)) { continue }
        $l.TargetPath = $Bat
        $l.Arguments = ''
        $l.WorkingDirectory = Split-Path -Parent $Bat
        $l.WindowStyle = 7                                   # minimized: only the app window shows
        $l.Description = "ys-app-id=$id (starts the server, then opens the app)"
        $l.Save()                                            # IconLocation is kept: the app's own icon
        $fixed++
    }
}
if ($id) {
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null
    Set-Content -Path $cache -Value $id -Encoding ASCII
}
if (-not $NoProtocol -and $Bat -and (Test-Path -LiteralPath $Bat)) {
    $k = 'HKCU:\Software\Classes\yeshivashorts'
    # 31/10: never pass %1 - a URL with a double quote and & could break out of the quoting and run another command.
    # The launcher only needs to know it was started by the handler, so it gets a fixed word.
    $cmd = '"' + $Bat + '" protocol'
    $cur = (Get-ItemProperty -LiteralPath "$k\shell\open\command" -Name '(default)').'(default)'
    if ($cur -ne $cmd) {
        New-Item -Path "$k\shell\open\command" -Force | Out-Null
        Set-ItemProperty -LiteralPath $k -Name '(default)' -Value 'URL:yeshivashorts'
        Set-ItemProperty -LiteralPath $k -Name 'URL Protocol' -Value ''
        Set-ItemProperty -LiteralPath "$k\shell\open\command" -Name '(default)' -Value $cmd
    }
}
if ($fixed) { [Console]::Error.WriteLine("app_link: repointed $fixed shortcut(s) to the launcher") }
Write-Output $id
