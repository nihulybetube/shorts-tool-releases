# -*- coding: utf-8 -*-
"""
מאתר את המיקום האופקי של הדובר בפריים, כדי שהחיתוך ל-9:16 ימרכז אותו
ולא יחתוך "לפי אמצע הפריים" (ברוב השיעורים הדובר יושב בצד, לא במרכז).

השיטה: שונוּת-בזמן לכל עמודה. הרקע (ארון, קיר, שלט) סטטי לחלוטין, והדובר
זז - ראש, זקן, ידיים - אז אנרגיית השינוי מתרכזת בדיוק עליו. לא צריך מודל
זיהוי פנים ולא הורדה מהאינטרנט.

לפי בקשת המשתמש: **בדיקה כל 10 שניות**. כל עוד המרכז לא זז - הקרופ נשאר
נעול (בלי ריחוף מיותר). כשהוא כן זז - מאתרים את רגע השינוי בדיוק של שנייה
ועושים שם מעבר קצר.

שימוש:
  python center_track.py <video> [--window 10] [--json out.json]
"""
import json
import subprocess
import sys

import numpy as np

SAMPLE_FPS = 4          # כמה פריימים לשנייה נדגמים לניתוח
ANA_W, ANA_H = 320, 180  # רזולוציית ניתוח (מספיקה בהחלט, וזולה)
ROW_LO, ROW_HI = 0.08, 0.78   # מתעלמים מהתקרה ומהשולחן/סטנד בתחתית
CHANGE_TOL = 0.030      # שינוי קטן מזה נחשב "לא זז" (3% מרוחב הפריים).
                        # מכוון בכוונה גבוה: תזוזת ראש/זקן רגילה לא אמורה
                        # להזיז את הקרופ, רק מיסגור שבאמת השתנה.
TRANSITION = 0.6        # משך המעבר בשניות כשהמרכז באמת השתנה
MIN_RUN_SEC = 15.0      # מיסגור חדש חייב להחזיק מעמד לפחות כך, אחרת זו
                        # תזוזה רגעית של הדובר ולא שינוי מיסגור


def sample_gray(path, fps=SAMPLE_FPS, w=ANA_W, h=ANA_H):
    """מחזיר מערך (N, h, w) של פריימים בגווני אפור."""
    cmd = [
        "ffmpeg", "-v", "error", "-i", path,
        "-vf", f"fps={fps},scale={w}:{h}",
        "-pix_fmt", "gray", "-f", "rawvideo", "-",
    ]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    n = len(raw) // (w * h)
    if n == 0:
        raise RuntimeError("לא התקבלו פריימים לניתוח")
    return np.frombuffer(raw[: n * w * h], dtype=np.uint8).reshape(n, h, w)


def column_profile(frames):
    """אנרגיית תנועה לכל עמודה: סטיית תקן בזמן, מסוכמת על השורות הרלוונטיות."""
    lo, hi = int(ANA_H * ROW_LO), int(ANA_H * ROW_HI)
    band = frames[:, lo:hi, :].astype(np.float32)
    std = band.std(axis=0)          # (rows, w)
    return std.sum(axis=0)          # (w,)


def center_from_profile(prof):
    """מרכז משוקלל של העמודות החזקות. מחזיר (fraction, strength)."""
    if prof.max() <= 1e-6:
        return None, 0.0
    p = prof - prof.min()
    peak = p.max()
    mask = p >= 0.5 * peak          # רק האזור הדומיננטי, לא רעש מפוזר
    if not mask.any():
        return None, 0.0
    idx = np.arange(len(p))
    w = p * mask
    frac = float((idx * w).sum() / w.sum()) / (len(p) - 1)
    return frac, float(peak)


def duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", path], capture_output=True, text=True, check=True)
    return float(out.stdout.strip())


def track(path, window=10.0):
    """מחזיר רשימת חלונות: [{'start','end','center','strength'}]"""
    frames = sample_gray(path)
    dur = duration(path)
    n = len(frames)
    per_win = max(2, int(round(window * SAMPLE_FPS)))

    wins = []
    for i in range(0, n, per_win):
        chunk = frames[i:i + per_win]
        if len(chunk) < 2:
            if wins:
                wins[-1]["end"] = dur
            break
        c, s = center_from_profile(column_profile(chunk))
        wins.append({
            "start": round(i / SAMPLE_FPS, 2),
            "end": round(min((i + len(chunk)) / SAMPLE_FPS, dur), 2),
            "center": c,
            "strength": round(s, 1),
        })

    # חלונות חלשים מדי (הרב כמעט לא זז) יורשים את המרכז מהשכן
    good = [w["center"] for w in wins if w["center"] is not None]
    fallback = float(np.median(good)) if good else 0.5
    for w in wins:
        if w["center"] is None:
            w["center"] = fallback
    return wins, dur


def refine_change(path, t_guess, window=10.0):
    """מחדד את רגע השינוי לרזולוציה של שנייה, סביב הגבול שנמצא."""
    lo = max(0.0, t_guess - window / 2)
    hi = t_guess + window / 2
    frames = sample_gray(path)
    per_sec = SAMPLE_FPS
    best_t, best_jump = t_guess, -1.0
    t = lo + 1.0
    while t < hi - 1.0:
        a = frames[int((t - 1.0) * per_sec):int(t * per_sec)]
        b = frames[int(t * per_sec):int((t + 1.0) * per_sec)]
        if len(a) < 2 or len(b) < 2:
            t += 1.0
            continue
        ca, _ = center_from_profile(column_profile(a))
        cb, _ = center_from_profile(column_profile(b))
        if ca is not None and cb is not None:
            jump = abs(cb - ca)
            if jump > best_jump:
                best_jump, best_t = jump, t
        t += 1.0
    return best_t


def build_runs(wins, path=None, tol=CHANGE_TOL, window=10.0):
    """
    ממזג חלונות יציבים לריצה אחת. מחזיר [{'start','end','center'}] כשכל
    ריצה היא מרכז נעול, והמעברים ביניהן הם רגעי שינוי אמיתיים.
    """
    runs = []
    for w in wins:
        if runs and abs(w["center"] - runs[-1]["center"]) <= tol:
            # אותו מרכז - מאריכים את הריצה ומעדכנים ממוצע רץ
            r = runs[-1]
            k = r["_n"]
            r["center"] = (r["center"] * k + w["center"]) / (k + 1)
            r["_n"] = k + 1
            r["end"] = w["end"]
        else:
            runs.append({"start": w["start"], "end": w["end"],
                         "center": w["center"], "_n": 1})

    # ריצה קצרה מדי = הרב נשען/הזיז ראש לרגע, לא מיסגור שבאמת השתנה.
    # פאן קצר בסוף קליפ נראה כמו תקלה, אז ממזגים אותה לשכנה.
    changed = True
    while changed and len(runs) > 1:
        changed = False
        for i, r in enumerate(runs):
            if r["end"] - r["start"] < MIN_RUN_SEC:
                j = i - 1 if i > 0 else 1
                keep, drop = (runs[j], runs[i])
                keep["start"] = min(keep["start"], drop["start"])
                keep["end"] = max(keep["end"], drop["end"])
                runs.pop(i)
                changed = True
                break

    # חידוד רגע המעבר בין ריצות
    for i in range(1, len(runs)):
        boundary = runs[i]["start"]
        if path:
            refined = refine_change(path, boundary, window)
            runs[i]["start"] = round(refined, 2)
            runs[i - 1]["end"] = round(refined, 2)
    for r in runs:
        r.pop("_n", None)
        r["center"] = round(r["center"], 4)
    return runs


def crop_x_expr(runs, out_w=1080, transition=TRANSITION, subject_x=0.5):
    """
    בונה ביטוי x לפילטר crop (צריך eval=frame).
    מרכז נעול בכל ריצה, ומעבר לינארי קצר ברגע השינוי.

    `subject_x` — איפה הדובר יישב ברוחב הפריט האנכי, 0=שמאל 1=ימין.
    0.5 ממרכז אותו. **דובר שמסתכל הצידה צריך "מרחב מבט" לכיוון שאליו הוא
    פונה**, אחרת הוא נראה מדבר אל המסגרת: פונה שמאלה → 0.62-0.68 (יושב
    ימינה), פונה ימינה → 0.32-0.38. הערה שהתקבלה בפועל על קליפים
    אחד הדוברים: "הוא מיושר לשמאל, מדבר למסגרת ולא לתוך המסך".
    """
    off = out_w * subject_x

    def x_of(c):
        return f"clip({c:.4f}*in_w-{off:.1f},0,in_w-{out_w})"

    if not runs:
        return f"(in_w-{out_w})/2"
    if len(runs) == 1:
        return x_of(runs[0]["center"])

    expr = x_of(runs[-1]["center"])
    for i in range(len(runs) - 1, 0, -1):
        t0 = runs[i]["start"]
        prev_x = x_of(runs[i - 1]["center"])
        cur_x = x_of(runs[i]["center"])
        ramp = (f"({prev_x}+({cur_x}-{prev_x})*(t-{t0:.2f})/{transition:.2f})")
        expr = (f"if(lt(t,{t0:.2f}),{prev_x},"
                f"if(lt(t,{t0 + transition:.2f}),{ramp},{expr}))")
    return expr


if __name__ == "__main__":
    vid = sys.argv[1]
    win = 10.0
    if "--window" in sys.argv:
        win = float(sys.argv[sys.argv.index("--window") + 1])
    wins, dur = track(vid, win)
    runs = build_runs(wins, path=vid, window=win)
    result = {"video": vid, "duration": dur, "windows": wins, "runs": runs,
              "crop_x": crop_x_expr(runs)}
    if "--json" in sys.argv:
        out = sys.argv[sys.argv.index("--json") + 1]
        with open(out, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print("wrote", out)
    print("windows:", len(wins), "runs:", len(runs))
    for r in runs:
        print("  %6.2f - %6.2f  center=%.4f" % (r["start"], r["end"], r["center"]))
