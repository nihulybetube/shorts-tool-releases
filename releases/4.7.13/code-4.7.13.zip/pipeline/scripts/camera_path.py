# -*- coding: utf-8 -*-
"""מסלול המצלמה של קליף, ומדידה של השניות שבהן הרב יוצא מהמסגרת שלנו (כרטיס 22, 28/10/2026).

למה זה קיים: בשיעור של הרב יוחאי פרלמן ("מהות התפילה") הרב זז כל כך שלכמה שניות הוא היה
**כולו מחוץ לקרופ 9:16** — אבל בתוך הפריים המקורי של יוטיוב. `check_framing` רץ על הקליף
הבנוי, ושם הרב שיצא פשוט לא נראה: אין פנים → הדגימה נזרקת → השניות הכי גרועות לא נספרות.
לכן כאן מודדים על ה-raw (הפריים המלא, הרב תמיד בפנים) מול מסלול המצלמה שנבנה ממנו.

המסלול מחושב באותו קוד בדיוק שבונה את הקליף (`face_track` + `per_piece_camera` שעבר לכאן
מ-multi_piece_clip), ולכן הוא דטרמיניסטי: אותו raw + אותה מצלמה = אותו מסלול.

שימוש (מתוך תיקיית הפרויקט):
    shorts.sh py camera_path.py exits <clipN> [default|smooth|zippy]   → JSON
    shorts.sh py camera_path.py compare <clipN>                         → טבלה לכל המצלמות
"""
import json
import os
import sys

import numpy as np

import face_track as F

PAD, HEAD = 0.5, 3.0           # כמו ב-multi_piece_clip: ריפוד שקט סביב כל חתיכה, 3 שניות פתיחה

# המצלמות שהתוכנה מכירה, כמשתני סביבה של multi_piece_clip (אותו מקור לבנייה, לתצוגה ולמדידה)
MODES = {"default": {}, "smooth": {"CAM_SMOOTH": "7"}, "zippy": {"CAM_ZIPPY": "1"}}
CAM_KEYS = ("CAM_SMOOTH", "CAM_ZIPPY")

# סף האזהרה: רצף של לפחות שנייה (2 דגימות) שבו יותר מרבע מהפנים מחוץ לקרופ.
# דגימה בודדת היא לפעמים זיהוי רועש של סיבוב ראש; שנייה שלמה הצופה כבר רואה.
MIN_RUN = 1.0


def cam_env(env, camera):
    """מכין סביבה לבנייה/תצוגה במצלמה הזאת (מוחק את הקודמת — אחרת חלקה+זריזה היו מצטברות)."""
    env = dict(env)
    for k in CAM_KEYS:
        env.pop(k, None)
    env.update(MODES.get(camera or "default", {}))
    return env


def profile_env(rabbi):
    """כרטיס 25 (1/11/2026): CAM_TRIGGER / CAM_PAN מפרופיל הרב (make_short_rabbis) — ריק כשאין פרופיל או מצלמה בו.
    CAM_RABBI = שם הרב, בסביבה של העבודה: הבנייה, התצוגה והמדידה קוראות אותו ומחשבות את אותו מסלול.
    "זריזה" יושבת מעל: ההמתנה והתקרה הרגילות — של הרב; במצב חירום זריזה מחליפה אותן בקבועים שלה (Z_*)."""
    if not rabbi:
        return {}
    try:
        import make_short_rabbis as RB
        return RB.camera_env(rabbi)
    except Exception:
        return {}


def prof_sig(rabbi=None):
    """חתימת פרופיל המצלמה — נשמרת עם המדידה, כך ששינוי בפרופיל פוסל מדידה ישנה."""
    return json.dumps(profile_env(rabbi if rabbi is not None else os.environ.get("CAM_RABBI")), sort_keys=True)


def apply_env(env=None):
    """מעתיק את משתני המצלמה לקבועים של face_track (multi_piece_clip עושה בדיוק את זה)."""
    env = os.environ if env is None else env
    if env.get("CAM_SMOOTH"):
        F.MEDIAN_SEC = F.MEAN_SEC = float(env["CAM_SMOOTH"])
    F.ZIPPY = env.get("CAM_ZIPPY", "") == "1"
    pe = profile_env(env.get("CAM_RABBI") or os.environ.get("CAM_RABBI"))
    if pe.get("CAM_TRIGGER"):
        F.TRIGGER_SEC = float(pe["CAM_TRIGGER"])
    if pe.get("CAM_PAN"):
        F.MAX_PAN_RATE = float(pe["CAM_PAN"])


_DEFAULTS = {"MEDIAN_SEC": F.MEDIAN_SEC, "MEAN_SEC": F.MEAN_SEC, "ZIPPY": F.ZIPPY,
             "TRIGGER_SEC": F.TRIGGER_SEC, "MAX_PAN_RATE": F.MAX_PAN_RATE}


def _reset():
    for k, v in _DEFAULTS.items():
        setattr(F, k, v)


# ── המצלמה לכל חתיכה (הועבר מ-multi_piece_clip בלי שינוי התנהגות) ──────────────────────
def groups(segs, min_group):
    # 12/10/2026 (וירא, קליף 3): שלוש חתיכות של 1, 4 ו-2 שניות קיבלו כל אחת איפוס משלה, והרב
    # רכן לספר וחזר — המצלמה קפצה 0.51→0.37→0.52→0.47 מרוחב המקור תוך 10 שניות (המשתמש: "קפיצות
    # מאוד מוזרות"). חתיכות רצופות מתקבצות עד CAM_MIN_PIECE שניות, וכל קבוצה מקבלת מיקום אחד.
    out, cur, dur = [], [], 0.0
    for k, (a, b) in enumerate(segs):
        cur.append(k); dur += b - a
        if dur >= min_group:
            out.append(cur); cur, dur = [], 0.0
    if cur:
        if out: out[-1] += cur   # חתיכה קצרה בסוף ממשיכה את המצלמה של הקודמת
        else: out.append(cur)
    return out


def per_piece_camera(target, fps, starts, segs, min_group=6.0, vc=None, pad=PAD, head=HEAD):
    vc = vc or F.virtual_camera
    edges = [int(round(s * fps)) for s in starts] + [len(target)]
    cams, moves, prev = [], 0, None
    for g in groups(segs, min_group):
        s, e = edges[g[0]], edges[g[-1] + 1]
        seg = np.array(target[s:e], dtype=float)
        if len(seg) == 0:
            continue
        a = int(round(pad * fps)); b = min(len(seg), a + int(round(head * fps)))
        hd = seg[a:b] if b > a else seg
        if len(g) > 1:
            hd = seg            # כמה חתיכות קצרות — מיקום אחד שמכסה את כולן
        mid = (float(np.min(hd)) + float(np.max(hd))) / 2.0
        # 21/10/2026 (קליפים 1–3 של זרעונים, הרב רוכן לספר וחוזר): אמצע 3 השניות הראשונות
        # השאיר את המצלמה 2–3.5% מרוחב הפלט לצד אחד לאורך כל הקליף ("בתוך הפריים, לא במרכז").
        # החציון של כל הקבוצה = המקום שבו הוא יושב רוב הזמן. נמדד על 3 הקליפים: חריגה מעבר
        # ל-±10% ירדה 25%→22%, מעבר ל-±15% 8%→6%; המצלמה עדיין לא זזה בכלל באף אחד מהם.
        # נשאר קרוב לפתיחה (עד 0.6×DEAD_OUT ממנה), כדי שלא יהיה פאן כבר בשנייה הראשונה.
        body = seg[a:max(a + 1, len(seg) - a)]
        lim = 0.6 * F.DEAD_OUT
        mid = min(max(float(np.median(body)), mid - lim), mid + lim)
        if prev is not None and abs(mid - prev) <= F.DEAD_OUT:
            mid = prev          # הפנים כמעט באותו מקום — לא מזיזים בכלל במעבר
        seg[0] = mid
        c, m = vc(seg, fps)
        cams.append(c); moves += m; prev = float(c[-1])
    return np.concatenate(cams), moves


def piece_starts(rel):
    """תחילת כל חתיכה ב-raw (כמו ב-multi_piece_clip: הריפוד שלפניה כלול בה)."""
    return [max(0.0, a - PAD) for a, _ in rel]


# ── זיהוי פנים על ה-raw (נשמר, כדי שהשוואה בין מצלמות לא תזהה מחדש) ──────────────────────
def detect(raw):
    cache = raw[:-len(".mp4")] + "_faces.json" if raw.endswith(".mp4") else raw + "_faces.json"
    st = os.stat(raw)
    key = "%d:%d" % (st.st_size, int(st.st_mtime))
    try:
        d = json.load(open(cache, encoding="utf-8"))
        if d.get("key") == key:
            return (np.array(d["t"]), np.array(d["c"], dtype=float), np.array(d["h"], dtype=float), d["aw"], d["ws"])
    except Exception:
        pass
    t, c, s, h = F.detect_centers(raw)
    aw, _ = F._analysis_size(raw)
    w, hh = F._probe_size(raw)
    try:
        json.dump({"key": key, "t": t.tolist(), "c": [None if np.isnan(x) else float(x) for x in c],
                   "h": [None if np.isnan(x) else float(x) for x in h], "aw": aw, "ws": w / hh},
                  open(cache, "w", encoding="utf-8"))
    except OSError:
        pass
    return t, c, h, aw, w / hh


def crop_width(ws):
    """רוחב הקרופ 1080x1920 כשבר מרוחב המקור (16:9 → 0.316)."""
    return min(1.0, 1080.0 / (1920.0 * ws))


def simulate(clip, camera="default", project="."):
    """מסלול המצלמה (שבר מרוחב המקור, לכל דגימה ב-raw) כמו שהבנייה מחשבת אותו."""
    raw = os.path.join(project, "work/clips/%s_raw.mp4" % clip)
    segs = json.load(open(os.path.join(project, "work/clips/%s_segments.json" % clip)))["raw_segments"]
    t, c, h, aw, ws = detect(raw)
    c = np.array([np.nan if x is None else x for x in c], dtype=float)
    h = np.array([np.nan if x is None else x for x in h], dtype=float)
    W = crop_width(ws)
    clean = F._reject_outliers(c, h)
    filled = F._fill_gaps(clean)
    fps = F.SAMPLE_FPS
    _reset()
    apply_env(MODES.get(camera, {}))
    try:
        tgt = F._smooth(filled, fps)
        if os.environ.get("CAM_PER_PIECE", "1") == "1":
            cam, moves = per_piece_camera(tgt, fps, piece_starts(segs), segs,
                                          float(os.environ.get("CAM_MIN_PIECE", "6")))
        else:
            cam, moves = F.virtual_camera(tgt, fps)
    finally:
        _reset()
    cam = np.clip(cam[:len(t)], W / 2, 1 - W / 2)     # crop_x נחתך לגבולות התמונה
    return {"t": t, "face": clean, "h": h, "cam": cam, "moves": moves, "W": W, "aw": aw, "segs": segs}


def measure(sim):
    """כמה שניות הרב מחוץ למסגרת (או חתוך בקצה), מתי, וכמה המצלמה זזה."""
    from build_clean_video import _raw_to_edited
    t, face, h, cam, W, segs = sim["t"], sim["face"], sim["h"], sim["cam"], sim["W"], sim["segs"]
    used = np.zeros(len(t), bool)
    for a, b in segs:
        used |= (t >= a) & (t < b)
    off = (face - cam) / W                         # מרכז הפנים, ביחידות רוחב הפלט (±0.5 = הקצה)
    half = 0.85 * h / sim["aw"] / W / 2.0          # חצי רוחב הפנים, באותן יחידות (קופסת YuNet ≈ 0.85×הגובה)
    ok = used & ~np.isnan(off)
    a_off = np.where(ok, np.abs(off), 0.0)
    out = ok & (a_off > 0.5)                       # מרכז הפנים מעבר לקצה = רוב הפנים בחוץ
    cut = ok & (a_off > 0.5 - 0.5 * np.nan_to_num(half, nan=0.08))   # יותר מרבע מהפנים בחוץ
    fps = F.SAMPLE_FPS
    runs, i = [], 0
    while i < len(t):
        if cut[i]:
            j = i
            while j + 1 < len(t) and cut[j + 1]:
                j += 1
            if (j - i + 1) / fps >= MIN_RUN:
                runs.append([round(_raw_to_edited(float(t[i]), segs), 1),
                             round(_raw_to_edited(float(t[j]) + 1 / fps, segs), 1)])
            i = j + 1
        else:
            i += 1
    long_cut = sum(b - a for a, b in runs)
    # תנועת המצלמה, ביחידות רוחב הפלט (1.0 = רוחב השורט כולו). מודדים רק בתוך החתיכות.
    d = np.abs(np.diff(cam)) / W
    d = d[used[1:] & used[:-1]]
    speed = d * fps * 1080.0                        # פיקסלים לשנייה בפלט
    return {"out_sec": round(out.sum() / fps, 1), "cut_sec": round(cut.sum() / fps, 1),
            "warn_sec": round(long_cut, 1), "runs": runs, "moves": int(sim["moves"]),
            "travel": round(float(d.sum()), 2), "peak_px_s": int(round(float(speed.max()) if len(speed) else 0)),
            "still_pct": int(round(100 * float((d < 1e-4).mean()) if len(d) else 100)),
            "samples": int(ok.sum())}


def exits(clip, camera="default", project="."):
    return measure(simulate(clip, camera, project))


def _status_path(project, clip):
    return os.path.join(project, "work/clips/%s_exits.json" % clip)


def _raw_key(project, clip):
    try:
        st = os.stat(os.path.join(project, "work/clips/%s_raw.mp4" % clip))
        return "%d:%d" % (st.st_size, int(st.st_mtime))
    except OSError:
        return None


def status(clip, camera="default", project="."):
    """מודד את המצלמה שהקליף נבנה בה + מה זריזה הייתה נותנת, ושומר ליד הקליף.
    קובץ נפרד (לא make_short.json) — כך החלון יכול לחשב ברקע בלי להתנגש בעבודה שכותבת את המצב."""
    camera = camera if camera in MODES else "default"
    d = {"key": _raw_key(project, clip), "camera": camera, "prof": prof_sig(), "cur": exits(clip, camera, project)}
    if camera != "zippy" and d["cur"]["warn_sec"] > 0:
        d["zippy"] = exits(clip, "zippy", project)
    tmp = _status_path(project, clip) + ".tmp"
    json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    os.replace(tmp, _status_path(project, clip))
    return d


def load_status(clip, camera="default", project=".", rabbi=None):
    """המדידה השמורה, או None אם אין / ה-raw השתנה / הקליף נבנה מאז במצלמה אחרת / פרופיל הרב השתנה."""
    try:
        d = json.load(open(_status_path(project, clip), encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if d.get("key") != _raw_key(project, clip) or d.get("camera") != (camera or "default"):
        return None
    if d.get("prof", "{}") != prof_sig(rabbi):
        return None
    return d


def summary(d):
    """מה שהכרטיס בדף צריך: כמה שניות, מתי, ומה זריזה הייתה נותנת."""
    if not d:
        return None
    cur = d["cur"]
    out = {"sec": cur["warn_sec"], "runs": cur["runs"], "camera": d["camera"], "times": fmt_runs(cur["runs"])}
    if d.get("zippy"):
        out["zippy_sec"] = d["zippy"]["warn_sec"]
    return out


def fmt_runs(runs, limit=6):
    """'0:12, 0:31…' — זמני התחלה בקליף, לכרטיס בדף."""
    s = ["%d:%02d" % (int(a) // 60, int(a) % 60) for a, _ in runs[:limit]]
    return " · ".join(s) + (" …" if len(runs) > limit else "")


if __name__ == "__main__":
    cmd, clip = sys.argv[1], sys.argv[2]
    if cmd == "status":
        print(json.dumps(summary(status(clip, sys.argv[3] if len(sys.argv) > 3 else "default")), ensure_ascii=False))
    elif cmd == "exits":
        print(json.dumps(exits(clip, sys.argv[3] if len(sys.argv) > 3 else "default"), ensure_ascii=False))
    elif cmd == "compare":
        print("%-8s %7s %7s %7s %6s %7s %8s %6s  %s" % ("camera", "out_s", "cut_s", "warn_s", "moves", "travel",
                                                       "peak/s", "still", "runs"))
        for m in MODES:
            r = exits(clip, m)
            print("%-8s %7.1f %7.1f %7.1f %6d %7.2f %8d %5d%%  %s" % (m, r["out_sec"], r["cut_sec"], r["warn_sec"],
                  r["moves"], r["travel"], r["peak_px_s"], r["still_pct"], r["runs"]))
    else:
        sys.exit("exits|compare")
