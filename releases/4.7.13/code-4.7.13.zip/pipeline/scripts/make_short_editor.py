# -*- coding: utf-8 -*-
"""
make_short_editor.py — "העורך החכם": הכרעה בהבנה בין שתי האוזניים, לפני שהוא רואה את הטקסט (28/10/2026).

למה (תלונתו, 28/10): בשורטס ש-Claude עושה הוא מתקן מילה פה ושם; בתוכנה — כמעט כל שורט צריך תיקונים. ההבדל:
אצל Claude שתי האוזניים הן חומר גלם, ומישהו *מכריע* — שומע, מבין את ההקשר, מכיר פסוקים וניבים. התוכנה רק
הציגה את המחלוקת ([א / ב]) ולקחה את אוזן 1. כאן שלב שמכריע: בקשה אחת ל-Gemini עם השמע של כל הקליפים (גם של
כמה שיעורים יחד — חיסכון בבקשות), שתי האוזניים, כתוביות יוטיוב, ההקשר (רב / סדרה / נושא), הכללים והמילון
האישי שלו. חוזר: טקסט סופי לכל קליף + רק ספקות אמיתיים (2–3 אפשרויות ועוד עד 5 חלופות, ושורה למה).

🚨 מגינים:
  - כל תשובה נבדקת מול אוזן 1 (כיסוי ≥90%, אין חור של יותר מ-3 שניות, לא נוספו משפטים שאף אוזן לא שמעה).
    קליף שנכשל — נשאר בטקסט של היום (שתי האוזניים), עם הודעה. לא מנחשים איזה טקסט שייך לאיזה קליף.
  - מכסה: כל בקשה נספרת במונה (PICK.gemini_call); עצירה של Google (429/403) — עוצרים, בלי ניסיון חוזר ובלי
    מודל אחר. אין Gemini → "העתק לצ'אט" (טקסטים + כללים, בלי שמע) עם תיבת הדבקה שמוחלת באותה דרך.
  - טקסט שהוא כבר תיקן בזמן שהעורך חיכה — נמזג (merge3), לא נדרס.

שימוש (החלון מריץ כעבודה):
  make_short_editor.py run <project> [<project> ...]     ← בקשה אחת (או כמה, אם גדול מדי) לכל השיעורים
  make_short_editor.py paste <project> <answer.txt>       ← תשובה מצ'אט
  make_short_editor.py chat <project> [...]               ← הבלוק להעתקה
"""
import base64
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import make_short_settings as SET  # noqa: E402
import make_short_pick as PICK  # noqa: E402
import make_short_rabbis as RB  # noqa: E402

ED_DIR = Path("work") / "editor"
GLOSSARY = Path(os.environ.get("MAKE_SHORT_GLOSSARY") or SET.CONFIG / "glossary.json")
QUALITY = Path(os.environ.get("MAKE_SHORT_QUALITY") or
               PICK.DATA / ("text_quality_test.jsonl" if MS.TEST_MODE else "text_quality.jsonl"))
# גבולות לבקשה אחת: השמע נשלח בתוך הבקשה (inline, ‏base64 ≈ ×1.33) ו-Google מקבל עד 20MB לבקשה
MAX_AUDIO_BYTES = int(os.environ.get("MAKE_SHORT_EDITOR_MAX_BYTES", "11000000"))
MAX_CLIPS = int(os.environ.get("MAKE_SHORT_EDITOR_MAX_CLIPS", "14"))
THINKING = int(os.environ.get("MAKE_SHORT_EDITOR_THINKING", "4096"))
MIN_COVER = 0.90
MAX_GAP = 3.0
MAX_ADDED_RUN = 7
PUNCT = ",.?!:;"


def say(msg):
    print(msg, flush=True)


# ═══════════════════════ טקסט ═══════════════════════

def norm(t):
    return MS.norm(t)


def brackets(text):
    return list(re.finditer(r"\[([^\]]*)\]", text or ""))


def resolved(text):
    """הטקסט שייצרב אם לא יכריעו: בכל [א / ב] — הראשונה ("—" = כלום)."""
    def first(m):
        a = m.group(1).split("/")[0].strip()
        return "" if a in ("—", "-") else a
    return " ".join(re.sub(r"\[([^\]]*)\]", first, text or "").split())


def ntoks(text):
    return [x for x in (norm(t) for t in (text or "").split()) if x]


def changed_words(a, b):
    """כמה מילים שונו בין שני טקסטים (בלי פיסוק): החלפה/הוספה/מחיקה — לפי הצד הארוך."""
    x, y = ntoks(a), ntoks(b)
    n = 0
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, x, y, autojunk=False).get_opcodes():
        if op != "equal":
            n += max(i2 - i1, j2 - j1)
    return n, len(y)


def clean_opt(o):
    o = " ".join(str(o or "").replace("[", "").replace("]", "").replace("/", " ").split())
    return o or "—"


def canon(text):
    """[ א/ב ] → [א / ב], בלי אפשרויות כפולות; סוגריים עם אפשרות אחת — פשוט המילה."""
    def fix(m):
        opts = []
        for o in m.group(1).split("/"):
            o = clean_opt(o)
            if o not in opts:
                opts.append(o)
        if len(opts) == 1:
            return "" if opts[0] == "—" else opts[0]
        return "[%s]" % " / ".join(opts[:3])
    return " ".join(re.sub(r"\[([^\]]*)\]", fix, text or "").split())


# ═══════════════════════ קלט לקליף ═══════════════════════

def _words(path):
    try:
        return [w for w in json.load(open(path, encoding="utf-8"))["words"] if w["word"].strip()]
    except (OSError, ValueError, KeyError, TypeError):
        return None


def ear2_words(P, c, e1):
    """אוזן 2 של הקליף כמו שהוא עכשיו: מה שההכנה רשמה (מ-28/10), אחרת התמלול של turbo שהכי דומה לאוזן 1
    (אחרי "להזיז גבולות" יש כמה תיקיות — לוקחים את זו של החיתוך הנוכחי)."""
    if c.get("ear2"):
        w = _words(P / c["ear2"])
        if w:
            return w
    tag = hashlib.md5(json.dumps(c["cuts"]).encode()).hexdigest()[:8]
    cands = [P / "work" / ("ear_turbo_rt_%s" % tag) / ("%s_words.json" % c["name"])]
    cands += sorted((P / "work").glob("ear_turbo_*/%s_words.json" % c["name"]), key=lambda p: -p.stat().st_mtime)
    a = [norm(w["word"]) for w in e1]
    best, score = None, 0.0
    for f in cands:
        w = _words(f)
        if not w:
            continue
        r = difflib.SequenceMatcher(None, a, [norm(x["word"]) for x in w], autojunk=False).ratio()
        if r > score:
            best, score = w, r
    return best if score >= 0.5 else None


def clip_input(P, st, c):
    P = Path(P)
    e1 = _words(P / c["ear1"]) or []
    e2 = ear2_words(P, c, e1) or []
    raw = MS.read_edit_raw(P / c["edit"])
    yt = raw.get("yt") or ""
    if yt.startswith("(אין"):
        yt = ""
    return {"P": P, "name": c["name"], "c": c, "ear1": e1, "ear2": e2, "yt": yt, "raw": raw,
            "ear1_text": " ".join(w["word"].strip() for w in e1), "ear2_text": " ".join(w["word"].strip() for w in e2),
            "title": raw.get("title") or "", "seconds": c.get("seconds") or 0}


def audio_bytes(P, c, a=None, b=None):
    """השמע של הקליף (או חלון ממנו) — mp3 מונו 16k, 32kbps: דקה ≈ 240KB."""
    out = Path(P) / ED_DIR / ("%s%s.mp3" % (c["name"], "" if a is None else "_%d_%d" % (a * 10, b * 10)))
    src = Path(P) / c["clean"]
    if not out.exists() or out.stat().st_mtime < src.stat().st_mtime:
        out.parent.mkdir(parents=True, exist_ok=True)
        cmd = [MS.FFMPEG, "-nostdin", "-loglevel", "error", "-y"]
        if a is not None:
            cmd += ["-ss", "%.2f" % a, "-to", "%.2f" % b]
        cmd += ["-i", str(src), "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "32k", str(out)]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError("חיתוך השמע נכשל: %s" % (r.stderr or "")[-200:])
    return out.read_bytes()


# ═══════════════════════ מילון אישי ═══════════════════════
# כל שמירה של קליף: מה שונה בין הטקסט שהתוכנה מסרה לבין מה שהוא שמר. החלפות קצרות (1–3 מילים) של שמות,
# ספרים, מונחים, ניבים — נשמרות כאן (בלי שום סוד), נכנסות לבקשה של העורך, והנכונות גם כרמז ל-whisper.

STOP = set("את של על אל לא לו כל הכל זה זו זאת הוא היא הם הן אני אתה אנחנו מה מי כי גם רק אבל אז כן נו אם עם "
           "יש אין היה היו הזה הזאת כך כמו או".split())
PREFIX = "והבכלמש"


def glossary_load():
    try:
        d = json.loads(GLOSSARY.read_text(encoding="utf-8"))
        if isinstance(d, dict) and isinstance(d.get("entries"), list):
            d.setdefault("blocked", [])
            return d
    except (OSError, ValueError):
        pass
    return {"entries": [], "blocked": []}


def glossary_save(d):
    import make_short_guard
    make_short_guard.assert_not_real_config(GLOSSARY)     # 4.1.2
    GLOSSARY.parent.mkdir(parents=True, exist_ok=True)
    tmp = GLOSSARY.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(GLOSSARY)


def _strip_prefix(w):
    while len(w) > 2 and w[0] in PREFIX:
        w = w[1:]
    return w


def learn_pairs(delivered, final):
    """זוגות (מה נמסר → מה תיקן) שראויים למילון. לא: פיסוק, מחיקות (מלמולים), שינוי של אות שימוש בלבד
    (ו/ה/ב/ל…), מילות קישור קצרות — אלה לא "מונחים", ורמז כזה ל-whisper רק היה מבלבל אותו."""
    a = (delivered or "").split()
    b = (final or "").split()
    na, nb = [norm(x) for x in a], [norm(x) for x in b]
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, na, nb, autojunk=False).get_opcodes():
        if op != "replace" or not (1 <= i2 - i1 <= 3 and 1 <= j2 - j1 <= 3):
            continue
        wrong = " ".join(x for x in na[i1:i2] if x)
        right_toks = [x.strip(PUNCT + "\"'״׳()") for x in b[j1:j2]]
        right = " ".join(x for x in right_toks if x)
        if not wrong or not right or wrong == norm(right).replace(" ", "") or norm(right) == wrong:
            continue
        rn = [x for x in nb[j1:j2] if x]
        if all(x in STOP for x in rn) or len("".join(rn)) < 3:
            continue
        if " ".join(_strip_prefix(x) for x in na[i1:i2]) == " ".join(_strip_prefix(x) for x in rn):
            continue
        out.append((wrong, right))
    return out


def glossary_learn(pairs, where=""):
    if not pairs:
        return 0
    d = glossary_load()
    blocked = {(x.get("wrong"), x.get("right")) for x in d["blocked"]}
    n = 0
    for wrong, right in pairs:
        if (wrong, right) in blocked or (None, right) in blocked:
            continue
        e = next((e for e in d["entries"] if e["right"] == right and e.get("wrong") == wrong), None)
        if e:
            e["n"] = e.get("n", 1) + 1
            e["last"] = time.strftime("%Y-%m-%d")
        else:
            d["entries"].append({"right": right, "wrong": wrong, "n": 1, "added": time.strftime("%Y-%m-%d"),
                                 "last": time.strftime("%Y-%m-%d"), "src": where})
        n += 1
    d["entries"] = sorted(d["entries"], key=lambda e: (-e.get("n", 1), e["right"]))[:400]
    glossary_save(d)
    return n


def glossary_edit(action, right="", wrong=""):
    """מההגדרות: remove (ולא ללמוד שוב את אותו זוג) / add (ידני) / reset (הכול, עם ביטול) / undo."""
    d = glossary_load()
    if action == "remove":
        d["entries"] = [e for e in d["entries"] if not (e["right"] == right and (e.get("wrong") or "") == (wrong or ""))]
        d["blocked"].append({"right": right, "wrong": wrong or None})
    elif action == "add":
        right = " ".join(str(right).split())[:60]
        if not right:
            raise ValueError("לכתוב את המילה הנכונה")
        wrong = " ".join(norm(x) for x in str(wrong or "").split()) or None
        d["blocked"] = [b for b in d["blocked"] if b.get("right") != right]
        if not any(e["right"] == right and e.get("wrong") == wrong for e in d["entries"]):
            d["entries"].insert(0, {"right": right, "wrong": wrong, "n": 1, "added": time.strftime("%Y-%m-%d"),
                                    "last": time.strftime("%Y-%m-%d"), "src": "ידני"})
    elif action == "reset":
        d["undo"] = {"entries": d["entries"], "at": time.strftime("%Y-%m-%d %H:%M")}
        d["entries"] = []
    elif action == "undo":
        if not d.get("undo"):
            raise ValueError("אין מה לבטל")
        d["entries"] = d["undo"]["entries"] + [e for e in d["entries"] if e not in d["undo"]["entries"]]
        d.pop("undo", None)
    else:
        raise ValueError("פעולה לא מוכרת")
    glossary_save(d)
    return glossary_view()


def glossary_view():
    d = glossary_load()
    return {"entries": d["entries"], "can_undo": bool(d.get("undo")), "path": str(GLOSSARY)}


def glossary_prompt(limit=80, rabbis=()):
    """המילון האישי + (כרטיס 25) מילים של הרבנים האלה מהפרופיל שלהם — בלוק נפרד, כי הן ספציפיות לדובר."""
    es = glossary_load()["entries"][:limit]
    rb = RB.prompt_text(rabbis) if rabbis else ""
    if not es:
        return rb
    return ("\nמילון אישי — תיקונים שהעורך האנושי עשה בעבר (כשנשמע דומה, כנראה זה הנכון; לא להכניס כשלא נאמר):\n" +
            "\n".join("- %s%s" % (e["right"], (" (במקום \"%s\")" % e["wrong"]) if e.get("wrong") else "") for e in es) + "\n") + rb


def asr_hint(limit=25, rabbi=None):
    """רמז ל-whisper (אוזן 1): המילים הנכונות מהמילון, הנפוצות קודם (מילי הרב מהפרופיל — ראשונות). ריק = ברירת המחדל של Modal."""
    if not SET.load().get("glossary_asr_hint", True):
        return ""
    words = list(RB.hint_words(rabbi)) if rabbi else []
    for e in glossary_load()["entries"]:
        if e["right"] not in words:
            words.append(e["right"])
        if len(words) >= limit:
            break
    if not words:
        return ""
    return "שיעור תורני. לשון תורנית, ציטוטי גמרא ומדרש. " + ", ".join(words) + "."


def hint_suspect(w1, w2):
    """אוזן 1 (עם רמז) חסרה לעומת אוזן 2 (בלי רמז)? התחלה שנבלעה, סוף שנחתך, או הרבה פחות מילים."""
    w1 = [w for w in w1 or [] if w["word"].strip()]
    w2 = [w for w in w2 or [] if w["word"].strip()]
    if not w2:
        return False
    if not w1:
        return True
    return (w1[0]["start"] - w2[0]["start"] > 2.5 or w2[-1]["end"] - w1[-1]["end"] > 2.5
            or len(w1) < 0.85 * len(w2))


# ═══════════════════════ מד איכות ═══════════════════════

def delivered_path(P, name):
    return Path(P) / ED_DIR / ("delivered_%s.txt" % name)


def write_delivered(P, name, text, src):
    """מה שהתוכנה "מסרה" לו (בלי הכרעה שלו — בכל ספק האפשרות הראשונה). בסיס למד האיכות ולמילון."""
    f = delivered_path(P, name)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps({"text": resolved(text), "src": src, "at": time.strftime("%Y-%m-%d %H:%M")},
                            ensure_ascii=False), encoding="utf-8")


def read_delivered(P, name):
    try:
        return json.loads(delivered_path(P, name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def on_saved(P, st, names):
    """אחרי "💾 שמור": כמה מילים תיקן בכל קליף לעומת מה שנמסר (נשמר בקליף + ביומן), והמילון לומד מהתיקונים."""
    P = Path(P)
    out = {}
    for c in st["clips"]:
        if c["name"] not in names or c.get("dropped"):
            continue
        d = read_delivered(P, c["name"])
        if not d:
            continue
        _, final, _ = MS.parse_edit(P / c["edit"])
        n, tot = changed_words(d["text"], final)
        q = {"changed": n, "words": tot, "src": d.get("src") or "ears", "at": time.strftime("%Y-%m-%d %H:%M")}
        out[c["name"]] = q
        try:
            QUALITY.parent.mkdir(parents=True, exist_ok=True)
            with open(QUALITY, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(dict(q, lesson=P.name, clip=c["name"]), ensure_ascii=False) + "\n")
        except OSError:
            pass
        try:
            pairs = learn_pairs(d["text"], final)
            glossary_learn(pairs, where=P.name)
            if st.get("rabbi"):                # כרטיס 25: ספירה לכל רב — אחרי 2 פעמים מציעים (בלחיצה שלו) להוסיף לפרופיל
                RB.note_corrections(st["rabbi"], pairs, where="%s/%s" % (P.name, c["name"]))
        except Exception as e:                 # המילון הוא תוספת — שמירה לעולם לא נכשלת בגללו
            say("(המילון לא התעדכן: %s)" % e)
    return out


def quality_summary():
    """לחלון ההגדרות: ממוצע מילים שתוקנו לקליף — עם העורך ובלי (הרשומה האחרונה של כל קליף)."""
    last = {}
    try:
        for line in QUALITY.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(line)
                last[(r["lesson"], r["clip"])] = r
            except (ValueError, KeyError):
                continue
    except OSError:
        pass
    by = {}
    for r in last.values():
        k = "editor" if str(r.get("src", "")).startswith(("gemini", "chat")) else "ears"
        b = by.setdefault(k, {"clips": 0, "changed": 0, "words": 0})
        b["clips"] += 1
        b["changed"] += r.get("changed", 0)
        b["words"] += r.get("words", 0)
    for b in by.values():
        b["avg"] = round(b["changed"] / b["clips"], 1) if b["clips"] else 0
        b["pct"] = round(100.0 * b["changed"] / b["words"], 1) if b["words"] else 0
    return by


# ═══════════════════════ הבקשה ═══════════════════════

def org_text(t):
    """3.4: שם הישיבה מההגדרות (📝) במקום שם קבוע בקוד. ריק = "של שיעורי תורה" בלי שם."""
    org = (SET.load().get("org_name") or "").strip()
    return t.replace("«MI_ORG»", " מ" + org if org else "").replace("«P_ORG»", " (%s)" % org if org else "")


RULES = """אתה עורך כתוביות לשורטס (סרטונים קצרים) של שיעורי תורה«MI_ORG».
לכל קטע מצורף השמע שלו, ושלוש קריאות אוטומטיות של מה שנאמר בו:
  אוזן 1 = whisper large-v3 עברי (בדרך כלל המדויקת ביותר), אוזן 2 = whisper turbo, יוטיוב = הכתוביות האוטומטיות של יוטיוב (מנוע אחר לגמרי).
הקריאות הן חומר גלם. התפקיד שלך: להאזין, להבין את התוכן, ולהכריע מה הרב אמר בדיוק — ולכתוב את הטקסט הסופי של הכתוביות.

כללים:
1. המילים המדויקות שנאמרו. לא לשפר ניסוח, לא לתקן דקדוק של הרב, לא לסכם, לא לקצר.
2. אסור להשמיט משפטים — כל מה שנאמר בקטע נכנס, מההתחלה ועד הסוף. מותר להשמיט רק מלמול/גמגום/"אה"/"אממ" או מילה בודדת שאי אפשר להבין גם אחרי האזנה.
3. אסור להמציא שום דבר שלא נשמע בשמע — בפרט תוכן הלכתי.
4. פסוק או מאמר חז"ל — בנוסח המקורי המדויק (מה שנאמר; אם הרב קיצר — כמו שאמר). חכמים — בתואר המלא (רבן שמעון בן גמליאל, רבי עקיבא).
5. ארמית וניבים תלמודיים ("היכי תמצי", "מאי נפקא מינה", "קל וחומר") — לזהות ולכתוב נכון. מילה שכל הקריאות "שמעו" אבל אינה מילה אמיתית — כמעט תמיד ניב או מילה ארמית: לחשוב מה נאמר באמת.
6. ראשי תיבות בעברית עם גרשיים (חז"ל, רמב"ם, הקב"ה). מילה שנאמרה באנגלית / קיצור לועזי (D9, AI) — באותיות לטיניות.
7. פיסוק = איפה ששורת כתובית נגמרת: פסיק במקום שהרב עוצר, נקודה בסוף משפט, סימן שאלה בשאלה. בלי מירכאות מיותרות ובלי סוגריים עגולים.
8. רוב קולות בין הקריאות אינו הכרעה: מילים קצרות (כל/הכל, לו/לא, על/אל, הלאה/למעלה) — להקשיב לשמע ולהחליט לפי ההקשר.
9. ספק — רק כשגם אחרי האזנה יש באמת שתי קריאות סבירות. כותבים אותו בתוך הטקסט כך: [הסבירה ביותר / אפשרות שנייה] — עד 3 אפשרויות, מופרדות ב-" / "; "—" = אולי לא נאמר כלום. הראשונה בסוגריים היא מה שייכנס לסרטון אם לא יכריעו. אין ספק על פיסוק בלבד. אין סוגריים מרובעים לשום דבר אחר.
10. לכל ספק, ברשימת doubts (באותו סדר כמו בטקסט): "options" = האפשרויות שבסוגריים, "more" = עד 5 חלופות נוספות ושונות (מילים שנשמעות דומה ומתאימות להקשר), "why" = שורה קצרה למה זה ספק.
"""

FORMAT = """
פורמט התשובה — JSON בלבד, בלי שום טקסט לפניו או אחריו:
{"clips":[{"n":1,"text":"הטקסט הסופי המלא, עם [א / ב] בספקות","doubts":[{"options":["א","ב"],"more":["ג","ד"],"why":"..."}]}]}
קטע אחד לכל "### קטע N" (n = המספר שלו), בלי לדלג ובלי לאחד קטעים.
"""

CHAT_NOTE = """
⚠️ אין כאן שמע — רק הקריאות. הכרע לפי ההקשר, ההיגיון, הפסוקים והמקורות; כשבאמת אי אפשר לדעת בלי לשמוע — ספק.
"""


def _ctx_line(it, st):
    return "שיעור: %s · %s · נושא הקליף: %s · %.0f שניות" % (
        st.get("video_title") or "", " · ".join(x for x in (st.get("rabbi"), st.get("series")) if x),
        it["title"] or "?", it["seconds"])


def _clip_block(k, it, st):
    return ("\n### קטע %d\n%s\nאוזן 1: %s\nאוזן 2: %s\nיוטיוב: %s\n" %
            (k, _ctx_line(it, st), it["ear1_text"] or "(אין)", it["ear2_text"] or "(אין)", it["yt"] or "(אין)"))


def build_request(items, chat=False):
    """items = [(it, st)] → (טקסט, parts של שמע)."""
    rules = RULES.replace("לכל קטע מצורף השמע שלו, ושלוש", "לכל קטע — שלוש") if chat else RULES
    rules = org_text(rules)
    head = rules + glossary_prompt(rabbis=list(dict.fromkeys(st.get("rabbi") for _, st in items if st.get("rabbi")))) + \
        (CHAT_NOTE if chat else "") + FORMAT + "\nהקטעים:\n"
    body, parts = [], []
    for k, (it, st) in enumerate(items, 1):
        body.append(_clip_block(k, it, st))
        if not chat:
            parts.append({"text": "### קטע %d — השמע" % k})
            parts.append({"inline_data": {"mime_type": "audio/mpeg",
                                          "data": base64.b64encode(audio_bytes(it["P"], it["c"])).decode("ascii")}})
    return head + "".join(body), parts


def groups_of(items):
    """חלוקה לבקשות לפי גודל השמע ומספר הקליפים (הכי מעט בקשות שאפשר)."""
    out, cur, size = [], [], 0
    for it in items:
        try:
            b = len(audio_bytes(it[0]["P"], it[0]["c"]))
        except (RuntimeError, OSError):
            b = 0
        if cur and (size + b > MAX_AUDIO_BYTES or len(cur) >= MAX_CLIPS):
            out.append(cur)
            cur, size = [], 0
        cur.append(it)
        size += b
    if cur:
        out.append(cur)
    return out


def _json_obj(text, key):
    """ה-JSON מהתשובה. 🚨 _json_chunks מנסה קודם [...] — בתשובה {"doubts":[{"options":[…]}]} זה תפס את הרשימה
    הפנימית (נמצא בבדיקה העצמית, 28/10). לכן: קודם אובייקט שיש בו המפתח, ורק אחר כך כל JSON תקין."""
    found = []
    for chunk in PICK._json_chunks(text or ""):
        for s in (chunk, PICK._repair(chunk)):
            try:
                found.append(json.loads(s))
                break
            except ValueError:
                continue
    for d in found:
        if isinstance(d, dict) and key in d:
            return d
    return found[0] if found else None


def parse_answer(text, n):
    """→ {k: {"text", "doubts"}} לקטעים 1..n שחזרו תקינים. סובלני לגדרות קוד ולמירכאות של צ'אט."""
    data = _json_obj(text, "clips")
    if isinstance(data, list):
        data = {"clips": data}
    if not isinstance(data, dict) or not isinstance(data.get("clips"), list):
        raise ValueError("התשובה לא בפורמט שביקשנו (JSON עם clips)")
    out = {}
    for i, c in enumerate(data["clips"], 1):
        if not isinstance(c, dict):
            continue
        try:
            k = int(c.get("n") or c.get("clip") or i)
        except (TypeError, ValueError):
            k = i
        t = c.get("text") or c.get("final") or ""
        if not isinstance(t, str) or not t.strip() or not 1 <= k <= n or k in out:
            continue
        ds = [d for d in (c.get("doubts") or []) if isinstance(d, dict)]
        out[k] = {"text": t, "doubts": ds}
    return out


# ═══════════════════════ בדיקת התשובה ═══════════════════════

def check(it, text):
    """(ok, סיבה, מדדים): התשובה מכסה את מה שאוזן 1 שמעה. בכל ספק — כל האפשרויות נחשבות "נאמרו"."""
    e1 = [w for w in it["ear1"] if norm(w["word"])]
    if not e1:
        return True, "", {"cover": 1.0}
    a = [norm(w["word"]) for w in e1]
    flat = re.sub(r"\[([^\]]*)\]", lambda m: m.group(1).split("/")[0], text)
    b = ntoks(flat)
    if not b:
        return False, "טקסט ריק", {"cover": 0.0}
    others = set(ntoks(it["ear2_text"])) | set(ntoks(it["yt"])) | set(a)
    for m in brackets(text):
        others |= set(ntoks(m.group(1).replace("/", " ")))
    dropped = [False] * len(a)
    worst_add = 0
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == "delete":
            for i in range(i1, i2):
                dropped[i] = True
        elif op == "replace" and (i2 - i1) > (j2 - j1) + 1:
            for i in range(i1 + (j2 - j1), i2):
                dropped[i] = True
        if op in ("insert", "replace") and (j2 - j1) - (i2 - i1) > 0:
            new = b[j1:j2]
            unknown = [x for x in new if x not in others]
            if len(unknown) >= MAX_ADDED_RUN:
                worst_add = max(worst_add, len(unknown))
    cover = 1.0 - sum(dropped) / len(a)
    gap, k = 0.0, 0
    while k < len(a):
        if dropped[k]:
            j = k
            while j + 1 < len(a) and dropped[j + 1]:
                j += 1
            gap = max(gap, e1[j]["end"] - e1[k]["start"])
            k = j + 1
        else:
            k += 1
    st = {"cover": round(cover, 3), "gap": round(gap, 1), "added": worst_add}
    if cover < MIN_COVER:
        return False, "חסר הרבה ממה שנשמע (כיסוי %d%%)" % round(cover * 100), st
    if gap > MAX_GAP:
        return False, "נשמט קטע של %.1f שניות" % gap, st
    if worst_add:
        return False, "נוספו %d מילים שאף תמלול לא שמע" % worst_add, st
    return True, "", st


def times_for(text, ear1):
    """לכל ספק בטקסט — הזמן בקליף (לכפתור ▶ ולחלון השמע של "חפש הצעות אחרות")."""
    toks, pos = [], []
    for m in re.finditer(r"\[[^\]]*\]|\S+", text):
        if m.group(0).startswith("["):
            pos.append(len(toks))
            toks.append(norm(m.group(0)[1:-1].split("/")[0]) or "—")
        else:
            toks.append(norm(m.group(0)))
    a = [norm(w["word"]) for w in ear1]
    mp = {}
    for blk in difflib.SequenceMatcher(None, toks, a, autojunk=False).get_matching_blocks():
        for k in range(blk.size):
            mp[blk.a + k] = blk.b + k
    out = []
    for p in pos:
        t = 0.0
        if ear1:
            prev = max([k for k in mp if k < p], default=None)
            nxt = min([k for k in mp if k > p], default=None)
            if prev is not None:
                t = ear1[min(len(ear1) - 1, mp[prev] + 1)]["start"] if nxt is None or mp[nxt] > mp[prev] + 1 \
                    else ear1[mp[prev]]["end"]
            elif nxt is not None:
                t = max(0.0, ear1[mp[nxt]]["start"] - 0.4)
        out.append(round(t, 2))
    return out


# ═══════════════════════ החלה ═══════════════════════

def _write_state(P, fn):
    """שינוי של make_short.json מתוך עבודה: קריאה טרייה, שינוי, כתיבה אטומית (החלון כותב בו גם)."""
    f = Path(P) / MS.STATE
    st = json.load(open(f, encoding="utf-8"))
    fn(st)
    tmp = f.with_suffix(".json.ed.tmp")
    json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    tmp.replace(f)
    return st


def set_status(P, **kv):
    def upd(st):
        e = dict(st.get("editor") or {})
        e.update(kv)
        e["updated"] = time.time()
        st["editor"] = e
    return _write_state(P, upd)


def apply_clip(it, res, src):
    """התשובה של העורך → קובץ העריכה (עם מיזוג של מה שהוא כבר תיקן בינתיים), ספקות + זמנים, "עוד הצעות"."""
    P, c = it["P"], it["c"]
    text = canon(res["text"])
    ds = res.get("doubts") or []
    brs = brackets(text)
    more = {}
    for k, m in enumerate(brs):
        opts = [clean_opt(o) for o in m.group(1).split("/")]
        d = ds[k] if k < len(ds) else {}
        if d and set(clean_opt(o) for o in d.get("options") or []) - set(opts):
            d = next((x for x in ds if set(clean_opt(o) for o in x.get("options") or []) == set(opts)), d)
        extra = [clean_opt(o) for o in (d.get("more") or []) if isinstance(o, str)]
        extra = [o for o in dict.fromkeys(extra) if o not in opts and o != "—"][:5]
        more[m.group(0)] = {"more": extra, "why": " ".join(str(d.get("why") or "").split())[:160]}
    f = P / c["edit"]
    raw = MS.read_edit_raw(f)
    base = c.get("editor_base") or ""
    merged_note = None
    if base and MS.edit_ver(f) != base:
        b = MS.version_text(P, f, base)
        if b and b["text"].strip() != raw["text"].strip():
            text, n, conf = MS.merge3(b["text"], raw["text"], text)
            merged_note = {"applied": n, "conflicts": conf}
    MS.write_edit(f, c, P, raw["title"], raw["desc"], raw["tags"], text, raw["yt"])
    ts = times_for(text, it["ear1"])
    doubts = [[t, m.group(0)] for t, m in zip(ts, brackets(text))]
    write_delivered(P, c["name"], text, src)
    info = {"src": src, "at": time.strftime("%Y-%m-%d %H:%M"), "doubts": len(doubts),
            "before": len(c.get("doubts") or []), **({"merged": merged_note} if merged_note else {})}

    def upd(st):
        for x in st["clips"]:
            if x["name"] == c["name"]:
                x["doubts"] = doubts
                x["doubt_more"] = {k: v for k, v in more.items() if any(d[1] == k for d in doubts)}
                x["editor"] = info
    _write_state(P, upd)
    return info


def items_for(P):
    P = Path(P)
    st = json.load(open(P / MS.STATE, encoding="utf-8"))
    return st, [clip_input(P, st, c) for c in st["clips"] if not c.get("dropped")]


def apply_answer(batch, text, src):
    """batch = [(it, st)] בסדר של הבקשה. מחזיר {project: [(clip, ok, msg)]}."""
    got = parse_answer(text, len(batch))
    out = {}
    for k, (it, st) in enumerate(batch, 1):
        r = got.get(k)
        res = out.setdefault(str(it["P"]), [])
        if not r:
            res.append((it["name"], False, "הקטע לא חזר בתשובה"))
            continue
        ok, why, stats = check(it, canon(r["text"]))
        if not ok:
            res.append((it["name"], False, why))
            continue
        info = apply_clip(it, r, src)
        res.append((it["name"], True, "%d ספקות (היו %d) · כיסוי %d%%" % (info["doubts"], info["before"],
                                                                         round(stats["cover"] * 100))))
    return out


def _finish_status(P, results, src):
    bad = [(n, m) for n, ok, m in results if not ok]
    good = [n for n, ok, _ in results if ok]
    if good and not bad:
        set_status(P, status="done", src=src, at=time.strftime("%H:%M"), msg="", failed=[])
    elif good:
        set_status(P, status="partial", src=src, at=time.strftime("%H:%M"),
                   msg="העורך לא הצליח ב-%s — שם נשאר הטקסט של שתי האוזניים" % ", ".join(
                       "%s (%s)" % (n.replace("clip", "קליף "), m) for n, m in bad),
                   failed=[n for n, _ in bad])
    else:
        set_status(P, status="failed", src=src, at=time.strftime("%H:%M"),
                   msg="התשובה של העורך לא עברה את הבדיקה (%s) — נשאר הטקסט של שתי האוזניים" %
                   "; ".join("%s: %s" % (n.replace("clip", "קליף "), m) for n, m in bad), failed=[n for n, _ in bad])


def run(projects):
    """בקשה אחת (או כמה, אם גדול מדי) לכל הקליפים של כל השיעורים. מחזיר 0 גם כשהעורך לא זמין —
    המצב נרשם בכל שיעור (chat / failed), והחלון מחליט מה הלאה."""
    batch = []
    for p in projects:
        P = Path(p)
        try:
            st, items = items_for(P)
        except (OSError, ValueError) as e:
            say("   ⚠️ %s: %s" % (P.name, e))
            continue
        set_status(P, status="sending", at=time.strftime("%H:%M"), with_=[str(x) for x in projects if x != p])
        batch += [(it, st) for it in items]
        say("PROJECT=%s" % P)
    if not batch:
        say("אין קליפים לעורך")
        return 0
    say("STAGE=working")
    groups = groups_of(batch)
    say("🧠 העורך החכם: %d קליפים מ-%d שיעורים → %d %s ל-Gemini" % (
        len(batch), len({str(it["P"]) for it, _ in batch}), len(groups), "בקשה" if len(groups) == 1 else "בקשות"))
    per = {}
    stop = None
    if not PICK.step_direct("editor"):          # 28/10: בהגדרות — העורך תמיד דרך "העתק לצ'אט"
        stop = PICK.GeminiStop("chat_mode", PICK.CHAT_MODE_MSG)
    else:
        left = PICK.margin_left()
        if left is not None and left < len(groups):
            # 28/10: לפני בקשה משותפת — האם היא נכנסת מתחת ל"X לפני הגבול". לא נכנסת כולה → לא שולחים חצי
            stop = PICK.GeminiStop("quota_margin", PICK.margin_msg())
    if stop:
        say("   📋 %s" % stop)
    for gi, g in enumerate(groups, 1):
        if stop:
            for it, _ in g:
                per.setdefault(str(it["P"]), []).append((it["name"], None, str(stop)))
            continue
        prompt, parts = build_request(g)
        say("   בקשה %d/%d: %d קליפים (%.1fMB שמע)…" % (gi, len(groups), len(g),
                                                    sum(len(p.get("inline_data", {}).get("data", "")) for p in parts) * 0.75 / 1e6))
        try:
            # 4.1.1: היה 900 שניות (רבע שעה של "עובד" מול Gemini מת). עכשיו editor_timeout_sec (240) — ובעומס/אין תשובה
            # אין ניסיון חוזר: העורך מוותר, והשיעור ממשיך עם הטקסט של שתי האוזניים
            text = PICK.gemini_call(prompt, parts=parts, timeout=int(SET.load().get("editor_timeout_sec", 240)),
                                    temperature=0.2, thinking=THINKING)
        except PICK.GeminiStop as e:
            say("   ⛔ %s" % e)
            stop = e
            for it, _ in g:
                per.setdefault(str(it["P"]), []).append((it["name"], None, str(e)))
            continue
        Path(g[0][0]["P"] / ED_DIR).mkdir(parents=True, exist_ok=True)
        for it, _ in g:                         # התשובה הגולמית נשמרת בכל שיעור שבבקשה (לבדיקה אחר כך)
            (it["P"] / ED_DIR / ("gemini_%s.txt" % time.strftime("%Y%m%d_%H%M%S"))).write_text(text, encoding="utf-8")
        try:
            res = apply_answer(g, text, "gemini")
        except ValueError as e:
            say("   ⚠️ לא הצלחתי לקרוא את התשובה: %s" % e)
            res = {}
            for it, _ in g:
                res.setdefault(str(it["P"]), []).append((it["name"], False, str(e)))
        for p, rs in res.items():
            per.setdefault(p, []).extend(rs)
            for n, ok, m in rs:
                say("   %s %s / %s: %s" % ("✓" if ok else "✗", Path(p).name[-14:], n, m))
    for p, rs in per.items():
        if any(ok is None for _, ok, _ in rs):
            kind = getattr(stop, "kind", "error")
            set_status(p, status="chat", at=time.strftime("%H:%M"), kind=kind,
                       msg=PICK.skip_msg(kind, stop), skipped=kind in PICK.SKIP_WHY)
            say("EDITOR=%s\tchat" % p)
        else:
            _finish_status(p, rs, "gemini")
            say("EDITOR=%s\t%s" % (p, json.load(open(Path(p) / MS.STATE, encoding="utf-8"))["editor"]["status"]))
    say("STAGE=done")
    return 0


# ═══════════════════════ העתק לצ'אט ═══════════════════════

def chat_block(projects):
    batch = []
    for p in projects:
        st, items = items_for(p)
        batch += [(it, st) for it in items]
    text, _ = build_request(batch, chat=True)
    return text, len(batch)


def paste(projects, answer):
    batch = []
    for p in projects:
        st, items = items_for(p)
        batch += [(it, st) for it in items]
    res = apply_answer(batch, answer, "chat")
    for p, rs in res.items():
        _finish_status(p, rs, "chat")
    return {p: [{"clip": n, "ok": ok, "msg": m} for n, ok, m in rs] for p, rs in res.items()}


# ═══════════════════════ "🔍 חפש הצעות אחרות" ═══════════════════════

ALTS_PROMPT = """אתה עוזר לעורך כתוביות של שיעור תורה«P_ORG». בכל אחד מהספקות למטה — מילה או צירוף שהתמלול
לא בטוח בהם. מצורף שמע קצר סביב כל ספק ("### ספק N"), והמשפט שבו הוא מופיע.
האפשרויות שכבר הוצעו — **פסולות**: אל תחזור על אף אחת מהן. הצע עד 5 קריאות *אחרות* ששומעים בשמע ושמתאימות להקשר
(ניב, ארמית, שם של ספר או חכם, מילה דומה בצליל), מהסבירה ביותר. אם אין שום קריאה אחרת סבירה — רשימה ריקה.
JSON בלבד: {"doubts":[{"n":1,"options":["..."],"why":"שורה קצרה"}]}
"""


ALTS_CHAT = """אתה עוזר לעורך כתוביות של שיעור תורה«P_ORG». בכל אחד מהספקות למטה — מילה או צירוף שהתמלול
האוטומטי לא בטוח בהם; מופיע המשפט שבו הוא נמצא (⟨___⟩ = המקום). אין כאן שמע — חשוב לפי ההקשר, הלשון התורנית, ניבים,
ארמית, שמות ספרים וחכמים, ומילים שנשמעות דומה.
האפשרויות שכבר הוצעו — **פסולות**: אל תחזור על אף אחת מהן. הצע עד 5 קריאות *אחרות* שמתאימות, מהסבירה ביותר.
אם אין שום קריאה אחרת סבירה — רשימה ריקה.
JSON בלבד: {"doubts":[{"n":1,"options":["..."],"why":"שורה קצרה"}]}
"""


def _alts_prep(P, name, text, audio=True):
    P = Path(P)
    st = json.load(open(P / MS.STATE, encoding="utf-8"))
    c = next(x for x in st["clips"] if x["name"] == name)
    text = text or MS.read_edit_raw(P / c["edit"])["text"]
    brs = brackets(text)
    if not brs:
        raise ValueError("אין ספקות פתוחים בקליף הזה")
    e1 = _words(P / c["ear1"]) or []
    known = {d[1]: d[0] for d in c.get("doubts") or []}
    ts = times_for(text, e1)
    dm = c.get("doubt_more") or {}
    dur = c.get("seconds") or (MS.duration(P / c["clean"]) if audio else 0)
    lines, parts = [], []
    for k, (m, t) in enumerate(zip(brs, ts), 1):
        t = known.get(m.group(0), t)
        before = " ".join(resolved(text[:m.start()]).split()[-10:])
        after = " ".join(resolved(text[m.end():]).split()[:10])
        ex = [clean_opt(o) for o in m.group(1).split("/")] + (dm.get(m.group(0)) or {}).get("more", []) + \
            (dm.get(m.group(0)) or {}).get("alts", [])
        lines.append("### ספק %d\nהמשפט: %s ⟨___⟩ %s\nכבר הוצעו (פסולות): %s\n" % (k, before, after, " | ".join(dict.fromkeys(ex))))
        if audio:
            a, b = max(0.0, t - 2.5), min(dur, t + 3.5)
            parts.append({"text": "### ספק %d — השמע" % k})
            parts.append({"inline_data": {"mime_type": "audio/mpeg",
                                          "data": base64.b64encode(audio_bytes(P, c, a, b)).decode("ascii")}})
    ctx = "שיעור: %s · %s\n" % (st.get("video_title") or "", st.get("rabbi") or "")
    return brs, dm, ctx + "\n".join(lines), parts


def _rabbi_of(P):
    try:
        return json.load(open(Path(P) / MS.STATE, encoding="utf-8")).get("rabbi") or ""
    except (OSError, ValueError):
        return ""


def alts_chat(P, name, text):
    """"העתק לצ'אט" של "חפש הצעות אחרות": אותם ספקות ואותן פסולות, בלי שמע."""
    _, _, body, _ = _alts_prep(P, name, text, audio=False)
    return org_text(ALTS_CHAT) + glossary_prompt(40, rabbis=[_rabbi_of(P)]) + body


def alts(P, name, text, answer=None):
    """בקשה אחת לכל הספקות הפתוחים של קליף (בטקסט כמו שהוא בדף עכשיו), או answer = תשובה שהודבקה מצ'אט —
    אותו פענוח ואותה שמירה. מחזיר {"[א / ב]": {"alts", "why"}}."""
    brs, dm, body, parts = _alts_prep(P, name, text, audio=answer is None)
    if answer is None:
        out_text = PICK.gemini_call(org_text(ALTS_PROMPT) + glossary_prompt(40, rabbis=[_rabbi_of(P)]) + body, parts=parts,
                                    timeout=300, temperature=0.5, thinking=2048)
    else:
        out_text = answer
    data = _json_obj(out_text, "doubts")
    ds = (data or {}).get("doubts") if isinstance(data, dict) else None
    if not isinstance(ds, list):
        raise ValueError("התשובה לא בפורמט שביקשנו")
    res = {}
    for i, d in enumerate(ds, 1):
        if not isinstance(d, dict):
            continue
        try:
            k = int(d.get("n") or i)
        except (TypeError, ValueError):
            k = i
        if not 1 <= k <= len(brs):
            continue
        full = brs[k - 1].group(0)
        bad = {norm(x) for x in [clean_opt(o) for o in brs[k - 1].group(1).split("/")] +
               (dm.get(full) or {}).get("more", []) + (dm.get(full) or {}).get("alts", [])}
        new = [clean_opt(o) for o in d.get("options") or [] if isinstance(o, str)]
        new = [o for o in dict.fromkeys(new) if o != "—" and norm(o) not in bad][:5]
        res[full] = {"alts": new, "why": " ".join(str(d.get("why") or "").split())[:160]}

    def upd(st):
        for x in st["clips"]:
            if x["name"] == name:
                m = dict(x.get("doubt_more") or {})
                for full, v in res.items():
                    e = dict(m.get(full) or {"more": [], "why": ""})
                    e["alts"] = list(dict.fromkeys((e.get("alts") or []) + v["alts"]))[:10]
                    if v["why"] and not e.get("why"):
                        e["why"] = v["why"]
                    m[full] = e
                x["doubt_more"] = m
    _write_state(P, upd)
    return res


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if len(a) >= 2 and a[0] == "run":
            sys.exit(run(a[1:]))
        if len(a) == 3 and a[0] == "paste":
            print(json.dumps(paste([a[1]], Path(a[2]).read_text(encoding="utf-8")), ensure_ascii=False, indent=1))
            sys.exit(0)
        if len(a) >= 2 and a[0] == "chat":
            print(chat_block(a[1:])[0])
            sys.exit(0)
        print(__doc__)
        sys.exit(2)
    except Exception as e:
        say("❌ %s" % e)
        sys.exit(1)
