# -*- coding: utf-8 -*-
"""מנוע התמלול: גרסאות מוצמדות, הודעה על גרסה חדשה, וכפתור "נסה מנוע חדש יותר" (29/10/2026).

הספריות הקריטיות (faster-whisper, modal ועוד) מוצמדות ב-requirements-pinned.txt (המקום היחיד שבו כתובות הגרסאות
הטובות; install.sh משתמש בו). yt-dlp לא מוצמד — יש לו "עדכן עכשיו" משלו.

  python make_short_engine.py upgrade     ← צילום הגרסאות → התקנת החדשות → בדיקה עצמית → כישלון: חזרה לקודמות;
                                            הצלחה: הגרסאות החדשות נרשמות כמוצמדות. (החלון מריץ את זה כעבודה.)
  python make_short_engine.py selfcheck   ← ייבוא + זיהוי דיבור + תמלול קטנטן (אם המודל כבר במחשב) + בדיקת Modal בלי עלות
  python make_short_engine.py status      ← מה מותקן ומה יש ב-PyPI

בדיקות: MAKE_SHORT_ENGINE_STATE (קובץ מצב אחר), ENGINE_PIP (pip מזויף), ENGINE_SELFCHECK (פקודת בדיקה אחרת),
ENGINE_PINS (קובץ הצמדות אחר), ENGINE_NO_GIT=1."""
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
PINS = Path(os.environ.get("ENGINE_PINS") or REPO / "requirements-pinned.txt")
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
STATE = Path(os.environ.get("MAKE_SHORT_ENGINE_STATE") or DATA / "engine_check.json")
WATCH = ("faster-whisper", "modal")          # מה שהכפתור מעדכן (התלויות שלהם מתעדכנות איתם)
CHECK_EVERY = 24 * 3600                      # שאלה ל-PyPI — פעם ביום לכל היותר
NOTE_EVERY = 30 * 24 * 3600                  # ההודעה השקטה — פעם בחודש לכל היותר
GIT_ID = ["-c", "user.name=מנוע התמלול (יצירת שורטס)", "-c", "user.email=engine@localhost"]


def norm(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or ""))


def load_state():
    try:
        return json.load(open(STATE, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_state(st):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_name(STATE.name + ".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, STATE)


def pip_cmd():
    fake = os.environ.get("ENGINE_PIP")
    return fake.split() if fake else [sys.executable, "-m", "pip"]


def freeze():
    """{שם בצורה אחידה: גרסה} של כל מה שבסביבה."""
    r = subprocess.run(pip_cmd() + ["freeze", "--all"], capture_output=True, text=True, errors="replace", timeout=120)
    out = {}
    for line in r.stdout.splitlines():
        m = re.match(r"^([A-Za-z0-9_.\-]+)==(\S+)", line.strip())
        if m:
            out[canon(m.group(1))] = m.group(2)
    return out


def canon(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def installed():
    f = freeze()
    return {n: f.get(n, "") for n in WATCH}


def latest(force=False, net=True):
    """הגרסה האחרונה ב-PyPI של כל אחת (מטמון של יום). בלי אינטרנט — מה שנשמר בפעם הקודמת."""
    st = load_state()
    if not force and time.time() - st.get("checked_ts", 0) < CHECK_EVERY and st.get("latest"):
        return st["latest"]
    if not net:
        return st.get("latest") or {}
    got = dict(st.get("latest") or {})
    for n in WATCH:
        try:
            with urllib.request.urlopen("https://pypi.org/pypi/%s/json" % n, timeout=8) as r:
                got[n] = json.loads(r.read().decode())["info"]["version"]
        except Exception:
            pass
    st.update(latest=got, checked_ts=time.time())
    save_state(st)
    return got


def newer(net=True, force=False):
    """{שם: (מותקן, חדש)} — רק מה שיש לו גרסה חדשה יותר."""
    cur, lat = installed(), latest(force=force, net=net)
    return {n: (cur[n], lat[n]) for n in WATCH if cur.get(n) and lat.get(n) and norm(lat[n]) > norm(cur[n])}


def note_due():
    return time.time() - load_state().get("dismissed_ts", 0) > NOTE_EVERY


def dismiss():
    st = load_state()
    st["dismissed_ts"] = time.time()
    save_state(st)


# ─────────────── הקובץ של הגרסאות המוצמדות ───────────────

def pins_read():
    out = {}
    try:
        for line in PINS.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^([A-Za-z0-9_.\-]+)==(\S+)", line.strip())
            if m:
                out[canon(m.group(1))] = m.group(2)
    except OSError:
        pass
    return out


def pins_write(new):
    """מעדכן בקובץ רק את השורות של מה שכבר מוצמד בו (ההערות והסדר נשארים)."""
    lines, changed = PINS.read_text(encoding="utf-8").splitlines(), []
    for i, line in enumerate(lines):
        m = re.match(r"^([A-Za-z0-9_.\-]+)==(\S+)(.*)$", line.strip())
        if m and canon(m.group(1)) in new and new[canon(m.group(1))] != m.group(2):
            lines[i] = "%s==%s%s" % (m.group(1), new[canon(m.group(1))], m.group(3))
            changed.append("%s %s→%s" % (m.group(1), m.group(2), new[canon(m.group(1))]))
    if changed:
        PINS.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return changed


def pins_commit(changed):
    """בקוד שהוא git (המחשב שלו) — commit מקומי, כך שהחבילה והעדכונים יודעים שאלה הגרסאות הטובות. בלי push."""
    if os.environ.get("ENGINE_NO_GIT") or not (REPO / ".git").exists():
        return
    rel = str(PINS.relative_to(REPO)) if PINS.is_relative_to(REPO) else None
    if not rel:
        return
    subprocess.run(["git", "-C", str(REPO), *GIT_ID, "commit", "-q", "-m",
                    "engine: new known-good versions after a passing self-check\n\n" + "\n".join(changed), "--", rel],
                   capture_output=True, timeout=60)


# ─────────────── בדיקה עצמית ───────────────

def selfcheck():
    """רץ בתהליך חדש (כדי לטעון את הגרסאות שהותקנו עכשיו). מדפיס שורה לכל שלב; יוצא 0 אם הכול עבר."""
    ok = True

    def step(name, fn):
        nonlocal ok
        try:
            msg = fn()
            print("  ✓ %s%s" % (name, (" — " + msg) if msg else ""), flush=True)
        except Exception as e:
            ok = False
            print("  ✗ %s: %s" % (name, str(e).strip().splitlines()[-1][:200] if str(e).strip() else type(e).__name__),
                  flush=True)
    import numpy as np
    sr = 16000
    t = np.arange(int(sr * 2.5)) / sr
    audio = (0.2 * np.sin(2 * np.pi * 220 * t) * (t % 0.5 < 0.3)).astype(np.float32)   # "הברות" קצרות

    def imp():
        import faster_whisper, ctranslate2, modal          # noqa: F401
        return "faster-whisper %s · modal %s" % (faster_whisper.__version__, modal.__version__)
    step("ייבוא הספריות", imp)

    def vad():                                              # מה שמערבב המוזיקה וחיתוך השקטים משתמשים בו
        from faster_whisper.vad import get_speech_timestamps, VadOptions
        get_speech_timestamps(audio, VadOptions(min_silence_duration_ms=100, speech_pad_ms=0))
        return ""
    step("זיהוי דיבור (VAD)", vad)

    def tiny():
        """תמלול קטנטן — רק אם המודל כבר במחשב (לא מורידים 1.5GB בשביל בדיקה)."""
        from faster_whisper import WhisperModel
        name = os.environ.get("SHORTS_MODEL") or "ivrit-ai/whisper-large-v3-turbo-ct2"
        try:
            from huggingface_hub import snapshot_download
            path = snapshot_download(name, local_files_only=True)
        except Exception:
            return "דילגתי — המודל המקומי לא במחשב (התמלול בענן לא צריך אותו)"
        m = WhisperModel(path, device="cpu", compute_type="int8", cpu_threads=2)
        segs, _ = m.transcribe(audio, language="he", beam_size=1)
        list(segs)
        return "המודל המקומי נטען ותמלל"
    step("תמלול קטנטן", tiny)

    def modal_dry():
        """בלי עלות: רק שואלים את Modal על כונן המטמון של המודלים (בלי מכונה, בלי GPU) — בודק התחברות והתאמת גרסה."""
        if os.environ.get("MAKE_SHORT_NO_EXPORT") or os.environ.get("ENGINE_SKIP_MODAL"):
            return "דילגתי (מצב בדיקה)"
        cfg = os.environ.get("MODAL_CONFIG_PATH") or os.path.expanduser("~/.modal.toml")
        if not (os.environ.get("MODAL_TOKEN_ID") or os.path.exists(cfg)):
            return "דילגתי — אין חשבון Modal מחובר"
        import modal
        modal.Volume.from_name("shorts-asr-model-cache", create_if_missing=True).hydrate()
        return "Modal ענה"
    step("Modal (בלי עלות)", modal_dry)
    return 0 if ok else 1


def run_selfcheck():
    cmd = os.environ.get("ENGINE_SELFCHECK")
    cmd = cmd.split() if cmd else [sys.executable, "-u", str(Path(__file__).resolve()), "selfcheck"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=900)
    except subprocess.TimeoutExpired:
        return False, "הבדיקה העצמית לא הסתיימה תוך 15 דקות"
    print(r.stdout.rstrip(), flush=True)
    return r.returncode == 0, (r.stderr or "").strip()[-300:]


# ─────────────── הכפתור ───────────────

def upgrade():
    say = lambda s: print(s, flush=True)
    before = freeze()
    snap = DATA / "engine_snapshots" / time.strftime("%Y%m%d-%H%M%S.txt")
    snap.parent.mkdir(parents=True, exist_ok=True)
    snap.write_text("".join("%s==%s\n" % kv for kv in sorted(before.items())), encoding="utf-8")
    say("STAGE=engine_snapshot")
    say("📸 הגרסאות הנוכחיות נשמרו: %s" % " · ".join("%s %s" % (n, before.get(n, "?")) for n in WATCH))
    say("STAGE=engine_install")
    say("⬇ מתקין גרסאות חדשות יותר (כמה דקות)…")
    r = subprocess.run(pip_cmd() + ["install", "--quiet", "--upgrade", *WATCH], capture_output=True, text=True,
                       errors="replace", timeout=1800)
    after = freeze()
    changed = {n: (before.get(n), v) for n, v in after.items() if before.get(n) != v}
    if r.returncode == 0 and not any(n in changed for n in WATCH):
        say("✓ כבר בגרסה האחרונה — אין מה להחליף")
        return 0
    good = False
    if r.returncode == 0:
        say("STAGE=engine_check")
        say("🔎 בדיקה עצמית: %s" % " · ".join("%s %s→%s" % (n, a or "-", b) for n, (a, b) in changed.items() if n in WATCH))
        good, why = run_selfcheck()
    else:
        why = (r.stderr or r.stdout).strip().splitlines()[-1:] or [""]
        why = "ההתקנה נכשלה: " + why[0][:200]
    if good:
        new = pins_write({n: v for n, (_, v) in changed.items()})
        if new:
            pins_commit(new)
        st = load_state()
        st.setdefault("history", []).append({"at": time.strftime("%Y-%m-%d %H:%M"), "ok": True,
                                             "changed": {n: list(v) for n, v in changed.items()}})
        st["dismissed_ts"] = 0
        save_state(st)
        say("✅ המנוע החדש עבר את הבדיקה ונשאר: %s" % " · ".join("%s %s" % (n, after.get(n)) for n in WATCH))
        return 0
    say("STAGE=engine_rollback")
    say("✗ %s — מחזיר את הגרסאות הקודמות…" % (why or "הבדיקה העצמית נכשלה"))
    back = ["%s==%s" % (n, a) for n, (a, _) in changed.items() if a]
    rr = subprocess.run(pip_cmd() + ["install", "--quiet", *back], capture_output=True, text=True, errors="replace",
                        timeout=1800) if back else None
    restored = freeze()
    ok_back = all(restored.get(n) == a for n, (a, _) in changed.items() if a)
    st = load_state()
    st.setdefault("history", []).append({"at": time.strftime("%Y-%m-%d %H:%M"), "ok": False, "restored": ok_back,
                                         "changed": {n: list(v) for n, v in changed.items()}, "why": why[:200]})
    save_state(st)
    if ok_back:
        say("↩ הוחזר בדיוק מה שהיה (%s). התוכנה ממשיכה לעבוד כמו קודם." %
            " · ".join("%s %s" % (n, restored.get(n)) for n in WATCH))
        return 1
    say("⚠ ההחזרה לא הושלמה (%s). הרשימה המלאה של מה שהיה: %s" %
        (((rr.stderr if rr else "") or "").strip()[-200:], snap))
    return 2


def main():
    a = sys.argv[1] if len(sys.argv) > 1 else "status"
    if a == "selfcheck":
        return selfcheck()
    if a == "upgrade":
        return upgrade()
    if a == "status":
        print(json.dumps({"installed": installed(), "latest": latest(), "pins": {n: pins_read().get(n) for n in WATCH}},
                         ensure_ascii=False))
        return 0
    sys.exit(__doc__)


if __name__ == "__main__":
    sys.exit(main())
