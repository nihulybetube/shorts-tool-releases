# -*- coding: utf-8 -*-
"""
make_short_personal.py — 4.5: שינויים אישיים של מקבל התוכנה שורדים עדכונים רשמיים.

הבעיה: מי שקיבל את התוכנה שינה אותה לעצמו ("תיבת העדכון" / "עבודה עם צ'אט" / "תיקנתי לעצמי"), ואז מגיע עדכון רשמי
לכולם. עד 4.4 העדכון רק *שמר* את השינוי שלו כקובץ patch והתקין את הרשמי במקומו — השינוי נעלם. עכשיו:

  • כל שינוי שהוחל מהתיבה נרשם ברישום (registry.json, מחוץ לעץ הקוד, ב-~/.local/share/yeshiva-shorts/local_changes/):
    שם (שורת "תיאור:"), תאריך, גרסת בסיס, ה-patch, הקבצים, מצב. בנוסף commit-מצביע ב-refs/personal/<id> בריפו המקומי —
    כדי שמיזוג תלת-כיווני (git cherry-pick) יוכל לעבוד על הגרסה החדשה.
  • אחרי כל עדכון רשמי מוצלח (פעם אחת, אחרי הגרסה האחרונה): כל שינוי פעיל מוחל מחדש לפי הסדר במיזוג תלת-כיווני, ואז הבדיקה
    המהירה. תוצאה לכל שינוי: ✅ הוחל · ⚠ לא התמזג (הרשמי נשאר, השינוי נשמר שלם) · ⛔ הוחל אבל הבדיקה נכשלה (הוסר אוטומטית,
    "לא תואם", נשמר) · ✓ כבר נכלל ברשמי.
  • עדכון רשמי לא נחסם ולא נהפך לעולם בגלל שינוי אישי, ושינוי אישי לא הולך לאיבוד בשקט (הכול ברישום, ה-patch נשאר).
  • מה שהמשתמש בוחר: להפעיל/לכבות כל שינוי, "לבקש מצ'אט למזג" (בלוק עם הקוד הרשמי החדש + השינוי + הוראות; התשובה חוזרת
    בתיבת העדכון כשינוי חדש), "לוותר" (ארכיון, אפשר לשחזר), "להציע למנהל" (4.4).
  • הפסקת חשמל באמצע ההחלה מחדש: יומן (reapply_pending.json) → בהפעלה חוזרים למצב השלם הקודם ומנסים שוב.
  • עץ הפיתוח של הבעלים (אין סימון .from_package / יש origin) מחוץ למנגנון הזה — active() שקר.

שימוש (דיבוג):  make_short_personal.py status | recover
"""
import difflib
import fnmatch
import hashlib
import json
import tempfile
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short_release as R  # noqa: E402

REPO = R.REPO
DATA = R.DATA
ROOT = R.LOCAL_CHANGES                       # ‎~/.local/share/yeshiva-shorts/local_changes — אותה תיקייה שבה 4.3 שמר patch-ים
REG = ROOT / "registry.json"
PDIR = ROOT / "personal"
JOURNAL = ROOT / "reapply_pending.json"
OFF_STATES = ("disabled", "archived", "absorbed")
STATE_HE = {"applied": "✅ פעיל", "conflict": "⚠ לא התמזג עם הגרסה החדשה", "incompatible": "⛔ לא תואם — הוסר אוטומטית",
            "disabled": "⏸ כבוי", "archived": "🗄 ויתרתי", "absorbed": "✓ כבר נכלל בגרסה הרשמית", "waiting": "⏳ ממתין להחלה"}
NEEDS_USER = ("conflict", "incompatible")
FORBIDDEN = ["config.env", "*.env", "*.env.*", "*cookie*", "*token*", "*secret*", "*.toml", "rclone.conf", "*.key", "*.pem",
             "*credential*", "*.vault", "*.enc", "state.json"]
MERGE_TAG = re.compile(r"\s*\[מיזוג (pc-\d+)\]\s*")


class PCError(Exception):
    """הודעה בעברית פשוטה — אפשר להציג למשתמש כמו שהיא."""


def _guard(path):
    try:
        import make_short_guard as G
        G.assert_not_real_config(path)
    except ImportError:
        pass


def active(repo=None):
    """רק אצל מקבל (התקנה מחבילה). עץ הפיתוח של הבעלים — לא."""
    try:
        return R.update_mode(Path(repo) if repo else None) == "receiver"
    except Exception:
        return False


# ─────────────────────────── git ───────────────────────────
QUIET_GIT = ["-c", "advice.mergeConflict=false", "-c", "advice.detachedHead=false", "-c", "advice.skippedCherryPicks=false",
             "-c", "advice.statusHints=false", "-c", "advice.resolveConflict=false"]


def _g(repo, *a, inp=None, timeout=180):
    # 4.5.62 (#5): בלי שורות "hint:" של git — הן היו מוצגות למשתמש כסיבת הקונפליקט
    r = subprocess.run(["git", "-C", str(repo), *R.GIT_ID, *QUIET_GIT, *a], capture_output=True, input=inp, timeout=timeout)
    return r.returncode, r.stdout.decode("utf-8", "replace").strip(), r.stderr.decode("utf-8", "replace").strip()


def _head(repo):
    return _g(repo, "rev-parse", "HEAD")[1]


def _clean(repo):
    return not _g(repo, "status", "--porcelain", "--untracked-files=no")[1]


def _reset(repo, to):
    """4.5.x (C4): דרך R.hard_reset — מסיר index.lock שנשאר מ-git שמת, ובונה אינדקס פגום מחדש."""
    R.unlock_stale(repo)
    _g(repo, "cherry-pick", "--quit")
    try:
        R.hard_reset(repo, to)
    except R.UpdateError as e:
        raise PCError("לא הצלחתי להחזיר את הקוד למצב קודם (%s)" % str(e)[:160])


def _no_symlink(repo, rel):
    """4.5.x (C9): הנתיב והתיקיות שמעליו בתוך העץ אינם קישורים סימבוליים (לא מעתיקים סוד מחוץ לריפו, לא כותבים דרך קישור)."""
    cur = Path(repo)
    for part in rel.split("/"):
        cur = cur / part
        if cur.is_symlink():
            return False
    return True


def official_commit(repo=None):
    """ה-commit הרשמי של הגרסה המותקנת (התגית rel-X שהעדכון הרשמי שם). ריק = לא ידוע."""
    repo = Path(repo or REPO)
    v = R.installed_version(repo)
    if not v:
        return ""
    return _g(repo, "rev-parse", "-q", "--verify", "rel-%s^{commit}" % v)[1]


# ─────────────────────────── רישום ───────────────────────────
class _Lock:
    def __enter__(self):
        ROOT.mkdir(parents=True, exist_ok=True)
        self.f = open(ROOT / ".lock", "w")
        try:
            import fcntl
            fcntl.flock(self.f, fcntl.LOCK_EX)
        except ImportError:
            pass
        return self

    def __exit__(self, *a):
        self.f.close()


CORRUPT_MSG = ("קובץ רשימת השינויים האישיים פגום — לא נוגעים בשינויים כדי לא לדרוס אותם. עותק נשמר (%s). "
               "התוכנה עצמה עובדת; לפנות למנהל.")


def load():
    """4.5.x (C5): קובץ שקיים אבל פגום ≠ רשימה ריקה. מגבים אותו פעם אחת ומחזירים רשימה מסומנת "_corrupt" — save מסרב,
    כך ש-pc-0001 ושאר השינויים השמורים לא נדרסים."""
    try:
        raw = REG.read_bytes()
    except FileNotFoundError:
        return {"v": 1, "seq": 0, "changes": [], "seen": [], "last_reapply": None, "last_done": ""}
    except OSError:
        raw = None
    try:
        d = json.loads(raw.decode("utf-8")) if raw is not None else None
        if isinstance(d, dict) and isinstance(d.get("changes"), list) and all(isinstance(c, dict) and "id" in c for c in d["changes"]):
            d.setdefault("seen", [])
            d.setdefault("seq", 0)
            return d
    except (ValueError, UnicodeDecodeError):
        pass
    bak = ROOT / ("registry.bad-%s.json" % hashlib.sha256(raw or b"").hexdigest()[:10])
    try:
        if raw is not None and not bak.exists():
            _guard(bak)
            bak.write_bytes(raw)
    except OSError:
        pass
    return {"v": 1, "seq": 0, "changes": [], "seen": [], "last_reapply": None, "last_done": "", "_corrupt": str(bak)}


def save(reg):
    if reg.get("_corrupt"):
        raise PCError(CORRUPT_MSG % Path(reg["_corrupt"]).name)
    _guard(ROOT)
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = REG.with_suffix(".json.tmp%d" % os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps(reg, ensure_ascii=False, indent=1))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, REG)


def _find(reg, cid):
    c = next((x for x in reg["changes"] if x["id"] == cid), None)
    if not c:
        raise PCError("אין שינוי כזה ברשימה")
    return c


def _event(c, text, version=""):
    c.setdefault("history", []).append({"at": int(time.time()), "text": text, "version": version})
    c["history"] = c["history"][-40:]


def _enabled(c):
    return c["state"] not in OFF_STATES


def _safe_rel(p):
    if not p or p.startswith(("/", "\\")) or ".." in p.split("/") or "\\" in p or re.search(r"[\x00-\x1f]", p):
        return False
    return not any(fnmatch.fnmatch(p.rsplit("/", 1)[-1].lower(), pat) for pat in FORBIDDEN)


def _max_dir_seq():
    n = 0
    try:
        for d in PDIR.iterdir():
            m = re.fullmatch(r"pc-(\d+)", d.name)
            if m:
                n = max(n, int(m.group(1)))
    except OSError:
        pass
    return n


def _new_change(reg, desc, kind, base_version, patch, files, state, ref="", commit="", untracked_from=None):
    if reg.get("_corrupt"):
        raise PCError(CORRUPT_MSG % Path(reg["_corrupt"]).name)
    # 4.5.x (C5): המספר הבא גבוה מכל תיקייה pc-* שכבר קיימת — אף פעם לא דורסים patch/ref של שינוי קיים
    reg["seq"] = max(int(reg.get("seq", 0)), _max_dir_seq(), max([int(c.get("seq", 0)) for c in reg["changes"]] or [0])) + 1
    cid = "pc-%04d" % reg["seq"]
    d = PDIR / cid
    _guard(d)
    d.mkdir(parents=True, exist_ok=True)
    (d / "orig.patch").write_bytes(patch)
    (d / "change.patch").write_bytes(patch)
    if untracked_from:
        shutil.copytree(untracked_from, d / "untracked", dirs_exist_ok=True, symlinks=True)   # קישור נשאר קישור (ולא יוחל)
    c = {"id": cid, "seq": reg["seq"], "desc": (desc or "שינוי אישי").strip()[:200], "kind": kind, "created": int(time.time()),
         "base_version": base_version, "applied_version": base_version if state == "applied" else "", "state": state,
         "files": sorted(files)[:200], "ref": ref, "commit": commit, "reason": "", "conflict_files": [], "history": []}
    reg["changes"].append(c)
    _event(c, {"box": "הוחל מתיבת העדכון", "manual": "שינוי ידני בקבצים נשמר לפני עדכון", "legacy": "נשמר כקובץ patch בעדכון קודם (4.3/4.4)"}.get(kind, "נרשם"),
           base_version)
    return c


# ─────────────────────────── נקודות חיבור: תיבת העדכון ───────────────────────────
def before_box(repo=None):
    """לפני "צילום" של תיבת העדכון: מוודאים שיש תגית rel-X (נקודת הבסיס הרשמית) — רק אם העץ נקי."""
    repo = Path(repo or REPO)
    if active(repo):
        R._ensure_base_tag(repo)


def after_box(repo, desc, snap, commit, installed=None):
    """אחרי שהתיבה החילה ועברה בדיקה: רושם שינוי אישי. מחזיר את הרשומה או None."""
    repo = Path(repo)
    if not active(repo):
        return None
    with _Lock():
        reg = load()
        desc = desc or "שינוי אישי"
        replaces = (MERGE_TAG.search(desc) or [None, ""])[1]
        desc = MERGE_TAG.sub(" ", desc).strip()
        patch = subprocess.run(["git", "-C", str(repo), "diff", "--binary", snap, commit], capture_output=True, timeout=60).stdout
        files = _g(repo, "diff", "--name-only", snap, commit)[1].splitlines()
        ver = installed or R.installed_version(repo)
        c = _new_change(reg, desc, "box", ver, patch, files, "applied", commit=commit)
        c["ref"] = "refs/personal/" + c["id"]
        _g(repo, "update-ref", c["ref"], commit)
        if replaces:
            old = next((x for x in reg["changes"] if x["id"] == replaces), None)
            if old and old["state"] in ("conflict", "incompatible", "waiting"):
                old["state"] = "archived"
                old["reason"] = "הוחלף בשינוי %s (תשובת הצ'אט למיזוג)" % c["id"]
                _event(old, "הוחלף בשינוי חדש %s — הועבר לארכיון" % c["id"], ver)
                c["replaces"] = old["id"]
        save(reg)
        return c


def after_undo(repo, commit):
    """"בטל עדכון אחרון" בתיבה: השינוי האישי המתאים נשאר ברשימה ככבוי (אפשר להפעיל שוב)."""
    if not active(repo):
        return
    with _Lock():
        reg = load()
        for c in reg["changes"]:
            if c.get("commit") == commit and c["state"] == "applied":
                c["state"] = "disabled"
                c["reason"] = "בוטל בלחיצה על «בטל עדכון אחרון»"
                _event(c, "בוטל בתיבת העדכון (נשאר ברשימה, אפשר להפעיל שוב)", R.installed_version(repo))
        save(reg)


def _fold_box_history():
    """אחרי עדכון רשמי "בטל עדכון אחרון" של התיבה לא יכול לגעת בשינויים ישנים (הקוד הרשמי כבר דרס אותם) — מסמנים אותם."""
    hp = Path(os.environ.get("MAKE_SHORT_UPDATES") or DATA / "updates.json")
    try:
        h = json.loads(hp.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    ch = False
    for e in h:
        if e.get("status") == "applied":
            e["status"] = "folded"
            ch = True
    if ch:
        _guard(hp)
        tmp = hp.with_suffix(".tmp")
        tmp.write_text(json.dumps(h, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(hp)


def capture_manual(repo, installed, target, stage_tree=None):
    """לפני שעדכון רשמי דורס: שינויים ידניים שלא נשמרו ב-commit (עריכה ישירה של קבצים) נרשמים כשינוי אישי — לא רק כקובץ patch."""
    repo = Path(repo)
    if not active(repo):
        return None
    ex = [":(exclude,glob)**/" + p for p in FORBIDDEN] + [":(exclude,glob)" + p for p in FORBIDDEN]
    patch = subprocess.run(["git", "-C", str(repo), "diff", "--binary", "HEAD", "--", "."] + ex, capture_output=True, timeout=60).stdout
    extra = []
    if stage_tree is not None:
        for p in _g(repo, "ls-files", "--others", "--exclude-standard")[1].splitlines():
            if _safe_rel(p) and _no_symlink(repo, p) and (Path(stage_tree) / p).exists() and (repo / p).is_file():
                extra.append(p)
    with _Lock():
        reg = load()
        if _register_unaccounted(repo, reg):    # 4.5.x (C1): commits בקוד שאף שינוי רשום לא מסביר — נרשמים לפני שהעדכון דורס
            save(reg)
    if not patch.strip() and not extra:
        return None
    with _Lock():
        reg = load()
        tmpd = None
        if extra:
            tmpd = ROOT / (".tmp_untracked_%d" % os.getpid())
            shutil.rmtree(tmpd, ignore_errors=True)
            for p in extra:
                (tmpd / p).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(repo / p, tmpd / p)
        files = re.findall(r"^diff --git a/(\S+) b/", patch.decode("utf-8", "replace"), re.M) + extra
        c = _new_change(reg, "שינוי ידני בקבצים (נשמר לפני העדכון ל-%s)" % target, "manual", installed, patch, files, "waiting",
                        untracked_from=tmpd)
        if tmpd:
            shutil.rmtree(tmpd, ignore_errors=True)
        save(reg)
        return c


def _unaccounted(repo, base, reg):
    """commits בין הגרסה הרשמית ל-HEAD שאף שינוי רשום לא מסביר (לא commit של שינוי, לא ריק, לא ביטול של שינוי רשום)."""
    rc, out, _e = _g(repo, "rev-list", "--reverse", "--no-merges", base + "..HEAD")
    if rc:
        return []
    known = {c.get("commit") for c in reg["changes"] if c.get("commit")}
    for c in reg["changes"]:
        if c.get("ref"):
            known.add(_g(repo, "rev-parse", "-q", "--verify", c["ref"] + "^{commit}")[1])
    res = []
    for sha in out.split():
        if sha in known or _g(repo, "diff", "--quiet", sha + "^", sha)[0] == 0:
            continue
        m = re.search(r"This reverts commit ([0-9a-f]{40})", _g(repo, "log", "-1", "--format=%B", sha)[1])
        if m and m.group(1) in known:
            continue
        res.append(sha)
    return res


def _register_unaccounted(repo, reg):
    """4.5.x (C1): כל commit כזה (למשל עריכה ידנית שנכנסה ל"צילום לפני עדכון" של תיבת העדכון) → שינוי אישי ממתין עם ref,
    כך שבנייה מחדש / עדכון רשמי לא מוחקים אותו בשקט. מחזיר את הרשומות החדשות."""
    base = official_commit(repo)
    if not base:
        return []
    new = []
    for sha in _unaccounted(repo, base, reg):
        patch = subprocess.run(["git", "-C", str(repo), "diff", "--binary", sha + "^", sha], capture_output=True, timeout=60).stdout
        files = _g(repo, "diff", "--name-only", sha + "^", sha)[1].splitlines()
        subj = _g(repo, "log", "-1", "--format=%s", sha)[1][:80]
        c = _new_change(reg, "שינוי שנמצא בקוד ולא היה רשום (%s)" % subj, "manual", R.installed_version(repo), patch, files, "waiting",
                        commit=sha)
        c["ref"] = "refs/personal/" + c["id"]
        _g(repo, "update-ref", c["ref"], sha)
        new.append(c)
    return new


def register_manual(repo, why="לפני שינוי בתיבת העדכון", untracked=True):
    """4.5.x (C1): לפני "צילום" של תיבת העדכון (החלה וביטול): עריכות ידניות בקבצים + קבצים חדשים שלא נשמרו → שינוי אישי
    פעיל עם commit משלו (במקום להיבלע ב-commit "לפני עדכון" ולהימחק בבנייה מחדש). קבצים אסורים (מפתחות, הגדרות) וקישורים — לא."""
    repo = Path(repo)
    if not active(repo):
        return None
    with _Lock():
        reg = load()
        if _register_unaccounted(repo, reg):
            save(reg)
        tracked = [p for p in _g(repo, "diff", "--name-only", "HEAD")[1].splitlines() if p and _safe_rel(p)]
        new = [p for p in _g(repo, "ls-files", "--others", "--exclude-standard")[1].splitlines()
               if p and _safe_rel(p) and _no_symlink(repo, p) and (repo / p).is_file()] if untracked else []
        if not tracked and not new:
            return None
        if reg.get("_corrupt"):
            raise PCError(CORRUPT_MSG % Path(reg["_corrupt"]).name)
        _g(repo, "add", "-A", "--", *(tracked + new))
        rc, _o, err = _g(repo, "commit", "-q", "-m", "שינוי ידני בקבצים (%s)" % why)
        if rc:
            raise PCError("לא הצלחתי לשמור את השינוי הידני (%s)" % err[-120:])
        sha = _head(repo)
        patch = subprocess.run(["git", "-C", str(repo), "diff", "--binary", sha + "^", sha], capture_output=True, timeout=60).stdout
        ver = R.installed_version(repo)
        c = _new_change(reg, "שינוי ידני בקבצים (נשמר %s)" % why, "manual", ver, patch, tracked + new, "applied", commit=sha)
        c["ref"] = "refs/personal/" + c["id"]
        _g(repo, "update-ref", c["ref"], sha)
        save(reg)
        return c


def note_backup_file(path):
    """קובץ patch-גיבוי שכתב save_local_changes — לא יירשם שוב כשינוי "ישן" בהגירה."""
    try:
        with _Lock():
            reg = load()
            n = Path(path).name
            if n not in reg["seen"]:
                reg["seen"].append(n)
                save(reg)
    except Exception:
        pass


def migrate_legacy(repo=None):
    """patch-ים ש-4.3/4.4 שמרו בעדכונים קודמים (`<ts>_<מותקן>_לפני_<יעד>.patch`) → שינוי אישי ממתין. פעם אחת לכל קובץ."""
    repo = Path(repo or REPO)
    if not active(repo) or not ROOT.is_dir():
        return 0
    n = 0
    with _Lock():
        reg = load()
        for f in sorted(ROOT.glob("*.patch")):
            if f.name in reg["seen"]:
                continue
            reg["seen"].append(f.name)
            try:
                patch = f.read_bytes()
            except OSError:
                continue
            m = re.match(r"^(\d{8})-(\d{6})_(.+?)_לפני_(.+)\.patch$", f.name)
            ts, inst, to = (m.group(1) + "-" + m.group(2), m.group(3), m.group(4)) if m else ("", R.installed_version(repo) or "", "")
            unt = ROOT / (ts + "_untracked") if ts else None
            has_unt = bool(unt and unt.is_dir() and any(unt.rglob("*")))
            if not patch.strip() and not has_unt:
                continue
            files = re.findall(r"^diff --git a/(\S+) b/", patch.decode("utf-8", "replace"), re.M)
            if has_unt:
                files += [str(p.relative_to(unt)) for p in unt.rglob("*") if p.is_file()]
            when = time.strftime("%d/%m/%Y", time.strptime(ts[:8], "%Y%m%d")) if ts else ""
            c = _new_change(reg, "שינויים שנשמרו בעדכון%s%s (%s)" % (" מ-" + inst if inst else "", " ל-" + to if to else "", when),
                            "legacy", inst, patch, files, "waiting", untracked_from=unt if has_unt else None)
            n += 1
        save(reg)
    return n


# ─────────────────────────── מיזוג והחלה ───────────────────────────
def _merge_in(repo, c):
    """מחיל שינוי אחד על עץ נקי במיזוג תלת-כיווני (בלי commit). → (ok, קבצים בעייתיים, סיבה). בכישלון — העץ חוזר כמו שהיה."""
    repo = Path(repo)
    head0 = _head(repo)
    ref = c.get("ref") or ""
    pf = PDIR / c["id"] / "change.patch"
    if ref and _g(repo, "rev-parse", "-q", "--verify", ref + "^{commit}")[0] == 0:
        rc, _o, err = _g(repo, "cherry-pick", "--no-commit", ref)
    elif pf.is_file() and pf.read_bytes().strip():
        rc, _o, err = _g(repo, "apply", "--3way", "--index", "--whitespace=nowarn", str(pf))
    else:
        rc, err = 0, ""
    bad = []
    if rc == 0:
        ud = PDIR / c["id"] / "untracked"
        if ud.is_dir():
            for p in sorted(x for x in ud.rglob("*") if x.is_file() and not x.is_symlink()):
                rel = str(p.relative_to(ud))
                dst = repo / rel
                if not _safe_rel(rel) or not _no_symlink(ud, rel):
                    continue
                if not _no_symlink(repo, rel):                 # 4.5.x (C9): לא כותבים דרך קישור שמוביל מחוץ לריפו
                    bad.append(rel)
                    continue
                if dst.exists() and dst.read_bytes() != p.read_bytes():
                    bad.append(rel)
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst)
                _g(repo, "add", "-f", "--", rel)
            if bad:
                rc, err = 1, "קובץ חדש שכבר קיים בגרסה הרשמית עם תוכן אחר"
    if rc != 0:
        if not bad:
            bad = _g(repo, "diff", "--name-only", "--diff-filter=U")[1].splitlines() or \
                re.findall(r"(?:patch failed|error): ([^\s:]+)", err)
        _reset(repo, head0)
        bad = sorted(set(bad))[:20]
        return False, bad, _reason(err, bad)
    return True, [], ""


def _reason(err, bad):
    """4.5.62 (#5): סיבה בעברית פשוטה — אף פעם לא שורת git גולמית (למשל "hint: Disable this message ...")."""
    lines = [l.strip() for l in (err or "").splitlines() if l.strip() and not re.match(r"^(hint|advice|error|fatal|warning):", l.strip(), re.I)]
    he = next((l for l in reversed(lines) if re.search(r"[֐-׿]", l)), "")
    if he:
        return he[:200]
    if bad:
        return ("הקוד הרשמי השתנה באותו מקום בקובץ: " + ", ".join(bad[:3]))[:200]
    return "לא התמזג עם הקוד הרשמי החדש"


def _diff_lines(repo, c):
    """{קובץ: (שורות שנוספו, שורות שהוסרו)} של שינוי אחד (בלי הקשר) — לזיהוי "כבר נכלל ברשמי"."""
    ref = c.get("ref") or ""
    if not ref or _g(repo, "rev-parse", "-q", "--verify", ref + "^{commit}")[0] != 0:
        return {}
    rc, out, _e = _g(repo, "diff", "-U0", "--no-color", ref + "^", ref)
    res, cur, hk = {}, None, None
    for ln in out.splitlines():
        m = re.match(r"^\+\+\+ b/(.+)$", ln)
        if m:
            cur, hk = m.group(1), None
            res.setdefault(cur, [])
        elif ln.startswith("--- ") or ln.startswith("+++ "):
            continue
        elif cur and ln.startswith("@@"):
            hk = ([], [])
            res[cur].append(hk)
        elif cur and hk is not None and ln.startswith("+"):
            hk[0].append(ln[1:])
        elif cur and hk is not None and ln.startswith("-"):
            hk[1].append(ln[1:])
    return res


MIN_SIGNIF = 20          # שורה קצרה ("return 9", "}") מופיעה בכל קובץ — לא ראיה לכלום


def _already_included(repo, c):
    """4.5.62 (#4): השינוי נכשל במיזוג — אבל אולי הקוד הרשמי כבר כולל את אותו תוכן בדיוק (והקשר השורות השתנה רק בגלל שינוי אחר
    שנכשל לפניו). נחשב "כבר נכלל" רק אם בכל קטע: הקטע שנוסף (כל השורות ברצף) כבר בקובץ, ושום שורה משמעותית (20+ תווים) שהוסרה
    לא נשארה; ולפחות שורה משמעותית אחת בסך הכול. (שורות קצרות לא נחשבות — הן מופיעות בכל קובץ.)"""
    d = _diff_lines(repo, c)
    if not d:
        return False
    signif = 0
    for path, hunks in d.items():
        f = Path(repo) / path
        if not f.is_file():
            return False
        lines = [l.strip() for l in f.read_text(encoding="utf-8", errors="replace").split("\n")]
        have = set(lines)
        for added, removed in hunks:
            add = [l.strip() for l in added]
            if add:
                n = len(add)
                if not any(lines[i:i + n] == add for i in range(0, len(lines) - n + 1)):
                    return False
            signif += sum(1 for l in add if len(l) >= MIN_SIGNIF)
            for l in removed:
                if len(l.strip()) >= MIN_SIGNIF:
                    signif += 1
                    if l.strip() in have:
                        return False
    return signif > 0


def _commit(repo, c):
    """commit לשינוי שהוחל. None = אין הבדל (הגרסה הרשמית כבר כוללת את אותו שינוי)."""
    if _g(repo, "diff", "--cached", "--quiet")[0] == 0:
        return None
    rc, _o, err = _g(repo, "commit", "-q", "-m", "שינוי אישי: %s [%s]" % (c["desc"], c["id"]))
    if rc:
        raise PCError("לא הצלחתי לשמור את השינוי (%s)" % err[-120:])
    return _head(repo)


def _verify(repo, files, check_fn):
    bad = R.light_selfcheck(Path(repo), [p for p in files if p.endswith((".py", ".json", ".sh")) and (Path(repo) / p).exists()])
    if bad:
        return False, "קבצים לא תקינים אחרי השינוי: " + ", ".join(bad[:3])
    if check_fn:
        ok, why = check_fn()
        if not ok:
            return False, (str(why).strip() or "הבדיקה נכשלה")[-300:]
    return True, ""


def _failed(repo, c, confl, why, everyone, out):
    """4.5.62 (#4): מיזוג של שינוי נכשל. (א) אולי הקוד הרשמי כבר כולל אותו → "כבר נכלל". (ב) אחרת קונפליקט, ואם שינוי *קודם*
    שנוגע באותם קבצים כבוי / ויתרו עליו / לא הוחל — אומרים את זה (השינויים בנויים זה על גבי זה; זה לא באג ברשמי)."""
    if _already_included(repo, c):
        return {"state": "absorbed"}
    mine = set(c.get("files") or [])
    dep = [x for x in everyone if x["id"] != c["id"] and x.get("seq", 0) < c.get("seq", 0) and mine & set(x.get("files") or [])
           and (not _enabled(x) or (out.get(x["id"]) or {}).get("state") in ("conflict", "incompatible", "waiting"))]
    if dep:
        why = "השינוי בנוי על גבי «%s» (%s) שכרגע לא בקוד — בלעדיו השורות סביבו שונות. להפעיל אותו שוב, או לבקש מצ'אט למזג." % (
            dep[0]["desc"][:50], dep[0]["id"])
    return {"state": "conflict", "files": confl, "why": why}


def _stack(repo, base, entries, check_fn, prog):
    """מחיל את השינויים לפי הסדר על הגרסה הרשמית `base`. → {id: {state, ...}}. בסוף HEAD על המחסנית המאומתת."""
    n = max(1, len(entries))
    _reset(repo, base)
    out, good = {}, []

    def P(i, label):
        if prog:
            prog(int(100 * i / (n * 2)), "%s (%d מתוך %d)" % (label, min(i, n), n))
    try:
        everyone = load()["changes"]
    except Exception:
        everyone = entries
    for i, c in enumerate(entries, 1):
        P(i - 1, "מחיל שינוי אישי")
        ok, confl, why = _merge_in(repo, c)
        if not ok:
            out[c["id"]] = _failed(repo, c, confl, why, everyone, out)
            continue
        sha = _commit(repo, c)
        if sha is None:
            out[c["id"]] = {"state": "absorbed"}
            continue
        out[c["id"]] = {"state": "applied", "commit": sha}
        good.append(c)
    if good:
        P(n, "בודק את השינויים האישיים")
        files = _g(repo, "diff", "--name-only", base, "HEAD")[1].splitlines()
        ok, why = _verify(repo, files, check_fn)
        if not ok:                                   # מצאנו שמשהו נשבר — בודקים אחד אחד כדי לדעת מי אשם, ורק אותו מוציאים
            _reset(repo, base)
            if check_fn:                             # 4.5.x (C6): קודם הגרסה הרשמית לבד. נכשלת גם היא = בעיה בסביבה, לא בשינויים
                P(n, "בודק את הגרסה הרשמית לבד")
                okb, whyb = check_fn()
                if not okb:
                    for c in good:
                        out[c["id"]] = {"state": "waiting", "why": "הבדיקה נכשלה גם בלי השינויים (בעיה במחשב/בסביבה, לא בשינוי): "
                                        + (str(whyb).strip() or "")[-160:]}
                    return out
            for k, c in enumerate(good, 1):
                P(n + k, "בודק שינוי אישי בנפרד")
                prev = _head(repo)
                ok2, confl, why2 = _merge_in(repo, c)
                if not ok2:
                    out[c["id"]] = _failed(repo, c, confl, why2, everyone, out)
                    continue
                sha = _commit(repo, c)
                if sha is None:                      # 4.5.x (C9): אין הבדל — לא commit ריק עם None
                    out[c["id"]] = {"state": "absorbed"}
                    continue
                f2 = _g(repo, "diff", "--name-only", prev, "HEAD")[1].splitlines()
                ok3, why3 = _verify(repo, f2, check_fn)
                if not ok3:
                    _reset(repo, prev)
                    out[c["id"]] = {"state": "incompatible", "why": why3}
                else:
                    out[c["id"]] = {"state": "applied", "commit": sha}
    return out


def _finish(repo, reg, entries, out, version, stamp, kind):
    now = int(time.time())
    results = []
    for c in entries:
        o = out.get(c["id"]) or {"state": "waiting"}
        st = o["state"]
        prev = c["state"]
        c["state"] = st
        c["reason"] = {"conflict": o.get("why", ""), "incompatible": o.get("why", ""), "waiting": o.get("why", ""),
                       "absorbed": "הגרסה הרשמית כבר כוללת את אותו שינוי"}.get(st, "")
        c["conflict_files"] = o.get("files", []) if st == "conflict" else []
        if st == "applied":
            c["commit"], c["applied_version"], c["base_version"] = o["commit"], version, version
            c["ref"] = "refs/personal/" + c["id"]
            _g(repo, "update-ref", c["ref"], o["commit"])
            pt = subprocess.run(["git", "-C", str(repo), "diff", "--binary", o["commit"] + "^", o["commit"]], capture_output=True).stdout
            (PDIR / c["id"] / "change.patch").write_bytes(pt)
            if prev != "applied":
                _event(c, "הוחל מחדש על גרסה %s" % version, version)
        else:
            c["applied_version"] = ""
            _event(c, {"conflict": "לא התמזג עם גרסה %s — הקוד הרשמי נשאר, השינוי נשמר שלם" % version,
                       "incompatible": "הוחל אבל הבדיקה נכשלה על גרסה %s — הוסר אוטומטית, נשמר" % version,
                       "absorbed": "כבר כלול בגרסה %s" % version,
                       "waiting": "לא הוחל על גרסה %s — הבדיקה נכשלה גם בלי השינויים; ינוסה שוב" % version}.get(st, st), version)
        results.append({"id": c["id"], "desc": c["desc"], "state": st, "state_he": STATE_HE.get(st, st), "reason": c["reason"],
                        "files": c["conflict_files"]})
    reg["last_reapply"] = {"at": now, "version": version, "kind": kind, "results": results, "error": ""}
    reg["last_done"] = stamp
    save(reg)
    _fold_box_history()           # 4.5.x (C8): אחרי כל בנייה מחדש ה-commits השתנו — "בטל עדכון אחרון" של התיבה כבר לא חל עליהם
    return results


def _jwrite(d):
    _guard(ROOT)
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = JOURNAL.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json.dumps(dict(d, pid=os.getpid(), ident=R.proc_ident()), ensure_ascii=False))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, JOURNAL)


def _jclear():
    try:
        JOURNAL.unlink()
    except OSError:
        pass


def _rebuild(repo, mutate, check_fn, kind, prog=None, only_if_entries=False):
    """הלב: אחרי ש-`mutate(reg)` שינה דגלים — בונים מחדש את המחסנית על הגרסה הרשמית. אטומי: או מצב חדש שלם או המצב הקודם."""
    repo = Path(repo)
    # 4.5.x (C1): עריכה ידנית בקובץ במעקב → שינוי אישי (reset היה מוחק אותה). קבצים חדשים שלא במעקב — reset לא נוגע בהם, נשארים
    register_manual(repo, "לפני בנייה מחדש של השינויים", untracked=False)
    with _Lock():
        reg = load()
        if reg.get("_corrupt"):
            raise PCError(CORRUPT_MSG % Path(reg["_corrupt"]).name)
        if _register_unaccounted(repo, reg):               # 4.5.x (C1): commits לא רשומים נכנסים למחסנית, לא נמחקים ב-reset
            save(reg)                                      # (נשמר לפני השינוי בדגלים — קריסה לא משאירה דגל שלא בוצע)
        mutate(reg)
        entries = sorted([c for c in reg["changes"] if _enabled(c)], key=lambda c: c["seq"])
        if only_if_entries and not entries:
            save(reg)
            return []
        base = official_commit(repo)
        if not base:
            raise PCError("לא נמצאה נקודת הבסיס של הגרסה הרשמית — אי אפשר לשנות כרגע בבטחה.")
        if not _clean(repo):
            raise PCError("יש בקוד שינויים שלא נשמרו כשינוי אישי — לא נוגעים בהם. (נסו שוב אחרי העדכון הבא.)")
        head0 = _head(repo)
        stamp = "%d-%d" % (os.getpid(), time.time_ns())
        _jwrite({"head_before": head0, "base": base, "ids": [c["id"] for c in entries], "kind": kind, "stamp": stamp})
        R._crashpoint("pc_before_stack")
        try:
            out = _stack(repo, base, entries, check_fn, prog)
            R._crashpoint("pc_after_stack")
        except Exception as e:
            try:
                _reset(repo, head0)
            except Exception as e2:                        # 4.5.x (C4): היומן נשאר — ההפעלה הבאה תחזיר (recover), לא "נשכח"
                raise PCError("ההחלה נעצרה (%s), וגם החזרת הקוד נכשלה (%s). לסגור ולפתוח את התוכנה — היא תשלים את ההחזרה."
                              % ((str(e)[:100] or type(e).__name__), str(e2)[:100]))
            _jclear()
            raise PCError("ההחלה נעצרה (%s) — הקוד חזר למצב הקודם." % (str(e)[:150] or type(e).__name__))
        version = R.installed_version(repo)
        res = _finish(repo, reg, entries, out, version, stamp, kind)
        R._crashpoint("pc_before_clear")
        _jclear()
        return res


def reapply(repo=None, check_fn=None, log=print, prog=None, kind="update"):
    """אחרי עדכון רשמי (או חזרה לגרסה קודמת): כל שינוי פעיל מוחל מחדש לפי הסדר. אף פעם לא זורק — כשל = השינויים ממתינים."""
    repo = Path(repo or REPO)
    if not active(repo):
        return None
    try:
        migrate_legacy(repo)
        if kind in ("update", "rollback"):
            _fold_box_history()
        reg0 = load()
        if reg0.get("_corrupt"):
            raise PCError(CORRUPT_MSG % Path(reg0["_corrupt"]).name)
        # 4.5.x (C3): גם "כבר נכלל בגרסה הרשמית" — אחרי חזרה לגרסה שאין בה את השינוי הוא צריך לחזור. אם הוא עדיין בקוד
        # הרשמי — המיזוג יזהה שוב "נכלל" (אין הבדל), בלי commit
        relevant = [c for c in reg0["changes"] if _enabled(c) or c["state"] == "absorbed"]
        if not relevant and not (official_commit(repo) and _unaccounted(repo, official_commit(repo), reg0)):
            return {"results": [], "error": ""}

        def mut(reg):
            for c in reg["changes"]:
                if _enabled(c) or c["state"] == "absorbed":
                    c["state"] = "waiting"
        res = _rebuild(repo, mut, check_fn or default_check, kind, prog)
        return {"results": res, "error": ""}
    except PCError as e:
        _mark_waiting(str(e), all_=kind in ("update", "rollback"))
        return {"results": [], "error": str(e)}
    except Exception as e:
        _mark_waiting("%s: %s" % (type(e).__name__, str(e)[:120]), all_=kind in ("update", "rollback"))
        return {"results": [], "error": "לא הצלחנו להחיל את השינויים האישיים כרגע (%s) — הם שמורים ויחולו בהפעלה הבאה." % type(e).__name__}


def _mark_waiting(msg, all_=False):
    """all_=True (אחרי עדכון רשמי / חזרה, כשהקוד כבר רשמי נקי): גם "פעיל" → "ממתין" — אחרת הרשימה אומרת "פעיל" לשינוי
    שכבר לא בקוד (4.5.x, C2)."""
    try:
        with _Lock():
            reg = load()
            for c in reg["changes"]:
                if _enabled(c) and (all_ or c["state"] != "applied"):
                    c["state"] = "waiting"
                    c["reason"] = msg[:200]
            if reg.get("last_reapply") is not None or msg:
                reg["last_reapply"] = {"at": int(time.time()), "version": R.installed_version(REPO), "kind": "error", "results": [],
                                       "error": msg[:300]}
            save(reg)
    except Exception:
        pass


CHECK_MACHINERY = ("pipeline/scripts/make_short_selftest.py", "pipeline/scripts/make_short_selftest_410.py",
                   "pipeline/scripts/make_short_update.py", "pipeline/scripts/make_short_guard.py", "pipeline/tests/")


def touches_checks(files):
    return sorted(f for f in files if any(f == m or (m.endswith("/") and f.startswith(m)) for m in CHECK_MACHINERY))


class pristine_checks:
    """4.5.x (A4/C9): שינוי שנוגע במנגנון הבדיקה עצמו (selftest, tests, הבדיקה העצמית) לא יכול "לאשר את עצמו": הבדיקה רצה על
    עותק של הקוד המשונה שבו קבצי הבדיקה מוחזרים לגרסה הרשמית (`base`). אם השינוי לא נוגע בהם — רצים במקום. מחזיר תיקייה."""

    def __init__(self, repo, base, files):
        self.repo, self.base, self.touched, self.tmp = Path(repo), base, touches_checks(files), None

    def __enter__(self):
        if not self.touched or not self.base:
            return self.repo
        self.tmp = Path(tempfile.mkdtemp(prefix="ys_pristine_check_"))
        arc = subprocess.run(["git", "-C", str(self.repo), "archive", "--format=tar", "HEAD"], capture_output=True, timeout=300)
        subprocess.run(["tar", "-x", "-C", str(self.tmp)], input=arc.stdout, capture_output=True, timeout=300, check=True)
        for f in self.touched:
            dst = self.tmp / f
            blob = subprocess.run(["git", "-C", str(self.repo), "show", "%s:%s" % (self.base, f)], capture_output=True, timeout=60)
            if dst.is_file() or dst.is_symlink():
                dst.unlink()
            if blob.returncode == 0:
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(blob.stdout)
        return self.tmp

    def __exit__(self, *a):
        if self.tmp:
            shutil.rmtree(self.tmp, ignore_errors=True)


def default_check(repo=None):
    """הבדיקה אחרי החלה: בדיקה עצמית (קומפילציה + שרת) ואז הבדיקה המהירה (make_short_selftest.py quick).
    4.5.x (C9): אם השינויים נוגעים בקבצי הבדיקה — רצים מעותק שבו הם רשמיים (pristine_checks)."""
    repo = Path(repo or REPO)
    base = official_commit(repo)
    files = _g(repo, "diff", "--name-only", base, "HEAD")[1].splitlines() if base else []
    try:
        with pristine_checks(repo, base, files) as root:
            return _run_checks(root / "pipeline" / "scripts")
    except Exception as e:
        return False, "הבדיקה לא הצליחה לרוץ: %s" % str(e)[:150]


def _run_checks(sc):
    try:
        r = subprocess.run([sys.executable, str(sc / "make_short_update.py"), "selfcheck"], capture_output=True, text=True,
                           errors="replace", timeout=300)
        if r.returncode:
            return False, (r.stdout + r.stderr).strip()[-300:]
        if os.environ.get("MAKE_SHORT_UPDATE_NO_SELFTEST") == "1":
            return True, ""
        r = subprocess.run([sys.executable, str(sc / "make_short_selftest.py"), "quick", "--json"], capture_output=True, text=True,
                           errors="replace", timeout=900)
        res = json.loads(next((l for l in reversed(r.stdout.splitlines()) if l.startswith("{")), "{}"))
        if res.get("ok"):
            return True, ""
        return False, "; ".join((res.get("errors") or ["הבדיקה המהירה נכשלה"])[:3])[:300]
    except Exception as e:
        return False, "הבדיקה לא הצליחה לרוץ: %s" % str(e)[:150]


def retry_waiting(repo=None, check_fn=None, prog=None):
    """בהפעלה / בלחיצה: שינויים שממתינים (נקטע, או לא הוחלו) — מנסים שוב על הגרסה הנוכחית. גם ⚠/⛔ (אולי הקוד השתנה)."""
    repo = Path(repo or REPO)
    if not active(repo):
        return None
    return reapply(repo, check_fn, prog=prog, kind="retry")


# ─────────────────────────── פעולות של המשתמש ───────────────────────────
def set_enabled(repo, cid, on, check_fn=None, prog=None):
    """הפעלה / כיבוי של שינוי אחד: בנייה מחדש בטוחה + בדיקה. בכישלון הבדיקה השינוי נשאר מחוץ לקוד ("לא תואם")."""
    repo = Path(repo)

    def mut(reg):
        c = _find(reg, cid)
        if on and c["state"] in ("disabled", "archived", "absorbed"):
            c["state"] = "waiting"
            _event(c, "הופעל על ידי המשתמש", R.installed_version(repo))
        elif not on and _enabled(c):
            c["state"] = "disabled"
            c["reason"] = ""
            _event(c, "כובה על ידי המשתמש", R.installed_version(repo))
        elif not on:
            raise PCError("השינוי כבר כבוי")
    res = _rebuild(repo, mut, check_fn or default_check, "toggle", prog)
    return next((r for r in res if r["id"] == cid), None)


def give_up(repo, cid, check_fn=None, prog=None):
    """"לוותר": ארכיון (אפשר לשחזר), ויוצא מהקוד אם היה בו."""
    def mut(reg):
        c = _find(reg, cid)
        c["state"] = "archived"
        c["reason"] = "ויתרתי על השינוי"
        _event(c, "ויתרתי — הועבר לארכיון (אפשר לשחזר)", R.installed_version(repo))
    _rebuild(repo, mut, check_fn or default_check, "giveup", prog)


def restore(repo, cid, check_fn=None, prog=None):
    c = next((x for x in load()["changes"] if x["id"] == cid), None)
    if not c or c["state"] != "archived":
        raise PCError("השינוי הזה לא בארכיון")
    return set_enabled(repo, cid, True, check_fn, prog)


def rename(cid, desc):
    desc = (desc or "").strip()[:200]
    if not desc:
        raise PCError("השם ריק")
    with _Lock():
        reg = load()
        c = _find(reg, cid)
        c["desc"] = desc
        save(reg)


def note_event(cid, text):
    try:
        with _Lock():
            reg = load()
            c = _find(reg, cid)
            _event(c, text, R.installed_version(REPO))
            save(reg)
    except Exception:
        pass


def patch_text(cid):
    c = _find(load(), cid)
    f = PDIR / c["id"] / "change.patch"
    return f.read_bytes().decode("utf-8", "replace") if f.is_file() else ""


def proposal_base_version(cid):
    """4.5.62: הגרסה שעליה נכתב ה-patch של השינוי הזה (לא הגרסה המותקנת עכשיו) — כדי שהבדיקה אצל המנהל תחיל אותו על הבסיס הנכון."""
    try:
        c = _find(load(), cid)
    except PCError:
        return ""
    return (c.get("applied_version") or c.get("base_version") or "") if c["state"] == "applied" else (c.get("base_version") or "")


def proposal_payload(cid):
    """לזרימת 4.4: הטקסט וה-patch של שינוי אישי אחד. → (תיאור, patch, הסבר אם לא ניתן)."""
    reg = load()
    c = _find(reg, cid)
    t = patch_text(cid)
    if not t.strip():
        return "", "", "אין בשינוי הזה קוד להציע (רק קבצים חדשים שמורים בצד)."
    if (PDIR / c["id"] / "untracked").is_dir():
        return c["desc"], t, "בשינוי יש גם קבצים חדשים שאינם נשלחים — רק ההפרשים בקבצים הקיימים."
    return c["desc"], t, ""


# ─────────────────────────── בלוק לצ'אט: "לבקש מצ'אט למזג" ───────────────────────────
def _hunks(patch):
    """{קובץ: [שורות «לפני» של כל קטע]} מתוך diff."""
    out, cur, hk = {}, None, None
    for ln in patch.splitlines():
        m = re.match(r"^diff --git a/(\S+) b/(\S+)", ln)
        if m:
            cur, hk = m.group(2), None
            out.setdefault(cur, [])
        elif cur and ln.startswith("@@"):
            hk = []
            out[cur].append(hk)
        elif cur and hk is not None and ln[:1] in (" ", "-") and not ln.startswith("--- "):
            hk.append(ln[1:])
    return out


def _locate(cur, old):
    idx = {}
    for i, l in enumerate(cur):
        if l.strip():
            idx.setdefault(l.strip(), []).append(i)
    votes = {}
    for k, l in enumerate(old):
        for i in idx.get(l.strip(), []) if l.strip() else []:
            votes[i - k] = votes.get(i - k, 0) + 1
    if votes:
        s = max(votes, key=lambda x: (votes[x], -abs(x)))
        return max(0, s), min(len(cur), s + len(old))
    first = next((x.strip() for x in old if x.strip()), "")
    m = difflib.get_close_matches(first, [x.strip() for x in cur], 1, 0.5) if first else []
    if m:
        i = next(i for i, x in enumerate(cur) if x.strip() == m[0])
        return i, min(len(cur), i + len(old))
    return None


def merge_block(repo, cid, max_chars=120000):
    """בלוק אחד להדבקה בצ'אט: מה השינוי ניסה לעשות + הקוד הרשמי החדש בדיוק באזורים האלה + הוראות. התשובה — בתיבת העדכון."""
    repo = Path(repo)
    reg = load()
    c = _find(reg, cid)
    patch = patch_text(cid)
    ver = R.installed_version(repo)
    try:
        import make_short_update as UPD
        rules = UPD.FORMAT_RULES
    except Exception:
        rules = ""
    hk = _hunks(patch)
    parts = []
    budget = max(20000, max_chars - len(patch) - len(rules) - 4000)
    for path in sorted(set(list(hk) + [f for f in c.get("files", []) if f not in hk]))[:12]:
        f = repo / path
        if not _safe_rel(path):
            continue
        if not f.is_file():
            parts.append("### %s\n(הקובץ הזה לא קיים בגרסה הרשמית החדשה — כנראה הועבר או נמחק. ראו את השינוי למעלה והציעו איפה הוא שייך עכשיו.)" % path)
            continue
        lines = f.read_text(encoding="utf-8", errors="replace").split("\n")
        per = max(4000, budget // 4)
        if sum(len(x) + 1 for x in lines) <= per:
            parts.append("### %s (כל הקובץ)\n```\n%s\n```" % (path, "\n".join(lines)))
            continue
        spans = []
        for h in hk.get(path, []):
            sp = _locate(lines, h) if h else None
            if sp:
                spans.append((max(0, sp[0] - 25), min(len(lines), sp[1] + 25)))
        if not spans:
            parts.append("### %s (תחילת הקובץ — לא נמצא אזור דומה לשינוי)\n```\n%s\n```" % (path, "\n".join(lines)[:per]))
            continue
        spans.sort()
        merged = [list(spans[0])]
        for a, b in spans[1:]:
            if a <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        body = "\n⋯\n".join("\n".join(lines[a:b]) for a, b in merged)[:per]
        parts.append("### %s (האזורים הרלוונטיים בלבד)\n```\n%s\n```" % (path, body))
    why = ("לא התמזג בקבצים: " + ", ".join(c.get("conflict_files") or ["?"])) if c["state"] == "conflict" else (c.get("reason") or "")
    txt = "\n".join([
        "=== בקשה: למזג שינוי אישי עם גרסה רשמית חדשה (תוכנת \"יצירת שורטס\") ===",
        "הכותב הוא עוזר (אדם או בינה מלאכותית). משתמש בתוכנה שינה אותה לעצמו, ועכשיו הותקנה גרסה רשמית חדשה (%s) שבה הקוד" % ver,
        "באזור הזה השתנה, ולכן השינוי שלו לא נכנס אוטומטית (%s)." % (why or "מצב: " + STATE_HE.get(c["state"], c["state"])),
        "המשימה: לכתוב את אותו שינוי שוב, כך שיתאים לקוד הרשמי החדש שלמטה — בלי לאבד את מה שהגרסה הרשמית הוסיפה.",
        "",
        "שם השינוי: %s" % c["desc"],
        "נכתב במקור על גרסה: %s" % (c.get("base_version") or "?"),
        "",
        "--- השינוי האישי המקורי (diff; שורות עם - הוסרו, עם + נוספו) ---",
        "```diff", patch[:40000].rstrip("\n"), "```",
        "",
        "--- הקוד הרשמי החדש באזורים האלה (גרסה %s) ---" % ver,
        "\n\n".join(parts) or "(אין קבצים)",
        "",
        "--- איך לענות ---",
        "ענו בפורמט של תיבת העדכון (בדיוק כמו בהוראות שלמטה), על בסיס הקוד הרשמי החדש שלמעלה.",
        "שורת התיאור חייבת להסתיים בסימון הזה בדיוק (כדי שהתוכנה תחליף את השינוי הישן בחדש):",
        "תיאור: %s [מיזוג %s]" % (c["desc"][:120], c["id"]),
        "אל תבקשו מפתחות או סיסמאות. חסר לכם קוד? ענו רק \"צריך קבצים: …\" כמו בהוראות.",
        "",
        rules,
    ])
    with _Lock():
        reg = load()
        c = _find(reg, cid)
        c["merge_requested"] = int(time.time())
        _event(c, "הועתק בלוק לצ'אט למיזוג עם גרסה %s" % ver, ver)
        save(reg)
    return {"text": txt, "chars": len(txt), "files": sorted(hk)}


# ─────────────────────────── מצב למסך / התאוששות ───────────────────────────
def status(repo=None):
    repo = Path(repo or REPO)
    reg = load()
    ch = []
    for c in sorted(reg["changes"], key=lambda x: x["seq"]):
        ch.append({"id": c["id"], "desc": c["desc"], "kind": c["kind"], "created": c["created"], "base_version": c.get("base_version", ""),
                   "applied_version": c.get("applied_version", ""), "state": c["state"], "state_he": STATE_HE.get(c["state"], c["state"]),
                   "files": c.get("files", []), "reason": c.get("reason", ""), "conflict_files": c.get("conflict_files", []),
                   "history": c.get("history", [])[-6:], "merge_requested": c.get("merge_requested", 0),
                   "has_code": (PDIR / c["id"] / "change.patch").is_file() and bool((PDIR / c["id"] / "change.patch").stat().st_size)})
    att = [c for c in ch if c["state"] in NEEDS_USER]
    return {"active": active(repo), "changes": ch, "attention": len(att), "waiting": len([c for c in ch if c["state"] == "waiting"]),
            "last_reapply": reg.get("last_reapply"), "has_official_base": bool(official_commit(repo)) if active(repo) else False}


def summary_he(results):
    """משפטים בעברית פשוטה: מה קרה לכל שינוי אישי אחרי העדכון."""
    out = []
    for r in results or []:
        d = "«%s»" % r["desc"][:70]
        out.append({"applied": "✅ השינוי שלך %s נשאר ופועל גם בגרסה החדשה." % d,
                    "conflict": "⚠ השינוי שלך %s לא נכנס — הקוד הרשמי באותו מקום השתנה. הגרסה הרשמית פועלת, והשינוי שלך שמור שלם. אפשר לבקש מצ'אט למזג." % d,
                    "incompatible": "⛔ השינוי שלך %s הוחל אבל הבדיקה נכשלה, אז הוא הוסר אוטומטית. הכול עובד, והשינוי שמור. אפשר לבקש מצ'אט למזג." % d,
                    "absorbed": "✓ השינוי שלך %s כבר כלול בגרסה הרשמית — לא צריך אותו יותר." % d}.get(r["state"], "• %s: %s" % (d, r["state_he"])))
    return out


def _personal_above(repo):
    """ה-commit העליון (HEAD) הוא עצמו commit של שינוי אישי (רשום ב-refs/personal, או הכותרת שלנו). commit של התקנה מחדש *מעל*
    שינוי אישי ישן — לא נחשב (הקוד הוחלף ברשמי)."""
    head = _head(repo)
    refs = {_g(repo, "rev-parse", "-q", "--verify", r + "^{commit}")[1]
            for r in _g(repo, "for-each-ref", "--format=%(refname)", "refs/personal/")[1].split()}
    return head in refs or _g(repo, "log", "-1", "--format=%s", "HEAD")[1].startswith(("שינוי אישי:", "שינוי ידני בקבצים"))


def _infer_official(repo):
    """ה-commit הרשמי של הגרסה המותקנת מתחת לשינויים אישיים: יורדים מ-HEAD על ההורה הראשון כל עוד זה commit של שינוי אישי
    (רשום ב-refs/personal, או הכותרת שלנו), ובודקים שה-VERSION שם הוא הגרסה המותקנת. '' = לא נמצא / אין שינויים מעל."""
    ver = R.installed_version(repo)
    if not ver:
        return ""
    refs = {_g(repo, "rev-parse", "-q", "--verify", r + "^{commit}")[1]
            for r in _g(repo, "for-each-ref", "--format=%(refname)", "refs/personal/")[1].split()}
    sha, steps = _head(repo), 0
    while sha and steps < 200:
        subj = _g(repo, "log", "-1", "--format=%s", sha)[1]
        if sha in refs or subj.startswith(("שינוי אישי:", "שינוי ידני בקבצים")):
            sha = _g(repo, "rev-parse", "-q", "--verify", sha + "^")[1]
            steps += 1
            continue
        break
    if not steps or not sha:
        return ""
    v = _g(repo, "show", "%s:VERSION" % sha)[1].strip()
    return sha if v == ver else ""


def startup_consistency(repo=None):
    """4.5.x (C7, וגם אחרי ש-shorts.sh חזר לבד לגרסה הקודמת — B7): הקוד הוחלף מבחוץ (התקנה מחדש מחבילה, חזרה).
    אין תגית rel-X לגרסה המותקנת → מסמנים את הקוד הנוכחי (אם נקי) כבסיס הרשמי. שינוי "פעיל" שה-commit שלו לא בקוד → "ממתין"
    (pc_watch יחיל אותו שוב). מחזיר כמה סומנו."""
    repo = Path(repo or REPO)
    if not active(repo):
        return 0
    if R.installed_version(repo) and not official_commit(repo):
        # 4.5.62 (#2): HEAD יכול להיות "רשמי + commits של שינויים אישיים" — לא מתייגים אותו כרשמי; מחפשים את ה-commit הרשמי מתחתיהם
        inferred = _infer_official(repo)
        if inferred:
            _g(repo, "tag", "-f", "rel-" + R.installed_version(repo), inferred)
        elif not _personal_above(repo):
            R._ensure_base_tag(repo)
    n = 0
    base = official_commit(repo)

    def in_code(sha):          # בקוד = בין הבסיס הרשמי ל-HEAD (commit ישן מהבסיס כבר נדרס ע"י הקוד הרשמי)
        return bool(sha) and _g(repo, "merge-base", "--is-ancestor", sha, "HEAD")[0] == 0 and \
            not (base and _g(repo, "merge-base", "--is-ancestor", sha, base)[0] == 0)
    with _Lock():
        reg = load()
        if reg.get("_corrupt"):
            return 0
        for c in reg["changes"]:
            if _enabled(c) and c["state"] == "applied" and not in_code(c.get("commit")):
                c["state"] = "waiting"
                c["reason"] = "הקוד הוחלף (התקנה מחדש או חזרה לגרסה קודמת) — השינוי יוחל שוב"
                _event(c, c["reason"], R.installed_version(repo))
                n += 1
            elif _enabled(c) and c["state"] in ("conflict", "waiting", "incompatible") and in_code(c.get("commit")):
                # 4.5.62 (#2): הרישום אמר "לא התמזג" אבל ה-commit של השינוי כן בקוד (למשל אחרי חזרה אוטומטית) — הרישום מתיישר עם הקוד
                c["state"], c["reason"], c["conflict_files"] = "applied", "", []
                c["applied_version"] = R.installed_version(repo)
                _event(c, "נמצא בקוד — הרישום עודכן ל«פעיל»", R.installed_version(repo))
                n += 1
        if n:
            save(reg)
    return n


def recover(repo=None):
    """בהפעלה: יומן החלה-מחדש שנשאר = נקטע באמצע (חשמל/כיבוי). חוזרים למצב השלם הקודם ומסמנים את השינויים "ממתין" — retry_waiting ימשיך."""
    repo = Path(repo or REPO)
    try:
        j = json.loads(JOURNAL.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        if JOURNAL.exists():
            _jclear()
        return ""
    if not active(repo):
        return ""
    try:
        mt = JOURNAL.stat().st_mtime
    except OSError:
        mt = None
    # 4.5.x (C6/C9): "חי" = אותו אתחול ואותו זמן התחלה (לא מספר תהליך שחזר); בלי חלון של 20 דקות — בדיקה ארוכה לא "מתה"
    if R.owner_alive(j.get("pid"), j.get("ident"), mt):
        return ""
    with _Lock():
        reg = load()
        if reg.get("last_done") == j.get("stamp"):
            _jclear()
            return ""
        if j.get("head_before"):
            _reset(repo, j["head_before"])
        if j.get("kind") in ("update", "rollback", "retry"):
            for c in reg["changes"]:
                if _enabled(c) and c["id"] in j.get("ids", []):
                    c["state"] = "waiting"
                    c["reason"] = "ההחלה נקטעה באמצע — תנוסה שוב"
        save(reg)
        _jclear()
    return "החלת השינויים האישיים נקטעה באמצע (כנראה כיבוי) — הקוד חזר למצב השלם האחרון והשינויים יוחלו שוב."


def _main(a):
    if not a:
        sys.exit(__doc__)
    if a[0] == "status":
        print(json.dumps(status(), ensure_ascii=False, indent=1))
    elif a[0] == "recover":
        print(recover() or "אין מה להתאושש")
    elif a[0] == "register-manual":              # המתקין, לפני התקנה מחדש מחבילה (4.5.x, C7)
        c = register_manual(REPO, "לפני התקנה מחדש מחבילה")
        print(c["id"] if c else "אין עריכות ידניות")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    _main(sys.argv[1:])
