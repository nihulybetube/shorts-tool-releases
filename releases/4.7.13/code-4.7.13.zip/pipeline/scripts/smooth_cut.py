# -*- coding: utf-8 -*-
"""
מחליף את auto-editor בגישה שמייצרת מעברי crossfade רכים בין הקטעים,
במקום קאט קשה. משתמש ב-ffmpeg silencedetect לזיהוי שקטים, ואז בונה
שרשרת xfade (וידאו) + acrossfade (אודיו) בין קטעי הדיבור.
"""
import re
import subprocess
import sys
import json

NOISE_DB = "-30dB"       # ברירת מחדל בלבד - ראה adaptive_noise_db()
MIN_SILENCE = 0.9       # שקט קצר מזה לא ייחתך (נשמר כהפסקה טבעית - כולל נשימות)
MARGIN = 0.15            # שניות שנשארות כ"נשימה" לפני/אחרי כל חיתוך
XFADE_DUR = 0.18         # משך מעבר הדיסולב
EDGE_GUARD = 1.0         # אין חיתוך בשנייה הראשונה/אחרונה - ראה compute_keep_segments


def get_duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True
    )
    return float(out.stdout.strip())


def adaptive_noise_db(path):
    """בוחר סף שקט יחסי לעוצמה של הקליפ עצמו, לא ערך מוחלט.

    סף קבוע של -30dB נכשל על הקלטות אולם שקטות: באזכרה של אתר ישיבה
    ה-mean_volume של חלק מהקטעים היה -36.7dB, כלומר *מתחת* לסף, ולכן
    תחילת מילה שקטה ("הרב...") סווגה כשקט ונאכלה. מעגנים ב-max_volume
    (שיא אמיתי של דיבור) פחות 24dB, ולא מרשים סף גבוה מ--30dB.
    """
    res = subprocess.run(
        ["ffmpeg", "-hide_banner", "-i", path, "-af", "volumedetect", "-f", "null", "-"],
        capture_output=True, text=True
    )
    m = re.search(r"max_volume:\s*(-?[\d.]+) dB", res.stderr)
    if not m:
        return NOISE_DB
    return f"{min(-30.0, float(m.group(1)) - 24.0):.1f}dB"


def detect_silence(path, noise_db=None):
    noise_db = noise_db or NOISE_DB
    cmd = ["ffmpeg", "-i", path, "-af", f"silencedetect=noise={noise_db}:d={MIN_SILENCE}", "-f", "null", "-"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    log = res.stderr
    starts = [float(x) for x in re.findall(r"silence_start:\s*([\d.]+)", log)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*([\d.]+)", log)]
    return list(zip(starts, ends))


def compute_keep_segments(path, noise_db=None):
    dur = get_duration(path)
    noise_db = noise_db or adaptive_noise_db(path)
    silences = detect_silence(path, noise_db)
    keep = []
    cursor = 0.0
    for s_start, s_end in silences:
        cut_start = s_start + MARGIN
        cut_end = s_end - MARGIN
        # שמירה על הקצוות: המילה הראשונה/אחרונה של הקליפ נחתכה בפועל כי
        # ה-onset שלה שקט מהסף. גבולות הקליפ כבר אומתו מול התמלול, אז
        # אין שם מה "לנקות" - פשוט לא נוגעים.
        if cut_start < EDGE_GUARD:
            cut_start = max(cut_start, min(EDGE_GUARD, s_end))
        if cut_end > dur - EDGE_GUARD:
            cut_end = min(cut_end, max(dur - EDGE_GUARD, s_start))
        if cut_start > cursor and cut_end > cut_start:
            keep.append((cursor, cut_start))
            cursor = cut_end
    if cursor < dur:
        keep.append((cursor, dur))
    keep = [(a, b) for a, b in keep if b - a > 0.05]
    return keep


def build_smooth_cut(input_path, output_path):
    segments = compute_keep_segments(input_path)
    if len(segments) <= 1:
        # אין מה לחתוך - פשוט מעתיק
        subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path], check=True, capture_output=True)
        return segments

    n = len(segments)
    filter_parts = []
    for i, (a, b) in enumerate(segments):
        filter_parts.append(f"[0:v]trim={a}:{b},setpts=PTS-STARTPTS[v{i}];")
        filter_parts.append(f"[0:a]atrim={a}:{b},asetpts=PTS-STARTPTS[a{i}];")

    # שרשור xfade/acrossfade הדרגתי
    cur_v = "v0"
    cur_a = "a0"
    cur_dur = segments[0][1] - segments[0][0]
    for i in range(1, n):
        seg_dur = segments[i][1] - segments[i][0]
        offset = max(0.0, cur_dur - XFADE_DUR)
        nv = f"vx{i}"
        na = f"ax{i}"
        filter_parts.append(
            f"[{cur_v}][v{i}]xfade=transition=fade:duration={XFADE_DUR}:offset={offset:.3f}[{nv}];"
        )
        filter_parts.append(
            f"[{cur_a}][a{i}]acrossfade=d={XFADE_DUR}[{na}];"
        )
        cur_v = nv
        cur_a = na
        cur_dur = cur_dur - XFADE_DUR + seg_dur

    filter_complex = "".join(filter_parts)
    cmd = [
        "ffmpeg", "-y", "-i", input_path,
        "-filter_complex", filter_complex,
        "-map", f"[{cur_v}]", "-map", f"[{cur_a}]",
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-c:a", "aac", "-b:a", "192k",
        output_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return segments


if __name__ == "__main__":
    inp, outp = sys.argv[1], sys.argv[2]
    segs = build_smooth_cut(inp, outp)
    print(json.dumps({"segments": segs, "count": len(segs)}, indent=2))
