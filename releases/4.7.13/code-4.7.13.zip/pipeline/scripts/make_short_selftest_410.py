# -*- coding: utf-8 -*-
"""
make_short_selftest_410.py — בדיקות של גרסה 4.1.0 (ביקורת קוד חיצונית): חבילת שיתוף, חיבור Drive עם מפתח משלו, ממשק מקומי.

נקרא מ-make_short_selftest.py (main). כל בדיקה כאן עושה את הדבר האמיתי על קבצים מזויפים בתיקייה זמנית — אף פעם לא על
ההגדרות, המוזיקה או הדרייב של הבעלים. כל קבוצה רצה בתהליך נפרד (קוד כמחרוזת), כמו שאר הבדיקות.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = sys.executable
# שם המשתמש של הבעלים — מחובר, כדי שהקובץ הזה (שנכנס לחבילה) לא יכיל אותו כמות שהוא
OWNER_USER = "ita" + "i"
OWNER_GH = "nihuly" + "betube"


def _run(code, T, env, extra=(), timeout=300):
    r = subprocess.run([PY, "-c", code, str(HERE), str(T), *extra], env=env, capture_output=True, text=True,
                       errors="replace", timeout=timeout, cwd=str(T))
    try:
        return json.loads(r.stdout.strip().splitlines()[-1]), ""
    except (ValueError, IndexError):
        return None, (r.stdout + r.stderr).strip()[-600:]


SHARE_CODE = r'''
import hashlib, io, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); OU, OG = sys.argv[3], sys.argv[4]
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
base = T / "sh410"; shutil.rmtree(base, ignore_errors=True); base.mkdir()
OWN = base / "owner" / "music"; (OWN / "tracks").mkdir(parents=True); (OWN / "_refs").mkdir()
os.environ["SHORTS_DATA_DIR"] = str(base / "owner"); os.environ["SHORTS_CONFIG_DIR"] = str(base / "ownercfg")
os.environ["HOME"] = str(base / "fakehome")
import importlib, make_short_share as SH, music_library as ML
importlib.reload(SH)
# ---------- 1. אינדקס ניתן לנשיאה ----------
foreign = "/home/%s/.local/share/yeshiva-shorts/music" % OU
for n in ("a", "b"):
    (OWN / "tracks" / (n + ".mp3")).write_bytes(b"ID3" + n.encode() * 50)
idx = {"source": {"x": 1}, "tracks": [
    {"uuid": "u-a", "title": "A", "downloaded": "2026", "path": foreign + "/tracks/a.mp3"},
    {"uuid": "u-b", "title": "B", "downloaded": "2026", "path": foreign + "/tracks/b.mp3", "removed_from": foreign + "/tracks"},
    {"uuid": "u-gone", "title": "G", "downloaded": "2026", "path": foreign + "/tracks/gone.mp3"},
    {"uuid": "u-cat", "title": "C"}]}
(OWN / "index.json").write_text(json.dumps(idx), encoding="utf-8")
(OWN / "_refs" / "mix.py").write_text("# mix v2\n", encoding="utf-8")
SH.MUSIC = OWN
raw, dropped = SH.portable_index()
chk(b"/home/" not in raw and OU.encode() not in raw, "אינדקס החבילה: אין בו /home/ ואין שם משתמש")
pi = json.loads(raw)
chk([t.get("path") for t in pi["tracks"]] == ["tracks/a.mp3", "tracks/b.mp3", None, None] and dropped == 1,
    "נתיבי הקטעים יחסיים; קטע בלי קובץ בחבילה מאבד נתיב", str([t.get("path") for t in pi["tracks"]]))
chk("removed_from" not in pi["tracks"][1] and "downloaded" not in pi["tracks"][2], "removed_from נעלם; קטע בלי קובץ לא מסומן כמורד")
# ---------- 2. מקבל עם משתמש אחר: הנתיבים נפתרים לתיקייה שלו ----------
R = base / "recv" / "data"; (R / "music" / "tracks").mkdir(parents=True)
for n in ("a", "b"):
    shutil.copy(OWN / "tracks" / (n + ".mp3"), R / "music" / "tracks")
(R / "music" / "index.json").write_bytes(raw)
os.environ["SHORTS_DATA_DIR"] = str(R)
got = ML.downloaded_tracks(ML.load_index())
chk(sorted(t["uuid"] for t in got) == ["u-a", "u-b"] and all(str(R) in t["path"] and os.path.isfile(t["path"]) for t in got),
    "מקבל אחר: downloaded_tracks מוצא את הקטעים בתיקייה שלו (נתיבים יחסיים)", str([t["path"] for t in got]))
(R / "music" / "index.json").write_text(json.dumps(idx), encoding="utf-8")       # אינדקס ישן עם /home/<הבעלים>/ מוחלט
got = ML.downloaded_tracks(ML.load_index())
chk(sorted(t["uuid"] for t in got) == ["u-a", "u-b"] and all(str(R) in t["path"] for t in got),
    "גם אינדקס ישן עם נתיב מוחלט של מחשב אחר נפתר מקומית")
own_abs = str(R / "music" / "tracks" / "a.mp3")
(R / "music" / "index.json").write_text(json.dumps({"tracks": [{"uuid": "u-a", "downloaded": "x", "path": own_abs, "likes": 3}]}), encoding="utf-8")
t0 = ML.load_index()["tracks"][0]
chk(t0["path"] == own_abs and t0["likes"] == 3, "האינדקס של הבעלים עצמו (נתיב מוחלט שקיים) נשאר כמו שהוא")
# מוסר/משוחזר עובדים גם אחרי החלפת מחשב
import make_short_music as MM
(R / "music" / "index.json").write_bytes(raw)
MM.remove("u-a")
chk(os.path.isfile(R / "music" / "_rejected" / "a.mp3"), "הסרת קטע אצל המקבל: עוברת ל-_rejected שלו")
MM.restore("u-a")
chk(os.path.isfile(R / "music" / "tracks" / "a.mp3"), "שחזור קטע אצל המקבל: חוזר ל-tracks שלו")
# ---------- 3. התקנה מחדש: מיזוג קטעים חדשים, לייקים נשארים, mix.py מתעדכן ----------
fb = base / "recv" / "fb.json"; fb.write_text(json.dumps({"tracks": {"u-a": {"ratings": [{"note": "like"}]}}}), encoding="utf-8")
pkg = base / "pkgmusic"; shutil.copytree(OWN, pkg)
extra = {"uuid": "u-new", "title": "N", "downloaded": "x", "path": "tracks/new.mp3"}
pidx = json.loads(raw); pidx["tracks"].append(extra); (pkg / "tracks" / "new.mp3").write_bytes(b"ID3new")
(pkg / "index.json").write_text(json.dumps(pidx), encoding="utf-8")
(R / "music" / "_refs").mkdir(exist_ok=True); (R / "music" / "_refs" / "mix.py").write_text("# mix v1\n", encoding="utf-8")
shutil.copy(pkg / "tracks" / "new.mp3", R / "music" / "tracks" / "new.mp3")
before = json.loads((R / "music" / "index.json").read_text(encoding="utf-8"))
n, mixed = SH.merge_music(pkg, R / "music")
after = json.loads((R / "music" / "index.json").read_text(encoding="utf-8"))
chk(n == 1 and mixed and (R / "music" / "_refs" / "mix.py").read_text() == "# mix v2\n", "התקנה מחדש: קטע חדש נכנס לאינדקס ו-mix.py הוחלף", "%s %s" % (n, mixed))
chk([t["uuid"] for t in after["tracks"]][:4] == [t["uuid"] for t in before["tracks"]][:4] and after["tracks"][-1]["uuid"] == "u-new"
    and after["tracks"][-1]["path"] == str(R / "music" / "tracks" / "new.mp3"), "הקטעים הקיימים נשארים בסדר ובשדות שלהם; החדש עם נתיב מלא אצלו")
chk(json.loads(fb.read_text())["tracks"]["u-a"]["ratings"], "הלייקים (קובץ נפרד) לא נגעו")
n2, mixed2 = SH.merge_music(pkg, R / "music")
chk(n2 == 0 and not mixed2, "מיזוג שני: אין שינוי (אידמפוטנטי)")
# ---------- 4. אריזה: מסמכים אישיים, ניטרול זהות, זרימת GitHub ----------
for rel in ("CHANGELOG.md", "docs/\u05de\u05d3\u05e8\u05d9\u05da-\u05d4\u05e2\u05d1\u05e8\u05d4-\u05dc\u05de\u05d7\u05e9\u05d1-\u05d0\u05d7\u05e8.md"):
    chk(SH.package_member(rel, b"x", False) is None, "לא נארז: " + rel[:20])
ho = ("# H\nRepo `%s/x`, home /home/%s, C:\\Users\\%s\n## 9. dbg\nok\n## 10. People\nsecret story\n## 11. Ext\nend\n" % (OG, OU, OU + "4")).encode()
nm, hb = SH.package_member("docs/HANDOFF.md", ho, False)
chk(OG.encode() not in hb and OU.encode() not in hb and b"secret story" not in hb and b"## 11. Ext" in hb and b"## 9. dbg" in hb,
    "HANDOFF בחבילה: בלי זהות ובלי סעיף האנשים, שאר הסעיפים נשארים")
ps = ("\ufeffa\r\n# <GITHUB-FLOW-BEGIN>\r\n$RepoUrl='https://github.com/%s/x'\r\ngit config --global user.name \"%s\"\r\n# <GITHUB-FLOW-END>\r\nb\r\n" % (OG, OG)).encode("utf-8")
nm, pb = SH.package_member("windows/install_windows.ps1", ps, False)
chk(pb.startswith(b"\xef\xbb\xbf") and OG.encode() not in pb and b"user.name" not in pb and pb.decode("utf-8-sig").replace("\r\n", "|") == "a|b|",
    "מתקין בחבילה: קטע ה-GitHub (כתובת, זהות גיט) הוסר, ה-BOM נשאר")
real_ps = (Path(sys.argv[1]).parent.parent / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig")
chk(real_ps.count("<GITHUB-FLOW-BEGIN>") == 2 and real_ps.count("<GITHUB-FLOW-END>") == 2
    and OG not in SH.strip_github_flow(real_ps), "install_windows.ps1 האמיתי: אחרי הסרת הקטע אין בו את זהות ה-GitHub")
import base64
BE, HE = "Beit" + " El", "בית אל"
prof_needles = [base64.b64decode(x).decode("utf-8") for x in SH._PROFILE_NEEDLES_B64]
chk(prof_needles == [BE, HE], "מחרוזות פרופיל מפוענחות נכון", str(prof_needles))
nm, tb = SH.package_member("x.md", ("%s / %s" % (BE, HE)).encode(), True)
chk(BE.encode() not in tb and HE.encode() not in tb, "חבילת פרופיל: 'בית אל' מוחלף בטקסט הנארז")
nm, tb = SH.package_member("x.md", BE.encode(), False)
chk(tb == BE.encode(), "חבילה רגילה: 'בית אל' נשאר (ההנחיות והלוגו שלו שם בכוונה)")
# ---------- 5. סריקות ----------
def mkzip(path, files):
    with zipfile.ZipFile(path, "w") as z:
        for n, d in files.items():
            z.writestr(n, d)
    return path
z1 = mkzip(base / "id1.zip", {"code/a.py": ("x = '%s'" % OG.upper()).encode(), "code/ok.py": b"print(1)"})
chk(SH.identity_scan(z1, profile=False) == ["code/a.py"], "זהות באותיות גדולות נתפסת (לא רגיש לאותיות)", str(SH.identity_scan(z1, profile=False)))
z2 = mkzip(base / "id2.zip", {"code/u.txt": ("my path /home/%s/x" % OU).encode("utf-16")})
chk(SH.identity_scan(z2, profile=False) == ["code/u.txt"], "זהות בקובץ UTF-16 נתפסת")
z3 = mkzip(base / "id3.zip", {"code/b.md": (BE + " site").encode(), "extras/config/guidelines.txt": b"clean"})
chk(SH.identity_scan(z3, profile=False) == [] and SH.identity_scan(z3, profile=True) == ["code/b.md"],
    "'Beit El' נתפס רק בחבילת פרופיל")
z4 = mkzip(base / "id4.zip", {"extras/music/index.json": b'{"path": "/home/someone/x.mp3"}', "code/readme.txt": b"see /home/<user>"})
chk(SH.identity_scan(z4, profile=False) == ["extras/music/index.json (\u05e0\u05ea\u05d9\u05d1 /home/)"], "נתיב /home/ בתוך extras נפסל (ובקוד/מדריך לא)", str(SH.identity_scan(z4, profile=False)))
cs = "GOCSPX-" + "abcDEF1234567890abcdEFGH"
priv = "-----BEGIN " + "PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7"
for nm_, body in (("gocspx", cs.encode()), ("gocspx_lower", cs.lower().encode()), ("gocspx_u16", cs.encode("utf-16")),
                  ("privkey", priv.encode()), ("aiza", ("AI" + "za" + "A" * 35).lower().encode())):
    chk(SH.scan(mkzip(base / ("s_%s.zip" % nm_), {"code/f.txt": body})) == ["code/f.txt"], "סריקת סודות תופסת: " + nm_)
chk(SH.scan(mkzip(base / "s_clean.zip", {"code/f.sh": b"grep -- '-----BEGIN' x; echo GOCSPX- AIza"})) == [],
    "מילה בלבד (בלי גוף של מפתח) בקוד לא פוסלת את החבילה")
(base / "fakehome" / ".config" / "rclone").mkdir(parents=True)
sec = "GO" + "CSPX-" + "zzzz1111yyyy2222xxxx3333"
(base / "fakehome" / ".config" / "rclone" / "rclone.conf").write_text("[x]\nclient_" + "secret = " + sec + "\n", encoding="utf-8")
chk(sec.encode() in SH.known_secrets() and SH.scan(mkzip(base / "s_cs.zip", {"code/n.txt": sec.upper().encode()})) == ["code/n.txt"],
    "סוד הלקוח מ-rclone.conf נקרא ונתפס גם באותיות אחרות")
# ---------- 5ב. לוגו שלו שנשמר מחדש / הוגדל — נתפס בחבילת פרופיל (פענוח PNG בלי PIL) ----------
import struct, zlib
def png(w, h, f, ft=0, level=6):
    def chunk(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    raw, prev = b"", bytes(w * 4)
    for y in range(h):
        line = bytes(c for x in range(w) for c in f(x, y))
        fl = []
        for i in range(len(line)):
            a = line[i - 4] if i >= 4 else 0; b = prev[i]; c = prev[i - 4] if i >= 4 else 0
            if ft == 0: pr = 0
            elif ft == 1: pr = a
            elif ft == 2: pr = b
            elif ft == 3: pr = (a + b) >> 1
            else:
                p = a + b - c; pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
            fl.append((line[i] - pr) & 255)
        raw += bytes([ft]) + bytes(fl); prev = line
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, level))
            + chunk(b"IEND", b""))
art = lambda x, y: ((x * 6) % 256, (y * 9) % 256, (x * y) % 256, 255 if (x // 5 + y // 5) % 3 else 40)
other = lambda x, y: (255 - (x * 3) % 256, (y * 2) % 256, 30, 255 if x > y else 0)
big = lambda x, y: art(x // 2, y // 2)
base_png = png(40, 40, art)
sigs = {(ft, lv): SH._logo_sigs(png(40, 40, art, ft, lv)) for ft in range(5) for lv in (1, 9)}
chk(base_png != png(40, 40, art, 4, 9) and len({s[0] for s in sigs.values()}) == 1 and None not in sigs.values(),
    "אותו ציור בכל סוגי הפילטר ורמות הדחיסה של PNG → אותו hash פיקסלים (בלי PIL)")
chk(SH._logo_sigs(png(40, 40, other))[0] != sigs[(0, 1)][0], "ציור אחר — hash אחר")
(base / "ownercfg" / "brand").mkdir(parents=True, exist_ok=True)
(base / "ownercfg" / "brand" / "logo.png").write_bytes(base_png)
importlib.reload(SH)
zl = lambda name, data: mkzip(base / name, {"code/assets/a.png": data, "code/ok.py": b"x"})
chk(SH.identity_scan(zl("lg0.zip", base_png)) == ["code/assets/a.png (הלוגו שלך)"], "אותו קובץ לוגו — נתפס (hash)")
chk(SH.identity_scan(zl("lg1.zip", png(40, 40, art, 4, 9))) == ["code/assets/a.png (נראה כמו הלוגו שלך)"],
    "הלוגו שנשמר מחדש בדחיסה אחרת — נתפס בהשוואת פיקסלים", str(SH.identity_scan(zl("lg1.zip", png(40, 40, art, 4, 9)))))
chk(SH.identity_scan(zl("lg2.zip", png(80, 80, big))) != [], "הלוגו אחרי הגדלה פי 2 — נתפס (חתימה תפיסתית)")
chk(SH.identity_scan(zl("lg3.zip", png(40, 40, other))) == [], "ציור אחר לגמרי — לא נתפס")
chk(SH.identity_scan(zl("lg4.zip", base_png), profile=False) == [], "חבילה רגילה: הלוגו שלו נשאר בכוונה")
# ---------- 6. zip זר לא נספר ולא נמחק ----------
D = base / "zips"; D.mkdir()
mkzip(D / "foreign.zip", {"a.txt": b"hi"})
mkzip(D / "notours.zip", {"package.json": json.dumps({"hello": 1}).encode()})
ours = mkzip(D / "ours_old.zip", {"package.json": json.dumps({"format": 1, "commit": "abc1234 x"}).encode()})
new = mkzip(D / "ours_new.zip", {"package.json": json.dumps({"format": 1, "commit": "abc1234 x"}).encode()})
os.utime(ours, (1, 1))
chk([z.name for z in SH.zip_list(D)] == ["ours_new.zip", "ours_old.zip"], "zip_list: רק חבילות עם format ו-commit", str([z.name for z in SH.zip_list(D)]))
os.environ["MAKE_SHORT_NO_EXPORT"] = "1"
SH.prune(D, new)
chk((D / "foreign.zip").exists() and (D / "notours.zip").exists() and not ours.exists(), "prune: zip זר לא נוגעים בו; הישן שלנו הוסר")
# ---------- 7. הגדרות המקבל: שבור / לא קריא / פרופיל לא תקין ----------
S = base / "settings"; S.mkdir()
pj = S / "p.json"; pj.write_text(json.dumps({"name": "x", "org_name": "ישיבה"}), encoding="utf-8")
sp = S / "s.json"; sp.write_text("{not json", encoding="utf-8")
SH.apply_profile(pj, sp)
chk((S / "s.json.bak").read_text() == "{not json" and json.loads(sp.read_text())["values"]["org_name"] == "ישיבה",
    "הגדרות שבורות: נשמר עותק .bak לפני שנכתב קובץ חדש")
sp2 = S / "s2.json"; sp2.write_text("[1,2]", encoding="utf-8")
SH.receiver_init(sp2)
chk((S / "s2.json.bak").exists() and json.loads(sp2.read_text())["values"]["view_mode"] == "simple", "receiver_init: קובץ שאינו אובייקט גם נשמר כ-.bak")
sp3 = S / "s3.json"; sp3.mkdir()                          # OSError שאינו FileNotFoundError (זה תיקייה)
try:
    SH.apply_profile(pj, sp3); chk(False, "קובץ הגדרות שאי אפשר לקרוא עוצר")
except SystemExit as e:
    chk("לא שיניתי כלום" in str(e), "קובץ הגדרות שאי אפשר לקרוא: עוצרים בהודעה פשוטה, בלי לדרוס")
bad = S / "bad_profile.json"; bad.write_text("[1]", encoding="utf-8")
sp4 = S / "s4.json"
chk(SH.apply_profile(bad, sp4) == [] and not sp4.exists(), "קובץ פרופיל שאינו אובייקט לא מפיל את ההתקנה")
bad.write_text("not json", encoding="utf-8")
chk(SH.apply_profile(bad, sp4) == [], "קובץ פרופיל שבור לא מפיל את ההתקנה")
# ---------- 8. תיאור: org_name ריק, ומעבר שורה ----------
import make_short as MS
MS.desc_settings = lambda cfg=None: {"footer_lines": "", "org_name": None, "subscribe_text": "", "fixed_tags": None}
cd = base / "clipd"; cd.mkdir()
os.chdir(base)
try:
    MS.write_meta({"url": "https://example.org/v", "channel_url": ""}, {"name": "clip1"}, cd, "רב", "סדרה",
                  {"כותרת": "כותרת", "תגיות": "א,ב", "תיאור": "גוף"}, "משפט ראשון. שני.", None)
    m = json.loads((cd / "meta.json").read_text(encoding="utf-8"))
    chk("רב" in m["tags"] and "סדרה" in m["tags"], "write_meta: org_name ריק (None) לא מפיל", str(m["tags"]))
except Exception as e:
    chk(False, "write_meta: org_name ריק (None) לא מפיל", repr(e))
cd2 = base / "clipe"; cd2.mkdir()
foot = "C:\\new\\tmp ◄ https://x.y/a\\nb"
r = subprocess.run([sys.executable, str(Path(sys.argv[1]) / "write_clip_meta.py"), str(cd2), "--title", "t", "--description", "d", "--subscribe", "",
                    "--footer", foot], capture_output=True, text=True)
d = json.loads((cd2 / "meta.json").read_text(encoding="utf-8"))["description"]
chk(foot in d, "write_clip_meta: \\n כטקסט (נתיב ווינדוס / כתובת) לא מומר לירידת שורה", d)
cd3 = base / "clipf"; cd3.mkdir()
r = subprocess.run([sys.executable, str(Path(sys.argv[1]) / "write_clip_meta.py"), str(cd3), "--title", "t", "--description", "d", "--subscribe", "",
                    "--footer", "שורה1\nשורה2"], capture_output=True, text=True)
chk(json.loads((cd3 / "meta.json").read_text(encoding="utf-8"))["description"].endswith("שורה1\nשורה2"), "write_clip_meta: שורות אמיתיות נשמרות")
print(json.dumps(out, ensure_ascii=False))
'''


OWNKEY_CODE = r'''
import json, os, shlex, stat, subprocess, sys, threading, time, re
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
base = T / "ok410"; base.mkdir(exist_ok=True)
conf = base / "rclone.conf"; lsf = base / "lsf_state"; argvlog = base / "argv.log"
fake = base / "rclone"
fake.write_text("""#!/usr/bin/env python3
import sys, json, configparser
C = %r; S = %r; L = %r
a = sys.argv[1:]
open(L, "a").write(" ".join(a) + "\\n")
cp = configparser.RawConfigParser(); cp.read(C)
if a[:2] == ["config", "file"]: print("Configuration file is stored at:"); print(C)
elif a[:2] == ["config", "dump"]: print(json.dumps({s: dict(cp.items(s)) for s in cp.sections()}))
elif a[:1] == ["listremotes"]: print("gdrive:")
elif a[:1] == ["lsf"]:
    n = int(open(S).read() or 0)
    if n != 0:
        if n > 0: open(S, "w").write(str(n - 1))
        sys.exit(1)
sys.exit(0)
""" % (str(conf), str(lsf), str(argvlog)))
os.chmod(fake, 0o755)
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked"))
import make_short_health as H
import make_short_app as A
H.RCLONE = A.HEALTH.RCLONE = str(fake)
ORIG_LAUNCH = A.launch_black_window
A.rclone_busy = lambda: False
A.backup_running = lambda: False
A.RECONNECT_PAUSE = 0
A.PROJECTS = base / "projects"; A.PROJECTS.mkdir(exist_ok=True)
TOK = "tok" + "en"
def mk(cid=None, secret=None, tok="T0", scope="drive.file"):
    s = "[gdrive]\ntype = drive\nscope = %s\n" % scope
    if cid: s += "client_id = %s\n" % cid
    if secret: s += "client_" + "sec" + "ret = %s\n" % secret
    return s + TOK + ' = {"access_' + TOK + '":"%s"}\n' % tok + "[other]\ntype = local\n"
CID = "123-abc.apps.googleusercontent.com"
SEC = "GOCSPX-" + "sekrit_value_for_test_9"
P = H.own_key_paths(conf)
def reset(text, lsf_n=0, pending=False, before=None, ok=False):
    for p in P.values(): p.unlink(missing_ok=True)
    conf.write_text(text); lsf.write_text(str(lsf_n)); argvlog.write_text("")
    if before is not None: P["before"].write_text(before)
    if pending: P["pending"].write_text("x")
    if ok: P["ok"].write_text("x")
    H.DRIVE_NOTE[0] = ""
    A.OWN_KEY["active"] = False
    A.HEALTH_STATE.setdefault("actions", {}).pop("drive_reconnect", None)
    os.environ.pop("MAKE_SHORT_FAKE_RECONNECT", None)
def sim_window(rc="0", newtok="T1"):
    """חלון שחור מזויף: כמו rclone אמיתי — כותב טוקן חדש להגדרות וקובץ "סיימתי" (הנתיב נקרא מהסקריפט שנוצר, עם הציטוט שלו)."""
    def go(sh):
        txt = Path(sh).read_text()
        done = shlex.split(re.search(r"echo \$\? > (.+)", txt).group(1))[0]
        if rc == "0":
            t = conf.read_text()
            conf.write_text(re.sub(TOK + r" = .*", TOK + ' = {"access_' + TOK + '":"' + newtok + '"}', t))
        Path(done).write_text(rc)
    A.launch_black_window = go
def wait_state(states=("ok", "fail"), secs=30):
    for _ in range(secs * 4):
        a = A.HEALTH_STATE.get("actions", {}).get("drive_reconnect", {})
        if a.get("state") in states and not A.OWN_KEY["active"]: return a
        time.sleep(0.25)
    return A.HEALTH_STATE.get("actions", {}).get("drive_reconnect", {})
def verr(f, *a):
    try: f(*a); return ""
    except ValueError as e: return str(e)
# ---------- 1. בדיקה שנפלה פעם-פעמיים אחרי rc=0: לא מחזירים, מנסים שוב, ומסמנים ----------
reset(mk(), lsf_n=2); sim_window()
A.drive_own_key(CID, SEC); a = wait_state()
chk(a.get("state") == "ok" and P["ok"].exists() and not P["pending"].exists() and CID in conf.read_text(),
    "lsf נכשל פעמיים ואז הצליח: מחובר, ok נכתב, ההגדרות החדשות נשארות", str(a))
# ---------- 2. rc=0, טוקן חדש, אבל כל הבדיקות נכשלות: לא מחזירים לעולם ----------
reset(mk(), lsf_n=-1); sim_window()
A.drive_own_key(CID, SEC); a = wait_state()
chk(a.get("state") == "fail" and "מחובר, הבדיקה נכשלה" in a.get("msg", "") and P["ok"].exists()
    and CID in conf.read_text() and "T1" in conf.read_text(), "כל ה-lsf נכשלו אבל הטוקן חדש: לא מוחזר, מסומן 'מחובר, הבדיקה נכשלה'", str(a))
tries = argvlog.read_text().count("lsf gdrive:")
chk(tries >= A.RECONNECT_TRIES, "הבדיקה נוסתה כמה פעמים לפני ויתור (%d)" % tries)
# ---------- 3. rc שונה מאפס: מוחזר, ו-ok לא נשאר ----------
reset(mk(), lsf_n=0); sim_window(rc="130")
A.drive_own_key(CID, SEC); a = wait_state()
chk(a.get("state") == "fail" and conf.read_text() == mk() and not P["before"].exists() and not P["pending"].exists() and not P["ok"].exists(),
    "חיבור שנקטע: ההגדרות הקודמות חזרו במדויק, אין before / pending / ok", str(a))
reset(mk(CID, SEC), before=mk(), pending=True, ok=True)
H.restore_before(conf)
chk(not P["ok"].exists() and conf.read_text() == mk(), "restore_before מסיר גם own_key_ok")
# ---------- 4. הסוד לא בשורת פקודה; הקבצים 0600 ----------
reset(mk(), lsf_n=0); sim_window()
runs = []
orig_run, orig_popen = subprocess.run, subprocess.Popen
subprocess.run = lambda *a, **k: (runs.append(list(a[0]) if isinstance(a[0], (list, tuple)) else a[0]), orig_run(*a, **k))[1]
subprocess.Popen = lambda *a, **k: (runs.append(list(a[0]) if isinstance(a[0], (list, tuple)) else a[0]), orig_popen(*a, **k))[1]
modes = {}
orig_wp = H.write_private
def spy(path, data):
    orig_wp(path, data); modes[Path(path).name] = stat.S_IMODE(os.stat(path).st_mode)
H.write_private = spy
A.drive_own_key(CID, SEC); wait_state()
subprocess.run, subprocess.Popen = orig_run, orig_popen
H.write_private = orig_wp
chk(not any(SEC in " ".join(map(str, r)) for r in runs) and SEC not in argvlog.read_text(), "הסוד לא מופיע באף שורת פקודה (ps) ולא ביומן הקריאות", str(len(runs)))
chk(re.search(r"client_" + "sec" + "ret = " + re.escape(SEC), conf.read_text()) is not None, "הסוד נכתב להגדרות בעריכה פנימית")
chk(stat.S_IMODE(os.stat(conf).st_mode) == 0o600 and modes.get(conf.name + ".before_own_key", 0) == 0o600,
    "קובץ ההגדרות והעותק נוצרים ב-0600 מההתחלה", str(modes))
# ---------- 5. קריסה באמצע כתיבה: הקובץ המקורי שלם ולא נשארים קבצים זמניים ----------
reset(mk(), lsf_n=0)
real_replace = os.replace
os.replace = lambda *a, **k: (_ for _ in ()).throw(OSError(28, "No space left on device"))
try:
    H.write_private(conf, "garbage")
    chk(False, "קריסה באמצע כתיבה אטומית")
except OSError:
    chk(conf.read_text() == mk() and not list(base.glob("rclone.conf.tmp*")), "קריסה לפני os.replace: הקובץ המקורי שלם, אין קובץ זמני")
os.replace = real_replace
reset(mk(), lsf_n=0)
orig_cu = H.conf_update
H.conf_update = lambda *a, **k: (_ for _ in ()).throw(OSError(28, "No space left on device"))
m = verr(A.drive_own_key, CID, SEC)
H.conf_update = orig_cu
chk("שום דבר לא השתנה" in m and conf.read_text() == mk() and not P["before"].exists() and not P["pending"].exists() and not A.OWN_KEY["active"],
    "כתיבת המפתח נכשלה: ההגדרות כמו שהיו, בלי סימנים, והדגל 'פעיל' ירד", m)
# ---------- 6. קריאה כפולה, חלון פתוח, גיבוי רץ ----------
reset(mk(), lsf_n=0); sim_window()
gate, entered = threading.Event(), threading.Event()
orig_run2 = H._run
def slow(cmd, t):
    if cmd[1:3] == ["config", "file"]:
        entered.set(); gate.wait(10)
    return orig_run2(cmd, t)
H._run = slow
res1 = {}
th = threading.Thread(target=lambda: res1.update(r=verr(A.drive_own_key, CID, SEC)), daemon=True); th.start()
entered.wait(10)
m2 = verr(A.drive_own_key, CID, SEC)
chk("כבר מתחיל" in m2, "קריאה שנייה בו-זמנית נדחית (נעילה)", m2)
gate.set(); th.join(30); H._run = orig_run2
a = wait_state()
chk(res1.get("r") == "" and a.get("state") == "ok" and P["ok"].exists(), "הקריאה הראשונה ממשיכה ומסתיימת כרגיל אחרי הדחייה", str(res1) + str(a))
reset(mk(), lsf_n=0)
A.rclone_busy = lambda: True
m = verr(A.drive_own_key, CID, SEC)
A.rclone_busy = lambda: False
chk("חלון שחור" in m and not P["before"].exists() and not P["pending"].exists(), "חלון שחור פתוח (stale busy): נדחה ולא נוצר עותק", m)
reset(mk(), lsf_n=0, pending=True, before=mk())
A.OWN_KEY["active"] = True
m = verr(A.drive_own_key, CID, SEC)
chk("באמצע" in m and conf.read_text() == mk(), "ניסיון פעיל (דגל) + pending: קריאה חדשה נדחית בלי לגעת בהגדרות", m)
A.OWN_KEY["active"] = False
reset(mk(), lsf_n=0)
A.backup_running = lambda: True
m = verr(A.drive_own_key, CID, SEC)
A.backup_running = lambda: False
chk("גיבוי" in m and not P["before"].exists() and conf.read_text() == mk(), "גיבוי רץ: ההגדרות לא מוחלפות מתחתיו", m)
# ---------- 7. אותו client_id אחרי שהשרת נסגר בין החיבור לסימון ----------
reset(mk(CID, SEC, "T1"), pending=True, before=mk(CID, SEC, "T0"))
st = H.own_key_recover(conf)
r = H.check_drive(True)
chk(st == "done" and P["ok"].exists() and r["level"] == "ok", "אותו client_id, טוקן חדש: מסומן הושלם — בלי אזהרה שקרית לתמיד", "%s %s" % (st, r.get("title")))
reset(mk(CID, "GOCSPX-" + "typo_secret_value_x", "T0"), pending=True, before=mk(CID, SEC, "T0"))
st = H.own_key_recover(conf)
chk(st == "restored" and conf.read_text() == mk(CID, SEC, "T0"), "אותו client_id ואותו טוקן, רק הסוד השתנה והחיבור נקטע: הסוד הקודם חוזר", st)
reset(mk(CID, SEC, "T0"), pending=True, before=mk(CID, SEC, "T0"))
chk(H.own_key_recover(conf) == "none" and not P["before"].exists() and not P["pending"].exists(), "לא השתנה כלום: העותק והסימן מנוקים")
# ---------- 8. קובץ הגדרות קטוע (unknown) — חוזרים מהעותק ----------
reset("[gdrive\ntype = dri", pending=True, before=mk())
chk(H.own_key_recover(conf) == "restored" and conf.read_text() == mk(), "הגדרות קטועות באמצע כתיבה + עותק תקין: מוחזר מהעותק")
reset("[gdrive]\ntype = drive\n", pending=True, before="[gdrive\nbroken")
chk(H.own_key_recover(conf) == "unknown", "גם העותק פגום: לא מנחשים (unknown)")
# ---------- 9. done ייחודי לכל ניסיון; ציטוט נתיבים ----------
reset(mk(), lsf_n=0)
os.environ["MAKE_SHORT_FAKE_RECONNECT"] = "0"
A.drive_reconnect(); n1 = sorted(p.name for p in A.PROJECTS.parent.glob("drive_reconnect_*"))
wait_state(); time.sleep(0.5)
os.environ.pop("MAKE_SHORT_FAKE_RECONNECT", None)
A.PROJECTS = base / "my dir (x)" / "projects"; A.PROJECTS.mkdir(parents=True, exist_ok=True)
seen = []
sim_calls = []
A.launch_black_window = lambda sh: sim_calls.append(Path(sh).read_text())
A.drive_reconnect()
d1 = re.search(r"drive_reconnect_(\w+)\.done", sim_calls[0]).group(1)
A.action_set("drive_reconnect", "fail", "x")
A.drive_reconnect()
d2 = re.search(r"drive_reconnect_(\w+)\.done", sim_calls[1]).group(1)
chk(d1 != d2, "שם קובץ ה-done שונה בכל ניסיון (חלון שחור ישן לא ישפיע על חדש)", "%s %s" % (d1, d2))
path_in_script = shlex.split(re.search(r"echo \$\? > (.+)", sim_calls[0]).group(1))[0]
chk("my dir (x)" in path_in_script and "'" in re.search(r"echo \$\? > (.+)", sim_calls[0]).group(1), "נתיב עם רווח וסוגריים מצוטט בסקריפט (shlex.quote)")
popen_args = []
subprocess.Popen = lambda *a, **k: popen_args.append(list(a[0]))
sp = A.PROJECTS.parent / "w.sh"; sp.write_text("#!/bin/bash\necho hi\n")
ORIG_LAUNCH(sp)                                       # נתיב עם רווח → עותק ב-/tmp; ל-cmd.exe מגיע רק נתיב בטוח
sp2 = base / "safe.sh"; sp2.write_text("#!/bin/bash\n")
ORIG_LAUNCH(sp2)
subprocess.Popen = orig_popen
passed, passed2 = popen_args[0][-1], popen_args[1][-1]
chk(re.fullmatch(r"[A-Za-z0-9_./:@+=,-]+", passed) and passed.startswith("/tmp/ys_win_") and Path(passed).read_text() == sp.read_text()
    and passed2 == str(sp2), "נתיב עם רווח: לחלון השחור (cmd.exe) מועבר עותק בנתיב בטוח; נתיב בטוח עובר כמו שהוא", passed)
Path(passed).unlink(missing_ok=True)
# ---------- 10. הגיבוי ברקע מושהה בזמן ניסיון ----------
runs2 = []
A.NET["ok"] = True
A.MS.drive_cmd = lambda: ("x",)
A.MS.drive_pending = lambda: {"last_change": 0, "n": 1}
A.MS.run_drive_backup = lambda: (runs2.append(1), (True, ""))[1]
A.SET.load = lambda: {"drive_on": True}
A.DRIVE_Q.update(boot=time.time() - 100, running=False, closing=False, last_error="", kick=False)
A.OWN_KEY["active"] = True
t = threading.Thread(target=A.drive_watch, daemon=True); t.start()
time.sleep(7)
paused = not runs2
A.OWN_KEY["active"] = False
for _ in range(20):
    if runs2: break
    time.sleep(0.5)
chk(paused and runs2, "גיבוי ברקע מושהה כל עוד ניסיון מפתח אישי פעיל, וחוזר מיד אחריו", "paused=%s runs=%d" % (paused, len(runs2)))
print(json.dumps(out, ensure_ascii=False))
'''


def ownkey_checks(T, env, ok, say):
    say("\n▶ מפתח אישי לדרייב — הקשחה (4.1.0)")
    res, err = _run(OWNKEY_CODE, T, dict(env), timeout=300)
    if res is None:
        return ok(False, "בדיקות ההקשחה של המפתח האישי רצו", err)
    for c, w, d in res:
        ok(c, w, d)


API_CODE = r'''
import ast, json, os, re, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import make_short as MS, make_short_update as UPD
SC = Path(sys.argv[1])
# ---------- קישורים ----------
good = ["https://www.youtube.com/watch?v=abcdefghijk", "https://youtu.be/abcdefghijk?t=5", "http://m.youtube.com/playlist?list=PLx",
        "https://youtube.com/shorts/abcdefghijk", "https://music.youtube.com/watch?v=abcdefghijk"]
bad = ["--exec=touch /tmp/x", "-x", "https://evil.example/https://www.youtube.com/", "https://www.youtube.com/watch?v=a b",
       "https://www.youtube.com/watch?v=a\nb", "file:///etc/passwd", "", None, "https://youtube.com.evil.example/x", "ftp://youtu.be/x"]
chk(all(MS.check_url(u) == u for u in good), "check_url מקבל קישורי יוטיוב רגילים")
def rej(u):
    try: MS.check_url(u); return False
    except ValueError: return True
chk(all(rej(u) for u in bad), "check_url דוחה אופציות של yt-dlp, אתרים זרים, רווחים ושורות חדשות", str([u for u in bad if not rej(u)]))
# ---------- "--" לפני כל קישור שמגיע ל-yt-dlp (בדיקה על העץ של הקוד) ----------
missing = []
for fn in ("make_short.py", "make_short_pick.py", "auto_pipeline.py"):
    tree = ast.parse((SC / fn).read_text(encoding="utf-8"))
    parent = {}
    for n in ast.walk(tree):
        for c in ast.iter_child_nodes(n): parent[c] = n
    for n in ast.walk(tree):
        if isinstance(n, ast.List) and any(isinstance(e, ast.Constant) and e.value == "yt-dlp" for e in n.elts):
            st = n
            while not isinstance(st, ast.stmt): st = parent[st]
            has = any(isinstance(x, ast.Constant) and x.value == "--" for x in ast.walk(st))
            if not has: missing.append("%s:%d" % (fn, n.lineno))
chk(not missing, "בכל קריאה ל-yt-dlp מהקוד יש '--' לפני הקישור", ", ".join(missing))
import make_short_pick as PICK
calls = []
class R:
    returncode = 0; stdout = ""; stderr = ""
import subprocess
orig = subprocess.run
subprocess.run = lambda cmd, *a, **k: (calls.append(list(cmd)), R())[1]
MS.run = lambda cmd, *a, **k: (calls.append([str(x) for x in cmd]), "id\tt\tc\t10")[1]
try:
    PICK.list_playlist("https://www.youtube.com/playlist?list=PLabc")
except Exception: pass
try: PICK.yt_info("https://youtu.be/abcdefghijk")
except Exception: pass
subprocess.run = orig
yt = [c for c in calls if "yt-dlp" in c]
chk(len(yt) >= 2 and all(c[-2] == "--" for c in yt), "list_playlist / yt_info בפועל: '--' ואז הקישור בסוף", str([c[-3:] for c in yt]))
try:
    PICK.list_playlist("--exec=touch /tmp/ys_pwn2"); chk(False, "list_playlist דוחה ערך שאינו קישור")
except ValueError:
    chk(not os.path.exists("/tmp/ys_pwn2"), "list_playlist דוחה ערך שאינו קישור")
# ---------- נתיבים ב-diff ----------
def any_problem(d, lvl=1): return any(UPD.path_problem(x) for x in UPD.diff_paths(d, lvl))
ok_diff = "diff --git a/pipeline/scripts/make_short.py b/pipeline/scripts/make_short.py\n--- a/pipeline/scripts/make_short.py\n+++ b/pipeline/scripts/make_short.py\n@@ -1 +1 @@\n-a\n+b\n"
chk(UPD.diff_paths(ok_diff, 1) == {"pipeline/scripts/make_short.py"} and not any_problem(ok_diff), "diff רגיל: הנתיב נקרא נכון ועובר")
q1 = 'diff --git "a/config.env\\t" "b/config.env\\t"\n--- "a/config.env\\t"\n+++ "b/config.env\\t"\n@@ -1 +1 @@\n-a\n+b\n'
chk(any_problem(q1), "נתיב מצוטט (C-style) נדחה — לא עוקף את בדיקת הקבצים האסורים")
q2 = "--- a/dir with space/x.py\n+++ b/dir with space/x.py\n@@ -1 +1 @@\n-a\n+b\n"
chk(any_problem(q2), "נתיב עם רווחים נדחה")
q3 = '--- "a/x.py"\n+++ "b/x.py"\n@@ -1 +1 @@\n-a\n+b\n'
chk(any_problem(q3, 1), "נתיב עם מירכאות נדחה")
chk(UPD.path_problem('a"b.py') and UPD.path_problem("a b.py") and UPD.path_problem("a\tb.py"), "path_problem: מירכאות / רווח / tab")
# ---------- שגיאות בלי נתיב הבית ----------
import make_short_app as A
home = os.path.expanduser("~")
t = A.err_text(ValueError("לא נמצא %s/.config/yeshiva-shorts/x.json ו-/home/someone/y וגם /mnt/c/Users/Someone/z" % home))
chk(home not in t and "/home/someone" not in t and "/mnt/c/Users/Someone" not in t and "x.json" in t, "err_text מסיר נתיבי בית אבל משאיר את שם הקובץ", t)
chk(A.b64_limited("QUJD", "logo") == b"ABC", "b64_limited מפענח קובץ קטן")
try:
    A.b64_limited("A" * (A.UPLOAD_LIMITS["logo"] * 2), "logo"); chk(False, "b64_limited דוחה קובץ ענק")
except ValueError as e:
    chk("גדול מדי" in str(e), "b64_limited דוחה קובץ ענק לפני פענוח")
print(json.dumps(out, ensure_ascii=False))
'''


def api_checks(T, env, ok, say):
    say("\n▶ ממשק מקומי — הקשחה (4.1.0)")
    res, err = _run(API_CODE, T, dict(env), timeout=300)
    if res is None:
        ok(False, "בדיקות ההקשחה של הממשק רצו", err)
    else:
        for c, w, d in res:
            ok(c, w, d)
    # השרת האמיתי (פורט פנוי, מצב בדיקה): גודל בקשה, refresh, קישורים, העלאות
    r = subprocess.run([PY, str(HERE.parent / "tests" / "test_local_guard.py")], capture_output=True, text=True, errors="replace",
                       timeout=300, env={k: v for k, v in env.items() if not k.startswith("SHORTS_PROJECTS")})
    bad = [l.strip() for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    ok(r.returncode == 0 and not bad, "שרת אמיתי: test_local_guard (כולל גודל בקשה, refresh, קישורים, העלאות)",
       "; ".join(bad[:4]) or r.stderr[-300:])


def all_checks(T, env, ok, say):
    # 4.5.62: אצל מקבל (.from_package) הקוד כבר עבר ניטרול זהות והקטע של GitHub הוסר — בדיקות האריזה מניחות עץ בעלים
    if (HERE.parent.parent / ".from_package").exists():
        say("\n▶ חבילת שיתוף — מדלגים (העץ הזה הותקן מחבילה; הבדיקות האלה לעץ הבעלים)")
    else:
        share_checks(T, env, ok, say)
    ownkey_checks(T, env, ok, say)
    api_checks(T, env, ok, say)


def share_checks(T, env, ok, say):
    say("\n▶ חבילת שיתוף — הקשחה (4.1.0)")
    res, err = _run(SHARE_CODE, T, dict(env), extra=(OWNER_USER, OWNER_GH))
    if res is None:
        return ok(False, "בדיקות ההקשחה של חבילת השיתוף רצו", err)
    for c, w, d in res:
        ok(c, w, d)
