# -*- coding: utf-8 -*-
"""
make_short_selftest.py — "בקרת איכות ובדיקה לסתירות במערכת" (22/10/2026, כרטיס 14).

למה: לתוכנה יש עשרות הגדרות ומצבים (מוזיקה כבויה, כל המנגינות מושבתות, שני הסמלים כבויים, צבעים שהושבתו
מהאקראי, דילוג על תיקון הטקסט, הכנה בלי אינטרנט, תור שנשמר, עדכון עצמי, גיבוי ברקע, חבילת שיתוף...). כל
אחד נבדק לבד כשנבנה — אבל צירוף של שניים יכול להיתקע או לסתור. כאן מריצים מטריצה של צירופים על
"שיעור" זעיר מלאכותי (4 שניות, נוצר כאן — בלי הורדה, בלי Modal, בלי אינטרנט), במצב בדיקה, בתיקייה זמנית,
ונכשלים על כל קריסה או על כל "כלל ברזל" שנשבר:
  • טיוטה לעולם לא נשמרת לתיקיית השורטס לבד (רק "💾 שמור")
  • בתיקיית השורטס רק סרטונים ו«תיאור להעתקה.txt»
  • שתי האוזניים — אף פעם לא אותו מודל
  • אין מפתח / עוגייה / טוקן בדוח לעוזר ובחבילת השיתוף
  • עבודה רצה עם ההגדרות שהיו כשלחץ (גם אחרי הפסקה)

שימוש:  shorts.sh py make_short_selftest.py [matrix|package|all|quick] [--json] [--keep]
  matrix   הצירופים (כ-2–4 דקות: כל צירוף = סיום אמיתי של קליף 4 שניות)
  quick    27/10: כללי הקוד + צירוף ברירת המחדל + שמירה/ויתור + בדיקות השרת — רץ לבד אחרי כל עדכון מתיבת "עדכון תוכנה"
  התוצאה האחרונה נשמרת ב-~/.local/share/yeshiva-shorts/selftest_last.json (לבלוק "🐞 מצאתי באג")
  package  חבילת שיתוף: בנייה לתיקייה זמנית → חילוץ → חלקי ההתקנה עצמם (מתוך install_windows.ps1) לבית זמני →
           גרסה = ה-commit הנוכחי, כל קובץ הרצה בפנים וזהה, שום סוד/קובץ אישי. רץ לבד אחרי כל עדכון.
  --json   שורה אחרונה = {"ok":..., "errors":[...]} (לחלון)
  --keep   לא למחוק את התיקייה הזמנית (לחקירה)
🚨 לא נוגע בשום דבר אמיתי: פרויקטים, תור, הגדרות, לייקים, ייצוא ודרייב — כולם בתיקייה הזמנית.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
PY = sys.executable
ERRORS, NOTES = [], []
JSON_OUT = "--json" in sys.argv


def say(s):
    if not JSON_OUT:
        print(s, flush=True)
    else:
        print(s, file=sys.stderr, flush=True)


def ok(cond, what, detail=""):
    if cond:
        say("   ✓ " + what)
    else:
        ERRORS.append(what + (" — " + detail if detail else ""))
        say("   ✗ %s%s" % (what, (" — " + detail) if detail else ""))
    return cond


def ffmpeg():
    return os.environ.get("FFMPEG") or shutil.which("ffmpeg") or "ffmpeg"


# ─────────────── סביבת בדיקה ───────────────

def test_env(T):
    """משתני סביבה לבדיקה — הכול בתוך T. ההגדרות, התור, הלייקים, הייצוא והדרייב — עותקים זמניים."""
    (T / "projects" / "תוכנה").mkdir(parents=True, exist_ok=True)
    for d in ("export", "drive", "shorts_root", "share"):
        (T / d).mkdir(exist_ok=True)
    fb_real = Path(os.environ.get("SHORTS_MUSIC_FEEDBACK") or
                   Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts")) / "music-feedback.json")
    fb = T / "music-feedback.json"
    if fb_real.exists() and not fb.exists():
        shutil.copy(fb_real, fb)
    env = dict(os.environ, MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_TEST_EXPORT=str(T / "export"),
               MAKE_SHORT_TEST_DRIVE_DST=str(T / "drive"), SHORTS_PROJECTS=str(T / "projects"),
               MAKE_SHORT_QUEUE=str(T / "queue.json"), MAKE_SHORT_SETTINGS=str(T / "settings.json"),
               SHORTS_MUSIC_FEEDBACK=str(fb), SHORTS_EXPORT_DIR=str(T / "shorts_root"), SHORTS_SHARE_DIR=str(T / "share"),
               SHORTS_SHARE_PROFILES=str(T / "share_profiles"),   # 3.5: פרופילים למקבלים — לא של אמת
               MAKE_SHORT_IDLE_EXIT="0", MAKE_SHORT_ASR="off", MAKE_SHORT_ASR_NO_CPU="1", PYTHONUNBUFFERED="1",
               MAKE_SHORT_NO_SHARE_CHECK="1", MAKE_SHORT_NO_MODAL_METER="1",
               SHORTS_EXPORT_LEDGER=str(T / "exports.jsonl"),   # 22/10: לא ליומן הייצוא האמיתי
               MAKE_SHORT_GLOSSARY=str(T / "glossary.json"), MAKE_SHORT_QUALITY=str(T / "quality.jsonl"))  # 28/10
    env.pop("GEMINI_API_KEY", None)                   # שום בקשה אמיתית ל-Gemini מתוך בדיקה
    env.pop("MAKE_SHORT_SETTINGS_SNAP", None)
    # 4.1.2: תיקיית ההגדרות, הרבנים והמכסה — כולן זמניות (בעבר רק ההגדרות עצמן, והשאר דלף לתיקייה האמיתית).
    # קריאה בלבד מהאמיתית: הלוגו וההנחיות מועתקים; שום סוד (config.env / עוגיות / rclone) לא מועתק.
    cfg_real = real_config_dir()
    cfg = T / "config"
    (cfg / "rabbis").mkdir(parents=True, exist_ok=True)
    if (cfg_real / "brand").is_dir() and not (cfg / "brand").exists():
        shutil.copytree(cfg_real / "brand", cfg / "brand")
    if (cfg_real / "guidelines.txt").is_file() and not (cfg / "guidelines.txt").exists():
        shutil.copy(cfg_real / "guidelines.txt", cfg / "guidelines.txt")
    env.update(SHORTS_CONFIG_DIR=str(cfg), MAKE_SHORT_RABBIS=str(cfg / "rabbis"), MAKE_SHORT_TEST_GUARD="1",
               MAKE_SHORT_GEMINI_USAGE=str(T / "gemini_usage_all.json"))
    return env


def real_config_dir():
    """התיקייה האמיתית של הבעלים — לפי משתמש המערכת, לא לפי $HOME (שאפשר להחליף)."""
    sys.path.insert(0, str(HERE))
    import make_short_guard
    return make_short_guard.real_dirs()[0]


WORDS = ["בדיקה", "אחת", "שתיים", "שלוש", "ארבע", "חמש", "שש", "שבע", "שמונה", "תשע"]


def make_fixture(T, name="fixture", words=None, text=None):
    """שיעור מלאכותי: קליף אחד של 4 שניות (תמונת בדיקה + צליל), "אוזן" מוכנה, קובץ עריכה עם ספק אחד.
    words/text — אוזן וטקסט אחרים (28/10: "D9" באמצע — כתובית עם אותיות לועזיות)."""
    sys.path.insert(0, str(HERE))
    import make_short as MS
    P = T / "projects" / "תוכנה" / ("2026-01-01_%s" % name)
    (P / "work" / "clips").mkdir(parents=True, exist_ok=True)
    (P / "work" / "ear").mkdir(parents=True, exist_ok=True)
    (P / "work" / "subtitles").mkdir(parents=True, exist_ok=True)
    (P / "לעריכה").mkdir(exist_ok=True)
    clean = P / "work" / "clips" / "clip1_clean.mp4"
    base = T / "fixture_clean.mp4"
    if not base.exists():
        subprocess.run([ffmpeg(), "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30",
                        "-f", "lavfi", "-i", "sine=frequency=220:sample_rate=48000", "-t", "4", "-c:v", "libx264",
                        "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(base)], check=True)
    shutil.copy(base, clean)
    words = [{"word": w, "start": round(0.2 + i * 0.36, 2), "end": round(0.2 + i * 0.36 + 0.3, 2)}
             for i, w in enumerate(words or WORDS)]
    ear = P / "work" / "ear" / "clip1_clean_words.json"
    ear.write_text(json.dumps({"words": words, "model": MS.LARGE}, ensure_ascii=False), encoding="utf-8")
    c = {"name": "clip1", "clean": "work/clips/clip1_clean.mp4", "edit": "לעריכה/clip1.txt",
         "ear1": "work/ear/clip1_clean_words.json", "seconds": 4.0, "cuts": [[100.0, 104.0]], "doubts": [[1.0, "[שתיים / שתים]"]],
         "camera": "default", "framing": {"ok": True}}
    st = {"project": str(P), "url": "https://www.youtube.com/watch?v=selftest000", "video_id": "selftest000",
          "video_title": "בדיקה עצמית", "channel_url": "", "rabbi": "הרב בדיקה", "series": "סדרת בדיקה",
          "series_title": "סדרת בדיקה", "clips": [c], "warnings": []}
    (P / MS.STATE).write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    text = text or "בדיקה אחת, [שתיים / שתים] שלוש ארבע חמש. שש שבע שמונה תשע."
    MS.write_edit(P / c["edit"], c, P, "כותרת בדיקה", "תיאור בדיקה", "", text, "")
    return P


def set_settings(T, values):
    (T / "settings.json").write_text(json.dumps({"values": values}, ensure_ascii=False), encoding="utf-8")


def run_ms(env, *args, timeout=600):
    r = subprocess.run([PY, "-u", str(HERE / "make_short.py"), *map(str, args)], env=env, capture_output=True,
                       text=True, errors="replace", timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def ass_rgb(P):
    """צבע ההדגשה שנצרב בפועל (מתוך ה-ass): RRGGBB."""
    a = (P / "work" / "subtitles" / "clip1.ass").read_text(encoding="utf-8")
    m = re.findall(r"\\1c&H00([0-9A-F]{6})&|&H00([0-9A-F]{6})", a)
    cols = {x or y for x, y in m}
    out = set()
    for bgr in cols:
        out.add(bgr[4:6] + bgr[2:4] + bgr[0:2])
    return out


def final_video(P):
    v = sorted((P / "shorts").glob("clip1*/*.mp4"))
    return v[0] if v else None


def meta_of(P):
    try:
        return json.load(open(sorted((P / "shorts").glob("clip1*/meta.json"))[0], encoding="utf-8"))
    except (IndexError, OSError, ValueError):
        return {}


# ─────────────── מטריצת הצירופים ───────────────

def matrix(T, env, quick=False):
    """quick (27/10): רק צירוף ברירת המחדל + שמירה/ויתור/שחזור — לבדיקה אחרי כל עדכון מהתיבה."""
    sys.path.insert(0, str(HERE))
    import make_short as MS
    import make_short_settings as SETM
    say("\n▶ מטריצת הגדרות (כל צירוף = סיום אמיתי של קליף 4 שניות)%s" % (" — רק ברירת המחדל (מהיר)" if quick else ""))
    export_dir = T / "export"
    teal = SETM.DEFAULT_COLORS["teal"]
    import karaoke_styles as KS0
    new_off = ["MARKER:" + c for c in KS0.MARKER_COLORS] + ["FLOAT"] + ["FLOAT:" + c for c in KS0.FLOAT_EMPH_COLORS] \
        + ["BOX:" + c for c in KS0.BOX_COLORS]   # 30/10: גם הם באקראי
    combos = [
        ("ברירת מחדל", {}, None),
        ("מוזיקה כבויה", {"music_on": False}, None),
        ("שני הסמלים כבויים", {"logo_on": False, "logo2_on": False}, None),
        ("שני הסמלים דולקים", {"logo_on": True, "logo2_on": True}, None),
        ("כל הצבעים הושבתו", {"colors_off": list(SETM.DEFAULT_COLORS.values()) + list(SETM.STYLE_NAMES) + new_off}, None),
        ("רק סגול נשאר פעיל", {"colors_off": [x for k, x in SETM.DEFAULT_COLORS.items() if k != "purple"]
                               + list(SETM.STYLE_NAMES) + new_off}, None),
        ("רק \"ללא צבע\" נשאר פעיל", {"colors_off": list(SETM.DEFAULT_COLORS.values()) + new_off}, None),
        # 31/10 (כרטיס 23): הגדרה ישנה (random_off + marker_off) עוברת ל"מושבת" — אותה תוצאה כמו "רק סגול"
        ("ישן: random_off/marker_off → מושבת", {"random_off": [x for k, x in SETM.DEFAULT_COLORS.items() if k != "purple"]
                                                + list(SETM.STYLE_NAMES) + [x for x in new_off if not x.startswith("MARKER:")],
                                                "marker_off": list(KS0.MARKER_COLORS)}, None),
        ("צבע משלו + מוזיקה הכי חלשה", {"sub_color": "custom:FF7A00", "custom_colors": ["FF7A00"], "music_level": -8}, None),
        ("כל המנגינות מושבתות", {}, "all_disabled"),
        ("דילוג על תיקון הטקסט (הסיום עצמו)", {"skip_text_check": True}, None),
    ][:1 if quick else None]
    fb_path = Path(env["SHORTS_MUSIC_FEEDBACK"])
    fb_orig = fb_path.read_bytes() if fb_path.exists() else None
    for i, (label, vals, special) in enumerate(combos, 1):
        say("\n %d. %s" % (i, label))
        P = make_fixture(T, "m%d" % i)
        set_settings(T, vals)
        if special == "all_disabled":           # בעותק הזמני של הלייקים בלבד
            r = subprocess.run([PY, "-c", "import sys;sys.path.insert(0,sys.argv[1]);import make_short_music as M;"
                                "n=[M.set_disabled(t['uuid'],True) for t in M.listing() if t.get('status') in ('active','pending')];"
                                "print(len(n))", str(HERE)], env=env, capture_output=True, text=True, errors="replace")
            ok(r.returncode == 0, "כל המנגינות הושבתו (בעותק): %s" % r.stdout.strip()[-6:], r.stderr.strip()[-200:])
        t0 = time.time()
        rc, out = run_ms(env, "finish", P)
        if special == "all_disabled" and fb_orig is not None:
            fb_path.write_bytes(fb_orig)
        if not ok(rc == 0, "הסיום עבר בלי קריסה (%.0f שנ')" % (time.time() - t0), out.strip().splitlines()[-1] if rc else ""):
            continue
        v = final_video(P)
        ok(v is not None, "נוצרה טיוטה")
        ok(not any(export_dir.rglob("*")), "שום דבר לא נכנס לתיקיית השורטס לבד (טיוטה בלבד)")
        meta = meta_of(P)
        if vals.get("music_on") is False:
            ok(not meta.get("music"), "בלי מוזיקה — אין מנגינה ב-meta")
        if special == "all_disabled":
            ok("אין אף מנגינה פעילה" in out, "כל המנגינות מושבתות → נבנה בלי מוזיקה, עם הודעה ברורה (לא נכשל)")
            ok(not meta.get("music"), "ובאמת בלי מנגינה")
        if label.startswith("ישן:"):
            mv = dict(vals)
            SETM.migrate_off(mv)
            ok("random_off" not in mv and "marker_off" not in mv and "MARKER:10206E" in mv["colors_off"]
               and SETM.DEFAULT_COLORS["teal"] in mv["colors_off"], "ההגדרה הישנה עברה ל\"מושבת\" (colors_off)")
        if label.startswith("רק \"ללא צבע\""):
            a = (P / "work" / "subtitles" / "clip1.ass").read_text(encoding="utf-8-sig")
            ok("; ys-style: plain" in a and "Dialogue: 2" not in a,
               "רק \"ללא צבע\" באקראי → נצרב ללא צבע (בלי הדגשה רצה, המתג כבוי → בלי מילים צבועות)")
        elif "colors_off" in vals or "random_off" in vals:
            cols = ass_rgb(P)
            if label.startswith("כל הצבעים"):
                ok(teal in cols, "כולם מושבתים → טורקיז", ",".join(sorted(cols)))
                ok("נלקח טורקיז" in out, "ההודעה \"נלקח טורקיז\" בדוח")
            else:
                ok(SETM.DEFAULT_COLORS["purple"] in cols, "רק סגול מותר → סגול", ",".join(sorted(cols)))
        if vals.get("sub_color", "").startswith("custom:"):
            ok("FF7A00" in ass_rgb(P), "צבע משלו נצרב")
        if label.startswith("דילוג"):
            raw = MS.read_edit_raw(P / "לעריכה" / "clip1.txt")["text"]
            ok("[" in raw, "הסוגריים נשארים בקובץ העריכה (כך רואים אחר כך איפה היה ספק)")
    set_settings(T, {})

    # שמירה: רשימת היתר של תיקיית השורטס
    say("\n 💾 שמירה — מה נכנס לתיקיית השורטס")
    P = T / "projects" / "תוכנה" / "2026-01-01_m1"
    set_settings(T, {"drive_on": False})       # בלי סימון "ממתין לגיבוי" (הקובץ שלו משותף לכל מצב בדיקה)
    # 28/10 — מד האיכות: "נמסר" עם מילה אחת שונה מהטקסט בקובץ → אחרי השמירה "תוקנו 1 מילים"
    import make_short_editor as ED
    ED.write_delivered(P, "clip1", "בדיקה אחת, שתיים שלוש ארבע חמש. שש שבע שמונה עשר.", "gemini")
    rc, out = run_ms(env, "save", P)
    try:
        q = json.load(open(P / "make_short.json", encoding="utf-8"))["clips"][0].get("quality") or {}
    except (OSError, ValueError):
        q = {}
    ok(q.get("changed") == 1 and q.get("src") == "gemini", "מד האיכות: השמירה רושמת כמה מילים תוקנו (1)", json.dumps(q))
    if ok(rc == 0, "השמירה עברה", out.strip().splitlines()[-1] if rc else ""):
        files = [f for f in export_dir.rglob("*") if f.is_file()]
        bad = [f.name for f in files if not (f.suffix == ".mp4" or f.name == "תיאור להעתקה.txt")]
        ok(files and not bad, "רק סרטונים ו«תיאור להעתקה.txt» (%d קבצים)" % len(files), ", ".join(bad[:5]))
        deep = [str(f.relative_to(export_dir)) for f in files if len(f.relative_to(export_dir).parts) != 4]
        ok(files and not deep, "מבנה כרטיס 16: <הרב>/<הסדרה>/<כותרת>/<קובץ>", ", ".join(deep[:3]))
        ok(not (T / "shorts_root").exists() or not any((T / "shorts_root").rglob("*.mp4")),
           "בבדיקה — לא נכתב לתיקיית השורטס \"האמיתית\" (רק לתיקיית הבדיקה)")

    # ויתור + שחזור
    rc, out = run_ms(env, "drop", P, "clip1")
    ok(rc == 0, "ויתור על קליף (לא שמור)")
    rc, out = run_ms(env, "restore", P, "clip1")
    ok(rc == 0, "שחזור הקליף", out.strip().splitlines()[-1] if rc and out.strip() else "")

    if quick:
        return
    # מוזיקה כבויה + עוצמה לקליף: לא קורס (הדף ממילא מסתיר את המחוון כשאין מנגינה)
    P2 = T / "projects" / "תוכנה" / "2026-01-01_m2"
    rc, out = run_ms(env, "restyle", P2, "clip1", "--db=3")
    ok(rc == 0, "קליף בלי מוזיקה + שינוי עוצמה — לא קורס", out.strip().splitlines()[-1] if rc else "")
    # 4.1.3: שמירה באמצע בנייה מחדש מזיזה את clip1 → clip1_<כותרת>; הבנייה מוצאת אותה ולא נופלת
    code = r'''
import json, os, shutil, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); P = Path(sys.argv[2])
import make_short as MS
real = shutil.copyfile
def hook(src, dst, *a, **k):
    r = real(src, dst, *a, **k)
    if str(dst).replace("\\", "/").endswith("work/swap/clip1.mp4"):
        d = [x for x in (P / "shorts").glob("clip1*") if x.is_dir()][0]
        d.rename(P / "shorts" / "clip1_כותרת אחרי שמירה")        # בדיוק מה ש"💾 שמור" עושה באמצע
    return r
shutil.copyfile = hook
try:
    rc = MS.restyle(str(P), "clip1", vol=4)
except Exception as e:
    print("ERR", type(e).__name__, e); sys.exit(0)
shutil.copyfile = real
d = P / "shorts" / "clip1_כותרת אחרי שמירה"
print("OK" if (d / "video.mp4").exists() or list(d.glob("*.mp4")) else "NOVIDEO", rc)
for x in (P / "shorts").glob("clip1_כותרת אחרי שמירה"):     # מחזירים לשם הטיוטה לבדיקות הבאות
    x.rename(P / "shorts" / "clip1")
'''
    r = subprocess.run([PY, "-c", code, str(HERE), str(P2)], env=env, capture_output=True, text=True, errors="replace",
                       timeout=300, cwd=str(P2))
    ok((r.stdout.strip().splitlines() or [""])[-1].startswith("OK"), "שמירה באמצע בנייה מחדש (clip1 → clip1_כותרת): הבנייה מוצאת את התיקייה החדשה ולא נופלת",
       (r.stdout + r.stderr).strip()[-300:])
    one_color_checks(T, env)
    style_checks(T, env)


def one_color(P):
    """28/10 (שורט "D9"): צבע אחד לכל הקליף — אף אירוע Dialogue לא נושא תגית צבע משלו (\\c / \\1c),
    ויש סגנון הדגשה אחד. (צבע, תקלה או "")."""
    a = (P / "work" / "subtitles" / "clip1.ass").read_text(encoding="utf-8-sig")
    ev = [l for l in a.splitlines() if l.startswith("Dialogue:")]
    tagged = [l for l in ev if re.search(r"\\1?c&H", l)]
    his = re.findall(r"^Style: Hi,[^,]*,\d+,&H00([0-9A-Fa-f]{6})", a, re.M)
    rgb = (his[0][4:6] + his[0][2:4] + his[0][0:2]).upper() if len(his) == 1 else ""
    bad = ("%d כתוביות עם צבע משלהן: %s" % (len(tagged), tagged[0][-60:])) if tagged else \
          ("" if rgb else "%d סגנונות הדגשה" % len(his))
    return rgb, bad


def one_color_checks(T, env):
    import make_short_settings as SETM
    say("\n 🎨 צבע אחד בכל הקליף (כתובית עם אותיות לועזיות, אחרי שינוי צבע ותיקון טקסט)")
    words = ["תיקחו", "D9", "בדיקה", "אחת", "שתיים", "שלוש", "ארבע", "חמש", "שש", "שבע"]
    P = make_fixture(T, "color1", words, "תיקחו D9, בדיקה אחת שתיים שלוש. ארבע חמש שש שבע.")
    # 31/10: מאז 30/10 🎲 בוחר גם מרקר/ריחוף לפי נתיב הקליף (תיקייה זמנית — כל ריצה אחרת) → הבדיקה הייתה תלויה במזל.
    # כאן נבדק צבע קריוקי אחד: מרקר, ריחוף ו"ללא צבע" מושבתים
    sl = SETM.style_lists(dict(SETM.DEFAULTS))
    set_settings(T, {"music_on": False, "colors_off": sl["marker"] + sl["float"] + sl["box"] + ["PLAIN"]})
    rc, out = run_ms(env, "finish", P)
    if not ok(rc == 0, "סיום עם \"D9\" בכתובית הראשונה", out.strip().splitlines()[-1] if rc else ""):
        return
    rgb0, bad = one_color(P)
    ok(not bad, "אחרי הסיום — צבע אחד (#%s)" % rgb0, bad)
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=B14EFF")
    rgb1, bad = one_color(P)
    ok(rc == 0 and not bad and rgb1 == "B14EFF", "אחרי שינוי צבע — צבע אחד, הצבע החדש", bad or rgb1)
    sys.path.insert(0, str(HERE))
    import make_short as MS
    e = P / "לעריכה" / "clip1.txt"
    raw = MS.read_edit_raw(e)
    f, _, _ = MS.parse_edit(e)
    st = json.loads((P / MS.STATE).read_text(encoding="utf-8"))
    MS.write_edit(e, st["clips"][0], P, f["כותרת"], f["תיאור"], f["תגיות"],
                  raw["text"].replace("בדיקה", "בדיקות"), raw["yt"])
    rc, out = run_ms(env, "finish", P, "--clips=clip1")
    rgb2, bad = one_color(P)
    ok(rc == 0 and not bad and rgb2 == "B14EFF", "אחרי תיקון טקסט — צבע אחד, אותו צבע", bad or rgb2)

    # "ללא צבע" + המתג דולק: המילים המסומנות — היחידות בצבע, לכל אורך הכתובית, בלי הגדלה; התצוגה בדף = הצריבה
    say("\n 🎨 \"ללא צבע\": המילים המסומנות נצבעות (ולא מוגדלות), והתצוגה בדף זהה לצריבה")
    r = subprocess.run([PY, "-c", "import sys,json;sys.path.insert(0,sys.argv[1]);import make_short as MS;"
                        "MS.emph_set(sys.argv[2],'clip1',on=True,picks=[{'w':'שלוש'},{'w':'שש'}]);"
                        "print(json.dumps(MS.sub_lines(sys.argv[2],'clip1','on'),ensure_ascii=False))", str(HERE), str(P)],
                       env=env, capture_output=True, text=True, errors="replace")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=PLAIN")
    a = (P / "work" / "subtitles" / "clip1.ass").read_text(encoding="utf-8-sig")
    ev = [l for l in a.splitlines() if l.startswith("Dialogue:")]
    his = [l for l in ev if ",Hi," in l]
    ok(rc == 0 and "; ys-style: plain" in a, "נצרב בסגנון \"ללא צבע\"", out.strip().splitlines()[-1] if rc else "")
    ok(not [l for l in ev if re.search(r"\\1?c&H|\\fs\d", l)], "בלי תגיות צבע/גודל בתוך שורה (עברית לא מתהפכת, אין הגדלה)")
    ok(len(his) == 2, "בדיוק שתי מילים צבועות (שתי המסומנות), לא הדגשה רצה", "%d אירועי Hi" % len(his))
    try:
        rr = subprocess.run([PY, "-c", "import sys,json;sys.path.insert(0,sys.argv[1]);import make_short as MS;"
                             "print(json.dumps(MS.sub_lines(sys.argv[2],'clip1'),ensure_ascii=False))", str(HERE), str(P)],
                            env=env, capture_output=True, text=True, errors="replace")
        sl = json.loads(rr.stdout.strip().splitlines()[-1])
        m = re.search(r"^Style: Hi,[^,]*,\d+,&H00([0-9A-Fa-f]{6})", a, re.M)
        burned = (m.group(1)[4:6] + m.group(1)[2:4] + m.group(1)[0:2]).upper() if m else ""
        nbig = sum(len(l.get("big") or []) for l in sl["lines"])
        ok(sl["rgb"] == "PLAIN" and sl["em_rgb"] == burned and nbig == len(his),
           "התצוגה בדף: ללא צבע, אותו צבע למילים (#%s) ואותן %d מילים" % (burned, nbig), json.dumps(sl)[:200])
        ok(burned in SETM.DEFAULT_COLORS.values(), "צבע המילים — אחד מצבעי האקראי", burned)
    except (ValueError, IndexError) as e:
        ok(False, "התצוגה בדף לא נקראה", (r.stderr + rr.stderr)[-300:] or str(e))
    set_settings(T, {})


def style_checks(T, env):
    """30/10 — "מרקר" ו"ריחוף מילים" (karaoke_styles.py): צריבה אמיתית, שקיפות, טקסט כהה בצהוב/מנטה, הדגשה בצבע במקום
    הגדלה, restyle --subs, אזהרת קצב, בורר/הגדרות, ו-fallback נקי כשאין מדידה."""
    import make_short_settings as SETM
    import karaoke_styles as KS
    say("\n 🖍️🪶 מרקר ו\"ריחוף מילים\"")
    a_of = lambda P: (P / "work" / "subtitles" / "clip1.ass").read_text(encoding="utf-8-sig")
    ev_of = lambda a: [l for l in a.splitlines() if l.startswith("Dialogue:")]
    P = make_fixture(T, "style1")
    set_settings(T, {"music_on": False, "marker_opacity": 50})
    rc, out = run_ms(env, "finish", P)
    if not ok(rc == 0, "סיום רגיל (טורקיז) לפני החלפת סגנון", out.strip().splitlines()[-1] if rc else ""):
        return
    n = len(WORDS)
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=MARKER:74202C")
    a = a_of(P)
    ev = ev_of(a)
    boxes = [l for l in ev if "\\p1" in l]
    ok(rc == 0 and "; ys-style: marker" in a and "; ys-rgb: 74202C" in a and "; ys-opacity: 50" in a,
       "מרקר בבורדו נצרב (הסגנון, הצבע והשקיפות נשמרים בקובץ ה-ass)", out.strip().splitlines()[-1] if rc else "")
    ok(len(boxes) == n and all("\\1c&H2C2074&" in l and "\\1a&H80&" in l for l in boxes),
       "תיבה לכל מילה (%d), בצבע הבורדו ובשקיפות 50%% (alpha 80)" % n, "%d תיבות" % len(boxes))
    ok(all("YSMarkerBold,103," in a for _ in [0]) and "\\p1" in boxes[0] and "\\an7" in boxes[0] and "\\clip" in boxes[0],
       "גופן Open Sans Hebrew Bold בגודל 103, ציור \\an7 עם \\clip רץ")
    ok(not [l for l in ev if "\\p1" not in l and re.search(r"\\1?c&H|\\fs\d", l)], "בכתוביות עצמן אין תגית צבע/גודל באמצע שורה")
    ok(" Dark," not in "\n".join(ev), "בבורדו הטקסט נשאר לבן (בלי שכבת טקסט כהה)")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=MARKER:FFD300")
    a = a_of(P)
    dark = [l for l in ev_of(a) if ",Dark," in l]
    ok(rc == 0 and len(dark) == n and all("\\clip(" in l for l in dark), "צהוב: שכבת טקסט כהה חתוכה לכל מילה (%d)" % n, "%d" % len(dark))
    ok("&H00111111" in a and "; ys-rgb: FFD300" in a, "הטקסט שעל הצהוב כהה (111111)")
    rc, out = run_ms(env, "restyle", P, "clip1", "--subs")
    ok(rc == 0 and "; ys-style: marker" in a_of(P) and "; ys-rgb: FFD300" in a_of(P),
       "restyle --subs שומר על מרקר + הצבע", out.strip().splitlines()[-1] if rc else "")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=MARKER:7CF5C4")
    ok(rc == 0 and len([l for l in ev_of(a_of(P)) if ",Dark," in l]) == n, "מנטה: גם כאן טקסט כהה")
    ok(not (set(KS.MARKER_COLORS) & set(SETM.DEFAULT_COLORS.values())),
       "🚨 צבעי המרקר לא לקוחים מרשימת הצבעים של הקריוקי (HIGHLIGHT_RGB)")
    ok("FF3B84" not in KS.MARKER_COLORS and len(KS.MARKER_COLORS) == 8, "שמונה צבעי מרקר, בלי ורוד")

    rc, out = run_ms(env, "restyle", P, "clip1", "--color=FLOAT")
    a = a_of(P)
    ev = ev_of(a)
    mv = [l for l in ev if "\\move(" in l]
    ok(rc == 0 and "; ys-style: float" in a and len(mv) == n and "\\p1" not in a and "YSFloatHeebo,136," in a,
       "ריחוף נצרב: מילה לכל אירוע (%d), Heebo ExtraBold 136" % len(mv), out.strip().splitlines()[-1] if rc else "")
    ok(not [l for l in ev if re.search(r"\\1c&H|\\fs\d", l)], "ריחוף בלי הדגשה: אין צבע ואין הגדלה")
    ends = {l.split(",")[2] for l in mv}
    ok(len(ends) == len(set(l.split(",")[2] for l in ev_of(a))) and len(ends) <= 3, "כל מילות הכתובית נעלמות יחד (זמן סיום אחד לכתובית)")
    rate = json.loads(subprocess.run([PY, "-c", "import sys,json;sys.path.insert(0,sys.argv[1]);import make_short as MS;"
                                      "print(json.dumps([MS.clip_rate(sys.argv[2],'clip1'),MS.sub_lines(sys.argv[2],'clip1')['rate'],MS.sub_lines(sys.argv[2],'clip1')['rgb']]))",
                                      str(HERE), str(P)], env=env, capture_output=True, text=True, errors="replace").stdout.strip().splitlines()[-1])
    ok(rate[0] == rate[1] and rate[0] > KS.FLOAT_MAX_WPS and rate[2] == "FLOAT",
       "קצב הדיבור בקליף (%.1f מילים בשנייה) מעל %.0f — הדף יזהיר; הבחירה נקראת בחזרה: %s" % (rate[0], KS.FLOAT_MAX_WPS, rate[2]))
    r = subprocess.run([PY, "-c", "import sys;sys.path.insert(0,sys.argv[1]);import make_short as MS;"
                        "MS.emph_set(sys.argv[2],'clip1',on=True,picks=[{'w':'שלוש'},{'w':'שש'}])", str(HERE), str(P)],
                       env=env, capture_output=True, text=True, errors="replace")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=FLOAT:1AC8A8")
    a = a_of(P)
    col = [l for l in ev_of(a) if "\\1c&HA8C81A&" in l]
    ok(rc == 0 and len(col) == 2 and not re.search(r"\\fs\d", a), "הדגשה בצבע: בדיוק שתי המילים המסומנות צבועות — ובלי הגדלה (צבע במקום גודל)",
       "%d צבועות" % len(col))
    ok("; ys-rgb: 1AC8A8" in a, "צבע ההדגשה נשמר בקובץ")

    # הגדרות / בורר
    S = SETM
    ok(S.clean("sub_color", "marker:10206e") == "MARKER:10206E" and S.clean("sub_color", "float") == "FLOAT"
       and S.clean("sub_color", "FLOAT:ffe600") == "FLOAT:FFE600", "ההגדרה \"צבע הכתוביות\" מקבלת מרקר/ריחוף")
    bad = 0
    for v in ("MARKER:12345", "FLOAT:GGGGGG", "FLOAT:", "marker:zz"):
        try:
            S.clean("sub_color", v)
        except ValueError:
            bad += 1
    ok(bad == 4 and S.clean("sub_color", "marker:C2185B") == "MARKER:C2185B" and S.clean("sub_color", "FLOAT:ff7a00") == "FLOAT:FF7A00",
       "בחירה עם צבע hex חופשי (שלא ברשימה) מתקבלת; hex שבור נדחה")

    # 30/10 (תוספת): צבעים ניתנים להוספה/שינוי/הסרה, טקסט אוטומטי לפי ניגודיות + עקיפה ידנית, שקיפות גם עליהם
    say("\n 🎨 צבעים שהוא מוסיף/משנה: מרקר + ריחוף")
    ok(KS.dark_text("FFD300") and KS.dark_text("7CF5C4") and not any(KS.dark_text(c) for c in ("10206E", "1A1A1A", "74202C", "0F5132", "4B2A7A", "0B5D5A")),
       "טקסט אוטומטי לפי ניגודיות: צהוב ומנטה כהה, כל השאר לבן")
    ok(KS.dark_text("F5F5F5") and not KS.dark_text("C2185B") and KS.dark_text("C2185B", "dark") and not KS.dark_text("FFD300", "light"),
       "צבע חדש בהיר → טקסט כהה, כהה → לבן; עקיפה ידנית גוברת")
    pal = S.clean("marker_palette", ["#c2185b", "F5F5F5", "zz", "C2185B"] + list(KS.MARKER_COLORS)[:2])
    ok(pal[:2] == ["C2185B", "F5F5F5"] and len(pal) == 4, "רשימת מרקר: הוספה (כפילויות וזבל נזרקים)")
    ok(S.clean("float_palette", ["ff7a00"]) == ["FF7A00"] and S.clean("marker_text", {"#10206e": "dark", "x": "dark", "74202C": "?"}) == {"10206E": "dark"},
       "רשימת ההדגשה ועקיפת הטקסט נשמרות רק תקינות")
    try:
        S.clean("float_palette", [])
        ok(False, "אי אפשר לרוקן את רשימת ההדגשה")
    except ValueError:
        ok(True, "אי אפשר לרוקן את רשימת ההדגשה")
    set_settings(T, {"music_on": False, "marker_opacity": 0, "marker_palette": ["C2185B", "F5F5F5", "10206E"],
                     "float_palette": ["FF7A00"], "marker_text": {"10206E": "dark"}})
    for color, want_dark, alpha in (("MARKER:C2185B", False, "&HFF&"), ("MARKER:F5F5F5", True, "&HFF&"), ("MARKER:10206E", True, "&HFF&")):
        rc, out = run_ms(env, "restyle", P, "clip1", "--color=" + color)
        a = a_of(P)
        nd = len([l for l in ev_of(a) if ",Dark," in l])
        bx = [l for l in ev_of(a) if "\\p1" in l]
        ok(rc == 0 and (nd == n) == want_dark and bx and all("\\1a" + alpha in l for l in bx),
           "%s: טקסט %s, שקיפות 0 → alpha FF" % (color, "כהה" if want_dark else "לבן"), out.strip().splitlines()[-1] if rc else "")
        ok(("; ys-text: dark" in a) == want_dark, "הסגנון נשמר בקובץ (ys-text)")
    set_settings(T, {"music_on": False, "marker_opacity": 100})
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=MARKER:C2185B")
    ok(rc == 0 and all("\\1a&H00&" in l for l in ev_of(a_of(P)) if "\\p1" in l), "שקיפות 100 על צבע חדש → תיבה מלאה")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=FLOAT:FF7A00")
    a = a_of(P)
    ok(rc == 0 and len([l for l in ev_of(a) if "\\1c&H007AFF&" in l]) == 2 and "; ys-rgb: FF7A00" in a,
       "ריחוף עם צבע הדגשה חדש (FF7A00): שתי המסומנות בצבע החדש")
    rc, out = run_ms(env, "restyle", P, "clip1", "--subs")
    ok(rc == 0 and "; ys-rgb: FF7A00" in a_of(P), "restyle --subs שומר גם צבע חדש")
    cl = subprocess.run([PY, str(HERE / "karaoke_ass.py"), str(P / "work" / "subtitles" / "clip1_words.json"), str(T / "cli.ass"),
                         "--duration=4", "--mode=marker", "--rgb=#C2185B", "--text=dark", "--opacity=40"], env=env, capture_output=True,
                        text=True, errors="replace", cwd=str(HERE))
    t = (T / "cli.ass").read_text(encoding="utf-8-sig") if (T / "cli.ass").exists() else ""
    ok(cl.returncode == 0 and "; ys-rgb: C2185B" in t and "; ys-text: dark" in t and "; ys-opacity: 40" in t,
       "קלוד (שורת פקודה): --rgb=#hex חופשי, --text, --opacity", (cl.stderr or cl.stdout)[-150:])
    set_settings(T, {"music_on": False, "marker_opacity": 50})
    ok(S.clean("marker_opacity", 150) == 100 and S.clean("marker_opacity", -5) == 0 and S.DEFAULTS["marker_opacity"] == 94,
       "שקיפות המרקר: 0–100, ברירת מחדל 94")
    # 31/10 (כרטיס 23): "מושבת" אחד לכל הסגנונות (colors_off) — אפשר להשבית הכול; מה שמושבת לא באקראי
    ok(S.clean("colors_off", ["#74202c", "marker:74202c", "zz"]) == ["74202C", "MARKER:74202C"], "השבתה: צבע קריוקי ומרקר נפרדים")
    # 30/10 (הצעתו): אקראי = קודם סגנון (קריוקי / מרקר / ריחוף, שווה בשווה) ואז צבע בתוכו
    base = dict(S.DEFAULTS, colors_off=[])
    g = S.random_groups(base)
    ok(sorted(g) == ["box", "float", "karaoke", "marker"] and len(g["marker"]) == 8 and "FLOAT" in g["float"] and len(g["box"]) == 4,
       "אקראי כולל את ארבעת הסגנונות וכל צבעיהם")
    picks = [S.parse_choice(S.random_pick(h, g))[0] for h in range(400)]
    cnt = {k: picks.count(k) for k in ("karaoke", "plain", "marker", "float", "box")}
    ok(cnt["marker"] == 100 and cnt["float"] == 100 and cnt["box"] == 100 and cnt["karaoke"] + cnt["plain"] == 100,
       "חלוקה שווה בין ארבעת הסגנונות (%s)" % cnt)
    ok(not any("MARKER" in x for x in S.random_pool(dict(base, colors_off=["MARKER:" + c for c in KS.MARKER_COLORS]))[0]),
       "צבע מרקר מושבת לא נבחר")
    ok(all(re.fullmatch(r"[0-9A-F]{6}", x) for x in S.em_pool(base)), "צבעי \"ללא צבע\" נשארים צבעים אמיתיים בלבד (בלי מרקר/ריחוף)")
    ok(S.clean("colors_off", ["marker:10206e", "FLOAT", "xx"]) == ["MARKER:10206E", "FLOAT"], "השבתה של מרקר/ריחוף נשמרת")
    sl = S.style_lists(dict(base, custom_colors=["ff7a00"]))
    ok("FF7A00" in sl["karaoke"] and "FF7A00" in S.random_groups(dict(base, custom_colors=["FF7A00"]))["karaoke"]
       and "FF7A00" not in S.random_groups(dict(base, custom_colors=["FF7A00"], colors_off=["FF7A00"])).get("karaoke", []),
       "צבע קריוקי שהוסיף: פעיל = גם באקראי, מושבת = לא")
    ok([S.parse_choice(x)[0] for x in ("1AC8A8", "PLAIN", "MARKER:10206E", "FLOAT", "FLOAT:1AC8A8", "bad")]
       == ["karaoke", "plain", "marker", "float", "float", None], "פירוק הבחירה לקליף")
    ok(S.state()["float_max_wps"] == 2.0 and "10206E" in S.state()["marker_colors"], "הדף מקבל את הצבעים ואת סף הקצב")

    # אקראי + קליף מהיר מדי לריחוף (2.8 מילים בשנייה): לא מקבל ריחוף באקראי, כן מרקר/קריוקי
    import make_short as MS2
    sd = P / "work" / "subtitles"
    got = set()
    for i in range(36):
        shutil.copy(sd / "clip1_words.json", sd / ("zz%d_words.json" % i))
        got.add(SETM.parse_choice(MS2.clip_choice(dict(base, sub_color="random"), str(sd / ("zz%d.ass" % i))))[0])
        (sd / ("zz%d_words.json" % i)).unlink()
    ok("float" not in got and "marker" in got and "karaoke" in got, "אקראי על קליף מהיר: בלי ריחוף, כן מרקר וקריוקי (%s)" % ",".join(sorted(map(str, got))))
    rc, out = run_ms(env, "preview", P, "clip1", "subs", "MARKER:C2185B")
    fl = [l[5:] for l in out.splitlines() if l.startswith("FILE=")]
    ok(rc == 0 and fl and Path(fl[0]).exists() and Path(fl[0]).stat().st_size > 20000, "תצוגה אמיתית (libass) של מרקר נוצרת", out.strip().splitlines()[-1] if rc else "")
    rc, out = run_ms(env, "preview", P, "clip1", "subs", "FLOAT:1AC8A8", "--emph=on")
    fl = [l[5:] for l in out.splitlines() if l.startswith("FILE=")]
    ok(rc == 0 and fl and Path(fl[0]).exists(), "תצוגה אמיתית של ריחוף עם הדגשה נוצרת", out.strip().splitlines()[-1] if rc else "")

    # fallback: אין מדידה → טקסט בלי תיבות/תנועה, לא קורס
    code = r'''
import sys, json
sys.path.insert(0, sys.argv[1])
import karaoke_ass as KA
KA.measure_words = lambda *a, **k: None
for m, rgb in (("marker", "10206E"), ("float", "1AC8A8")):
    KA.build(sys.argv[2], sys.argv[3] + m + ".ass", 4.0, "teal", mode=m, rgb=rgb, emph_idx={0, 1})
    t = open(sys.argv[3] + m + ".ass", encoding="utf-8-sig").read()
    ev = [l for l in t.splitlines() if l.startswith("Dialogue:")]
    print("RES", m, len(ev), "\\p1" in t, "\\move" in t)
'''
    wj = P / "work" / "subtitles" / "clip1_words.json"
    r = subprocess.run([PY, "-c", code, str(HERE), str(wj), str(T / "fb_")], env=env, capture_output=True, text=True, errors="replace")
    rows = [x.split()[1:] for x in r.stdout.splitlines() if x.startswith("RES ")]
    ok(r.returncode == 0 and len(rows) == 2 and all(int(x[1]) >= 1 and x[2] == "False" and x[3] == "False" for x in rows),
       "כתובית שלא נמדדה → טקסט נקי בלי תיבה ובלי תנועה (fallback)", (r.stderr or r.stdout)[-200:])
    # 31/10: { } בטקסט הכתובית פתחו בלוק עיצוב ב-libass והמילה נעלמה — כל הסגנונות, צריבה ותצוגה
    PB = make_fixture(T, "braces", words=["בדיקה", "{של}", "סוגריים", "אחד", "שניים"])
    (PB / "work" / "subtitles" / "clip1_words.json").write_text(json.dumps({"words": [
        {"word": w, "start": round(0.2 + i * 0.4, 2), "end": round(0.2 + i * 0.4 + 0.35, 2)}
        for i, w in enumerate(["בדיקה", "{של}", "סוגריים", "אחד", "שניים"])]}, ensure_ascii=False), encoding="utf-8")
    code = r'''
import sys, re
sys.path.insert(0, sys.argv[1])
import karaoke_ass as KA
for m, rgb in (("karaoke", None), ("marker", "10206E"), ("float", "1AC8A8"), ("box", "1AC8A8")):
    KA.build(sys.argv[2], sys.argv[3] + m + ".ass", 4.0, "teal", mode=m, rgb=rgb)
    t = open(sys.argv[3] + m + ".ass", encoding="utf-8-sig").read()
    body = "".join(re.sub(r"\{[^}]*\}", "", l.split(",,", 1)[1]) for l in t.splitlines() if l.startswith("Dialogue:") and ",,0,0,0,," in l)
    print("RES", m, all(w in body for w in ("בדיקה", "סוגריים", "אחד")), "｛של｝" in body)
'''
    r = subprocess.run([PY, "-c", code, str(HERE), str(PB / "work" / "subtitles" / "clip1_words.json"), str(T / "br_")],
                       env=env, capture_output=True, text=True, errors="replace")
    rows = [x.split()[1:] for x in r.stdout.splitlines() if x.startswith("RES ")]
    ok(r.returncode == 0 and len(rows) == 4 and all(x[1] == "True" and x[2] == "True" for x in rows),
       "מילה עם { } בתוכה מופיעה בכל הסגנונות (קריוקי / מרקר / ריחוף / קופסה)", (r.stderr or r.stdout)[-300:])
    rc, out = run_ms(env, "preview", PB, "clip1", "subs", "MARKER:C2185B")
    ass = sorted((PB / "work" / "preview").glob("clip1_subs_*.ass"))
    txt = ass[-1].read_text(encoding="utf-8-sig") if ass else ""
    ok(rc == 0 and "｛של｝" in txt and "{של}" not in txt, "גם בתצוגה המקדימה (/api/sub_preview, אותו קוד) — בלי { } גולמיים",
       out.strip().splitlines()[-1] if rc else "")

    # 31/10 (כרטיס 24): צל הריחוף נשלט מההגדרות — ברירת מחדל זהה לגמרי למה שהיה; "קופסה" — סגנון חדש
    say("\n 🪶 צל הריחוף  ·  🔲 קופסה")
    ok(S.float_shadow(dict(S.DEFAULTS)) is None and S.float_shadow(dict(S.DEFAULTS, float_shadow_opacity=70)) == (True, 70, 3)
       and S.float_shadow(dict(S.DEFAULTS, float_shadow=False))[0] is False, "הגדרות צל: ברירת מחדל = None (המראה שהיה), שינוי = ערכים")
    ok(S.clean("float_shadow_opacity", 500) == 100 and S.clean("float_shadow_size", 99) == 12 and S.clean("float_shadow_size", -3) == 0
       and S.clean("box_opacity", -1) == 0 and S.clean("box_color", "#ff7a00") == "FF7A00" and S.DEFAULTS["box_opacity"] == 60
       and S.DEFAULTS["box_color"] == "000000" and S.DEFAULTS["float_shadow"] is True, "טווחי ההגדרות וברירות המחדל של הצל והקופסה")
    try:
        S.clean("box_color", "red")
        ok(False, "צבע קופסה לא תקין נדחה")
    except ValueError:
        ok(True, "צבע קופסה לא תקין נדחה")
    ok(MS2._style_sig(dict(S.DEFAULTS), "FLOAT") == [] and MS2._style_sig(dict(S.DEFAULTS), "MARKER:10206E") == []
       and MS2._style_sig(dict(S.DEFAULTS, float_shadow_size=6), "FLOAT:1AC8A8") == [[True, 50, 6]] and MS2._style_sig(dict(S.DEFAULTS), "BOX") == ["000000", 60]
       and MS2._style_sig(dict(S.DEFAULTS, float_shadow_size=6), "BOX") == ["000000", 60],
       "מפתח הצריבה: צל/קופסה נכנסים רק אצל קליף בסגנון הזה (ברירת מחדל = המפתח של לפני)")
    code = r'''
import sys
sys.path.insert(0, sys.argv[1])
import karaoke_ass as KA
w, o = sys.argv[2], sys.argv[3]
KA.build(w, o + "f0.ass", 4.0, "teal", mode="float")
KA.build(w, o + "f1.ass", 4.0, "teal", mode="float", shadow=(True, 50, 3))
KA.build(w, o + "f2.ass", 4.0, "teal", mode="float", shadow=(True, 80, 6))
KA.build(w, o + "f3.ass", 4.0, "teal", mode="float", shadow=(False, 50, 3))
'''
    wj = P / "work" / "subtitles" / "clip1_words.json"
    r = subprocess.run([PY, "-c", code, str(HERE), str(wj), str(T / "sh_")], env=env, capture_output=True, text=True, errors="replace")
    f = [(T / ("sh_f%d.ass" % i)).read_text(encoding="utf-8-sig") if (T / ("sh_f%d.ass" % i)).exists() else "" for i in range(4)]
    ok(r.returncode == 0 and f[0] == f[1] and f[0] != "", "🚨 צל בברירת מחדל = קובץ ה-ass זהה בבייטים למה שהיה", (r.stderr or "")[-200:])
    soft = [l for l in f[2].splitlines() if "\\1c&H000000&" in l]
    ok(len(soft) == n and "\\blur4.8" in soft[0] and re.search(r"^Style: Base,YSFloatHeebo,136,.*,0,0,0,0,100,100,0,0,1,0,0,2", f[2], re.M)
       and ",3,2,60" not in f[2].split("[Events]")[0], "צל רך: שכבה שחורה מטושטשת לכל מילה (%d) ובלי צל קשיח של הסגנון" % n, "%d" % len(soft))
    ok("\\1a&H33&" in soft[0], "שקיפות 80% → alpha 33 בשכבת הצל")
    ok(not [l for l in f[3].splitlines() if "\\1c&H000000&" in l] and re.search(r"^Style: Base,YSFloatHeebo,136,.*,0,0,0,0,100,100,0,0,1,0,0,2", f[3], re.M),
       "צל כבוי: אין שכבת צל ואין צל קשיח")
    # קופסה
    set_settings(T, {"music_on": False})
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=BOX:1AC8A8")
    a = a_of(P)
    ev = ev_of(a)
    boxes = [l for l in ev if "\\p1" in l]
    hi = [l for l in ev if ",Hi," in l]
    ok(rc == 0 and "; ys-style: box" in a and "; ys-rgb: 1AC8A8" in a and "; ys-opacity: 60" in a and "; ys-boxcolor: 000000" in a,
       "קופסה נצרבת (סגנון, צבע המילה, שקיפות 60 וצבע התיבה נשמרים בקובץ)", out.strip().splitlines()[-1] if rc else "")
    nch = len({l.split(",")[1] for l in boxes})
    ok(boxes and len(boxes) == nch and all("\\1c&H000000&" in l and "\\1a&H66&" in l and "\\clip" not in l and "\\move" not in l and "\\t(" not in l for l in boxes),
       "תיבה אחת לכל כתובית (%d), שחורה ב-60%%, קבועה: בלי תנועה ובלי \\clip" % len(boxes))
    ok(len(hi) == n and all("\\clip(" in l and "\\1c" not in l for l in hi) and "&H00A8C81A" in a, "המילה שנאמרת: שכבת טקסט חתוכה בצבע (%d), בלי תגית צבע בשורה" % len(hi))
    ok("YSMarkerBold,103," in a and not re.search(r"\\fs\d", a), "גופן המרקר, בלי הגדלה")
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=MARKER:10206E")
    mk_top = [float(re.search(r"\\pos\([\d.]+,([\d.]+)\)", l).group(1)) for l in ev_of(a_of(P)) if "\\p1" in l]
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=BOX:1AC8A8")
    bx_top = [float(re.search(r"\\pos\([\d.]+,([\d.]+)\)", l).group(1)) for l in ev_of(a_of(P)) if "\\p1" in l]
    ok(mk_top and bx_top and abs(min(mk_top) - min(bx_top)) < 40 and max(bx_top) < 1700, "הקופסה באותו גובה כמו המרקר (התיבה העליונה: %d / %d)" % (min(bx_top), min(mk_top)))
    set_settings(T, {"music_on": False, "box_color": "1A1A8C", "box_opacity": 100})
    rc, out = run_ms(env, "restyle", P, "clip1", "--color=BOX:FFE600")
    a = a_of(P)
    ok(rc == 0 and all("\\1c&H8C1A1A&" in l and "\\1a&H00&" in l for l in ev_of(a) if "\\p1" in l) and "; ys-rgb: FFE600" in a and "&H0000E6FF" in a,
       "הגדרות הקופסה (צבע, שקיפות) וצבע מילה אחר מחלחלים לצריבה")
    rc, out = run_ms(env, "restyle", P, "clip1", "--subs")
    ok(rc == 0 and "; ys-style: box" in a_of(P) and "; ys-rgb: FFE600" in a_of(P), "restyle --subs שומר על קופסה + הצבע")
    ok(MS2.clip_rgb("clip1", P) == "BOX:FFE600" and MS2.style_of("BOX:FFE600") == "box", "הבחירה נקראת בחזרה מהקובץ: BOX:RRGGBB")
    ok(SETM.parse_choice("box")[0] == "box" and SETM.parse_choice("BOX:ff7a00") == ("box", "FF7A00") and SETM.valid_choice("BOX:1AC8A8")
       and not SETM.valid_choice("BOX:12") and S.clean("sub_color", "box:ffe600") == "BOX:FFE600" and "קופסה" in SETM.choice_name("BOX"),
       "פירוק הבחירה BOX / BOX:RRGGBB, הגדרת ברירת מחדל ושם בעברית")
    ok(S.clean("colors_off", ["box:1ac8a8", "BOX"])[0] == "BOX:1AC8A8" and "BOX:1AC8A8" not in S.random_groups(dict(base, colors_off=["BOX:1AC8A8"]))["box"]
       and S.state()["box_colors"].get("1AC8A8") == "טורקיז", "קופסה ברשימת ההשבתה / אקראי / מצב הדף")
    # 1/11: styles_off — סגנון שלם מושבת מהאקראי (ביד נשאר), ברירת מחדל = כמו קודם
    b2 = dict(base, styles_off=[])
    ok(set(S.random_groups(b2)) == set(S.random_groups(base)) and S.DEFAULTS["styles_off"] == [], "styles_off ריק = אותו אקראי כמו קודם")
    ok(S.clean("styles_off", ["Marker", "zz", "box", "marker"]) == ["marker", "box"], "styles_off נשמר נקי, לפי הסדר הקבוע")
    g = S.random_groups(dict(base, styles_off=["marker", "float", "box"]))
    ok(set(g) == {"karaoke"}, "מרקר/ריחוף/קופסה מושבתים → רק קריוקי באקראי", sorted(g))
    g = S.random_groups(dict(base, styles_off=["plain"]))
    ok("PLAIN" not in g["karaoke"] and any(re.fullmatch("[0-9A-F]{6}", x) for x in g["karaoke"]) and "marker" in g, "plain מושבת מוציא רק את \"ללא צבע\"")
    g = S.random_groups(dict(base, styles_off=["karaoke"]))
    ok(g["karaoke"] == ["PLAIN"], "karaoke מושבת משאיר את \"ללא צבע\"")
    allx = list(S.STYLE_KEYS)
    pool, fb = S.random_pool(dict(base, styles_off=allx))
    ok(fb and pool == [S.DEFAULT_COLORS["teal"]], "כל הסגנונות מושבתים → נפילה לטורקיז")
    ok(S.parse_choice("MARKER:10206E")[0] == "marker" and S.valid_choice("MARKER:10206E"), "בחירה ביד של סגנון מושבת עדיין תקינה")
    rc, out = run_ms(env, "preview", P, "clip1", "subs", "BOX:1AC8A8")
    fl = [l[5:] for l in out.splitlines() if l.startswith("FILE=")]
    ok(rc == 0 and fl and Path(fl[0]).exists() and Path(fl[0]).stat().st_size > 20000, "תצוגה אמיתית (libass) של קופסה נוצרת", out.strip().splitlines()[-1] if rc else "")
    rc, out = run_ms(env, "preview", PB, "clip1", "subs", "BOX:1AC8A8")
    txt = "".join(x for x in (f.read_text(encoding="utf-8-sig") for f in (PB / "work" / "preview").glob("clip1_subs_*.ass")) if "; ys-style: box" in x)
    ok(rc == 0 and "; ys-style: box" in txt and "｛של｝" in txt and "{של}" not in txt, "קופסה בתצוגה המקדימה: בלי { } גולמיים")
    set_settings(T, {})


def app_checks(T, env):
    """הצירופים שבשרת עצמו (תור, צילום הגדרות, דילוג על תיקון, ויתור על קליף בתור, עדכון באמצע גיבוי) —
    בתהליך נפרד, עם הסביבה הזמנית (הייבוא של השרת קורא את משתני הסביבה)."""
    say("\n▶ השרת: תור, צילום הגדרות, ספקות, עדכון עצמי")
    code = r'''
import json, os, sys, time
sys.path.insert(0, sys.argv[1])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked in selftest"))
import make_short_app as A, make_short_settings as SET, make_short as MS
A.kick_queue = lambda: None          # שום עבודה אמיתית לא מתחילה מתוך הבדיקה
P = sys.argv[2]
# 1. צילום הגדרות: שינוי אחרי הלחיצה לא משנה עבודה שכבר בתור / שנקטעה
SET.update({"sub_color": "yellow"})
jid = A.enqueue("finish", ["finish", P], P, "t", kick=False)
q = next(x for x in A.BUILD_Q if x.get("job") == jid)
SET.update({"sub_color": "purple"})
chk(A.snapshot_values(q["settings"])["sub_color"] == "yellow", "עבודה בתור רצה עם ההגדרות שהיו כשלחץ (צהוב, לא הסגול שנבחר אחר כך)")
env = A.JOBS[jid].get("env") or {}
chk(env.get("MAKE_SHORT_SETTINGS") == q["settings"], "העבודה מקבלת את הצילום (MAKE_SHORT_SETTINGS)")
chk("MAKE_SHORT_SETTINGS_SNAP" in env, "והצילום נרשם ב-progress.json ל\"▶ המשך\"")
A.queue_edit({"id": q["id"], "action": "remove"})
# 2. דילוג על תיקון + הכנה בלי אינטרנט: רק הכנה מלאה צורבת
SET.update({"skip_text_check": True})
snap = A.settings_snapshot("t2")
qn = {"kind": "prepare", "settings": snap, "net_only_run": True}
chk(not A.wants_auto_finish(qn, {"ok": True, "cmd": ["prepare", "x", "--net-only"]}), "דילוג על תיקון + \"הכן בלי אינטרנט\": ההורדה לבדה לא צורבת")
chk(A.wants_auto_finish({"kind": "prepare", "settings": snap}, {"ok": True, "cmd": ["prepare", "x", "--local"]}),
    "דילוג על תיקון + \"▶ המשך בלי אינטרנט\": בסוף — טיוטה")
chk(not A.wants_auto_finish({"kind": "prepare", "settings": snap}, {"ok": False, "cmd": []}), "הכנה שנכשלה — לא צורבים")
SET.update({"skip_text_check": False})
snap0 = A.settings_snapshot("t3")
chk(not A.wants_auto_finish({"kind": "prepare", "settings": snap0}, {"ok": True, "cmd": []}), "ההגדרה כבויה — כמו תמיד (קודם תיקון)")
# auto_finish עצמו: מסמן "טקסט לא נבדק" ומכניס סיום לתור עם אותו צילום
jid2 = A.auto_finish(P, snap)
st = json.load(open(os.path.join(P, MS.STATE), encoding="utf-8"))
chk("clip1" in (st.get("text_unchecked") or []), "אחרי צריבה אוטומטית — הקליף מסומן \"⚠ טקסט לא נבדק\"")
q2 = next((x for x in A.BUILD_Q if x.get("job") == jid2), None)
chk(q2 is not None and q2["settings"] == snap, "הסיום האוטומטי בתור, עם ההגדרות של ההכנה")
if q2: A.queue_edit({"id": q2["id"], "action": "remove"})
# 28/10: באג 4 — כותרת בלי סדרה ("נושא | הרב X") עצרה את כל הטיוטה; עכשיו נבנית, והשמירה מבקשת את השם
st0 = json.load(open(os.path.join(P, MS.STATE), encoding="utf-8"))
st0["series"] = ""; json.dump(st0, open(os.path.join(P, MS.STATE), "w", encoding="utf-8"), ensure_ascii=False)
jid5 = A.auto_finish(P, snap)
chk(jid5 is not None, "דילוג על תיקון + אין שם סדרה → הטיוטה בכל זאת נבנית (רק השמירה תבקש את השם)")
for x in [x for x in A.BUILD_Q if x.get("project") == P and x["status"] == "waiting"]: A.queue_edit({"id": x["id"], "action": "remove"})
st0["series"] = st["series"]; json.dump(st0, open(os.path.join(P, MS.STATE), "w", encoding="utf-8"), ensure_ascii=False)
# 28/10: "אוטומטי עד הצריבה" — הצעות של Gemini (מדומות, בלי בקשה) נבנות לבד; הצעה שהציטוט שלה לא נמצא — לא
import make_short_pick as PICK
PP = os.path.join(os.path.dirname(P), "2026-01-02_auto-selftestAB")
os.makedirs(PP, exist_ok=True)
PICK.save(PP, {"kind": "lesson", "url": "https://youtu.be/selftestAB1", "dir": PP, "title": "בדיקה", "rabbi": "", "series": "",
               "lessons": [{"n": 1, "url": "https://youtu.be/selftestAB1", "title": "בדיקה"}], "seq": 2,
               "picks": [{"id": "p1", "lesson": 1, "pieces": "1:00-1:40", "title": "טוב", "emph_src": "gemini", "flags": [], "seconds": 40},
                         {"id": "p2", "lesson": 1, "pieces": "5:00-5:40", "title": "ציטוט חסר", "emph_src": "gemini", "bad": True,
                          "flags": ["ציטוט הפתיחה לא נמצא"], "seconds": 40}]})
SET.update({"auto_burn": False, "skip_text_check": False})
A.auto_burn_after_pick({"project": PP, "ok": True})
chk(not any(x.get("project") == PP for x in A.BUILD_Q), "\"אוטומטי עד הצריבה\" כבוי — שום דבר לא נבנה לבד (כמו תמיד)")
SET.update({"auto_burn": True})
A.auto_burn_after_pick({"project": PP, "ok": True})
qa = [x for x in A.BUILD_Q if x.get("project") == PP and x["status"] == "waiting"]
pk = PICK.load(PP)
chk(len(qa) == 1 and qa[0].get("auto_burn") and qa[0]["kind"] == "prepare", "דולק → הכנה בתור, מסומנת לצריבה אוטומטית")
chk(not pk["picks"][1].get("selected") and "ציטוט חסר" in pk.get("auto_note", ""),
    "הצעה שהציטוט שלה לא נמצא — לא נבנית, ומופיעה ברשימה")
chk(A.wants_auto_finish(dict(qa[0]) if qa else {"kind": "prepare"}, {"ok": True, "cmd": []}),
    "בסוף ההכנה — צריבה לבד, גם כש\"לדלג על תיקון הטקסט\" כבוי")
for x in qa: A.queue_edit({"id": x["id"], "action": "remove"})
SET.update({"auto_burn": False})
A.save_edits({"project": P, "rabbi": st["rabbi"], "series": st["series"], "text_ok": ["clip1"], "clips": []})
st = json.load(open(os.path.join(P, MS.STATE), encoding="utf-8"))
chk("clip1" not in (st.get("text_unchecked") or []), "תיקן/אישר את הטקסט → הסימון יורד")
# 3. ויתור על קליף שיש לו עבודה בתור
jid3 = A.enqueue("swap", ["swap", P, "clip1", "--mode=swap"], P, "t", kick=False, clip="clip1")
n = A.drop_clip_jobs(P, "clip1")
chk(n == 1 and not any(x.get("job") == jid3 for x in A.BUILD_Q), "ויתור על קליף: העבודות שחיכו לו יוצאות מהתור")
fake = A.start_job("restyle", ["true"], P, "t", extra={"clip": "clip1"}, deferred=True)
A.JOBS[fake]["launched"] = True
try:
    A.drop_clip_jobs(P, "clip1"); chk(False, "ויתור על קליף שנבנה ממש עכשיו — נחסם")
except ValueError as e:
    chk(True, "ויתור על קליף שנבנה ממש עכשיו — נחסם עם הסבר", str(e)[:60])
A.JOBS[fake]["running"] = False
# 4. עדכון עצמי לא קורה באמצע גיבוי / בדיקת חבילה / עבודה בתור
A.CODE["pending"] = {"hash": "x", "at": "", "files": []}
for k, setter in (("גיבוי לדרייב", lambda v: A.DRIVE_Q.__setitem__("running", v)),
                  ("בדיקת חבילת השיתוף", lambda v: A.SHARE_CHECK.__setitem__("running", v))):
    setter(True)
    try:
        A.RESTARTING.update(on=True, at=0); A.code_restart_if_idle()
        chk(not A.RESTARTING["on"], "עדכון עצמי מחכה כש%s רץ" % k)
    except RuntimeError:
        chk(False, "עדכון עצמי מחכה כש%s רץ" % k, "ניסה להפעיל מחדש")
    setter(False)
jw = A.enqueue("finish", ["finish", P], P, "t", kick=False)
A.NET["ok"] = False
A.RESTARTING.update(on=True, at=0); A.code_restart_if_idle()
chk(not A.RESTARTING["on"], "עדכון עצמי מחכה כשיש עבודה בתור (גם בלי אינטרנט)")
A.queue_edit({"id": next(x for x in A.BUILD_Q if x.get("job") == jw)["id"], "action": "remove"})
A.CODE["pending"] = None
# 5. הדוח לעוזר — בלי שום סוד
import make_short_share as SH
rep = A.report_text("", True).encode("utf-8")
vals = SH.known_secrets()
chk(not any(p.search(rep) for p in SH.SECRET_PATTERNS) and not any(v in rep for v in vals),
    "הדוח לעוזר (כולל המדריך המלא) — בלי מפתח, עוגייה או טוקן")
import make_short_chat as CH         # 27/10: הבלוק של "עבודה עם צ'אט" — גם בו שום סוד
bb = CH.block("bug", "בדיקה", {"job": {"kind": "finish", "log": ["x"]}}, budget=60000)["text"].encode("utf-8")
chk(not any(p.search(bb) for p in SH.SECRET_PATTERNS) and not any(v in bb for v in vals) and len(bb.decode()) <= 60000,
    "הבלוק לצ'אט (🐞 / ➕) — בתוך התקציב, בלי מפתח, עוגייה או טוקן")
# 6. הגדרות: כל ערך נשמר/מאופס/מבוטל בלי לשבור
SET.update({"colors_off": ["1ac8a8", "zz", "B14EFF"], "notif_sound": "harp"})
v = SET.load()
chk(v["colors_off"] == ["1AC8A8", "B14EFF"], "צבעים מושבתים נשמרים נקיים")
pool, fb = SET.random_pool(v); chk(SET.DEFAULT_COLORS["teal"] not in pool and not fb, "האקראי לא בוחר צבע מושבת")
SET.reset(["colors_off", "notif_sound"]); chk(SET.load()["colors_off"] == [] and SET.load()["notif_sound"] == "chime", "איפוס")
SET.undo(); chk(SET.load()["notif_sound"] == "harp", "ביטול האיפוס מחזיר בדיוק")
SET.update({"styles_off": ["marker", "bad"]}); chk(SET.load()["styles_off"] == ["marker"], "styles_off נשמר")
SET.reset(["styles_off"]); chk(SET.load()["styles_off"] == [], "איפוס styles_off")
SET.undo(); chk(SET.load()["styles_off"] == ["marker"], "ביטול איפוס styles_off"); SET.reset(["styles_off"])
try:
    SET.update({"notif_sound": "rock"}); chk(False, "צליל לא מוכר נדחה")
except ValueError:
    chk(True, "צליל לא מוכר נדחה")
# 7. 31/10: ניקוי תצוגות מקדימות — רק גמורות שלא נראו שעה; רצות ותצוגות טריות נשארות; הקובץ נמחק רק בתיקיית work/preview
pd = os.path.join(P, "work", "preview"); os.makedirs(pd, exist_ok=True)
def pvf(n):
    f = os.path.join(pd, n); open(f, "wb").write(b"x"); return f
now = time.time()
fo, fn, fr, fs = pvf("old.mp4"), pvf("new.mp4"), pvf("run.mp4"), pvf("shared.mp4")
elsewhere = os.path.join(P, "keep.mp4"); open(elsewhere, "wb").write(b"x")
A.PREVIEWS.clear()
A.PREVIEWS.update({"o": {"running": False, "ok": True, "file": fo, "started": now - 9000},
                   "n": {"running": False, "ok": True, "file": fn, "started": now - 9000, "seen": now - 60},
                   "r": {"running": True, "ok": None, "file": fr, "started": now - 9000},
                   "s1": {"running": False, "ok": True, "file": fs, "started": now - 9000},
                   "s2": {"running": False, "ok": True, "file": fs, "started": now - 100},
                   "x": {"running": False, "ok": True, "file": elsewhere, "started": now - 9000}})
A.prune_previews(now)
chk(set(A.PREVIEWS) == {"n", "r", "s2"}, "ניקוי תצוגות: נשארו רק הטרייה, זו שנראתה לאחרונה והרצה", sorted(A.PREVIEWS))
chk(not os.path.exists(fo) and os.path.exists(fn) and os.path.exists(fr), "קובץ התצוגה הישנה נמחק; החדשה והרצה — נשארו")
chk(os.path.exists(fs), "קובץ שתצוגה חיה עדיין משתמשת בו — לא נמחק")
chk(os.path.exists(elsewhere), "קובץ מחוץ ל-work/preview — אף פעם לא נמחק")
A.PREVIEWS.clear()
print("RESULT=" + json.dumps(out, ensure_ascii=False))
'''
    P = make_fixture(T, "app")
    set_settings(T, {})
    r = subprocess.run([PY, "-c", code, str(HERE), str(P)], env=env, capture_output=True, text=True, errors="replace",
                       timeout=300, cwd=str(T))
    line = next((l for l in reversed(r.stdout.splitlines()) if l.startswith("RESULT=")), "")
    if not line:
        ok(False, "בדיקות השרת רצו", (r.stdout + r.stderr).strip()[-400:])
        return
    for c, w, d in json.loads(line[7:]):
        ok(c, w, d if not c else "")


def guard_checks(T, env):
    """29/10: אתר זר לא מדבר עם השרת (Host / Origin / JSON בלבד) — והדף עצמו, כולל sendBeacon, עדיין עובר."""
    say("\n▶ השרת המקומי: אתר זר נחסם, הדף עובר")
    r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / "test_local_guard.py")], env=env, capture_output=True,
                       text=True, errors="replace", timeout=180, cwd=str(T))
    bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    ok(r.returncode == 0, "אתר זר נחסם (Host / Origin / טופס), הדף וה-sendBeacon עוברים",
       "; ".join(bad) or (r.stdout + r.stderr).strip()[-300:])


def release_checks(T, env):
    """4.3: עדכונים חתומים — חתימה וזיופים, סדר, שחזור מהפסקה, כישלון באמצע, פרסום וביטול (שרת מרוחק מזויף, בלי רשת)
    + השורה העליונה: הכפתור האחד שם, ו-Modal והמתגים עברו להגדרות."""
    say("\n▶ עדכונים חתומים (4.3)")
    r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / "test_release_update.py")], env=env, capture_output=True,
                       text=True, errors="replace", timeout=900, cwd=str(T))
    bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    n = sum(1 for l in r.stdout.splitlines() if l.strip().startswith(("✓", "✗")))
    ok(r.returncode == 0 and n > 80, "בדיקות העדכונים החתומים (%d בדיקות)" % n, "; ".join(bad)[:500] or (r.stdout + r.stderr).strip()[-400:])
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    bar = page[page.index('<div class="top bar">'):page.index('<div id="banners">')]
    ok('id="updBtn"' in bar and 'id="muteBadge"' in bar, "בשורה העליונה: כפתור העדכון האחד וסמל 🔕")
    ok('id="mModal"' not in bar and 'id="tgPop"' not in bar and 'id="tgSnd"' not in bar,
       "Modal והמתגים כבר לא בשורה העליונה")
    ok('data-sec="asr"' in page and page.index('id="mModal"') > page.index('data-sec="asr"')
       and page.index('id="tgPop"') > page.index('data-sec="notif"'), "מד Modal בכרטיס 🎙️ תמלול והמתגים בכרטיס 🔔 התראות")


def proposals_checks(T, env):
    """4.4: הצעות למנהל דרך ntfy — כל הבדיקות מול שרת ntfy מזויף מקומי (בלי רשת) + הסתרת מסך הבעלים בדף ובשרת."""
    say("\n▶ הצעות למנהל (4.4)")
    r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / "test_proposals.py")], env=env, capture_output=True,
                       text=True, errors="replace", timeout=900, cwd=str(T))
    bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    n = sum(1 for l in r.stdout.splitlines() if l.strip().startswith(("✓", "✗")))
    ok(r.returncode == 0 and n > 100, "בדיקות ההצעות למנהל (%d בדיקות)" % n, "; ".join(bad)[:500] or (r.stdout + r.stderr).strip()[-400:])
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    app = (HERE / "make_short_app.py").read_text(encoding="utf-8")
    ok('id="propOwner"' in page and 'class="set adv" id="propOwner" hidden' in page, "מסך 'הצעות ממשתמשים' מוסתר כברירת מחדל ובפשוט")
    ok('id="propCard"' in page and 'class="set" id="propCard"' in page, "כרטיס השליחה למנהל גלוי גם בתצוגה הפשוטה")
    ok("prop_owner_guard()" in app and 'path.startswith("/api/proposals/owner/")' in app, "פעולות הבעלים נחסמות בשרת גם בלי הדף")
    ok("textContent=PROPD.preview" in page, "התצוגה המקדימה כטקסט (לא HTML)")

def personal_checks(T, env):
    """4.5: שינויים אישיים שורדים עדכונים — מנוע (מאגרים זמניים) + שרת אמיתי על שיבוט + הדף."""
    say("\n▶ שינויים אישיים (4.5)")
    for name, lo in (("test_personal.py", 40), ("test_personal_app.py", 15), ("test_fixes_4562.py", 40)):
        r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / name)], env=env, capture_output=True, text=True, errors="replace",
                           timeout=900, cwd=str(T))
        bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
        n = sum(1 for l in r.stdout.splitlines() if l.strip().startswith(("✓", "✗")))
        ok(r.returncode == 0 and n > lo, "%s (%d בדיקות)" % (name, n), "; ".join(bad)[:500] or (r.stdout + r.stderr).strip()[-400:])
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    ok('id="pcSet"' in page and 'class="set" id="pcSet" hidden' in page, "מסך «שינויים אישיים שלי» מוסתר כשאין שינויים וגלוי גם בפשוט")
    ok("personal:" in page and "2 מתוך 3" in (HERE / "make_short_release.py").read_text(encoding="utf-8"), "שלב ההחלה מחדש בהתקדמות העדכון")


def vault_checks(T, env):
    """4.6: הכספת המוצפנת + ערכת השחזור למחשב חדש (סודות מזויפים, Drive מזויף = תיקייה מקומית, בלי רשת)."""
    say("\n▶ כספת ושחזור למחשב חדש (4.6)")
    r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / "test_vault.py")], env=env, capture_output=True, text=True, errors="replace",
                       timeout=1800, cwd=str(T))
    bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    n = sum(1 for l in r.stdout.splitlines() if l.strip().startswith(("✓", "✗")))
    ok(r.returncode == 0 and n > 120, "test_vault.py (%d בדיקות)" % n, "; ".join(bad)[:500] or (r.stdout + r.stderr).strip()[-400:])
    r = subprocess.run([PY, "-u", str(HERE.parent / "tests" / "test_undo_bar.py")], env=env, capture_output=True, text=True, errors="replace",
                       timeout=300, cwd=str(T))
    bad = [l.strip()[2:] for l in r.stdout.splitlines() if l.strip().startswith("✗")]
    n = sum(1 for l in r.stdout.splitlines() if l.strip().startswith(("✓", "✗")))
    ok(r.returncode == 0 and n >= 9, "test_undo_bar.py (%d בדיקות)" % n, "; ".join(bad)[:500] or (r.stdout + r.stderr).strip()[-400:])


def past_ui_checks():
    """4.3.1: "📂 שיעורים קודמים" — שם השורט עצמו בכל רוחב השורה (בלי שם השיעור לפניו), אורך · מצב · ✓ הועלה · 🧹 בכל שורה,
    ו"חזרה למקום": ניקוי שנסגר (גם "המשך ברקע") פותח מחדש את הרשימה באותו גלילה ובאותם שיעורים מקופלים — לא בדף הבית."""
    say("\n▶ שיעורים קודמים: שמות השורטס + חזרה למקום (4.3.1)")
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    app = (HERE / "make_short_app.py").read_text(encoding="utf-8")
    ok("CLEAN.clip_title(d, c)" in app and '"seconds"' in app and '"state": "uploaded"' in app,
       "השרת מחזיר לכל שורט: שם אמיתי (מקובץ העריכה), אורך ומצב")
    row = page[page.index("function pastUpHTML"):page.index("function fillPast")]
    ok('class="ut"' in row and "c.title||cn(c.name)" in row and "x.title" not in row,
       "שורת שורט: השם של השורט בלבד (בלי שם השיעור), 'קליף N' רק כשאין שם")
    ok("data-cc" in row and "data-um" in row and "CLIPST[c.state]" in row and "c.seconds" in row, "בכל שורה: אורך, מצב, ✓ הועלה ו-🧹")
    ok("-webkit-line-clamp:2" in page and ".upx .ur .ut{flex:1 1 100%" in page, "השם בכל רוחב השורה, עד שתי שורות")
    fp = page[page.index("function fillPast"):page.index("/* ───────── 🧹 נקה")]
    ok("m.remove();cleanDialog(" not in fp and fp.count("back()") >= 3 and "openPast(sc)" in fp,
       "כל פתיחת ניקוי מתוך הרשימה מחזירה אליה (עם מיקום הגלילה)")
    cd = page[page.index("async function cleanDialog"):page.index("/* 31/10 (כרטיס 23): הניקוי רץ ברקע")]
    ok(cd.count("goBack()") >= 2 and "m.remove();goBack()" in cd and "fail(" in cd and "opts" in cd, "סגירת חלון הניקוי (גם 'המשך ברקע' וכשל בתכנון) חוזרת למקום")
    ok("PAST_SHUT" in page and "PAST_OPEN" not in page, "קיפול שיעורים נשמר בין רענונים של הרשימה")


def editor_checks(T, env):
    """28/10 — העורך החכם, בלי שום בקשה ל-Gemini: קריאת תשובה, בדיקת כיסוי (משפט שנשמט / תוכן שהומצא נדחים),
    החלה על קובץ העריכה עם מיזוג של מה שתיקן בינתיים, המילון, מד האיכות, והחלטת חלון השליחה המשותפת."""
    say("\n▶ העורך החכם (בלי Gemini)")
    code = r'''
import json, os, sys, time
sys.path.insert(0, sys.argv[1])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked in selftest"))
import make_short_editor as ED, make_short as MS, make_short_app as A
from pathlib import Path
P = Path(sys.argv[2])
st, items = ED.items_for(P)
it = items[0]
good = '{"clips":[{"n":1,"text":"בדיקה אחת, שתיים שלוש [ארבע / ארבעה] חמש. שש שבע שמונה תשע.","doubts":[{"options":["ארבע","ארבעה"],"more":["אַרְבַּע","ארבה"],"why":"נבלע"}]}]}'
r = ED.parse_answer("```json\n" + good + "\n```", 1)
chk(1 in r and "[ארבע / ארבעה]" in r[1]["text"], "תשובה בתוך גדר קוד נקראת")
chk(ED.check(it, ED.canon(r[1]["text"]))[0], "תשובה מלאה עוברת את בדיקת הכיסוי")
short = "בדיקה אחת, שתיים."
chk(not ED.check(it, short)[0], "תשובה שהשמיטה משפט נדחית", ED.check(it, short)[1])
inv = "בדיקה אחת שתיים שלוש ארבע חמש שש שבע שמונה תשע ואסור לאכול חמץ בפסח כל שבעת הימים לפי ההלכה"
chk(not ED.check(it, inv)[0], "תשובה שהוסיפה משפט שאף אוזן לא שמעה נדחית", ED.check(it, inv)[1])
# הוא תיקן מילה לפני שהעורך חזר — התיקון שלו נשאר
f = P / it["c"]["edit"]
raw = MS.read_edit_raw(f)
base = MS.keep_version(P, f)
MS.write_edit(f, it["c"], P, raw["title"], raw["desc"], raw["tags"], raw["text"].replace("תשע", "תשעה"), raw["yt"])
it["c"]["editor_base"] = base
info = ED.apply_clip(it, r[1], "gemini")
txt = MS.read_edit_raw(f)["text"]
chk("תשעה" in txt and "[ארבע / ארבעה]" in txt, "העורך לא דורס תיקון שהקליד בזמן ההמתנה (מיזוג)", txt)
st2 = json.load(open(P / MS.STATE, encoding="utf-8"))
c2 = st2["clips"][0]
chk(c2["doubts"] and c2["doubts"][0][1] == "[ארבע / ארבעה]" and 1.0 < c2["doubts"][0][0] < 2.0,
    "ספק של העורך מקבל זמן בקליף (▶)", str(c2["doubts"]))
chk((c2.get("doubt_more") or {}).get("[ארבע / ארבעה]", {}).get("more") == ["אַרְבַּע", "ארבה"], "\"עוד הצעות\" נשמרות לספק")
chk(ED.canon("א [ב/ב] ג [ד / ה ] ו [—/ז]") == "א ב ג [ד / ה] ו [— / ז]", "ספקות מתנקים לצורה אחת")
# מד איכות + מילון
ED.write_delivered(P, "clip1", "הרב אמר שהיכי תמצית לדבקות כל ביחד", "gemini")
pairs = ED.learn_pairs("הרב אמר שהיכי תמצית לדבקות כל ביחד", "הרב אמר שהיכי תמצי לדבקות הכל ביחד.")
chk(("תמצית", "תמצי") in pairs and not any(p[1] == "הכל" for p in pairs), "המילון לומד מונח ולא מילת קישור", str(pairs))
n, tot = ED.changed_words("א ב ג ד", "א ב, ג ה.")
chk(n == 1 and tot == 4, "מד האיכות סופר מילים (בלי פיסוק)", "%d/%d" % (n, tot))
ED.glossary_learn(pairs, "t")
chk(ED.glossary_view()["entries"] and "תמצי" in ED.asr_hint(), "המילון נכנס לרמז של התמלול")
ED.glossary_edit("remove", "תמצי", "תמצית")
ED.glossary_learn(pairs, "t")
chk(not any(e["right"] == "תמצי" for e in ED.glossary_view()["entries"]), "מילה שהוריד מהמילון לא נלמדת שוב")
chk(ED.hint_suspect([{"word": "x", "start": 4.0, "end": 5.0}], [{"word": "y", "start": 0.2, "end": 5.0}]),
    "תמלול עם רמז שבלע את ההתחלה — מזוהה ומתומלל שוב")
# חלון השליחה המשותפת
s = {"editor_window_min": 3, "editor_cap_min": 20}
now = 1000.0
chk(A.editor_decide([("a", now - 10)], [], now, s)[0] == "wait", "אין שיעור בדרך — מחכים עד 3 דקות")
chk(A.editor_decide([("a", now - 200)], [], now, s) == ("send", ["a"]), "אחרי 3 דקות בלי שיעור נוסף — שולחים")
chk(A.editor_decide([("a", now - 300)], [("b", "שיעור ב")], now, s)[0] == "wait", "שיעור בדרך — מחכים לו גם אחרי 3 דקות")
chk(A.editor_decide([("a", now - 1300)], [("b", "שיעור ב")], now, s)[0] == "send", "תקרה (20 דקות) — שולחים מה שמוכן")
chk(A.editor_decide([("a", now - 300), ("b", now - 5)], [], now, s) == ("send", ["a", "b"]), "שני שיעורים מוכנים — בקשה אחת לשניהם")
chk(A.editor_decide([("a", now)], [("b", "x")], now, dict(s, editor_window_min=0))[0] == "send", "0 דקות = לא מחכים אף פעם")
chk(A.editor_decide([("a", now)], [("b", "x")], now, s, force=True)[0] == "send", "\"שלח עכשיו\" — מיד")
blk, n = ED.chat_block([P])
chk(n == 1 and "### קטע 1" in blk and "אין כאן שמע" in blk, "\"העתק לצ'אט\" של העורך — בלי שמע, עם הכללים")
# 28/10 — כל שלב: מפתח או צ'אט; עצירה לפני הגבול. מפתח מזויף + קובץ מכסה זמני: שום בקשה לא יוצאת לרשת
import make_short_pick as PICK, make_short_settings as SET
os.environ["GEMINI_API_KEY"] = "selftest-fake-key-000000000000"
for k in ("gm_pick", "gm_rank", "gm_playlist", "gm_editor", "gm_alts"):
    chk(SET.DEFAULTS[k] == "key", "ברירת מחדל: %s ישירות דרך המפתח" % k)
try:
    SET.update({"gm_editor": "maybe"}); chk(False, "בחירה לא מוכרת לשלב נדחית")
except ValueError:
    chk(True, "בחירה לא מוכרת לשלב נדחית")
SET.update({"gm_editor": "chat"})
ED.set_status(P, status="pending")
ED.run([str(P)])
e = json.load(open(P / MS.STATE, encoding="utf-8"))["editor"]
chk(e["status"] == "chat" and "העתק לצ'אט" in e.get("msg", ""), "העורך בהגדרה \"תמיד העתק לצ'אט\" — לא שולח, עובר לצ'אט", str(e)[:200])
SET.update({"gm_editor": "key"})
PICK._usage_edit(lambda d: d["models"].__setitem__(SET.load()["gemini_model"], {"used": 18, "limit": 20, "limit_src": "google"}))
chk(PICK.margin_left() == 0 and PICK.gemini_status()["margin_stop"], "18 מתוך 20 עם עצירה 2 לפני — נעצר")
try:
    PICK.gemini_call("x"); chk(False, "עצירה לפני הגבול — gemini_call לא שולח")
except PICK.GeminiStop as ex:
    chk(ex.kind == "quota_margin" and "העתק לצ'אט" in str(ex), "עצירה לפני הגבול — gemini_call לא שולח, ומסביר בעברית", str(ex)[:120])
ED.set_status(P, status="pending")
ED.run([str(P)])
e = json.load(open(P / MS.STATE, encoding="utf-8"))["editor"]
chk(e["status"] == "chat", "בקשה משותפת שלא נכנסת מתחת לגבול — לא נשלחת (צ'אט)")
SET.update({"gemini_margin": 0})
chk(PICK.margin_left() is None, "0 = רק העצירה של Google עצמו")
SET.update({"gemini_margin": 2})
# ───── 4.1.1: Gemini לא שמיש → העורך לא מופעל; כישלון מהיר; ⛔ עצירה; עריכה בזמן שליחה ─────
import signal, subprocess, urllib.error, urllib.request
MODEL = SET.load()["gemini_model"]
KEY = os.environ["GEMINI_API_KEY"]
def reset_usage():
    PICK._usage_edit(lambda d: (d["models"].clear(), d.pop("key_block", None), d.pop("last_fail", None)))
def pend(**kv):
    ED.set_status(P, status="pending", skipped=False, after=None, **kv)
def est():
    return json.load(open(P / MS.STATE, encoding="utf-8"))["editor"]
reset_usage()
chk(PICK.gemini_unusable(P) is None, "אין עצירה ידועה — Gemini שמיש")
PICK._usage_edit(lambda d: d.__setitem__("key_block", {"fp": PICK.key_fp(KEY), "at": "x", "msg": ""}))
chk((PICK.gemini_unusable(P) or ("",))[0] == "key_blocked", "תנאי א: מפתח חסום — לא מפעילים")
reset_usage()
PICK._usage_edit(lambda d: d["models"].__setitem__(MODEL, {"blocked_until": time.time() + 600, "block_msg": "המכסה היומית נגמרה"}))
chk((PICK.gemini_unusable(P) or ("",))[0] == "quota_day", "תנאי ב: מכסה יומית נגמרה — לא מפעילים")
PICK._usage_edit(lambda d: d["models"].__setitem__(MODEL, {"used": 18, "limit": 20}))
chk((PICK.gemini_unusable(P) or ("",))[0] == "quota_margin", "תנאי ב: בתוך שולי הבטיחות — לא מפעילים")
reset_usage()
PICK.fail_note("busy")
u = PICK.gemini_unusable(P)
chk(u and u[0] == "busy" and u[1] == "העורך החכם לא הופעל כי Gemini עמוס כרגע", "תנאי ג: עומס לפני דקה — לא מפעילים, ושורה רגועה בעברית", str(u))
PICK.fail_note("timeout")
chk((PICK.gemini_unusable(P) or ("",))[0] == "timeout", "תנאי ג: אין תשובה בזמן — לא מפעילים")
PICK._usage_edit(lambda d: d["last_fail"].__setitem__("at", time.time() - 16 * 60))
chk(PICK.gemini_unusable(P) is None, "כישלון ישן (מעבר ל-15 דקות) — מנסים שוב")
SET.update({"gemini_recent_fail_min": 0}); PICK.fail_note("busy")
chk(PICK.gemini_unusable(P) is None, "gemini_recent_fail_min=0 — הבדיקה כבויה")
SET.update({"gemini_recent_fail_min": 15}); reset_usage()
pk = P / PICK.PICK
pk.write_text(json.dumps({"gemini_stop": {"kind": "busy", "msg": "x", "at": "00:00", "ts": time.time()}}), encoding="utf-8")
chk((PICK.gemini_unusable(P) or ("",))[0] == "busy", "תנאי ג: שלב בחירת הקטעים באותו שיעור נפל בגלל עומס — לא מפעילים")
pk.write_text(json.dumps({"gemini_stop": {"kind": "busy", "msg": "x", "at": "00:00", "ts": time.time() - 3600}}), encoding="utf-8")
chk(PICK.gemini_unusable(P) is None, "עצירת בחירה ישנה (שעה) — לא חוסמת")
pk.unlink()
# הבקשה האמיתית: נתפסת ב-urlopen מזויף — בלי רשת
calls = []
def fake(kind):
    def _u(req, timeout=None):
        calls.append(timeout)
        if kind == "503":
            raise urllib.error.HTTPError("u", 503, "busy", {}, None)
        if kind == "timeout":
            raise TimeoutError("timed out")
        class R:
            def __enter__(s): return s
            def __exit__(s, *a): return False
            def read(s): return json.dumps({"candidates": [{"content": {"parts": [{"text": "שלום"}]}}]}).encode()
        return R()
    return _u
real_open = urllib.request.urlopen
urllib.request.urlopen = fake("503")
try:
    PICK.gemini_call("x"); chk(False, "503 צריך לזרוק")
except PICK.GeminiStop as ex:
    chk(ex.kind == "busy" and (PICK.recent_fail() or {}).get("kind") == "busy" and len(calls) == 1, "503: עצירה מיד (בלי ניסיון חוזר), והכישלון נרשם", str(calls))
urllib.request.urlopen = fake("timeout"); calls.clear()
try:
    PICK.gemini_call("x", timeout=77); chk(False, "timeout צריך לזרוק")
except PICK.GeminiStop as ex:
    chk(ex.kind == "timeout" and (PICK.recent_fail() or {}).get("kind") == "timeout" and calls == [77], "אין תשובה בזמן: kind=timeout, נרשם, בלי ניסיון חוזר", str(calls))
urllib.request.urlopen = fake("ok")
chk(PICK.gemini_call("x") == "שלום" and PICK.recent_fail() is None, "תשובה תקינה מוחקת את סימן הכישלון")
# העורך עצמו: עומס → וויתור מהיר עם timeout קצר (240, לא 900) וסטטוס "לא הופעל" שלא חוסם
REAL_BUILD = ED.build_request
ED.build_request = lambda g, chat=False: ("p", [])
urllib.request.urlopen = fake("503"); calls.clear()
reset_usage(); pend()
ED.run([str(P)])
e = est()
chk(e["status"] == "chat" and e.get("skipped") and e["msg"] == "העורך החכם לא הופעל כי Gemini עמוס כרגע" and len(calls) == 1
    and calls[0] == 240, "העורך מול עומס: וויתור מהיר, שורה רגועה, timeout 240 ולא 900", str(e)[:160] + str(calls))
urllib.request.urlopen = fake("timeout"); calls.clear()
reset_usage(); pend()
ED.run([str(P)])
e = est()
chk(e["status"] == "chat" and e.get("skipped") and "לא ענה בזמן" in e["msg"] and len(calls) == 1, "העורך מול אין-תשובה: וויתור מהיר", str(e)[:160])
urllib.request.urlopen = real_open
ED.build_request = REAL_BUILD
# השער של השרת: מדלג בלי להפעיל עורך ובלי חלון ההמתנה; "אוטומטי עד הצריבה" ממשיך; ידני עוקף
burned = []
A.auto_finish = lambda p, snap, auto: burned.append((str(p), auto))
reset_usage(); PICK.fail_note("busy")
pend(); A._ed_write(P, lambda e: e.update(after={"settings": "", "auto_burn": True}))
rest = A.editor_gate([(str(P), time.time())])
e = est()
chk(rest == [] and e["status"] == "chat" and e.get("skipped") and burned == [(str(P), True)] and "after" not in e,
    "שער: Gemini עמוס — מדלגים בלי להתחיל המתנה, והצריבה האוטומטית ממשיכה", str(e)[:200] + str(burned))
chk(e["msg"].startswith("העורך החכם לא הופעל כי"), "השער כותב שורה אחת רגועה")
pend(); A.EDITOR["manual"].add(str(P))
rest = A.editor_gate([(str(P), time.time())])
chk(rest == [(str(P), rest[0][1])] and est()["status"] == "pending", "\"🔁 נסה עם Gemini\" (ידני) עוקף את הסימן ונשלח")
A.EDITOR["manual"].clear()
reset_usage()
pend()
chk(len(A.editor_gate([(str(P), time.time())])) == 1, "בלי עצירה ידועה — השיעור ממשיך לחלון הרגיל")
# ⛔ עצור את העורך: התהליך נהרג, הטקסט נשאר, המצב "בלי העורך"
ED.set_status(P, status="sending", skipped=False)
sp = subprocess.Popen(["sleep", "60"])
job = {"id": "t1", "kind": "editor", "project": str(P), "projects": [str(P)], "running": True, "pid": sp.pid}
A.JOBS["t1"] = job
f_ed = P / it["c"]["edit"]
before_txt = MS.read_edit_raw(f_ed)["text"]
A.editor_stop(P)
try:
    sp.wait(timeout=5); dead = True
except Exception:
    dead = False; sp.kill()
chk(dead and job.get("stopped"), "עצירה: הבקשה שבדרך מבוטלת (התהליך נהרג)")
A.editor_ended(job)
e = est()
chk(e["status"] == "skipped" and "עצרת" in e["msg"] and MS.read_edit_raw(f_ed)["text"] == before_txt, "עצירה: מצב \"בלי העורך\" והטקסט שלו נשאר", str(e)[:160])
A.JOBS.pop("t1", None)
try:
    A.editor_stop(P); chk(False, "עצירה כשלא עובד — צריכה להודיע")
except ValueError:
    chk(True, "עצירה כשהעורך לא עובד — הודעה ברורה")
# עריכה בזמן "נשלח": מה שהקליד נשמר, התשובה ממוזגת, והמילים שלו גוברות
ED.set_status(P, status="sending", skipped=False)
raw = MS.read_edit_raw(f_ed)
base2 = MS.keep_version(P, f_ed)
MS.write_edit(f_ed, it["c"], P, raw["title"], raw["desc"], raw["tags"], raw["text"].replace("שמונה", "שמונים"), raw["yt"])
it["c"]["editor_base"] = base2
ED.apply_clip(it, r[1], "gemini")
t2 = MS.read_edit_raw(f_ed)["text"]
chk("שמונים" in t2 and "[ארבע / ארבעה]" in t2, "עריכה בזמן שהעורך עובד: התיקון שלו נשמר והתשובה ממוזגת", t2)
page = (Path(sys.argv[1]) / "make_short_page.html").read_text(encoding="utf-8")
chk('QUICK_KINDS=["restyle","swap","save","editor"]' in page, "הדף: עבודת העורך לא מחליפה את מסך העריכה ב\"בעבודה\"")
chk("edStop()" in page and "⛔ עצור את העורך" in page and "🔁 נסה עם Gemini" in page, "הדף: כפתורי ⛔ עצור ו-🔁 נסה עם Gemini")
ab = ED.alts_chat(P, "clip1", "בדיקה אחת, שתיים [שלוש / שלש] ארבע")
chk("### ספק 1" in ab and "פסולות" in ab and "שלש" in ab and "אין כאן שמע" in ab, "\"חפש הצעות אחרות\" לצ'אט — בלי שמע, עם הפסולות")
r = ED.alts(P, "clip1", "בדיקה אחת, שתיים [שלוש / שלש] ארבע",
            answer='```json\n{"doubts":[{"n":1,"options":["שלוש","שולש","שלושה"],"why":"מהר"}]}\n```')
chk(r.get("[שלוש / שלש]", {}).get("alts") == ["שולש", "שלושה"], "תשובה מהצ'אט ל\"חפש הצעות אחרות\" נשמרת כמו של Gemini (בלי הפסולות)", str(r))
SET.update({"gm_pick": "chat", "gm_rank": "chat"})
pst = {"kind": "lesson", "lessons": [], "chunks": {"gemini": [{"id": "g1", "lessons": [1], "status": "pending"}]},
       "rchunks": {"gemini": [{"id": "rg1", "lessons": [1], "status": "pending"}]}}
chk(PICK.ask_gemini(P, pst) is False and pst["gemini_stop"]["kind"] == "chat_mode",
    "בחירה/דירוג בהגדרה \"תמיד העתק לצ'אט\" — לא נשאל לבד, נשאר לצ'אט")
print("RESULT=" + json.dumps(out, ensure_ascii=False))
'''
    P = make_fixture(T, "editor")
    set_settings(T, {})
    e = dict(env, MAKE_SHORT_GLOSSARY=str(T / "glossary.json"), MAKE_SHORT_QUALITY=str(T / "quality.jsonl"),
             MAKE_SHORT_GEMINI_USAGE=str(T / "gemini_usage.json"))
    r = subprocess.run([PY, "-c", code, str(HERE), str(P)], env=e, capture_output=True, text=True, errors="replace",
                       timeout=300, cwd=str(T))
    line = next((l for l in reversed(r.stdout.splitlines()) if l.startswith("RESULT=")), "")
    if not line:
        ok(False, "בדיקות העורך רצו", (r.stdout + r.stderr).strip()[-600:])
        return
    for c, w, d in json.loads(line[7:]):
        ok(c, w, d if not c else "")


def static_checks():
    """כללים שבקוד עצמו."""
    say("\n▶ כללים בקוד")
    sys.path.insert(0, str(HERE))
    import make_short as MS
    src = (HERE / "make_short.py").read_text(encoding="utf-8")
    ok(MS.LARGE != MS.TURBO and "turbo" in MS.TURBO and "turbo" not in MS.LARGE, "שתי האוזניים — שני מודלים שונים (large-v3 + turbo)")
    ok(re.search(r"asr\([^)]*\bLARGE\b", src) and re.search(r"asr\([^)]*\bTURBO\b", src), "ההכנה מתמללת עם שניהם, במודל מפורש")
    ok("אוזן שנייה כזאת לא שווה כלום" in src, "תמלול שרץ על מודל אחר ממה שביקשו — נעצר")
    fin = src[src.index("def finish(project"):src.index("def export_root")]
    ok("export_clips" not in fin and "mark_drive_pending" not in fin, "הסיום (טיוטה) לא קורא לייצוא ולא לדרייב")
    # 31/10: כתובת yeshivashorts: עם מירכאה ו-& שברה את הציטוט ויכלה להריץ פקודה — המטפל לא מקבל יותר את הכתובת (%1)
    win = REPO / "windows"
    link = (win / "app_link.ps1").read_text(encoding="utf-8-sig")
    cmd = next((l for l in link.splitlines() if l.strip().startswith("$cmd =")), "")
    ok(cmd and "%1" not in cmd and "protocol" in cmd, "הפקודה הרשומה ב-yeshivashorts: בלי %1 (הזרקת פקודה)", cmd.strip())
    bat = (win / "launcher.bat.txt").read_text(encoding="ascii")
    uses = [l.strip() for l in bat.splitlines() if re.search(r"%~?[1-9]", l) and not l.lstrip().lower().startswith("rem")]
    ok(uses == ['set "A1=x%~1"'], "המפעיל מרחיב את הארגומנט רק בשורה אחת (set), לא בשום שורת הרצה", uses)
    ok('"%A1%"=="xprotocol"' in bat, "המפעיל מזהה את מילת המטפל המדויקת")
    # 4.0.3: מדריך המפתח האישי לדרייב — Branding (דף בית + מדיניות פרטיות) לפני Publish app, בלי פרטים אישיים
    hs = (HERE / "make_short_health.py").read_text(encoding="utf-8")
    ib, ia = hs.find("auth/branding"), hs.find("auth/audience (Audience) ← Publish app")
    ok(0 < ib < ia, "מדריך הדרייב: שלב Branding (דף בית + מדיניות פרטיות) לפני Publish app")
    # 4.5.62: אין יותר "GitHub Pages" בלי הסבר — דף בית ב-Google Sites (כתובת עם מציין מקום בלבד, בלי שם משתמש אמיתי)
    ok("Application privacy policy link" in hs and "sites.google.com/view/…" in hs and "USERNAME" not in hs
       and ("nihuly" + "betube") not in hs, "מדריך הדרייב: דף בית בלי GitHub, כתובת עם מציין מקום בלבד (בלי שם משתמש אמיתי)")

# ─────────────── 3.4: תיאור ותגיות מההגדרות · מקור הגיבוי לדרייב · גיבוי הזיכרון ───────────────

def real_desc_values():
    """הערכים של הבעלים מקובץ ההגדרות האמיתי (לא של הבדיקה), אם יש; אחרת ערכים מלאכותיים באותה צורה.
    בקוד הזה אין את המחרוזות שלו — כדי שגם הבדיקה לא תכניס אותן לחבילת השיתוף."""
    real = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts")) / "make_short_settings.json"
    try:
        v = json.loads(real.read_text(encoding="utf-8")).get("values", {})
    except (OSError, ValueError):
        v = {}
    keys = ("footer_lines", "org_name", "subscribe_text", "fixed_tags")
    if all(v.get(k) for k in keys):
        return {k: v[k] for k in keys}, True
    return {"footer_lines": "◄ אתר • https://example.org\n◄ עוד • https://example.org/more", "org_name": "ישיבת בדיקה",
            "subscribe_text": "🔔 הירשמו לערוץ הבדיקה, ולחצו על הפעמון", "fixed_tags": "שיעור תורה"}, False


def legacy_footer(series, org, footer):
    """footer_for כמו שהיה עד 3.4 (הקישורים ושם הישיבה כפרמטרים) — ההשוואה מוכיחה שאצלו כלום לא משתנה."""
    if not series:
        return org + "\n" + footer
    line = ("מתוך סדרת ה" + series) if series.startswith("שיעורים") else ("מתוך סדרת השיעורים " + series)
    return "%s | %s\n%s" % (line, org, footer)


def desc_checks(T, env):
    say("\n▶ 3.4: תיאור ותגיות מההגדרות, מקור הגיבוי, גיבוי הזיכרון")
    sys.path.insert(0, str(HERE))
    import make_short as MS
    import make_short_settings as SET
    import write_clip_meta as WCM
    D = SET.DEFAULTS
    ok(D["footer_lines"] == "" and D["org_name"] == "" and D["fixed_tags"] == "שיעור תורה"
       and D["subscribe_text"] == SET.GENERIC_SUBSCRIBE == WCM.GENERIC_SUBSCRIBE and "החדש" not in D["subscribe_text"],
       "ברירות המחדל של 📝 ריקות/כלליות (מי שמקבל את התוכנה לא מפרסם קישורים של אף ישיבה)")
    pat = re.compile(r"ybe\.org\.il|org\.il/midrash|ישיבת " + "בית" + " אל|ערוץ השיעורים " + "החדש,")
    hits = [f.name for f in sorted(HERE.glob("*.py")) + sorted(HERE.glob("*.html")) + [REPO / "drive_backup.sh", REPO / "backup_extras.sh"]
            if f.is_file() and pat.search(f.read_text(encoding="utf-8", errors="replace"))]
    ok(not hits, "אין קישורים / שם ישיבה / משפט הרשמה של בית אל כתובים בקוד", ", ".join(hits))
    ok("org_name" not in SET.reset()["undo"]["values"], "\"אפס הכול\" לא מוחק את התיאור והתגיות")
    vals, real = real_desc_values()
    for s in ("שיעורים בנושא תפילה", "בנושא בדיקה", ""):
        ok(MS.footer_for(s, vals) == legacy_footer(s, vals["org_name"], vals["footer_lines"]),
           "שורת הסדרה + הקישורים זהים לנוסח של לפני 3.4 (%s, %s)" % ("הערכים שלו" if real else "ערכים לדוגמה", s or "בלי סדרה"))
    # מקצה לקצה: write_meta על שיעור מלאכותי — התיאור והתגיות בדיוק כמו בנוסח הישן
    P = make_fixture(T, "desc")
    cwd = os.getcwd()
    try:
        os.chdir(P)
        st = MS.load_st()
        c = st["clips"][0]
        f, text, _ = MS.parse_edit(c["edit"])
        f["תגיות"] = "נושא א, נושא ב"
        d = P / "shorts" / "clip1"
        d.mkdir(parents=True, exist_ok=True)
        set_settings(T, vals)
        MS.write_meta(st, c, d, "הרב בדיקה", "סדרת בדיקה", f, text, None)
        m = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        want = WCM.build_description(f["תיאור"], st["url"], "לצפייה בשיעור המלא",
                                     legacy_footer("סדרת בדיקה", vals["org_name"], vals["footer_lines"]), vals["subscribe_text"], "")
        ok(m["description"] == want, "תיאור שלם עם ההגדרות = בייט-בייט הנוסח של לפני 3.4", repr(m["description"][-120:]))
        ok(m["tags"] == ["נושא א", "נושא ב", "הרב בדיקה", vals["org_name"], "סדרת בדיקה"]   # 3.5: התגיות הקבועות שלו כמו שהן
           + [t.strip() for t in vals["fixed_tags"].split(",") if t.strip()],
           "סדר התגיות: של Gemini, רב, ישיבה, סדרה, קבועות", ", ".join(m["tags"]))
        set_settings(T, {"footer_lines": "", "org_name": "", "subscribe_text": "", "fixed_tags": ""})
        MS.write_meta(st, c, d, "הרב בדיקה", "סדרת בדיקה", f, text, None)
        m = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        ok("הירשמו" not in m["description"] and "◄ אתר" not in m["description"] and "|" not in m["description"]
           and m["description"].rstrip().endswith("מתוך סדרת השיעורים סדרת בדיקה")
           and m["tags"] == ["נושא א", "נושא ב", "הרב בדיקה", "סדרת בדיקה"],
           "הכול ריק: בלי שורת הרשמה, בלי קישורים, בלי \" | \", בלי תגיות קבועות — ובלי שגיאה", repr(m["description"][-80:]))
        ok(MS.footer_for("", {"footer_lines": "", "org_name": "", "subscribe_text": "", "fixed_tags": ""}) == "",
           "בלי סדרה ובלי שם ישיבה — אין שורת סדרה בכלל")
    finally:
        os.chdir(cwd)
        set_settings(T, {})
        shutil.rmtree(P, ignore_errors=True)          # לא להשאיר שיעור נוסף לבדיקות שאחרי
    # מקור הגיבוי לדרייב: DRIVE_SRC → SHORTS_EXPORT_DIR (או השורה שלו ב-config.env) → ~/Videos/Shorts
    src_sh = (REPO / "drive_backup.sh").read_text(encoding="utf-8")
    block = src_sh[src_sh.index('if [ -z "${SHORTS_EXPORT_DIR'):src_sh.index("\nDST=")] + '\necho "$SRC"\n'
    (T / "src_probe.sh").write_text(block, encoding="utf-8")
    H = T / "fakehome"
    (H / ".config" / "yeshiva-shorts").mkdir(parents=True, exist_ok=True)
    def probe(extra):
        e = {k: v for k, v in os.environ.items() if k not in ("SHORTS_EXPORT_DIR", "DRIVE_SRC")}
        e.update(HOME=str(H), **extra)
        return subprocess.run(["bash", str(T / "src_probe.sh")], env=e, capture_output=True, text=True).stdout.strip()
    ok(probe({}) == str(H / "Videos" / "Shorts"), "גיבוי: בלי הגדרה — ~/Videos/Shorts (כמו תמיד)", probe({}))
    ok(probe({"SHORTS_EXPORT_DIR": "/x/מוכנים"}) == "/x/מוכנים", "גיבוי: עוקב אחרי תיקיית הייצוא שנבחרה (SHORTS_EXPORT_DIR)")
    ok(probe({"SHORTS_EXPORT_DIR": "/x", "DRIVE_SRC": "/y"}) == "/y", "גיבוי: DRIVE_SRC (מצב בדיקה) קודם")
    (H / ".config" / "yeshiva-shorts" / "config.env").write_text('SHORTS_EXPORT_DIR="~/שורטס שלי"\n', encoding="utf-8")
    ok(probe({}) == str(H / "שורטס שלי"), "גיבוי: הרצה ישירה בלי shorts.sh קוראת את התיקייה מ-config.env", probe({}))
    big = T / "exp_dir"
    big.mkdir(exist_ok=True)
    (big / "a.bin").write_bytes(b"0" * 600000)
    ok(MS.drive_limit({"SHORTS_EXPORT_DIR": str(big)}) == 3602, "מגבלת הזמן של הגיבוי נמדדת על תיקיית הייצוא שנבחרה")
    # גיבוי הזיכרון של Claude: רשימה לבנה בלבד, אף פעם לא .credentials.json
    if not shutil.which("rclone") and not os.path.exists(os.path.expanduser("~/.local/bin/rclone")):
        NOTES.append("גיבוי הזיכרון לא נבדק: אין rclone במחשב")
        return
    W = T / "winhome"
    for p, body in ((".claude/.credentials.json", "{}"), (".claude/settings.json", "{}"), (".claude/CLAUDE.md", "x"),
                    (".claude/projects/P/memory/a.md", "x"), (".claude/projects/P/memory/b.json", "{}"),
                    (".claude/projects/P/s.jsonl", "{}"), (".claude/projects/P/other/c.md", "x"), (".claude/plugins/d.md", "x"),
                    ("yeshiva-shorts/CLAUDE.md", "x"), ("yeshiva-shorts/other.md", "x")):
        (W / p).parent.mkdir(parents=True, exist_ok=True)
        (W / p).write_text(body, encoding="utf-8")
    R = T / "mem_remote"
    e = dict(os.environ, CLAUDE_WIN_HOME=str(W), EXTRAS_REMOTE=str(R), SHORTS_DATA_DIR=str(T / "data"),
             SHORTS_CONFIG_DIR=str(T / "cfg"), PATH=os.path.expanduser("~/.local/bin") + ":" + os.environ.get("PATH", ""))
    r = subprocess.run(["bash", str(REPO / "backup_extras.sh"), "memory"], env=e, capture_output=True, text=True, timeout=120)
    got = sorted(str(p.relative_to(R)) for p in R.rglob("*") if p.is_file()) if R.exists() else []
    ok(r.returncode == 0 and got == ["claude/CLAUDE.md", "claude/projects/P/memory/a.md", "claude/yeshiva-shorts/CLAUDE.md"],
       "גיבוי הזיכרון: רק CLAUDE.md וקבצי memory/*.md — בלי .credentials.json, הגדרות או שיחות",
       (", ".join(got) + " " + r.stderr[-200:]).strip())
    ok("backup_memory" in (REPO / "backup_extras.sh").read_text(encoding="utf-8")
       and "extras_watch" in (HERE / "make_short_app.py").read_text(encoding="utf-8"),
       "גיבוי \"גיבוי תוכנה\" (כולל הזיכרון) רץ לבד פעם ביום מהתוכנה")


# ─────────────── חבילת השיתוף ───────────────

RUNTIME = re.compile(r"^(pipeline/|windows/|assets/|setup/|shorts\.sh$|install\.sh$|backup_extras\.sh$|drive_backup\.sh$|"
                     r"requirements[^/]*\.txt$|SKILL\.md$|docs/)")


def ps_blocks():
    """הקטעים של bash מתוך install_windows.ps1 (אותם קטעים שההתקנה מריצה), לפי סימן מזהה בכל אחד."""
    ps = (REPO / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig")
    blocks = re.findall(r"@'\r?\n(.*?)\r?\n'@", ps, re.S)
    find = lambda mark: next((b for b in blocks if mark in b), None)
    return {"code": find(".from_package"), "extras": find("cpn()"), "verify": find("בית זמני")}


def git(*a):
    return subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True, errors="replace").stdout


def package(T, env):
    sys.path.insert(0, str(HERE))
    import make_short_share as SH
    say("\n▶ חבילת השיתוף: בנייה → חילוץ → התקנה בבדיקה → השוואה לגרסה הנוכחית")
    head = git("rev-parse", "--short", "HEAD").strip()
    # קבצי הרצה שעוד לא ב-git — לא ייכנסו לחבילה (git archive) ולא יגיעו למקבל
    untracked = [f for f in git("ls-files", "--others", "--exclude-standard").splitlines() if RUNTIME.match(f)]
    ok(not untracked, "כל קבצי ההרצה נמצאים ב-git (אחרת לא ייכנסו לחבילה)", "חדשים שלא נוספו: " + ", ".join(untracked[:6]))
    dirty = [l[3:] for l in git("status", "--porcelain", "--untracked-files=no").splitlines() if RUNTIME.match(l[3:])]
    ok(not dirty, "אין שינויים בקוד שלא נשמרו (commit) — החבילה = מה שרץ", "לא נשמרו: " + ", ".join(dirty[:6]))
    out = T / "share"
    r = subprocess.run([PY, "-u", str(HERE / "make_short_share.py"), "build", "--out", str(out)], env=env, capture_output=True,
                       text=True, errors="replace", timeout=900)
    zf = next((Path(l[5:].strip()) for l in r.stdout.splitlines() if l.startswith("FILE=")), None)
    if not ok(r.returncode == 0 and zf and zf.exists(), "החבילה נבנתה", (r.stdout + r.stderr).strip()[-300:]):
        return
    ok(not SH.scan(zf), "בחבילה אין מפתח / עוגייה / טוקן / לייקים / הגדרות אישיות")
    with zipfile.ZipFile(zf) as z:
        names = z.namelist()
        meta = json.loads(z.read("package.json"))
        cfgs = [n for n in names if n.startswith("extras/config/")]
        ok(set(cfgs) <= {"extras/config/guidelines.txt", "extras/config/brand/logo.png"},
           "מההגדרות שלו רק הלוגו וההנחיות", ", ".join(cfgs))
        personal = [n for n in names if re.search(r"(music-feedback|make_short_settings|likes)[^/]*\.json$", n)]
        ok(not personal, "בלי לייקים ובלי הגדרות שלו", ", ".join(personal[:4]))
        ok(meta.get("commit", "").split(" ")[0] == head, "גרסת החבילה = ה-commit הנוכחי (%s)" % head, meta.get("commit", ""))
        ok(meta.get("version") == SH.tool_version() and SH.tool_version() in zf.name, "מספר הגרסה בשם הקובץ ובחבילה (%s)" % SH.tool_version())
        x = T / "extract"
        z.extractall(x)
    # 3.4: הקישורים / שם הישיבה / משפט ההרשמה שלו (מקובץ ההגדרות שלו) לא נמצאים באף קובץ קוד בחבילה
    vals, real = real_desc_values()
    if real:
        needles = [l.strip() for l in vals["footer_lines"].splitlines() if l.strip()] + [vals["subscribe_text"], vals["org_name"]]
        code_files = [p for p in (x / "code").rglob("*") if p.is_file() and p.suffix in (".py", ".sh", ".html", ".ps1", ".js", ".txt", ".bat")]
        leaks = sorted({str(p.relative_to(x)) for p in code_files for n in needles
                        if n and n in p.read_text(encoding="utf-8", errors="replace")})
        ok(not leaks, "בקוד שבחבילה אין את הקישורים, שם הישיבה ומשפט ההרשמה שלו", ", ".join(leaks[:6]))
    # הקבצים שבחבילה = מה שב-HEAD (קובץ אחרי קובץ)
    # 4.1.0: מסמכים אישיים לא נארזים, ומחרוזות זהות מוחלפות — מה שמצופה בחבילה הוא package_member של כל קובץ
    tracked = [f for f in git("ls-files").splitlines() if RUNTIME.match(f) and SH.package_member(f, b"", False) is not None]
    missing = [f for f in tracked if not (x / "code" / f).is_file()]
    ok(not missing, "כל קובץ הרצה (%d) נמצא בחבילה" % len(tracked), ", ".join(missing[:6]))
    need = ["code/windows/install_windows.ps1", "code/windows/launcher.bat.txt", "code/windows/package_setup.bat.txt",
            "code/assets/app/icon.ico", "code/pipeline/scripts/make_short_page.html", "code/pipeline/scripts/make_short_app.py",
            "code/pipeline/scripts/make_short_selftest.py", "התקנה.bat", "קרא אותי.txt", "package.json"]
    ok(all((x / n).exists() for n in need), "חלקי ההתקנה, הדף, הסמל והבדיקה העצמית בפנים",
       ", ".join(n for n in need if not (x / n).exists()))
    # ההתקנה עצמה — הקטעים של install_windows.ps1, לבית זמני (כמו -DryRun)
    B = ps_blocks()
    if not ok(all(B.values()), "נמצאו קטעי ההתקנה ב-install_windows.ps1", ", ".join(k for k, v in B.items() if not v)):
        return
    home = T / "home"
    home.mkdir()
    for key, args in (("code", [str(x / "code"), str(home), meta.get("commit", "")]),
                      ("extras", [str(x / "extras"), str(home), "1"]),
                      ("verify", [str(home)])):
        sh = T / ("inst_%s.sh" % key)
        sh.write_text(B[key].replace("\r\n", "\n"), encoding="utf-8")
        r = subprocess.run(["bash", str(sh), *args], capture_output=True, text=True, errors="replace", timeout=600,
                           env=dict(os.environ, HOME=str(home)))
        ok(r.returncode == 0, "שלב ההתקנה \"%s\" עבר" % key, (r.stdout + r.stderr).strip()[-300:])
    D = home / "yeshiva-shorts-skill"
    ver = (D / ".from_package").read_text(encoding="utf-8").strip() if (D / ".from_package").exists() else ""
    ok(ver.split(" ")[0] == head, "הגרסה המותקנת = ה-commit הנוכחי", ver)
    diff = []
    for f in tracked:
        a, b = D / f, REPO / f
        if not a.is_file():
            diff.append(f + " (חסר)")
        else:
            want = subprocess.run(["git", "-C", str(REPO), "show", "HEAD:" + f], capture_output=True).stdout
            want = SH.package_member(f, want, False)[1]          # 4.1.0: אחרי הניטרול של מחרוזות הזהות
            if a.read_bytes() != want:
                diff.append(f)
    ok(not diff, "כל קובץ שהותקן זהה לגרסה ב-git (אחרי ניטרול מחרוזות הזהות)", ", ".join(diff[:6]))
    # 4.5.62 (בדיקת מכלול #1): הבדיקה העצמית חייבת לעבור גם *בתוך* התקנה של מקבל — אחרת כל שינוי מתיבת העדכון מתבטל לבד
    clean = {k: v for k, v in os.environ.items() if not k.startswith(("MAKE_SHORT", "SHORTS_"))}
    rr = subprocess.run([PY, "-u", str(D / "pipeline/scripts/make_short_selftest.py"), "units", "--json"], capture_output=True,
                        text=True, errors="replace", timeout=1500, cwd=str(home), env=dict(clean, HOME=str(home)))
    try:
        rj = json.loads(rr.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        rj = {"ok": False, "errors": ["אין פלט: " + (rr.stdout + rr.stderr)[-300:]]}
    ok(rj.get("ok"), "הבדיקה העצמית עוברת בתוך ההתקנה של המקבל (units)", "; ".join(rj.get("errors", []))[:600])
    bad_x = [f for f in tracked if f.endswith(".sh") and not os.access(D / f, os.X_OK)]
    ok(not bad_x, "סקריפטי ה-shell ניתנים להרצה אחרי ההתקנה", ", ".join(bad_x[:4]))
    ok((home / ".local/share/yeshiva-shorts/music/index.json").exists() or not SH.music_files(), "המוזיקה הותקנה עם האינדקס")
    ok(not (home / ".config/yeshiva-shorts/config.env").exists(), "אין config.env במחשב החדש (המקבל מחבר את שלו)")
    sv = json.loads((home / ".config/yeshiva-shorts/make_short_settings.json").read_text(encoding="utf-8")).get("values", {})
    ok(sv.get("view_mode") == "simple" and sv.get("first_steps_seen") is False and "profile_from" not in sv,
       "4.0: מקבל (חבילה בלי פרופיל) — תצוגה פשוטה, \"צעדים ראשונים\" ייפתח פעם אחת, בלי הודעת פרופיל", str(sv)[:200])
    # 3.5: החבילה בלי פרופיל — בדיוק כמו קודם: הלוגו וההנחיות שלו, בלי profile.json ובלי סימן פרופיל
    lg = SH.logo_file()
    with zipfile.ZipFile(zf) as z:
        ok("profile" not in meta and "extras/config/profile.json" not in z.namelist(), "חבילה בלי פרופיל: אין בה פרופיל (כמו עד 3.4)")
        if lg:
            ok(z.read("extras/config/brand/logo.png") == lg.read_bytes(), "חבילה בלי פרופיל: הלוגו שלו, כמו תמיד")
        g = SH.CONFIG / "guidelines.txt"
        if g.is_file():
            ok(z.read("extras/config/guidelines.txt") == g.read_bytes(), "חבילה בלי פרופיל: ההנחיות שלו, כמו תמיד")
    profile_package(T, env, B, meta.get("commit", ""), SH)
    return meta.get("commit", "")


def tiny_png(rgb=(10, 120, 200)):
    """PNG של פיקסל אחד (לוגו מלאכותי לבדיקה — אף פעם לא הלוגו שלו)."""
    import struct
    import zlib

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"\x00" + bytes(rgb))) + chunk(b"IEND", b""))


def his_state():
    """טביעה של ההגדרות והלוגו האמיתיים שלו — לפני ואחרי הבדיקה (אסור שישתנו)."""
    import hashlib
    cfg = real_config_dir()
    secret = {"config.env", "youtube_cookies.txt", "rclone.conf"}      # לא נקראים: רק גודל וזמן (שינוי יתגלה, התוכן לא)
    out = {}
    for f in sorted(cfg.rglob("*")):
        if not f.is_file() or f.suffix in (".lock", ".tmp"):
            continue
        rel = str(f.relative_to(cfg))
        # קבצים שהאפליקציה האמיתית (אם פתוחה אצלו בזמן הבדיקה) כותבת בעצמה — מוגנים בקוד (make_short_guard) ולא כאן,
        # אחרת כל לייק / תיקון רב שלו באמצע ריצה היה מפיל את הבדיקה (19/11)
        if rel in ("music-feedback.json", "glossary.json") or rel.startswith(("rabbis/", "share_profiles/")):
            continue
        s = f.stat()
        out[rel] = ("%d:%d" % (s.st_size, s.st_mtime_ns)) if f.name in secret else hashlib.sha256(f.read_bytes()).hexdigest()
    return out


def state_diff(a, b):
    return sorted(["חדש: " + k for k in b if k not in a] + ["נמחק: " + k for k in a if k not in b]
                  + ["השתנה: " + k for k in a if k in b and a[k] != b[k]])


def profile_unit_checks(T, env):
    """3.5: פרופילים למקבלים — שמירה / עריכה / מחיקה, כתיבה אצל המקבל בלי לדרוס, הפרדה בין חבילה רגילה לחבילות
    פרופיל, ו"בנייה מחדש לבד" שלא נוגעת בפרופילים (רק מי שסימן)."""
    say("\n▶ פרופילים למקבלים (3.5)")
    code = r'''
import json, os, sys, time, zipfile
from pathlib import Path
sys.path.insert(0, sys.argv[1])
T = Path(sys.argv[2]); png = bytes.fromhex(sys.argv[3])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import make_short_share as SH
chk(str(SH.PROFILES).startswith(str(T)), "הבדיקה עובדת על תיקיית פרופילים זמנית")
# 1. שמירה, רשימה, עריכה (הלוגו נשאר), שם כפול / סימנים אסורים / לא PNG — נדחים
p = SH.profile_save({"name": "ישיבת  בדיקה", "org_name": "ישיבת בדיקה", "footer_lines": "◄ אתר • https://example.org\n\n◄ עוד", "subscribe_text": ""}, png)
chk(p["name"] == "ישיבת בדיקה" and p["logo"] and (SH.PROFILES / p["id"] / "logo.png").read_bytes() == png, "פרופיל חדש נשמר עם הלוגו")
chk([x["id"] for x in SH.profiles()] == [p["id"]], "הפרופיל ברשימה")
e = SH.profile_save({"id": p["id"], "name": "ישיבת בדיקה 2", "org_name": "ישיבת בדיקה", "footer_lines": "◄ אתר • https://example.org"})
chk(e["name"] == "ישיבת בדיקה 2" and e["logo"] and len(SH.profiles()) == 1, "עריכה: השם השתנה, הלוגו נשאר, לא נוצר פרופיל נוסף")
bad = []
for d, lg in (({"name": ""}, None), ({"name": "א/ב"}, None), ({"name": "ישיבת בדיקה 2"}, None), ({"name": "חדש"}, b"GIF89a")):
    try:
        SH.profile_save(d, lg); bad.append(d["name"])
    except ValueError:
        pass
chk(not bad, "שם ריק / סימן אסור / שם כפול / קובץ שאינו PNG — נדחים", ", ".join(bad))
try:
    SH._pdir("../../etc"); chk(False, "מזהה פרופיל עם נתיב נדחה")
except ValueError:
    chk(True, "מזהה פרופיל עם נתיב נדחה")
# 2. מחיקה: לא rm — לתיקיית _deleted (בבדיקה), יוצא מהרשימה
q = SH.profile_save({"name": "למחיקה"}, None)
SH.profile_delete(q["id"])
chk(q["id"] not in [x["id"] for x in SH.profiles()] and any((SH.PROFILES / "_deleted").glob("*/" + q["id"] + "/profile.json")),
    "מחיקה: הפרופיל יצא מהרשימה ונשמר בצד (לא נמחק לגמרי)")
# 3. אצל המקבל: נכתב רק מה שאין לו; משפט הרשמה ריק בפרופיל לא נכתב; מה ששינה — לא נדרס
pj = T / "pj.json"; pj.write_text(json.dumps({"name": "x", "footer_lines": "◄ שלהם", "org_name": "ישיבתם", "subscribe_text": ""}, ensure_ascii=False), encoding="utf-8")
s1 = T / "r1" / "make_short_settings.json"
got = SH.apply_profile(pj, s1)
v = json.loads(s1.read_text(encoding="utf-8"))["values"]
chk(got == ["footer_lines", "org_name", "profile_from"] and v == {"footer_lines": "◄ שלהם", "org_name": "ישיבתם", "profile_from": "x"},
    "התקנה חדשה: השורות ושם הישיבה של הפרופיל נכתבו (משפט הרשמה ריק → הכללי) + שם הפרופיל (4.0)", str(v))
s2 = T / "r2" / "make_short_settings.json"; s2.parent.mkdir()
s2.write_text(json.dumps({"values": {"drive_on": False, "footer_lines": "◄ שלי"}}, ensure_ascii=False), encoding="utf-8")
SH.apply_profile(pj, s2)
v = json.loads(s2.read_text(encoding="utf-8"))["values"]
chk(v["footer_lines"] == "◄ שלי" and v["drive_on"] is False and v["org_name"] == "ישיבתם", "התקנה מחדש: מה שהמקבל שינה נשאר, רק החסר נוסף", str(v))
SH.apply_profile(pj, s2)
chk(json.loads(s2.read_text(encoding="utf-8"))["values"] == v, "התקנה שלישית: כלום לא משתנה")
# 4. חבילה רגילה וחבילות פרופיל באותה תיקייה — "ישן / בנה מחדש / לסל" של הרגילה לא רואים את הפרופילים
D = T / "zips"; D.mkdir()
def fake(name, meta, age):
    f = D / name
    with zipfile.ZipFile(f, "w") as z: z.writestr("package.json", json.dumps(dict(meta, format=1)))   # 4.1.0: "שלנו" = format + commit
    os.utime(f, (time.time() - age, time.time() - age)); return f
old_reg = fake("reg_old.zip", {"commit": "0000000 x"}, 300)
prof_z = fake("prof.zip", {"commit": "0000000 x", "profile": {"id": p["id"], "name": "x"}}, 10)
new_reg = fake("reg_new.zip", {"commit": "0000000 x"}, 100)
chk([z.name for z in SH.zip_list(D)] == ["reg_new.zip", "reg_old.zip"], "רשימת החבילות הרגילות בלי חבילות הפרופילים")
chk(SH.stale_info(D)["file"] == "reg_new.zip" and SH.stale_info(D, p["id"])["file"] == "prof.zip", "\"ישן?\" נבדק לכל סוג בנפרד")
SH.prune(D, new_reg)
chk(prof_z.exists() and not old_reg.exists(), "ניקוי אחרי בנייה רגילה: הישנה הרגילה הוסרה, חבילת הפרופיל לא נגעו בה")
pv = SH.profiles_view(D)
chk(pv and pv[0]["zip"] == "prof.zip" and pv[0]["stale"], "בחלון: החבילה של הפרופיל ישנה → \"⚠ החבילה ישנה — בנה מחדש\"")
# 5. השרת: "בנייה מחדש לבד" — פרופילים רק אם סימן בהם (ברירת מחדל כבוי), הרגילה בלי --profile
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked in selftest"))
import make_short_app as A
calls = []
A.start_job = lambda kind, cmd, **k: calls.append(cmd) or "j"
A.server_idle = lambda: True
chk(A.share_profile_autorebuild({"profiles": pv}) is None and not calls, "פרופיל שלא סימן \"🔄 לבנות מחדש לבד\" — לא נבנה לבד (ברירת מחדל)")
chk(SH.profile_get(p["id"])["auto_rebuild"] is False, "\"🔄 לבנות מחדש לבד\" כבוי כברירת מחדל")
A.share_profile_autorebuild({"profiles": [dict(pv[0], auto_rebuild=True)]})
chk(calls and calls[-1][-2:] == ["--profile", p["id"]], "פרופיל שסימן — נבנה לבד (רק הוא)")
src = Path(sys.argv[1], "make_short_app.py").read_text(encoding="utf-8")
i = src.index("share_auto_rebuild\") and s.get(\"stale\")")
chk("--profile" not in src[i:i + 500].split("else:")[0], "הבנייה הרגילה אחרי עדכון — בלי פרופיל, כמו קודם")
print(json.dumps(out, ensure_ascii=False))
'''
    (T / "punit").mkdir(exist_ok=True)
    r = subprocess.run([PY, "-c", code, str(HERE), str(T / "punit"), tiny_png().hex()],
                       env=dict(env, SHORTS_SHARE_PROFILES=str(T / "punit" / "profiles")), capture_output=True,
                       text=True, errors="replace", timeout=300, cwd=str(T))
    try:
        res = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return ok(False, "בדיקת הפרופילים רצה", (r.stdout + r.stderr).strip()[-400:])
    for c, w, d in res:
        ok(c, w, d)


def profile_package(T, env, B, commit, SH):
    """3.5: חבילה עם פרופיל בדיקה → הלוגו / השורות / שם הישיבה שלו, הנחיות ניטרליות, ושום דבר של הבעלים;
    ההתקנה (הקטעים של install_windows.ps1) לבית זמני, ואז התקנה מחדש שלא דורסת מה שהמקבל שינה."""
    import hashlib
    say("\n▶ חבילת שיתוף עם פרופיל למקבל (3.5)")
    # /tmp ב-WSL הוא דיסק בזיכרון (~2GB) — החבילה הרגילה, החילוץ וההתקנה שלה (~600MB) מפנים מקום קודם.
    # רק תת-תיקיות של תיקיית הבדיקה הזמנית עצמה.
    if T.name.startswith("ys_selftest_"):
        for sub in ("share", "extract", "home"):
            if (T / sub).is_dir() and (T / sub).resolve().parent == T.resolve():
                shutil.rmtree(T / sub, ignore_errors=True)
    png = tiny_png((200, 30, 30))
    p = SH.profile_save({"name": "ישיבת הבדיקה", "org_name": "ישיבת הבדיקה לפרופיל",
                         "footer_lines": "◄ אתר הבדיקה • https://example.org/profile\n◄ וואטסאפ • https://example.org/wa",
                         "subscribe_text": "🔔 הירשמו לערוץ הבדיקה"}, png)
    out = T / "share_p"
    r = subprocess.run([PY, "-u", str(HERE / "make_short_share.py"), "build", "--out", str(out), "--profile", p["id"]], env=env,
                       capture_output=True, text=True, errors="replace", timeout=900)
    zf = next((Path(l[5:].strip()) for l in r.stdout.splitlines() if l.startswith("FILE=")), None)
    if not ok(r.returncode == 0 and zf and zf.exists(), "חבילה עם פרופיל נבנתה", (r.stdout + r.stderr).strip()[-300:]):
        return
    ok(p["name"] in zf.name and SH.tool_version() in zf.name, "שם הקובץ כולל את שם הפרופיל והגרסה", zf.name)
    ok(not SH.scan(zf), "סריקת הסודות הרגילה עברה גם בחבילת פרופיל")
    needles = SH.his_strings()
    ok(len(needles) >= 3, "יש רשימה של המחרוזות שלו לבדיקה (%d)" % len(needles))
    ok(not SH.identity_scan(zf), "בחבילת הפרופיל אין את הלוגו, הקישורים, שם הישיבה ומשפט ההרשמה שלו", ", ".join(SH.identity_scan(zf)[:5]))
    with zipfile.ZipFile(zf) as z:
        meta = json.loads(z.read("package.json"))
        ok((meta.get("profile") or {}).get("id") == p["id"], "package.json מסמן את הפרופיל")
        ok(z.read("extras/config/brand/logo.png") == png, "הלוגו בחבילה = הלוגו של הפרופיל")
        ok(z.read("extras/config/guidelines.txt") == SH.NEUTRAL_GUIDELINES.read_bytes(), "ההנחיות בחבילה = ההנחיות הכלליות")
        gl = SH.NEUTRAL_GUIDELINES.read_text(encoding="utf-8")
        ok(not re.search(r"https?://|www\.|@\w", gl), "בהנחיות הכלליות אין אף קישור")
        x = T / "extract_p"
        z.extractall(x)
    # שום עותק של הלוגו שלו בחבילה, גם לא בשם אחר
    mine = SH.his_logo_hashes()
    ok(not any(hashlib.sha256(f.read_bytes()).hexdigest() in mine for f in x.rglob("*.png")), "אף קובץ PNG בחבילה אינו הלוגו שלו")
    # התקנה לבית זמני
    home = T / "home_p"
    home.mkdir()

    def inst(key, args):
        sh = T / ("instp_%s.sh" % key)
        sh.write_text(B[key].replace("\r\n", "\n"), encoding="utf-8")
        rr = subprocess.run(["bash", str(sh), *args], capture_output=True, text=True, errors="replace", timeout=600,
                            env=dict(os.environ, HOME=str(home)))
        ok(rr.returncode == 0, "התקנת חבילת פרופיל — שלב \"%s\"" % key, (rr.stdout + rr.stderr).strip()[-300:])
    inst("code", [str(x / "code"), str(home), commit])
    inst("extras", [str(x / "extras"), str(home), "1"])
    cfg = home / ".config/yeshiva-shorts"
    v = json.loads((cfg / "make_short_settings.json").read_text(encoding="utf-8")).get("values", {})
    ok(v.get("footer_lines") == p["footer_lines"] and v.get("org_name") == p["org_name"] and v.get("subscribe_text") == p["subscribe_text"]
       and v.get("drive_on") is False, "אצל המקבל: השורות, שם הישיבה ומשפט ההרשמה של הפרופיל (והדרייב כבוי כמו שביקש)", str(v)[:200])
    ok((cfg / "brand/logo.png").read_bytes() == png, "אצל המקבל: הלוגו של הפרופיל")
    ok(v.get("view_mode") == "simple" and v.get("first_steps_seen") is False and v.get("profile_from") == p["name"],
       "4.0: מקבל עם פרופיל — תצוגה פשוטה, \"צעדים ראשונים\" עוד לא נראה, ונרשם מאיזה פרופיל (להודעה)", str(v)[:200])
    ok((cfg / "guidelines.txt").read_bytes() == SH.NEUTRAL_GUIDELINES.read_bytes(), "אצל המקבל: ההנחיות הכלליות")
    # התקנה מחדש אחרי שהמקבל שינה — לא נדרס
    vals = dict(v, footer_lines="◄ השורות שהמקבל כתב", view_mode="advanced", first_steps_seen=True, profile_from="שיניתי")
    (cfg / "make_short_settings.json").write_text(json.dumps({"values": vals}, ensure_ascii=False), encoding="utf-8")
    (cfg / "brand/logo.png").write_bytes(tiny_png((1, 2, 3)))
    inst("extras", [str(x / "extras"), str(home), "1"])
    v2 = json.loads((cfg / "make_short_settings.json").read_text(encoding="utf-8")).get("values", {})
    ok(v2.get("footer_lines") == "◄ השורות שהמקבל כתב" and (cfg / "brand/logo.png").read_bytes() == tiny_png((1, 2, 3)),
       "התקנה מחדש מעל: השורות והלוגו שהמקבל שינה נשארו")
    ok(v2.get("view_mode") == "advanced" and v2.get("first_steps_seen") is True and v2.get("profile_from") == "שיניתי",
       "4.0: התקנה מחדש לא מחזירה לפשוט, לא פותחת שוב את \"צעדים ראשונים\" ולא דורסת את סימן הפרופיל", str(v2)[:200])


# ─────────────── 4.0: תצוגה פשוטה / מתקדמת + צעדים ראשונים ───────────────

# ההגדרות שבתצוגה הפשוטה (כל השאר מוסתרות — וממשיכות לעבוד עם הערך שלהן). הגדרה חדשה חייבת להיכנס לאחת הרשימות.
SIMPLE_KEYS = {"modal_day_cap", "music_on", "music_level", "logo_on", "auto_burn", "smart_editor", "hook_on", "hook_sfx",
               "org_name", "footer_lines", "subscribe_text", "fixed_tags", "drive_on"}
ADV_KEYS = {"share_auto_rebuild", "chat_code_chars", "smart_music", "logo2_on", "logo2_glow", "logo_glow", "marker_opacity",
            "float_shadow", "float_shadow_opacity", "float_shadow_size", "box_color", "box_opacity", "skip_text_check",
            "editor_window_min", "editor_cap_min", "glossary_asr_hint", "emph_default", "camera_check", "exit_fix",
            "camera_default", "tab_layout", "playlist_mode", "playlist_auto_max", "playlist_top_n", "gemini_model",
            "chat_chunk_chars", "gemini_chunk_chars", "gm_pick", "gm_playlist", "gm_rank", "gm_editor", "gm_alts",
            "gemini_margin", "auto_skips", "modal_all_lessons", "modal_missing"}
# מוסתרים בפשוט (לפי id) — ושום דבר אחר מהדף הסטטי
ADV_IDS = {"shareSet", "updSet", "toolsCard", "musicAdv", "subsAdv", "stylesCard", "skipSet", "edTiming", "glossSet",
           "rabSet", "emphSet", "gemAdv", "propOwner"}
# הדרך מקישור לשורט שמור + מה שנשאר בפשוט — אסור שיהיו בתוך משהו מוסתר
MUST_SHOW_IDS = {"url", "bPick", "bManual", "rabbi", "series", "setBtn", "viewBtn", "fsBtn", "fsBtn2", "gemKey", "bSaveKey",
                 "themeSeg", "engSeg", "colors", "cookieFile", "fsDlg", "tabs", "vPick", "vLesson", "health", "banners"}


def page_tree():
    """הדף הסטטי: לכל אלמנט — תגית, מאפיינים, והאם הוא בתוך משהו שמסומן adv."""
    from html.parser import HTMLParser
    VOID = {"input", "br", "img", "meta", "link", "hr", "source", "col", "area", "base", "wbr", "track", "embed", "param"}
    out, stack = [], []

    class P(HTMLParser):
        def handle_starttag(self, tag, attrs):
            a = {k: (v or "") for k, v in attrs}
            cls = a.get("class", "").split()
            under = any(s[1] for s in stack)
            out.append({"tag": tag, "a": a, "adv": "adv" in cls, "under": under})
            if tag not in VOID:
                stack.append((tag, under or "adv" in cls))

        def handle_endtag(self, tag):
            for i in range(len(stack) - 1, -1, -1):
                if stack[i][0] == tag:
                    del stack[i:]
                    break
    src = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    body = src[src.index("<body>"):src.rindex("<script>")]   # רק ה-HTML; התבניות שבקוד נבדקות בנפרד
    P().feed(body)
    return src, out


def view_checks(T, env):
    say("\n▶ תצוגה פשוטה / מתקדמת וצעדים ראשונים (4.0)")
    src, els = page_tree()
    css = src[src.index("<style>"):src.index("</style>")]
    ok("body.simple .adv{display:none!important}" in css, "כלל אחד מסתיר את המתקדם — רק כשבגוף הדף יש simple")
    ok(re.findall(r"[^\n]*\.adv\b[^\n]*", css) == ["body.simple .adv{display:none!important}"],
       "מתקדם = הדף של היום: אין שום כלל אחר על .adv (אף אלמנט לא מוסתר במתקדם)")
    ok("simponly" not in css or "body:not(.simple) .simponly" in css, "הסבר של פשוט מופיע רק בפשוט")
    keys = {}
    for e in els:
        k = e["a"].get("data-k")
        if k:
            keys[k] = e["under"] or e["adv"]
    hid = {k for k, h in keys.items() if h}
    vis = set(keys) - hid
    ok(vis == SIMPLE_KEYS, "בפשוט נשארות בדיוק ההגדרות שסוכמו", "עודף: %s · חסר: %s" % (sorted(vis - SIMPLE_KEYS), sorted(SIMPLE_KEYS - vis)))
    ok(hid == ADV_KEYS, "בפשוט מוסתרות בדיוק ההגדרות המתקדמות", "עודף: %s · חסר: %s" % (sorted(hid - ADV_KEYS), sorted(ADV_KEYS - hid)))
    ids_adv = {e["a"].get("id") for e in els if e["adv"] and e["a"].get("id")}
    ok(ADV_IDS <= ids_adv, "החלקים המתקדמים מסומנים (שיתוף, עדכון, צ'אט, כלים, פלטות, עורך, מילון, רבנים…)", str(sorted(ADV_IDS - ids_adv)))
    cards = {(e["a"].get("data-sec"), e["adv"]) for e in els if "card" in e["a"].get("class", "").split() and e["a"].get("data-sec")}
    ok({s for s, a in cards if a and s in ("camera", "tabs", "rules")} == {"camera", "tabs", "rules"},
       "המצלמה, הלשוניות וכללי העריכה — מתקדם בלבד")
    ok(any(e["a"].get("data-slot") == "right" and e["adv"] for e in els), "סמל: בפשוט רק פינה אחת (הימנית מתקדם)")
    bad = sorted(e["a"]["id"] for e in els if e["a"].get("id") in MUST_SHOW_IDS and (e["under"] or e["adv"]))
    ok(not bad, "שום דבר שצריך משיעור לשורט שמור לא מוסתר בפשוט", str(bad))
    miss = sorted(MUST_SHOW_IDS - {e["a"].get("id") for e in els})
    ok(not miss, "כל האלמנטים החיוניים קיימים בדף", str(miss))
    vb = next((e for e in els if e["a"].get("id") == "viewBtn"), None)
    ok(vb and vb["a"].get("role") == "switch" and "vsw" in vb["a"].get("class", ""), "4.0.1: פשוט/מתקדם הוא מתג (role=switch) עם שתי התוויות")
    ok(".vsw.on-adv::before" in css and "nowrap" in css[css.index(".top.bar"):], "4.0.1: השורה העליונה דחוסה לשורה אחת (בלי לשבור כפתור לשתי שורות)")
    lg = next((e for e in els if "applogo" in e["a"].get("class", "")), None)
    ok(lg and lg["a"].get("src") == "/icon-192.png", "4.0.2: סמל התוכנה (לא הלוגו של הישיבה) לפני השם")
    ok('<div class="ttlblk"><h1>' in src and 'id="verTag"' in src[src.index('class="ttlblk"'):src.index('class="ttlblk"') + 300],
       "4.0.2: מספר הגרסה מתחת לשם")
    ok('🧭<span class="blbl"> צעדים ראשונים</span>' in src and "#fsBtn .blbl{display:none}" in css,
       "4.0.2: 🧭 עם תווית; רק במסך צר (מתחת ל-1100) — סמל בלבד, השם ברמז")
    past = [e for e in els if "openPast()" in e["a"].get("onclick", "")]
    ok(past and not any(e["under"] or e["adv"] for e in past), "📂 שיעורים קודמים — גלוי בפשוט")
    js = src[src.rindex("<script>"):]
    # תבניות בקוד: מה שבכרטיס הקליף
    def lines(s):
        return [l for l in js.splitlines() if s in l]
    ok(all("rt adv" in l for l in lines("data-scene><summary")), "📜 הקטע והסביבה — מתקדם")
    ok(lines("data-rt><summary") and all('class="rt" data-rt>' in l for l in lines("data-rt><summary")), "✂️ התחלה/סוף — גלוי בפשוט")
    must_js = ("dropClip(", "data-fin1", "data-mnext", "data-monoff", "data-col=", "data-rnd", "data-xfix")

    def tag_of(l, m):                                  # התגית שבה מופיע הסימן
        i = l.index(m)
        return l[l.rfind("<", 0, i):l.find(">", i) + 1]
    leak = [m for m in must_js if not lines(m) or any(re.search(r"class=\"[^\"]*\badv\b", tag_of(l, m)) for l in lines(m))]
    ok(not leak, "בכרטיס: ויתרתי, שמירה, מוזיקה, צבע/סגנון ו\"בנה שוב במצלמה זריזה\" (באזהרה) — לא מוסתרים", str(leak))
    cam = [l for l in js.splitlines() if "המצלמה מקפצת? בנה במצלמה חלקה" in l]
    ok(cam and "hint adv" in cam[0], "\"בנה שוב במצלמה\" בלי אזהרה — מתקדם; עם אזהרה — גלוי")
    warn = [l for l in js.splitlines() if "הרב לא תמיד במרכז הפריים" in l]
    ok(warn and "adv" not in warn[0], "אזהרת מצלמה אמיתית נשארת בפשוט")
    ok('${q.camera||(c.exits&&c.exits.sec)?"":"adv"}' in js, "שורת המצלמה ב\"⚡\" — רק כשיש יציאה מהמסגרת או שינוי שבחרתם")
    ok("first_steps_seen===false){openFirst();setS({first_steps_seen:true})" in js.replace(" ", ""),
       "צעדים ראשונים נפתח לבד רק כשלא נראה — ומיד מסומן \"נראה\"")
    ok("Workspace budget — להגדיר 30 (דולר) — כגובה הקרדיט החודשי החינמי. כך לעולם לא תשלמו מעבר אליו" in js,       # 4.5.62: שם המסך המדויק
       "Modal: ההמלצה על תקרה של 30$ כתובה במפורש")
    ok("הפרטים האלה הגיעו מוכנים עם התוכנה (פרופיל" in js, "הודעת \"הגיעו מוכנים\" לפרופיל מלא")
    # ההגדרות: מעבר בעלים, התקנה חדשה, מקבל
    code = r'''
import json, os, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import importlib, make_short_settings as SET, make_short_share as SH
def at(p):
    SET.PATH = p
    return SET
# 1. התקנה חדשה (אין קובץ) — פשוט, עוד לא ראה
p = T / "fresh.json"; at(p)
v = SET.load(); chk(v["view_mode"] == "simple" and v["first_steps_seen"] is False, "התקנה חדשה: 🙂 פשוט, צעדים ראשונים ייפתח")
chk(SET.ensure_view() is False and not p.exists(), "התקנה חדשה: הפתיחה לא יוצרת קובץ")
SET.update({"music_on": False}); v = SET.load()
chk(v["view_mode"] == "simple" and json.loads(p.read_text())["values"]["view_mode"] == "simple", "שינוי הגדרה ראשון בהתקנה חדשה לא הופך אותה ל\"מלפני 4.0\"")
SET.update({"first_steps_seen": True}); chk(SET.load()["first_steps_seen"] is True, "אחרי שנפתח פעם אחת — מסומן, ולא נפתח שוב")
# 2. הבעלים: קובץ מלפני 4.0 — מתקדם, בלי מסך פתיחה, וכל ההגדרות שלו כמו שהיו
o = T / "owner.json"; o.write_text(json.dumps({"values": {"music_level": 2, "org_name": "ישיבה"}, "undo": {"values": {"music_on": True}}}, ensure_ascii=False)); at(o)
before = {k: x for k, x in SET.load().items() if k not in SET.VIEW_KEYS}
v = SET.load(); chk(v["view_mode"] == "advanced" and v["first_steps_seen"] is True, "הבעלים (קובץ מלפני 4.0): 🛠️ מתקדם, בלי צעדים ראשונים")
chk(SET.ensure_view() is True and json.loads(o.read_text())["values"]["view_mode"] == "advanced", "המעבר נשמר בכתב בפתיחה הראשונה")
chk(SET.ensure_view() is False, "פתיחה שנייה — לא נוגעים")
after = {k: x for k, x in SET.load().items() if k not in SET.VIEW_KEYS}
chk(before == after and json.loads(o.read_text()).get("undo"), "המעבר לא שינה אף הגדרה אחרת (וגם לא את \"בטל\")")
# 3. מעבר תצוגה לא משנה שום הגדרה; "אפס הכול" לא נוגע בתצוגה
SET.update({"view_mode": "simple"}); mid = {k: x for k, x in SET.load().items() if k not in SET.VIEW_KEYS}
SET.update({"view_mode": "advanced"}); back = {k: x for k, x in SET.load().items() if k not in SET.VIEW_KEYS}
chk(before == mid == back, "פשוט ↔ מתקדם: שום הגדרה אחרת לא זזה")
SET.reset(None); v = SET.load(); chk(v["view_mode"] == "advanced" and v["first_steps_seen"] is True, "\"אפס הכול\" לא מעביר לפשוט ולא פותח שוב את הצעדים הראשונים")
try:
    SET.update({"view_mode": "weird"}); chk(False, "תצוגה לא מוכרת נדחית")
except ValueError:
    chk(True, "תצוגה לא מוכרת נדחית")
# 4. מקבל: ההתקנה כותבת drive_on (בלי דרייב), פרופיל, ואז receiver-init — פשוט + עוד לא ראה + שם הפרופיל
r = T / "recv.json"; r.write_text(json.dumps({"values": {"drive_on": False}}))
pj = T / "pj.json"; pj.write_text(json.dumps({"name": "ישיבת המקבל", "org_name": "ישיבת המקבל", "footer_lines": "◄ שלו"}, ensure_ascii=False), encoding="utf-8")
SH.apply_profile(pj, r); SH.receiver_init(r); at(r); v = SET.load()
chk(v["view_mode"] == "simple" and v["first_steps_seen"] is False and v["profile_from"] == "ישיבת המקבל" and v["drive_on"] is False,
    "מקבל: 🙂 פשוט, צעדים ראשונים ייפתח, ונרשם הפרופיל", str({k: v[k] for k in SET.VIEW_KEYS}))
chk(SET.ensure_view() is False, "אצל מקבל המעבר של הבעלים לא חל (כבר כתוב \"פשוט\")")
e = T / "empty.json"; ep = T / "ep.json"; ep.write_text(json.dumps({"name": "ריק"}, ensure_ascii=False), encoding="utf-8")
SH.apply_profile(ep, e); SH.receiver_init(e); at(e); v = SET.load()
chk(v["profile_from"] == "ריק" and not v["org_name"] and not v["footer_lines"], "פרופיל ריק: נרשם השם, השדות ריקים (בלי \"הגיעו מוכנים\")")
n = T / "noprof.json"; SH.receiver_init(n); at(n); v = SET.load()
chk(v["view_mode"] == "simple" and v["first_steps_seen"] is False and v["profile_from"] == "", "חבילה בלי פרופיל: פשוט, צעדים ראשונים, בלי שם פרופיל")
print(json.dumps(out, ensure_ascii=False))
'''
    (T / "vunit").mkdir(exist_ok=True)
    r = subprocess.run([PY, "-c", code, str(HERE), str(T / "vunit")], env=env, capture_output=True,
                       text=True, errors="replace", timeout=120, cwd=str(T))
    try:
        res = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return ok(False, "בדיקת התצוגה רצה", (r.stdout + r.stderr).strip()[-400:])
    for c, w, d in res:
        ok(c, w, d)


def shim_checks(T, env):
    """4.0.4: פותח-דפדפן לחלונות השחורים (דרייב / Modal). אצל הבעלים ב-WSL אין xdg-open, ו-rclone רק הדפיס קישור.
    נבדק עם rclone מזויף שקורא ל-$BROWSER — בלי לפתוח באמת דפדפן (YS_OPEN_LOG רושם במקום)."""
    say("\n▶ פתיחת דפדפן מהחלון השחור (4.0.4)")
    code = r'''
import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked"))
import make_short_app as A
lines = A.browser_shim_lines()
shim = T / "data" / "bin" / "xdg-open"
src = Path(sys.argv[1]).parents[1] / "setup" / "wsl_open.sh"
chk(shim.is_file() and os.access(shim, os.X_OK) and shim.read_bytes() == src.read_bytes(), "פותח-הדפדפן נוצר לבד, ניתן להרצה, זהה לקובץ שבריפו")
chk(str(shim.parent) in lines and "export BROWSER=" in lines and "קליק ימני" in lines and "Ctrl+Shift+C" not in lines, "סקריפט החלון: הפותח ראשון ב-PATH, BROWSER, וההסבר בעברית")
fake = T / "fakebin"; fake.mkdir(exist_ok=True)
url = "http://127.0.0.1:53682/auth?state=a1B2&x=1;y=2"
(fake / "rclone").write_text("#!/bin/bash\necho 'go to the following link: %s'\n\"${BROWSER:-xdg-open}\" '%s'\nexit 0\n" % (url, url))
os.chmod(fake / "rclone", 0o755)
log = T / "opened.txt"
sh = T / "t.sh"; sh.write_text("#!/bin/bash\n" + lines + "export PATH=%s:$PATH\nrclone config reconnect gdrive:\n" % fake, encoding="utf-8")
r = subprocess.run(["bash", str(sh)], capture_output=True, text=True, env=dict(os.environ, YS_OPEN_LOG=str(log)), timeout=60)
chk(log.is_file() and log.read_text().strip() == url, "rclone (מזויף) פתח את הקישור דרך הפותח — הקישור שלם, עם & ו-;", log.read_text() if log.is_file() else r.stderr[-200:])
chk(url in r.stdout and "אם הדפדפן לא נפתח" in r.stdout, "הקישור עדיין מודפס בחלון (גיבוי) + ההסבר")
r2 = subprocess.run([str(shim), "file:///etc/passwd"], capture_output=True, text=True, env=dict(os.environ, YS_OPEN_LOG=str(log)))
chk(r2.returncode == 2, "הפותח מסרב לכל מה שאינו http/https")
print(json.dumps(out, ensure_ascii=False))
'''
    (T / "shim").mkdir(exist_ok=True)
    r = subprocess.run([PY, "-c", code, str(HERE), str(T / "shim")], env=dict(env, SHORTS_DATA_DIR=str(T / "shim" / "data")),
                       capture_output=True, text=True, errors="replace", timeout=120, cwd=str(T))
    try:
        res = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return ok(False, "בדיקת פותח-הדפדפן רצה", (r.stdout + r.stderr).strip()[-400:])
    for c, w, d in res:
        ok(c, w, d)


def own_key_checks(T, env):
    """4.0.5: "מפתח אישי" לדרייב שנקטע באמצע (Ctrl+C / חלון או שרת שנסגרו) — לא ירוק כוזב, החיבור הקודם חוזר,
    וחיבור שהסתיים לא מוחזר לעולם. rclone מזויף (קורא וכותב קובץ הגדרות זמני) — שום דבר של הבעלים."""
    say("\n▶ מפתח אישי לדרייב — ניסיון שנקטע / שהסתיים (4.0.5)")
    code = r'''
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
conf = T / "rclone.conf"
fake = T / "rclone"
fake.write_text("""#!/usr/bin/env python3
import sys, json, configparser
C = %r
a = sys.argv[1:]
cp = configparser.RawConfigParser(); cp.read(C)
if a[:2] == ["config", "file"]: print("Configuration file is stored at:"); print(C)
elif a[:2] == ["config", "dump"]: print(json.dumps({s: dict(cp.items(s)) for s in cp.sections()}))
elif a[:2] == ["config", "update"]:
    kv = [x for x in a[3:] if not x.startswith("--")]
    for k, v in zip(kv[0::2], kv[1::2]):
        if k != "config_refresh_token": cp.set(a[2], k, v)
    cp.write(open(C, "w"))
elif a[:1] == ["listremotes"]: print("gdrive:")
elif a[:1] == ["lsf"]: pass
sys.exit(0)
""" % str(conf))
os.chmod(fake, 0o755)
import make_short_health as H
H.RCLONE = str(fake)
# (המילים מפוצלות בכוונה: סריקת הסודות של חבילת השיתוף מחפשת "token =" / "secret =" — גם בקוד הבדיקה)
SHARED = '[gdrive]\ntype = drive\nscope = drive.file\n' + 'tok' + 'en = {"access_token":"OLD","refresh_' + 'token":"R1"}\n'
def setup(cur, before=None, pending=False, ok=False):
    for p in H.own_key_paths(conf).values(): p.unlink(missing_ok=True)
    conf.write_text(cur)
    if before is not None: H.own_key_paths(conf)["before"].write_text(before)
    if pending: H.own_key_paths(conf)["pending"].write_text("x")
    if ok: H.own_key_paths(conf)["ok"].write_text("x")
    H.DRIVE_NOTE[0] = ""
HALF = SHARED.replace("type = drive", "type = drive\nclient_id = 123-abc.apps.googleusercontent.com\nclient_" + "sec" + "ret = s")
DONE = HALF.replace("OLD", "NEW").replace("R1", "R2")
P = H.own_key_paths(conf)
# 1. נקטע (עם סימן): client_id חדש, טוקן ישן → לא ירוק; בפתיחה — מוחזר, וההתראה עם הטופס וההסבר
setup(HALF, SHARED, pending=True)
r = H.check_drive(True)
chk(r["level"] == "warn" and r.get("form") == "drive_key", "נקטע: לא ירוק כוזב — ההתראה והטופס מוצגים", r["title"])
st = H.own_key_recover(H.rclone_conf(), busy=False)
r = H.check_drive(True)
chk(st == "restored" and conf.read_text() == SHARED and not P["before"].exists() and not P["pending"].exists(),
    "נקטע: ההגדרות הקודמות הוחזרו במדויק, הסימנים נוקו", st)
chk(r.get("form") == "drive_key" and H.INTERRUPTED in r["detail"], "אחרי ההחזרה: הטופס מוצג עם \"הניסיון הקודם נקטע\"")
# 2. המצב שנשאר אצל הבעלים (לפני 4.0.5): עותק "לפני" בלי שום סימן, client_id חדש, טוקן ישן → מוחזר
setup(HALF, SHARED)
chk(H.own_key_recover(H.rclone_conf()) == "restored" and conf.read_text() == SHARED, "מצב מלפני 4.0.5 (עותק בלי סימן) — מתוקן")
# 3. הושלם אבל השרת לא הספיק לסמן: טוקן חדש → own_key_ok, לא מוחזר לעולם
setup(DONE, SHARED, pending=True)
st = H.own_key_recover(H.rclone_conf())
r = H.check_drive(True)
chk(st == "done" and conf.read_text() == DONE and P["ok"].exists() and r["level"] == "ok", "חיבור שהסתיים — מסומן ירוק, לא מוחזר", st)
chk(r.get("key_steps"), "גם כשירוק — השלבים נשלחים (לטופס מ\"🩺 בדיקת מערכת\")")
# 4. חלון שחור עוד פתוח (שרת שנפתח מחדש באמצע) — לא נוגעים
setup(HALF, SHARED, pending=True)
chk(H.own_key_recover(H.rclone_conf(), busy=True) == "busy" and conf.read_text() == HALF and P["pending"].exists(),
    "באמצע חיבור (חלון שחור פתוח) — שום שינוי עד שהוא נסגר")
# 5. מפתח אישי שהוגדר ביד (בלי עותק "לפני") — ירוק כמו תמיד
setup(DONE)
chk(H.check_drive(True)["level"] == "ok" and H.own_key_recover(H.rclone_conf()) == "none", "מפתח שהוגדר ביד — ירוק, בלי שינוי")
# 6. כל הזרימה באפליקציה: "שמור וחבר" → נקטע (rclone יצא ב-130) → הוחזר; ואז שוב → הושלם → ירוק
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked"))
import make_short_app as A
A.HEALTH.RCLONE = str(fake); A.rclone_busy = lambda: False
def flow(rc):
    os.environ["MAKE_SHORT_FAKE_RECONNECT"] = rc
    A.HEALTH_STATE.setdefault("actions", {}).pop("drive_reconnect", None)
    A.drive_own_key("123-abc.apps.googleusercontent.com", "GOCSPX-test_secret_1")
    # 4.1.0: הבדיקה הישנה כאן (pending או ok או אין before) הייתה ריקה — תמיד אמת. הבדיקות החזקות של "באמצע",
    # נעילה כפולה, קריסה, ו-lsf שנופל אחרי הצלחה — ב-make_short_selftest_410.ownkey_checks
    for _ in range(40):
        a = A.HEALTH_STATE["actions"].get("drive_reconnect", {})
        if a.get("state") in ("ok", "fail"): return a
        time.sleep(0.5)
    return {}
setup(SHARED)
a = flow("130")
chk(a.get("state") == "fail" and conf.read_text() == SHARED and not P["pending"].exists() and not P["before"].exists(),
    "אפליקציה: חיבור שנקטע → ההגדרות הקודמות חזרו, בלי סימנים", str(a))
setup(SHARED)
a = flow("0")
chk(a.get("state") == "ok" and P["ok"].exists() and not P["pending"].exists() and "client_id" in conf.read_text(),
    "אפליקציה: חיבור שהסתיים → סימן own_key_ok, ירוק", str(a))
print(json.dumps(out, ensure_ascii=False))
'''
    (T / "okey").mkdir(exist_ok=True)
    r = subprocess.run([PY, "-c", code, str(HERE), str(T / "okey")], env=env, capture_output=True,
                       text=True, errors="replace", timeout=180, cwd=str(T))
    try:
        res = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return ok(False, "בדיקת המפתח האישי רצה", (r.stdout + r.stderr).strip()[-500:])
    for c, w, d in res:
        ok(c, w, d)


def last_path():
    """התוצאה האחרונה — לבלוק "🐞 מצאתי באג" שמעתיקים לצ'אט (27/10). MAKE_SHORT_SELFTEST_LAST = קובץ אחר (בדיקות)."""
    return Path(os.environ.get("MAKE_SHORT_SELFTEST_LAST") or
                Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts")) / "selftest_last.json")


def save_last(res):
    try:
        p = last_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(p)
    except OSError:
        pass


def extras_checks(T, env):
    """4.1.0: גיבוי "גיבוי תוכנה" — היסטוריית דריסות, מפתחות בתוך .md, שמות חשודים מדווחים, קישור סמלי, נעילה, יומן, פסק זמן."""
    say("\n▶ גיבוי התוכנה ל-Drive: היסטוריה, סודות, נעילה (4.1.0)")
    if not shutil.which("rclone") and not os.path.exists(os.path.expanduser("~/.local/bin/rclone")):
        NOTES.append("בדיקות גיבוי התוכנה (4.1.0) לא רצו: אין rclone במחשב")
        return
    X = T / "ex"
    D, C, R, W = X / "data", X / "cfg", X / "remote", X / "win"
    tracks = D / "music" / "tracks"
    tracks.mkdir(parents=True)
    C.mkdir(parents=True)
    (D / "logs").mkdir(parents=True)
    for n in ("a.mp3", "x.environment.mp3", "my-token-song.mp3"):
        (tracks / n).write_bytes(b"A" * 20)
    (D / "music" / "index.json").write_text('{"v":1}', encoding="utf-8")
    (C / "make_short_settings.json").write_text('{"v":1}', encoding="utf-8")
    fake_key = "AI" + "za" + "x" * 30
    fake_modal = "MODAL_TOKEN" + "_ID=ak-" + "1" * 12
    for p, body in ((".claude/CLAUDE.md", "clean"), (".claude/projects/P/memory/ok.md", "clean"),
                    (".claude/projects/P/memory/leak.md", "key is " + fake_key),
                    (".claude/projects/P/memory/modal.md", fake_modal),
                    (".claude/projects/P/memory/mention.md", "we talk about MODAL_TOKEN in words only"),
                    ("yeshiva-shorts/real.md", "x")):
        (W / p).parent.mkdir(parents=True, exist_ok=True)
        (W / p).write_text(body, encoding="utf-8")
    os.symlink(W / "yeshiva-shorts" / "real.md", W / "yeshiva-shorts" / "CLAUDE.md")
    script = str(REPO / "backup_extras.sh")
    e = dict(os.environ, CLAUDE_WIN_HOME=str(W), EXTRAS_REMOTE=str(R), SHORTS_DATA_DIR=str(D), SHORTS_CONFIG_DIR=str(C),
             PATH=os.path.expanduser("~/.local/bin") + ":" + os.environ.get("PATH", ""))
    def run(mode):
        return subprocess.run(["bash", script, mode], env=e, capture_output=True, text=True, timeout=180)
    def remote():
        return sorted(str(p.relative_to(R)) for p in R.rglob("*") if p.is_file() and "_old" not in p.parts)
    r = run("backup")
    got = remote()
    ok(r.returncode == 0, "גיבוי: רץ עד הסוף", r.stderr[-300:])
    ok("claude/projects/P/memory/ok.md" in got and "claude/projects/P/memory/mention.md" in got,
       "גיבוי: קבצי זיכרון נקיים (גם כאלה שרק מזכירים MODAL_TOKEN במילים) עולים", ", ".join(got))
    ok(not any(g.endswith(("leak.md", "modal.md")) for g in got) and "leak.md" in r.stderr,
       "גיבוי: קובץ זיכרון שמכיל מפתח או טוקן לא עולה, ויש אזהרה", r.stderr[-300:])
    ok("claude/yeshiva-shorts/CLAUDE.md" not in got, "גיבוי: CLAUDE.md שהוא קישור סמלי לא עולה (cp_up בודק קובץ רגיל)")
    ok("music/tracks/x.environment.mp3" in got and "music/tracks/my-token-song.mp3" not in got and "my-token-song" in r.stderr,
       "גיבוי: x.environment.mp3 עולה (LEAK_RE מעוגן); שם עם token לא עולה אבל מדווח", ", ".join(got))
    # היסטוריה: דריסה שומרת את הגרסה הקודמת ב-_old/<תאריך>
    (D / "music" / "index.json").write_text('{"v":2}', encoding="utf-8")
    (C / "make_short_settings.json").write_text('{"v":2}', encoding="utf-8")
    r = run("backup")
    old = {p.name: p.read_text() for p in R.glob("_old/*/**/*") if p.is_file()}
    ok(r.returncode == 0 and (R / "music" / "index.json").read_text() == '{"v":2}'
       and old.get("index.json") == '{"v":1}' and old.get("make_short_settings.json") == '{"v":1}',
       "גיבוי: הגרסה הקודמת של קובץ שנדרס נשמרת ב-_old/<תאריך>", str(old) + r.stderr[-200:])
    # 4.5.62 (#8): מפתח ההצעות של הבעלים — רק העותק המוצפן עולה; ה-.key הגלוי לעולם לא; קובץ ".enc" שלא נראה מוצפן עוצר את הריצה
    (C / "proposals_owner.key").write_text('{"v":1,"x25519":"AAA","ed25519":"BBB"}', encoding="utf-8")
    (C / "release.json").write_text('{"repo":"x"}', encoding="utf-8")
    (C / "proposals_owner.enc").write_text(json.dumps({"v": 1, "kdf": "scrypt", "ct": "Zm9v", "salt": "", "nonce": ""}), encoding="utf-8")
    r = run("backup")
    got = remote()
    ok(r.returncode == 0 and "config/proposals_owner.enc" in got and "config/release.json" in got
       and "config/proposals_owner.key" not in got and not any(g.endswith(".key") for g in got),
       "גיבוי: proposals_owner.enc (מוצפן) עולה, ה-.key הגלוי לא", ", ".join(got) + r.stderr[-200:])
    (C / "proposals_owner.enc").write_text(json.dumps({"v": 1, "kdf": "scrypt", "ct": "x", "x25519": "AAA"}), encoding="utf-8")
    r = run("backup")
    ok(r.returncode == 2 and "לא נראה מוצפן" in r.stderr, "גיבוי: proposals_owner.enc שלא נראה מוצפן — עוצר ולא מעלה", str(r.returncode) + r.stderr[-200:])
    for n in ("proposals_owner.key", "proposals_owner.enc", "release.json"):
        (C / n).unlink()
    # שחזור: מקומי חדש ושונה — לא נדרס ונשמר גם כ-.bak; מקומי ישן ושונה — נדרס והישן נשמר ב-restore_old
    (D / "music" / "index.json").write_text('{"v":3}', encoding="utf-8")
    os.utime(D / "music" / "index.json", (time.time() + 600, time.time() + 600))
    (C / "make_short_settings.json").write_text('{"v":0}', encoding="utf-8")
    os.utime(C / "make_short_settings.json", (time.time() - 5000, time.time() - 5000))
    r = run("restore")
    ro = [p.read_text() for p in (D / "restore_old").rglob("*") if p.is_file()]
    ok(r.returncode == 0 and (D / "music" / "index.json").read_text() == '{"v":3}'
       and (D / "music" / "index.json.bak").read_text() == '{"v":3}',
       "שחזור: קובץ מקומי חדש ושונה לא נדרס, ונשמר גם עותק .bak", r.stdout[-200:] + r.stderr[-200:])
    ok((C / "make_short_settings.json").read_text() == '{"v":2}' and '{"v":0}' in ro,
       "שחזור: קובץ מקומי ישן ושונה נדרס, והישן נשמר ב-restore_old", str(ro))
    # נעילה: הרצה שנייה במקביל יוצאת בקוד 75 ולא נוגעת בכלום
    hold = subprocess.Popen(["flock", str(D / "backup_extras.lock"), "sleep", "8"], start_new_session=True)
    try:
        time.sleep(0.7)
        r = run("backup")
        ok(r.returncode == 75, "גיבוי: הרצה שנייה בזמן שהראשונה רצה — יוצאת (75) ולא דורסת", str(r.returncode) + r.stderr[-120:])
    finally:
        os.killpg(hold.pid, 9)                  # גם ה-sleep שמחזיק את הנעילה
        hold.wait()
    # יומן: מעל 1MB מסתובב
    (D / "logs" / "backup_extras.log").write_bytes(b"x" * 1_200_000)
    run("backup")
    ok((D / "logs" / "backup_extras.log.1").is_file() and (D / "logs" / "backup_extras.log").stat().st_size < 1_000_000,
       "גיבוי: יומן גדול מ-1MB מסתובב")
    # התוכנה: בפסק זמן נהרגת כל קבוצת התהליכים (לא רק ה-bash), ו-75 לא נחשב כישלון
    code = r'''
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import make_short_app as A
fake = T / "fsh"; fake.mkdir(exist_ok=True)
(fake / "backup_extras.sh").write_text("#!/bin/bash\nsleep 300 &\necho $! > %s\nwait\n" % (T / "kid.pid"))
A.MS.SH = fake
A.EXTRAS_TIMEOUT = 2
ok_, why = A.extras_run()
time.sleep(0.5)
pid = int((T / "kid.pid").read_text())
try:
    os.kill(pid, 0); alive = True
except OSError:
    alive = False
chk(not ok_ and "שעתיים" in why, "פסק זמן: הגיבוי נחשב כושל")
chk(not alive, "פסק זמן: גם התהליך שהסקריפט הפעיל (rclone/sleep) נהרג, לא רק ה-bash", str(pid))
(fake / "backup_extras.sh").write_text("#!/bin/bash\nexit 75\n")
chk(A.extras_run() == (True, ""), "גיבוי שרץ כבר (75) לא נרשם ככישלון")
print(json.dumps(out, ensure_ascii=False))
'''
    (X / "app" / "data").mkdir(parents=True, exist_ok=True)
    r = subprocess.run([PY, "-c", code, str(HERE), str(X / "app")], env=dict(env, SHORTS_DATA_DIR=str(X / "app" / "data")),
                       capture_output=True, text=True, errors="replace", timeout=120, cwd=str(X))
    try:
        for c, w, d in json.loads(r.stdout.strip().splitlines()[-1]):
            ok(c, w, d)
    except (ValueError, IndexError):
        ok(False, "בדיקת פסק הזמן של הגיבוי רצה", (r.stdout + r.stderr).strip()[-400:])


def guard_unit_checks(T, env):
    """4.1.2: השומר — במצב בדיקה כתיבה להגדרות/רבנים/מילון/פרופילים האמיתיים נעצרת בשגיאה, והקבצים האמיתיים לא זזים;
    כתיבה לתיקייה זמנית עובדת; מחוץ למצב בדיקה השומר לא מפריע."""
    say("\n▶ שומר ההגדרות האמיתיות (4.1.2)")
    code = r'''
import json, os, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import make_short_guard as G, make_short_settings as SET, make_short_rabbis as RB, make_short_editor as ED
real = G.real_dirs()[0]
rs = real / "make_short_settings.json"
before = rs.read_bytes() if rs.exists() else None
chk(G.test_mode() and G.inside_real(rs) and not G.inside_real(T / "x"), "מצב בדיקה מזוהה; נתיב אמיתי נתפס, זמני לא")
def raises(fn):
    try:
        fn(); return False
    except G.RealConfigTouched:
        return True
    except Exception:
        return False
old = SET.PATH
SET.PATH = rs
chk(raises(lambda: SET.update({"music_on": False})), "הגדרות: כתיבה לקובץ האמיתי — נעצרת בשגיאה")
SET.PATH = old
chk((rs.read_bytes() if rs.exists() else None) == before, "הקובץ האמיתי לא נגע")
olddir = RB.DIR
RB.DIR = real / "rabbis"
chk(raises(lambda: RB.save("הרב לבדיקה", {"sub_gap": 1.5})) and not (real / "rabbis" / "הרב_לבדיקה.json").exists(), "רבנים: כתיבה לתיקייה האמיתית — נעצרת")
RB.DIR = olddir
oldg = ED.GLOSSARY
ED.GLOSSARY = real / "glossary.json"
chk(raises(lambda: ED.glossary_save({})), "מילון: כתיבה לאמיתי — נעצרת")
ED.GLOSSARY = oldg
import make_short_share as SH
oldp = SH.PROFILES
SH.PROFILES = real / "share_profiles"
chk(raises(lambda: SH.profile_save({"name": "בדיקה לשומר"})), "פרופילי שיתוף: כתיבה לאמיתי — נעצרת")
SH.PROFILES = oldp
import music_library as ML
chk(raises(lambda: ML.save_json(real / "music-feedback.json", {})), "לייקים של מוזיקה: כתיבה לאמיתי — נעצרת")
SET.PATH = T / "guard_ok.json"
SET.update({"music_on": False})
chk(SET.PATH.exists(), "כתיבה לקובץ זמני עובדת")
# היסטוריה יומית + בטל-איפוס
os.environ["SHORTS_DATA_DIR"] = str(T / "gdata")
SET.PATH = T / "hist.json"
SET.update({"float_shadow_opacity": 65, "playlist_top_n": 4})
SET.update({"playlist_top_n": 5})
hs = list((T / "gdata" / "settings_history").glob("*.json"))
chk(len(hs) == 1, "עותק יומי של ההגדרות נוצר (אחד ליום)", str(hs))
SET.reset()
chk(len(list((T / "gdata" / "settings_history").glob("*pre-reset*.json"))) == 1, "לפני איפוס נשמר עותק")
SET.reset()
chk(SET.load()["playlist_top_n"] == SET.DEFAULTS["playlist_top_n"], "אחרי איפוס כפול — עדיין על ברירת מחדל")
SET.undo()
chk(SET.load()["playlist_top_n"] == 5 and SET.load()["float_shadow_opacity"] == 65, "בטל אחרי איפוס כפול מחזיר את הערכים האמיתיים שלפני האיפוס")
print(json.dumps(out))
'''
    r = subprocess.run([PY, "-c", code, str(HERE), str(T)], env=env, capture_output=True, text=True, errors="replace",
                       timeout=120, cwd=str(T))
    try:
        for c, w, d in json.loads(r.stdout.strip().splitlines()[-1]):
            ok(c, w, d)
    except (ValueError, IndexError):
        ok(False, "בדיקת השומר רצה", (r.stdout + r.stderr).strip()[-500:])
    r2 = subprocess.run([PY, "-c", "import sys; sys.path.insert(0, sys.argv[1]); import make_short_guard as G; "
                         "G.assert_not_real_config(G.real_dirs()[0] / 'x'); print('ok')", str(HERE)],
                        env={k: v for k, v in env.items() if k not in ("MAKE_SHORT_NO_EXPORT", "MAKE_SHORT_TEST_GUARD")},
                        capture_output=True, text=True, timeout=30)
    ok(r2.stdout.strip() == "ok", "מחוץ למצב בדיקה השומר לא מפריע לתוכנה האמיתית", (r2.stdout + r2.stderr)[-200:])


def v413_checks(T, env):
    """4.1.3: שמירה לא נכנסת לפני עבודה על אותו קליף (גם בתור, גם בצורת נתיב אחרת); עדכון קוד אוטומטי רק למצב שנשמר
    ומסומן בתגית, ולא בזמן פוקוס של דף; הדף: פס עדין במקום alert חוסם, והודעה אחת ל"אין חיבור"."""
    say("\n▶ מרוץ שמירה/בנייה, עדכון קוד רק ממצב שנשמר, הודעות הדף (4.1.3)")
    code = r'''
import json, os, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2])
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("execv blocked"))
import make_short_app as A, make_short_snap as SNAP
P = T / "v413proj"; P.mkdir(exist_ok=True)
lnk = T / "v413lnk"
if not lnk.exists(): lnk.symlink_to(P)
A.JOBS["v1"] = {"id": "v1", "kind": "restyle", "project": str(lnk), "running": True, "clip": "clip1"}
chk(A.busy_clips(P) == {"clip1"}, "קליף בעבודה מזוהה גם כשהנתיב של העבודה בצורה אחרת (קישור)", str(A.busy_clips(P)))
A.JOBS.pop("v1")
with A.QLOCK:
    A.BUILD_Q.append({"id": "vq", "kind": "swap", "status": "waiting", "project": str(P), "clip": "clip2"})
chk(A.busy_clips(P) == {"clip2"}, "עבודה שממתינה בתור נחשבת (שמירה לא נכנסת לפניה)")
st = {"clips": [{"name": "clip1"}, {"name": "clip2"}], "video_title": "x"}
A.launch = lambda jid: None
r = A.save_start(P, st, ["clip2"])
sq = next((q for q in A.BUILD_Q if q["kind"] == "save"), None)
chk(r.get("job") and sq and A.BUILD_Q.index(sq) < [q["id"] for q in A.BUILD_Q].index("vq") and A.lane_blocker(sq) is None,
    "שמירה של קליף שעבודה שלו רק ממתינה — נכנסת לתור, עם עדיפות לפניה (לא נדחית)", str(r))
with A.QLOCK:
    A.BUILD_Q[:] = [q for q in A.BUILD_Q if q["id"] != "vq" and q["kind"] != "save"]
A.JOBS.pop(r.get("job"), None)
# עדכון קוד: רק עץ נקי + תגית
R = T / "fakerepo"; (R / "pipeline" / "scripts").mkdir(parents=True, exist_ok=True)
def git(*a): return subprocess.run(["git", "-c", "user.email=a@b", "-c", "user.name=t", "-C", str(R), *a], capture_output=True, text=True)
if not (R / ".git").exists():
    git("init", "-q"); (R / "f.txt").write_text("1"); git("add", "-A"); git("commit", "-qm", "c")
oldH = A.HERE
A.HERE = R / "pipeline" / "scripts"
os.environ.pop("MAKE_SHORT_UPDATE_GATE", None)
chk(A.code_tree_ready()[0] is False and "תגית" in A.code_tree_ready()[1], "commit בלי תגית — לא מעדכנים")
git("tag", "v9.9.9")
chk(A.code_tree_ready()[0] is True, "commit מסומן בתגית, עץ נקי — מותר")
(R / "f.txt").write_text("2")
chk(A.code_tree_ready()[0] is False and "commit" in A.code_tree_ready()[1], "עץ מלוכלך (באמצע עריכה) — לא מעדכנים")
os.environ["MAKE_SHORT_UPDATE_GATE"] = "off"
chk(A.code_tree_ready()[0] is True, "מתג בדיקה (off) מבטל את השער")
os.environ.pop("MAKE_SHORT_UPDATE_GATE")
import shutil as _sh; _sh.rmtree(R / ".git")
chk(A.code_tree_ready()[0] is True, "התקנה בלי git (מקבל) — כמו קודם")
git("init", "-q"); git("add", "-A"); git("commit", "-qm", "c2")
# code_check_now: מלוכלך → ממתין ולא מריץ בדיקה; אחרי שמירה+תגית → עדכון ממתין
SNAP.content_hash = lambda *a, **k: "newhash"
A.CODE.update(boot="oldhash", checked="", pending=None, failed=None, held=False)
ran = []
A.code_selfcheck = lambda: (ran.append(1) or (True, ""))
(R / "f.txt").write_text("3")
A.code_check_now()
chk(A.CODE["pending"] is None and A.CODE["held"] and not ran, "קוד השתנה באמצע עריכה — לא נבדק ולא ממתין לעדכון")
git("add", "-A"); git("commit", "-qm", "c3"); git("tag", "v9.9.10")
A.code_check_now()
chk(A.CODE["pending"] and A.CODE["pending"]["hash"] == "newhash" and ran, "אחרי שמירה + תגית — הבדיקה העצמית רצה ועדכון ממתין")
# לא מפעילים מחדש מתחת לדף בפוקוס
A.JOBS.clear()
A.FOCUS["at"] = time.time()
A.RESTARTING.update(on=False, at=0)
for _ in range(3):
    A.code_restart_if_idle()
chk(A.RESTARTING["on"] is False, "דף פתוח ובפוקוס — לא מפעילים מחדש")
A.FOCUS["at"] = 0
A.RESTARTING.update(on=True, at=time.time() - 100)
git("tag", "-d", "v9.9.10"); git("tag", "-d", "v9.9.9")
A.code_restart_if_idle()
chk(A.RESTARTING["on"] is False, "תגית נעלמה — לא מפעילים מחדש (השער נבדק גם ברגע ההפעלה)")
A.HERE = oldH
print(json.dumps(out))
'''
    e2 = dict(env, MAKE_SHORT_UPDATE_GATE="")
    e2.pop("MAKE_SHORT_UPDATE_GATE")
    r = subprocess.run([PY, "-c", code, str(HERE), str(T)], env=e2, capture_output=True, text=True, errors="replace",
                       timeout=180, cwd=str(T))
    try:
        for c, w, d in json.loads(r.stdout.strip().splitlines()[-1]):
            ok(c, w, d)
    except (ValueError, IndexError):
        ok(False, "בדיקות 4.1.3 רצו", (r.stdout + r.stderr).strip()[-600:])
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    ok("window.alert=function" in page and 'id="ysBanners"' in page.replace("h.id=\"ysBanners\"", 'id="ysBanners"'),
       "הדף: alert הוחלף בפס עדין שאפשר לסגור (בלי חלון חוסם)")
    ok("function srvDown()" in page and "SEENMSG" in page, "הדף: 'אין חיבור' מוצג פעם אחת + חיבור מחדש, ואותה הודעה לא חוזרת")
    ok('"/api/focus"' in page and "FOCUS" in (HERE / "make_short_app.py").read_text(encoding="utf-8"), "הדף מדווח פוקוס לשרת")


def v420_checks(T, env):
    """4.2.0: שמירה = פריט בתור לפי סדר ההגעה באותו שיעור (עדיפות על ממתינים, לא על רץ; לא מחכה לשיעורים אחרים);
    תצוגה מקדימה מקפיאה עבודה כבדה (SIGSTOP/SIGCONT) וממשיכה תמיד — והקידוד המוקפא נגמר שלם."""
    say("\n▶ תור לפי שיעור + עדיפות לתצוגה (4.2.0)")
    code = r'''
import json, os, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, sys.argv[1]); T = Path(sys.argv[2]); FF = sys.argv[3]
out = []
def chk(c, w, d=""): out.append([bool(c), w, d])
import make_short_app as A
launched = []
A.launch = lambda jid: launched.append(jid)
P1 = T / "lane1"; P1.mkdir(exist_ok=True); P2 = T / "lane2"; P2.mkdir(exist_ok=True)
A.BUILD_Q.clear()
R = {"id": "r1", "kind": "restyle", "args": ["restyle", str(P1), "clip1"], "project": str(P1), "title": "t", "status": "running",
     "clip": "clip1", "job": "x1", "added": "x", "settings": ""}
A.BUILD_Q.append(R)
W = {"id": "w1", "kind": "restyle", "args": ["restyle", str(P1), "clip2"], "project": str(P1), "title": "t", "status": "waiting",
     "clip": "clip2", "added": "x", "settings": ""}
A.BUILD_Q.append(W)
jid = A.enqueue("save", ["save", str(P1)], str(P1), "t", kick=False)
S = next(q for q in A.BUILD_Q if q["kind"] == "save")
chk(A.BUILD_Q.index(S) == 1, "שמירה שהגיעה עוברת לפני פריט *ממתין* של אותו שיעור, אחרי זה שכבר רץ", str([q["kind"] for q in A.BUILD_Q]))
chk(A.lane_blocker(S) is R, "שמירה של כל השיעור ממתינה לבנייה שרצה")
chk(A.lane_blocker(W) is S, "בנייה שמגיעה אחרי שמירה ממתינה לה (סדר הגעה)")
v = [x for x in A.queue_view()["items"] if x["id"] == S["id"]][0]
chk(v.get("after") and v["state"] == "queued", "בדף: ממתין בתור (אחרי: …)", str(v.get("after")))
A.kick_queue()
chk(not launched, "שמירה לא התחילה כל עוד הבנייה רצה")
# שמירה בשיעור אחר — לא ממתינה לכבד של שיעור אחר
A.enqueue("save", ["save", str(P2)], str(P2), "t2", kick=False)
S2 = [q for q in A.BUILD_Q if q["kind"] == "save" and q["project"] == str(P2)][0]
chk(A.lane_blocker(S2) is None, "שמירה בשיעור אחר לא ממתינה לבנייה של שיעור אחר")
A.kick_queue()
chk(len(launched) == 1 and S2.get("status") == "running", "…ורצה מיד", str(launched))
# שמירה של קליף אחר מזה שנבנה — לא מחכה
A.enqueue("save", ["save", str(P1), "--clips=clip3"], str(P1), "t", kick=False, clip="clip3")
S3 = [q for q in A.BUILD_Q if q["kind"] == "save" and q.get("clip") == "clip3"][0]
chk(A.lane_blocker(S3) is S, "שמירה של קליף אחד ממתינה לשמירה קודמת של כל השיעור (חפיפה)")
# ביטול פריט ממתין — מפנה את התור
A.queue_edit({"id": S3["id"], "action": "remove"})
chk(S3 not in A.BUILD_Q, "ביטול שמירה שממתינה — יוצאת מהתור")
# הבנייה נגמרה → השמירה (ולא לפני) רצה, ושתי שמירות רצופות — בזו אחר זו
R["status"] = "done"; R.pop("job", None)
launched.clear()
A.kick_queue()
chk(S.get("status") == "running" and len(launched) == 1, "אחרי שהבנייה נגמרה — השמירה מתחילה")
S["status"] = "waiting"   # (בודקים את הסדר בין שתי שמירות)
jid2 = A.enqueue("save", ["save", str(P1)], str(P1), "t", kick=False)
S4 = [q for q in A.BUILD_Q if q["kind"] == "save" and q["project"] == str(P1) and q is not S][-1]
chk(A.lane_blocker(S4) is S, "שתי שמירות רצופות — השנייה אחרי הראשונה")
# עדיפות לתצוגה: הקפאה והמשך של קידוד אמיתי
os.environ["MAKE_SHORT_NO_EXPORT"] = "1"
o = T / "pause_out.mp4"
if o.exists(): o.unlink()
job = subprocess.Popen([FF, "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=30:duration=6",
                        "-c:v", "libx264", "-preset", "slow", str(o)])
A.JOBS["pj"] = {"id": "pj", "kind": "restyle", "project": str(P1), "running": True, "launched": True, "pid": job.pid, "log": []}
time.sleep(0.8)
def state(pid):
    try:
        return open("/proc/%d/stat" % pid).read().rsplit(")", 1)[1].split()[0]
    except OSError:
        return "?"
A.pause_heavy()
time.sleep(0.5)
chk(state(job.pid) == "T" and A.JOBS["pj"].get("paused") and A.PAUSE_FILE.exists(), "תצוגה: הצריבה שרצה מוקפאת, מסומנת ב-paused, ונרשמה לשחזור")
sz = o.stat().st_size if o.exists() else 0
time.sleep(1.0)
chk((o.stat().st_size if o.exists() else 0) == sz, "בזמן ההקפאה הקידוד לא מתקדם")
A.resume_heavy()
chk(state(job.pid) != "T" and not A.JOBS["pj"].get("paused") and not A.PAUSE_FILE.exists(), "אחרי התצוגה — ממשיכה, הסימון והקובץ נמחקו")
rc = job.wait(timeout=120)
dec = subprocess.run([FF, "-v", "error", "-i", str(o), "-f", "null", "-"], capture_output=True, text=True)
chk(rc == 0 and dec.returncode == 0 and not dec.stderr.strip(), "הקידוד שהוקפא וממשיך — נגמר שלם ונפתח בלי שגיאות", dec.stderr[-200:])
# קריסה בין STOP ל-CONT: בפתיחה הבאה הכול ממשיך
p2 = subprocess.Popen(["sleep", "30"])
A.JOBS["pj"] = {"id": "pj", "kind": "finish", "project": str(P1), "running": True, "launched": True, "pid": p2.pid, "log": []}
A.pause_heavy(); time.sleep(0.3)
frozen = state(p2.pid) == "T"
A.PAUSE.update(n=0, pids=[], jobs=[])          # "השרת נפל": הזיכרון נעלם, הקובץ נשאר
A.pause_recover(); time.sleep(0.3)
chk(frozen and state(p2.pid) != "T" and not A.PAUSE_FILE.exists(), "קריסה בין הקפאה להמשך — בפתיחה הבאה התהליך ממשיך (לא נשאר קפוא)")
p2.kill()
# שומר: הקפאה ארוכה מדי / כפויה — מתעוררת
p3 = subprocess.Popen(["sleep", "30"])
A.JOBS["pj"] = {"id": "pj", "kind": "retime", "project": str(P1), "running": True, "launched": True, "pid": p3.pid, "log": []}
A.pause_heavy(); A.pause_heavy(); time.sleep(0.2)
A.resume_heavy()
still = state(p3.pid) == "T"                    # תצוגה אחת נגמרה, עוד אחת רצה — עדיין קפוא
A.resume_heavy()
chk(still and state(p3.pid) != "T", "שתי תצוגות יחד: ממשיכים רק כשהאחרונה נגמרה")
A.pause_heavy(); A.PAUSE["since"] -= 1000; A.resume_heavy(force=True); time.sleep(0.2)
chk(state(p3.pid) != "T" and A.PAUSE["n"] == 0, "המשך כפוי (שומר הזמן) מחזיר הכול")
p3.kill()
src = Path(A.__file__).read_text(encoding="utf-8")
chk("pause_heavy()" in src and "finally:\n            resume_heavy()" in src, "start_preview עוטף את התצוגה ב-pause/finally-resume")
A.JOBS.pop("pj", None)
print(json.dumps(out))
'''
    r = subprocess.run([PY, "-c", code, str(HERE), str(T), ffmpeg()], env=env, capture_output=True, text=True,
                       errors="replace", timeout=240, cwd=str(T))
    try:
        for c, w, d in json.loads(r.stdout.strip().splitlines()[-1]):
            ok(c, w, d)
    except (ValueError, IndexError):
        ok(False, "בדיקות 4.2.0 רצו", (r.stdout + r.stderr).strip()[-700:])


def manifest_checks():
    """4.1.2: מניפסט תכונות — כל מה שהיה בגרסה המאושרת עדיין קיים (הגדרות, data-k, מזהים, כפתורים, נתיבי API, אזורים),
    אלא אם הוסר לבקשת הבעלים (removed_on_request: תאריך + ציטוט)."""
    say("\n▶ מניפסט תכונות (4.1.2)")
    sys.path.insert(0, str(HERE))
    import make_short_manifest as MF
    m = MF.load()
    gone = MF.missing(m, MF.extract())
    ok(not gone, "כל התכונות במניפסט עדיין קיימות (%d פריטים)" % sum(len(m.get(k, [])) for k in MF.KINDS),
       "; ".join("%s: %s" % g for g in gone[:12]))
    fake = {k: [] for k in MF.KINDS}
    fake["settings_keys"] = ["x_removed"]
    fake["removed_on_request"] = []
    ok(MF.missing(fake, MF.extract()) == [("settings_keys", "x_removed")], "פריט שנעלם נתפס")
    fake["removed_on_request"] = [{"kind": "settings_keys", "item": "x_removed", "date": "2026-11-19", "quote": "ציטוט"}]
    ok(MF.missing(fake, MF.extract()) == [], "פריט שהוסר לבקשתו (עם תאריך וציטוט) לא נכשל")
    fake["removed_on_request"] = [{"kind": "settings_keys", "item": "x_removed"}]
    ok(MF.missing(fake, MF.extract()) != [], "הסרה בלי תאריך וציטוט לא נחשבת")


def main():
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    mode = a[0] if a else "matrix"
    if mode not in ("matrix", "package", "all", "quick", "units"):     # units (4.1.0) = רק הבדיקות הקטנות, בלי סרטונים
        sys.exit(__doc__)
    sys.path.insert(0, str(HERE))
    his0 = his_state()                           # 4.1.2: כל קבצי תיקיית ההגדרות האמיתית — לפני (hash + רשימה)
    T = Path(tempfile.mkdtemp(prefix="ys_selftest_"))
    env = test_env(T)
    # 4.1.2: הסביבה המבודדת נקבעת *לפני* כל ייבוא של מודול של התוכנה (נתיבים נקבעים בזמן ייבוא)
    os.environ.update({k: v for k, v in env.items() if k.startswith(("MAKE_SHORT", "SHORTS_"))})
    os.environ.pop("GEMINI_API_KEY", None)
    import make_short_selftest_410 as T410
    t0, version = time.time(), ""
    try:
        if mode in ("matrix", "all", "quick"):
            static_checks()
            guard_unit_checks(T, env)
            manifest_checks()
            v413_checks(T, env)
            v420_checks(T, env)
            desc_checks(T, env)
            profile_unit_checks(T, env)
            view_checks(T, env)
            shim_checks(T, env)
            own_key_checks(T, env)
            matrix(T, env, quick=mode == "quick")
            app_checks(T, env)
            guard_checks(T, env)
            release_checks(T, env)
            proposals_checks(T, env)
            personal_checks(T, env)
            vault_checks(T, env)
            past_ui_checks()
            editor_checks(T, env)
            extras_checks(T, env)
            T410.all_checks(T, env, ok, say)
        if mode == "units":
            guard_unit_checks(T, env)
            manifest_checks()
            v413_checks(T, env)
            v420_checks(T, env)
            own_key_checks(T, env)
            extras_checks(T, env)
            release_checks(T, env)
            proposals_checks(T, env)
            personal_checks(T, env)
            past_ui_checks()
            T410.all_checks(T, env, ok, say)
        if mode in ("package", "all"):
            version = package(T, env) or ""
        his1 = his_state()
        ok(his1 == his0, "תיקיית ההגדרות האמיתית שלו (כל הקבצים) לא השתנתה בבדיקה", "; ".join(state_diff(his0, his1))[:600])
    except Exception as e:
        import traceback
        ERRORS.append("הבדיקה עצמה נפלה: %s" % e)
        say(traceback.format_exc()[-1500:])
    finally:
        if "--keep" in sys.argv:
            say("(התיקייה הזמנית נשארה: %s)" % T)
        else:
            shutil.rmtree(T, ignore_errors=True)
    say("\n%s %s (%.0f שניות)" % ("✅" if not ERRORS else "❌",
                                  "הכול עבר" if not ERRORS else "%d בעיות:\n   - %s" % (len(ERRORS), "\n   - ".join(ERRORS)),
                                  time.time() - t0))
    save_last({"at": time.strftime("%Y-%m-%d %H:%M"), "mode": mode, "ok": not ERRORS, "errors": ERRORS[:20],
               "secs": round(time.time() - t0), "commit": git("log", "-1", "--format=%h %cs %s").strip()})
    if JSON_OUT:
        print(json.dumps({"ok": not ERRORS, "errors": ERRORS, "version": version, "mode": mode}, ensure_ascii=False))
    return 0 if not ERRORS else 1


if __name__ == "__main__":
    sys.exit(main())
