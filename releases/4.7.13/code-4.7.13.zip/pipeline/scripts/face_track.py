# -*- coding: utf-8 -*-
"""
מעקב אחרי **הפנים** של הדובר לאורך הקליף, כדי שהקרופ ל-9:16 ישאיר אותו
במרכז הפריים כל הזמן.

🚨 למה זה נכתב (26/8/2026) — `center_track.py` מודד מרכז-מסה של **תנועה**
(סטיית תקן בזמן לכל עמודה). אצל דובר שמדבר עם הידיים, מרכז התנועה הוא
**הידיים**, לא הראש — הידיים רחבות, זזות הרבה יותר, ויושבות נמוך ומהצדדים.
התוצאה בפועל: הפנים נדחפו לקצה הפריים, ותיקנו את זה ידנית עם `subject_x`
(ניחוש קבוע לכל הקליף) — מה שנשבר ברגע שהדובר זז. הערה שהתקבלה: *"סדר גם
שהדובר יופיע במרכז הפריים לאורך כל הסרטון."*

השיטה כאן: YuNet (OpenCV DNN, מודל 230KB ב-`library/models/`) מזהה פנים
בכל דגימה, והמסלול עובר החלקה חזקה — חציון נע ואז ממוצע נע — כדי שהקרופ
ינוע כמו מצלמה אנושית איטית ולא ירדוף אחרי כל הנהון.

תלות: `opencv-python-headless`. אם המודל או cv2 חסרים — הפונקציה מחזירה
None, והקורא נופל חזרה ל-`center_track` הישן.

שימוש:
    python face_track.py <video> [--json out.json] [--fps 2]
"""
import json
import os
import subprocess
import sys

import numpy as np

MODEL_PATH = os.path.join(
    os.environ.get("SHORTS_LIB",
                   os.path.join(os.path.dirname(os.path.dirname(
                       os.path.dirname(os.path.abspath(__file__)))), "assets")),
    "models", "face_detection_yunet_2023mar.onnx",
)

SAMPLE_FPS = 2.0        # דגימות לשנייה. הראש לא זז מהר, 2 מספיק בהחלט
ANA_W, ANA_H = 640, 360
SCORE_MIN = 0.45        # מתחת לזה זו לא באמת פנים
MEDIAN_SEC = 1.5        # חלון החציון — מנקה זיהויי-שווא בודדים
MEAN_SEC = 1.0          # חלון הממוצע — מנקה רעש זיהוי לפני המצלמה הווירטואלית

# ═══ המצלמה הווירטואלית ═══
# 🚨 גרסה ראשונה עקבה אחרי הפנים ברציפות. הערה שהתקבלה אחרי צפייה:
# *"הרבה יותר טוב עכשיו, אבל עדיין לא מושלם — יש יותר מדי תנועה. צריך
# לשים גבול מקסימלי, כשהרב זז הרבה — תנועה איטית יותר, ובתדירות שלא
# מאבדת יציבות בעין הצופה."*
#
# מעקב רציף הוא הדבר הלא נכון גם כשהוא מדויק: הרקע זוחל **כל הזמן**,
# והעין נאחזת בזחילה. צלם אנושי לא עושה את זה — הוא מחזיק את הפריים
# נעול, ורק כשהדובר באמת יצא מהמסגרת הוא מתקן, לאט. זה מה שמיושם כאן.
#
# כל הערכים בשבר מרוחב **פריים המקור**. חלון הקרופ רואה 0.3164 ממנו,
# ולכן 0.0475 במקור = 15% מרוחב הפלט.
# הערכים נבחרו במדידה על שלושת הקליפים, לא בהערכה. מה שנמדד לכל הגדרה:
# כמה תנועות מצלמה, כמה אחוז מהזמן היא עומדת לגמרי, וכמה **שניות רצופות**
# הדובר יוצא מ-30% מהמרכז. אזור מת רחב מדי (0.0475/1.2ש') הוריד את התנועה
# יפה אבל השאיר את הרב 4 שניות רצופות מחוץ למסגרת — זה גרוע יותר מזחילה.
# 🚨 כוונון 15/9/2026 — הערה שהתקבלה: *"התזוזה בהתאם לפנים של הרב דרמטית
# מדי, המצלמה זזה מאוד בקיצוניות"*. מה שנלמד מהמדידה: **המהירות היא מה
# שנקרא 'דרמטי' לעין, לא תדירות התיקונים.** הרחבת אזור המת לבדה (0.060 /
# 1.8ש') דווקא *הרעה* את המיסגור — 82% בתוך ±25% מול 92% קודם — כי המצלמה
# נשארה מאחור ואז נאלצה לתקן מרחק גדול. הורדת MAX_PAN_RATE עם הרחבה מתונה
# בלבד נתנה את שתי התכונות יחד. נמדד על 20 שניות מקליפ 1 (הרב הראל כהן):
#
#   |                        | במרכז ±25% | מעבר ל-30% |
#   | קודם (0.035/0.8/0.060) |    92%     |   0.5 ש'   |
#   | אזור מת רחב (0.060/1.8)|    82%     |   0.5 ש'   |
#   | כאן   (0.045/1.3/0.038)|    98%     |   0 ש'     |
#
# על קליפ 1 המלא: 99% במרכז, 0 שניות חריגה, 18 נקודות מסלול במקום 37.
DEAD_OUT = 0.045        # עד כאן המצלמה לא זזה בכלל (14% מרוחב הפלט)
DEAD_IN = 0.0100        # וכשהיא כבר זזה — עוצרת כשהגיעה לכאן (3%)
TRIGGER_SEC = 1.3       # חריגה חייבת להחזיק כך לפני שמתחילים לזוז.
                        # בלי זה כל רכינה רגעית מפעילה פאן.
MAX_PAN_RATE = 0.038    # תקרת מהירות: ~130 פיקסלים לשנייה בפלט
EASE_K = 0.45           # מקדם ההתקרבות — נותן האטה בסוף התנועה
EASE_SEC = 0.8          # החלקה סופית שמעגלת את רגעי ההתחלה והעצירה
SIMPLIFY_TOL = 0.004    # פישוט המסלול: ~1.3% מרוחב הפלט — מתחת לסף הנראות
NODE_SEC = 0.5          # צפיפות נקודות לפני הפישוט
# 🚨 תקרת נקודות — מגבלה של ffmpeg, לא בחירה אסתטית. מנתח הביטויים
# (`libavutil/eval.c`) נופל על ביטוי ארוך מדי: נמדד בבינארי-סרץ' על
# הפייפליין הזה — 93 נקודות עוברות, 94 מחזירות
# "Failed to configure input pad on Parsed_crop". התסמין הוא קוד יציאה
# 234 מ-ffmpeg בלי הסבר. 75 משאיר שוליים בטוחים.
MAX_NODES = 75

# ═══ מצלמה זריזה (כרטיס 22, 28/10/2026) — CAM_ZIPPY=1 ═══
# הרב יוחאי פרלמן ("מהות התפילה") זז כל כך שהמצלמה הרגילה (1.3ש' המתנה + תקרת 0.038/ש')
# השאירה אותו **כולו מחוץ לקרופ** לכמה שניות; "חלקה" (CAM_SMOOTH) רק הוסיפה איחור. הוא חשש
# ממצלמה קופצנית, ולכן זו לא מצלמה מהירה בכלל — היא **הרגילה בדיוק** כל עוד הפנים בנוחות
# בפנים, ומאיצה רק כשהן מתקרבות לקצה הקרופ. בגלל שהבנייה לא בזמן אמת, היא מסתכלת קדימה:
# אם בשנייה הקרובה הפנים יגיעו לקצה, היא מתחילה לזוז כבר עכשיו — מוקדם ובמהירות מתונה,
# במקום מאוחר ובקפיצה. כשהפנים חזרו לאזור המת היא ממשיכה בקצב הרגיל ונעצרת כרגיל.
# נמדד על שני הקליפים של פרלמן (camera_path.py compare; "חתוך" = רצף ≥1ש' שבו יותר מרבע מהפנים
# מחוץ לקרופ; מהירות שיא בפיקסלים לשנייה בפלט; "עומדת" = אחוז הזמן שהמצלמה לא זזה בכלל):
#   |            | קליפ 1: חתוך / שיא / עומדת | קליפ 2: חתוך / שיא / עומדת |
#   | רגילה      |   6.0ש' / 130 / 49%        |  18.5ש' / 130 / 43%        |
#   | חלקה       |   6.5ש' / 130 / 51%        |  16.0ש' / 130 / 60%        |
#   | זריזה (כאן)|   0ש'   / 341 / 59%        |   0ש'   / 341 / 42%        |
# תקרה 0.16 + K 1.2 תפסה אותו באותה מידה אבל בשיא 546 — נבחר הערך המתון שעדיין מגיע ל-0.
ZIPPY = False
Z_EDGE = 0.085          # מרחק פנים-ממרכז-המצלמה שנחשב "ליד הקצה" (27% מרוחב הפלט; הקצה = 50%)
Z_LOOK_SEC = 1.5        # כמה קדימה מסתכלים (1.0 לא הספיק לקליף 2 בתקרה הזאת: 3ש' חתוך)
Z_PAN_RATE = 0.10       # תקרת המהירות בזמן חירום (~340 פיקסלים לשנייה בפלט; הרגילה 130)
Z_EASE_K = 0.8          # מקדם ההתקרבות בזמן חירום


def _probe_size(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=p=0", path],
        capture_output=True, text=True, check=True).stdout.strip()
    w, h = out.split(",")[:2]
    return int(w), int(h)


def _analysis_size(path, long_side=640):
    """גודל ניתוח **בשמירת יחס** של המקור.

    🚨 למה זה לא קבוע 640x360: כשמריצים את הבדיקה על הפלט האנכי (1080x1920),
    `scale=640:360` מועך אותו פי 3.16 לרוחב. YuNet עדיין "מוצא פנים" — אבל
    באותו מקום בדיוק בכל פריים, כי מה שהוא מוצא זו לא הפנים. התסמין שחשף
    את זה: סטיית תקן 0.000 על פני קליף שלם. **תוצאה בלי שונות היא באג,
    לא הצלחה.**
    """
    w, h = _probe_size(path)
    if w >= h:
        aw = long_side
        ah = max(2, int(round(long_side * h / w)) // 2 * 2)
    else:
        ah = long_side
        aw = max(2, int(round(long_side * w / h)) // 2 * 2)
    return aw, ah


def _sample_bgr(path, fps=SAMPLE_FPS, size=None):
    w, h = size or _analysis_size(path)
    cmd = ["ffmpeg", "-v", "error", "-i", path,
           "-vf", f"fps={fps},scale={w}:{h}", "-pix_fmt", "bgr24",
           "-f", "rawvideo", "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    n = len(raw) // (w * h * 3)
    if n == 0:
        raise RuntimeError("לא התקבלו פריימים לניתוח פנים")
    return np.frombuffer(raw[: n * w * h * 3], dtype=np.uint8).reshape(n, h, w, 3)


def detect_centers(path, fps=SAMPLE_FPS):
    """מחזיר (times, centers, scores) כשמרכז הוא שבר מרוחב הפריים, או NaN."""
    import cv2

    aw, ah = _analysis_size(path)
    frames = _sample_bgr(path, fps, size=(aw, ah))
    det = cv2.FaceDetectorYN.create(MODEL_PATH, "", (aw, ah),
                                    score_threshold=SCORE_MIN)
    det.setInputSize((aw, ah))

    times, centers, scores, heights = [], [], [], []
    for i, fr in enumerate(frames):
        times.append(i / fps)
        _, faces = det.detect(np.ascontiguousarray(fr))
        if faces is None or len(faces) == 0:
            centers.append(np.nan)
            scores.append(0.0)
            heights.append(np.nan)
            continue
        # הפנים הגדולות ביותר, לא הראשונות: בשיעור ישיבה נכנס לפעמים
        # תלמיד ברקע, והוא קטן משמעותית מהדובר שיושב קרוב למצלמה.
        best = max(faces, key=lambda f: float(f[2]) * float(f[3]))
        x, y, w_, h_ = best[:4]
        centers.append(float(x + w_ / 2) / aw)
        scores.append(float(best[-1]))
        heights.append(float(h_))
    return np.array(times), np.array(centers), np.array(scores), np.array(heights)


def _reject_outliers(centers, heights):
    """פוסל זיהויים שחורגים מהגודל האופייני — כמעט תמיד זיהוי-שווא ברקע."""
    ok = ~np.isnan(heights)
    if ok.sum() < 3:
        return centers
    med_h = float(np.median(heights[ok]))
    bad = ok & ((heights < 0.55 * med_h) | (heights > 1.8 * med_h))
    out = centers.copy()
    out[bad] = np.nan
    return out


def _fill_gaps(centers):
    """מילוי פערים (הרב הפנה את הראש הצידה ו-YuNet לא זיהה) באינטרפולציה."""
    idx = np.arange(len(centers))
    ok = ~np.isnan(centers)
    if ok.sum() == 0:
        return None
    return np.interp(idx, idx[ok], centers[ok])


def _smooth(centers, fps):
    n = len(centers)
    mk = max(1, int(round(MEDIAN_SEC * fps)) | 1)     # אי-זוגי
    ak = max(1, int(round(MEAN_SEC * fps)))
    pad = mk // 2
    ext = np.pad(centers, pad, mode="edge")
    med = np.array([np.median(ext[i:i + mk]) for i in range(n)])
    pad2 = ak // 2
    ext2 = np.pad(med, pad2, mode="edge")
    kern = np.ones(ak) / ak
    return np.convolve(ext2, kern, mode="same")[pad2:pad2 + n]


def virtual_camera(target, fps):
    """ממיר מסלול פנים למסלול **מצלמה**: נעולה רוב הזמן, זזה לאט ומעט.

    מחזיר (cam, n_moves) — המסלול, וכמה פעמים המצלמה בכלל התחילה לזוז.
    `n_moves` הוא המדד שהתבקש ("תדירות שלא מאבדת יציבות"): פחות
    תנועות ארוכות ואיטיות עדיף על הרבה תיקונים קצרים.
    """
    n = len(target)
    if n == 0:
        return target, 0
    cam = np.empty(n, dtype=float)
    # מתחילים כבר ממורכז — פאן פתיחה נראה כמו תקלה
    pos = float(target[0])
    moving = False
    out_since = None
    max_step = MAX_PAN_RATE / fps
    n_moves = 0
    urgent = False                          # מצלמה זריזה: באמצע תיקון מהיר
    look = max(1, int(round(Z_LOOK_SEC * fps)))

    for i in range(n):
        err = float(target[i]) - pos
        if ZIPPY:
            ahead = np.asarray(target[i:i + look + 1], dtype=float) - pos
            far = float(ahead[int(np.argmax(np.abs(ahead)))])
            if not urgent and abs(far) > Z_EDGE:
                urgent = True
                if not moving:
                    moving = True
                    n_moves += 1
                    out_since = None
            elif urgent and abs(far) <= DEAD_OUT:
                urgent = False              # חזר לאזור המת — ממשיכים בקצב הרגיל עד העצירה
            if urgent:
                # מכוונים לנקודה הקיצונית שלפנינו, לא למקום הנוכחי — כך לא מגיעים באיחור
                step = far * Z_EASE_K / fps
                cap = Z_PAN_RATE / fps
                pos += max(-cap, min(cap, step))
                cam[i] = pos
                continue
        if not moving:
            if abs(err) > DEAD_OUT:
                if out_since is None:
                    out_since = i
                elif (i - out_since) / fps >= TRIGGER_SEC:
                    moving = True
                    n_moves += 1
                    out_since = None
            else:
                out_since = None            # חזר לתוך אזור המת — מאפסים
        else:
            if abs(err) <= DEAD_IN:
                moving = False
        if moving:
            step = err * EASE_K / fps * 2.0
            if abs(step) > max_step:
                step = max_step if step > 0 else -max_step
            pos += step
        cam[i] = pos

    # החלקה קצרה שמעגלת את רגעי ההתחלה והעצירה, בלי להחזיר זחילה
    k = max(1, int(round(EASE_SEC * fps)))
    pad = k // 2
    ext = np.pad(cam, pad, mode="edge")
    cam = np.convolve(ext, np.ones(k) / k, mode="same")[pad:pad + n]
    return cam, n_moves


def _simplify(times, values, tol=SIMPLIFY_TOL):
    """Douglas-Peucker על מסלול 1D — משאיר רק נקודות שבאמת משנות צורה."""
    if len(times) <= 2:
        return list(zip(times, values))
    stack = [(0, len(times) - 1)]
    keep = {0, len(times) - 1}
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        t0, t1 = times[a], times[b]
        v0, v1 = values[a], values[b]
        span = (t1 - t0) or 1e-9
        lin = v0 + (times[a:b + 1] - t0) * (v1 - v0) / span
        dev = np.abs(values[a:b + 1] - lin)
        k = int(np.argmax(dev))
        if dev[k] > tol:
            keep.add(a + k)
            stack.append((a, a + k))
            stack.append((a + k, b))
    ks = sorted(keep)
    return [(float(times[i]), float(values[i])) for i in ks]


def track_faces(path, fps=SAMPLE_FPS):
    """מחזיר רשימת נקודות [(t, center_fraction)] מוחלקת, או None אם נכשל."""
    if not os.path.exists(MODEL_PATH):
        return None
    try:
        import cv2  # noqa: F401
    except Exception:
        return None
    try:
        times, centers, scores, heights = detect_centers(path, fps)
    except Exception:
        return None

    hits = int((~np.isnan(centers)).sum())
    if hits < max(4, 0.25 * len(centers)):
        # פחות מרבע מהדגימות — לא לסמוך על זה, שיפול חזרה לשיטה הישנה
        return None

    centers = _reject_outliers(centers, heights)
    filled = _fill_gaps(centers)
    if filled is None:
        return None
    smooth, n_moves = virtual_camera(_smooth(filled, fps), fps)

    step = max(1, int(round(NODE_SEC * fps)))
    t_nodes = np.append(times[::step], times[-1])
    v_nodes = np.append(smooth[::step], smooth[-1])
    nodes = _simplify(t_nodes, v_nodes)
    # מגדילים את הסבילות עד שנכנסים לתקרה של ffmpeg. עדיף מסלול קצת
    # פחות מדויק מאשר ביטוי ש-ffmpeg מסרב לפרסר.
    tol = SIMPLIFY_TOL
    while len(nodes) > MAX_NODES and tol < 0.05:
        tol *= 1.3
        nodes = _simplify(t_nodes, v_nodes, tol)
    return {"nodes": nodes, "hit_ratio": hits / len(centers), "moves": n_moves,
            "raw_min": float(np.nanmin(centers)), "raw_max": float(np.nanmax(centers))}


def crop_x_expr(nodes, out_w=1080, subject_x=0.5):
    """
    ביטוי x לפילטר crop — אינטרפולציה לינארית רציפה בין הנקודות.
    `subject_x` — איפה המרכז שנמדד נוחת ברוחב הפלט (0.5 = ממש במרכז).

    🚨 הביטוי **שטוח** (סכום של קטעים חסומי-`gte`/`lt`) ולא `if` מקונן.
    למנתח הביטויים של ffmpeg יש תקרת עומק רקורסיה (~100 ב-`libavutil/eval.c`),
    ומסלול פנים מפורט מגיע ל-100+ נקודות — `if` מקונן היה נופל שם. סכום
    שטוח נקרא בלולאה ולא ברקורסיה, ולכן מספר הנקודות לא מוגבל.
    """
    off = out_w * subject_x

    if not nodes:
        return f"(in_w-{out_w})/2"
    if len(nodes) == 1:
        return f"clip({nodes[0][1]:.5f}*in_w-{off:.1f},0,in_w-{out_w})"

    terms = [f"lt(t,{nodes[0][0]:.3f})*{nodes[0][1]:.5f}"]
    for i in range(len(nodes) - 1):
        t0, v0 = nodes[i]
        t1, v1 = nodes[i + 1]
        span = max(1e-6, t1 - t0)
        slope = (v1 - v0) / span
        terms.append(f"gte(t,{t0:.3f})*lt(t,{t1:.3f})"
                     f"*({v0:.5f}+{slope:+.6f}*(t-{t0:.3f}))")
    terms.append(f"gte(t,{nodes[-1][0]:.3f})*{nodes[-1][1]:.5f}")
    center = "+".join(terms)
    return f"clip(({center})*in_w-{off:.1f},0,in_w-{out_w})"


if __name__ == "__main__":
    vid = sys.argv[1]
    res = track_faces(vid)
    if res is None:
        print("מעקב פנים נכשל — אין מודל/cv2, או מעט מדי זיהויים")
        sys.exit(2)
    print("זיהוי בפועל: %.0f%% מהדגימות · טווח גולמי %.3f–%.3f · %d נקודות · "
          "%d תנועות מצלמה"
          % (res["hit_ratio"] * 100, res["raw_min"], res["raw_max"],
             len(res["nodes"]), res["moves"]))
    for t, v in res["nodes"]:
        print("  %7.2f  center=%.4f" % (t, v))
    if "--json" in sys.argv:
        out = sys.argv[sys.argv.index("--json") + 1]
        res["crop_x"] = crop_x_expr(res["nodes"])
        with open(out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
        print("wrote", out)
