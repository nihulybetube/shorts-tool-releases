# -*- coding: utf-8 -*-
"""
auto_pipeline.py — הפייפליין כולו, רץ **בלי בן אדם באמצע**.

זה מה שמפריד בין "שירות שהמשתמש נותן ידנית" לבין מוצר. הסקיל `yeshiva-shorts`
הוא תהליך מודרך שבו סוכן מקבל החלטות תוכן בכל שלב; כאן אותם שלבים בדיוק
רצים אוטומטית, וכל החלטה שדרשה שיקול דעת הפכה ל**שער נמדד**:

| השלב שדרש בן אדם | מה מחליף אותו |
|---|---|
| בחירת קטעים | ג'מיני קורא את הווידאו ומחזיר JSON עם גבולות |
| אימות שהגבול נכון | התמלול המדויק — הגבול נצמד לגבול מילה אמיתי |
| הגהת התמלול | הצלבה בין שני מודלים, ומה שחלוק — יורד מהכתובית |
| "נראה טוב?" | `check_subs` + `check_framing`, שנכשלים בקוד יציאה |

🚨 **שער שנכשל לא מפיל את הבקשה — הוא מסמן את הקליף.** בשירות אמיתי עדיף
לתת להמשתמש שלושה קליפים שאחד מהם מסומן "לבדוק" מאשר להיכשל על כולם.

פלט: שורות JSON ל-stdout (`{"ev":"progress"|"done"|"error", ...}`), כדי
שהעובד ב-Node יוכל לקרוא התקדמות בזמן אמת בלי לפרסר טקסט חופשי.

שימוש: shorts.sh py auto_pipeline.py <spec.json>
"""
import json
import music_library as ML
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

SH = os.environ.get("SHORTS_SKILL_HOME",
                    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
LIB = os.environ.get("SHORTS_LIB", os.path.join(SH, "assets"))
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")
PY = sys.executable

PAD = 25.0          # ריפוד סביב ההצעה של ג'מיני, לתמלול מדויק לפני החיתוך
MIN_CLIP = 20.0
MAX_CLIP = 180.0


def emit(ev, **kw):
    print(json.dumps({"ev": ev, "t": round(time.time(), 3), **kw}, ensure_ascii=False), flush=True)


def progress(msg, pct=None):
    emit("progress", msg=msg, pct=pct)


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", **kw)
    if r.returncode != 0:
        tail = "\n".join((r.stderr or r.stdout or "").strip().splitlines()[-8:])
        raise RuntimeError("%s נכשל:\n%s" % (os.path.basename(str(cmd[0])), tail))
    return r.stdout


def probe_duration(p):
    return float(run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
                      "-of", "csv=p=0", p]).strip())


# ─────────────────────────── 1. הורדה ───────────────────────────

def download(url, out_mp4):
    if os.path.exists(out_mp4) and os.path.getsize(out_mp4) > 1e6:
        try:
            probe_duration(out_mp4)
            return out_mp4
        except Exception:
            os.remove(out_mp4)
    progress("מוריד את הסרטון מיוטיוב")
    # `shorts.sh yt-dlp` מוסיף את ה-cookies לבד. בלעדיהן יוטיוב מחזיר
    # "Sign in to confirm you're not a bot" מכל IP של דאטה-סנטר.
    run([os.path.join(SH, "shorts.sh"), "yt-dlp",
         "-f", "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b",
         "--merge-output-format", "mp4", "-o", out_mp4, "--", url])
    if not os.path.exists(out_mp4):
        raise RuntimeError("ההורדה הסתיימה בלי קובץ")
    return out_mp4


# ──────────────────── 2. בחירת קטעים (ג'מיני) ────────────────────

SELECT_PROMPT = """אתה עורך תוכן שבוחר קטעי שורטס מתוך הרצאה מצולמת.

צפה בסרטון ובחר בדיוק {n} קטעים. לכל קטע:
- 30 עד 90 שניות. שלם: מתחיל בתחילת משפט ונגמר אחרי הפואנטה.
- **חמש השניות הראשונות חייבות להחזיק צופה.** נפסל: הקדמה, התארגנות
  ("אם כן", "אני רוצה לומר"), ציטוט מקור לפני שברור למה, מוסר השכל לפני הסיפור.
- עדיפות לסיפור קצר עם פואנטה.
- **אסור** שקטע ייגמר לפני המסר שלו. אם הפואנטה ב-2:30, הקטע נגמר אחריה.

{extra}

זמנים: כתוב אותם כמחרוזת בפורמט **דקות:שניות** מתחילת הסרטון,
למשל "40:14" לארבעים דקות וארבע-עשרה שניות. אורך הסרטון הוא {dur}.

החזר **אך ורק JSON** בפורמט הזה, בלי טקסט לפניו או אחריו:
{{"clips":[{{"start":"40:14","end":"41:44",
"title":"כותרת קצרה ומסקרנת בעברית, עד 60 תווים",
"hook":"ציטוט מדויק של המשפט הפותח",
"last_words":"ציטוט מדויק של 4-6 המילים האחרונות",
"description":"2-3 משפטים בעברית על מה יש בקטע",
"tags":["תג","תג"]}}]}}"""


def parse_time(v, video_dur):
    """
    מפרסר חותמת זמן מכל צורה שמודל מחזיר בפועל.

    🚨 נולד מכשל אמיתי בריצה הראשונה: ביקשנו שניות בשדה בשם `start_sec`,
    וג'מיני החזיר `40.14` בכוונת **40 דקות ו-14 שניות**. הסינון תפס את זה
    (כל ה"קליפים" יצאו באורך שנייה), אבל בלי הסינון היו נחתכים שלושה
    קטעים אקראיים בתחילת הסרטון. **שם השדה אינו אכיפה של יחידות.**
    """
    if isinstance(v, str):
        t = v.strip()
        if ":" in t:
            parts = [float(x) for x in t.split(":")]
            sec = 0.0
            for x in parts:
                sec = sec * 60 + x
            return sec
        v = float(t)
    return float(v)


def _resolve_units(cands, video_dur):
    """בוחר בין 'שניות' ל-'דקות.שניות' לפי מה שמייצר קטעים סבירים לכל הסט."""
    def as_mmss(x):
        m = int(x)
        return m * 60 + round((x - m) * 100)

    plain_ok = all(MIN_CLIP <= c["end"] - c["start"] <= MAX_CLIP
                   and c["end"] <= video_dur for c in cands)
    if plain_ok:
        return cands
    conv = [dict(c, start=as_mmss(c["start"]), end=as_mmss(c["end"])) for c in cands]
    conv_ok = all(MIN_CLIP <= c["end"] - c["start"] <= MAX_CLIP
                  and c["end"] <= video_dur for c in conv)
    if conv_ok:
        emit("warn", msg="חותמות הזמן פורשו כדקות.שניות ולא כשניות")
        return conv
    return cands            # שיישפט בסינון הרגיל ויידחה עם הודעה ברורה


def gemini_select(video, n, extra, out_raw, video_dur):
    progress("ג'מיני צופה בסרטון ובוחר קטעים (זה השלב הארוך)")
    import ask_gemini_upload as UP
    api_key = UP.load_api_key()
    uri, mime = UP.upload_file(video, api_key)
    prompt = SELECT_PROMPT.format(n=n, extra=extra or "", dur=_hhmm(video_dur))
    # `ask` זורק אם video_tokens==0 — זו ההוכחה שהוא באמת צפה ולא ניחש
    # ממטא-דאטה. אל תעקוף את זה: זה השער היחיד שמבדיל בין ניתוח להזיה.
    txt, video_tokens = UP.ask(uri, mime, prompt, api_key)
    with open(out_raw, "w", encoding="utf-8") as f:
        f.write(txt)
    emit("usage", gemini_video_tokens=video_tokens)
    return parse_clip_json(txt, video_dur)


def _hhmm(sec):
    return "%d:%02d" % (int(sec // 60), int(sec % 60))


def parse_clip_json(txt, video_dur):
    """ג'מיני עוטף JSON ב-```json למרות שביקשנו שלא. לא נלחמים בזה."""
    m = re.search(r"\{[\s\S]*\}", txt)
    if not m:
        raise RuntimeError("ג'מיני לא החזיר JSON")
    data = json.loads(m.group(0))
    clips = data.get("clips") or []
    raw = []
    for c in clips:
        try:
            s = parse_time(c.get("start", c.get("start_sec")), video_dur)
            e = parse_time(c.get("end", c.get("end_sec")), video_dur)
        except Exception:
            continue
        raw.append({"start": s, "end": e, "title": c.get("title", ""),
                    "hook": c.get("hook", ""), "last_words": c.get("last_words", ""),
                    "description": c.get("description", ""), "tags": c.get("tags", [])})
    out = []
    for c in _resolve_units(raw, video_dur):
        s, e = c["start"], c["end"]
        if not (MIN_CLIP <= e - s <= MAX_CLIP) or e > video_dur + 1:
            emit("warn", msg="הצעה נדחתה: %s (%.0f–%.0f שניות)"
                 % (c.get("title") or "ללא כותרת", s, e))
            continue
        out.append({"start": s, "end": e, "title": c.get("title", ""),
                    "hook": c.get("hook", ""), "last_words": c.get("last_words", ""),
                    "description": c.get("description", ""), "tags": c.get("tags", [])})
    if not out:
        raise RuntimeError("אף הצעה של ג'מיני לא עברה בדיקת שפיות")
    return out


# ──────────── 3. גבולות מדויקים מתוך תמלול פר-מילה ────────────

def transcribe(media, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    run([PY, os.path.join(SH, "pipeline", "scripts", "asr.py"), "run",
         "--media", media, "--out-dir", out_dir])
    stem = os.path.splitext(os.path.basename(media))[0]
    return os.path.join(out_dir, stem + "_words.json")


def norm(t):
    return re.sub(r"[^א-תA-Za-z]", "", t)


def snap_bounds(words, want_start, want_end, phrase_start, phrase_end):
    """
    מזיז את הגבולות לגבול מילה אמיתי.

    🚨 זה השלב שמונע את שני הפגמים שהמשתמש דיווח עליהם בגרסה הידנית:
    קליף שנפתח באמצע מילה, וקליף שנגמר לפני הפואנטה. חותמות הזמן של
    ג'מיני הן הערכה מהצפייה; רק התמלול פר-מילה יודע איפה מילה באמת מתחילה.
    """
    if not words:
        return want_start, want_end
    ns = [norm(w["word"]) for w in words]

    def find(phrase, near, backwards=False):
        toks = [norm(x) for x in (phrase or "").split() if norm(x)]
        if len(toks) < 2:
            return None
        best, best_d = None, 1e9
        for i in range(len(ns) - len(toks) + 1):
            if ns[i:i + len(toks)] == toks:
                t = words[i + len(toks) - 1]["end"] if backwards else words[i]["start"]
                d = abs(t - near)
                if d < best_d:
                    best, best_d = t, d
        return best if best_d < 30 else None

    s = find(phrase_start, want_start)
    e = find(phrase_end, want_end, backwards=True)
    if s is None:
        cand = [w["start"] for w in words if w["start"] >= want_start - 2.0]
        s = min(cand, key=lambda t: abs(t - want_start)) if cand else want_start
    if e is None:
        cand = [w["end"] for w in words if w["end"] <= want_end + 2.0]
        e = max(cand) if cand else want_end
    s = max(0.0, s - 0.25)
    e = e + 0.9                      # נחיתה: בלי זה המשפט האחרון נשמע קטוע
    if e - s < MIN_CLIP:
        e = s + MIN_CLIP
    return s, e


# ──────────────── 4-8. בניית קליף בודד ────────────────

def build_clip(job, idx, start, end, meta):
    import build_clean_video as BCV
    import build_ass as BA

    work = os.path.join(job, "work")
    subs = os.path.join(work, "subtitles")
    os.makedirs(subs, exist_ok=True)
    raw = os.path.join(work, "clips", "clip%d_raw.mp4" % idx)
    os.makedirs(os.path.dirname(raw), exist_ok=True)
    clean = os.path.join(work, "clips", "clip%d_clean.mp4" % idx)
    trf = os.path.join("work", "clips", "clip%d_transforms.trf" % idx)  # יחסי — ראה סקיל

    progress("קליף %d: חותך מהמקור" % idx)
    run([FFMPEG, "-y", "-v", "error", "-ss", "%.3f" % start,
         "-i", os.path.join(job, "source", "full_video.mp4"), "-t", "%.3f" % (end - start),
         "-c:v", "libx264", "-preset", "medium", "-crf", "18",
         "-c:a", "aac", "-b:a", "192k", raw])

    progress("קליף %d: מייצב וממרכז על הפנים" % idx)
    cwd = os.getcwd()
    os.chdir(job)
    try:
        BCV.build_clean(os.path.relpath(raw, job), trf, os.path.relpath(clean, job),
                        subject_x=0.5, cut_silence=False)
    finally:
        os.chdir(cwd)

    progress("קליף %d: מתמלל" % idx)
    words_json = transcribe(clean, subs)
    asr = json.load(open(words_json, encoding="utf-8"))["words"]

    progress("קליף %d: מצליב מול מודל שני ומגיה" % idx)
    clean_txt = proofread(clean, asr, subs, idx, meta)

    aligned = os.path.join(subs, "clip%d_words.json" % idx)
    import align_clean_text as ACT
    with open(os.path.join(subs, "clip%d_final.txt" % idx), "w", encoding="utf-8") as f:
        f.write(clean_txt)
    out = ACT.align(asr, clean_txt)
    json.dump({"words": out}, open(aligned, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    import check_subs as CS
    ratio, worst, _ = CS.analyze(asr, out)
    ass = os.path.join(subs, "clip%d.ass" % idx)
    BA.build_ass(aligned, ass)

    progress("קליף %d: צורב כתוביות ולוגו" % idx)
    outdir = os.path.join(job, "out", "clip%d" % idx)
    os.makedirs(outdir, exist_ok=True)
    plain = os.path.join(outdir, "video.mp4")
    BCV.burn_subtitles(clean, ass, plain, os.path.join(LIB, "fonts"),
                       logo_path=job_logo(job))

    music, music_credit = None, None
    if meta.get("want_music"):
        progress("קליף %d: מוסיף גרסה עם מוזיקה" % idx)
        pick = choose_music(end - start, meta.get("music_mood"))
        if pick:
            import add_music as AM
            music = AM.add_music(plain, pick["path"])
            music_credit = pick["credit"]
            ML.cmd_used(_Args(uuid=pick["uuid"], clip=outdir, project=job))
        else:
            # אין ספרייה, או שכל מה שיש נפסל. גרסה בלי מוזיקה היא תוצר
            # תקין — הפלה כאן הייתה מבטלת קליף גמור בגלל תוספת לא חיונית.
            progress("קליף %d: אין טראק מתאים — ממשיך בלי מוזיקה" % idx)

    progress("קליף %d: בודק מיסגור" % idx)
    qc = framing_qc(plain)
    qc.update({"subtitle_coverage": round(ratio, 4), "subtitle_worst_gap": round(worst, 2)})
    qc["ok"] = (ratio >= 0.90 and worst <= 3.0
                and qc.get("far_run", 99) <= 2.5 and qc.get("in_tol", 0) >= 0.75)
    return {"plain": plain, "music": music, "music_credit": music_credit,
            "qc": qc, "start": start, "end": end}


class _Args:
    """music_library מקבל Namespace של argparse; זה אותו חוזה בלי לעבור דרך shell."""
    def __init__(self, **kw):
        self.__dict__.update(kw)
        self.__dict__.setdefault("project", "")


def choose_music(duration, mood=None):
    """בוחר טראק לקליף הזה — מהספרייה, לפי אופי ולפי מה שעבד בעבר.

    מחזיר None כשאין ספרייה או כשהסינון ריק. זה מצב תקין ולא שגיאה:
    המוזיקה היא תוספת, והקליף בלי מוזיקה שלם."""
    try:
        idx = ML.load_index()
        fb = ML.load_feedback()
        pool = [t for t in ML.downloaded_tracks(idx) if ML.track_score(fb, t["uuid"]) > -2]
        if mood:
            pool = [t for t in pool if mood in t["moods"]]
        # 🚨 טראק קצר מהקליף מתחיל לולאה שנשמעת כמו תקלה. add_music מלווּפ,
        # אבל לולאה בת 20 שניות בקליף של דקה בולטת לאוזן.
        pool = [t for t in pool if t["seconds"] >= max(30, duration)] or pool
        if not pool:
            return None
        used = lambda t: len(fb.get("tracks", {}).get(t["uuid"], {}).get("uses", []))
        pool.sort(key=lambda t: (-ML.track_score(fb, t["uuid"]), used(t), t["title"]))
        best = pool[0]
        lic = ML.load_json(best["path"] + ".license.json", {})
        return {"path": best["path"], "uuid": best["uuid"],
                "credit": lic.get("credit_line", "")}
    except Exception as e:
        print("  ! בחירת מוזיקה נכשלה: %s" % e)
        return None


def job_logo(job):
    """לוגו של הריצה הזאת גובר; אחרת הלוגו שהמשתמש בחר ב-setup; אחרת אין.

    "אחרת אין" הוא מכוון: הלוגו הוא המותג של מי שמריץ, ואין לנו אחד
    לתת לו. קליף בלי לוגו הוא תוצר תקין; קליף עם לוגו זר הוא תקלה."""
    p = os.path.join(job, "logo.png")
    if os.path.exists(p):
        return p
    env = os.environ.get("SHORTS_LOGO", "")
    return env if env and os.path.exists(env) else None


def framing_qc(video):
    try:
        import numpy as np
        import face_track as FT
        t, c, s, h = FT.detect_centers(video)
        c = FT._reject_outliers(c, h)
        ok = ~np.isnan(c)
        if ok.sum() == 0:
            return {"in_tol": 0.0, "far_run": 99.0, "note": "לא זוהו פנים"}
        dev = np.abs(c[ok] - 0.5)
        tt = t[ok]
        far = dev > 0.30
        runs, cur, worst = [], None, 0.0
        for k, m in enumerate(far):
            if m and cur is None:
                cur = tt[k]
            elif not m and cur is not None:
                runs.append(tt[k] - cur); cur = None
        if cur is not None:
            runs.append(tt[-1] - cur)
        worst = max(runs) if runs else 0.0
        return {"in_tol": round(float((dev <= 0.25).mean()), 3),
                "mean_dev": round(float(dev.mean()), 3),
                "far_run": round(float(worst), 2)}
    except Exception as e:
        return {"in_tol": 0.0, "far_run": 99.0, "note": "בדיקת מיסגור נכשלה: %s" % e}


# ──────────────── ההגהה האוטומטית ────────────────

MERGE_PROMPT = """לפניך שני תמלולים של אותו קטע אודיו בעברית, משני מנועים שונים.

תמלול א (whisper):
{a}

תמלול ב (מודל שני):
{b}

כתוב גרסה נקייה אחת, לפי הכללים:
- הטקסט חייב לכסות את **כל** מה שנאמר. אל תקצר ואל תדלג על משפטים.
- מילה ששני התמלולים חלוקים עליה — בחר את הקריאה שהגיונית בהקשר.
- ציטוט מפסוק או מחז"ל — לנוסח המקורי המדויק.
- קטע שבשני התמלולים יוצא ג'יבריש — **השמט אותו**, אל תנחש.
- בלי חותמות זמן, בלי הערות. רק הטקסט.

החזר רק את הטקסט הנקי."""


def proofread(clean_video, asr_words, subs_dir, idx, meta):
    """
    מייצר את הטקסט שנצרב. **לא** מעתיק ASR אחד.

    הכשל שזה מונע מתועד בסקיל: whisper העברי טועה עקבית בשמות ובמונחי
    הלכה, וטעות כזאת נצרבת לסרטון ובלתי הפיכה. שני מודלים טועים טעויות
    **שונות**, ולכן החילוק ביניהם מסמן בדיוק איפה צריך הכרעה.
    """
    whisper_txt = " ".join(w["word"].strip() for w in asr_words)
    wav = os.path.join(subs_dir, "clip%d.wav" % idx)
    run([FFMPEG, "-y", "-v", "error", "-i", clean_video, "-vn", "-ac", "1",
         "-ar", "16000", "-c:a", "pcm_s16le", wav])
    second = ""
    try:
        import ask_gemini_upload as UP
        import gemini_verify_audio as GVA
        api_key = UP.load_api_key()
        uri, mime = UP.upload_file(wav, api_key)
        hint = meta.get("hint", "")
        prompt = GVA.PROMPT + (f"\nהקשר שעשוי לעזור: {hint}\n" if hint else "")
        second, audio_tokens = GVA.ask_audio([(uri, mime)], prompt, api_key)
        second = second.strip()
        with open(os.path.join(subs_dir, "clip%d_gemini.txt" % idx), "w",
                  encoding="utf-8") as f:
            f.write(second)
        emit("usage", gemini_audio_tokens=audio_tokens, clip=idx)
    except Exception as e:
        emit("warn", msg="ההצלבה מול המודל השני נכשלה בקליף %d: %s" % (idx, e))
    if not second:
        return whisper_txt     # עדיף תמלול אחד מאשר בלי כתוביות בכלל

    try:
        from gemini_text import ask_text
        merged = ask_text(MERGE_PROMPT.format(a=whisper_txt, b=second)).strip()
        # שער שפיות: מיזוג שיצא קצר בהרבה = המודל קיצר במקום להגיה
        if merged and len(merged.split()) >= 0.75 * len(whisper_txt.split()):
            return merged
        emit("warn", msg="ההגהה בקליף %d יצאה קצרה מדי — נשאר התמלול המקורי" % idx)
    except Exception as e:
        emit("warn", msg="ההגהה בקליף %d נכשלה: %s" % (idx, e))
    return whisper_txt


# ──────────────────────────── main ────────────────────────────

def main():
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    job = spec["job_dir"]
    os.makedirs(os.path.join(job, "source"), exist_ok=True)
    n = int(spec.get("clip_count") or 3)

    src = download(spec["youtube_url"], os.path.join(job, "source", "full_video.mp4"))
    dur = probe_duration(src)
    emit("meta", duration=round(dur, 1))

    extra = []
    if spec.get("brand_name"):
        extra.append("שם הגוף: %s" % spec["brand_name"])
    if spec.get("notes"):
        extra.append("בקשה מיוחדת של המזמין: %s" % spec["notes"])
    cands = gemini_select(src, n, "\n".join(extra),
                          os.path.join(job, "gemini_raw.txt"), dur)
    emit("candidates", clips=[{"start": c["start"], "end": c["end"], "title": c["title"]}
                              for c in cands])

    results = []
    for i, c in enumerate(cands[:n], start=1):
        try:
            progress("קליף %d מתוך %d: מאמת גבולות מול תמלול" % (i, n),
                     pct=int(20 + 70 * (i - 1) / n))
            lo = max(0.0, c["start"] - PAD)
            hi = min(dur, c["end"] + PAD)
            win = os.path.join(job, "work", "win%d.wav" % i)
            os.makedirs(os.path.dirname(win), exist_ok=True)
            run([FFMPEG, "-y", "-v", "error", "-ss", "%.3f" % lo, "-i", src,
                 "-t", "%.3f" % (hi - lo), "-vn", "-ac", "1", "-ar", "16000",
                 "-c:a", "pcm_s16le", win])
            wj = transcribe(win, os.path.join(job, "work", "transcripts"))
            words = json.load(open(wj, encoding="utf-8"))["words"]
            for w in words:
                w["start"] += lo
                w["end"] += lo
            s, e = snap_bounds(words, c["start"], c["end"], c["hook"], c["last_words"])
            meta = dict(c)
            meta["want_music"] = bool(spec.get("want_music"))
            meta["hint"] = "%s. %s" % (spec.get("brand_name") or "", c.get("description") or "")
            r = build_clip(job, i, s, e, meta)
            results.append({**c, **r, "idx": i})
        except Exception as ex:
            emit("warn", msg="קליף %d נכשל ולא ייכלל: %s" % (i, ex))

    if not results:
        emit("error", msg="אף קליף לא הופק")
        return 1

    def described(r):
        """🚨 הקרדיט נכנס לתיאור עצמו, לא לשדה נפרד לידו.

        הרישיון (CC BY 4.0) מחייב קרדיט *בסרטון או בתיאורו*. שדה נפרד
        ב-JSON מסתמך על כך שמישהו יזכור להעתיק אותו גם — וזה בדיוק מה
        שלא קורה בהעלאה השלוש-עשרה. מי שמשתמש בגרסה בלי מוזיקה פשוט
        מוחק את השורה."""
        d = r["description"]
        if r.get("music") and r.get("music_credit"):
            d = "%s\n\nמוזיקה: %s" % (d, r["music_credit"])
        return d

    emit("done", clips=[{
        "idx": r["idx"], "title": r["title"], "hook": r["hook"],
        "description": described(r), "tags": r.get("tags") or [],
        "start_sec": round(r["start"], 2), "end_sec": round(r["end"], 2),
        "file_plain": os.path.relpath(r["plain"], job),
        "file_music": os.path.relpath(r["music"], job) if r.get("music") else None,
        "music_credit": r.get("music_credit"),
        "qc": r["qc"],
    } for r in results])
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        emit("error", msg=str(e))
        sys.exit(1)
