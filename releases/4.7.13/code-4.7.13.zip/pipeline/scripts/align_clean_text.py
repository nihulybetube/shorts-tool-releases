# -*- coding: utf-8 -*-
"""
מיישר טקסט "נקי" (קוהרנטי, שנכתב ידנית) על טיימסטמפים מהתמלול האוטומטי,
באמצעות השוואת רצפים (במקום התאמת-מחרוזת-מדויקת שבירה).
לכל מילה בטקסט הנקי: אם יש לה match ישיר במילה מתומללת קרובה - משתמשים
בזמן שלה. אחרת - אינטרפולציה לינארית בין העוגנים התואמים הקרובים.
"""
import json
import re
from difflib import SequenceMatcher


def normalize(t):
    # אותיות לטיניות נשמרות: כשהטקסט הנקי כותב "RPG" ו-ASR שמע "הרפג'י",
    # בלי זה שתיהן היו מתנרמלות למחרוזת ריקה ומתחברות זו לזו כעוגן שקרי.
    return re.sub(r"[^א-תA-Za-z]", "", t)


def align(asr_words, clean_text):
    clean_words = clean_text.split()
    asr_norm = [normalize(w["word"]) for w in asr_words]
    clean_norm = [normalize(w) for w in clean_words]

    sm = SequenceMatcher(None, asr_norm, clean_norm, autojunk=False)
    blocks = sm.get_matching_blocks()

    # anchors: (clean_index -> (start_time, end_time)) לכל מילה שתואמת ישירות
    anchor_time = {}
    for b in blocks:
        for k in range(b.size):
            asr_idx = b.a + k
            clean_idx = b.b + k
            anchor_time[clean_idx] = (asr_words[asr_idx]["start"], asr_words[asr_idx]["end"])

    # 21/10/2026 (כרטיס 12): מילה שהוחלפה (ספק [א / ב] שהוכרע לאוזן השנייה, או "משהו אחר" שהקליד) קיבלה עד
    # היום זמן מאינטרפולציה בין העוגנים — באמצע השקט שלפניה, חצי שנייה באיחור, ובשורה משלה (multi-piece-clips
    # in memory: "copy the ASR word's start/end"). כאן: החלפה של N מילים ב-N מילים — כל מילה מקבלת את הזמן של
    # המילה שהחליפה; מספר אחר של מילים — מתחלקות שווה על הטווח של המילים שהוחלפו.
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op != "replace":
            continue
        if i2 - i1 == j2 - j1:
            for k in range(j2 - j1):
                anchor_time[j1 + k] = (asr_words[i1 + k]["start"], asr_words[i1 + k]["end"])
        else:
            t0, t1 = asr_words[i1]["start"], asr_words[i2 - 1]["end"]
            step = (t1 - t0) / (j2 - j1)
            for k in range(j2 - j1):
                anchor_time[j1 + k] = (t0 + step * k, t0 + step * (k + 1))

    n = len(clean_words)
    result = []
    anchors_sorted = sorted(anchor_time.keys())

    def find_surrounding(idx):
        prev_a = max([a for a in anchors_sorted if a <= idx], default=None)
        next_a = min([a for a in anchors_sorted if a >= idx], default=None)
        return prev_a, next_a

    for i in range(n):
        if i in anchor_time:
            start, end = anchor_time[i]
        else:
            prev_a, next_a = find_surrounding(i)
            if prev_a is None and next_a is None:
                start = end = asr_words[0]["start"] if asr_words else 0.0
            elif prev_a is None:
                start = end = anchor_time[next_a][0]
            elif next_a is None:
                start = end = anchor_time[prev_a][1]
            else:
                t0 = anchor_time[prev_a][1]
                t1 = anchor_time[next_a][0]
                span = next_a - prev_a
                frac_start = (i - prev_a) / span
                frac_end = (i - prev_a + 1) / span
                start = t0 + (t1 - t0) * frac_start
                end = t0 + (t1 - t0) * frac_end
                if end <= start:
                    end = start + 0.15
        result.append({"word": " " + clean_words[i], "start": round(start, 3), "end": round(end, 3)})

    return result


if __name__ == "__main__":
    import sys
    asr_json_path, clean_text_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    with open(asr_json_path, encoding="utf-8") as f:
        data = json.load(f)
    with open(clean_text_path, encoding="utf-8") as f:
        clean_text = f.read().strip()
    aligned = align(data["words"], clean_text)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"clip": data.get("clip"), "words": aligned}, f, ensure_ascii=False, indent=2)
