# -*- coding: utf-8 -*-
"""
make_short_modal_day.py — תקרת Modal ליום (22/10/2026, בקשתו).

למה: עד היום אושרה כל בקשה לבד מעל סכום ("modal_confirm_usd"), כך שעשר בקשות קטנות עברו בלי
שאלה ואחת גדולה עצרה. הכלל שלו הוא ליום: "עד $1–2 ביום, מעבר לזה לשאול". אז סופרים כמה כבר
הוצא היום, ועבודה רצה בלי לשאול כל עוד (היום כבר + ההערכה שלה) ≤ התקרה; רק עבודה שתעבור
את התקרה שואלת, ומראה את שלושת המספרים.

"היום כבר" = הגבוה מבין שני מקורות:
  (א) סכום ההערכות של עבודות שהתחילו היום (נרשמות כאן כשהן מתחילות לשלוח ל-Modal);
  (ב) דוח החיוב של Modal להיום (נקרא עם מד Modal — בחינם; מתעדכן אצלם באיחור של כמה דקות,
      וכולל גם שימוש מחוץ לתוכנה, למשל עבודה עם Claude).
"""
import json
import os
import time
from pathlib import Path

import make_short_settings as SET

DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
TEST = os.environ.get("MAKE_SHORT_NO_EXPORT") == "1"
LEDGER = Path(os.environ.get("MAKE_SHORT_MODAL_DAY") or DATA / ("modal_day_test.json" if TEST else "modal_day.json"))

# הערכות (נמדד 14–21/10): תמלול בחירה (turbo, כל השיעור) ≈ 0.0015$ לדקה; אוזניים של קליפים
# (large-v3 + turbo, קבצים קצרים — עיקר העלות הוא ההפעלה) ≈ 1 סנט לקובץ + 0.4 סנט לדקה
PICK_PER_MIN = 0.0015
CLIP_PER_FILE, CLIP_PER_MIN = 0.01, 0.004


def today():
    return time.strftime("%Y-%m-%d")


def _read():
    try:
        d = json.loads(LEDGER.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if d.get("day") != today():
        d = {"day": today(), "jobs": [], "billing": None}
    return d


def _edit(fn):
    import fcntl
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with open(str(LEDGER) + ".lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = _read()
        fn(d)
        tmp = LEDGER.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(LEDGER)
        return d


def cap():
    """תמיד התקרה שבהגדרות *עכשיו* — גם בעבודה שרצה מצילום הגדרות (כרטיס 14): זה תקציב של היום, לא של העבודה,
    ואם העלה את התקרה אחרי שעבודה נעצרה עליה — "נסה שוב" צריך לראות את החדשה."""
    snap = os.environ.get("MAKE_SHORT_SETTINGS_SNAP")
    if snap:
        try:
            live = json.loads(Path(snap).read_text(encoding="utf-8")).get("snapshot_of")
            if live and Path(live).exists():
                v = json.loads(Path(live).read_text(encoding="utf-8")).get("values") or {}
                if "modal_day_cap" in v or "modal_confirm_usd" in v:
                    return max(0.0, min(30.0, float(v.get("modal_day_cap", v.get("modal_confirm_usd")))))
                return float(SET.DEFAULTS["modal_day_cap"])
        except (OSError, ValueError, TypeError):
            pass
    return float(SET.load()["modal_day_cap"])


def view():
    d = _read()
    est = round(sum(float(j.get("usd") or 0) for j in d["jobs"]), 3)
    bill = (d.get("billing") or {}).get("usd")
    spent = round(max(est, float(bill or 0)), 3)
    return {"day": d["day"], "est_sum": est, "billing": bill, "billing_at": (d.get("billing") or {}).get("at", ""),
            "spent": spent, "cap": cap(), "jobs": d["jobs"][-20:]}


def numbers(est, v=None):
    v = v or view()
    return "היום כבר: $%.2f · הפעולה: ~$%.2f · התקרה: $%.2f" % (v["spent"], est, v["cap"])


def check(est):
    """(אפשר_בלי_לשאול, פרטים). התקרה 0 = תמיד לשאול לפני Modal."""
    v = view()
    ok = v["cap"] > 0 and v["spent"] + est <= v["cap"] + 1e-9
    return ok, dict(v, est=round(est, 3), text=numbers(est, v))


def record(usd, what):
    """עבודה ששולחת ל-Modal — ההערכה שלה נכנסת ל"היום כבר" כבר כשהיא מתחילה."""
    _edit(lambda d: d["jobs"].append({"at": time.strftime("%H:%M"), "usd": round(float(usd), 3), "what": str(what)[:80]}))


def set_billing(usd):
    """מה ש-Modal עצמו אומר שהוצא היום (המד קורא את זה) — הגבוה מבין זה לבין ההערכות קובע."""
    _edit(lambda d: d.update(billing={"usd": round(float(usd), 3), "at": time.strftime("%H:%M")}))


def clip_estimate(seconds_list):
    return round(sum(CLIP_PER_FILE + (s or 0) / 60.0 * CLIP_PER_MIN for s in seconds_list), 3)


class OverCap(RuntimeError):
    """עבודה שתעבור את תקרת היום — נעצרת לפני שנשלח משהו ל-Modal, עד שהוא מאשר."""


def gate(est, what):
    """לפני שליחה ל-Modal מתוך עבודה (הכנה / גבולות חדשים): מתחת לתקרה — נרשם וממשיכים;
    מעל — עוצרים עם שלושת המספרים, אלא אם אישר ("אשר והמשך" → MAKE_SHORT_MODAL_OK=1)."""
    ok, info = check(est)
    if not ok and os.environ.get("MAKE_SHORT_MODAL_OK") != "1":
        raise OverCap("עובר את תקרת Modal היומית — %s. לא נשלח כלום ל-Modal. "
                      "(אפשר: \"✓ אשר והמשך\", או להעלות את התקרה בהגדרות)" % info["text"])
    record(est, what)
    return info
