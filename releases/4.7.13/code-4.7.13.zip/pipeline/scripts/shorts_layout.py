# -*- coding: utf-8 -*-
"""מבנה תיקיית השורטסים המוכנים (כרטיס 16, 22/10/2026).

בקשתו: "אני לוחץ מלא פעמים על התיקיות עד שאני מגיע לתוצר... שהכותרות שם כבר יהיו קשורות למה שהיה
בתוכנה". עד היום שורט ישב חמש תיקיות עמוק:
    <הרב>/<הסדרה>/<תאריך>_<slug>/shorts/clipN_<כותרת>/<קובץ>
מעכשיו (גם התוכנה וגם הייצוא של Claude):
    <הרב>/<הסדרה>/<כותרת השורט>/<כותרת   הרב>.mp4  +  תיאור להעתקה.txt

כאן רק הכללים — שמות נקיים לרב ולסדרה, התאמה לתיקייה קיימת שכמעט זהה, ושם בטוח לתיקיית השורט.
export_clips.py / make_short.py / reorganize_exports.py משתמשים בזה, כדי שכולם יחליטו אותו דבר.
"""
import os
import re
from pathlib import Path

ROOT_DEFAULT = Path(os.path.expanduser("~/Videos/Shorts"))
DESC_FILE = "תיאור להעתקה.txt"
VIDEO_EXT = (".mp4", ".mov", ".m4v")

# תווים שחלונות פוסלת בשם קובץ/תיקייה (הקבצים נפתחים דרך \\wsl.localhost ונוסעים לדרייב)
_BAD = '/\\:*?"<>|'
_Q = "[\"'״׳`]"
# תארים אחרי השם — לא חלק מהשם (20/10: "הרב יהודה מלמד שליט"א" פתח תיקיית רב חדשה)
_SUFFIX = re.compile(r"(\s+(שליט%sא|זצ%sל|זצוק%sל|זיע%sא|הי%sד|נ%sי|יצ%sו))+\s*$" % ((_Q,) * 7))
# תארים לפני השם — כולם נהיים "הרב" (כלל 4: הרב מכותרת הסרטון בלבד, בצורה "הרב X")
_PREFIX = re.compile(r"^\s*((הרה%sג|הגאון|הרב|כבוד הרב|מו%sר|ר%s|רבי)\s+)+" % (_Q, _Q, _Q))


def _ws(s):
    return " ".join((s or "").split())


def tidy(s, max_len=0):
    """שם בטוח לחלונות: בלי תווים אסורים, רווחים מכווצים, בלי נקודה/רווח בסוף, לא ריק."""
    s = "".join(c for c in (s or "") if c not in _BAD and ord(c) >= 32)
    s = _ws(s)
    if max_len and len(s) > max_len:
        s = s[:max_len]
    return s.rstrip(". ").strip()


def clean_rabbi(name):
    """"הרה"ג זלמן ברוך מלמד שליט"א" / "'הרב  זלמן ברוך מלמד'" → "הרב זלמן ברוך מלמד"."""
    s = _ws(name).strip("\"'״׳ ")
    if not s:
        return ""
    s = _SUFFIX.sub("", s)
    rest = _PREFIX.sub("", s).strip()
    if not rest:
        return ""
    return tidy("הרב " + rest)


def clean_series(name):
    """שם סדרה כתיקייה: מירכאות מסביב, רווחים כפולים ותווים שחלונות פוסלת (בש"ס → בשס) — בחוץ."""
    return tidy(_ws(name).strip("\"'״׳ "))


def name_key(name, rabbi=False):
    """מפתח להשוואה: רק אותיות וספרות (מירכאות/גרשיים/רווחים לא נחשבים), ולרב — בלי התארים."""
    s = _ws(name)
    if rabbi:
        s = _SUFFIX.sub("", s.strip("\"'״׳ "))
        s = _PREFIX.sub("", s)
    return re.sub(r"[^א-תA-Za-z0-9]", "", s)


def match_dir(parent, name, rabbi=False):
    """שם תיקייה קיימת ב-parent שהיא "אותו שם" (name_key זהה) — אחרת השם עצמו. כך "הרה"ג X שליט"א",
    "הרב  X" ו"הרב X" נכנסים כולם לתיקייה האחת שכבר יש, ולא נפתחת כפולה."""
    parent = Path(parent)
    k = name_key(name, rabbi)
    if k and parent.is_dir():
        for d in sorted(parent.iterdir()):
            if d.is_dir() and name_key(d.name, rabbi) == k:
                return d.name
    return name


def resolve_names(root, rabbi, series):
    """(רב, סדרה) נקיים, ואם יש כבר תיקייה כמעט זהה — בשם שלה."""
    root = Path(root)
    r = clean_rabbi(rabbi)
    r = match_dir(root, r, rabbi=True) if r else ""
    s = clean_series(series)
    s = match_dir(root / r, s) if (r and s) else s
    return r, s


def title_part(title):
    """"כותרת | הרב X" → "כותרת" (הרב כבר בתיקיית האב ובשם הקובץ)."""
    return (title or "").split("|")[0].strip()


def win_len(path):
    """אורך הנתיב כפי שסייר הקבצים רואה אותו (\\\\wsl.localhost\\Ubuntu\\home\\...). חלונות נכשלת מעל 260."""
    distro = os.environ.get("WSL_DISTRO_NAME") or "Ubuntu"
    return len("\\\\wsl.localhost\\%s" % distro) + len(str(path))


MAX_WIN_PATH = 250          # מרווח ביטחון מתחת ל-260 (24/9: נתיב של 263 לא הועתק)
FOLDER_MAX = 80


def folder_name(title, file_name="", parent=None):
    """שם תיקיית השורט = הכותרת (בלי שם הרב). מתקצר אם הנתיב המלא לקובץ ארוך מדי לחלונות."""
    base = tidy(title_part(title), FOLDER_MAX) or "שורט"
    if parent is not None and file_name:
        while len(base) > 20 and win_len(Path(parent) / (base + " (9)") / file_name) > MAX_WIN_PATH:
            base = tidy(base[:-1])
    return base


FILE_MIN_STEM = 20
PART_SLACK = len(".part")      # הקובץ נכתב קודם בשם "<שם>.part" ורק אז מקבל את שמו


def fit_file_name(folder, name):
    """31/10/2026 (Gemini review): folder_name מקצר רק את התיקייה (עד 20 תווים) — כותרת של 250 תווים נתנה שם קובץ
    ארוך שהנתיב נשאר מעל MAX_WIN_PATH וההעתקה נכשלה ב-OSError. כאן מקצרים גם את *שם הקובץ* (הסיומת נשארת, כללי tidy
    נשמרים; החיתוך מהסוף, כך שהכותרת נשארת ראשונה). אם הנתיב נכנס — השם לא משתנה."""
    p = Path(name)
    stem, ext = p.stem, p.suffix
    if win_len(Path(folder) / name) + PART_SLACK <= MAX_WIN_PATH:
        return name
    while len(stem) > FILE_MIN_STEM and win_len(Path(folder) / (stem + ext)) + PART_SLACK > MAX_WIN_PATH:
        over = win_len(Path(folder) / (stem + ext)) + PART_SLACK - MAX_WIN_PATH
        stem = tidy(stem[:max(FILE_MIN_STEM, len(stem) - over)]) or stem[:FILE_MIN_STEM]
    return stem + ext


def short_dir(series_dir, title, file_name="", owned=()):
    """התיקייה של שורט אחד בתוך תיקיית הסדרה. תפוסה ע"י שורט אחר (כותרת זהה) → " (2)", " (3)"...
    owned = תיקיות שכבר שייכות לשורט הזה (שמירה חוזרת) — מותר לחזור אליהן."""
    series_dir = Path(series_dir)
    base = folder_name(title, file_name, series_dir)
    owned = {str(Path(o)) for o in owned if o}
    # התיקייה שהשורט כבר נמצא בה ("X (2)") — נשאר בה, גם אם "X" התפנה בינתיים (לא קופצים בלי סיבה)
    mine = re.compile(r"^%s( \(\d+\))?$" % re.escape(base))
    for o in sorted(owned):
        if Path(o).parent == series_dir and mine.match(Path(o).name) and Path(o).is_dir():
            return Path(o)
    for i in range(1, 100):
        cand = series_dir / (base if i == 1 else "%s (%d)" % (base, i))
        if str(cand) in owned or not cand.exists():
            return cand
    raise RuntimeError("יותר מדי שורטים בשם «%s»" % base)


def prune_empty(path, root):
    """תיקיות ריקות שנשארו (סדרה/רב) — יורדות, עד root ולא כולל (22/10: "אל תשאיר לי תיקיות ריקות").
    רק rmdir — תיקייה שיש בה משהו לא נוגעים."""
    root = Path(root).resolve()
    p = Path(path)
    while True:
        try:
            rp = p.resolve()
        except OSError:
            return
        if rp == root or root not in rp.parents:
            return
        try:
            p.rmdir()
        except OSError:
            return
        p = p.parent
