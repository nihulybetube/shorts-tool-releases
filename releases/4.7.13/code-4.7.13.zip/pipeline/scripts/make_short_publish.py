# -*- coding: utf-8 -*-
"""4.3 — צד הבעלים של העדכונים: מפתח החתימה (מוצפן בסיסמה), בניית גרסה נקייה וחתומה, ו"📤 פרסם עדכון".

המפתח הפרטי: קובץ אחד מוצפן (scrypt + AES-GCM) ב-~/.config/yeshiva-shorts/release_key.enc, מחוץ לריפו; רק העותק המוצפן
עולה לדרייב (backup_extras.sh). הסיסמה מוקלדת בחלון, נשמרת בזיכרון רק בזמן הפרסום, ולא נכתבת לשום מקום.

הפרסום (Publisher) רץ ברקע בשלבים; כל פעולה כלפי חוץ (דחיפה לריפו הציבורי, ועדכון latest.json) מחכה לאישור מפורש בחלון.
ביטול אפשרי עד רגע ההפעלה של latest.json; ביטול מחזיר את הריפו הציבורי למצבו (commit הפוך, בלי דריסת היסטוריה).
"""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import threading
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short_release as R  # noqa: E402

CONFIG, DATA = R.CONFIG, R.DATA
KEY_FILE = CONFIG / "release_key.enc"
WORK = DATA / "release_work"
CFG_FILE = CONFIG / "release.json"
PREFIX = "yeshiva-shorts-releases"
GIT_ENV = dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_SSH_COMMAND="ssh -o BatchMode=yes -o ConnectTimeout=15")


# ─────────────────────────── מפתח חתימה ───────────────────────────
def have_key():
    return KEY_FILE.is_file()


KDF_N = 2 ** 17          # 4.5.x: היה 2^15; מפתחות ישנים נקראים לפי ה-n שנשמר בקובץ שלהם


def _derive(passphrase, salt, n=KDF_N, r=8, p=1):
    return hashlib.scrypt(passphrase.encode("utf-8"), salt=salt, n=n, r=r, p=p, maxmem=2 ** 29, dklen=32)


def _write_private(path, text):
    """כותב קובץ סודי שהרשאתו 0600 כבר מהרגע שנוצר (לא נוצר קריא לכולם ואז מתוקן)."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.unlink()
    except OSError:
        pass
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def keygen(passphrase):
    """יוצר זוג מפתחות; הפרטי נשמר מוצפן. מחזיר את הציבורי (base64). לא דורס מפתח קיים."""
    if len(passphrase or "") < 10:
        raise R.UpdateError("הסיסמה קצרה מדי — לפחות 10 תווים (ואי אפשר לשחזר אותה אם תישכח).")
    if KEY_FILE.exists():
        raise R.UpdateError("כבר יש מפתח חתימה — לא יוצרים עוד אחד (זה היה מנתק את כל מי שכבר התקין).")
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives import serialization as S
    k = Ed25519PrivateKey.generate()
    seed = k.private_bytes(S.Encoding.Raw, S.PrivateFormat.Raw, S.NoEncryption())
    pub = k.public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)
    salt, nonce = os.urandom(16), os.urandom(12)
    ct = AESGCM(_derive(passphrase, salt)).encrypt(nonce, seed, b"yeshiva-shorts-release-key-v1")
    R._guard(KEY_FILE)
    KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    _write_private(KEY_FILE, json.dumps({"v": 1, "kdf": "scrypt", "n": KDF_N, "r": 8, "p": 1, "salt": base64.b64encode(salt).decode(),
                                         "nonce": base64.b64encode(nonce).decode(), "ct": base64.b64encode(ct).decode(),
                                         "pub": base64.b64encode(pub).decode()}))
    return base64.b64encode(pub).decode()


def public_key_b64():
    return json.loads(KEY_FILE.read_text(encoding="utf-8"))["pub"]


def load_key(passphrase):
    """מפענח את המפתח הפרטי. סיסמה שגויה → UpdateError. מחזיר Ed25519PrivateKey (בזיכרון בלבד)."""
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    d = json.loads(KEY_FILE.read_text(encoding="utf-8"))
    if not (isinstance(d.get("n"), int) and 2 ** 14 <= d["n"] <= 2 ** 18 and d.get("r") == 8 and d.get("p") == 1):
        raise R.UpdateError("קובץ המפתח פגום (פרמטרי הצפנה לא מוכרים).")
    try:
        seed = AESGCM(_derive(passphrase or "", base64.b64decode(d["salt"]), d["n"], d["r"], d["p"])).decrypt(
            base64.b64decode(d["nonce"]), base64.b64decode(d["ct"]), b"yeshiva-shorts-release-key-v1")
    except InvalidTag:
        raise R.UpdateError("הסיסמה שגויה.")
    return Ed25519PrivateKey.from_private_bytes(seed)


def sign(key, data):
    return base64.b64encode(key.sign(data)).decode()


# ─────────────────────────── בניית גרסה ───────────────────────────
def build_release(repo, version, previous, notes, must_not_skip, min_required, out_dir, key, say=print, key_pub=None,
                  include_channel=True):
    """ארכיון קוד נקי (אותה אריזה ניטרלית כמו חבילת השיתוף) + מניפסט + חתימה → out_dir/releases/<ver>/. מחזיר את התיקייה.
    4.6: key=None (ערכת השחזור כשעוד אין מפתח חתימה) → אותו ארכיון ומניפסט, בלי manifest.sig; include_channel=False — בלי
    קובץ ערוץ ההצעות (בערכה של הבעלים הוא משתחזר מהכספת)."""
    import make_short_share as SH
    repo, out_dir = Path(repo), Path(out_dir)
    if R.installed_version(repo) != version:
        raise R.UpdateError("קובץ VERSION (%s) לא תואם לגרסה שמפרסמים (%s)." % (R.installed_version(repo), version))
    tar = subprocess.run(["git", "-C", str(repo), "archive", "--format=tar", "HEAD"], capture_output=True, check=True).stdout
    rdir = out_dir / "releases" / version
    shutil.rmtree(rdir, ignore_errors=True)
    rdir.mkdir(parents=True)
    zname = "code-%s.zip" % version
    files = {}
    with zipfile.ZipFile(rdir / zname, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z, tarfile.open(fileobj=io.BytesIO(tar)) as t:
        for m in sorted(t.getmembers(), key=lambda x: x.name):
            if not m.isfile():
                continue
            raw_data = t.extractfile(m).read()
            # כתובת העדכונים לא עוברת ניטרול שקט (הוא היה מקלקל אותה): אם יש בה זהות שלו — הסריקה למטה חוסמת
            pm = (m.name, raw_data) if m.name == "assets/release_source.json" else SH.package_member(m.name, raw_data, False)
            if pm is None:
                continue
            name, data = pm
            if not R._safe_path(name):
                continue                      # קובץ בשם של סוד/קובץ אישי — לא נארז בשום מקרה
            zi = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            zi.external_attr = ((0o755 if m.mode & 0o111 else 0o644) | 0o100000) << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, data)
            files[name] = {"sha256": R.sha256(data), "size": len(data), "mode": 0o755 if m.mode & 0o111 else 0o644}
        # 4.4: ערוץ ההצעות למנהל (נושאי ntfy אקראיים) — נשמר רק אצל הבעלים, מחוץ לריפו, ונכנס לארכיון החתום בלבד
        try:
            import make_short_proposals as PRP
            cb = PRP.channel_file_bytes() if include_channel else None
        except Exception:
            cb = None
        if cb and PRP.CHANNEL_ASSET not in files:
            zi = zipfile.ZipInfo(PRP.CHANNEL_ASSET, (1980, 1, 1, 0, 0, 0))
            zi.external_attr = (0o644 | 0o100000) << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, cb)
            files[PRP.CHANNEL_ASSET] = {"sha256": R.sha256(cb), "size": len(cb), "mode": 0o644}
    say("   ✓ ארכיון: %d קבצים" % len(files))
    bad = SH.scan(rdir / zname)
    if bad:
        shutil.rmtree(rdir, ignore_errors=True)
        raise R.UpdateError("🚨 נמצא בארכיון משהו שנראה כמו סוד (%s) — לא מפרסמים." % ", ".join(bad[:5]))
    mine = SH.identity_scan(rdir / zname, profile=False)
    if mine:
        shutil.rmtree(rdir, ignore_errors=True)
        raise R.UpdateError("🚨 בארכיון נמצאו פרטים מזהים שלך (%s) — לא מפרסמים. (גם כתובת הריפו הציבורי חייבת להיות ניטרלית.)"
                            % ", ".join(mine[:5]))
    if "VERSION" not in files:
        raise R.UpdateError("בארכיון אין קובץ VERSION.")
    zdata = (rdir / zname).read_bytes()
    if not key_pub and key is not None:
        from cryptography.hazmat.primitives import serialization as S
        key_pub = base64.b64encode(key.public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)).decode()
    manifest = {"format": R.SUPPORTED_FORMAT, "version": version, "date": time.strftime("%Y-%m-%d"), "previous": previous,
                "min_required": min_required or previous, "must_not_skip": bool(must_not_skip),
                "notes": [n.strip() for n in notes if n.strip()], "key_id": R.key_id(key_pub) if key_pub else "",
                "archive": {"name": zname, "size": len(zdata), "sha256": R.sha256(zdata)}, "files": files}
    raw = json.dumps(manifest, ensure_ascii=False, indent=1, sort_keys=True).encode("utf-8")
    (rdir / "manifest.json").write_bytes(raw)
    if key is not None:
        (rdir / "manifest.sig").write_text(sign(key, raw), encoding="ascii")
    return rdir


def new_index(old_bytes, m):
    try:
        d = json.loads(old_bytes.decode("utf-8")) if old_bytes else {}
    except ValueError:
        d = {}
    rel = [r for r in d.get("releases", []) if r.get("version") != m["version"]]
    rel.append({"version": m["version"], "previous": m.get("previous"), "must_not_skip": bool(m.get("must_not_skip")),
                "path": "releases/" + m["version"], "date": m.get("date", "")})
    rel.sort(key=lambda r: R.ver_tuple(r["version"]))
    return json.dumps({"format": R.SUPPORTED_FORMAT, "latest": rel[-1]["version"], "updated": m.get("date", ""), "releases": rel},
                      ensure_ascii=False, indent=1).encode("utf-8")


def base_for_ref(base, sha):
    """כתובת הקבצים בדיוק ב-commit שדחפנו (ב-GitHub raw: .../main → .../<sha>) — כדי לא לקרוא עותק ישן שנשמר במטמון."""
    return re.sub(r"/main$", "/" + sha, base) if base.endswith("/main") else base


# ─────────────────────────── הגדרות ───────────────────────────
def load_cfg():
    try:
        return json.loads(CFG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_cfg(d):
    R._guard(CFG_FILE)
    CFG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CFG_FILE.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    os.chmod(CFG_FILE, 0o600)


OWNER_SCREENS = CONFIG / "owner_screens"      # 4.6.5: סימן "הצג מסכי בעלים" — בלעדיו המסכים מוסתרים עד שיש מפתח חתימה, והמפתח נוצר בהם


def owner_screens_on():
    return OWNER_SCREENS.is_file()


def set_owner_screens(on=True):
    """הכפתור בכרטיס הכספת. רק מראה את המסכים (פרסם עדכון / הצעות) — לא יוצר מפתח ולא שולח כלום."""
    R._guard(OWNER_SCREENS)
    if on:
        OWNER_SCREENS.parent.mkdir(parents=True, exist_ok=True)
        _write_private(OWNER_SCREENS, "1\n")
    else:
        OWNER_SCREENS.unlink(missing_ok=True)


def derived_remote(base):
    """4.7.8: כתובת ה-SSH של הריפו הציבורי, נגזרת מכתובת ההורדה שבקוד (אותו חשבון ואותו ריפו) — כך אין שלב נפרד של "שמירת כתובת"."""
    import make_short_share as SH
    p = SH.release_base_parts(base)
    return "git@github.com:%s/%s.git" % p if p else ""


def effective_remote():
    """הכתובת שמפרסמים אליה: מה שהוגדר ידנית בהגדרות (בדיקות / ריפו אחר), ואחרת הנגזרת מ-assets/release_source.json."""
    return load_cfg().get("remote") or derived_remote(R.source()[0])


def suggested_baseline(repo=None):
    """4.7.8: לפרסום הראשון — הגרסה שלפני הנוכחית (התגית הקודמת), כדי שהשדה "מגרסה" יתמלא לבד. ריק אם אין."""
    repo = Path(repo or R.REPO)
    try:
        cur = "v" + R.installed_version(repo)
        tags = [t for t in R.git(repo, "tag", "--list", "v[0-9]*", check=False).split() if t != cur]
        tags = [t for t in tags if re.match(r"^v\d+\.\d+\.\d+$", t)]
        tags.sort(key=lambda t: tuple(int(x) for x in t[1:].split(".")))
        older = [t for t in tags if tuple(int(x) for x in t[1:].split(".")) < tuple(int(x) for x in cur[1:].split("."))]
        return older[-1][1:] if older else ""
    except Exception:
        return ""


def screen_status(repo=None):
    """מה מוצג במסך "פרסם עדכון" לפני ההתחלה — ומה עוד חסר."""
    repo = repo or R.REPO
    base, keys = R.source()
    cfg = {"remote": effective_remote()}
    missing = []
    if not have_key():
        missing.append("key")
    if not cfg.get("remote"):
        missing.append("remote")
    if not base:
        missing.append("source")
    elif have_key() and public_key_b64() not in keys:
        missing.append("pubkey_not_in_code")
    return {"suggested_baseline": suggested_baseline(repo),
            "visible": have_key() or bool(load_cfg().get("remote")) or os.environ.get("MAKE_SHORT_PUBLISH_SCREEN") == "1" or owner_screens_on(),
            "have_key": have_key(), "remote_set": bool(cfg.get("remote")), "source_set": bool(base),
            "missing": missing, "version": R.installed_version(repo), "pending_cleanup": cleanup_pending() is not None}


def setup(remote, base, repo=None, allow_account=False, save=True):
    """אחרי שהבעלים אישר את שם הריפו הציבורי: שומר את הכתובת (בהגדרות, מחוץ לריפו) וכותב לקוד (assets/release_source.json)
    את כתובת ההורדה ואת המפתח הציבורי. הקובץ בקוד צריך commit + תגית כדי שייכנס לחבילות ולעדכונים. מסרב לכתובת עם זהות שלו.
    4.7.8: allow_account=True (החלטת הבעלים 25/11: הריפו בחשבון GitHub שלו) מתיר את שם החשבון בלבד, ורק בתבנית המדויקת
    https://raw.githubusercontent.com/<חשבון>/<ריפו>/main + git@github.com:<חשבון>/<ריפו>.git — שם הריפו עצמו חייב להיות ניטרלי.
    save=False — לא נוגעים בהגדרות המקומיות (הכתובת נגזרת מהקוד, ראו derived_remote)."""
    import make_short_share as SH
    repo = Path(repo or R.REPO)
    if not have_key():
        raise R.UpdateError("קודם יוצרים מפתח חתימה.")
    if not base.startswith("https://") or not remote:
        raise R.UpdateError("כתובת ההורדה חייבת להתחיל ב-https://")
    low = (base + " " + remote).lower().encode()
    if any(n in low for n in SH.identity_needles(False)):
        parts = SH.release_base_parts(base.rstrip("/"))
        ok = bool(allow_account and parts and remote == "git@github.com:%s/%s.git" % parts
                  and not any(n in parts[1].lower().encode() for n in SH.identity_needles(False)))
        if not ok:
            raise R.UpdateError("הכתובת מכילה פרט מזהה שלך — לבחור שם ניטרלי לריפו (או לארגון).")
    if save:
        save_cfg({"remote": remote})
    f = repo / "assets" / "release_source.json"
    d = {"base": base.rstrip("/"), "pubkey": public_key_b64()}
    if allow_account and any(n in low for n in SH.identity_needles(False)):
        d["account_approved"] = True        # 4.7.8: הבעלים אישר במפורש שם החשבון בכתובת (סריקת הזהות מדלגת על הכתובת הזאת בלבד)
    f.write_text(json.dumps(d, indent=1) + "\n", encoding="utf-8")
    return str(f)


# ─────────────────────────── ניקוי העלאה שנקטעה ───────────────────────────
def _marker():
    return WORK / "cleanup.json"


def cleanup_pending():
    try:
        return json.loads(_marker().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _git(cwd, *a, check=True, env=None):
    r = subprocess.run(["git", "-C", str(cwd)] + list(a), capture_output=True, text=True, errors="replace", timeout=180,
                       env=env or GIT_ENV)
    if check and r.returncode:
        raise R.UpdateError("git %s נכשל: %s" % (a[0], (r.stderr or r.stdout).strip()[-200:]))
    return (r.stdout or "").strip()


def undo_upload(mk):
    """מוציא מהריפו הציבורי את מה שהועלה בהרצה הזאת (commit הפוך, בלי דריסת היסטוריה). רק אם latest.json עוד לא מפנה אליו."""
    work = Path(mk["work"])
    _git(work, "fetch", "-q", "origin")
    head = _git(work, "rev-parse", "origin/main")
    idx = _git(work, "show", "origin/main:latest.json", check=False)
    if idx and ('"%s"' % mk["version"]) in idx:
        raise R.UpdateError("הגרסה כבר מופיעה ב-latest.json — לא מסירים אוטומטית.")
    _git(work, "reset", "-q", "--hard", "origin/main")
    c = mk.get("commit")
    if c:
        # 4.5.x (B8): גם כשה-commit שלנו כבר לא האחרון (מישהו העלה אחריו) — אם הוא בהיסטוריה, מוציאים אותו ב-revert.
        # לא מוחקים את סימון הניקוי בשקט: כשל → UpdateError והסימון נשאר ("נקה" יופיע שוב).
        inside = subprocess.run(["git", "-C", str(work), "merge-base", "--is-ancestor", c, "origin/main"], capture_output=True,
                                env=GIT_ENV, timeout=60).returncode == 0
        if inside:
            if head != c and not _git(work, "diff", "--name-only", c + "^", c, check=False):
                inside = False                         # commit ריק — אין מה להוציא
        if inside:
            _git(work, *R.GIT_ID, "revert", "--no-edit", c)
            _git(work, "push", "-q", "origin", "HEAD:main")
    try:
        _marker().unlink()
    except OSError:
        pass


# ─────────────────────────── הפרסום ───────────────────────────
STEPS = [("preflight", "בדיקות מקדימות", 5), ("plan", "אישור מה יפורסם", 0), ("build", "בניית הארכיון הנקי", 15),
         ("selftest", "בדיקה עצמית", 25), ("sign", "חתימה", 5), ("push", "העלאה לריפו הציבורי", 15),
         ("verify", "הורדה חזרה ואימות", 15), ("final", "אישור אחרון", 0), ("flip", "הפעלת העדכון לכולם", 15),
         ("done", "אימות סופי", 5)]


class Cancelled(Exception):
    pass


def saved_state():
    """המצב האחרון שנשמר בדיסק (אחרי רענון חלון/הפעלה מחדש). 'רץ' שנשמר ע"י תהליך שכבר אינו → נקטע."""
    try:
        d = json.loads((WORK / "publish_state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if d.get("running"):
        d.update(running=False, waiting=None, error="הפרסום נקטע באמצע (התוכנה נסגרה). מה שהועלה נוקה בלחיצה על \"🧹 נקה אותה\" אם מופיע.")
    return d


class Publisher:
    def __init__(self, repo=None, selftest_cmd=None):
        self.repo = Path(repo or R.REPO)
        self.selftest_cmd = selftest_cmd
        self.lock = threading.Lock()
        self.ev = threading.Event()
        self.yes = None
        self.s = self._fresh()

    def _fresh(self):
        return {"running": False, "step": "", "label": "", "pct": 0, "log": [], "waiting": None, "cancel": False,
                "done": False, "error": "", "can_cancel": True, "version": "", "files": 0, "detail": "", "step_no": 0,
                "steps_total": len([1 for k, _, w in STEPS if w])}

    def _save(self):
        """4.3.1: המצב נשמר בדיסק בכל שינוי — רענון החלון (או הפעלה מחדש) לא מאבדים את ההתקדמות (כמו progress.json)."""
        try:
            R._guard(WORK)
            WORK.mkdir(parents=True, exist_ok=True)
            tmp = WORK / "publish_state.json.tmp"
            tmp.write_text(json.dumps(dict(self.s, saved_at=int(time.time())), ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, WORK / "publish_state.json")
        except Exception:
            pass

    def _sub(self, frac, detail=""):
        """התקדמות בתוך השלב הנוכחי (0..1) → אחוז כללי + טקסט ("העלאה 45%")."""
        acc, w = getattr(self, "_cur", (0, 0))
        with self.lock:
            self.s["pct"] = int(acc + w * max(0.0, min(1.0, frac)))
            self.s["detail"] = detail
        self._save()

    def state(self):
        with self.lock:
            return json.loads(json.dumps(self.s))

    def _log(self, t):
        with self.lock:
            self.s["log"].append(t)
            self.s["log"] = self.s["log"][-80:]
        self._save()

    def _step(self, key):
        acc, no = 0, 0
        for k, lab, w in STEPS:
            if w:
                no += 1
            if k == key:
                self._cur = (acc, w)
                with self.lock:
                    self.s.update(step=k, label=lab, pct=acc, detail="", step_no=no)
                self._save()
                return
            acc += w

    def _check_cancel(self):
        if self.s["cancel"]:
            raise Cancelled()

    def _wait(self, kind, text, extra=None):
        with self.lock:
            self.s["waiting"] = dict({"kind": kind, "text": text}, **(extra or {}))
        self.ev.clear()
        self.yes = None
        while not self.ev.wait(0.2):
            if self.s["cancel"]:
                break
        with self.lock:
            self.s["waiting"] = None
        self._check_cancel()
        if not self.yes:
            raise Cancelled()

    def answer(self, yes):
        self.yes = bool(yes)
        self.ev.set()

    def cancel(self):
        with self.lock:
            if not self.s["running"]:
                return False
            if not self.s["can_cancel"]:
                return False
            self.s["cancel"] = True
        self.ev.set()
        proc = getattr(self, "_proc", None)
        if proc and proc.poll() is None:
            proc.terminate()
        return True

    def start(self, passphrase, notes, must_not_skip=False, baseline=None):
        with self.lock:
            if self.s["running"]:
                raise R.UpdateError("פרסום כבר רץ.")
            self.s = self._fresh()
            self.s["running"] = True
        t = threading.Thread(target=self._run, args=(passphrase, notes, must_not_skip, baseline), daemon=True)
        t.start()
        return t

    # -- הגוף --
    def _remote_clone(self, remote):
        wd = WORK / hashlib.sha256(remote.encode()).hexdigest()[:12]
        R._guard(wd)
        WORK.mkdir(parents=True, exist_ok=True)
        if not (wd / ".git").exists():
            shutil.rmtree(wd, ignore_errors=True)
            subprocess.run(["git", "clone", "-q", remote, str(wd)], capture_output=True, text=True, timeout=180, env=GIT_ENV)
            if not (wd / ".git").exists():
                raise R.UpdateError("לא הצלחתי להתחבר לריפו הציבורי (%s). אולי עוד לא נוצר, או שאין הרשאה." % "git clone")
        _git(wd, "fetch", "-q", "origin", check=False)
        has_main = _git(wd, "rev-parse", "--verify", "-q", "origin/main", check=False)
        if has_main:
            _git(wd, "checkout", "-q", "-B", "main", "origin/main")
            _git(wd, "reset", "-q", "--hard", "origin/main")
        else:
            _git(wd, "checkout", "-q", "-B", "main")
        return wd

    def _run(self, passphrase, notes, must_not_skip, baseline):
        cleanup, key, committed, flipped = None, None, False, False
        try:
            self._step("preflight")
            self._log("בודק שהכול מוכן ...")
            repo = self.repo
            ver = R.installed_version(repo)
            R.ver_tuple(ver)
            self.s["version"] = ver
            if not have_key():
                raise R.UpdateError("עוד אין מפתח חתימה — קודם יוצרים אותו.")
            cfg = {"remote": effective_remote()}
            if not cfg.get("remote"):
                raise R.UpdateError("עוד לא הוגדר הריפו הציבורי.")
            base, keys = R.source()
            if not base:
                raise R.UpdateError("כתובת העדכונים עוד לא נכתבה בקוד (assets/release_source.json).")
            if public_key_b64() not in keys:
                raise R.UpdateError("המפתח הציבורי שלך לא נמצא בקוד שבעץ — צריך לשמור אותו בגרסה לפני הפרסום (אחרת אף אחד לא יוכל לאמת).")
            if not [x for x in notes if x.strip()]:
                raise R.UpdateError("חסר טקסט \"מה חדש\" בעברית פשוטה.")
            if R.git(repo, "status", "--porcelain", "--untracked-files=no"):
                raise R.UpdateError("בעץ יש שינויים שלא נשמרו (commit) — מפרסמים רק מצב שמור.")
            tag = R.git(repo, "describe", "--tags", "--exact-match", "HEAD", check=False)
            if tag != "v" + ver:
                raise R.UpdateError("ה-commit הנוכחי לא מסומן בתגית v%s." % ver)
            key = load_key(passphrase)
            passphrase = None
            self._check_cancel()
            wd = self._remote_clone(cfg["remote"])
            idx_old = (wd / "latest.json").read_bytes() if (wd / "latest.json").exists() else b""
            published = R.fetch_index_bytes(idx_old) if idx_old else []
            if published and R.ver_tuple(ver) <= R.ver_tuple(published[-1]["version"]):
                raise R.UpdateError("גרסה %s אינה חדשה יותר מהאחרונה שפורסמה (%s)." % (ver, published[-1]["version"]))
            previous = published[-1]["version"] if published else (baseline or "")
            if not previous:
                raise R.UpdateError("זה הפרסום הראשון — צריך לציין מאיזו גרסה מתחילה השרשרת.")
            self._log("גרסה %s, אחרי %s" % (ver, previous))
            # ── אישור מה יפורסם (לפני שמשהו נבנה או עולה) ──
            self._step("plan")
            self._wait("plan", "יפורסם בריפו הציבורי: ארכיון קוד נקי של גרסה %s + מניפסט חתום + רשימת עדכונים. "
                       "אף פרט אישי לא נכנס (נבדק אוטומטית). להמשיך?" % ver)
            self._step("build")
            self._log("בונה ארכיון נקי ...")
            out = WORK / ("build_" + ver)
            shutil.rmtree(out, ignore_errors=True)
            rdir = build_release(repo, ver, previous, notes, must_not_skip, previous, out, key, self._log, public_key_b64())
            self._step("selftest")
            self._log("מריץ את הבדיקה העצמית ...")
            self._selftest()
            self._check_cancel()
            self._step("sign")
            self._log("נחתם ✓")
            m = json.loads((rdir / "manifest.json").read_text(encoding="utf-8"))
            self.s["files"] = len(m["files"])
            self._check_cancel()
            # ── העלאה (שלב ראשון: בלי latest.json) ──
            self._step("push")
            dest = wd / "releases" / ver
            shutil.rmtree(dest, ignore_errors=True)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(rdir, dest)
            _git(wd, "add", "-A")
            _git(wd, *R.GIT_ID, "commit", "-q", "-m", "גרסה %s (עדיין לא מופעלת)" % ver)
            c1 = _git(wd, "rev-parse", "HEAD")
            cleanup = {"work": str(wd), "remote": cfg["remote"], "version": ver, "commit": c1, "at": int(time.time())}
            R._guard(WORK)
            _marker().write_text(json.dumps(cleanup), encoding="utf-8")
            self._check_cancel()
            self._log("מעלה ...")
            self._push(wd, "העלאה")
            committed = True
            # ── הורדה חזרה ואימות ──
            self._step("verify")
            self._log("מוריד חזרה ובודק ...")
            rb = base_for_ref(base, c1)
            raw = R.fetch(rb, "releases/%s/manifest.json" % ver, R.MAX_MANIFEST)
            sig = R.fetch(rb, "releases/%s/manifest.sig" % ver, 4096).decode("ascii")
            m2 = R.verify_manifest(raw, sig, keys)
            if raw != (rdir / "manifest.json").read_bytes():
                raise R.UpdateError("המניפסט שירד שונה ממה שהועלה.")
            self._sub(0.1, "מוריד חזרה את הארכיון")

            def dl(got, total):
                self._check_cancel()
                t = total or m2["archive"]["size"] or 1
                self._sub(0.1 + 0.8 * got / t, "הורדה חזרה %d%%" % int(100 * got / t))
            data = R.fetch(rb, "releases/%s/%s" % (ver, m2["archive"]["name"]), R.MAX_ARCHIVE, timeout=60, progress=dl)
            self._sub(0.9, "מאמת חתימה וכל קובץ")
            tmp = WORK / "verify_tmp"
            R.unpack_verified(data, m2, tmp)
            shutil.rmtree(tmp, ignore_errors=True)
            self._log("ההורדה חזרה זהה ותקינה ✓")
            # ── אישור אחרון, ואז נקודת האל-חזור ──
            self._step("final")
            self._wait("final", "הכול הועלה ואומת. עכשיו מפעילים את גרסה %s לכולם (latest.json). אחרי זה אי אפשר לבטל. להפעיל?" % ver)
            with self.lock:
                self.s["can_cancel"] = False
            self._step("flip")
            (wd / "latest.json").write_bytes(new_index(idx_old, m))
            _git(wd, "add", "latest.json")
            _git(wd, *R.GIT_ID, "commit", "-q", "-m", "הפעלת גרסה %s" % ver)
            self._push(wd, "הפעלה")
            flipped = True
            try:
                _marker().unlink()
            except OSError:
                pass
            self._step("done")
            e = R.fetch_index(base)
            if e[-1]["version"] != ver:
                self._log("⚠️ latest.json עוד לא מציג את %s (ייתכן עיכוב של כמה דקות בשרת)" % ver)
            with self.lock:
                self.s.update(pct=100, done=True)
            self._log("✅ גרסה %s פורסמה" % ver)
        except Cancelled:
            self._log("מבטל ...")
            if cleanup and committed and not flipped:
                try:
                    undo_upload(cleanup)
                    self._log("מה שהועלה בהרצה הזאת הוסר ✓")
                except R.UpdateError as e:
                    self._log("⚠️ לא הצלחתי להסיר אוטומטית: %s" % e)
            elif cleanup and not committed:
                try:
                    _marker().unlink()
                except OSError:
                    pass
            with self.lock:
                self.s["error"] = "בוטל. שום דבר לא פורסם."
        except R.UpdateError as e:
            with self.lock:
                self.s["error"] = str(e)
            if cleanup and committed and not flipped:
                try:
                    undo_upload(cleanup)
                    self._log("מה שהועלה בהרצה הזאת הוסר ✓")
                except R.UpdateError as e2:
                    self._log("⚠️ לא הצלחתי להסיר אוטומטית: %s" % e2)
        except Exception as e:
            with self.lock:
                self.s["error"] = "הפרסום נכשל: %s: %s" % (type(e).__name__, str(e)[:160])
        finally:
            key = None
            with self.lock:
                self.s.update(running=False, waiting=None)
            self._save()

    def _push(self, wd, what):
        """git push עם אחוזים אמיתיים (מה ש-git מדווח: "Writing objects: 45%") → פס ההתקדמות של השלב."""
        p = subprocess.Popen(["git", "-C", str(wd), "push", "--progress", "origin", "HEAD:main"], stdout=subprocess.DEVNULL,
                             stderr=subprocess.PIPE, env=GIT_ENV)
        buf, tail = b"", b""
        while True:
            ch = p.stderr.read(256)
            if not ch:
                break
            tail = (tail + ch)[-600:]
            buf = (buf + ch)[-200:]
            m = list(re.finditer(rb"(Compressing|Writing) objects:\s+(\d+)%", buf))
            if m:
                self._sub(int(m[-1].group(2)) / 100.0, "%s %s%%" % (what, m[-1].group(2).decode()))
        if p.wait() != 0:
            raise R.UpdateError("git push נכשל: %s" % tail.decode("utf-8", "replace").strip()[-200:])
        self._sub(1.0, what + " הושלמה")

    def _selftest(self):
        cmd = self.selftest_cmd
        if cmd is None:
            ov = os.environ.get("MAKE_SHORT_PUBLISH_SELFTEST")
            cmd = json.loads(ov) if ov else [sys.executable, str(self.repo / "pipeline" / "scripts" / "make_short_selftest.py"), "units"]
        if not cmd:
            self._log("(הבדיקה העצמית דולגה)")
            return
        self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                                      cwd=str(self.repo))
        tail = []
        for line in self._proc.stdout:
            tail = (tail + [line.rstrip()])[-6:]
        rc = self._proc.wait()
        self._check_cancel()
        if rc != 0:
            raise R.UpdateError("הבדיקה העצמית נכשלה — לא מפרסמים. " + " | ".join(tail[-3:])[:300])
        self._log("הבדיקה העצמית עברה ✓")


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["setup"] and len(a) in (3, 4):   # make_short_publish.py setup <git-remote-ssh-url> <https-base-url> [--allow-owner-account]
        acc = len(a) == 4 and a[3] == "--allow-owner-account"
        print("נכתב: " + setup(a[1], a[2], allow_account=acc, save=not acc) + " — צריך commit + תגית גרסה כדי שייכנס לחבילות")
    elif a[:1] == ["status"]:
        print(json.dumps(screen_status(), ensure_ascii=False))
    else:
        sys.exit("שימוש: make_short_publish.py setup <remote> <base> | status")
