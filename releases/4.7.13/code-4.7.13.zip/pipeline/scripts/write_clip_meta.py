# -*- coding: utf-8 -*-
"""כותב את המטא-דאטה של קליף לתוך shorts/<clip>/meta.json — ממנו הייצוא
בונה את «תיאור להעתקה.txt» (והוא נשאר בתיקיית העבודה בלבד).

התיאור נבנה כאן בסדר קבוע, ולא נסמך על הסדר שג'מיני כתב:
  1. גוף התיאור (--description, פרוזה בלבד)
  2. "לצפייה בשיעור המלא ◄ <קישור>" (--source-url), ומיד מתחתיה הזמנה
     להירשם לערוץ (--subscribe, עם קישור הרשמה אם ניתן --channel-url)
  3. שורת הסדרה והקישורים של הישיבה (--footer)
ואחריו, מחוץ לתיאור, התגיות. אין שורת "קישור למקור" נפרדת — הקישור כבר בתיאור.

שימוש:
  python write_clip_meta.py shorts/clip1 \
      --title "..." --hook "..." --description "..." --tags "a,b,c" \
      --source-url "https://..." --escaped-newlines --footer "מתוך סדרת השיעורים ב... | ...\n◄ ..."   (או שורות אמיתיות בלי הדגל)
"""
import argparse
import json
from pathlib import Path


# 16/11 (3.4): משפט ההרשמה הוא הגדרה ("📝 תיאור ותגיות" → subscribe_text). הנוסח של הבעלים
# ("ערוץ השיעורים החדש" — 14/10/2026) נמצא בקובץ ההגדרות שלו, לא בקוד: מי שמקבל את התוכנה
# מקבל נוסח כללי. התוכנה מעבירה --subscribe תמיד; כאן ברירת המחדל לשימוש ישיר (הסקיל).
GENERIC_SUBSCRIBE = "🔔 הירשמו לערוץ ולחצו על הפעמון כדי לקבל התראה על כל שיעור חדש"


def default_subscribe():
    try:
        import make_short_settings as SET
        return SET.load()["subscribe_text"]
    except Exception:
        return GENERIC_SUBSCRIBE


def build_description(body, source_url, link_label, footer, subscribe, channel_url):
    # אם גוף התיאור כבר מכיל את שורת הקישור או את ההזמנה להירשם (ג'מיני שם
    # אותן בעצמו) — מוציאים, אחרת הן מופיעות פעמיים ובמקום הלא נכון.
    # ג'מיני מנסח את ההזמנה אחרת בכל קליף ("להירשם", "הצטרפו למנויים"...).
    drop = [s for s in (source_url, "הירשמו", "הרשמו", "להירשם", "מנויים", "מנוי לערוץ") if s]
    body = "\n".join(l for l in body.splitlines() if not any(s in l for s in drop))
    parts = [body.strip()]
    if source_url:
        link = f"{link_label} ◄ {source_url}"
        if subscribe:
            # קישור ?sub_confirmation=1 פותח ישר את חלון ההרשמה לערוץ.
            sub = f"{subscribe} ◄ {channel_url}?sub_confirmation=1" if channel_url else subscribe
            link += "\n" + sub
        parts.append(link)
    elif subscribe:
        parts.append(subscribe)
    if footer.strip():
        parts.append(footer.strip())
    return "\n\n".join(p for p in parts if p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("clip_dir")
    ap.add_argument("--title", required=True)
    ap.add_argument("--hook", default="")
    ap.add_argument("--description", required=True, help="גוף התיאור בלבד, בלי קישורים")
    ap.add_argument("--tags", default="", help="מופרד בפסיקים")
    ap.add_argument("--source-url", default="", help="קישור לסרטון המלא — יוטיוב, או עמוד באתר ישיבה")
    ap.add_argument("--link-label", default="לצפייה בשיעור המלא",
                    help="למשל 'לצפייה בשיחה המלאה' כשהמקור אינו שיעור")
    ap.add_argument("--footer", default="", help="שורת הסדרה והקישורים של הישיבה")
    ap.add_argument("--escaped-newlines", action="store_true",
                    help="להמיר את הסימן \\n שבתוך --footer לירידת שורה (ברירת מחדל: לא; מעבירים שורות אמיתיות)")
    ap.add_argument("--subscribe", default=None, help="הזמנה להירשם; ריק = בלי; בלי הדגל = מההגדרות")
    ap.add_argument("--channel-url", default="",
                    help="כתובת הערוץ (yt-dlp: %%(channel_url)s) — הופכת את ההזמנה לקישור הרשמה")
    a = ap.parse_args()

    out = Path(a.clip_dir)
    out.mkdir(parents=True, exist_ok=True)
    tags = [t.strip() for t in a.tags.split(",") if t.strip()]
    description = build_description(a.description, a.source_url, a.link_label,
                                     # 4.1.0: מעבירים שורות אמיתיות. הסימן \n כטקסט (כתובת, נתיב ווינדוס) כבר לא מומר,
                                     # אלא רק אם ביקשו במפורש --escaped-newlines (שימוש ישן מהמעטפת)
                                     a.footer.replace("\\n", "\n") if a.escaped_newlines else a.footer,
                                     default_subscribe() if a.subscribe is None else a.subscribe,
                                     a.channel_url.rstrip("/"))

    meta = {"title": a.title, "hook": a.hook, "description": description,
            "tags": tags, "source_url": a.source_url}
    (out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # ההוק נשמר ב-meta.json לשימוש פנימי בלבד. הוא לא נכתב לקבצים שהמשתמש קורא:
    # הוא לא מעלה אותו לשום מקום, וההוק עצמו הוא כבר הפתיחה של הסרטון (29/9/2026).
    # אין יותר info.txt (בקשת המשתמש, 14/10/2026): הוא לא השתמש בו. מה שהוא
    # מעתיק הוא «תיאור להעתקה.txt», שנכתב בייצוא מתוך meta.json.
    print(f"נכתב: {out}/meta.json")


if __name__ == "__main__":
    main()
