# -*- coding: utf-8 -*-
"""
make_short_health.py — "בדיקת מערכת" של חלון יצירת השורטס (20/10/2026).

למה: כשאין סוכן שיאבחן, תקלה צריכה להופיע בפתיחה, בעברית, עם מה לעשות — לא באמצע
הורדה של עשר דקות. כל בדיקה זולה (שניות), ואף אחת לא מדפיסה סוד: את קובץ העוגיות
ואת הגדרות rclone קוראים רק כדי לבדוק תאריכים / קיום שדה, ולא מחזירים מהם כלום.

כל בדיקה מחזירה {id, level: ok|warn|bad, title, detail, steps[], action?}.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
COOKIES = CONFIG / "youtube_cookies.txt"
RCLONE = shutil.which("rclone") or os.path.expanduser("~/.local/bin/rclone")
MODAL = str(Path(sys.executable).parent / "modal")
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
MODAL_BUDGET = float(os.environ.get("MODAL_MONTHLY_BUDGET", "30"))   # הקרדיט החודשי שלו (22/9)

# 22/10: לא קשור לעדכוני התוכנה עצמה — רק לכלי ההורדה (הוא חשב ש"עדכן" מעדכן את כל התוכנה)
YTDLP_WHY = ("יוטיוב משתנה לעיתים קרובות; גרסה ישנה של כלי ההורדה מתחילה להיכשל — לחיצה על 'עדכן' לוקחת כמה שניות. "
             "(זה רק כלי ההורדה מיוטיוב, לא התוכנה עצמה.)")
# בדיקות שהחלון מוסיף (למשל Gemini — המונה המקומי של make_short_pick). {id: fn} → res(...)
EXTRA = {}

# 4.5.62 (בדיקת הדרכות): קישור ישיר לתוסף, אזהרה מתוספים מתחזים, איך מאשרים גלישה בסתר, איך פותחים חלון סתר, איפה התוסף,
# מה הפורמט, ומה לעשות אם הקובץ נדחה. שמות כפתורים: אנגלית ואחריה העברית בסוגריים (בכרום בעברית השמות יכולים להיות מעט שונים —
# הסדר והמיקום זהים; "התרה במצב גלישה בסתר" לא אומת מול כרום בעברית).
EXT_URL = "https://chromewebstore.google.com/detail/cclelndahbckbenkjhflpdbgdldlbecc"
COOKIE_STEPS = [
    "בכרום לפתוח את דף התוסף " + EXT_URL + " ← Add to Chrome (הוספה ל-Chrome) ← Add extension (התקנת התוסף). "
    "⚠ השם חייב להיות Get cookies.txt LOCALLY — עם המילה LOCALLY. תוסף בשם דומה בלי LOCALLY (או \"Clean\" וכדומה) הוא מתחזה — "
    "אחד כזה כבר נתפס שולח עוגיות לשרת זר. לא להתקין תוספים בשמות דומים",
    "לאשר לתוסף לפעול בגלישה בסתר: בשורת הכתובת להקליד chrome://extensions ← בכרטיס של התוסף ללחוץ Details (פרטים) ← "
    "להדליק Allow in Incognito (התרה במצב גלישה בסתר)",
    "לפתוח חלון גלישה בסתר: Ctrl+Shift+N. להיכנס ל-youtube.com ולהתחבר לחשבון של הערוץ (לא ל-studio)",
    "באותו חלון סתר לעבור לכתובת https://www.youtube.com/robots.txt",
    "ללחוץ למעלה מימין על סמל הפאזל 🧩 (תוספים) ← Get cookies.txt LOCALLY ← Export (ייצוא; הפורמט Netscape — ברירת המחדל). "
    "הקובץ יורד לתיקיית \"הורדות\"",
    "לסגור את חלון הסתר מיד — בלי ללחוץ \"יציאה\" ביוטיוב (זה מבטל את העוגיות)",
    "כאן בחלון: \"📤 העלה קובץ עוגיות\" ולבחור את הקובץ מ\"הורדות\"",
    "(מומלץ) לחזור ל-chrome://extensions ולכבות שוב את \"התרה במצב גלישה בסתר\" של התוסף",
    "אם התוכנה עונה \"לא נראה כמו קובץ עוגיות\": לחזור לשלב 4 ולוודא שהייצוא היה מתוך youtube.com, ובפורמט Netscape (לא JSON)",
    "🔒 את הקובץ הזה לא שולחים לאף אחד לעולם — מי שמחזיק אותו נכנס לחשבון היוטיוב שלכם",
]
COOKIE_REJECT_NOTE = ("הקובץ לא נראה כמו קובץ עוגיות של יוטיוב. בדרך כלל: הייצוא היה מדף אחר (צריך מתוך youtube.com, אחרי robots.txt) "
                      "או שנבחר פורמט JSON במקום Netscape. לייצא שוב לפי השלבים.")
BOT_NOTE = ("יוטיוב ביקש לאשר שאתם לא רובוט. אם זה שיעור ציבורי — לא צריך עוגיות: לחכות כמה שעות או לעבור לרשת אחרת "
            "(למשל נקודה חמה מהטלפון) ולנסות שוב. אם הוא מתוזמן או פרטי — לחדש עוגיות לפי השלבים.")


def _run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return 127, "לא מותקן"
    except subprocess.TimeoutExpired:
        return 124, "לא ענה תוך %d שניות" % timeout


def res(id_, level, title, detail="", steps=None, action=None):
    return {"id": id_, "level": level, "title": title, "detail": detail, "steps": steps or [], "action": action}


def check_ffmpeg():
    rc, out = _run([FFMPEG, "-hide_banner", "-version"], 15)
    if rc:
        return res("ffmpeg", "bad", "תוכנת הווידאו (ffmpeg) לא עובדת",
                   "בלי ffmpeg אי אפשר לחתוך ולבנות סרטונים.",
                   ["להריץ שוב את התקנה.bat (היא שומרת הכול — הגדרות, מוזיקה ומפתחות). אם ההודעה חוזרת: ללחוץ \"📋 העתק פרטים לעוזר\" ולשלוח למי שעוזר לכם"])
    missing = [k for k in ("libass", "libx264") if "--enable-" + k not in out]
    if missing:
        return res("ffmpeg", "bad", "ל-ffmpeg חסר רכיב: " + ", ".join(missing),
                   "בלי libass אין כתוביות, בלי libx264 אין קידוד וידאו.",
                   ["להריץ שוב את התקנה.bat (שומרת הכול). אם ההודעה חוזרת: \"📋 העתק פרטים לעוזר\" ולשלוח למי שעוזר לכם"])
    return res("ffmpeg", "ok", "ffmpeg תקין")


def ytdlp_version():
    fake = os.environ.get("MAKE_SHORT_FAKE_YTDLP")         # בדיקות בלבד: קובץ שבו כתובה "הגרסה"
    if fake and os.environ.get("MAKE_SHORT_NO_EXPORT") == "1":
        try:
            return Path(fake).read_text().strip()
        except OSError:
            return ""
    cmd = [sys.executable, "-m", "yt_dlp"]
    try:                       # בחירה בהגדרות → כלים; בלי בחירה זה תמיד yt-dlp של הסביבה הפרטית
        import tool_finder
        pref = tool_finder.load_prefs().get("ytdlp")
        cur = tool_finder.effective("ytdlp", tool_finder.find_ytdlp(), pref) if pref else None
        if cur and cur["source"] in ("custom", "system"):
            cmd = [cur["path"]]
    except Exception:
        pass
    rc, out = _run(cmd + ["--version"], 30)
    return out.strip().splitlines()[-1] if not rc and out.strip() else ""


def check_ytdlp():
    have = ytdlp_version()
    if not have:
        return res("ytdlp", "bad", "תוכנת ההורדה מיוטיוב (yt-dlp) לא עובדת", "",
                   ["ללחוץ \"עדכן עכשיו\""], {"id": "update_ytdlp", "label": "עדכן עכשיו"})
    latest = ""
    try:
        with urllib.request.urlopen("https://pypi.org/pypi/yt-dlp/json", timeout=8) as r:
            latest = json.loads(r.read().decode())["info"]["version"]
    except Exception:
        pass
    try:
        age = (time.time() - time.mktime(time.strptime(have[:10], "%Y.%m.%d"))) / 86400
    except ValueError:
        age = 0
    norm = lambda v: tuple(int(x) for x in re.findall(r"\d+", v))
    if latest and norm(latest) > norm(have) and age > 14:
        lvl = "bad" if age > 60 else "warn"
        return res("ytdlp", lvl, "תוכנת ההורדה מיוטיוב ישנה (%s, יש %s)" % (have, latest), YTDLP_WHY,
                   ["ללחוץ \"עדכן עכשיו\""], {"id": "update_ytdlp", "label": "עדכן עכשיו"})
    return res("ytdlp", "ok", "yt-dlp עדכני (%s)" % have)


def check_cookies():
    """רק תאריכי תפוגה — לא תוכן. העוגיות נחוצות רק לסרטונים מתוזמנים/פרטיים."""
    act = {"id": "upload_cookies", "label": "העלה קובץ עוגיות"}
    if not COOKIES.exists():
        return res("cookies", "warn", "אין קובץ עוגיות של יוטיוב",
                   "צריך אותו רק לשיעורים שעוד מתוזמנים או פרטיים. שיעורים ציבוריים עובדים בלעדיו.",
                   COOKIE_STEPS, act)
    now, key, n_yt = time.time(), [], 0
    try:
        for line in COOKIES.read_text(encoding="utf-8", errors="replace").splitlines():
            f = line.split("\t")
            if len(f) >= 7 and "youtube.com" in f[0]:
                n_yt += 1
                if f[5] in ("SID", "__Secure-1PSID", "__Secure-3PSID", "LOGIN_INFO"):
                    key.append(int(f[4]) if f[4].isdigit() else 0)
    except OSError:
        pass
    age_days = (now - COOKIES.stat().st_mtime) / 86400
    if not n_yt or not key:
        return res("cookies", "warn", "קובץ העוגיות לא נראה כמו עוגיות של חשבון יוטיוב מחובר",
                   "צריך אותו רק לשיעורים מתוזמנים או פרטיים.", COOKIE_STEPS, act)
    if max(key) and max(key) < now:
        return res("cookies", "warn", "העוגיות של יוטיוב פגו",
                   "שיעורים מתוזמנים או פרטיים לא יירדו עד שיחודשו (ציבוריים — כן).", COOKIE_STEPS, act)
    if age_days > 45:
        return res("cookies", "warn", "העוגיות של יוטיוב בנות %d ימים — ייתכן שהתיישנו" % age_days,
                   "אם הורדה של שיעור מתוזמן נכשלת — לחדש לפי השלבים.", COOKIE_STEPS, act)
    return res("cookies", "ok", "עוגיות יוטיוב בתוקף (בנות %d ימים)" % age_days)


def check_drive(enabled=True):
    if not enabled:
        return res("drive", "ok", "הגיבוי לדרייב כבוי בהגדרות")
    act = {"id": "drive_reconnect", "label": "חבר מחדש את הדרייב"}
    if not os.path.exists(RCLONE):
        return res("drive", "bad", "תוכנת הגיבוי (rclone) לא מותקנת", "",
                   ["להריץ שוב את התקנה.bat (שומרת הכול). אם ההודעה חוזרת: \"📋 העתק פרטים לעוזר\" ולשלוח למי שעוזר לכם"])
    rc, out = _run([RCLONE, "lsf", "gdrive:", "--max-depth", "1", "--dirs-only"], 40)
    if rc:
        return res("drive", "bad", "הגיבוי לגוגל דרייב לא מתחבר",
                   "השורטסים נשמרים במחשב, אבל לא מגובים לדרייב.",
                   ["ללחוץ \"חבר מחדש את הדרייב\" — ייפתח חלון שחור ואחריו דפדפן",
                    "בדפדפן: לבחור את חשבון הגוגל ולאשר",
                    "כשהחלון השחור כותב Success / Got code — ללחוץ Enter ולסגור, ואז \"בדיקת מערכת\""], act)
    # 16/11/2026: התיקון מתוך החלון — שלבים + שתי תיבות + "שמור וחבר" (make_short_app.drive_own_key).
    # 4.0.5: השלבים נשלחים תמיד (גם כשירוק), כדי שאפשר לפתוח את הטופס מ"🩺 בדיקת מערכת" בכל זמן
    # 4.5.62 (בדיקת הדרכות): שמות באנגלית + העברית בסוגריים (בקונסולה בעברית השמות יכולים להיות מעט שונים — הסדר והמיקום זהים;
    # התוויות העבריות של Google Cloud לא אומתו מול חשבון אמיתי); סדר המסכים ב-Get started; הסבר איך יוצרים דף בית בלי GitHub;
    # תוכנית ב' אם גוגל לא מאפשר פרסום
    steps = ["לפתוח https://console.cloud.google.com/projectcreate ולהתחבר עם חשבון הגוגל של הדרייב "
                 "(אותו חשבון שהגיבוי עולה אליו). שם הפרויקט: shorts-backup ← Create (יצירה). "
                 "הודעה על מכסת פרויקטים (למשל \"9 projects\") — לא מפריעה: היא רק סופרת פרויקטים בחשבון "
                 "(גם מחוקים נספרים כ-30 יום). האתר של גוגל קלאוד באנגלית; אם כרום מתרגם אותו לעברית — השמות יכולים להיות מעט שונים, הסדר והמיקום זהים",
                 "לפתוח https://console.cloud.google.com/apis/library/drive.googleapis.com — לוודא שלמעלה "
                 "נבחר הפרויקט shorts-backup — וללחוץ Enable (הפעלה)",
                 "לפתוח https://console.cloud.google.com/auth/overview ← Get started (תחילת העבודה). המסכים לפי הסדר: "
                 "App Information (שם האפליקציה shorts-backup + המייל שלכם) ← Audience: External (חיצוני) ← Contact Information (שוב המייל) ← "
                 "Finish (לסמן \"I agree to the Google API Services: User Data Policy\" — ההסכמה) ← Continue ← Create",
                 # 4.0.3: גוגל לא מאפשר Publish app (הכפתור אפור) בלי דף בית ומדיניות פרטיות — גם לאפליקציה אישית
                 "לפתוח https://console.cloud.google.com/auth/branding (Branding) ולמלא: App name = shorts-backup, "
                 "User support email ו-Developer contact email = המייל שלכם, ובחלק App domain: Application home page "
                 "ו-Application privacy policy link — אותה כתובת בשניהם. אין לכם דף? יוצרים אחד בדקה, בלי GitHub ובלי לדעת תכנות: "
                 "פותחים https://sites.google.com ← \"+\" (אתר ריק) ← כותרת למשל shorts-backup ← לוחצים על הטקסט וכותבים שורה אחת: "
                 "\"האפליקציה לשימוש אישי, שום מידע לא נשלח לאף אחד\" ← Publish (פרסום) למעלה מימין ← בוחרים כתובת (למשל shorts-backup-שמכם) ← "
                 "מעתיקים את הכתובת שמתקבלת (https://sites.google.com/view/…) ומדביקים בשני השדות ← Save (שמירה). "
                 "אם גוגל מבקש Authorized domains — להוסיף sites.google.com; אם מסרב לכתובת — להעתיק את ההודעה המדויקת שלו ל\"💬 עבודה עם צ'אט\" "
                 "או לעוזר שלכם. (מסך הפרסום של Google Sites וקבלת הכתובת כדף בית לא נבדקו מול חשבון אמיתי)",
                 "לפתוח https://console.cloud.google.com/auth/audience (Audience) ← Publish app (פרסום) ← Confirm. "
                 "למה: בלי פרסום, גוגל מנתק את החיבור כל 7 ימים. (אם הכפתור עדיין אפור — חסר משהו בשלב הקודם.) "
                 "תוכנית ב': אם אי אפשר לפרסם — באותו מסך, ב-Test users (משתמשי בדיקה) ← Add users ← המייל שלכם ← Save. "
                 "הגיבוי יעבוד, אבל פעם בשבוע צריך ללחוץ \"🔁 חבר מחדש את הדרייב\"",
                 "לפתוח https://console.cloud.google.com/auth/clients (Clients) ← Create client (יצירת לקוח) ← Application type: "
                 "Desktop app (אפליקציית שולחן עבודה) ← Create. יופיעו Client ID ו-Client secret — להעתיק כל אחד לתיבה שלו כאן למטה. "
                 "🔒 הם כמו סיסמה: לא לשלוח לאף אחד",
                 "ללחוץ \"🔑 שמור וחבר\" — ייפתח חלון שחור ואחריו דפדפן: לבחור את אותו חשבון. אם כתוב "
                 "\"Google hasn't verified this app\" — זה צפוי ותקין (גוגל לא בודק אפליקציה אישית, והיא שלכם): "
                 "Advanced (מתקדם) ← Go to shorts-backup (unsafe) ← Continue (המשך). "
                 "אם החלון השחור שואל שאלות באנגלית, לענות לפי הסדר: Already have a token – refresh? ← y · Use web browser…? ← y · "
                 "Configure this as a Shared Drive? ← n · Keep this remote? ← y (אם נתקעים — Enter משאיר ברירת מחדל). "
                 "הדפדפן לא נפתח? להעתיק את הקישור מהחלון (לסמן בעכבר ← קליק ימני) ולהדביק בכרום. "
                 "Ctrl+C עוצר את התהליך — לא ללחוץ עליו",
                 "כשהחלון השחור כותב Success — ללחוץ בו Enter. ההתראה הזאת תיעלם לבד",
                 "למי שרוצה את ההסבר המלא (באנגלית): https://rclone.org/drive/#making-your-own-client-id"]
    # rclone עם ה-client_id המשותף — שלהם נסגר במהלך 2026 (הודעה ביומן הגיבוי, 19/10)
    rc2, conf = _run([RCLONE, "config", "dump"], 15)
    own_id = False
    if not rc2:
        try:
            own_id = bool(json.loads(conf).get("gdrive", {}).get("client_id"))
        except ValueError:
            pass
    # 4.0.5: client_id לבד לא מספיק — ניסיון שנקטע השאיר client_id חדש עם הטוקן הישן (ירוק כוזב עד שהטוקן פג).
    # ירוק רק אם החיבור עם המפתח האישי הסתיים (own_key_ok), או שאין בכלל עותק "לפני" (מישהו הגדיר ביד — כמו תמיד)
    if own_id and not own_key_trusted(rclone_conf()):
        own_id = False
    if not own_id:
        r = res("drive", "warn", "הגיבוי לדרייב עובד — אבל דרך מפתח משותף שנסגר במהלך 2026",
                (DRIVE_NOTE[0] + " " if DRIVE_NOTE[0] else "") +
                "ביום שהמפתח המשותף ייסגר, הגיבוי יפסיק. התיקון: מפתח גוגל אישי — פעם אחת, כ-15 דקות, "
                "לפי השלבים כאן. אם משהו לא יעבוד — החיבור הקודם חוזר לבד והגיבוי ממשיך כרגיל.", steps)
        r["form"] = "drive_key"
        return r
    r = res("drive", "ok", "הגיבוי לדרייב מחובר")
    r["key_steps"] = steps
    return r


# ─────────────── 4.0.5: ניסיון "מפתח אישי" שנקטע ───────────────
# drive_own_key (באפליקציה) כותב עותק "לפני" (rclone.conf.before_own_key) וסימן own_key_pending, ואז מריץ חיבור מחדש.
# חיבור שהסתיים → own_key_ok. נקטע (Ctrl+C, סגירת החלון / השרת) → בפתיחה הבאה own_key_recover() מחזיר את העותק.
# אף ערך מהקובץ לא מודפס ולא נרשם ליומן — רק משווים.
DRIVE_NOTE = [""]          # הודעה להתראה של הדרייב (נקבעת ב-own_key_recover, עד הפעלה מחדש)
INTERRUPTED = "הניסיון הקודם נקטע — החיבור הקודם הוחזר, אפשר לנסות שוב."


def rclone_conf():
    rc, out = _run([RCLONE, "config", "file"], 15)
    p = Path(out.strip().splitlines()[-1].strip()) if not rc and out.strip() else None
    return p if p and p.is_file() else None


def own_key_paths(conf):
    conf = Path(conf)
    return {"before": conf.with_name(conf.name + ".before_own_key"), "pending": conf.with_name(conf.name + ".own_key_pending"),
            "ok": conf.with_name(conf.name + ".own_key_ok")}


def own_key_trusted(conf):
    """מפתח אישי נחשב רק אם החיבור איתו הסתיים. בלי עותק "לפני" (הוגדר ביד, לא דרך החלון) — כמו לפני 4.0.5."""
    if not conf:
        return True
    p = own_key_paths(conf)
    return p["ok"].exists() or not p["before"].exists()


def _gdrive(path):
    """client_id והטוקן של gdrive — רק להשוואה בזיכרון. קובץ מוצפן / לא קריא → None."""
    import configparser
    try:
        txt = Path(path).read_text(encoding="utf-8")
    except OSError:
        return None
    if txt.lstrip().startswith("# Encrypted rclone configuration"):
        return None
    cp = configparser.RawConfigParser(strict=False)
    try:
        cp.read_string(txt)
    except configparser.Error:
        return None
    if not cp.has_section("gdrive"):
        return None
    return {k: v.strip() for k, v in cp.items("gdrive")}      # 4.1.0: כל הסעיף (client_id, סוד, scope, טוקן) — להשוואה בלבד


def write_private(path, data):
    """4.1.0: כתיבה אטומית עם הרשאה 0600 *מההתחלה* (קובץ זמני שנוצר ב-O_EXCL ו-0600 ואז os.replace) — בלי רגע שבו
    הקובץ (עותק הגדרות עם סוד) קריא לאחרים, ובלי קובץ חצי-כתוב אם נקטע באמצע."""
    path = Path(path)
    if isinstance(data, str):
        data = data.encode("utf-8")
    tmp = path.with_name("%s.tmp%d" % (path.name, os.getpid()))
    tmp.unlink(missing_ok=True)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def conf_update(conf, section, updates):
    """4.1.0: עריכה בתוך התהליך של סעיף בהגדרות rclone — במקום `rclone config update … client_secret <סוד>` שהסוד נראה בו
    ב-ps לכל משתמש במחשב. נכתב אטומית, 0600; הסוד לא נכנס לשורת פקודה ולא ליומן. קובץ מוצפן — לא נוגעים."""
    conf = Path(conf)
    txt = conf.read_text(encoding="utf-8")
    if txt.lstrip().startswith("# Encrypted rclone configuration"):
        raise ValueError("הגדרות הגיבוי מוצפנות בסיסמה — אי אפשר לשנות אותן מכאן")
    lines = txt.splitlines(keepends=True)
    start = next((i for i, l in enumerate(lines) if re.fullmatch(r"\s*\[%s\]\s*" % re.escape(section), l.rstrip("\r\n"))), None)
    if start is None:
        raise ValueError("לא מצאתי את החיבור \"%s\" בהגדרות הגיבוי" % section)
    end = next((i for i in range(start + 1, len(lines)) if lines[i].lstrip().startswith("[")), len(lines))
    nl = "\r\n" if "\r\n" in txt else "\n"
    for k, v in updates.items():
        row = next((i for i in range(start + 1, end) if re.match(r"\s*%s\s*=" % re.escape(k), lines[i])), None)
        if row is not None:
            lines[row] = "%s = %s%s" % (k, v, nl)
        else:
            at = end
            while at > start + 1 and not lines[at - 1].strip():
                at -= 1
            if at > start + 1 and not lines[at - 1].endswith("\n"):
                lines[at - 1] += nl
            lines.insert(at, "%s = %s%s" % (k, v, nl))
            end += 1
    write_private(conf, "".join(lines))


def own_key_state(conf):
    """4.1.0: מצב הניסיון בלי לשנות כלום: none (אין עותק / כבר הסתיים) · same (שום דבר לא השתנה) · done (טוקן חדש —
    החיבור הסתיים) · interrupted (הוגדר מפתח אבל הטוקן ישן) · broken (הקובץ הנוכחי פגום, העותק תקין) · unknown."""
    p = own_key_paths(conf)
    if p["ok"].exists() or not p["before"].exists():
        return "none"
    now, before = _gdrive(conf), _gdrive(p["before"])
    if before is None:
        return "unknown"
    if now is None:
        return "broken"
    if now == before:
        return "same"
    if now.get("token") and now.get("token") != before.get("token"):
        return "done"
    return "interrupted"


def restore_before(conf):
    """מחזיר את העותק "לפני" על ההגדרות — אטומית (קובץ זמני + os.replace), ומנקה את כל הסימנים."""
    p = own_key_paths(conf)
    write_private(conf, p["before"].read_bytes())
    p["before"].unlink(missing_ok=True)
    p["pending"].unlink(missing_ok=True)
    p["ok"].unlink(missing_ok=True)


def own_key_recover(conf, busy=False):
    """נקרא בפתיחת השרת (וכשחיבור שרץ מסתיים). מחזיר: none / busy / done / restored / unknown.
    הכלל, כשיש עותק "לפני" ואין own_key_ok:
      - ה-client_id עכשיו = שבעותק → לא השתנה כלום (או כבר הוחזר): רק מנקים את הסימן.
      - client_id השתנה והטוקן *לא* → החיבור לא הסתיים (נקטע): מחזירים את העותק, מוחקים אותו (הוא זהה עכשיו).
      - client_id השתנה וגם הטוקן → החיבור הסתיים (רק השרת לא הספיק לרשום): own_key_ok.
    זה גם מתקן מצב שנוצר לפני 4.0.5 (עותק בלי שום סימן) — ולעולם לא מחזיר חיבור אישי שהסתיים (הטוקן שלו חדש)."""
    if not conf:
        return "none"
    p = own_key_paths(conf)
    if p["ok"].exists() or not p["before"].exists():
        p["pending"].unlink(missing_ok=True)
        return "none"
    if busy:                                   # חלון שחור עוד פתוח עם rclone — לא נוגעים באמצע
        return "busy"
    # 4.1.0: משווים את כל הסעיף (לא רק client_id): ניסיון חוזר עם אותו client_id אחרי שהשרת נסגר בין החיבור לסימון
    # ("ok") היה משאיר אזהרה שקרית לתמיד; וניסיון שנקטע אחרי ששונה רק הסוד נשאר בלי החזרה. קובץ נוכחי פגום (נקטע באמצע
    # כתיבה) והעותק תקין → מחזירים מהעותק במקום להיתקע ב-"לא ידוע".
    st = own_key_state(conf)
    if st == "unknown":
        return "unknown"
    if st == "same":                           # שום דבר לא השתנה — העותק מיותר
        p["before"].unlink(missing_ok=True)
        p["pending"].unlink(missing_ok=True)
        return "none"
    if st == "done":
        p["ok"].write_text(time.strftime("%Y-%m-%d %H:%M") + "\n")
        p["pending"].unlink(missing_ok=True)
        return "done"
    restore_before(conf)                       # interrupted / broken
    DRIVE_NOTE[0] = INTERRUPTED
    return "restored"


def modal_spend():
    rc, out = _run([MODAL, "billing", "report", "--for", "this month", "--json"], 60)
    if rc:
        return None, out
    try:
        rows = json.loads(out[out.index("["):])
        return sum(float(r.get("cost") or 0) for r in rows), ""
    except ValueError:
        return None, out


def modal_today():
    """כמה Modal רשם היום (דוח החיוב — בחינם, באיחור של כמה דקות). None = לא הצליח לקרוא."""
    rc, out = _run([MODAL, "billing", "report", "--for", "today", "--json"], 60)
    if rc:
        return None
    try:
        return sum(float(r.get("cost") or 0) for r in json.loads(out[out.index("["):]))
    except ValueError:
        return None


def check_modal():
    spent, err = modal_spend()
    if spent is None:
        rc, out = _run([MODAL, "app", "list", "--json"], 40)
        if rc:
            return res("modal", "bad", "אין חיבור ל-Modal (התמלול בענן)",
                       "בלי Modal התמלול רץ על המחשב — איטי מאוד (רבע שעה ויותר לקליף).",
                       ["לבדוק שיש אינטרנט ואז \"בדיקת מערכת\"",
                        "אם זה נמשך: להיכנס ל-modal.com ולבדוק שהחשבון פעיל ושיש קרדיט",
                        "אם עדיין לא — ללחוץ \"📋 העתק פרטים לעוזר\" ולשלוח למי שעוזר לכם"])
        return res("modal", "ok", "Modal מחובר (את הסכום החודשי לא הצלחתי לקרוא)")
    left = MODAL_BUDGET - spent
    r = res("modal", "ok", "Modal מחובר · החודש נוצלו $%.2f מתוך $%.0f (נשארו $%.2f)" % (spent, MODAL_BUDGET, left))
    r["spent"], r["budget"] = round(spent, 2), MODAL_BUDGET
    if left < 3:
        r.update(level="warn", detail="הקרדיט של החודש כמעט נגמר — אחרי זה התמלול יעבור למחשב (איטי) עד תחילת החודש הבא. "
                 "זה בסדר: זה בדיוק מה שתקרת ההוצאה נועדה לעשות, ואין צורך לעשות כלום. "
                 "(רוצים להגדיל? באתר modal.com ← Settings ← Usage & Billing ← Workspace budget.)")
    return r


def check_disk():
    free = shutil.disk_usage(os.path.expanduser("~")).free / 2**30
    if free < 10:
        return res("disk", "warn" if free > 3 else "bad", "נשאר מעט מקום בדיסק (%.0f GB)" % free,
                   "כל שיעור תופס כמה מאות MB עד שהוא נמחק.",
                   ["ללחוץ \"📂 שיעורים קודמים\" ← \"🧹 נקה\" כדי למחוק שיעורים ישנים שכבר הועלו (הם עוברים לסל המיחזור — אפשר לשחזר)"])
    return res("disk", "ok", "מקום בדיסק: %.0f GB פנויים" % free)


def run_one(id_, drive_enabled=True):
    """בדיקה אחת לפי שם — אחרי פעולת תיקון (עדכון yt-dlp, עוגיות, דרייב) בודקים מיד רק אותה (22/10).
    בלי זה ההתראה נשארה על המסך אחרי עדכון שהצליח, והוא חשב שנכשל ולחץ שוב."""
    fn = {"ffmpeg": check_ffmpeg, "ytdlp": check_ytdlp, "cookies": check_cookies, "modal": check_modal,
          "disk": check_disk, "drive": lambda: check_drive(drive_enabled), **EXTRA}.get(id_)
    if not fn:
        raise KeyError(id_)
    try:
        return fn()
    except Exception as e:
        return res(id_, "warn", "בדיקה נכשלה", str(e)[:200])


def run_all(drive_enabled=True, online=True):
    # 21/10: בלי אינטרנט — לא בודקים מה שצריך רשת (yt-dlp, דרייב, Modal): אחרת הבדיקה מציגה שלוש
    # "תקלות" שהן בעצם ניתוק אחד, וזה לא אמור לחסום עריכה וסיום של שיעור שכבר הוכן
    if not online:
        checks = [check_ffmpeg, check_disk]
    else:
        checks = [check_ffmpeg, check_ytdlp, check_cookies, lambda: check_drive(drive_enabled), check_modal, check_disk]
    checks += list(EXTRA.values())             # מקומיות בלבד (Gemini = המונה שבקובץ, בלי בקשה לגוגל)
    with ThreadPoolExecutor(len(checks)) as ex:
        futs = [ex.submit(f) for f in checks]
        out = []
        for f, fn in zip(futs, checks):
            try:
                r = f.result()
                if r is not None:       # 4.6: בדיקה שלא רלוונטית במחשב הזה (הכספת אצל מי שאינו הבעלים) — לא מוצגת
                    out.append(r)
            except Exception as e:      # בדיקה שנפלה לא מפילה את החלון
                out.append(res(getattr(fn, "__name__", "check"), "warn", "בדיקה נכשלה", str(e)[:200]))
    return {"at": time.strftime("%H:%M"), "results": out, "online": online}


SECRET_RES = [re.compile(p) for p in (
    r"AIza[0-9A-Za-z_\-]{20,}", r"\b(?:ak|as|wk|ws)-[0-9A-Za-z]{10,}", r"ya29\.[0-9A-Za-z_\-]+",
    r"1//[0-9A-Za-z_\-]{20,}", r"(?i)(token|secret|password|api[_-]?key)\s*[=:]\s*\S+",
    r"[A-Za-z0-9+/_\-]{40,}")]


def scrub(text):
    """דוח תקלה בלי סודות: מפתחות, טוקנים ומחרוזות ארוכות שנראות כמו מפתח — מוחלפים."""
    # הערך האמיתי קודם, בכל פורמט: מפתח מהפורמט החדש של גוגל (21/10) לא נראה כמו "AIza..."
    for name in ("GEMINI_API_KEY", "MODAL_TOKEN_ID", "MODAL_TOKEN_SECRET"):
        real = (os.environ.get(name) or "").strip().strip("'\"")
        if len(real) >= 8:
            text = text.replace(real, "[הוסתר]")
    for rx in SECRET_RES:
        text = rx.sub("[הוסתר]", text)
    return text


if __name__ == "__main__":
    print(json.dumps(run_all(), ensure_ascii=False, indent=1))
