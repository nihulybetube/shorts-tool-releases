# -*- coding: utf-8 -*-
"""שני סגנונות כתוביות שאושרו ב-30/10/2026 (לצד הטורקיז, שנשאר ברירת המחדל) — האב-טיפוס: חומרים\\סגנונות כתוביות\\אב-טיפוס\\gen_v3.py.

  marker — "מרקר": טקסט לבן ב-Open Sans Hebrew Bold; מאחורי המילה שנאמרת תיבה מעוגלת (רדיוס 38 ב-1080) שרצה מתחילת
           המילה (ימין) ומתקפלת אל סופה (שמאל) בכ-0.09 שנ'. התיבה ממורכזת אנכית לפי *גוף האותיות* (ח מ ש), לא לפי
           ל הגבוהה — עם פיצוי שנמדד על פריימים אמיתיים (mid = base_y − גוף/2 + 0.075·גודל). צבע התיבה נבחר לכל קליף
           (MARKER_COLORS); בצהוב ובמנטה הטקסט שעל התיבה כהה — שכבה נוספת של אותה כתובית בצבע כהה, חתוכה ב-\\clip
           על מלבן המילה. שקיפות התיבה: opacity 0–100 (100 = מלא).
  float  — "ריחוף מילים": Heebo ExtraBold ~136. כל מילה נכנסת בדהייה עולה ממקום סופי קבוע; כל השורה נעלמת יחד.
           מתאים לדיבור איטי בלבד (FLOAT_MAX_WPS). הדגשה בצבע — אופציונלית, ובמקום הגדלה אף פעם לא יחד איתה.

🚨 בעברית ב-libass כל כתובית היא אירוע אחד בקטע עיצוב אחד (תגית צבע/גודל באמצע שורה מהפכת סדר מילים). לכן התיבות
הן ציורי \\p1 (\\an7, פינה שמאלית-עליונה — עם \\an5 וקואורדינטות שליליות המיקום זז), הטקסט הכהה הוא שכבה חתוכה, וכל מילה
בריחוף מצוירת לבד במיקום שנגזר ממדידת השורה המלאה (karaoke_ass.measure_words).
🚨 צבעי התיבה הם רשימה משלהם — לא HIGHLIGHT_RGB של הקריוקי (הוראה מפורשת שלו, 30/10).
"""
import tempfile

import build_ass as B
from subtitle_terms import fix_words

# צבעי תיבת המרקר (צבעי הדגשה נפוצים; בלי ורוד — 30/10). הראשון = ברירת המחדל.
MARKER_COLORS = {"10206E": "כחול כהה", "1A1A1A": "שחור פחם", "74202C": "בורדו", "0F5132": "ירוק יער",
                 "4B2A7A": "סגול עמוק", "0B5D5A": "טורקיז כהה", "FFD300": "צהוב", "7CF5C4": "מנטה"}
MARKER_DARK_TEXT = {"FFD300", "7CF5C4"}        # על תיבה בהירה הטקסט כהה (111111)
MARKER_DEFAULT = "10206E"
MARKER_OPACITY_DEFAULT = 94                    # כמו האב-טיפוס שאושר (alpha &H10 ≈ 94%)
FLOAT_EMPH_COLORS = {"1AC8A8": "טורקיז", "FFE600": "צהוב"}
FLOAT_MAX_WPS = 2.0                            # ריחוף מתאים עד ~שתי מילים בשנייה
# 31/10 (כרטיס 24): צל הריחוף נשלט מההגדרות — (פעיל, שקיפות 0–100, גודל). ברירת המחדל = בדיוק המראה שהיה (צל קשיח עומק 3 ב-50%):
# רק ערך שונה מהברירת מחדל מצייר צל רך (שכבה שחורה מטושטשת מתחת לטקסט) — כך שום קליף קיים לא משתנה.
FLOAT_SHADOW_DEFAULT = (True, 50, 3)
# "קופסה": תיבה כהה מעוגלת קבועה סביב כל כתובית (1–2 שורות); המילה שנאמרת בצבע טקסט. הצבע שבבחירה (BOX:RRGGBB) = צבע המילה.
BOX_COLOR_DEFAULT = "000000"
BOX_OPACITY_DEFAULT = 60
BOX_HILITE_DEFAULT = "1AC8A8"                  # טורקיז, כמו הסגנון הראשי
BOX_COLORS = {"1AC8A8": "טורקיז", "FFE600": "צהוב", "B14EFF": "סגול", "39FF14": "ירוק ניאון"}
BOX_RADIUS, BOX_PADX = 34, 38

# שם משפחה ייחודי (assets/fonts), גודל, יחס גובה האות ל, יחס גוף האותיות — נמדדו בגופן עצמו (fontTools), לא בזמן ריצה.
# גודל המרקר: ל = 78px ב-1080. הערכים נבדקים ב-make_short_selftest.
MARKER_FONT = {"name": "YSMarkerBold", "size": 103, "ink": 0.7598, "body": 0.6364}
FLOAT_FONT = {"name": "YSFloatHeebo", "size": 136}
MV = 400                                       # שולי תחתית הסגנונות האלה (גבוה מהטורקיז, כמו באב-טיפוס)
RADIUS, PADX, TR = 38, 25, 0.09

RLE, PDF = "‫", "‬"


def dark_text(rgb, override=None):
    """האם הטקסט שעל תיבה בצבע rgb כהה (111111)? override = "dark"/"light" שבחר ביד; אחרת לפי ניגודיות WCAG —
    הטקסט (לבן או 111111) שמקבל יחס ניגודיות גבוה יותר מהצבע. נותן: צהוב ומנטה → כהה, כחול/בורדו/טורקיז כהה → לבן."""
    if override in ("dark", "light"):
        return override == "dark"
    ch = [int(rgb[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in ch]
    lum = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
    return (lum + 0.05) / (0.0056 + 0.05) > 1.05 / (lum + 0.05)      # 0.0056 = הבהירות של 111111


def bgr(rgb):
    """"0A1A78" -> "&H781A0A&" (תגית צבע)"""
    return "&H%s%s%s&" % (rgb[4:6], rgb[2:4], rgb[0:2])


def _style(name, font, size, color, shadow, back):
    return ("Style: %s,%s,%d,%s,&H000000FF,&H00101010,%s,0,0,0,0,100,100,0,0,1,0,%s,2,60,60,%d,1"
            % (name, font, size, color, back, shadow, MV))


def rr(w, h, r):
    """מלבן מעוגל (ציור ASS) בפינה (0,0)"""
    r = min(r, h / 2.0, w / 2.0)
    k = 0.5523 * r                              # קירוב מעגל בבזייה
    f = lambda v: "%.1f" % v
    return ("m %s %s l %s %s b %s %s %s %s %s %s l %s %s b %s %s %s %s %s %s l %s %s b %s %s %s %s %s %s l %s %s b %s %s %s %s %s %s"
            % (f(r), f(0), f(w - r), f(0),
               f(w - r + k), f(0), f(w), f(r - k), f(w), f(r),
               f(w), f(h - r),
               f(w), f(h - r + k), f(w - r + k), f(h), f(w - r), f(h),
               f(r), f(h),
               f(r - k), f(h), f(0), f(h - r + k), f(0), f(h - r),
               f(0), f(r),
               f(0), f(r - k), f(r - k), f(0), f(r), f(0)))


def speech_rate(words):
    """מילים בשנייה בקטע המדובר (מהמילה הראשונה עד סוף האחרונה). 0 כשאין מה למדוד."""
    ws = [w for w in words if str(w.get("word", "")).strip()]
    if len(ws) < 2:
        return 0.0
    span = ws[-1]["end"] - ws[0]["start"]
    return round(len(ws) / span, 2) if span > 0.5 else 0.0


def _prepare(K, words, duration, rows_layout, with_index, font, size, tmp):
    """מחלק לכתוביות ומודד כל אחת ב-libass (שורות, מילים, תיבות, זמן כל מילה). מחזיר (כתוביות, drop, pitch, items)."""
    K.MEASURE_STYLE = ("Style: Base,%s,%d,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,2,60,60,%d,1"
                       % (font, size, MV))
    K.BOTTOM_Y = B.PLAY_RES_Y - MV
    items, rows_by_first = K.make_items(words, duration, rows_layout, with_index=with_index)
    drop_per_px, pitch = K.calibrate(tmp)
    drop = drop_per_px * 122.0                  # פיקסלים: מקו הבסיס עד תחתית תיבת \an2
    out = []
    for ci, (start, end, chunk) in enumerate(items):
        tokens = fix_words([w["word"].strip() for w in chunk], color=False).split()
        rows = (K.layout_rows(tokens, chunk, words, rows_by_first) if rows_layout else None) or B.split_rows(tokens)
        text = B.ass_text(tokens, rows)
        boxes = K.measure_words(text, [len(r) for r in rows], tmp)
        ws = [w for w in chunk if w["word"].strip()]
        n = len(tokens)
        t = [min(max(ws[min(k, len(ws) - 1)]["start"], start), end) for k in range(n)] if ws else [start] * n
        if t:
            t[0] = start
        row_of = []
        for ri, r in enumerate(rows):
            row_of += [ri] * len(r)
        out.append(dict(start=start, end=end, tokens=tokens, rows=rows, text=text, boxes=boxes, t=t, row_of=row_of,
                        ok=boxes is not None and len(ws) == n))
    return out, drop, pitch, items


def _row_bottom(K, ri, nrows, pitch):
    return K.BOTTOM_Y - (nrows - 1 - ri) * pitch


def _marker(K, cs, drop, pitch, rgb, opacity, dark):
    f = MARKER_FONT
    size = f["size"]
    lines = [K.header([_style("Base", f["name"], size, "&H00FFFFFF", 1, "&H50000000"),
                       _style("Dark", f["name"], size, "&H00111111", 0, "&H00000000")])]
    alpha = "&H%02X&" % max(0, min(255, round(255 * (100 - opacity) / 100.0)))
    ink = f["ink"] * size                       # גובה האות ל בפועל
    body = f["body"] * size
    for c in cs:
        s, e = c["start"], c["end"]
        lines.append("Dialogue: 1,%s,%s,Base,,0,0,0,,{\\bord0\\3c&HFFFFFF&\\fad(100,80)}%s\n"
                     % (B.fmt_time(s), B.fmt_time(e), c["text"]))
        if not c["ok"]:
            continue                            # לא נמדד — טקסט בלי תיבה, לא מנחשים מיקום
        n = len(c["tokens"])
        geo = []
        for k in range(n):
            x0, x1, _y0, _y1 = c["boxes"][k]
            base_y = _row_bottom(K, c["row_of"][k], len(c["rows"]), pitch) - drop
            # 🚨 התיבה סימטרית סביב אמצע גוף האותיות (לא סביב ל): אותו קו אמצע למילים ולמלבן. +0.075·גודל = הפיצוי
            # שנמדד בפריימים אמיתיים (בלעדיו התיבה גבוהה ב-~8px מהדיו)
            mid = base_y - body / 2.0 + 0.075 * size
            half = max(ink - body / 2.0 + 20, body / 2.0 + 30)    # מכסה את ל למעלה ואת ק למטה בשוליים
            geo.append((x0 - PADX, x1 + PADX, mid - half, mid + half))      # שמאל, ימין, למעלה, למטה
        for k in range(n):
            a = c["t"][k]
            b = c["t"][k + 1] if k + 1 < n else e
            if b - a < 0.03:
                continue
            L, R, T, Bm = geo[k]
            ms_in = int(TR * 1000)
            end = b + (TR if k + 1 < n else 0.0)
            # נכנסת: רצה מתחילת המילה (הצד הימני) אל סופה (השמאלי); יוצאת: מתקפלת אל הצד השמאלי כשהבאה נכנסת
            out_ms = int((end - a) * 1000)
            ev = ("\\an7\\pos(%.1f,%.1f)\\bord0\\shad0\\1c%s\\1a%s" % (L, T, bgr(rgb), alpha)
                  + "\\clip(%.1f,%.1f,%.1f,%.1f)\\t(0,%d,\\clip(%.1f,%.1f,%.1f,%.1f))" % (R, T, R, Bm, ms_in, L, T, R, Bm)
                  + "\\t(%d,%d,\\clip(%.1f,%.1f,%.1f,%.1f))" % (out_ms - ms_in, out_ms, L, T, L, Bm))
            lines.append("Dialogue: 0,%s,%s,Base,,0,0,0,,{%s\\p1}%s{\\p0}\n"
                         % (B.fmt_time(a), B.fmt_time(end), ev, rr(R - L, Bm - T, RADIUS)))
            if dark:
                x0, x1, y0, y1 = c["boxes"][k]
                clip = "\\clip(%d,%d,%d,%d)" % (max(0, x0 - K.CLIP_PAD), max(0, y0 - 30),
                                                min(B.PLAY_RES_X, x1 + K.CLIP_PAD), min(B.PLAY_RES_Y, y1 + 30))
                fade = "\\fad(0,80)" if k + 1 == n else ""
                lines.append("Dialogue: 2,%s,%s,Dark,,0,0,0,,{%s%s\\bord0}%s\n"
                             % (B.fmt_time(a), B.fmt_time(b), clip, fade, c["text"]))
    return "".join(lines)


def shadow_plan(shadow):
    """(עומק צל הסגנון, צל רך או None) לפי (פעיל, שקיפות, גודל) — None או ברירת המחדל = המראה המקורי בדיוק.
    כבוי = בלי צל. כל ערך אחר = צל רך: שכבה שחורה מטושטשת, מוסטת מעט למטה, מתחת לטקסט (בלי צל קשיח של הסגנון)."""
    if shadow is None:
        return 3, None
    on, op, size = shadow
    if not on:
        return 0, None
    if (True, int(op), int(size)) == FLOAT_SHADOW_DEFAULT:
        return 3, None
    return 0, (max(0, min(100, int(op))), max(1, min(12, int(size))))


def _box(K, cs, drop, pitch, hi, box_rgb, opacity):
    """"קופסה": תיבה קבועה סביב כל הכתובית (1–2 שורות), בלי תנועה. הטקסט המלא לבן (שכבה 1), והמילה שנאמרת — אותו טקסט
    בצבע ההדגשה, חתוך ב-\\clip על מלבן המילה (שכבה 2; בעברית אי אפשר תגית צבע באמצע שורה). גובה כמו מרקר/ריחוף (MV)."""
    f = MARKER_FONT
    size = f["size"]
    light_box = dark_text(box_rgb)               # תיבה בהירה — הטקסט הבסיסי כהה, כמו במרקר
    lines = [K.header([_style("Base", f["name"], size, "&H00111111" if light_box else "&H00FFFFFF", 0, "&H00000000"),
                       _style("Hi", f["name"], size, bgr(hi).replace("&H", "&H00").rstrip("&"), 0, "&H00000000")])]
    alpha = "&H%02X&" % max(0, min(255, round(255 * (100 - opacity) / 100.0)))
    ink, body = f["ink"] * size, f["body"] * size
    for c in cs:
        s, e = c["start"], c["end"]
        lines.append("Dialogue: 1,%s,%s,Base,,0,0,0,,{\\bord0\\fad(100,80)}%s\n" % (B.fmt_time(s), B.fmt_time(e), c["text"]))
        if not c["ok"]:
            continue                            # לא נמדד — טקסט בלי תיבה ובלי הדגשה, לא מנחשים מיקום
        n, nr = len(c["tokens"]), len(c["rows"])
        mid = lambda ri: _row_bottom(K, ri, nr, pitch) - drop - body / 2.0 + 0.075 * size      # אמצע גוף האותיות (כמו במרקר)
        half = max(ink - body / 2.0 + 20, body / 2.0 + 30)
        L = min(b[0] for b in c["boxes"]) - BOX_PADX
        R = max(b[1] for b in c["boxes"]) + BOX_PADX
        T, Bm = mid(0) - half, mid(nr - 1) + half
        lines.append("Dialogue: 0,%s,%s,Base,,0,0,0,,{\\an7\\pos(%.1f,%.1f)\\bord0\\shad0\\1c%s\\1a%s\\fad(100,80)\\p1}%s{\\p0}\n"
                     % (B.fmt_time(s), B.fmt_time(e), L, T, bgr(box_rgb), alpha, rr(R - L, Bm - T, BOX_RADIUS)))
        for k in range(n):
            a = c["t"][k]
            b = c["t"][k + 1] if k + 1 < n else e
            if b - a < 0.03:
                continue
            x0, x1, y0, y1 = c["boxes"][k]
            clip = "\\clip(%d,%d,%d,%d)" % (max(0, x0 - K.CLIP_PAD), max(0, y0 - 30), min(B.PLAY_RES_X, x1 + K.CLIP_PAD), min(B.PLAY_RES_Y, y1 + 30))
            fade = "\\fad(%d,%d)" % (100 if k == 0 else 0, 80 if k + 1 == n else 0)
            lines.append("Dialogue: 2,%s,%s,Hi,,0,0,0,,{%s%s\\bord0}%s\n" % (B.fmt_time(a), B.fmt_time(b), clip, fade, c["text"]))
    return "".join(lines)


def _float(K, cs, pitch, rgb, plan, shadow=None):
    f = FLOAT_FONT
    depth, soft = shadow_plan(shadow)
    lines = [K.header([_style("Base", f["name"], f["size"], "&H00FFFFFF", depth, "&H80000000")])]
    for ci, c in enumerate(cs):
        s, e = c["start"], c["end"]
        if not c["ok"]:
            lines.append("Dialogue: 1,%s,%s,Base,,0,0,0,,{\\fad(110,90)}%s\n" % (B.fmt_time(s), B.fmt_time(e), c["text"]))
            continue
        n = len(c["tokens"])
        marked = set(plan.get(ci, ())) if rgb else set()
        for k in range(n):
            x0, x1, _a, _b = c["boxes"][k]
            cx = (x0 + x1) / 2
            y = _row_bottom(K, c["row_of"][k], len(c["rows"]), pitch)
            col = "\\1c%s" % bgr(rgb) if k in marked else ""      # מילה בודדת באירוע משלה — תגית צבע בטוחה כאן
            if soft:                                              # צל רך: אותו אירוע בשחור מטושטש, מתחת (שכבה 0), באותה תנועה ודהייה
                op, sz = soft
                dx, dy = sz * 0.35, sz * 0.7
                lines.append("Dialogue: 0,%s,%s,Base,,0,0,0,,{\\an2\\1c&H000000&\\1a&H%02X&\\bord0\\shad0\\blur%.1f\\move(%.1f,%.1f,%.1f,%.1f,0,320)\\fad(260,110)}%s%s%s\n"
                             % (B.fmt_time(c["t"][k]), B.fmt_time(e), max(0, min(255, round(255 * (100 - op) / 100.0))), sz * 0.8,
                                cx + dx, y + 26 + dy, cx + dx, y + dy, RLE, c["tokens"][k], PDF))
            lines.append("Dialogue: 1,%s,%s,Base,,0,0,0,,{\\an2%s\\move(%.1f,%.1f,%.1f,%.1f,0,320)\\fad(260,110)\\blur1}%s%s%s\n"
                         % (B.fmt_time(c["t"][k]), B.fmt_time(e), col, cx, y + 26, cx, y, RLE, c["tokens"][k], PDF))
    return "".join(lines)


def build(K, words, duration, mode, rgb=None, opacity=None, rows_layout=None, emph_idx=None, text=None, shadow=None,
         box_rgb=None):
    """הטקסט של קובץ ה-ass לסגנון mode ("marker"/"float"/"box"). words = המילים עם SUB_DELAY כבר מוסף.
    rgb: מרקר = צבע התיבה (ברירת מחדל כחול כהה); ריחוף = צבע ההדגשה, או None (בלי הדגשה); קופסה = צבע המילה הנאמרת.
    opacity: מרקר/קופסה = שקיפות התיבה. shadow = (פעיל, שקיפות, גודל) של צל הריחוף (None = כמו תמיד). box_rgb = צבע התיבה בקופסה.
    text = "dark"/"light" = עקיפה ידנית של צבע הטקסט שעל התיבה (ברירת מחדל: לפי ניגודיות, dark_text).
    emph_idx = המילים המסומנות (🔠) — מקבלות צבע בריחוף עם הדגשה; בשום סגנון הן לא מוגדלות.
    מחזיר (טקסט, מספר כתוביות, כמה לא נמדדו, כמה צבועות)."""
    saved = (K.MEASURE_STYLE, K.BOTTOM_Y)       # הקריוקי משתמש בערכים האלה; מחזירים אותם בסוף
    try:
        font = FLOAT_FONT if mode == "float" else MARKER_FONT
        with tempfile.TemporaryDirectory() as tmp:
            cs, drop, pitch, items = _prepare(K, words, duration, rows_layout, emph_idx is not None,
                                              font["name"], font["size"], tmp)
        if mode == "marker":
            rgb = (rgb or MARKER_DEFAULT).upper()
            op = MARKER_OPACITY_DEFAULT if opacity is None else max(0, min(100, int(opacity)))
            dk = dark_text(rgb, text)
            out = _marker(K, cs, drop, pitch, rgb, op, dk)
            tag = "; ys-style: marker\n; ys-rgb: %s\n; ys-opacity: %d\n; ys-text: %s" % (rgb, op, "dark" if dk else "light")
            colored = 0
        elif mode == "box":
            rgb = (rgb or BOX_HILITE_DEFAULT).upper()
            brgb = (box_rgb or BOX_COLOR_DEFAULT).upper()
            op = BOX_OPACITY_DEFAULT if opacity is None else max(0, min(100, int(opacity)))
            out = _box(K, cs, drop, pitch, rgb, brgb, op)
            tag = "; ys-style: box\n; ys-rgb: %s\n; ys-opacity: %d\n; ys-boxcolor: %s" % (rgb, op, brgb)
            colored = 0
        else:
            rgb = rgb.upper() if rgb else None
            plan = K.plan_from_idx(items, set(emph_idx))[0] if (rgb and emph_idx is not None) else {}
            out = _float(K, cs, pitch, rgb, plan, shadow)
            tag = "; ys-style: float\n; ys-rgb: %s" % (rgb or "-")
            colored = sum(len(v) for v in plan.values())
        out = out.replace("[Script Info]\n", "[Script Info]\n%s\n" % tag, 1)
        return out, len(cs), sum(1 for c in cs if not c["ok"]), colored
    finally:
        K.MEASURE_STYLE, K.BOTTOM_Y = saved
