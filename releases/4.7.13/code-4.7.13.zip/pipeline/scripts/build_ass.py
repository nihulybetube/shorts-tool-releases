# -*- coding: utf-8 -*-
"""
בונה קובץ כתוביות ASS מעוצב מתוך תמלול word-level:
- מקבץ מילים לנתחים קצרים (2-4 מילים / עד ~1.4 שניות) בסגנון שורטס
- RTL עברית (libass+fribidi מטפלים בכיווניות אוטומטית)
- פונט Heebo Black (900) - משקל אמיתי, ולכן Bold=0 (בולד סינתטי היה מרח את הקווים)
- עטיפת RLE...PDF לכל שורה - חיוני לפיסוק (פסיקים/נקודות) שיושב בצד הנכון
- ממוקם למעלה-משליש התחתון, מותאם ל-1080x1920 (9:16)
- ראשי תיבות לועזיים (RPG וכו') נכתבים באנגלית ומודגשים בזהב — ראה
  `subtitle_terms.py`. נולד מ-"הרפג'י" שנצרב לקליף של אחד הדוברים (26/8/2026).
"""
import json
import sys

from subtitle_terms import fix_words

PLAY_RES_X = 1080
PLAY_RES_Y = 1920

# 🚨 שונה 22/9/2026: עד עכשיו היה כאן 3 מילים "לבקשת המשתמש" — זו הייתה בקשה
# של הלקוח המקורי של הסקיל, לא של המשתמש הנוכחי. הוא ביקש במפורש יותר מילים
# ("4, 5, 6"), ושתי שורות כשצריך. הגבול הטבעי הוא עכשיו הפיסוק והעצירות
# (ראה GAP_THRESHOLD), והמספרים כאן רק תקרה.
MAX_WORDS_PER_CHUNK = 7
MAX_CHUNK_CHARS = 34      # שתי שורות של ~17 אותיות
LINE_CHARS = 18           # נמדד: ~42px לאות ב-Heebo 900/122 → 18 אותיות ≈ 760px מתוך 960
MAX_CHUNK_DURATION = 3.2
# 🚨 גבולות "קשים" — בקשת המשתמש, 22/9/2026: פסיק או נקודה בסוף משפט-חלקי
# חייבים לסיים שורת כתובית, וכך גם עצירה משמעותית בשטף הדיבור. כתובית
# שמתחילה משפט אחרי פסיק, או שחוצה עצירה של הרב, נקראת בניגוד למה ששומעים.
# הגבול הקשה גם **חוסם מיזוג** ב-polish_chunks — מילה בודדת בין שתי עצירות
# נשארת לבד, כי זה בדיוק מה שהרב עשה.
GAP_THRESHOLD = 0.30  # עצירה בדיבור (היה 0.5 — פספס עצירות קצרות אך ברורות)
# דובר איטי שעוצר לחשוב באמצע משפט (הרב ש.יוסף וייצן, 28/9/2026) קיבל ב-0.30 שורות של
# מילה אחת ("בשביל" / "זה יש את" / "הלולב."). אצלו SHORTS_SUB_GAP=1.5: הפסיקים והנקודות
# בטקסט הנקי כבר שוברים בסופי משפטים, והעצירה שוברת רק כשהיא באמת ארוכה.
import os as _os
GAP_THRESHOLD = float(_os.environ.get("SHORTS_SUB_GAP", GAP_THRESHOLD))
CLAUSE_END = (",", ".", "?", "!", ":", ";", "…")
_TRAILING_QUOTES = "\"'״׳”“)]"


def text_len(words) -> int:
    return len(" ".join(w["word"].strip() if isinstance(w, dict) else w for w in words))


def split_rows(tokens):
    """שורה אחת אם נכנס, אחרת שתי שורות מאוזנות (השבירה במקום שבו הארוכה
    מביניהן הכי קצרה; בתיקו — העליונה הקצרה). מחזיר [[מילים], ...]."""
    if len(tokens) < 2 or len(" ".join(tokens)) <= LINE_CHARS:
        return [tokens]
    best = min(range(1, len(tokens)),
               key=lambda i: (max(len(" ".join(tokens[:i])), len(" ".join(tokens[i:]))),
                              len(" ".join(tokens[:i]))))
    return [tokens[:best], tokens[best:]]


def ass_text(tokens, rows=None):
    """טקסט לאירוע ASS: כל שורה עטופה ב-RLE...PDF בנפרד, ושבירה מפורשת (\\N) —
    כדי שנדע בדיוק אילו מילים בכל שורה (הקריוקי מודד לפי זה).
    rows = שורות שנקבעו ביד ("📐 פריסת שורות", 21/10/2026); בלי — החלוקה המאוזנת הרגילה."""
    return "\\N".join("\u202b" + " ".join(r) + "\u202c" for r in (rows or split_rows(tokens)))


def ends_clause(word: str) -> bool:
    """המילה מסיימת משפט או חלק ממנו — גם כשאחרי הפיסוק יש מירכאה ('כפרתו".')."""
    return word.strip().rstrip(_TRAILING_QUOTES).endswith(CLAUSE_END) or \
        word.strip().endswith(CLAUSE_END)

# 🚨 ליטוש תזמון — נולד מתלונה אמיתית: *"כתוביות מרובות
# שקופצות פתאום"*. הסיבה: משך הכתובית נקבע ממשך ה**מילים**, ומילה מהירה
# נותנת כתובית של 0.12 שניות — שלושה פריימים, שנקראים כתקלה ולא כטקסט.
# בקליף אחד היו 14 כתוביות מתחת ל-0.6 שניות.
MIN_CHUNK_DURATION = 0.70   # מתחת לזה העין לא מספיקה לקרוא
HOLD_MAX = 1.00             # כמה מותר להחזיק כתובית אחרי שהמילה נגמרה
# הכתובית האחרונה מוחזקת יותר — עד סוף הקליף. בלי זה נשאר בסוף חצי שנייה
# עד שתיים של תמונה בלי טקסט, וזה נראה כאילו הסרטון נקטע. (הערה שהתקבלה:
# *"נתקע באמצע משפט"* — בפועל הכתובית האחרונה נגמרה **אחרי** סוף הווידאו.)
FINAL_HOLD_MAX = 3.00
# גישור על חלון קצר בלי כתובית. **מסך ריק באמצע קליף נקרא כתקלה**, גם
# כשהוא מוצדק. שני מקרים מייצרים אותו: הפסקה טבעית בדיבור, וקטע שלא
# הוכרע בתמלול ולכן במתכוון אין לו טקסט (ראה 5ב בסקיל). בשניהם עדיף
# להשאיר על המסך את מה שהרב אמר זה עתה מאשר להבהב לשחור.
MAX_BRIDGE = 2.00
# חריגה מ-3 מילים מותרת **רק** כדי להציל כתובית מהבהבת, ורק כשהמיזוג
# עדיין נשאר בתוך MAX_CHUNK_DURATION. הסיבה שזה נדרש: חותמות המילים של
# whisper לא אמינות ברזולוציה הזאת — הוא נתן ל"גם" 0.72 שניות ול-ארבע
# המילים שאחריה 0.36 יחד. הטקסט אמיתי, החלוקה לזמנים לא.
MERGE_MAX_WORDS = 8
# 🚨 תקרת משך למיזוג — נפרדת מ-MAX_CHUNK_DURATION בכוונה. נולד מסוף
# קליף 3 (הערה שהתקבלה: *"נתקע באמצע משפט"*): whisper נתן למילה "משהוא"
# משך של 1.84 שניות, והמשפט "יותר משהוא היה עצוב מהחטא" הוצג כ-
# "יותר" / "משהוא" / "היה עצוב מהחטא" — מילים בודדות תלויות באוויר.
# המיזוג נחסם כי הוא חרג מ-1.6ש'. **כשחותמות הזמן שגויות, תקרה שנגזרת
# מהן חוסמת דווקא את התיקון.**
MERGE_MAX_DURATION = 3.6
LONE_WORD_MAX = 1.2         # מילה בודדת שנשארת יותר מזה — למזג לשכנה
# 🚨 תקרת משך למילה בודדת. חותמת של whisper למילה כוללת בפועל גם את
# השתיקה שאחריה, ולכן יוצאות "מילים" של 1.9 שניות. זה לא משנה מה שרואים
# (ההחזקה ב-`polish_chunks` מחזירה את הזמן ממילא) — אבל זה **חוסם את
# המיזוג**, כי כל מיזוג עם מילה כזאת חורג מהתקרה. נמדד על שלושת הקליפים:
# חציון משך מילה 0.30-0.36ש', אחוזון 95 ~0.70ש'. 3× חציון הוא בדיוק הגבול
# שמפריד בין מילה ארוכה אמיתית לבין מילה+שתיקה.
WORD_DUR_CAP_FACTOR = 3.0
WORD_DUR_CAP_MIN = 0.80
MIN_VISIBLE_GAP = 0.04      # מרווח מינימלי בין כתוביות, שלא ייראו חופפות
BORROW_MAX = 0.35           # כמה מותר לדחות כתובית כדי שהקודמת לה תהיה קריאה

HEADER = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {PLAY_RES_X}
PlayResY: {PLAY_RES_Y}
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Heebo900,122,&H00FFFFFF,&H000000FF,&H00101010,&H00000000,0,0,0,0,100,100,0,0,1,8,0,2,60,60,320,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def fmt_time(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h:d}:{m:02d}:{s:05.2f}"


def cap_word_durations(words):
    """גוזם משכי-מילה לא סבירים. לא נוגע ב-start, רק ב-end."""
    durs = sorted(w["end"] - w["start"] for w in words if w["end"] > w["start"])
    if not durs:
        return words
    med = durs[len(durs) // 2]
    cap = max(WORD_DUR_CAP_MIN, WORD_DUR_CAP_FACTOR * med)
    out = []
    for w in words:
        w = dict(w)
        if w["end"] - w["start"] > cap:
            w["end"] = w["start"] + cap
        out.append(w)
    return out


def chunk_words(words, breaks=()):
    """`breaks` — אינדקסים שחייבים לפתוח נתח חדש.

    למה: הגרסה הקצרה נחתכת מתוך הארוכה בגבול מילה, ונתח כתובית שחוצה את
    הגבול היה מציג בפתיחת הקצרה מילה שהצופה לא שמע ("המצרים. צריך להבין"
    כשהאודיו מתחיל ב"צריך"). נתפס ב-QC של אחד הדוברים, 26/8/2026.
    """
    breaks = set(breaks)
    chunks = []
    hard = []      # hard[i] — האם הנתח ה-i נגמר בגבול קשה (פיסוק / עצירה / חיתוך)
    cur = []
    for idx, w in enumerate(words):
        text = w["word"].strip()
        if not text:
            continue
        if cur:
            gap = w["start"] - cur[-1]["end"]
            dur = w["end"] - cur[0]["start"]
            is_hard = idx in breaks or gap > GAP_THRESHOLD
            too_long = (len(cur) >= MAX_WORDS_PER_CHUNK or dur > MAX_CHUNK_DURATION
                        or text_len(cur + [w]) > MAX_CHUNK_CHARS)
            # מילה שסוגרת משפט לא נזרקת לבד לכתובית הבאה רק בגלל התקרה:
            # "לא נעים לבקש / סליחה." נקרא כשבירה, ו"סליחה." לבד מהבהב.
            closes = (not is_hard and too_long and ends_clause(text)
                      and text_len(cur + [w]) <= MAX_CHUNK_CHARS + 6
                      and w["end"] - cur[0]["start"] <= MERGE_MAX_DURATION)
            if not closes and (is_hard or too_long):
                chunks.append(cur)
                hard.append(is_hard)
                cur = []
        cur.append(w)
        if ends_clause(text):
            chunks.append(cur)
            hard.append(True)
            cur = []
    if cur:
        chunks.append(cur)
        hard.append(True)
    return chunks, hard


def polish_chunks(chunks, media_duration=None, hard=None):
    """הופך רשימת נתחים לזמני תצוגה קריאים.

    שלושה תיקונים, בסדר הזה:
    1. **החזקה** — כתובית נשארת על המסך עד הכתובית הבאה (עד `HOLD_MAX`
       אחרי סוף המילה), במקום להיעלם באמצע שקט קצר ולחזור. זה מה שמסיר
       את ההבהוב.
    2. **מיזוג** — נתח שגם אחרי ההחזקה קצר מ-`MIN_CHUNK_DURATION` מתמזג
       לשכן. עדיף ארבע מילים לשנייה שלמה מאשר שתי מילים לשתי עשיריות.
    3. **בלי חפיפה** — סוף כל כתובית נחתך לפני תחילת הבאה.

    מחזיר [(start, end, [words])].
    """
    if not chunks:
        return []

    if hard is None:
        hard = [False] * len(chunks)
    # it[3] — הנתח נגמר בגבול קשה; אסור להדביק אליו את הנתח שאחריו
    items = [[c[0]["start"], c[-1]["end"], list(c), h] for c, h in zip(chunks, hard)]

    # 2. מיזוג נתחים קצרים — לפני ההחזקה, כי מיזוג משנה את הגבולות
    changed = True
    while changed and len(items) > 1:
        changed = False
        for i, it in enumerate(items):
            # כמה זמן באמת יעמוד לרשות הנתח הזה אחרי ההחזקה
            nxt = items[i + 1][0] if i + 1 < len(items) else it[1] + HOLD_MAX
            avail = min(nxt, it[1] + HOLD_MAX) - it[0]
            # 🚨 "בודדת ותלויה" נמדד על הזמן ש**רואים** (אחרי ההחזקה),
            # לא על משך המילה. אחרי גיזום המשכים המילה עצמה קצרה, אבל
            # היא עדיין נשארת על המסך עד הכתובית הבאה — וזה מה שהעין רואה.
            lonely = len(it[2]) == 1 and avail > LONE_WORD_MAX
            if avail >= MIN_CHUNK_DURATION and not lonely:
                continue
            # מתמזגים לשכן שיישאר הקצר יותר, וזה חוקי רק אם לא חורגים
            def ok(k):
                if not (0 <= k < len(items)) or k == i:
                    return False
                if len(items[k][2]) + len(it[2]) > MERGE_MAX_WORDS:
                    return False
                if text_len(items[k][2] + it[2]) > MAX_CHUNK_CHARS:
                    return False
                a, b = (k, i) if k < i else (i, k)
                if items[a][3]:
                    # גבול קשה (פיסוק/עצירה) — לעולם לא מדביקים מעליו.
                    # זה מחליף את crosses_sentence הישן, שרק העדיף לא לחצות.
                    return False
                return items[b][1] - items[a][0] <= MERGE_MAX_DURATION

            cands = [k for k in (i - 1, i + 1) if ok(k)]
            if not cands:
                continue
            j = min(cands, key=lambda k: items[k][1] - items[k][0])
            a, b = (j, i) if j < i else (i, j)
            merged = [items[a][0], items[b][1], items[a][2] + items[b][2], items[b][3]]
            items[a:b + 1] = [merged]
            changed = True
            break

    # 1. החזקה עד הכתובית הבאה
    # 🚨 `media_duration` — התקרה של הכתובית האחרונה. בלי זה FINAL_HOLD_MAX
    # מותח אותה **מעבר לסוף הווידאו**, והמשפט האחרון נחתך תוך כדי הצגה.
    # זה בדיוק הפגם שתואר כ"נתקע באמצע משפט" (26/8/2026): ההחזקה
    # תוקנה אז, אבל שום דבר לא הצמיד אותה לאורך הקובץ, ולכן קליף שנגמר
    # מיד אחרי המילה האחרונה נשאר פגום. נמדד 28/8/2026: 47.59 מול 44.86.
    end_cap = (media_duration - MIN_VISIBLE_GAP) if media_duration else float("inf")
    for i, it in enumerate(items):
        last = i + 1 >= len(items)
        hold = FINAL_HOLD_MAX if last else HOLD_MAX
        limit = end_cap if last else items[i + 1][0] - MIN_VISIBLE_GAP
        it[1] = min(it[1] + hold, limit) if limit != float("inf") else it[1] + hold
        it[1] = max(it[1], items[i][0] + 0.05)

    # 3א. גישור פערים קצרים — אין הבהוב לשחור באמצע
    for i in range(len(items) - 1):
        gap = items[i + 1][0] - items[i][1]
        if 0 < gap <= MAX_BRIDGE:
            items[i][1] = items[i + 1][0] - MIN_VISIBLE_GAP

    # 3ב. בלי חפיפה, ובלי משך אפסי
    for i in range(len(items) - 1):
        if items[i][1] > items[i + 1][0] - MIN_VISIBLE_GAP:
            items[i][1] = items[i + 1][0] - MIN_VISIBLE_GAP

    # 3ג. "הלוואה" מהכתובית הבאה. הגבולות הקשים (3 למעלה) חוסמים מיזוג, ולכן
    # סוף משפט שנאמר מהר ("האי-נעימות," — 0.33ש') נשאר קצר מכדי לקרוא. במקום
    # לשבור את הכלל, דוחים מעט את הופעת הכתובית הבאה (עד BORROW_MAX), כל עוד
    # גם היא נשארת קריאה. איחור של שליש שנייה מול האודיו לא מורגש; הבהוב כן.
    for i in range(len(items) - 1):
        short = MIN_CHUNK_DURATION - (items[i][1] - items[i][0])
        if short <= 0:
            continue
        room = (items[i + 1][1] - items[i + 1][0]) - MIN_CHUNK_DURATION
        shift = min(short + MIN_VISIBLE_GAP, max(0.0, room), BORROW_MAX)
        if shift > 0:
            items[i + 1][0] += shift
            items[i][1] = items[i + 1][0] - MIN_VISIBLE_GAP
    items = [it for it in items if it[1] - it[0] > 0.05]

    return [(it[0], it[1], it[2]) for it in items]


def build_ass(words_json_path: str, ass_out_path: str, break_text_path: str = None,
              media_duration: float = None):
    with open(words_json_path, encoding="utf-8") as f:
        data = json.load(f)
    words = data["words"]
    breaks = []
    if break_text_path:
        from trim_version import find_span
        with open(break_text_path, encoding="utf-8") as f:
            i, j = find_span(words, f.read().strip())
        breaks = [i, j + 1]
    chunks, hard = chunk_words(cap_word_durations(words), breaks)
    chunks = polish_chunks(chunks, media_duration, hard)

    lines = [HEADER]
    for start, end, chunk in chunks:
        # שורה אחת או שתיים (split_rows), כל אחת עטופה ב-RLE...PDF
        text = ass_text(fix_words([w["word"].strip() for w in chunk]).split())
        lines.append(
            f"Dialogue: 0,{fmt_time(start)},{fmt_time(end)},Default,,0,0,0,,{text}\n"
        )

    with open(ass_out_path, "w", encoding="utf-8-sig") as f:
        f.writelines(lines)


if __name__ == "__main__":
    # ארגומנט שלישי (רשות): קובץ הטקסט של הגרסה הקצרה — כדי שנתח כתובית
    # לא יחצה את גבול החיתוך שלה.
    # ארגומנט רביעי (רשות): אורך הווידאו בשניות — תקרה לכתובית האחרונה.
    # להעביר תמיד כשיש קובץ וידאו; בלי זה הכתובית האחרונה עלולה לחרוג ממנו.
    argv = [a for a in sys.argv[1:] if not a.startswith("--")]
    dur = None
    for a in sys.argv[1:]:
        if a.startswith("--duration="):
            dur = float(a.split("=", 1)[1])
    build_ass(argv[0], argv[1], argv[2] if len(argv) > 2 else None, dur)
