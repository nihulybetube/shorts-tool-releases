# -*- coding: utf-8 -*-
"""
make_short_progress.py — מה כבר נעשה בכל שיעור, כדי שאפשר יהיה להמשיך מאיפה שעצרנו.

למה (21/10/2026, אחרי השיעור הראשון שלו בתוכנה — "חשוב מאוד"): סגירת החלון של התוכנה בטוחה, אבל
סגירת החלון השחור, כיבוי המחשב או הפסקת חשמל הורגים את העבודה באמצע. עד עכשיו זה אומר להתחיל הכול
מחדש (הורדה, חיתוך, תמלול). כאן כל שלב שהסתיים נרשם ב-<project>/progress.json, וריצה חוזרת של אותה
פקודה מדלגת על מה שכבר גמור — אחרי שבודקים שהקובץ שלו באמת שלם (קידוד שנקטע משאיר mp4 שבור).

הקובץ:
  job    — העבודה האחרונה: kind, argv, pid, status (running/done/failed), error. status=running עם pid
           מת = נקטעה באמצע → בחלון "▶ המשך מאיפה שעצרתי" (מריץ שוב את אותו argv).
  plan   — רשימת השלבים של העבודה ([key, תיאור, הערכת שניות]) — לחלון "בעבודה".
  steps  — key → {"state": run/done/skip/fail, "detail"}
  data   — מה ששלב צריך להעביר לשלב הבא בריצה חוזרת (פרטי הסרטון, גבולות שנמדדו, חתימות).

שורות שהחלון קורא מהפלט: PLAN=<json> · STEP=<key>\\t<state>\\t<detail>
"""
import json
import os
import subprocess
import time
from pathlib import Path

NAME = "progress.json"
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")


def path(P):
    return Path(P) / NAME


def load(P):
    try:
        return json.load(open(path(P), encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save(P, d):
    f = path(P)
    tmp = f.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())              # הפסקת חשמל: או הישן או החדש, לא קובץ ריק
    tmp.replace(f)


def edit(P, fn):
    # 21/10/2026 (כרטיס 12): החלפת מוזיקה רצה עכשיו במקביל לעבודה כבדה של קליף אחר באותו שיעור —
    # שתי קריאות-כתיבה בו בזמן היו מאבדות עדכון. נעילת קובץ קצרה סביב קריאה→שינוי→כתיבה.
    import fcntl
    lk = open(Path(P) / (NAME + ".lock"), "w")
    try:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = load(P)
        fn(d)
        save(P, d)
        return d
    finally:
        fcntl.flock(lk, fcntl.LOCK_UN)
        lk.close()


def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
    except (OSError, ValueError, TypeError):
        return False
    try:                                   # pid שנמחזר לתהליך אחר — לא שלנו
        cmd = Path("/proc/%d/cmdline" % int(pid)).read_bytes()
        return b"make_short" in cmd
    except OSError:
        return True


def job_state(P):
    """running / interrupted / failed / done / '' — לפי הקובץ בלבד (כשהשרת לא מכיר את העבודה)."""
    j = load(P).get("job") or {}
    s = j.get("status", "")
    if s == "running":
        return "running" if pid_alive(j.get("pid")) else "interrupted"
    return s


CUR = {"P": None}          # הפרויקט של העבודה שרצה בתהליך הזה — בשביל job_end בסוף


def job_begin(P, kind, argv):
    # עבודה קלה (החלפת מוזיקה, שניות) שרצה במקביל לעבודה כבדה באותו שיעור: לא דורסת את רשומת
    # העבודה הכבדה — אחרת אחרי הפעלה מחדש השרת היה חושב שהכבדה הסתיימה ומריץ אותה שוב
    if os.environ.get("MAKE_SHORT_NO_PROGRESS") == "1":
        return {}
    CUR["P"] = str(P)

    def fn(d):
        old = d.get("job") or {}
        d["job"] = {"kind": kind, "argv": [str(a) for a in argv], "pid": os.getpid(), "status": "running",
                    "started": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "resumed": bool(old.get("argv") == [str(a) for a in argv] and old.get("status") != "done")}
        # 22/10 (כרטיס 14): ההגדרות שהעבודה התחילה איתן (צילום שהחלון שמר) — "▶ המשך" אחרי הפסקה רץ איתן,
        # גם אם בינתיים שינה הגדרה; עבודה חדשה מקבלת צילום חדש
        snap = os.environ.get("MAKE_SHORT_SETTINGS_SNAP")
        if snap:
            d["job"]["settings"] = snap
        if kind != old.get("kind") or old.get("status") == "done":
            d["steps"] = {}                # עבודה חדשה — רשימת השלבים מתחילה מאפס (הנתונים נשארים)
    return edit(P, fn)["job"]


def job_end(P, ok, error=""):
    P = P or CUR["P"]
    if not P:
        return

    def fn(d):
        j = d.setdefault("job", {})
        if j.get("pid") == os.getpid():
            j.update(status="done" if ok else "failed", error=error[:600], ended=time.strftime("%Y-%m-%d %H:%M:%S"))
    if Path(P).is_dir():
        edit(P, fn)


def plan(P, items):
    """items = [(key, תיאור, שניות משוערות)]"""
    edit(P, lambda d: d.__setitem__("plan", [list(x) for x in items]))
    print("PLAN=" + json.dumps(items, ensure_ascii=False), flush=True)


def step(P, key, state, detail=""):
    def fn(d):
        d.setdefault("steps", {})[key] = {"state": state, "detail": detail, "at": time.time()}
    edit(P, fn)
    print("STEP=%s\t%s\t%s" % (key, state, detail.replace("\n", " ")), flush=True)


def data(P):
    return load(P).get("data") or {}


def put(P, key, value):
    edit(P, lambda d: d.setdefault("data", {}).__setitem__(key, value))


def media_ok(f, expect=None, tol=2.0):
    """קובץ וידאו/שמע שלם: ffprobe קורא אורך, השנייה האחרונה מתפענחת בלי שגיאה, והאורך קרוב
    למה שציפינו (expect). mp4 שהקידוד שלו נקטע — אין לו moov ו-ffprobe נכשל."""
    f = Path(f)
    if not f.is_file() or f.stat().st_size < 1024:
        return False
    try:
        r = subprocess.run([FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(f)],
                           capture_output=True, text=True, timeout=60)
        dur = float(r.stdout.strip().splitlines()[0])
    except Exception:
        return False
    if dur <= 0.3 or (expect is not None and abs(dur - expect) > tol):
        return False
    r = subprocess.run([FFMPEG, "-v", "error", "-sseof", "-1", "-i", str(f), "-f", "null", "-"],
                       capture_output=True, text=True, timeout=120)
    return r.returncode == 0 and "Invalid data" not in r.stderr and "moov atom" not in r.stderr


def sig(f):
    """חתימה זולה של קובץ (גודל + זמן שינוי) — "האם הקובץ השתנה מאז"."""
    try:
        s = Path(f).stat()
        return "%d:%d" % (s.st_size, int(s.st_mtime))
    except OSError:
        return ""
