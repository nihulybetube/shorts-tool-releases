# -*- coding: utf-8 -*-
"""אימות תמלול עצמאי: מעלה את האודיו של קליף ל-Gemini ומבקש תמלול מילולי.

למה זה קיים: whisper בעברית טועה באופן עקבי בשמות פרטיים ובמונחי הלכה, וטעות
כזאת נצרבת לכתובית ומגיעה לצופה. מודל שני ששומע את אותו אודיו הוא הדרך היחידה
להפריד "ASR שגה" מ"הרב באמת אמר את זה" בלי אוזן אנושית.

שימוש:
  shorts.sh py gemini_verify_audio.py <audio_or_video> <out_txt> [hint]
  shorts.sh py gemini_verify_audio.py --batch <out_dir> <wav> <wav> ... [--hint=...]

🚨 **מצב --batch: כל הקליפים בבקשה אחת.** המכסה החינמית נספרת ב**פניות**
(20 ליום לכל מודל), לא באורך, ולכן שיעור עם 3 קליפים שרף 3 פניות על מה שאפשר
לעשות באחת. ההעלאות עצמן (Files API) אינן נספרות במכסה הזאת — רק generateContent.
בקשת המשתמש, 9/10/2026. הפלט מופרד ב"### קטע N"; אם מספר הקטעים שחזר אינו
תואם — נכשל בקול ולא מנחש איזה טקסט שייך לאיזה קליף.

הערה: הוא **לא** מייבא את `ask()` של ask_gemini_upload — שם שער האמת סופר
טוקנים במודליות VIDEO, ולקובץ אודיו זה תמיד 0. כאן סופרים AUDIO.
"""
import importlib.util as _ilu
import urllib.parse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

_here = os.path.dirname(os.path.abspath(__file__))
_src = os.path.join(_here, "ask_gemini_upload.py")
_spec = _ilu.spec_from_file_location("ask_gemini_upload", _src)
_up = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_up)

# gemini-flash-latest נופל ב-503 (עומס) לפעמים שעות ברצף (24/9/2026: כל היום).
# gemini-3.6-flash הוכח כמאזין אמיתי בבחירת המוזיקה — אפשר להחליף בלי לגעת בקוד.
MODEL = os.environ.get("SHORTS_GEMINI_VERIFY_MODEL", "gemini-flash-latest")

# 🚨 סולם נסיגה (9/10/2026, בקשת המשתמש להפעיל "פיצול מודלים"). המכסה החינמית
# היא 20 פניות ליום **לכל מודל בנפרד**, אז מודל שנגמרה בו המכסה אינו סוף הדרך.
# הסדר אינו שרירותי: שני הראשונים חזקים באותה מידה; השלישי קל יותר ונמדד כפחות
# מדויק על אותם ארבעה קליפים (81-84% חפיפה, "אלה תולדות"→"אֵלת דות",
# "מכעיסים"→"מכייסים"), ולכן הוא אחרון, ועם בקשות קטנות יותר.
# 🚨 כבוי כברירת מחדל (החלטת המשתמש, 9/10/2026): "נשמע לי מסוכן לעבוד עם המודל
# היותר פשוט… להשאיר כרגע רק את איחוד הבדיקות". כשהמכסה נגמרת — נעצרים ומודיעים
# לו, כמו קודם. להפעלה חד-פעמית: SHORTS_GEMINI_FALLBACK=1 (או רשימה משלך).
_LADDER = os.environ.get("SHORTS_GEMINI_FALLBACK", "")
if _LADDER == "1":
    FALLBACK_MODELS = [MODEL, "gemini-3.6-flash", "gemini-flash-lite-latest"]
elif _LADDER:
    FALLBACK_MODELS = [MODEL] + [m.strip() for m in _LADDER.split(",") if m.strip()]
else:
    FALLBACK_MODELS = [MODEL]
LITE_MAX_PER_REQUEST = 2      # לקל: בקשה קטנה, שלא ידלג על קטע


class QuotaExhausted(RuntimeError):
    """המכסה היומית של המודל הזה נגמרה — להחליף מודל, לא לנסות שוב."""

PROMPT = """תמלל את קטע האודיו המצורף **מילה במילה**, בעברית, בדיוק כפי שנאמר.

כללים:
- אל תתקן, אל תערוך ואל תשפר את הניסוח. תמלול מילולי בלבד.
- שמות של רבנים, ספרים ומקורות — כתוב אותם במדויק כפי שנשמעים.
- ציטוט מפסוק או ממאמר חז"ל — כתוב אותו בנוסח המקורי המדויק.
- אם מילה אינה ברורה בשמע, כתוב אותה בסוגריים מרובעים כך: [לא ברור].
- אל תוסיף חותמות זמן ואל תוסיף הערות. רק הטקסט.
"""


def ask_audio(files, prompt, api_key, model=MODEL, thinking_budget=8192):
    """files — [(file_uri, mime_type), ...]. קובץ אחד או כמה באותה בקשה."""
    if isinstance(files, str):          # תאימות לאחור: (uri, mime) כשני ארגומנטים
        raise TypeError("ask_audio מקבל רשימת (uri, mime)")
    parts = [{"text": prompt}]
    for i, (uri, mime) in enumerate(files, 1):
        if len(files) > 1:
            parts.append({"text": f"### קטע {i}"})
        parts.append({"file_data": {"file_uri": uri, "mime_type": mime}})
    body = {
        "contents": [{"parts": parts}],
        "generationConfig": {"thinkingConfig": {"thinkingBudget": thinking_budget}},
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={urllib.parse.quote(api_key, safe='')}"
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    RETRY = {429, 500, 502, 503, 504}
    last = None
    result = None
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            break
        except TimeoutError:
            last = "timeout"
        except urllib.error.HTTPError as e:
            if e.code not in RETRY:
                raise
            if e.code == 429:
                # "retry in 15s" בגוף התשובה מטעה כשהמכסה **היומית** נגמרה
                # (מוקש 16). לא מנסים שוב — מחליפים מודל.
                body = e.read().decode("utf-8", "replace")
                if "PerDay" in body or "per day" in body.lower():
                    raise QuotaExhausted(f"המכסה היומית של {model} נגמרה") from None
            last = e
        if attempt < 4:
            time.sleep(5 * (2 ** attempt))
    if result is None:
        raise RuntimeError(f"Gemini לא זמין אחרי 5 ניסיונות: {last}")
    if "error" in result:
        raise RuntimeError(f"Gemini API error: {result['error']}")
    text = "".join(p.get("text", "") for p in result["candidates"][0]["content"]["parts"])
    usage = result.get("usageMetadata", {})
    audio_tokens = next(
        (d["tokenCount"] for d in usage.get("promptTokensDetails", [])
         if d.get("modality") == "AUDIO"), 0)
    # אותה הוכחה כמו בשער הווידאו: 0 טוקני אודיו = הוא לא שמע כלום וניחש
    if audio_tokens == 0:
        raise RuntimeError("אזהרה: 0 audio tokens — ג'מיני לא עיבד את האודיו")
    return text, audio_tokens


BATCH_RULES = """
לפניך {n} קטעי אודיו נפרדים, מסומנים "### קטע 1" עד "### קטע {n}".
תמלל **כל אחד מהם בנפרד**, בסדר שבו הם מופיעים, ובפורמט הזה בדיוק:

### קטע 1
<התמלול של קטע 1>

### קטע 2
<התמלול של קטע 2>

אל תאחד קטעים, אל תדלג על קטע, ואל תוסיף שום טקסט מחוץ למבנה הזה.
"""


def split_batch(text, n):
    """מפצל את הפלט ל-n תמלולים לפי כותרות "### קטע N". None אם לא תואם."""
    parts = re.split(r"^\s*#{0,3}\s*קטע\s*(\d+)\s*$", text, flags=re.M)
    if len(parts) < 3:
        return None
    out = {}
    for idx, body in zip(parts[1::2], parts[2::2]):
        out[int(idx)] = body.strip()
    if sorted(out) != list(range(1, n + 1)) or not all(out.values()):
        return None
    return [out[i] for i in range(1, n + 1)]


def _groups(medias, per_request):
    """חלוקה לקבוצות, מאוזנת: 4 קליפים עם תקרה 3 → 2+2, לא 3+1.

    🚨 למה זה קיים (שאלת המשתמש, 9/10/2026): איחוד חוסך פניות אבל מעמיס את
    הבקשה. על המודל החזק אפשר הכול באחת; כשעוברים למודל הקל (`flash-lite`,
    כשהמכסה של החזק נגמרה) בקשה כבדה היא בדיוק מה שהוא עלול לפספס — לדלג על
    קטע או לערבב. שם מגבילים ל-2 בערך, וגם ככה זו פנייה אחת במקום ארבע."""
    n = len(medias)
    if not per_request or per_request >= n:
        return [medias]
    k = -(-n // per_request)                     # מספר הקבוצות
    size, extra = divmod(n, k)
    out, i = [], 0
    for g in range(k):
        step = size + (1 if g < extra else 0)
        out.append(medias[i:i + step])
        i += step
    return out


def run_batch(out_dir, medias, hint, per_request=0, dry=False):
    """מריץ על המודל הראשון; אם נגמרה בו המכסה היומית — יורד בסולם המודלים.
    העלאות אינן נספרות במכסה, ולכן מעבר מודל לא "מבזבז" את מה שכבר הועלה."""
    last = None
    for mi, model in enumerate(FALLBACK_MODELS):
        per = per_request
        if "lite" in model and (not per or per > LITE_MAX_PER_REQUEST):
            per = LITE_MAX_PER_REQUEST
        if mi:
            print(f"↻ עובר ל-{model} (מכסה נפרדת)" +
                  (f", עד {per} קליפים לפנייה" if per else ""))
        try:
            return _run_batch_model(out_dir, medias, hint, per, dry, model)
        except QuotaExhausted as e:
            last = e
            print(f"  {e}")
    raise RuntimeError(f"כל המודלים מוצו היום: {last}")


def _run_batch_model(out_dir, medias, hint, per_request, dry, model):
    groups = _groups(medias, per_request)
    if dry:
        for gi, g in enumerate(groups, 1):
            print(f"  פנייה {gi}: " + ", ".join(os.path.basename(m) for m in g))
        print(f"סה\"כ {len(groups)} פניות עבור {len(medias)} קליפים ({model})")
        return
    api_key = _up.load_api_key()
    total_tokens = 0
    for gi, group in enumerate(groups, 1):
        prompt = PROMPT + BATCH_RULES.format(n=len(group)) + \
            (f"\nהקשר שעשוי לעזור: {hint}\n" if hint else "")
        files = []
        for m in group:
            print(f"מעלה {os.path.basename(m)}...")
            files.append(_up.upload_file(m, api_key))
        print(f"פנייה {gi}/{len(groups)} ל-Gemini עבור {len(files)} קליפים ({model})...")
        text, tokens = ask_audio(files, prompt, api_key, model=model)
        total_tokens += tokens
        texts = split_batch(text, len(group)) if len(group) > 1 else [text.strip()]
        if texts is None:
            raw = os.path.join(out_dir, f"batch_raw_{gi}.txt")
            with open(raw, "w", encoding="utf-8") as f:
                f.write(text)
            raise RuntimeError(
                f"הפלט לא התחלק ל-{len(group)} קטעים — הגולמי נשמר ב-{raw}. "
                "לפצל ידנית או להריץ קליף-קליף; לא משייכים טקסט לקליף בניחוש.")
        for m, t in zip(group, texts):
            stem = os.path.splitext(os.path.basename(m))[0]
            path = os.path.join(out_dir, f"{stem}_gemini.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write(t + "\n")
            print(f"  ✓ {os.path.basename(path)} ({len(t.split())} מילים)")
    print(f"audio_tokens={total_tokens} · {len(groups)} פניות במקום {len(medias)} · {model}")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    hint = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--hint=")), "")
    if "--batch" in sys.argv:
        out_dir, medias = args[0], args[1:]
        if not medias:
            raise SystemExit("--batch <out_dir> <wav> [<wav> ...]")
        os.makedirs(out_dir, exist_ok=True)
        per = next((int(a.split("=", 1)[1]) for a in sys.argv[1:]
                    if a.startswith("--max-per-request=")), 0)
        return run_batch(out_dir, medias, hint, per, "--dry-run" in sys.argv)
    media, out_path = args[0], args[1]
    hint = hint or (args[2] if len(args) > 2 else "")
    api_key = _up.load_api_key()
    prompt = PROMPT + (f"\nהקשר שעשוי לעזור: {hint}\n" if hint else "")
    print(f"מעלה {os.path.basename(media)} ל-Gemini...")
    uri, mime = _up.upload_file(media, api_key)
    text, tokens = ask_audio([(uri, mime)], prompt, api_key)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"audio_tokens={tokens} saved -> {out_path}")


if __name__ == "__main__":
    main()
