# -*- coding: utf-8 -*-
"""
make_short_snap.py — עדכון התוכנה בלי להפיל עבודה שרצה (21/10/2026, בקשתו לכל שלוש התוכנות).

הבעיה: עבודה כבדה (הכנה, סיום...) היא סקריפט שקורא לעוד סקריפטים (תמלול, חיתוך, מיקס...) לפי הנתיב. אם הקוד
משתנה באמצע (עדכון מ"עדכון תוכנה", או עריכה בקבצים ע"י Claude Code), חלק מהשלבים היו רצים בקוד החדש וחלק
בישן — תערובת שלא נבדקה.

הפתרון (כמו בתוכנת ה-mp3-לווידאו):
  1. **צילום קוד בלתי-ניתן-לשינוי לכל עבודה**: בתחילת העבודה הקוד (pipeline/ + shorts.sh) מועתק לתיקייה
     <data>/snapshots/<גיבוב>/ והעבודה רצה משם בלבד. שורת הפקודה היא הנתיב שבצילום, ולכן כל קריאה לסקריפט
     אחר מתוך העבודה נשארת בתוך אותו צילום. עבודה חדשה — צילום חדש (אם הקוד השתנה).
  2. **טביעת קוד**: גיבוב של הקבצים. השרת בודק כל כמה שניות אם הקבצים בדיסק השתנו (מהחלון או מ-Claude Code),
     מחכה שיירגעו, מריץ בדיקה עצמית, ומסמן "עדכון ממתין". כשאין שום עבודה (גם לא בתור) — השרת מופעל מחדש
     לבד על הקוד החדש.
  3. **ניקוי**: צילום שאף תהליך חי לא משתמש בו, ושאינו הנוכחי — נמחק.

שימוש פנימי (מ-make_short_app.py). בדיקות: `make_short_snap.py probe <שניות>` (רק במצב בדיקה).
"""
import hashlib
import os
import shutil
import sys
import time
from pathlib import Path

VERSION = "v1"                                     # נערך רק בבדיקות (probe) כדי להראות איזה קוד רץ
HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
ROOT = DATA / "snapshots"
LINKED = ("assets", "setup", "docs", "windows")    # לא קוד שרץ — מקושרים לעץ החי (גופנים, לוגו וכו')


def tracked(repo=REPO):
    """הקבצים שמהם בנוי הקוד שרץ: כל pipeline/ (בלי מטמון פייתון) + shorts.sh."""
    out = [p for p in sorted((repo / "pipeline").rglob("*")) if p.is_file() and "__pycache__" not in p.parts
           and p.suffix != ".pyc"]
    if (repo / "shorts.sh").is_file():
        out.append(repo / "shorts.sh")
    return out


def stat_sig(repo=REPO):
    """חתימה זולה (גודל וזמן שינוי) — לזיהוי שהקבצים השתנו, בלי לקרוא אותם."""
    sig = []
    for p in tracked(repo):
        try:
            s = p.stat()
        except OSError:
            continue
        sig.append((str(p.relative_to(repo)), s.st_size, s.st_mtime_ns))
    return tuple(sig)


def content_hash(repo=REPO):
    h = hashlib.sha1()
    for p in tracked(repo):
        try:
            h.update(str(p.relative_to(repo)).encode("utf-8") + b"\0" + p.read_bytes() + b"\0")
        except OSError:
            continue
    return h.hexdigest()[:12]


def changed_files(old_dir, repo=REPO):
    """אילו קבצים שונים בין צילום (או עץ) לבין העץ החי — להודעה "עודכנו: ..."."""
    out = []
    for p in tracked(repo):
        rel = p.relative_to(repo)
        q = Path(old_dir) / rel
        try:
            if not q.exists() or q.read_bytes() != p.read_bytes():
                out.append(str(rel))
        except OSError:
            out.append(str(rel))
    return out


def ensure(repo=REPO):
    """מחזיר (תיקיית הצילום, גיבוב). קיים כבר לאותו קוד — משתמש בו."""
    ROOT.mkdir(parents=True, exist_ok=True)
    tmp = ROOT / (".tmp-%d-%d" % (os.getpid(), time.time_ns() % 10**9))
    try:
        for p in tracked(repo):
            dst = tmp / p.relative_to(repo)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
        for name in LINKED:
            if (repo / name).exists():
                os.symlink(str(repo / name), str(tmp / name))
        h = content_hash(tmp)                     # הגיבוב של מה שהועתק בפועל — לא של מה שהשתנה באמצע ההעתקה
        dest = ROOT / h
        if dest.exists():
            shutil.rmtree(tmp, ignore_errors=True)
            os.utime(dest, None)                  # "בשימוש לאחרונה" — לניקוי
            return dest, h
        for p in tracked(tmp):
            os.chmod(p, 0o555 if os.access(p, os.X_OK) else 0o444)
        os.replace(tmp, dest)
        return dest, h
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        raise


def rewrite(cmd, live_scripts=HERE, dest=None):
    """הפקודה של העבודה → אותה פקודה כשכל נתיב לסקריפט בקוד החי מוחלף בנתיב שבצילום. מחזיר (פקודה, גיבוב).
    dest = צילום קיים לשימוש (הגרסה האחרונה שנבדקה), במקום לצלם את הקוד שבדיסק."""
    if dest:
        dest = Path(dest)
        h = dest.name
        os.utime(dest, None)
    else:
        dest, h = ensure()
    pre = str(live_scripts) + os.sep
    new = str(dest / "pipeline" / "scripts") + os.sep
    return [new + str(c)[len(pre):] if str(c).startswith(pre) else c for c in cmd], h


def referenced():
    """צילומים שתהליך חי עדיין משתמש בהם (לפי שורת הפקודה של כל התהליכים)."""
    seen = set()
    base = (str(ROOT) + os.sep).encode()
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return seen
    for pid in pids:
        try:
            data = open("/proc/%s/cmdline" % pid, "rb").read()
        except OSError:
            continue
        i = data.find(base)
        while i != -1:
            seen.add(data[i + len(base):i + len(base) + 12].decode("ascii", "ignore"))
            i = data.find(base, i + 1)
    return seen


def clean(keep=(), min_age=600):
    """מוחק צילומים שאין בהם שימוש: לא נקראים משום תהליך, לא ב-keep, ולא חדשים מ-min_age שניות. מחזיר את מה שנמחק."""
    gone = []
    if not ROOT.is_dir():
        return gone
    used = referenced()
    now = time.time()
    for d in ROOT.iterdir():
        try:
            if not d.is_dir():
                continue
            age = now - d.stat().st_mtime
            if d.name.startswith(".tmp-"):
                if age > 3600:
                    shutil.rmtree(d, ignore_errors=True)
                continue
            if d.name in used or d.name in keep or age < min_age:
                continue
            shutil.rmtree(d, ignore_errors=True)
            gone.append(d.name)
        except OSError:
            continue
    return gone


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "probe":
        # בדיקת עדכון באמצע עבודה: מדפיס איזה קוד רץ, ממתין, ואז קורא לסקריפט אחר (כמו שעבודה אמיתית קוראת לשלבים)
        import subprocess
        secs = float(a[1]) if len(a) > 1 else 5
        print("PROBE start version=%s file=%s" % (VERSION, __file__), flush=True)
        time.sleep(secs)
        r = subprocess.run([sys.executable, str(HERE / "make_short_snap.py"), "version"], capture_output=True, text=True)
        print("PROBE sub-script version=%s" % r.stdout.strip(), flush=True)
    elif a and a[0] == "version":
        print(VERSION)
    else:
        print(__doc__)
