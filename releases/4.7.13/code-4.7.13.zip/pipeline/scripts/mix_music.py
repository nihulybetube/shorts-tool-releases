# -*- coding: utf-8 -*-
"""מערבב מוזיקת רקע לשורט לפי יעדים שנמדדו מסרטוני ההשראה של המשתמש:
מוזיקה בהפסקות קצרות ~10dB מתחת לקול, תחת דיבור ~15dB מתחת,
ובהפסקה ארוכה (>=2.5s) היא עולה עד ~4dB מתחת לקול.
שימוש: mix.py <video.mp4> <music.mp3> <out.mp4> [--under -15] [--pause -10] [--swell -4]
"""
import subprocess, sys, json, os
import numpy as np
from faster_whisper.vad import get_speech_timestamps, VadOptions

SR = 48000
VSR = 16000
WIN = 0.05
ATT = 0.15    # שניות - ירידה מהירה כשהדיבור מתחיל
REL = 0.70    # שניות - עלייה איטית כשהדיבור נפסק
LONG_PAUSE = 1.5

def ff(args):
    return subprocess.run(["ffmpeg","-v","error"]+args, capture_output=True)

def track_name(path):
    try:
        return json.load(open(path + ".license.json", encoding="utf-8")).get("title") or os.path.basename(path)
    except (OSError, ValueError):
        return os.path.basename(path)

def load(path, sr, ch=1, what="track"):
    r = subprocess.run(["ffmpeg","-v","error","-i",path,"-f","f32le","-ac",str(ch),"-ar",str(sr),"-"],
                       capture_output=True)
    a = np.frombuffer(r.stdout[:len(r.stdout)//4*4], dtype=np.float32).astype(np.float64)
    # 29/10 (סקירה חיצונית): קובץ פגום נתן מערך ריק ו-ZeroDivisionError בלי שם — עכשיו הודעה ברורה
    if r.returncode or len(a) < sr * ch // 10:
        err = r.stderr.decode(errors="replace").strip().splitlines()[-1:] or [""]
        if what == "track":
            sys.exit("המנגינה \"%s\" פגומה או ריקה ולא נקראה (%s).\n"
                     "מה לעשות: לבחור לקליף מנגינה אחרת (\"החלף מוזיקה\"), ובספריית המוזיקה ללחוץ ⏸ השבת על המנגינה הזאת."
                     % (track_name(path), err[0][:120]))
        sys.exit("לא הצלחתי לקרוא את הקול של הסרטון לפני הוספת המוזיקה (%s)" % err[0][:120])
    return a.reshape(-1, ch) if ch > 1 else a

def db(x): return 20*np.log10(max(float(x),1e-12))

def main():
    vid, mus, out = sys.argv[1], sys.argv[2], sys.argv[3]
    args = dict(under=-15.0, pause=-10.0, swell=-4.0)
    for i, a in enumerate(sys.argv[4:]):
        if a.startswith("--") and a[2:] in args: args[a[2:]] = float(sys.argv[4+i+1])

    sp_audio = load(vid, SR, what="video")   # mono, לניתוח
    dur = len(sp_audio)/SR
    v16 = load(vid, VSR, what="video").astype(np.float32)
    ts = get_speech_timestamps(v16, VadOptions(min_silence_duration_ms=100, speech_pad_ms=0))
    speech = [(t["start"]/VSR, t["end"]/VSR) for t in ts]

    n = int(SR*WIN); m = len(sp_audio)//n
    fr = sp_audio[:m*n].reshape(m, n)
    rms = np.sqrt((fr**2).mean(axis=1))
    t = np.arange(m)*WIN
    is_sp = np.zeros(m, bool)
    for a,b in speech: is_sp[(t>=a)&(t<b)] = True
    speech_db = db(np.median(rms[is_sp])) if is_sp.any() else -20.0

    # אורך כל הפסקה, כדי לדעת מתי לתת למוזיקה לעלות
    gap_len = np.zeros(m)
    i = 0
    while i < m:
        if not is_sp[i]:
            j = i
            while j < m and not is_sp[j]: j += 1
            gap_len[i:j] = (j-i)*WIN
            i = j
        else: i += 1

    target = np.where(is_sp, speech_db+args["under"],
             np.where(gap_len >= LONG_PAUSE, speech_db+args["swell"], speech_db+args["pause"]))

    # החלקה א-סימטרית: ירידה מהירה, עלייה איטית
    sm = np.empty(m); cur = target[0]
    ka = 1-np.exp(-WIN/ATT); kr = 1-np.exp(-WIN/REL)
    for i in range(m):
        cur += (target[i]-cur)*(ka if target[i] < cur else kr)
        sm[i] = cur

    music = load(mus, SR, 2)
    need = len(sp_audio)
    if len(music) < need:                      # לולאה עם חפיפה קצרה
        reps = int(np.ceil(need/len(music)))
        music = np.tile(music, (reps,1))
    music = music[:need]
    mus_db = db(np.sqrt((music**2).mean()))
    # תיקון קבוע לטראק (mix_gain_db בקובץ ה-license.json שלו): העוצמה כאן נמדדת על כל
    # התדרים, וטראק שרובו בס (Isolated: 86% מתחת ל-200Hz) יוצא כמעט לא נשמע ברמקול
    # של טלפון — נמדד 9dB מתחת לשאר בתחום השמיעה. המשתמש ביקש להגביר אותו תמיד.
    try:
        mus_db -= float(json.load(open(mus + ".license.json", encoding="utf-8")).get("mix_gain_db", 0))
    except (OSError, ValueError):
        pass

    gain_db = sm - mus_db
    g = np.interp(np.arange(need)/SR, t+WIN/2, 10**(gain_db/20))
    # פייד-אין ופייד-אאוט
    fi, fo = int(1.2*SR), int(1.8*SR)
    g[:fi] *= np.linspace(0,1,fi); g[-fo:] *= np.linspace(1,0,fo)
    music = music*g[:,None]

    mix_path = out.replace(".mp4","_music.wav")
    (music.astype(np.float32)).tofile(mix_path+".raw")
    ff(["-y","-f","f32le","-ar",str(SR),"-ac","2","-i",mix_path+".raw",mix_path])
    r = ff(["-y","-i",vid,"-i",mix_path,
            "-filter_complex","[0:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a];"
                              "[1:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[b];"
                              "[a][b]amix=inputs=2:normalize=0:duration=first[m]",
            "-map","0:v","-map","[m]","-c:v","copy","-c:a","aac","-b:a","192k",out])
    if r.returncode:                           # לפני 29/10 הודפס ויצא 0 — עכשיו נכשל באמת
        sys.exit("ערבוב המוזיקה לסרטון נכשל: %s" % r.stderr.decode(errors="replace").strip()[-300:])
    else:
        # קובצי הביניים (~20MB לקליף) נשארו ליד הסרטון ו-export העתיק אותם לתיקיית הפלט
        for p in (mix_path, mix_path + ".raw"):
            if os.path.exists(p): os.remove(p)
    print(json.dumps({"video": out, "dur": round(dur,1), "speech_dB": round(speech_db,1),
                      "music_dB_targets": {k: round(speech_db+v,1) for k,v in args.items()},
                      "long_pauses>=2.5s": int(((gap_len>=LONG_PAUSE)&~is_sp).sum()*WIN)},
                     ensure_ascii=False))

main()
