# -*- coding: utf-8 -*-
"""תמלול — נתיב אחד, שני מנועים.

    shorts.sh py asr.py run --media a.mp4 b.mp4 --out-dir work/subtitles

הפלט זהה בשני המנועים, כי כל שאר הפייפליין קורא אותו:
    <stem>_words.json     — חותמות ברמת מילה
    <stem>.segments.json  — avg_logprob / no_speech_prob לכל מקטע
    <stem>.txt            — הטקסט הרציף

איזה מנוע: `SHORTS_ASR` מ-`config.env` (`shorts.sh setup` כותב אותו).
  local — faster-whisper על המכונה הזאת. עם GPU זה מהיר; בלי GPU זה עובד
          אבל לוקח פי-כמה מזמן ההקלטה. חינם, ובלי חשבון.
  modal  — אותו מודל בדיוק על GPU בענן. אגורות לריצה, חוסם עד שמסתיים.

🚨 המודל הוא הפורק העברי (`ivrit-ai/whisper-large-v3-ct2`), לא large-v3
הגנרי. ההבדל בעברית תורנית אינו ניואנס: הגנרי מטלטל שמות ומונחים.
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODEL = os.environ.get("SHORTS_MODEL", "ivrit-ai/whisper-large-v3-ct2")
FALLBACK = "ivrit-ai/whisper-large-v3-turbo-ct2"
LANG = os.environ.get("SHORTS_LANG", "he")
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")


def prep_audio(src: Path, dst: Path):
    """16kHz מונו + סינון רחש + יישור עוצמה.

    יישור העוצמה (dynaudnorm) הוא מה שמציל קטעים שבהם הדובר מתרחק
    מהמיקרופון — בדיוק אלה שהמודל שוגה בהם. אין לו השפעה על הטיימינג,
    ולכן חותמות המילים נשארות ישימות על הווידאו המקורי.
    """
    subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-i", str(src),
                    "-vn", "-ac", "1", "-ar", "16000",
                    "-af", "highpass=f=70,dynaudnorm=f=200:g=12:p=0.9",
                    "-c:a", "pcm_s16le", str(dst)], check=True)
    probe = subprocess.run([FFPROBE, "-v", "quiet", "-print_format", "json",
                            "-show_format", str(dst)],
                           capture_output=True, text=True).stdout
    return float(json.loads(probe)["format"]["duration"])


def run_local(media, out_dir: Path, prompt: str):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        print("✗ faster-whisper לא מותקן. הרץ שוב את install.sh, או בחר Modal:")
        print("    shorts.sh setup --redo asr")
        return 3

    device, compute = "cpu", "int8"
    try:
        import torch
        if torch.cuda.is_available():
            device, compute = "cuda", "float16"
    except ImportError:
        pass
    print("מנוע: מקומי · %s/%s · %s" % (device, compute, MODEL))
    if device == "cpu":
        print("⚠️  בלי GPU זה איטי — כדקה עיבוד לכל דקת אודיו, לפעמים יותר.")

    model_id = MODEL
    try:
        model = WhisperModel(model_id, device=device, compute_type=compute)
    except Exception as e:  # noqa: BLE001
        print("%s נכשל (%s) — עובר ל-turbo" % (model_id, str(e)[:120]))
        model_id = FALLBACK
        model = WhisperModel(model_id, device=device, compute_type=compute)

    out_dir.mkdir(parents=True, exist_ok=True)
    for n, m in enumerate(media, 1):
        src = Path(m)
        stem = src.stem
        words_out = out_dir / ("%s_words.json" % stem)
        if words_out.exists():
            print("[%d/%d] %s — כבר תומלל, מדלג" % (n, len(media), stem))
            continue
        wav = out_dir / ("%s.16k.wav" % stem)
        dur = prep_audio(src, wav)
        print("[%d/%d] %s — %.1f שניות" % (n, len(media), stem, dur))
        t0 = time.time()

        # initial_prompt מכוון את המודל לרישום התורני. אין בו שמות של דוברים
        # בכוונה — הטיה לשם מסוים גורמת למודל "לשמוע" אותו גם כשלא נאמר.
        segments, _ = model.transcribe(
            str(wav),
            language=LANG,   # חובה מפורש — זיהוי השפה האוטומטי של הפורק העברי הוחלש באימון
            task="transcribe",
            beam_size=5, best_of=5, patience=1.0,
            temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
            compression_ratio_threshold=2.4,
            log_prob_threshold=-1.0,
            no_speech_threshold=0.6,
            condition_on_previous_text=False,  # בלעדיו whisper נכנס ללולאת חזרות על אודיו עם קאטים
            repetition_penalty=1.05,
            initial_prompt=prompt or "שיעור תורני. לשון תורנית, ציטוטי גמרא ומדרש.",
            word_timestamps=True,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=250),
        )

        words, segs = [], []
        for s in segments:
            segs.append({"start": round(s.start, 3), "end": round(s.end, 3),
                         "text": s.text.strip(),
                         "avg_logprob": round(s.avg_logprob, 4),
                         "no_speech_prob": round(s.no_speech_prob, 4)})
            for w in (s.words or []):
                words.append({"word": w.word, "start": round(w.start, 3),
                              "end": round(w.end, 3),
                              "prob": round(getattr(w, "probability", 0.0) or 0.0, 4)})

        words_out.write_text(json.dumps(
            {"source": str(src), "model": model_id, "words": words},
            ensure_ascii=False, indent=2), encoding="utf-8")
        (out_dir / ("%s.segments.json" % stem)).write_text(
            json.dumps(segs, ensure_ascii=False, indent=1), encoding="utf-8")
        (out_dir / ("%s.txt" % stem)).write_text(
            " ".join(s["text"] for s in segs).strip(), encoding="utf-8")

        weak = [s for s in segs if s["avg_logprob"] < -0.9 or s["no_speech_prob"] > 0.5]
        print("  ✓ %d מילים · %.1f דק' · %d מקטעים חלשים"
              % (len(words), (time.time() - t0) / 60, len(weak)))
        for s in weak[:10]:
            print("     %6.1fs  %s" % (s["start"], s["text"][:70]))
        try:
            wav.unlink()
        except OSError:
            pass
    return 0


def run_modal(media, out_dir: Path, extra):
    cmd = [sys.executable, str(HERE / "modal_asr.py"), "run",
           "--media", *[str(m) for m in media], "--out-dir", str(out_dir), *extra]
    return subprocess.run(cmd).returncode


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("run")
    p.add_argument("--media", nargs="+", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--prompt", default="")
    p.add_argument("--engine", default="", choices=["", "local", "modal", "modal-cpu"])
    p.add_argument("--fast", action="store_true",
                   help="מודל קטן/greedy, בלי חותמות מילה — לגילוי קטעים בלבד")
    a = ap.parse_args()

    engine = a.engine or os.environ.get("SHORTS_ASR", "local")
    out = Path(a.out_dir)
    if engine in ("modal", "modal-cpu"):
        extra = (["--fast"] if a.fast else []) + (["--cpu"] if engine == "modal-cpu" else [])
        return run_modal(a.media, out, extra)
    return run_local(a.media, out, a.prompt)


if __name__ == "__main__":
    raise SystemExit(main())
