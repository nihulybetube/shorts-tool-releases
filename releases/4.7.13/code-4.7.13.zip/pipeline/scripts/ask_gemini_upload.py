# -*- coding: utf-8 -*-
"""גרסה של ask_gemini_video.py למקור מקומי (לא יוטיוב, או יוטיוב שג'מיני
לא מצליח לקרוא ישירות — למשל סרטון לא רשום/לא ציבורי במלואו). מעלה קובץ
מקומי ל-Gemini Files API (upload רזומבילי) במקום להצביע על URL.

שימוש: python ask_gemini_upload.py <local_mp4> <guidelines_file> <output_txt>
"""
import json
import urllib.parse
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.request

MODEL = "gemini-flash-latest"


def load_api_key():
    key = os.environ.get("GEMINI_API_KEY")
    if key:
        return key
    for path in (os.path.join(os.path.expanduser("~"), "shorts", "secrets", "shorts.env"),):
        if os.path.exists(path):
            for line in open(path, encoding="utf-8"):
                if line.startswith("GEMINI_API_KEY="):
                    return line.strip().split("=", 1)[1].strip().strip("'\"")
    raise RuntimeError("GEMINI_API_KEY לא נמצא בסביבה")


def upload_file(path, api_key):
    size = os.path.getsize(path)
    mime = mimetypes.guess_type(path)[0] or "video/mp4"
    start_req = urllib.request.Request(
        f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={urllib.parse.quote(api_key, safe='')}",
        method="POST",
        headers={
            "X-Goog-Upload-Protocol": "resumable",
            "X-Goog-Upload-Command": "start",
            "X-Goog-Upload-Header-Content-Length": str(size),
            "X-Goog-Upload-Header-Content-Type": mime,
            "Content-Type": "application/json",
        },
        data=json.dumps({"file": {"display_name": os.path.basename(path)}}).encode(),
    )
    with urllib.request.urlopen(start_req, timeout=60) as resp:
        upload_url = resp.headers.get("X-Goog-Upload-URL")
    if not upload_url:
        raise RuntimeError("לא התקבל upload URL")

    with open(path, "rb") as f:
        data = f.read()
    up_req = urllib.request.Request(
        upload_url, method="POST", data=data,
        headers={
            "Content-Length": str(size),
            "X-Goog-Upload-Offset": "0",
            "X-Goog-Upload-Command": "upload, finalize",
        },
    )
    with urllib.request.urlopen(up_req, timeout=1800) as resp:
        info = json.loads(resp.read().decode())
    file_info = info["file"]
    uri = file_info["uri"]
    name = file_info["name"]

    for _ in range(120):
        state_req = urllib.request.Request(
            f"https://generativelanguage.googleapis.com/v1beta/{name}?key={urllib.parse.quote(api_key, safe='')}"
        )
        with urllib.request.urlopen(state_req, timeout=60) as resp:
            state_info = json.loads(resp.read().decode())
        state = state_info.get("state")
        if state == "ACTIVE":
            return uri, state_info.get("mimeType", mime)
        if state == "FAILED":
            raise RuntimeError(f"עיבוד הקובץ נכשל אצל Gemini: {state_info}")
        time.sleep(5)
    raise RuntimeError("timeout בהמתנה לעיבוד הקובץ אצל Gemini")


def ask(file_uri, mime_type, guidelines_text, api_key, model=MODEL, thinking_budget=32768):
    prompt = guidelines_text + "\n\nהסרטון לניתוח מצורף כקובץ."
    body = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"file_data": {"file_uri": file_uri, "mime_type": mime_type}},
            ]
        }],
        "generationConfig": {"thinkingConfig": {"thinkingBudget": thinking_budget}},
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={urllib.parse.quote(api_key, safe='')}"
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST"
    )
    RETRY_CODES = {429, 500, 502, 503, 504}
    last_err = None
    result = None
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            break
        except TimeoutError:
            last_err = 'timeout'
            if attempt < 4:
                time.sleep(5 * (2 ** attempt))
            continue
        except urllib.error.HTTPError as e:
            if e.code not in RETRY_CODES:
                raise
            last_err = e
            if attempt < 4:
                time.sleep(5 * (2 ** attempt))
    else:
        raise RuntimeError(f"Gemini לא זמין אחרי 5 ניסיונות: {last_err}")
    if "error" in result:
        raise RuntimeError(f"Gemini API error: {result['error']}")
    text = "".join(p.get("text", "") for p in result["candidates"][0]["content"]["parts"])
    usage = result.get("usageMetadata", {})
    video_tokens = next((d["tokenCount"] for d in usage.get("promptTokensDetails", []) if d["modality"] == "VIDEO"), 0)
    if video_tokens == 0:
        raise RuntimeError("אזהרה: 0 video tokens - ג'מיני כנראה לא עיבד את הווידאו")
    return text, video_tokens


if __name__ == "__main__":
    local_path, guidelines_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    api_key = load_api_key()
    guidelines_text = open(guidelines_path, encoding="utf-8").read()
    model = sys.argv[4] if len(sys.argv) > 4 else MODEL
    print("מעלה קובץ ל-Gemini Files API...")
    file_uri, mime_type = upload_file(local_path, api_key)
    print(f"הועלה: {file_uri}")
    text, video_tokens = ask(file_uri, mime_type, guidelines_text, api_key, model=model)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"video_tokens_processed={video_tokens}")
    print(f"saved -> {out_path}")
