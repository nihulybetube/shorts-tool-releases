# -*- coding: utf-8 -*-
"""ייצוא — סוף הצינור. מעביר את הקליפים המוכנים לתיקייה שלך במחשב.

    shorts.sh export <project>                 # ייצוא לתיקייה שנבחרה ב-setup
    shorts.sh export <project> --dry-run       # מה יקרה, בלי לעשות
    shorts.sh export <project> --to ~/somewhere
    shorts.sh export <project> --cleanup       # למחוק את תיקיית העבודה אחרי אימות

מה זה עושה, בסדר הזה:
0. משנה את שם תיקיית הקליפ ואת שמות הקבצים לכותרת — "clip1" לא אומר כלום
   כשיש שלוש תיקיות זו לצד זו.
1. מעתיק כל קליף לתיקייה משלו: <הרב>/<הסדרה>/<כותרת השורט>/ ובה רק `<כותרת   הרב>.mp4`
   ו«תיאור להעתקה.txt» (כרטיס 16, 22/10/2026). `--to "<הרב>/<הסדרה>"` — יחסית ל-~/Videos/Shorts או נתיב מלא;
   שם רב/סדרה כמעט זהה לתיקייה קיימת (מירכאות, שליט"א, הרה"ג, רווחים) נכנס לקיימת (shorts_layout.py).
   `--layout lesson` / `--into` = המבנה הישן (תיקייה לשיעור) — רק לשיעורים של התוכנה שעוד לא סודרו.
2. **מאמת שהקבצים באמת שם** — גודל בייט מול המקור, לא קוד יציאה.
3. כותב שורה ל-`logs/exports.jsonl` — תיעוד שנשאר גם אחרי שהחומר הועבר.
4. רק אם ביקשת `--cleanup`, ורק אחרי שהאימות עבר, מוחק את תיקיית העבודה.

🚨 אם שלב 1 או 2 נכשל — לא נמחק כלום, ומדווח. זה מכוון.
"""

import argparse
import json
import os
import re
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import shorts_layout as SL  # noqa: E402

DATA = Path(os.environ.get("SHORTS_DATA_DIR",
                           Path.home() / ".local" / "share" / "yeshiva-shorts"))
# SHORTS_EXPORT_LEDGER: לבדיקות בלבד — הבדיקה העצמית כתבה עד 22/10 שורות "הרב בדיקה" ליומן האמיתי
LEDGER = Path(os.environ.get("SHORTS_EXPORT_LEDGER") or DATA / "logs" / "exports.jsonl")


MAX_NAME_BYTES = 200


def sanitize_filename(title: str, max_len: int = 150) -> str:
    """כותרת → שם קובץ בטוח. שומר עברית ואימוג'י, מוריד רק תווים ששוברים
    מערכות קבצים (כולל של חלונות, כי הקבצים האלה מסתובבים בין מכונות)."""
    bad = '/\\:*?"<>|\n\r\t'
    # "|" אסור בשם קובץ בחלונות. המפריד ("שם | הרב") הופך לשלושה רווחים:
    # יוטיוב ממלא את הכותרת משם הקובץ, והמשתמש מקליד שם את ה-"|" בעצמו —
    # הרווח המשולש מסמן לו איפה. (22/9 נוסה U+FF5C שנראה כמו "|"; אחרי
    # העלאה ראשונה הוא לא אהב את התוצאה וביקש לחזור לרווח, 24/9/2026.)
    def _clean(s):
        s = "".join(c for c in s if c not in bad and ord(c) >= 32)
        return " ".join(s.split())
    out = "   ".join(p for p in (_clean(x) for x in title.split("|")) if p)
    out = out.rstrip(". ")           # חלונות פוסלת שם שנגמר בנקודה או ברווח
    out = out[:max_len].strip()
    # 31/10: ext4 limits a name to 255 BYTES and a Hebrew letter is 2 - 150 letters = 300 bytes made the rename fail (ENAMETOOLONG).
    # 200 leaves room for the " - גרסה ארוכה לטיקטוק" suffix, ".mp4" and ".part".
    while len(out.encode("utf-8")) > MAX_NAME_BYTES:
        out = out[:-1]
    return out.rstrip(". ").strip() or "video"


# שתי גרסאות לכל קליף: קצרה ליוטיוב שורטס, ארוכה לטיקטוק, ואם יש — עם מוזיקה.
VERSIONS = {
    "video": ("", "יוטיוב (גרסה קצרה)"),
    "video_long": (" - גרסה ארוכה לטיקטוק", "טיקטוק (גרסה ארוכה)"),
    # בלי סיומת בשם (24/9/2026): כל קליף יוצא עם מוזיקה, ויוטיוב ממלא את הכותרת
    # משם הקובץ — " - עם מוזיקת רקע" נכנס לכותרת והמשתמש מחק אותו בכל העלאה.
    "video_music": ("", "עם מוזיקת רקע"),
}

_CLIP_DIR = re.compile(r"^clip\d+$")

# סיומת ששמות ישנים (לפני 24/9) עוד נושאים — לזיהוי בלבד
_OLD_MUSIC_SUFFIX = " - עם מוזיקת רקע"


def has_music(video: Path) -> bool:
    """גרסה עם מוזיקה. אחרי 24/9 השם כבר לא מסגיר את זה, ולכן הסימן הוא
    ה-meta.json של הקליף (מפתח `music`, או שורת הקרדיט בתיאור); לפני השינוי
    — ה-stem המקורי או הסיומת הישנה."""
    if video.stem == "video_music" or _OLD_MUSIC_SUFFIX in video.stem:
        return True
    meta = video.parent / "meta.json"
    try:
        d = json.loads(meta.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return bool(d.get("music")) or "\nמוזיקה:" in (d.get("description") or "")


def stash_plain(project: Path, dry: bool):
    """קליף שיש לו גרסה עם מוזיקה — הגרסה בלעדיה לא נוסעת לתיקיית הפלט
    (בקשת המשתמש, 24/9/2026: "תמיד רק עם מוזיקה"). היא עוברת ל-work/plain/,
    כבסיס להחלפת מנגינה אם הוא לא אוהב את מה שנבחר (mix מחדש עליה, בלי
    לרנדר את הווידאו שוב). `work/` לא מיוצא ממילא."""
    for d in sorted(project.glob("shorts/*")):
        plain, music = d / "video.mp4", d / "video_music.mp4"
        if d.is_dir() and plain.exists() and music.exists():
            dst = project / "work" / "plain" / ("%s.mp4" % d.name.split("_")[0])
            print("  %s/video.mp4 → work/plain/%s (בסיס להחלפת מנגינה)" % (d.name, dst.name))
            if not dry:
                dst.parent.mkdir(parents=True, exist_ok=True)
                plain.rename(dst)

# 🚨 סוד לא יוצא מהמכונה, גם לא בטעות. המפתחות של המשתמש יושבים ב-
# ~/.config/yeshiva-shorts ולא אמורים להימצא בתיקיית פרויקט לעולם — אבל
# "לא אמור" הוא לא בקרה. עשר שורות שמונעות דליפה שקטה לתיקיית ייצוא
# מסונכרנת-לענן.
SECRETY = ("*.env", ".env", "*token*.json", "client_secret*.json",
           "*credentials*.json", "*.pem", "*.key", "*cookies*.txt")


def secret_scan(project: Path):
    hits = []
    for pat in SECRETY:
        hits += [p for p in project.rglob(pat) if p.is_file()]
    return hits


def collect(project: Path):
    """מה נחשב תוצר. וידאו הוא החובה; השאר נלווה.

    שם הקובץ הוא `video.mp4` טרי מהצריבה, **או** כבר שונה לכותרת בריצה
    קודמת שנקטעה אחרי השינוי. לכל תיקיית קליפ יש mp4 יחיד, לכן
    `shorts/*/*.mp4` תופס את שני המצבים בלי לדעת איזה מהם.
    """
    videos = sorted(project.glob("shorts/*/*.mp4"))
    if not videos:
        videos = sorted(project.glob("shorts/*.mp4"))
    return videos


def meta_for(video: Path, project: Path):
    for cand in (video.parent / "meta.json", project / "project.json"):
        if cand.exists():
            try:
                d = json.loads(cand.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                continue
            if cand.name == "meta.json":
                return d
            clips = d.get("clips") or d.get("shorts") or {}
            if isinstance(clips, dict) and video.parent.name in clips:
                return clips[video.parent.name]
    return {"title": video.parent.name}


def rename_clip_dirs(project: Path, dry: bool):
    """shorts/clip1 → shorts/clip1_<כותרת>.
    אידמפוטנטי: תיקייה ששמה כבר שונה לא נוגעים בה שוב (ריצה שנקטעה)."""
    for d in sorted(project.glob("shorts/*")):
        if not d.is_dir() or not _CLIP_DIR.match(d.name):
            continue
        title = ""
        meta = d / "meta.json"
        if meta.exists():
            try:
                title = json.loads(meta.read_text(encoding="utf-8")).get("title", "")
            except (ValueError, OSError):
                title = ""
        if not title:
            print("⚠️  אין meta.json/כותרת ל-%s — התיקייה נשארת בשמה" % d.name)
            continue
        # 🚨 מגבלת 260 התווים של חלונות (24/9/2026): הכותרת מופיעה בנתיב פעמיים —
        # בשם התיקייה ובשם הקובץ — ודרך \\wsl.localhost\...\<הרב>\<הסדרה>\ נתיב
        # אחד הגיע ל-263 וסייר הקבצים לא הצליח להעתיק אותו. שם התיקייה רק צריך
        # להיות מזוהה: בלי שם הרב (הוא כבר בתיקיית האב ובשם הקובץ), ועד 40 תווים.
        short = sanitize_filename(title.split("|")[0], 40)
        new = d.parent / ("%s_%s" % (d.name, short))
        if new != d and not new.exists():
            print("  %s → %s" % (d.name, new.name))
            if not dry:
                d.rename(new)


def rename_to_title(videos, project: Path, dry: bool):
    """שם הקובץ = הכותרת, לא 'video.mp4'. דורש meta.json (write_clip_meta.py,
    שלב 6). בלעדיו — משאיר את השם ומדפיס אזהרה, לא נכשל בשקט."""
    out = []
    for v in videos:
        title = meta_for(v, project).get("title")
        if not title:
            print("⚠️  אין כותרת עבור %s — משאיר %s" % (v.parent.name, v.name))
            out.append(v)
            continue
        suffix, _ = VERSIONS.get(v.stem, ("", ""))
        new = v.parent / (sanitize_filename(title) + suffix + v.suffix)
        if new != v and not new.exists():
            if not dry:
                v.rename(new)
            out.append(new)
        else:
            out.append(v)
    return out


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f%s" % (n, u)
        n /= 1024.0
    return "%.1fTB" % n


# מה נוסע לתיקיית הפלט. `source/` ו-`work/` נשארים מאחור בכוונה:
# `source/full_video.mp4` של שיעור בן שעה הוא מאות מגה עד גיגה, ותיקיית
# הפלט היא לרוב תיקיית מדיה מסונכרנת. הם נשארים בתיקיית העבודה עד
# `--cleanup`, ומי שבכל זאת רוצה אותם מעביר `--include-source`.
HEAVY_DIRS = ("source", "work")

# קבצים פנימיים שנשארים בתיקיית העבודה ולא מגיעים לתיקייה הסופית: בקשת
# המשתמש (14/10/2026) — שם יהיו רק הסרטון ו«תיאור להעתקה.txt».
INTERNAL_FILES = ("meta.json", "info.txt")


VIDEO_EXT = (".mp4", ".mov", ".m4v")


def wanted_files(project: Path, include_source: bool):
    # 🚨 רשימה של מה *כן* נכנס, לא של מה לא (21/10/2026): הבחירה האוטומטית הוסיפה תיקייה חדשה (pick/ —
    # אודיו של כל השיעור, wav-ים, תמלולים), וגם make_short.json / לעריכה/, וכולם עברו לתיקיית השורטס ולדרייב
    # כי לא הופיעו ברשימת הדילוג. הכלל שלו: שם יש רק הסרטון ו«תיאור להעתקה.txt» (נכתב בנפרד).
    for src in sorted(project.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(project)
        if include_source:
            if src.name not in INTERNAL_FILES:
                yield src, rel
            continue
        if rel.parts and rel.parts[0] == "shorts" and src.suffix.lower() in VIDEO_EXT:
            yield src, rel


def replace_into(project: Path, target: Path):
    """שמירה חוזרת מהחלון (21/10/2026): לאותה תיקייה בדיוק, מחליפה קבצים — לא "_1714" חדשה.
    מה שיש בתיקייה ולא שייך לשמירה הזאת (כותרת שהשתנתה → קובץ בשם אחר, קליף שוויתרו עליו) עובר
    לתיקיית העבודה (work/replaced_<זמן>/), לא נמחק. מחזיר (target, ok, bad, moved)."""
    wanted = {rel for _, rel in wanted_files(project, False)}
    keep_dirs = {rel.parts[1] for rel in wanted if len(rel.parts) > 2}
    moved = []
    park = project / "work" / ("replaced_%s" % time.strftime("%Y%m%d_%H%M%S"))
    sh = target / "shorts"
    if sh.is_dir():
        for d in sorted(sh.iterdir()):
            stale = [d] if (d.is_dir() and d.name not in keep_dirs) else \
                [f for f in d.iterdir() if f.is_file() and f.suffix.lower() in VIDEO_EXT
                 and (f.relative_to(target)) not in wanted] if d.is_dir() else []
            for s in stale:
                dst = park / s.relative_to(target)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(s), str(dst))
                moved.append(str(s.relative_to(target)))
    target.mkdir(parents=True, exist_ok=True)
    for src, rel in wanted_files(project, False):
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + ".part")
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
    bad = [str(rel) for src, rel in wanted_files(project, False)
           if not (target / rel).exists() or (target / rel).stat().st_size != src.stat().st_size]
    return target, not bad, bad, moved


def copy_verified(project: Path, dest: Path, dry: bool, include_source: bool):
    """העתקה ואז אימות גודל, קובץ מול קובץ.

    🚨 `copytree`/`copy2` שמסתיימים בלי חריגה אינם הוכחה שהקבצים שם:
    דיסק שהתמלא באמצע, תיקיית ענן שסונכרנה חלקית ונקודת עגינה שנעלמה —
    כולם מחזירים "הצלחה" ומשאירים קובץ קטוע. משווים גדלים, ורק אז
    מדווחים שהייצוא הצליח.
    """
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / project.name
    if dry:
        n = sum(1 for _ in wanted_files(project, include_source))
        print("[dry] %d קבצים → %s" % (n, target))
        return target, True, []
    if target.exists():
        target = dest / ("%s_%s" % (project.name, time.strftime("%H%M")))

    for src, rel in wanted_files(project, include_source):
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    bad = [str(rel) for src, rel in wanted_files(project, include_source)
           if not (target / rel).exists()
           or (target / rel).stat().st_size != src.stat().st_size]
    return target, not bad, bad


def copy_block(meta: dict):
    """הטקסט של «תיאור להעתקה.txt»: התיאור ובסופו האשטגים (ראו write_copy_blocks)."""
    if not meta.get("description"):
        return ""
    block = meta["description"].rstrip()
    tags = hashtags(meta.get("tags") or [])
    if tags:
        block += "\n\n" + " ".join(tags)
    return block + "\n"


def ledger_owned(project: Path):
    """{clipN: {תיקיות}} — לאן הפרויקט הזה כבר ייצא כל קליף במבנה החדש (מהיומן). ככה ייצוא חוזר של
    Claude (בלי מצב של התוכנה) חוזר לאותה תיקייה ולא פותח " (2)" ליד עצמו."""
    out = {}
    try:
        lines = LEDGER.read_text(encoding="utf-8").splitlines()
    except OSError:
        return out
    for ln in lines:
        try:
            e = json.loads(ln)
        except ValueError:
            continue
        if e.get("project") == project.name and isinstance(e.get("clips"), dict):
            for k, v in e["clips"].items():
                out.setdefault(k, set()).add(v)
    return out


def export_flat(project: Path, series_dir: Path, known: dict, dry: bool, root: Path, only=None):
    """המבנה החדש (כרטיס 16, 22/10/2026): כל שורט בתיקייה משלו בשם הכותרת, ישר בתוך תיקיית הסדרה —
    <הרב>/<הסדרה>/<כותרת>/<כותרת   הרב>.mp4 + «תיאור להעתקה.txt». בלי תיקיית שיעור, בלי shorts/, בלי clipN_.

    known = {clipN: תיקייה} — איפה הקליף נשמר בפעם הקודמת (מצב התוכנה). כותרת שהשתנתה → התיקייה הישנה
    *משנה שם* לחדשה (אותו דיסק), כך שאף פעם לא נשארים שני עותקים. קבצים שלא שייכים לשמירה הזאת
    (קובץ בשם הכותרת הישנה) עוברים לתיקיית העבודה (work/replaced_<זמן>/), לא נמחקים.
    מחזיר (ok, bad, dirs, moved) — dirs = {clipN: התיקייה}."""
    owned_log = ledger_owned(project)
    park = project / "work" / ("replaced_%s" % time.strftime("%Y%m%d_%H%M%S"))
    dirs, bad, moved, taken = {}, [], [], set()
    for d in sorted(project.glob("shorts/*")):
        if not d.is_dir():
            continue
        vids = sorted(f for f in d.iterdir() if f.is_file() and f.suffix.lower() in VIDEO_EXT
                      and not f.name.endswith(".part.mp4"))
        if not vids:
            continue
        cid = d.name.split("_")[0]
        if only and cid not in only:              # 28/10: "💾 שמור את הקליף הזה" — השאר לא נוגעים
            continue
        meta = meta_for(vids[0], project)
        title = meta.get("title") or vids[0].stem
        old = Path(known[cid]) if known.get(cid) else None
        owned = set(owned_log.get(cid, ())) | ({str(old)} if old else set())
        tgt = SL.short_dir(series_dir, title, vids[0].name, owned - taken)
        taken.add(str(tgt))
        dirs[cid] = str(tgt)
        print("  %s → %s/" % (cid, tgt.name))
        if dry:
            continue
        series_dir.mkdir(parents=True, exist_ok=True)
        if old and old.is_dir() and old != tgt and not tgt.exists():
            old.rename(tgt)                       # הכותרת השתנתה: אותה תיקייה, שם חדש
            moved.append("%s → %s" % (old.name, tgt.name))
            SL.prune_empty(old.parent, root)
        tgt.mkdir(parents=True, exist_ok=True)
        names = {v: SL.fit_file_name(tgt, v.name) for v in vids}       # 31/10: גם שם הקובץ מתקצר אם הנתיב ארוך מדי לחלונות
        want = set(names.values()) | {SL.DESC_FILE}
        for f in sorted(tgt.iterdir()):           # קובץ בשם הכותרת הישנה — לתיקיית העבודה
            if f.name not in want:
                dst = park / tgt.name / f.name
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), str(dst))
                moved.append("%s/%s" % (tgt.name, f.name))
        if old and old.is_dir() and old != tgt:   # לא הצליח לשנות שם (היעד כבר היה) — הישנה הצידה
            park.mkdir(parents=True, exist_ok=True)
            dst = park / ("old_" + old.name)
            shutil.move(str(old), str(dst))
            moved.append(old.name + "/")
            SL.prune_empty(old.parent, root)
        for v in vids:
            dst = tgt / names[v]
            tmp = dst.with_name(dst.name + ".part")
            shutil.copy2(v, tmp)
            os.replace(tmp, dst)
            if not dst.exists() or dst.stat().st_size != v.stat().st_size:
                bad.append(str(dst))
        block = copy_block(meta)
        if block:
            (tgt / SL.DESC_FILE).write_text(block, encoding="utf-8")
    return not bad, bad, dirs, moved


def write_readme(target: Path, project: Path, videos):
    """דף אחד קריא לבן אדם ליד הסרטונים — כותרת, תיאור ותגיות להעתקה.
    בלעדיו הקבצים מגיעים בלי הטקסט שצריך כדי להעלות אותם.

    קליף אחד = כותרת אחת, גם כשיש לו שלוש גרסאות קובץ. הגרסאות חולקות
    את אותה כותרת ואותו תיאור, וחזרה עליהם שלוש פעמים הופכת את הדף
    לרשימה שאי אפשר לסרוק."""
    lines = ["# %s" % project.name, ""]

    # 🚨 האזהרה יושבת בראש הדף ולא בסופו. מי שמעלה סורק את הדף מלמעלה,
    # מעתיק את הכותרת והתיאור, וסוגר — הערה בתחתית נקראת אחרי ההעלאה,
    # כלומר אחרי שהחשיפה המשפטית כבר קיימת.
    if any(has_music(v) for v in videos):
        lines += [
            "> ## ⚠️ חובה: שורת הקרדיט למוזיקה",
            "> ",
            "> בסרטונים שמסומנים כאן למטה יש מוזיקה ברישיון",
            "> Creative Commons שמחייב **קרדיט בתיאור הסרטון**.",
            "> ",
            "> שורת הקרדיט כבר נמצאת בתוך התיאור שכאן, בסוף. **העתק את",
            "> התיאור במלואו** — כולל השורה שמתחילה ב«מוזיקה:».",
            "> ",
            "> בלי השורה הזאת השימוש במוזיקה אינו חוקי, וגם אם אף אחד לא",
            "> יתלונן — אין על מה להישען אם כן. לגרסאות בלי מוזיקה זה לא נוגע.",
            "",
        ]

    seen = []
    for v in videos:
        m = meta_for(v, project)
        key = v.parent.name
        if key not in [k for k, _, _ in seen]:
            seen.append((key, m, [v]))
        else:
            for k, _mm, files in seen:
                if k == key:
                    files.append(v)
    for _key, m, files in seen:
        lines += ["## %s" % m.get("title", files[0].stem), ""]
        # בלי שורת "ההוק" (בקשת המשתמש, 29/9/2026): הוא לא מעלה אותה, וההוק הוא הפתיחה של הסרטון עצמו
        if m.get("description"):
            lines += ["### תיאור", m["description"], ""]
        if m.get("tags"):
            tags = m["tags"]
            lines += ["### תגיות",
                      ", ".join(tags) if isinstance(tags, list) else str(tags), ""]
        lines += ["### קבצים"]
        for f in files:
            note = "  ← **צריך את שורת הקרדיט**" if has_music(f) else ""
            lines += ["- `%s`%s" % (f.name, note)]
        lines += ["", "---", ""]
    (target / "להעלאה.md").write_text("\n".join(lines), encoding="utf-8")
    write_copy_blocks(target, project)


def hashtags(tags, limit=5):
    """תגיות → האשטגים. הסדרה/פרשה, הרב והישיבה קודם (יוטיוב מציג את
    שלושת הראשונים מעל הכותרת), ואחריהם נושאים עד limit."""
    tags = tags if isinstance(tags, list) else [t.strip() for t in str(tags).split(",")]
    first = [t for t in tags if t.startswith(("פרשת", "הרב", "ישיבת"))]
    rest = [t for t in tags if t not in first and t != "שיעור תורה"]
    out = []
    for t in first + rest:
        h = "#" + re.sub(r"[\s\-]+", "_", re.sub(r"['\"׳״]", "", t.strip()))
        if len(h) > 1 and h not in out:
            out.append(h)
    return out[:limit]


def write_copy_blocks(target: Path, project: Path):
    """קובץ «תיאור להעתקה.txt» ליד כל קליף: התיאור ובסופו האשטגים, בלי
    כותרות-ביניים — הוא פותח, Ctrl+A, מעתיק ומדביק לתיאור ביוטיוב.
    בקשת המשתמש (12/10/2026): הדבקה אחת במקום שתיים (תיאור + שדה תגיות);
    תגיות בתיאור לא עובדות כתגיות, אבל האשטגים כן.
    meta.json נקרא מתיקיית העבודה — לתיקייה הסופית הוא לא מועתק."""
    for pmf in sorted(project.glob("shorts/*/meta.json")):
        mf = target / pmf.relative_to(project)
        if not mf.parent.is_dir():
            continue
        m = json.loads(pmf.read_text(encoding="utf-8"))
        if not m.get("description"):
            continue
        block = m["description"].rstrip()
        tags = hashtags(m.get("tags") or [])
        if tags:
            block += "\n\n" + " ".join(tags)
        (mf.parent / "תיאור להעתקה.txt").write_text(block + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--to", default="", help="תיקיית יעד; ברירת מחדל — מה שנבחר ב-setup")
    ap.add_argument("--into", default="", help="התיקייה המדויקת של השיעור (שמירה חוזרת מחליפה בה, בלי _HHMM)")
    ap.add_argument("--known", default="",
                    help="JSON {clipN: תיקייה} — איפה כל קליף נשמר בפעם הקודמת (שמירה חוזרת מהתוכנה)")
    ap.add_argument("--layout", choices=("short", "lesson"), default="short",
                    help="short (ברירת מחדל, 22/10) = תיקייה לכל שורט; lesson = המבנה הישן, תיקייה לשיעור")
    ap.add_argument("--only", default="", help="clip1,clip2 — רק הקליפים האלה (מבנה תיקייה לכל שורט בלבד)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--include-source", action="store_true",
                    help="לייצא גם את הווידאו המקורי ואת קובצי העבודה (כבד; תמיד במבנה הישן)")
    ap.add_argument("--cleanup", action="store_true",
                    help="למחוק את תיקיית העבודה אחרי שהייצוא אומת")
    a = ap.parse_args()

    project = Path(os.path.expanduser(a.project)).resolve()
    if not project.is_dir():
        print("✗ אין תיקייה כזאת: %s" % project)
        return 2

    dest_raw = a.to or (str(Path(a.into).parent) if a.into else "") or os.environ.get("SHORTS_EXPORT_DIR", "")
    if not dest_raw:
        print("✗ לא הוגדרה תיקיית ייצוא. הרץ:  shorts.sh setup")
        return 2
    dest = Path(os.path.expanduser(dest_raw))
    root = Path(os.path.expanduser(os.environ.get("SHORTS_EXPORT_DIR") or SL.ROOT_DEFAULT))
    if not dest.is_absolute():                      # --to "הרב X/סדרה" — יחסית לתיקיית השורטס
        dest = root / dest
    flat = not a.into and not a.include_source and a.layout == "short"
    if flat:
        try:
            rel = dest.resolve().relative_to(root.resolve()).parts
        except ValueError:
            rel = None
        if rel is not None:
            if len(rel) < 2:
                print("✗ צריך יעד בצורה <הרב>/<הסדרה>, למשל:  --to \"%s/הרב X/שם הסדרה\"" % root)
                return 2
            # 1ב (22/10): רב/סדרה חדשים — שם נקי; שם כמעט זהה לתיקייה קיימת — נכנס אליה
            r, s = SL.resolve_names(root, rel[0], rel[1])
            if (r, s) != (rel[0], rel[1]):
                print("  שם התיקייה: %s/%s → %s/%s" % (rel[0], rel[1], r, s))
            dest = root.joinpath(r, s, *rel[2:])
        else:
            root = dest.parent.parent                # תיקיית בדיקה — מחוץ לשורטסים האמיתיים
    known = {}
    if a.known:
        try:
            known = json.loads(Path(a.known).read_text(encoding="utf-8")) or {}
        except (OSError, ValueError):
            known = {}

    leaks = secret_scan(project)
    if leaks:
        print("✗ נמצאו קבצים שנראים כמו סודות בתוך הפרויקט — לא מייצא:")
        for p in leaks:
            print("   %s" % p)
        return 3

    videos = collect(project)
    if not videos:
        print("✗ אין סרטונים ב-%s/shorts — אין מה לייצא." % project)
        return 2

    print("פרויקט: %s" % project.name)
    stash_plain(project, a.dry_run)
    rename_clip_dirs(project, a.dry_run)
    videos = collect(project) if not a.dry_run else videos
    videos = rename_to_title(videos, project, a.dry_run)
    total = sum(v.stat().st_size for v in videos if v.exists())
    if a.dry_run and not total:   # בהרצה יבשה השמות החדשים עוד לא קיימים
        total = sum(v.stat().st_size for v in collect(project))
    print("  %d סרטונים · %s" % (len(videos), human(total)))
    for v in videos:
        print("   • %s" % v.name)

    dirs = None
    if flat:
        ok, bad, dirs, moved = export_flat(project, dest, known, a.dry_run, root,
                                           set(x for x in a.only.split(",") if x) or None)
        target = dest
        for m in moved:
            print("  ↪ הוחלף/שונה שם (שום דבר לא נמחק): %s" % m)
    elif a.into and not a.dry_run:
        target, ok, bad, moved = replace_into(project, Path(os.path.expanduser(a.into)))
        for m in moved:
            print("  ↪ הוחלף (הישן עבר לתיקיית העבודה): %s" % m)
    else:
        target, ok, bad = copy_verified(project, dest, a.dry_run, a.include_source)
    if a.dry_run:
        print("[dry] היעד היה: %s" % target)
        return 0
    if not ok:
        print("✗ הייצוא לא אומת — %d קבצים חסרים או קטועים:" % len(bad))
        for b in bad[:10]:
            print("   %s" % b)
        print("  תיקיית העבודה לא נגעה בה. נסה שוב או בחר יעד אחר.")
        return 4

    # בלי «להעלאה.md» (בקשת המשתמש, 14/10/2026): בתיקייה הסופית רק הסרטון
    # ו«תיאור להעתקה.txt», שכבר כולל את שורת הקרדיט. write_readme נשאר לשימוש ידני.
    if not flat:
        write_copy_blocks(target, project)
    print("✓ יוצא ואומת: %s" % target)
    if dirs is not None:
        print("EXPORT_DIRS=%s" % json.dumps(dirs, ensure_ascii=False))
    if any(has_music(v) for v in videos):
        # התזכורת חוזרת בכל ייצוא ולא רק בראשון. מי שמייצא בפעם העשרים
        # הוא בדיוק מי ששכח, כי בפעם העשרים כבר לא קוראים את הדף.
        print("")
        print("⚠️  יש כאן גרסאות עם מוזיקה — הן דורשות שורת קרדיט בתיאור.")
        print("   השורה כבר בתוך «תיאור להעתקה.txt». העתק את התיאור במלואו.")
        print("   בלעדיה השימוש במוזיקה אינו חוקי.")

    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "project": project.name,
        "target": str(target),
        "videos": [v.name for v in videos],
        "bytes": total,
        "cleaned": bool(a.cleanup),
    }
    if dirs is not None:                 # המבנה החדש: איפה בדיוק כל קליף (לייצוא חוזר ולמחיקה לפי שיעור)
        entry.update(layout="short", clips=dirs)
    with LEDGER.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    if a.cleanup:
        shutil.rmtree(project)
        print("✓ תיקיית העבודה נמחקה (הייצוא אומת קודם).")
    else:
        print("  תיקיית העבודה נשארה: %s" % project)
        print("  למחוק אותה אחרי שבדקת:  shorts.sh export <project> --cleanup")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
