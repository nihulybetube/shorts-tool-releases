# -*- coding: utf-8 -*-
"""כרטיס קצר לכל שיעור בסדרה — כדי לבחור אילו שיעורים שווים שורטס, בלי לקרוא
את כל הסדרה ובלי שום מכסה.

🚨 למה זה קיים (בקשת המשתמש, 10-11/10/2026): הוא רוצה לשלוח **פלייליסט** ולקבל
דירוג של השיעורים החזקים. תמלול של 80 שיעורים הוא ~400,000 מילים — אי אפשר
לקרוא אותם בשיחה. הסקריפט קורא אותם במקומי ומדפיס ~200 מילים לשיעור: זה מה
שנכנס לשיחה. אין כאן שום מודל — רק חיפוש וספירה, ולכן זה חינם ומיידי
(נמדד: 0.37 שניות לשלושה שיעורים).

הזרימה המלאה:
  1. `yt-dlp --flat-playlist` → רשימת השיעורים.
  2. לכל שיעור: `yt-dlp --skip-download --write-auto-subs --sub-langs iw-orig`
     (~2.6 שניות לשיעור, בלי להוריד וידאו). אין כתוביות? להוריד **אודיו בלבד**
     (`-f 140`, ~20-40MB) ולתמלל ב-Modal (~$0.045 לשיעור) — ולשאול אותו קודם
     אם מדובר בסדרה גדולה.
  3. הסקריפט הזה → כרטיסים → אני קורא ומדרג.
  4. תמלול מלא נקרא רק ל-2-3 המועמדים הסופיים.

🚨 **בסדרה הדגש הוא תמצית הסדרה, לא הסיפורים המשעשעים** (הנחיה שלו, 10/10):
`CORE` הוא הסימן החשוב, `STORY`/`MASHAL` בונוס. בשיעור בודד — כרגיל.

⚠️ הכתוביות האוטומטיות גסות ("אלה תולדות נחמרו"), ולכן הכרטיס הוא **מפה ולא
פסק דין**: הוא אומר איפה לחפש, וההכרעה אחרי קריאת הטקסט המלא סביב אותן נקודות.

שימוש:  shorts.sh py series_cards.py <captions.srt> [<captions.srt> ...]
"""
import os
import re
import sys

STORY = ["פעם", "סיפר", "סיפור", "מעשה ב", "אני זוכר", "היה לי", "שאלו אותי", "ניגש אליי"]
MASHAL = ["משל", "זה כמו", "דוגמה", "תארו לעצמכם", "נגיד ש"]
CORE = ["העיקר", "היסוד", "כל העניין", "זה מה ש", "הנקודה", "בעצם", "זאת אומרת ש", "המגמה"]


def parse(path):
    """SRT → [(שניות, טקסט)], בלי כפילויות של שורות גוללות"""
    out = []
    for block in open(path, encoding="utf-8", errors="replace").read().split("\n\n"):
        lines = [l for l in block.splitlines() if l.strip()]
        if len(lines) < 2:
            continue
        m = re.search(r"(\d+):(\d+):(\d+)", lines[1] if "-->" in lines[1] else lines[0])
        if not m:
            continue
        t = int(m[1]) * 3600 + int(m[2]) * 60 + int(m[3])
        txt = " ".join(lines[2:] if "-->" in lines[1] else lines[1:]).strip()
        if txt and (not out or txt != out[-1][1]):
            out.append((t, txt))
    return out


def around(cues, i, words=28):
    s = " ".join(c[1] for c in cues[max(0, i - 1):i + 3])
    return " ".join(s.split()[:words])


def card(path, name):
    cues = parse(path)
    if not cues:
        return f"## {name}\n   (אין כתוביות קריאות)\n"
    text = " ".join(c[1] for c in cues)
    dur = cues[-1][0]
    opening = " ".join(" ".join(c[1] for c in cues if c[0] < 100).split()[:45])
    hits = {}
    for label, keys in (("ניסוח-עיקרון", CORE), ("סיפורים", STORY), ("משלים", MASHAL)):
        hits[label] = [(t, around(cues, i)) for i, (t, txt) in enumerate(cues)
                       if any(k in txt for k in keys)]
    out = [f"## {name}",
           f"   אורך {dur//60}:{dur%60:02d} · {len(text.split())} מילים · "
           + " · ".join(f"{k}:{len(v)}" for k, v in hits.items()),
           f"   פתיחה: {opening}"]
    for label, found in hits.items():
        for t, q in found[:2]:
            out.append(f"   [{label} {t//60:02d}:{t%60:02d}] {q}")
    # 21/10: גם הסיום — במסקנה הרב אומר בדרך כלל את עיקר השיעור (חשוב לדירוג של כל הסדרה בבקשה אחת)
    tail = " ".join(" ".join(c[1] for c in cues if c[0] > dur - 90).split()[-35:])
    if tail:
        out.append(f"   סיום: {tail}")
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    for p in sys.argv[1:]:
        # שם השיעור: תיקיית הפרויקט/הסדרה שמעל קובץ הכתוביות
        print(card(p, os.path.basename(os.path.dirname(os.path.dirname(p)))))
