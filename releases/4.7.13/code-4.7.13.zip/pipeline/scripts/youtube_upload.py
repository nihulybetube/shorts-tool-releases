# -*- coding: utf-8 -*-
"""העלאת שורטס ליוטיוב מתוך project.json.

    python youtube_upload.py auth                       חיבור חד-פעמי (פותח דפדפן)
    python youtube_upload.py status                     מי מחובר, כמה זמן נשאר להרשאה
    python youtube_upload.py reauth                     מוחק את הטוקן ומאשר מחדש
    python youtube_upload.py list                       מה מוכן ומה כבר עלה
    python youtube_upload.py upload <project> <clip> [--music] [--privacy unlisted]
    python youtube_upload.py upload-all <project> [--music] [--limit 5]

--------------------------------------------------------------------------
שתי מגבלות אמיתיות שחייבים להכיר לפני שמתחילים
--------------------------------------------------------------------------
1. **פרויקט API שלא עבר audit מעלה רק כפרטי.** מאז 28.07.2020 כל סרטון
   שמועלה דרך `videos.insert` מפרויקט לא מאומת ננעל ל-private, ו-YouTube
   מתעלם מ-`privacyStatus` שביקשת. זה *לא* באג. אפשר לפרסם ידנית מ-Studio
   אחרי ההעלאה, או לעבור audit מול גוגל. ברירת המחדל כאן היא `private`
   בכוונה - כדי שמה שרואים יהיה מה שקורה.

2. **מכסה: 10,000 יחידות ליום, והעלאה עולה 1,600.** כלומר **6 העלאות ביום**
   ותו לא. הסקריפט סופר ועוצר לפני שנחטף 403 באמצע קובץ.
--------------------------------------------------------------------------
"""
import argparse
import http.client
import json
import os
import socket
import ssl
import sys
import time
from datetime import datetime, date, timedelta

# הנתיבים מגיעים מ-shorts.sh. ברירת המחדל היא תיקיית ההגדרות של
# המשתמש — שם יושב ה-client_secret שלו, ולשם נכתב הטוקן שיתקבל.
ROOT = os.environ.get("SHORTS_ROOT",
                      os.path.expanduser("~/.local/share/yeshiva-shorts"))
PIPE = os.environ.get("SHORTS_SECRETS",
                      os.path.expanduser("~/.config/yeshiva-shorts"))
CLIENT_SECRET = os.path.join(PIPE, "client_secret.json")
TOKEN = os.path.join(PIPE, ".youtube_token.json")
TOKEN_GRANTED = os.path.join(PIPE, ".youtube_token_granted.json")
QUOTA_LOG = os.path.join(PIPE, ".youtube_quota.json")

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
# לעדכון מטא-דאטה של סרטון קיים (videos.update) חייבים את ה-scope הרחב.
SCOPES_RW = SCOPES + ["https://www.googleapis.com/auth/youtube"]
COST_PER_UPLOAD = 1600
COST_PER_UPDATE = 50
DAILY_QUOTA = 10000
CATEGORY_EDUCATION = "27"

# ניתוקים שקורים באמצע העלאה ואינם שגיאת API - שווה לנסות שוב את הצ'אנק.
RETRIABLE_ERRORS = (ConnectionResetError, ConnectionAbortedError, BrokenPipeError,
                    TimeoutError, ssl.SSLError, socket.timeout, socket.gaierror,
                    http.client.HTTPException, OSError)
MAX_CHUNK_RETRIES = 8
# באפליקציית OAuth במצב Testing גוגל מנפיקה refresh token שפג אחרי 7 ימים.
# אחרי Publish App (Production) המגבלה נעלמת — ואז _days_left מחזיר None.
TESTING_TOKEN_DAYS = 7
# האפליקציה פורסמה ל-Production ב-18.08.2026, ולכן אין תפוגה.
# החזר ל-False רק אם היא הוחזרה למצב Testing.
APP_IN_PRODUCTION = True


def _svc(scopes=None):
    """מחזיר client. `scopes` ברירת מחדל = העלאה בלבד.

    `videos.update` (פקודת sync) **לא** עובד עם youtube.upload - גוגל דורשת
    לשם כך את ה-scope הרחב `youtube`. לכן sync מבקש SCOPES_RW, ואם הטוקן
    השמור צר מדי הוא מפעיל consent מחדש.
    """
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    scopes = scopes or SCOPES
    creds = None
    if os.path.exists(TOKEN):
        # חייבים להשוות מול מה שגוגל *נתנה* (מה ששמור בקובץ), לא מול
        # creds.scopes - `from_authorized_user_file` ממלא שם את מה שביקשנו.
        # בלי זה מנסים לרענן טוקן צר עם scope רחב, וגוגל מחזירה
        # invalid_scope במקום לפתוח consent חדש.
        granted = set(json.load(open(TOKEN, encoding="utf-8")).get("scopes") or [])
        if set(scopes) <= granted:
            try:
                creds = Credentials.from_authorized_user_file(TOKEN, scopes)
            except ValueError:
                creds = None
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(CLIENT_SECRET):
                sys.exit(f"חסר {CLIENT_SECRET} — ראה את הוראות ההקמה ב-README.")
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, scopes)
            creds = flow.run_local_server(port=0, prompt="consent")
            json.dump({"granted_at": datetime.now().isoformat(timespec="seconds")},
                      open(TOKEN_GRANTED, "w", encoding="utf-8"))
        with open(TOKEN, "w", encoding="utf-8") as f:
            f.write(creds.to_json())
    return build("youtube", "v3", credentials=creds)


def _quota_day():
    """המכסה של יוטיוב מתאפסת בחצות שעון פסיפיק, לא בחצות המקומי.
    ספירה לפי התאריך המקומי חסמה העלאות אחרי איפוס אמיתי ושחררה לפניו —
    הפוך מהמציאות (בישראל: 10:00 בבוקר). (מהסקיל המקורי, 3.4.0)"""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("America/Los_Angeles")).date().isoformat()
    except Exception:
        # בלי מסד אזורי זמן (חלק מהתקנות פייתון): UTC-8 קבוע. בקיץ טועה בשעה, לא ביום.
        from datetime import timezone
        return datetime.now(timezone(timedelta(hours=-8))).date().isoformat()


def _quota_used_today():
    if not os.path.exists(QUOTA_LOG):
        return 0
    d = json.load(open(QUOTA_LOG, encoding="utf-8"))
    return d.get("units", 0) if d.get("date") == _quota_day() else 0


def _quota_add(units):
    json.dump({"date": _quota_day(), "units": _quota_used_today() + units},
              open(QUOTA_LOG, "w", encoding="utf-8"))


def _proj_path(pid):
    return os.path.join(ROOT, "projects", pid, "project.json")


def _load(pid):
    return json.load(open(_proj_path(pid), encoding="utf-8"))


def _save(pid, meta):
    json.dump(meta, open(_proj_path(pid), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)


def _granted_at():
    """מתי ניתנה ההסכמה בפועל. לא זהה ל-mtime של הטוקן, שמתעדכן בכל רענון."""
    if not os.path.exists(TOKEN_GRANTED):
        return None
    try:
        raw = json.load(open(TOKEN_GRANTED, encoding="utf-8"))["granted_at"]
        return datetime.fromisoformat(raw)
    except (ValueError, KeyError, json.JSONDecodeError):
        return None


def _days_left():
    """ימים עד שה-refresh token מת. None אם אין תפוגה או שלא ידוע."""
    if APP_IN_PRODUCTION:
        return None
    g = _granted_at()
    if g is None:
        return None
    used = (datetime.now() - g).total_seconds() / 86400
    return TESTING_TOKEN_DAYS - used


def _warn_if_expiring():
    left = _days_left()
    if left is not None and left < 2:
        if left <= 0:
            print("! ההרשאה בת 7 הימים כנראה פגה. אם ההעלאה תיפול — הרץ reauth.\n")
        else:
            print(f"! נותרו כ-{left:.1f} ימים להרשאה (מצב Testing). "
                  "שקול Publish App או reauth.\n")


def _has_readwrite(tok):
    """האם ההסכמה מאחורי ה-refresh token כוללת את ה-scope הרחב.

    בודקים בפועל מול גוגל, כי אין דרך לדעת את זה מהקובץ. בקשת access
    token בהיקף שלא אושר נכשלת ב-invalid_scope בלי לפתוח דפדפן.
    """
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        c = Credentials(None, refresh_token=tok["refresh_token"],
                        token_uri=tok["token_uri"], client_id=tok["client_id"],
                        client_secret=tok["client_secret"],
                        scopes=["https://www.googleapis.com/auth/youtube"])
        c.refresh(Request())
        return True
    except Exception:
        return False


def cmd_status(_):
    if not os.path.exists(TOKEN):
        print("לא מחובר. הרץ:  python youtube_upload.py auth")
        return
    d = json.load(open(TOKEN, encoding="utf-8"))
    print("חשבון:      ", d.get("account") or "(לא נמסר)")
    # 🚨 השדה `scopes` בקובץ הטוקן הוא מה ש**ביקשנו** בריצה האחרונה, לא מה
    # שגוגל אישרה — כל `_svc()` דורס אותו. ב-25/8/2026 הוא הראה גם את
    # ה-scope הרחב אחרי שהריצה הקודמת ביקשה אותו, ואז ירד לצר אחרי העלאה.
    # מה שקובע הוא ההסכמה שמאחורי ה-refresh token, וזו נבדקת רק בפועל.
    print("scopes אחרונים שביקשנו:", ", ".join(d.get("scopes", [])))
    print("קריאת מטא-דאטה (youtube):", "יש" if _has_readwrite(d) else "אין — רק העלאה")
    print("token קובץ: ", TOKEN)

    g = _granted_at()
    if APP_IN_PRODUCTION:
        print("\nהאפליקציה ב-Production — לטוקן אין תפוגה קצובה.")
        if g is not None:
            print("הסכמה ניתנה: ", g.strftime("%d.%m.%Y %H:%M"))
    elif g is None:
        print("\nמתי ניתנה ההסכמה: לא ידוע — הטוקן נוצר לפני שהמעקב הזה נוסף.")
        print("הרץ reauth פעם אחת כדי להתחיל לעקוב.")
    else:
        left = _days_left()
        print("\nהסכמה ניתנה: ", g.strftime("%d.%m.%Y %H:%M"))
        if left > 0:
            print(f"במצב Testing תפוג ב: {(g + timedelta(days=TESTING_TOKEN_DAYS)).strftime('%d.%m.%Y')}"
                  f"  (עוד {left:.1f} ימים)")
        else:
            print("במצב Testing כבר הייתה אמורה לפוג.")
        print("אם האפליקציה כבר ב-Production — התאריך הזה לא רלוונטי, הטוקן מחזיק.")

    used = _quota_used_today()
    print(f"\nמכסה היום:   {used}/{DAILY_QUOTA} "
          f"({(DAILY_QUOTA - used) // COST_PER_UPLOAD} העלאות נותרו)")


def cmd_reauth(_):
    for f in (TOKEN, TOKEN_GRANTED):
        if os.path.exists(f):
            os.remove(f)
    print("הטוקן הישן נמחק, פותח דפדפן לאישור מחדש...")
    _svc()
    print("מחובר מחדש. הטוקן נשמר ב-", TOKEN)


def cmd_auth(_):
    _svc()
    print("מחובר. הטוקן נשמר ב-", TOKEN)
    print("שים לב: אם אפליקציית ה-OAuth במצב Testing, הטוקן פג אחרי 7 ימים")
    print("וצריך להריץ את זה שוב. 'status' מראה כמה זמן נשאר.")


def cmd_list(_):
    used = _quota_used_today()
    print(f"מכסה שנוצלה היום: {used}/{DAILY_QUOTA} "
          f"({(DAILY_QUOTA - used) // COST_PER_UPLOAD} העלאות נותרו)\n")
    for pid in sorted(os.listdir(os.path.join(ROOT, "projects"))):
        p = _proj_path(pid)
        if not os.path.exists(p):
            continue
        meta = json.load(open(p, encoding="utf-8"))
        print(pid)
        for s in meta["shorts"]:
            yid = s.get("youtube_video_id")
            state = f"עלה · {yid}" if yid else s.get("status", "draft")
            mus = "  [יש גרסת מוזיקה]" if s.get("music") else ""
            print(f"   {s['id']:8} {state:28} {s['youtube']['title'][:52]}{mus}")


def _has_music_credit(description):
    """האם התיאור נושא ייחוס למוזיקה.

    מחפש את סימני הרישיון ולא מחרוזת אחת קשיחה: המשתמש רשאי לנסח
    מחדש, לתרגם או להוסיף טראק משלו, וגם אז הייחוס תקף. מה שלא תקף
    הוא תיאור שאין בו שום זכר לרישיון או ליוצר."""
    d = (description or "").lower()
    return any(k in d for k in ("creativecommons.org", "creative commons", "incompetech",
                                "cc by", "מוזיקה:"))


def upload_one(svc, pid, meta, s, use_music, privacy):
    from googleapiclient.http import MediaFileUpload

    sd = os.path.join(ROOT, "projects", pid, "shorts", s["id"])
    name = "video_music.mp4" if use_music else "video.mp4"
    path = os.path.join(sd, name)
    if not os.path.exists(path):
        print(f"   ! חסר {name}, מדלג")
        return None

    yt = s["youtube"]

    # 🚨 שער, לא תזכורת. העלאה אוטומטית היא המסלול היחיד שבו אף אדם לא
    # קורא את התיאור לפני הפרסום — ולכן היא המקום היחיד שבו הפרת רישיון
    # יכולה לצאת לאוויר בלי שאיש ראה אותה. גרסה עם מוזיקה שאיבדה את
    # שורת הקרדיט נעצרת כאן ולא מועלית.
    if use_music and not _has_music_credit(yt.get("description", "")):
        print("   ✗ %s — בתיאור אין שורת קרדיט למוזיקה. לא מעלה." % s["id"])
        print("     הרישיון (CC BY) מחייב אותה. `music_library.py credits` מדפיס")
        print("     את השורה; להוסיף לתיאור ולהריץ שוב.")
        return None

    body = {
        "snippet": {
            "title": yt["title"][:100],
            "description": yt["description"][:5000],
            "tags": yt.get("tags", [])[:30],
            "categoryId": CATEGORY_EDUCATION,
            "defaultLanguage": "he",
            "defaultAudioLanguage": "he",
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        },
    }
    # צ'אנק של 4MB, לא 8: ברשת ביתית החיבור נסגר באמצע צ'אנק גדול
    # (WinError 10054) ואז כל הצ'אנק נזרק ומועלה שוב.
    media = MediaFileUpload(path, chunksize=4 * 1024 * 1024, resumable=True,
                            mimetype="video/mp4")
    req = svc.videos().insert(part="snippet,status", body=body, media_body=media)

    resp = None
    fails = 0
    while resp is None:
        try:
            # num_retries מטפל ב-5xx/429 בתוך הספרייה; ה-except שמסביב הוא
            # לניתוקי TCP/SSL, שאותם הספרייה לא תופסת ומפילה את הריצה.
            status, resp = req.next_chunk(num_retries=5)
            fails = 0
        except RETRIABLE_ERRORS as e:
            fails += 1
            if fails > MAX_CHUNK_RETRIES:
                raise
            wait = min(2 ** fails, 30)
            print(f"\r   {s['id']}: ניתוק ({type(e).__name__}) — "
                  f"ניסיון {fails}/{MAX_CHUNK_RETRIES} בעוד {wait}s", flush=True)
            time.sleep(wait)
            continue
        if status:
            print(f"\r   {s['id']}: {int(status.progress() * 100)}%", end="", flush=True)
    _quota_add(COST_PER_UPLOAD)
    vid = resp["id"]
    print(f"\r   {s['id']}: הועלה · https://youtu.be/{vid}")

    s["youtube_video_id"] = vid
    s["uploaded_at"] = datetime.now().isoformat(timespec="seconds")
    s["uploaded_version"] = "music" if use_music else "clean"
    s["status"] = "uploaded"
    return vid


def cmd_upload(a):
    _warn_if_expiring()
    meta = _load(a.project)
    by = {s["id"]: s for s in meta["shorts"]}
    if a.clip not in by:
        sys.exit(f"אין קליפ {a.clip} ב-{a.project}")
    if _quota_used_today() + COST_PER_UPLOAD > DAILY_QUOTA:
        sys.exit("המכסה היומית נגמרה. נסה מחר.")
    svc = _svc()
    upload_one(svc, a.project, meta, by[a.clip], a.music, a.privacy)
    _save(a.project, meta)


def cmd_sync(a):
    """דוחף כותרת/תיאור/תגיות מ-project.json לסרטונים שכבר עלו.

    שימושי כשמתגלה טעות במטא-דאטה אחרי ההעלאה (למשל ייחוס דובר שגוי).
    **videos.update מחליף את כל ה-snippet**, ולכן שולחים אותו שלם - כולל
    categoryId ושפה, אחרת יוטיוב מאפס את מה שלא נשלח.
    """
    meta = _load(a.project)
    todo = [s for s in meta["shorts"] if s.get("youtube_video_id")]
    if a.clips:
        todo = [s for s in todo if s["id"] in a.clips]
    if not todo:
        sys.exit("אין סרטונים שעלו שמתאימים לבקשה.")

    cost = COST_PER_UPDATE * len(todo)
    if _quota_used_today() + cost > DAILY_QUOTA:
        sys.exit("המכסה היומית לא מספיקה לעדכון.")

    print(f"מעדכן {len(todo)} סרטונים ({cost} יחידות מכסה).")
    print("אם זו הפעם הראשונה - ייפתח דפדפן לאישור הרשאת עריכה.\n")
    svc = _svc(SCOPES_RW)
    try:
        for s in todo:
            yt = s["youtube"]
            body = {
                "id": s["youtube_video_id"],
                "snippet": {
                    "title": yt["title"][:100],
                    "description": yt["description"][:5000],
                    "tags": yt.get("tags", [])[:30],
                    "categoryId": CATEGORY_EDUCATION,
                    "defaultLanguage": "he",
                    "defaultAudioLanguage": "he",
                },
            }
            svc.videos().update(part="snippet", body=body).execute()
            _quota_add(COST_PER_UPDATE)
            s["youtube_synced"] = True
            s["synced_at"] = datetime.now().isoformat(timespec="seconds")
            print(f"   {s['id']}: עודכן · https://youtu.be/{s['youtube_video_id']}")
    finally:
        _save(a.project, meta)


def cmd_upload_all(a):
    _warn_if_expiring()
    meta = _load(a.project)
    todo = [s for s in meta["shorts"] if not s.get("youtube_video_id")]
    room = (DAILY_QUOTA - _quota_used_today()) // COST_PER_UPLOAD
    n = min(len(todo), room, a.limit)
    if n <= 0:
        sys.exit("אין מה להעלות, או שהמכסה היומית נגמרה.")
    print(f"מעלה {n} מתוך {len(todo)} (מקום במכסה: {room})")
    svc = _svc()
    try:
        for s in todo[:n]:
            upload_one(svc, a.project, meta, s, a.music, a.privacy)
    finally:
        _save(a.project, meta)      # שומר גם אם נפלנו באמצע


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("auth").set_defaults(fn=cmd_auth)
    sub.add_parser("reauth").set_defaults(fn=cmd_reauth)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    sub.add_parser("list").set_defaults(fn=cmd_list)

    for name, fn in (("upload", cmd_upload), ("upload-all", cmd_upload_all)):
        p = sub.add_parser(name)
        p.add_argument("project")
        if name == "upload":
            p.add_argument("clip")
        else:
            p.add_argument("--limit", type=int, default=6)
        p.add_argument("--music", action="store_true", help="להעלות את גרסת המוזיקה")
        p.add_argument("--privacy", default="private",
                       choices=["private", "unlisted", "public"])
        p.set_defaults(fn=fn)

    ps = sub.add_parser("sync", help="דוחף מטא-דאטה מתוקן לסרטונים שכבר עלו")
    ps.add_argument("project")
    ps.add_argument("clips", nargs="*", help="ברירת מחדל: כל מה שעלה")
    ps.set_defaults(fn=cmd_sync)

    args = ap.parse_args()
    args.fn(args)
