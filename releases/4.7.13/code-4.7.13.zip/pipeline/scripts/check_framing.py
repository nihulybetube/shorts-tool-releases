# -*- coding: utf-8 -*-
"""שער מיסגור — מודד איפה הפנים של הדובר יושבות בפריט האנכי הסופי.

נולד מתלונה אמיתית: *"סדר גם שהדובר יופיע במרכז הפריים לאורך
כל הסרטון."* עד עכשיו המיסגור נבדק בעין על פריים אחד או שניים — וזה בדיוק
מה שמפספס דובר שזז באמצע. כאן מודדים את **כל** הקליף.

    python check_framing.py <video> [--tol 0.20] [--min-ok 0.90]

`--tol` — כמה מותר לפנים לסטות ממרכז הפריים, כשבר מרוחב הפריים.
0.20 על 1080 = 216 פיקסלים לכל צד, כשהראש עצמו רחב ~350 — כלומר הוא עדיין
חוצה את מרכז הפריים. סף הדוק יותר היה מחייב פאן מהיר שרודף אחרי הדובר
ונראה גרוע יותר מסטייה קטנה. יוצא בקוד 1 אם פחות מ-`--min-ok` מהדגימות
בטווח.
"""
import argparse
import sys

import numpy as np

import face_track as FT


def measure(path, fps=2.0):
    times, centers, scores, heights = FT.detect_centers(path, fps)
    centers = FT._reject_outliers(centers, heights)
    ok = ~np.isnan(centers)
    return times, centers, ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--tol", type=float, default=0.25)
    ap.add_argument("--min-ok", type=float, default=0.80)
    ap.add_argument("--far", type=float, default=0.30,
                    help="סטייה שנחשבת 'ממש מחוץ למרכז'")
    ap.add_argument("--max-far-run", type=float, default=2.5,
                    help="כמה שניות רצופות מותר להיות מעבר ל---far")
    ap.add_argument("--side", type=float, default=0.12,
                    help="סטייה לצד אחד שנחשבת 'יושב בצד' (אזהרה בלבד)")
    ap.add_argument("--max-side-run", type=float, default=3.0)
    ap.add_argument("--max-bias", type=float, default=0.06,
                    help="הטיה חציונית לצד אחד שמזהירים עליה")
    a = ap.parse_args()

    times, centers, ok = measure(a.video)
    if ok.sum() == 0:
        print("❌ לא זוהו פנים בכלל — אי אפשר לאמת מיסגור")
        return 1

    dev = np.abs(centers[ok] - 0.5)
    inside = dev <= a.tol
    ratio = inside.mean()
    worst_i = int(np.argmax(dev))
    worst_t = times[ok][worst_i]

    print("מיסגור: הפנים בתוך ±%.0f%% מהמרכז ב-%.0f%% מהדגימות · "
          "סטייה ממוצעת %.1f%% · הגרועה ביותר %.1f%% בשנייה %.1f"
          % (a.tol * 100, ratio * 100, dev.mean() * 100,
             dev[worst_i] * 100, worst_t))

    bad_t = times[ok][~inside]
    if len(bad_t):
        # מקבצים לרצפים כדי שלא יודפסו 40 שורות על אותו אירוע
        runs, cur = [], [bad_t[0], bad_t[0]]
        for t in bad_t[1:]:
            if t - cur[1] <= 1.01:
                cur[1] = t
            else:
                runs.append(cur)
                cur = [t, t]
        runs.append(cur)
        for r in runs:
            print("   מחוץ לטווח %5.1f–%5.1f" % (r[0], r[1]))

    # 🚨 הרצף חשוב יותר מהאחוז. מאז שהמצלמה עומדת רוב הזמן (ראה
    # `face_track.virtual_camera`) יש רגעי רכינה קצרים שבהם הדובר יוצא
    # מהמרכז וחוזר — וזה בסדר. מה שאסור הוא **להישאר** שם.
    far = dev > a.far
    tt = times[ok]
    runs_far, cur = [], None
    for k, m in enumerate(far):
        if m and cur is None:
            cur = tt[k]
        elif not m and cur is not None:
            runs_far.append((cur, tt[k]))
            cur = None
    if cur is not None:
        runs_far.append((cur, tt[-1]))
    worst_run = max((b - a_ for a_, b in runs_far), default=0.0)
    print("מעבר ל-%.0f%%: %.1f שניות בסך הכל · הרצף הארוך ביותר %.1f שניות"
          % (a.far * 100, sum(b - a_ for a_, b in runs_far), worst_run))

    # 21/10/2026 — הערה אחרי השיעור הראשון בתוכנה: *"הרב בתוך הפריים אבל לא במרכז"*. הקליפים
    # עברו את השער (100% בתוך ±25%), כי השער שאל רק "האם הוא בפנים". כאן שואלים גם "האם הוא
    # יושב בצד": רצף ארוך באותו צד מעבר ל---side, או הטיה ממוצעת לצד אחד. אזהרה (קוד 2), לא כישלון.
    sgn = centers[ok] - 0.5
    side_run, cur_run, cur_sign = 0.0, 0, 0
    for v in sgn:
        s = int(v > a.side) - int(v < -a.side)
        cur_run = cur_run + 1 if (s and s == cur_sign) else (1 if s else 0)
        cur_sign = s
        side_run = max(side_run, cur_run / 2.0)
    bias = float(np.median(sgn))
    warn = []
    if side_run > a.max_side_run:
        warn.append("הרב יושב בצד (מעבר ל-%.0f%%) %.1f שניות רצופות" % (a.side * 100, side_run))
    if abs(bias) > a.max_bias:
        warn.append("רוב הזמן הוא %.0f%% %s מהמרכז" % (abs(bias) * 100, "ימינה" if bias > 0 else "שמאלה"))

    fail = []
    if ratio < a.min_ok:
        fail.append("רק %.0f%% מהדגימות בתוך ±%.0f%%" % (ratio * 100, a.tol * 100))
    if worst_run > a.max_far_run:
        fail.append("הדובר %.1f שניות רצופות מחוץ למרכז" % worst_run)
    if fail:
        print("❌ המיסגור לא עובר: " + " · ".join(fail))
        return 1
    if warn:
        print("⚠️ בתוך הפריים, אבל לא במרכז: " + " · ".join(warn))
        return 2
    print("✅ הדובר במרכז הפריים לאורך הקליף.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
