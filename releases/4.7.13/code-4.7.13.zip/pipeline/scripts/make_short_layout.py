# -*- coding: utf-8 -*-
"""
make_short_layout.py — "📐 פריסת שורות" (כרטיס 12, 21/10/2026): הוא רוצה לקבוע בעצמו איפה כתובית נשברת.

החלוקה האוטומטית (build_ass.chunk_words → polish_chunks → split_rows) נשארת ברירת המחדל. כשהוא משנה —
נשמרת פריסה מפורשת לקליף: work/subtitles/<clip>_layout.json =
  {"words": [המילים, מנורמלות, כמו שהיו כשנשמר], "chunks": [[[i, i, ...], [i, ...]], ...]}
  — כל כתובית היא שורה אחת או שתיים, וכל שורה היא אינדקסים רצופים ב-<clip>_words.json.
הזמנים תמיד מהשמע (המילים עצמן); הפריסה קובעת רק מה יחד ואיפה השבירה.

אחרי תיקון טקסט ויישור מחדש המילים משתנות — apply() ממפה את הפריסה השמורה למילים החדשות לפי השוואת
רצפים: כתובית שכל המילים שלה עדיין שם (ברצף) נשמרת כמו שהיא; באזור שהמילים בו השתנו — חלוקה אוטומטית.
"""
import difflib
import json
import re
from pathlib import Path

import build_ass as B

LONG_ROW = 22          # אותיות בשורה שמעליהן כנראה גולשת מהמסך (18 ≈ 760px מתוך 960 — build_ass.LINE_CHARS)


def _n(w):
    return re.sub(r"[^א-תA-Za-z0-9]", "", w or "")


def path(P, name):
    return Path(P) / "work" / "subtitles" / ("%s_layout.json" % name)


def load(P, name):
    try:
        return json.load(open(path(P, name), encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _rows_of(idx, words):
    rows, k = [], 0
    for r in B.split_rows([words[i]["word"].strip() for i in idx]):
        rows.append(idx[k:k + len(r)])
        k += len(r)
    return rows


def auto_chunks(words, sub=None):
    """החלוקה האוטומטית בדיוק כמו בצריבה, כאינדקסים. sub = רק המילים האלה (אזור שהפריסה השמורה לא מכסה)."""
    sub = list(range(len(words))) if sub is None else sub
    ws = [dict(words[i], i=i) for i in sub]
    chunks, hard = B.chunk_words(B.cap_word_durations(ws), ())
    items = B.polish_chunks(chunks, None, hard)
    return [_rows_of([w["i"] for w in ch if w["word"].strip()], words) for _, _, ch in items]


def apply(words, layout):
    """(chunks, כמה כתוביות מהפריסה השמורה לא נמצאו) — הפריסה השמורה על המילים של עכשיו."""
    live = [i for i, w in enumerate(words) if w["word"].strip()]
    if not layout:
        return auto_chunks(words), 0
    cur = [_n(words[i]["word"]) for i in live]
    mp = {}
    for b in difflib.SequenceMatcher(None, layout["words"], cur, autojunk=False).get_matching_blocks():
        for k in range(b.size):
            mp[b.a + k] = live[b.b + k]
    pos = {i: k for k, i in enumerate(live)}
    kept, lost = [], 0
    for ch in layout["chunks"]:
        flat = [i for r in ch for i in r]
        m = [mp.get(i) for i in flat]
        if not flat or None in m or [pos[x] for x in m] != list(range(pos[m[0]], pos[m[0]] + len(m))):
            lost += 1
            continue
        rows, k = [], 0
        for r in ch:
            rows.append(m[k:k + len(r)])
            k += len(r)
        kept.append(rows)
    covered = {i for ch in kept for r in ch for i in r}
    gaps, run = [], []
    for i in live:                               # רצפים של מילים שאף כתובית שמורה לא מכסה → חלוקה אוטומטית
        if i in covered:
            if run:
                gaps.append(run)
            run = []
        else:
            run.append(i)
    if run:
        gaps.append(run)
    for g in gaps:
        kept += auto_chunks(words, g)
    kept.sort(key=lambda ch: ch[0][0])
    return kept, lost


def validate(words, chunks):
    live = [i for i, w in enumerate(words) if w["word"].strip()]
    flat = [i for ch in chunks for r in ch for i in r]
    if flat != live:
        raise ValueError("הפריסה לא מכסה את כל המילים לפי הסדר — לרענן ולנסות שוב")
    for ch in chunks:
        if not 1 <= len(ch) <= 2 or any(not r for r in ch):
            raise ValueError("בכתובית אחת — שורה אחת או שתיים")


def save(P, name, words, chunks):
    """chunks=None = חזרה לחלוקה האוטומטית (הקובץ נמחק)."""
    f = path(P, name)
    if chunks is None:
        if f.exists():
            f.unlink()
        return
    validate(words, chunks)
    live = [i for i, w in enumerate(words) if w["word"].strip()]
    pos = {i: k for k, i in enumerate(live)}
    # נשמר באינדקסים של המילים החיות (בלי ריקות) — כך ההשוואה מול מילים חדשות פשוטה
    data = {"words": [_n(words[i]["word"]) for i in live],
            "chunks": [[[pos[i] for i in r] for r in ch] for ch in chunks]}
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".json.tmp")
    json.dump(data, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    tmp.replace(f)


def chunks_for(P, name, words):
    """מה שהצריבה משתמשת בו: (chunks באינדקסים של words, יש פריסה שמורה?, כמה כתוביות שמורות לא נמצאו).
    בלי פריסה שמורה → None (karaoke_ass עושה את החלוקה הרגילה בעצמו — פלט זהה למה שהיה תמיד)."""
    lay = load(P, name)
    if not lay:
        return None, False, 0
    ch, lost = apply(words, lay)
    return ch, True, lost


def view(P, name, words, duration=None):
    """לדף: כל מילה עם זמן, והפריסה (שמורה או אוטומטית)."""
    lay = load(P, name)
    ch, lost = apply(words, lay) if lay else (auto_chunks(words), 0)
    return {"words": [{"w": w["word"].strip(), "s": round(w["start"], 2), "e": round(w["end"], 2)} for w in words],
            "chunks": ch, "override": bool(lay), "lost": lost, "long_row": LONG_ROW}
