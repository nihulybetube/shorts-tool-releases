# -*- coding: utf-8 -*-
"""
שולח קישור יוטיוב + הנחיות ל-Gemini API הרשמי ישירות (עוקף באג ידוע ב-
gemini-cli MCP שלא מצליח לצפות בקבצי וידאו/URL - ה-API הרגיל תומך נטיבית
בקישורי YouTube כקלט).

צריך GEMINI_API_KEY בסביבה (או בקובץ .env בתיקיית העבודה).
מודל ברירת מחדל: gemini-flash-latest (הכי חדש בטירת החינם - מודלי pro
דורשים billing מחובר לפרויקט, לא זמינים בחינם).

שימוש:
  python ask_gemini_video.py <youtube_url> <guidelines_file> <output_txt>
"""
import json
import urllib.parse
import os
import sys
import time
import urllib.error
import urllib.request

MODEL = "gemini-flash-latest"


def normalize_youtube_url(url):
    """מנרמל כל צורת קישור יוטיוב ל-watch?v=<id>.

    ה-API דוחה ב-400 קישורים בצורת `youtube.com/live/<id>` (וכנראה גם
    `/shorts/<id>` ו-`youtu.be/<id>`) - הוא מקבל רק את הצורה הקנונית.
    נתקלנו בזה בפועל על שידור חי של אתר ישיבה.
    """
    import re
    m = re.search(r"(?:youtube\.com/(?:watch\?(?:.*&)?v=|live/|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})", url)
    if not m:
        return url          # לא מזוהה - משאירים כמו שהוא, שהשגיאה תדבר בעצמה
    return f"https://www.youtube.com/watch?v={m.group(1)}"


def load_api_key():
    key = os.environ.get("GEMINI_API_KEY")
    if key:
        return key
    # חיפוש .env בתיקיית העבודה או בתיקיית הפרויקט
    for path in [".env", os.path.join(os.getcwd(), ".env")]:
        if os.path.exists(path):
            for line in open(path, encoding="utf-8"):
                if line.startswith("GEMINI_API_KEY="):
                    return line.strip().split("=", 1)[1].strip().strip("'\"")
    raise RuntimeError("GEMINI_API_KEY לא נמצא - צריך משתנה סביבה או קובץ .env")


def ask(youtube_url, guidelines_text, api_key, model=MODEL, thinking_budget=32768):
    youtube_url = normalize_youtube_url(youtube_url)
    prompt = guidelines_text + f"\n\nהסרטון לניתוח: {youtube_url}"
    body = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"file_data": {"file_uri": youtube_url}},
            ]
        }],
        "generationConfig": {"thinkingConfig": {"thinkingBudget": thinking_budget}},
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={urllib.parse.quote(api_key, safe='')}"
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST"
    )
    # ג'מיני בטירת החינם מחזיר 503/429 באופן חולף למדי - בלי retry ריצה שלמה
    # נופלת על עומס רגעי בצד של גוגל. נתקלנו בזה בפועל (אוגוסט 26, 2 מתוך 3
    # קריאות נפלו ב-503 בו-זמנית). backoff מעריכי, עד 5 ניסיונות.
    RETRY_CODES = {429, 500, 502, 503, 504}
    last_err = None
    for attempt in range(5):
        try:
            # בלי timeout חיבור תקוע נתלה לנצח - קרה בפועל פעמיים על אותו סרטון
            # (16 דקות בלי שום פלט). 600 שניות מספיקות בהרבה לניתוח וידאו.
            with urllib.request.urlopen(req, timeout=600) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            break
        except TimeoutError:
            last_err = 'timeout'
            if attempt < 4:
                time.sleep(5 * (2 ** attempt))
            continue
        except urllib.error.HTTPError as e:
            if e.code not in RETRY_CODES:
                raise
            last_err = e
            if attempt < 4:
                time.sleep(5 * (2 ** attempt))      # 5, 10, 20, 40 שניות
    else:
        raise RuntimeError(f"Gemini לא זמין אחרי 5 ניסיונות: {last_err}")
    if "error" in result:
        raise RuntimeError(f"Gemini API error: {result['error']}")
    text = "".join(p.get("text", "") for p in result["candidates"][0]["content"]["parts"])
    usage = result.get("usageMetadata", {})
    video_tokens = next((d["tokenCount"] for d in usage.get("promptTokensDetails", []) if d["modality"] == "VIDEO"), 0)
    if video_tokens == 0:
        raise RuntimeError(
            "אזהרה: לא נראה שג'מיני באמת עיבד את תוכן הווידאו (0 video tokens) - "
            "יתכן שהקישור לא תקין או לא נגיש publicly."
        )
    return text, video_tokens


if __name__ == "__main__":
    youtube_url, guidelines_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    api_key = load_api_key()
    guidelines_text = open(guidelines_path, encoding="utf-8").read()
    # ארגומנט רביעי אופציונלי: שם מודל (לעקוף עומס/503 על מודל ספציפי)
    model = sys.argv[4] if len(sys.argv) > 4 else MODEL
    text, video_tokens = ask(youtube_url, guidelines_text, api_key, model=model)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"video_tokens_processed={video_tokens}")
    print(f"saved -> {out_path}")
