# -*- coding: utf-8 -*-
"""חותך את 4 הקליפים מהסרטון המלא לפי הזמנים המאומתים, עם ריקוד מדויק (re-encode, לא keyframe-snap)."""
import subprocess

VIDEO = "source/full_video.mp4"

CLIPS = {
    "clipA": (203.96, 241.24),
    "clipB": (475.80, 540.86),
    "clipC": (341.02, 369.60),
    "clipD": (742.58, 798.52),
}

for name, (start, end) in CLIPS.items():
    out = f"clips/{name}_raw.mp4"
    duration = end - start
    cmd = [
        "ffmpeg", "-y",
        "-ss", str(start),
        "-i", VIDEO,
        "-t", str(duration),
        "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-c:a", "aac", "-b:a", "192k",
        out,
    ]
    print("Cutting", name, start, "->", end, f"({duration:.2f}s)")
    subprocess.run(cmd, check=True, capture_output=True)
    print("  saved:", out)

print("DONE")
