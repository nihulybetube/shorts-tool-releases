# -*- coding: utf-8 -*-
"""שער איכות לכתוביות — נולד מכשל אמיתי (26/8/2026, שורטס של הרב חיים בן שושן).

מה קרה: הטקסט ה"נקי" נכתב ידנית **מקוצר** — דילג על קטעי דיבור שלמים.
`align_clean_text` לא נכשל, הוא פשוט פרש את המילים שכן היו על פני כל
הטווח, וכך יצאו כתוביות שנעלמות לחלקים גדולים מהקליפ, קופצות, ומאבדות
תוכן. אף שלב בדיקה לא תפס את זה, והסרטונים הגיעו ללקוח.

הבדיקה: לכל מילה שה-ASR שמע בפועל — האם יש כתובית שמכסה אותה בזמן?
מילה שנשמעה ואין לה כיסוי = תוכן שאבד. זה בדיוק מה שהעין רואה כ"חסר".

    python check_subs.py <asr_words.json> <aligned_words.json> [--max-gap 3.0] [--min-cover 0.90]

יוצא בקוד 1 אם הכתוביות לא עוברות — כדי שהפייפליין ייעצר לפני מסירה.
"""
import argparse
import json
import sys


def load_words(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)["words"]


def analyze(asr_words, aligned_words):
    """מחזיר (אחוז כיסוי, הרווח הארוך ביותר בשניות, רשימת הרווחים)."""
    if not asr_words:
        return 1.0, 0.0, []

    covered = []
    for w in asr_words:
        # מילת ASR נחשבת מכוסה אם כתובית כלשהי חופפת לה בזמן
        hit = any(a["start"] < w["end"] and a["end"] > w["start"] for a in aligned_words)
        covered.append(hit)

    n_cov = sum(covered)
    ratio = n_cov / len(asr_words)

    gaps, run = [], None
    for w, hit in zip(asr_words, covered):
        if not hit:
            if run is None:
                run = [w["start"], w["end"], []]
            run[1] = w["end"]
            run[2].append(w["word"].strip())
        else:
            if run is not None:
                gaps.append(run)
                run = None
    if run is not None:
        gaps.append(run)

    worst = max((g[1] - g[0] for g in gaps), default=0.0)
    return ratio, worst, gaps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("asr_words")
    ap.add_argument("aligned_words")
    ap.add_argument("--max-gap", type=float, default=3.0,
                    help="רווח מותר בשניות בלי כתובית על דיבור")
    ap.add_argument("--min-cover", type=float, default=0.90,
                    help="אחוז מילים מדוברות שחייבות לקבל כתובית")
    a = ap.parse_args()

    asr = load_words(a.asr_words)
    aligned = load_words(a.aligned_words)
    ratio, worst, gaps = analyze(asr, aligned)

    print("כיסוי כתוביות: %.1f%% מהמילים שנאמרו · הרווח הארוך ביותר: %.1f שניות"
          % (ratio * 100, worst))
    for g in gaps:
        if g[1] - g[0] >= 1.0:
            print("   חסר %5.1f–%5.1f (%.1fש'): %s"
                  % (g[0], g[1], g[1] - g[0], " ".join(g[2])[:90]))

    ok = ratio >= a.min_cover and worst <= a.max_gap
    if not ok:
        print("❌ הכתוביות לא עוברות. הטקסט הנקי כנראה מדלג על דיבור — "
              "לכתוב אותו מחדש מתוך התמלול בפועל, בלי להשמיט קטעים.")
        return 1
    print("✅ הכתוביות מכסות את כל הדיבור.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
