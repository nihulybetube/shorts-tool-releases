# -*- coding: utf-8 -*-
"""ספריית מוזיקת רקע — הורדה, אינדקס לפי אופי, ומעקב אחרי מה עבד.

הבעיה שזה פותר: עד כאן המשתמש היה צריך למצוא מוזיקה בעצמו, להוריד
קבצים לתיקייה, ולזכור לבד מה מתאים לאיזה שיעור. שלושת החלקים כאן:

  1. **הורדה** — קטלוג Incompetech (‏Kevin MacLeod, ~1,400 יצירות)
     מפורסם כ-JSON עם אופי, קצב ואורך לכל טראק. `sync` מוריד אותו,
     `fetch` מוריד קבצים בפועל.
  2. **אינדקס** — לכל טראק נשמר למה הוא מתאים, בעברית, לפי ה-`feel`
     שהמלחין עצמו סימן. `suggest` בוחר לפי זה.
  3. **משוב** — מה שומרים הוא לא "אהבתי" אלא *מתי* ועל *איזה קליף*.
     טראק שקיבל טוב פעמיים עולה בדירוג, טראק שנפסל יורד ממנו.

🚨 **הרישיון הוא CC BY 4.0 — קרדיט חובה.** זה לא "חינם בלי תנאים":
בלי שורת הקרדיט בתיאור הסרטון השימוש מפר את הרישיון. הכלי כותב את
השורה לבד לתוך `meta.json` של הקליף, ומשם היא מגיעה לדף ההעלאה — אבל
מי שמוחק אותה ביד נשאר בלי רישיון.

שימוש:
    shorts.sh py music_library.py sync
    shorts.sh py music_library.py fetch --count 20
    shorts.sh py music_library.py list
    shorts.sh py music_library.py suggest --mood calm --min-seconds 60
    shorts.sh py music_library.py used <uuid> --clip shorts/clip1
    shorts.sh py music_library.py rate <uuid> --good --note "ישב יפה על הסבר"
    shorts.sh py music_library.py credits shorts/clip1
"""
import argparse
import json
import os
import re
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

CATALOG_URL = "https://incompetech.com/music/royalty-free/pieces.json"
GENRE_URL = "https://incompetech.com/music/royalty-free/genre.json"
MP3_BASE = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/"
LICENSE_URL = "https://creativecommons.org/licenses/by/4.0/"
COMPOSER = "Kevin MacLeod"
COMPOSER_SITE = "https://incompetech.com/"
UA = "yeshiva-shorts/3.0 (+personal use; contact via incompetech.com)"

# ה-`feel` של הקטלוג → למה זה מתאים בשיעור. רק מה שנשאר כאן יורד:
# שיעור תורה עם פסקול "Aggressive" הוא לא באג בקוד אלא באג בשיקול דעת.
MOODS = {
    "Calming":   ("calm",      "רגוע — שיעור עיוני, הסבר ארוך"),
    "Calm":      ("calm",      "רגוע — שיעור עיוני, הסבר ארוך"),
    "Relaxed":   ("relaxed",   "נינוח — סיפור, זיכרון אישי"),
    "Uplifting": ("uplifting", "מרומם — סיום, מסר מחזק"),
    "Bright":    ("bright",    "בהיר — פתיחה, אנרגיה נעימה"),
    "Mystical":  ("mystical",  "פנימי — קבלה, מחשבה, עומק"),
    "Somber":    ("somber",    "כבד — נושא רציני, יום זיכרון"),
}
EXCLUDE = {"Dark", "Eerie", "Unnerving", "Aggressive", "Action",
           "Suspenseful", "Intense", "Humorous"}

IDEAL_MIN, IDEAL_MAX = 60, 420      # שניות — חלון האורך המועדף לשורט
MAX_BYTES = 25 * 2**20              # תקרה קשיחה לקובץ בודד


# --- נתיבים ------------------------------------------------------------------

def data_dir():
    d = os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts")
    return Path(d) / "music"


def config_dir():
    return Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))


def tracks_dir():
    return data_dir() / "tracks"


def index_path():
    return data_dir() / "index.json"


def feedback_path():
    # המשוב הוא של המשתמש ולא תוצר ריצה — הוא חי עם ההגדרות ולא עם הקבצים,
    # ולכן ניקוי תיקיית העבודה לא מוחק שנה של "מה עבד".
    # SHORTS_MUSIC_FEEDBACK — רק לבדיקות (22/10): לייקים/נשמע/השבתה בבדיקה לא נוגעים בקובץ האמיתי שלו.
    if os.environ.get("SHORTS_MUSIC_FEEDBACK"):
        return Path(os.environ["SHORTS_MUSIC_FEEDBACK"])
    return config_dir() / "music-feedback.json"


def now():
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M")


def load_json(p, default):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return default


def rel_track_path(path):
    """הנתיב בצורה שמותר לשים בחבילה: 'tracks/x.mp3' או '_rejected/x.mp3' — בלי שם משתמש/מחשב (4.1.0)."""
    p = str(path or "").replace("\\", "/")
    parts = [x for x in p.split("/") if x]
    if not parts:
        return ""
    sub = "_rejected" if "_rejected" in parts[:-1] else "tracks"
    return sub + "/" + parts[-1]


def resolve_track_path(path):
    """נתיב קטע כפי שהוא במחשב הזה. נתיב מוחלט של מחשב אחר (/home/<מישהו>/...) או יחסי —
    מתורגם לתיקיית המוזיקה המקומית. נתיב מוחלט שקיים כאן נשאר כמות שהוא."""
    p = str(path or "")
    if not p:
        return p
    try:
        if os.path.isabs(p) and os.path.exists(p):
            return p
    except OSError:
        pass
    parts = [x for x in p.replace("\\", "/").split("/") if x]
    if not parts:
        return p
    cand = [data_dir() / rel_track_path(p)]
    if "_rejected" in parts[:-1]:
        cand.append(tracks_dir() / parts[-1])
    else:
        cand.append(data_dir() / "_rejected" / parts[-1])
    for c in cand:
        if c.exists():
            return str(c)
    return str(cand[0])      # עדיין לא קיים — ברירת המחדל המקומית (בדיקת קיום נעשית אצל הקורא)


def load_index():
    """האינדקס עם נתיבים שנפתרו למחשב הזה (4.1.0). כל מי שקורא את האינדקס עובר כאן."""
    idx = load_json(index_path(), {})
    if isinstance(idx, dict):
        for t in idx.get("tracks", []) or []:
            if isinstance(t, dict) and t.get("path"):
                t["path"] = resolve_track_path(t["path"])
    return idx


def save_json(p, obj):
    p = Path(p)
    import make_short_guard
    make_short_guard.assert_not_real_config(p)        # 4.1.2: בדיקה לא כותבת אינדקס/לייקים אמיתיים
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def fetch_url(url, timeout=90):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def seconds_of(length):
    """'00:05:07' → 307. מחזיר 0 על כל דבר שלא נראה כך."""
    try:
        parts = [int(x) for x in str(length).split(":")]
    except ValueError:
        return 0
    s = 0
    for p in parts:
        s = s * 60 + p
    return s


def safe_name(title):
    out = re.sub(r"[^\w֐-׿ .()-]", "", title, flags=re.UNICODE).strip()
    return (out or "track")[:80]


# --- סנכרון הקטלוג -----------------------------------------------------------

def cmd_sync(a):
    print("מוריד קטלוג…")
    pieces = json.loads(fetch_url(CATALOG_URL).decode("utf-8"))
    try:
        genres = json.loads(fetch_url(GENRE_URL).decode("utf-8"))
    except Exception:
        genres = {}
    if isinstance(genres, list):
        genres = {str(g.get("id")): g.get("name", "") for g in genres if isinstance(g, dict)}

    keep = []
    for t in pieces:
        feels = [f.strip() for f in (t.get("feel") or "").split(",") if f.strip()]
        if any(f in EXCLUDE for f in feels):
            continue
        matched = [MOODS[f] for f in feels if f in MOODS]
        if not matched:
            continue
        secs = seconds_of(t.get("length"))
        if secs < 45:          # קליפ קצר עדיין צריך טראק שלא נגמר באמצע
            continue
        keep.append({
            "uuid": t.get("uuid"),
            "title": t.get("title", ""),
            "filename": t.get("filename", ""),
            "seconds": secs,
            "length": t.get("length", ""),
            "bpm": t.get("bpm", ""),
            "genre": genres.get(str(t.get("genre")), ""),
            "instruments": t.get("instruments", ""),
            "description": t.get("description", ""),
            "feel": ", ".join(feels),
            "moods": sorted({m[0] for m in matched}),
            "suits": " · ".join(sorted({m[1] for m in matched})),
            "isrc": t.get("isrc", ""),
        })

    idx = load_index()
    idx["source"] = {"name": "Incompetech", "composer": COMPOSER, "site": COMPOSER_SITE,
                     "license": "CC BY 4.0", "license_url": LICENSE_URL,
                     "catalog_url": CATALOG_URL, "synced": now()}
    have = {t["uuid"]: t for t in idx.get("tracks", []) if t.get("downloaded")}
    for t in keep:
        if t["uuid"] in have:
            t.update({k: v for k, v in have[t["uuid"]].items() if k in ("downloaded", "path")})
    # 🚨 הספרייה כבר לא רק Incompetech (מ-2026-09-24 גם Scott Buckley), וחלק מהטראקים
    # נבחרו ביד אחרי מדידה ושמיעה. sync בונה את הרשימה מחדש מהקטלוג של Kevin בלבד —
    # בלי השורות האלה הוא היה מוחק בשקט כל טראק מורד שלא מהקטלוג או שהסינון כאן פוסל.
    kept = {t["uuid"] for t in keep}
    keep += [t for u, t in have.items() if u not in kept]
    idx["tracks"] = keep
    save_json(index_path(), idx)
    print("נשמרו %d טראקים מתאימים מתוך %d בקטלוג." % (len(keep), len(pieces)))
    by = {}
    for t in keep:
        for m in t["moods"]:
            by[m] = by.get(m, 0) + 1
    for m, c in sorted(by.items(), key=lambda x: -x[1]):
        print("  %-10s %d" % (m, c))
    print("להורדה בפועל:  music_library.py fetch --count 20")
    return 0


# --- הורדת קבצים -------------------------------------------------------------

def write_license(track, mp3_path):
    """הקובץ שמנצח תלונת זכויות יוצרים.

    מה שמכריע בערעור הוא תיעוד בן-זמן ההורדה — לא הזיכרון ולא קישור
    שאולי השתנה מאז. נשמר ליד הקובץ, ונוסע איתו."""
    # המלחין מגיע מהטראק: קרדיט עם שם לא נכון הוא הפרת רישיון כמו קרדיט חסר.
    composer = track.get("composer") or COMPOSER
    site = track.get("source_site") or COMPOSER_SITE
    credit = ('"%s" מאת %s (%s) — ברישיון Creative Commons Attribution 4.0: %s'
              % (track["title"], composer, site, LICENSE_URL))
    info = {
        "title": track["title"], "composer": composer, "source": site,
        "license": "CC BY 4.0", "license_url": LICENSE_URL,
        "attribution_required": True, "credit_line": credit,
        "isrc": track.get("isrc", ""), "downloaded": now(),
        "downloaded_from": MP3_BASE + track["filename"],
    }
    Path(str(mp3_path) + ".license.json").write_text(
        json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    return credit


def cmd_fetch(a):
    idx = load_index()
    tracks = idx.get("tracks", [])
    if not tracks:
        print("אין אינדקס. הרץ קודם:  music_library.py sync", file=sys.stderr)
        return 2

    pool = [t for t in tracks if not t.get("downloaded")]
    if a.mood:
        pool = [t for t in pool if a.mood in t["moods"]]
    if not pool:
        print("אין מה להוריד (הכל כבר קיים, או שהסינון לא החזיר כלום).")
        return 0

    # 🚨 אורך: הקטלוג מלא באמביינט של שעה. לשורט של 45 שניות זה 140MB
    # כדי להשתמש ב-45 שניות — ולכן מעדיפים 1-7 דקות, ורק אם אין, ארוך יותר.
    # (הגרסה הראשונה מיינה לפי `-seconds` והורידה שמונה טראקים של חצי שעה.)
    def length_rank(t):
        s = t["seconds"]
        if IDEAL_MIN <= s <= IDEAL_MAX:
            return (0, s)
        return (1, abs(s - IDEAL_MAX))

    # פיזור על פני האופי: 20 טראקים שכולם "רגוע" הם ספרייה של אחד.
    pool.sort(key=lambda t: (t["moods"][0],) + length_rank(t))
    picked, seen = [], {}
    for t in pool:
        m = t["moods"][0]
        if seen.get(m, 0) >= max(1, a.count // max(1, len(MOODS) // 2 or 1)):
            continue
        seen[m] = seen.get(m, 0) + 1
        picked.append(t)
        if len(picked) >= a.count:
            break
    for t in pool:                       # השלמה אם הפיזור לא מילא את המכסה
        if len(picked) >= a.count:
            break
        if t not in picked:
            picked.append(t)

    tracks_dir().mkdir(parents=True, exist_ok=True)
    ok = 0
    for t in picked:
        dst = tracks_dir() / (safe_name(t["title"]) + ".mp3")
        try:
            data = fetch_url(MP3_BASE + urllib.parse.quote(t["filename"]), timeout=180)
        except Exception as e:
            print("  ✗ %s — %s" % (t["title"], e), file=sys.stderr)
            continue
        if len(data) < 20000:
            print("  ✗ %s — קובץ קצר מדי (%d בתים), כנראה דף שגיאה" % (t["title"], len(data)),
                  file=sys.stderr)
            continue
        if len(data) > MAX_BYTES:
            print("  ⏭️  %s — %dMB, גדול מדי לשורט" % (t["title"], len(data) // 2**20))
            continue
        dst.write_bytes(data)
        write_license(t, dst)
        t["downloaded"] = now()
        t["path"] = str(dst)
        ok += 1
        print("  ✓ %-42s %-9s %s" % (t["title"][:42], t["length"], t["suits"]))
    save_json(index_path(), idx)
    print("הורדו %d טראקים אל %s" % (ok, tracks_dir()))
    if ok:
        print("🚨 הקרדיט חובה. הוא נכתב לבד לכל קליף; `credits` מדפיס אותו.")
    return 0 if ok else 1


# --- משוב: מה עבד, ומתי ------------------------------------------------------

def load_feedback():
    return load_json(feedback_path(), {"version": 1, "tracks": {}})


def track_score(fb, uuid):
    """דירוג פשוט ומכוון: כל 'טוב' +1, כל 'לא' -2.

    א-סימטרי בכוונה. טראק שצרם פעם אחת עדיף שלא יחזור, גם אם הוא ישב
    יפה פעמיים לפני כן — עלות ההחמצה נמוכה (יש עוד 300) ועלות החזרה
    על צרימה גבוהה."""
    e = fb.get("tracks", {}).get(uuid, {})
    return sum(1 if r.get("verdict") == "good" else -2 for r in e.get("ratings", []))


def cmd_used(a):
    """הפייפליין מדווח שהטראק שימש בקליף. זה לא דירוג — זו עובדה."""
    fb = load_feedback()
    e = fb["tracks"].setdefault(a.uuid, {"uses": [], "ratings": []})
    e["uses"].append({"at": now(), "clip": a.clip or "", "project": a.project or ""})
    save_json(feedback_path(), fb)
    print("נרשם שימוש: %s (%s)" % (a.uuid, a.clip or "-"))
    return 0


def cmd_rate(a):
    idx = load_index()
    known = {t["uuid"]: t for t in idx.get("tracks", [])}
    if a.uuid not in known:
        print("אין טראק כזה באינדקס: %s" % a.uuid, file=sys.stderr)
        return 2
    fb = load_feedback()
    e = fb["tracks"].setdefault(a.uuid, {"uses": [], "ratings": []})
    verdict = "good" if a.good else "bad"
    # מקשרים את הדירוג לשימוש האחרון: "לא אהבתי" בלי לדעת על איזה קליף
    # הוא נאמר אינו ניתן ללמידה אחרי חודש.
    last = e["uses"][-1] if e["uses"] else {}
    e["ratings"].append({"at": now(), "verdict": verdict, "note": a.note or "",
                         "clip": a.clip or last.get("clip", ""),
                         "used_at": last.get("at", "")})
    save_json(feedback_path(), fb)
    print("%s — %s (ניקוד עכשיו: %+d)"
          % (known[a.uuid]["title"], "אהב" if a.good else "לא אהב", track_score(fb, a.uuid)))
    return 0


# --- תצוגה ובחירה ------------------------------------------------------------

def downloaded_tracks(idx):
    return [t for t in idx.get("tracks", []) if t.get("downloaded") and Path(t.get("path", "")).exists()]


def cmd_list(a):
    idx = load_index()
    have = downloaded_tracks(idx)
    if not have:
        print("הספרייה ריקה. `music_library.py sync` ואז `fetch --count 20`.")
        return 0
    fb = load_feedback()
    rows = sorted(have, key=lambda t: (-track_score(fb, t["uuid"]), t["title"]))
    print("%d טראקים בספרייה · %s" % (len(rows), tracks_dir()))
    print("%-40s %-8s %-6s %-7s %s" % ("שם", "אורך", "ניקוד", "שימושים", "מתאים ל"))
    for t in rows:
        e = fb.get("tracks", {}).get(t["uuid"], {})
        sc = track_score(fb, t["uuid"])
        print("%-40s %-8s %-6s %-7d %s"
              % (t["title"][:40], t["length"], ("%+d" % sc) if sc else "·",
                 len(e.get("uses", [])), t["suits"]))
    return 0


def cmd_suggest(a):
    """בוחר טראק לקליף. מדפיס נתיב אחד — כדי שאפשר יהיה לצנרת אותו."""
    idx = load_index()
    fb = load_feedback()
    pool = downloaded_tracks(idx)
    if a.mood:
        pool = [t for t in pool if a.mood in t["moods"]]
    if a.min_seconds:
        pool = [t for t in pool if t["seconds"] >= a.min_seconds]
    # טראק שנפסל לא חוזר מעצמו. הוא עדיין בספרייה, ו-`list` מראה אותו.
    pool = [t for t in pool if track_score(fb, t["uuid"]) > -2]
    if not pool:
        print("אין טראק שעונה על הסינון.", file=sys.stderr)
        return 1
    used_count = lambda t: len(fb.get("tracks", {}).get(t["uuid"], {}).get("uses", []))
    # ניקוד יורד, ואז מי שנוצל פחות — כדי שלא כל הקליפים יישמעו אותו דבר.
    pool.sort(key=lambda t: (-track_score(fb, t["uuid"]), used_count(t), t["title"]))
    best = pool[0]
    if a.quiet:
        print(best["path"])
    else:
        print("%s\n  %s\n  אורך %s · %s · ניקוד %+d · שימושים %d\n  uuid %s"
              % (best["path"], best["title"], best["length"], best["suits"],
                 track_score(fb, best["uuid"]), used_count(best), best["uuid"]))
    return 0


def cmd_credits(a):
    """שורת הקרדיט של הקליף — מ-meta.json שלו, או של כל הספרייה."""
    if a.clip_dir:
        meta = load_json(Path(a.clip_dir) / "meta.json", {})
        m = meta.get("music")
        if not m:
            print("לקליף הזה אין מוזיקה רשומה.")
            return 0
        print(m.get("credit", ""))
        return 0
    idx = load_index()
    for t in downloaded_tracks(idx):
        lic = load_json(t["path"] + ".license.json", {})
        if lic.get("credit_line"):
            print(lic["credit_line"])
    return 0


def main():
    ap = argparse.ArgumentParser(description="ספריית מוזיקת רקע")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("sync", help="מוריד את הקטלוג ובונה אינדקס").set_defaults(fn=cmd_sync)

    f = sub.add_parser("fetch", help="מוריד קובצי מוזיקה בפועל")
    f.add_argument("--count", type=int, default=20)
    f.add_argument("--mood", choices=sorted({v[0] for v in MOODS.values()}))
    f.set_defaults(fn=cmd_fetch)

    sub.add_parser("list", help="מה יש בספרייה").set_defaults(fn=cmd_list)

    g = sub.add_parser("suggest", help="בוחר טראק מתאים")
    g.add_argument("--mood", choices=sorted({v[0] for v in MOODS.values()}))
    g.add_argument("--min-seconds", type=int, default=0)
    g.add_argument("--quiet", action="store_true", help="נתיב בלבד")
    g.set_defaults(fn=cmd_suggest)

    u = sub.add_parser("used", help="רישום שהטראק שימש בקליף")
    u.add_argument("uuid"); u.add_argument("--clip", default=""); u.add_argument("--project", default="")
    u.set_defaults(fn=cmd_used)

    r = sub.add_parser("rate", help="הלקוח אהב או לא")
    r.add_argument("uuid")
    m = r.add_mutually_exclusive_group(required=True)
    m.add_argument("--good", action="store_true"); m.add_argument("--bad", action="store_true")
    r.add_argument("--note", default=""); r.add_argument("--clip", default="")
    r.set_defaults(fn=cmd_rate)

    c = sub.add_parser("credits", help="שורות הקרדיט")
    c.add_argument("clip_dir", nargs="?")
    c.set_defaults(fn=cmd_credits)

    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
