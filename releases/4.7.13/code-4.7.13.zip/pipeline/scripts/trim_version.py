# -*- coding: utf-8 -*-
"""חיתוך גרסה קצרה מתוך המאסטר הארוך — בלי לרנדר פעמיים.

    python trim_version.py <long.mp4> <words.json> <short_text.txt> <out.mp4>

למה ככה: הגרסה הקצרה (יוטיוב) היא תת-קטע מדויק של הארוכה (טיקטוק), ולכן
רינדור שני של אותו קטע הוא בזבוז של חצי שעה מעבד — וגם סיכון: ייצוב הוא
לא דטרמיניסטי מול קלט אחר, ושתי הגרסאות היו יוצאות מעט שונות זו מזו.

איך נמצא הגבול: `words.json` הוא הפלט של `align_clean_text.py` על הטקסט
הנקי הארוך, כלומר לכל מילה יש חותמת זמן **בציר של הווידאו הארוך**. הטקסט
הקצר הוא רצף מילים רציף בתוך הארוך, ולכן חיפוש תת-רצף מנורמל מוצא בדיוק
איפה הוא מתחיל ונגמר.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

LEAD = 0.18   # רגע לפני המילה הראשונה — פתיחה לא נשמעת קטועה
TAIL = 0.35   # ורגע אחרי האחרונה, שהמשפט ייסגר


def norm(t: str) -> str:
    return re.sub(r"[^א-תA-Za-z0-9]", "", t)


def find_span(words, short_text: str):
    """מחזיר (i, j) — אינדקס המילה הראשונה והאחרונה של הטקסט הקצר בתוך הארוך."""
    # מקפים ופיסוק בודדים ("-") הם מילים בפני עצמן בטקסט הנקי ומתנרמלים
    # למחרוזת ריקה. משמיטים אותם משני הצדדים, ושומרים מיפוי חזרה לאינדקס
    # האמיתי — אחרת רצף זהה לחלוטין "לא נמצא" רק בגלל מקף באמצע.
    idx = [k for k, w in enumerate(words) if norm(w["word"])]
    big = [norm(words[k]["word"]) for k in idx]
    small = [norm(w) for w in short_text.split() if norm(w)]
    if not small:
        raise SystemExit("הטקסט הקצר ריק")
    n, m = len(big), len(small)
    for i in range(n - m + 1):
        if big[i:i + m] == small:
            return idx[i], idx[i + m - 1]
    # לא נמצאה התאמה מדויקת — מנסים לפי מילת הפתיחה והסיום בלבד, ומדווחים
    print("⚠️  לא נמצאה התאמה מלאה של הטקסט הקצר בתוך הארוך — נופל לעוגני קצה")
    try:
        i = idx[big.index(small[0])]
        j = idx[len(big) - 1 - big[::-1].index(small[-1])]
    except ValueError:
        raise SystemExit("❌ גם מילת הפתיחה/סיום לא נמצאה — הטקסטים לא תואמים")
    if j <= i:
        raise SystemExit("❌ סדר עוגנים לא הגיוני — לא חותך")
    return i, j


def locate(words, short_text: str):
    """מחזיר (start, end) בשניות של הטקסט הקצר בתוך רצף המילים הארוך."""
    i, j = find_span(words, short_text)
    return words[i]["start"], words[j]["end"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("long_video")
    ap.add_argument("words_json")
    ap.add_argument("short_text")
    ap.add_argument("out_video")
    a = ap.parse_args()

    words = json.loads(Path(a.words_json).read_text(encoding="utf-8"))["words"]
    text = Path(a.short_text).read_text(encoding="utf-8").strip()
    start, end = locate(words, text)
    start = max(0.0, start - LEAD)
    end = end + TAIL
    print("גרסה קצרה: %.2f–%.2f (%.1f שניות)" % (start, end, end - start))

    ff = os.environ.get("FFMPEG", "ffmpeg")
    r = subprocess.run([ff, "-y", "-loglevel", "error", "-i", a.long_video,
                        "-ss", "%.3f" % start, "-to", "%.3f" % end,
                        "-c:v", "libx264", "-preset", "medium", "-crf", "16",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                        "-movflags", "+faststart", a.out_video])
    if r.returncode != 0 or not Path(a.out_video).exists():
        raise SystemExit("❌ חיתוך הגרסה הקצרה נכשל")
    print("נכתב: " + a.out_video)
    return 0


if __name__ == "__main__":
    sys.exit(main())
