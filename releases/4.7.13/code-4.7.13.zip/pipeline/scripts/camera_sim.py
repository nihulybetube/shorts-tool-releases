# -*- coding: utf-8 -*-
# שימוש (מתוך תיקיית הפרויקט, אחרי multi_piece_clip): shorts.sh py camera_sim.py <clipN>
"""מדמה מצלמות שונות על זיהוי הפנים של קליף, ומודד בדיוק לפי כללי check_framing:
אחוז הדגימות שבהן הפנים בתוך ±25% מרוחב הפלט (=±0.079 מרוחב המקור), ורצף מקסימלי מעבר ל-30%."""
import json, sys
import numpy as np
import face_track as F

clip = sys.argv[1]
t, c, s, h = F.detect_centers(f"work/clips/{clip}_raw.mp4")
c = F._reject_outliers(c, h); c = F._fill_gaps(c)
fps = F.SAMPLE_FPS
segs = json.load(open(f"work/clips/{clip}_segments.json"))["raw_segments"]
used = np.zeros(len(t), bool)
for a, b in segs: used |= (t >= a) & (t < b)
starts = [0.0]
for (a0, b0), (a1, b1) in zip(segs[:-1], segs[1:]): starts.append((b0 + a1) / 2)
W = 0.316   # רוחב חלון הקרופ ביחידות רוחב-מקור (1080 מתוך 3413)

def score(cam):
    off = np.abs(c - cam)[used] / W
    inr = (off <= 0.25).mean()
    run = best = 0
    for o in off:
        run = run + 1 if o > 0.30 else 0; best = max(best, run)
    return inr, best / fps

def camera(median_sec, mean_sec, per_piece):
    F.MEDIAN_SEC, F.MEAN_SEC = median_sec, mean_sec
    tgt = F._smooth(c, fps)
    if not per_piece:
        return F.virtual_camera(tgt, fps)[0]
    edges = [int(round(x * fps)) for x in starts] + [len(tgt)]
    out = []
    for k in range(len(starts)):
        seg = tgt[edges[k]:edges[k+1]].copy()
        a = int(round(0.5 * fps)); b = min(len(seg), a + int(round(3 * fps)))
        seg[0] = (seg[a:b].min() + seg[a:b].max()) / 2
        out.append(F.virtual_camera(seg, fps)[0])
    return np.concatenate(out)

print(f"{clip}: face range {c[used].min():.2f}-{c[used].max():.2f}")
for med, mean in [(1.5, 1.0), (3.0, 3.0), (4.0, 4.0), (5.0, 5.0), (7.0, 7.0)]:
    for pp in (False, True):
        inr, run = score(camera(med, mean, pp))
        ok = "PASS" if inr >= 0.80 and run <= 2.5 else "fail"
        print(f"  smooth {med:.1f}/{mean:.1f}s  per-piece={pp!s:5}  in-range {inr*100:5.1f}%  longest>30% {run:.1f}s  {ok}")
