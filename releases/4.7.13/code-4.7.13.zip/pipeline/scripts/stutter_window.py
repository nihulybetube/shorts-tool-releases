# -*- coding: utf-8 -*-
"""שער הקרטוע — גם החלון הגרוע, לא רק הממוצע (4/10/2026).

    shorts.sh py stutter_window.py <video.mp4> [--win 2.0]

מדפיס: יחס פריימים ייחודיים לכל הקובץ (≥0.97), והחלון של 2 שניות הגרוע ביותר (≥0.80).
למה: בשורט אחד השידור המקורי קפא 2.3 שניות בדיוק על הפואנטה. הממוצע עבר (0.976),
החלון הגרוע היה 0.35. למדוד על הווידאו **לפני** גרפיקות וכתוביות — הן זזות ומסתירות קפיאה.
יציאה 1 אם אחד מהשניים נכשל."""
import os
import re
import subprocess
import sys

f = sys.argv[1]
W = float(sys.argv[sys.argv.index("--win") + 1]) if "--win" in sys.argv else 2.0
FF = os.environ.get("FFMPEG", "ffmpeg")
FP = os.environ.get("FFPROBE", "ffprobe")


def probe(entries, *extra):
    return subprocess.run([FP, "-v", "error", *extra, "-show_entries", entries, "-of", "csv=p=0", f],
                          capture_output=True, text=True).stdout.strip()


dur = float(probe("format=duration"))
# קצב הפריימים של הקובץ עצמו: עם 30 קבוע, כל מקור של 25 פריימים "נכשל" ב-0.83.
_n, _, _d = probe("stream=avg_frame_rate", "-select_streams", "v:0").partition("/")
FPS = float(_n) / float(_d or 1)
err = subprocess.run([FF, "-v", "info", "-i", f, "-vf", "mpdecimate=hi=200:lo=64:frac=0.33,showinfo",
                      "-map", "0:v", "-fps_mode", "vfr", "-f", "null", "-"], capture_output=True, text=True).stderr
ts = [float(x) for x in re.findall(r"pts_time:([0-9.]+)", err)]
total = len(ts) / (dur * FPS)
worst, at, t = 9.0, 0.0, 0.0
while t + W <= dur + 1e-6:
    r = sum(1 for x in ts if t <= x < t + W) / (W * FPS)
    if r < worst:
        worst, at = r, t
    t += 0.25
ok = total >= 0.97 and worst >= 0.80
print(f"{'✅' if ok else '❌'} [{FPS:g}fps] ייחודיים {total:.3f} (סף 0.97) · "
      f"החלון הגרוע ({W:.0f}ש') {worst:.2f} ב-{at:.2f} (סף 0.80)")
sys.exit(0 if ok else 1)
