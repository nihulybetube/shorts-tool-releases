# -*- coding: utf-8 -*-
"""4.6 — הכספת המוצפנת + "ערכת השחזור למחשב חדש" (תיקייה קטנה ב-Drive).

ההחלטות של הבעלים (23–24/11/2026):
  • כל מה שאינו סוד (קוד, הגדרות, לוגו, מוזיקה, הנחיות, מילון, פרופילי רבנים, שורטסים) — בגיבוי הרגיל ב-Drive,
    משתחזר בלי שום סיסמה.
  • הכספת = קובץ אחד מוצפן בסיסמה (scrypt + AES-GCM, אותה תבנית כמו release_key.enc / proposals_owner.enc):
    מפתח החתימה, מפתח ההצעות + ערוץ ה-ntfy, מפתח Gemini, החיבור ל-Modal, והמפתח האישי של Drive (client id/secret).
    לא נשמרים: עוגיות יוטיוב (מתיישנות) והכניסה ל-Drive עצמה (הטוקן) — את הכניסה עושים פעם אחת בדפדפן.
  • הסיסמה מוקלדת בחלון ולא נשמרת בשום מקום (הוא שומר אותה ב-Google Keep + על נייר).
  • ההצפנה מגינה מפני שיתוף בטעות ומפני אפליקציות אחרות שקוראות את ה-Drive — לא מפני מי שהשתלט על חשבון הגוגל
    (הסיסמה ב-Keep של אותו חשבון). זה כתוב לו במסך, במילים פשוטות.

למה גם ה-client id/secret של Drive בפנים (החלטה שלי, מוסברת ב-HANDOFF §8r): הם לא כניסה לחשבון — בלי אישור בדפדפן
אי אפשר לקרוא איתם כלום; אבל בלעדיהם במחשב חדש הוא היה צריך לחזור על כל מדריך ה-Google Cloud (15 דקות, מסכים באנגלית).
איתם: לחיצה אחת בדפדפן. הסיכון (מישהו "מתחזה" לאפליקציה שלו במסך אישור של גוגל) קטן, ומוגן בכל מקרה בהצפנה.

שימוש:
  shorts.sh py make_short_vault.py status
  shorts.sh py make_short_vault.py restore --file <vault.enc> --interactive     (תוכנית השחזור; הסיסמה ב-getpass)
  shorts.sh py make_short_vault.py drive-state | drive-login
  shorts.sh py make_short_vault.py kit [--force]                                (בונה את תיקיית השחזור; backup_extras.sh)
הסיסמה לעולם לא בשורת הפקודה, ואף ערך סודי לא מודפס, לא נרשם ביומן ולא חוזר לדף.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
sys.path.insert(0, str(HERE))
CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
VAULT_FILE = CONFIG / "vault.enc"
STATE_FILE = DATA / "vault_state.json"          # מקומי בלבד: טביעות (HMAC עם מלח אקראי) כדי לדעת ש"משהו השתנה מאז"
KIT_DIR = DATA / "restore_kit"                  # התיקייה שעולה ל-Drive: "גיבוי תוכנה/שחזור למחשב חדש"
KIT_REMOTE_NAME = "שחזור למחשב חדש"
KIND = "yeshiva-shorts-vault"
AAD = b"yeshiva-shorts-vault-v1|"
MIN_PW = 10


class VaultError(ValueError):
    """הודעה בעברית פשוטה — אפשר להציג למשתמש כמו שהיא."""


class SimulatedCrash(BaseException):
    """רק לבדיקות: הפסקת חשמל באמצע כתיבה (MAKE_SHORT_VAULT_CRASH_AT)."""


def _crashpoint(name):
    if os.environ.get("MAKE_SHORT_VAULT_CRASH_AT") == name:
        raise SimulatedCrash(name)


def _guard(path):
    try:
        import make_short_guard as G
        G.assert_not_real_config(path)
    except ImportError:
        pass


def _kdf_n():
    # בדיקות בלבד (במצב בדיקה): scrypt קל יותר כדי שהבדיקות לא יימשכו דקות. הקובץ שומר את n, כך שהקריאה תמיד נכונה.
    try:
        import make_short_guard as G
        if G.test_mode() and os.environ.get("MAKE_SHORT_VAULT_FAST_KDF") == "1":
            return 2 ** 14
    except ImportError:
        pass
    return 2 ** 17


def _derive(pw, salt, n):
    return hashlib.scrypt(pw.encode("utf-8"), salt=salt, n=n, r=8, p=1, maxmem=2 ** 29, dklen=32)


def write_private(path, data):
    """כתיבה אטומית, 0600 מהרגע הראשון (O_EXCL), fsync, ואז os.replace. data: bytes או str."""
    path = Path(path)
    _guard(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, str):
        data = data.encode("utf-8")
    tmp = path.with_name("%s.tmp%d" % (path.name, os.getpid()))
    try:
        tmp.unlink()
    except OSError:
        pass
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


# ─────────────────────────── מקורות הסודות (איפה כל אחד יושב במחשב) ───────────────────────────
def _state_mod():
    sys.path.insert(0, str(REPO / "setup"))
    import state
    return state


def _env():
    try:
        return _state_mod().read_env()
    except Exception:
        return {}


def _modal_path(env=None):
    env = env if env is not None else _env()
    p = os.environ.get("MODAL_CONFIG_PATH") or env.get("MODAL_CONFIG_PATH") or ""
    return Path(os.path.expanduser(p)) if p else Path.home() / ".modal.toml"


def rclone_conf_path():
    p = os.environ.get("RCLONE_CONFIG")
    return Path(p) if p else Path.home() / ".config" / "rclone" / "rclone.conf"


def _gdrive_section(conf=None):
    import configparser
    conf = conf or rclone_conf_path()
    try:
        txt = Path(conf).read_text(encoding="utf-8")
    except OSError:
        return None
    if txt.lstrip().startswith("# Encrypted rclone configuration"):
        return None
    cp = configparser.RawConfigParser(strict=False)
    try:
        cp.read_string(txt)
    except configparser.Error:
        return None
    if not cp.has_section("gdrive"):
        return None
    return {k: v.strip() for k, v in cp.items("gdrive")}


def _read(path):
    try:
        return Path(path).read_text(encoding="utf-8")
    except OSError:
        return None


ITEMS = [
    ("signing", "🔑 מפתח החתימה של העדכונים",
     "הקובץ release_key.enc (הוא עצמו מוצפן גם בסיסמת החתימה). בלעדיו אי אפשר לפרסם עדכונים למי שקיבל את התוכנה."),
    ("proposals", "📥 מפתח ההצעות + ערוץ ההתראות (ntfy)",
     "המפתח שפותח הצעות ממשתמשים, הנושאים של ntfy ומצב תיבת ההצעות."),
    ("gemini", "✨ מפתח Gemini", "המפתח לבחירת קטעים ולעורך החכם."),
    ("modal", "☁️ החיבור ל-Modal", "קובץ החיבור לחשבון Modal (התמלול המהיר בענן)."),
    ("drive_client", "📁 המפתח האישי של Google Drive",
     "רק ה-client id/secret של המפתח האישי — לא הכניסה לחשבון. בזכותם במחשב חדש מספיקה לחיצה אחת בדפדפן."),
]
LABEL = {i: l for i, l, _ in ITEMS}


def _collect(item):
    """dict עם התוכן הסודי של פריט, או None אם אין אותו במחשב הזה. לא מדפיס כלום."""
    if item == "signing":
        t = _read(CONFIG / "release_key.enc")
        return {"release_key.enc": t} if t else None
    if item == "proposals":
        # 4.6.8: גם ערוץ מ-4.4 (נושאי ntfy בלי מפתח פרטי עדיין) נחשב — המפתח נוצר בגיבוי (ראו _prepare_proposals)
        k, o = _read(CONFIG / "proposals_owner.key"), _read(CONFIG / "proposals_owner.json")
        if not k and not (o and '"channel"' in o):
            return None
        out = {"proposals_owner.json": o or ""}
        if k:
            out["proposals_owner.key"] = k
        return out
    if item == "gemini":
        v = (_env().get("GEMINI_API_KEY") or "").strip()
        return {"GEMINI_API_KEY": v} if v else None
    if item == "modal":
        t = _read(_modal_path())
        if t and re.search(r"token_id", t):
            return {"modal.toml": t}
        env = _env()
        if env.get("MODAL_TOKEN_ID") and env.get("MODAL_TOKEN_SECRET"):
            return {"MODAL_TOKEN_ID": env["MODAL_TOKEN_ID"], "MODAL_TOKEN_SECRET": env["MODAL_TOKEN_SECRET"]}
        return None
    if item == "drive_client":
        g = _gdrive_section()
        if g and g.get("client_id") and g.get("client_secret"):
            return {"client_id": g["client_id"], "client_secret": g["client_secret"]}
        return None
    raise VaultError("פריט לא מוכר: %s" % item)


def available():
    """[{id, label, desc, present}] — מה יש במחשב הזה שאפשר לשים בכספת. בלי ערכים."""
    out = []
    for i, label, desc in ITEMS:
        try:
            present = _collect(i) is not None
        except Exception:
            present = False
        out.append({"id": i, "label": label, "desc": desc, "present": present})
    return out


# ─────────────────────────── מצב מקומי (טביעות, בלי סודות) ───────────────────────────
def _load_state():
    try:
        d = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _fp(salt, payload):
    return hmac.new(bytes.fromhex(salt), json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8"),
                    hashlib.sha256).hexdigest()


def _header(path=None):
    try:
        d = json.loads(Path(path or VAULT_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and d.get("kind") == KIND else None


def status():
    """{exists, made, items:[{id,label}], stale:[ids], new:[ids], available:[...], kit:{...}} — בלי ערכים."""
    h = _header()
    st = _load_state()
    avail = available()
    d = {"exists": bool(h), "made": int((h or {}).get("made") or 0), "items": [], "stale": [], "new": [],
         "available": avail, "kit": kit_status()}
    if h:
        d["items"] = [{"id": i, "label": LABEL.get(i, i)} for i in h.get("items", [])]
        salt, fps = st.get("salt"), st.get("fp") or {}
        for a in avail:
            if not a["present"]:
                continue
            if a["id"] not in h.get("items", []):
                d["new"].append(a["id"])
            elif salt and fps.get(a["id"]) and fps[a["id"]] != _fp(salt, _collect(a["id"])):
                d["stale"].append(a["id"])
    return d


# ─────────────────────────── הצפנה / פענוח ───────────────────────────
def _aad(h):
    return AAD + json.dumps({k: h[k] for k in sorted(h) if k != "ct"}, sort_keys=True, ensure_ascii=False).encode("utf-8")


def _encrypt(pw, payload, items, made):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    n = _kdf_n()
    salt, nonce = os.urandom(16), os.urandom(12)
    h = {"v": 1, "kind": KIND, "kdf": "scrypt", "n": n, "r": 8, "p": 1, "salt": base64.b64encode(salt).decode(),
         "nonce": base64.b64encode(nonce).decode(), "made": int(made), "items": list(items)}
    plain = json.dumps({"items": payload, "made": int(made)}, ensure_ascii=False).encode("utf-8")
    h["ct"] = base64.b64encode(AESGCM(_derive(pw, salt, n)).encrypt(nonce, plain, _aad(h))).decode()
    return h


def decrypt(pw, path=None):
    """מחזיר {"items": {...}, "made": ...}. סיסמה שגויה / קובץ ששונה → VaultError (לא מבחינים — כמו בכל AES-GCM)."""
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    p = Path(path or VAULT_FILE)
    try:
        h = json.loads(p.read_text(encoding="utf-8"))
    except OSError:
        raise VaultError("לא נמצא קובץ כספת (%s)." % p.name)
    except ValueError:
        raise VaultError("קובץ הכספת פגום (לא נקרא בכלל) — כנראה לא הורד עד הסוף.")
    if not isinstance(h, dict) or h.get("kind") != KIND or h.get("v") != 1 or h.get("kdf") != "scrypt":
        raise VaultError("זה לא קובץ כספת של התוכנה.")
    if not (isinstance(h.get("n"), int) and 2 ** 14 <= h["n"] <= 2 ** 18 and h.get("r") == 8 and h.get("p") == 1):
        raise VaultError("קובץ הכספת פגום (פרמטרי הצפנה לא מוכרים).")
    try:
        plain = AESGCM(_derive(pw or "", base64.b64decode(h["salt"]), h["n"])).decrypt(
            base64.b64decode(h["nonce"]), base64.b64decode(h["ct"]), _aad(h))
    except (InvalidTag, KeyError, ValueError, TypeError):
        raise VaultError("הסיסמה שגויה — או שקובץ הכספת השתנה/נפגם. (אי אפשר לדעת מה מהשניים; לנסות שוב בזהירות.)")
    d = json.loads(plain.decode("utf-8"))
    if sorted(d.get("items", {})) != sorted(h.get("items", [])):
        raise VaultError("קובץ הכספת לא עקבי — לא משחזרים ממנו.")
    return d


def _prepare_proposals():
    """ערוץ שנוצר ב-4.4 (לפני שנוספו מפתחות להצעות) אין לו עדיין קובץ מפתח פרטי — הוא נוצר רק בבניית גרסה. בלי זה הכספת
    הייתה נשמרת בלי המפתח, ובגרסה הבאה הוא היה נוצר ולא מגובה. עכשיו יוצרים אותו (מקומי בלבד, בדיוק כמו בבניית גרסה)."""
    if (CONFIG / "proposals_owner.key").is_file():
        return
    try:
        import make_short_proposals as PRP
        PRP.channel_file_bytes()
    except Exception:
        pass


def create(pw, pw2, items=None):
    """יוצר/מחליף את הכספת (CONFIG/vault.enc). items=None → כל מה שקיים במחשב. מחזיר status()."""
    if (pw or "") != (pw2 or ""):
        raise VaultError("שתי הסיסמאות לא זהות — להקליד שוב.")
    if len(pw or "") < MIN_PW:
        raise VaultError("הסיסמה קצרה מדי — לפחות %d תווים. (אי אפשר לשחזר אותה אם תישכח: לשמור ב-Keep וגם על נייר.)" % MIN_PW)
    want = [i for i, _, _ in ITEMS if items is None or i in items]
    unknown = [i for i in (items or []) if i not in LABEL]
    if unknown:
        raise VaultError("פריט לא מוכר: %s" % ", ".join(unknown))
    if "proposals" in want:
        _prepare_proposals()
    payload = {}
    for i in want:
        c = _collect(i)
        if c is not None:
            payload[i] = c
    if not payload:
        raise VaultError("אין במחשב הזה שום דבר לשים בכספת (אין מפתח חתימה, Gemini, Modal וכו').")
    made = int(time.time())
    h = _encrypt(pw, payload, sorted(payload), made)
    raw = json.dumps(h, indent=1, sort_keys=True).encode("utf-8")
    # כתיבה לקובץ זמני, בדיקה שהוא באמת נפתח בסיסמה הזאת ומחזיר בדיוק את מה שהוכנס — רק אז מחליפים
    _guard(VAULT_FILE)
    VAULT_FILE.parent.mkdir(parents=True, exist_ok=True)
    for old in VAULT_FILE.parent.glob(VAULT_FILE.name + ".tmp*"):
        try:
            old.unlink()
        except OSError:
            pass
    tmp = VAULT_FILE.with_name(VAULT_FILE.name + ".tmp%d" % os.getpid())
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(raw[: len(raw) // 2])
        _crashpoint("half_written")
        f.write(raw[len(raw) // 2:])
        f.flush()
        os.fsync(f.fileno())
    try:
        if decrypt(pw, tmp)["items"] != payload:
            raise VaultError("בדיקת הכספת אחרי הכתיבה נכשלה — לא הוחלפה.")
        _crashpoint("before_replace")
        os.replace(tmp, VAULT_FILE)
    except VaultError:
        tmp.unlink(missing_ok=True)
        raise
    os.chmod(VAULT_FILE, 0o600)
    st = _load_state()
    salt = st.get("salt") or os.urandom(16).hex()
    write_private(STATE_FILE, json.dumps({"salt": salt, "made": made, "fp": {i: _fp(salt, c) for i, c in payload.items()}}))
    return status()


# ─────────────────────────── שחזור: כל פריט למקומו ───────────────────────────
def _same(path, text):
    return _read(path) == text


def _put(path, text, overwrite, res):
    path = Path(path)
    if path.exists():
        if _same(path, text):
            res["result"] = "same"
            return False
        if not overwrite:
            res["result"] = "kept"
            res["note"] = "כבר יש במחשב הזה גרסה אחרת — לא נדרסה (אפשר לסמן «להחליף גם מה שקיים»)."
            return False
        bak = path.with_name(path.name + ".before-vault-%d" % int(time.time()))
        write_private(bak, path.read_bytes())
    write_private(path, text)
    res["result"] = "restored"
    return True


def _restore_item(i, c, overwrite):
    res = {"id": i, "label": LABEL.get(i, i), "result": "", "check": "", "note": ""}
    st = _state_mod()
    if i == "signing":
        _put(CONFIG / "release_key.enc", c["release_key.enc"], overwrite, res)
        try:
            j = json.loads(_read(CONFIG / "release_key.enc") or "{}")
            import make_short_release as R
            ok = j.get("kdf") == "scrypt" and j.get("ct") and j.get("pub")
            res["check"] = ("✓ קובץ המפתח תקין (מזהה %s). הסיסמה שלו — סיסמת החתימה, נדרשת רק בפרסום." % R.key_id(j["pub"])) if ok \
                else "✗ קובץ המפתח לא נראה תקין"
        except Exception:
            res["check"] = "✗ קובץ המפתח לא נקרא"
    elif i == "proposals":
        if c.get("proposals_owner.key"):
            _put(CONFIG / "proposals_owner.key", c["proposals_owner.key"], overwrite, res)
        if c.get("proposals_owner.json"):
            r2 = dict(res)
            _put(CONFIG / "proposals_owner.json", c["proposals_owner.json"], overwrite, r2)
            if res["result"] == "same" and r2["result"] != "same":
                res.update(result=r2["result"], note=r2.get("note", ""))
        try:
            o = json.loads(_read(CONFIG / "proposals_owner.json") or "{}")
            json.loads(_read(CONFIG / "proposals_owner.key") or "{}")
            res["check"] = "✓ המפתח נקרא" + (" · ערוץ ההתראות קיים" if o.get("channel") else " · (אין עדיין ערוץ)")
        except ValueError:
            res["check"] = "✗ קובץ המפתח לא נקרא"
    elif i == "gemini":
        cur = st.read_env().get("GEMINI_API_KEY", "")
        v = c["GEMINI_API_KEY"]
        if cur == v:
            res["result"] = "same"
        elif cur and not overwrite:
            res.update(result="kept", note="כבר יש מפתח Gemini אחר במחשב — לא הוחלף.")
        else:
            _guard(st.env_path())
            st.write_env({"GEMINI_API_KEY": v})
            res["result"] = "restored"
        k = st.read_env().get("GEMINI_API_KEY", "")
        res["check"] = "✓ המפתח במקומו (בדיקה מול גוגל — בכפתור «שמור ובדוק» בחלון)" if re.fullmatch(r"[A-Za-z0-9_\-]{20,}", k) \
            else "⚠ המפתח לא נראה כמו מפתח Gemini"
    elif i == "modal":
        if "modal.toml" in c:
            dst = Path.home() / ".modal.toml"
            env = st.read_env()
            cur = _modal_path(env)
            if cur.is_file() and _same(cur, c["modal.toml"]):
                dst = cur
                res["result"] = "same"
            else:
                _put(dst, c["modal.toml"], overwrite, res)
            if res["result"] in ("restored", "same"):
                upd = {"MODAL_CONFIG_PATH": str(dst)}           # מחווטים מחדש: הנתיב הישן (C:\Users\...) לא קיים במחשב החדש
                if env.get("SHORTS_ASR", "local") in ("", "local"):
                    upd["SHORTS_ASR"] = "modal"
                if any(env.get(k) != v for k, v in upd.items()):
                    _guard(st.env_path())
                    st.write_env(upd)
            t = _read(_modal_path(st.read_env())) or ""
            res["check"] = "✓ קובץ החיבור במקומו (חשבון: %s)" % (re.search(r"^\s*\[([^\]]+)\]", t, re.M).group(1) if re.search(r"^\s*\[([^\]]+)\]", t, re.M) else "?") \
                if ("token_id" in t and "token_secret" in t) else "✗ קובץ החיבור לא נראה תקין"
        else:
            env = st.read_env()
            if env.get("MODAL_TOKEN_ID") == c["MODAL_TOKEN_ID"]:
                res["result"] = "same"
            elif env.get("MODAL_TOKEN_ID") and not overwrite:
                res.update(result="kept", note="כבר יש חיבור Modal אחר במחשב — לא הוחלף.")
            else:
                _guard(st.env_path())
                st.write_env({"MODAL_TOKEN_ID": c["MODAL_TOKEN_ID"], "MODAL_TOKEN_SECRET": c["MODAL_TOKEN_SECRET"]})
                res["result"] = "restored"
            res["check"] = "✓ פרטי החיבור במקומם"
    elif i == "drive_client":
        conf = rclone_conf_path()
        g = _gdrive_section(conf)
        if g is None:
            if conf.exists() and (_read(conf) or "").lstrip().startswith("# Encrypted"):
                res.update(result="kept", note="הגדרות rclone מוצפנות בסיסמה — לא נוגעים.")
            else:
                body = (_read(conf) or "").rstrip("\n")
                body = (body + "\n\n" if body else "") + "[gdrive]\ntype = drive\nscope = drive\nclient_id = %s\nclient_%s = %s\n" % (
                    c["client_id"], "secret", c["client_secret"])
                conf.parent.mkdir(parents=True, exist_ok=True)
                write_private(conf, body)
                res["result"] = "restored"
        elif g.get("client_id") == c["client_id"] and g.get("client_secret") == c["client_secret"]:
            res["result"] = "same"
        elif (g.get("token") or g.get("client_id")) and not overwrite:
            res.update(result="kept", note="כבר יש חיבור Drive במחשב הזה — לא נגעתי בו.")
        else:
            import make_short_health as HEALTH
            HEALTH.conf_update(conf, "gdrive", {"client_id": c["client_id"], "client_secret": c["client_secret"], "scope": "drive"})
            res["result"] = "restored"
        res["check"] = {"connected": "✓ Drive מחובר", "needs-login": "⚠ צריך עוד כניסה אחת בדפדפן (לחיצה על «חבר מחדש את הדרייב»)",
                        "no-client": "✗ המפתח לא נכתב"}.get(drive_state(), "")
    return res


def restore(pw, path=None, items=None, overwrite=False):
    """מפענח ומחזיר כל פריט למקומו (0600). מחזיר [{id,label,result,check,note}] — בלי ערכים."""
    d = decrypt(pw, path)
    out = []
    for i, _, _ in ITEMS:
        if i not in d["items"] or (items is not None and i not in items):
            continue
        try:
            out.append(_restore_item(i, d["items"][i], overwrite))
        except Exception as e:                    # פריט אחד שנכשל לא עוצר את האחרים; ההודעה בלי ערכים
            out.append({"id": i, "label": LABEL.get(i, i), "result": "failed", "check": "", "note": _safe_msg(e)})
    # עותק מקומי של הכספת (אם שוחזרה מקובץ אחר) — כדי שהמחשב החדש יזהה שהוא של הבעלים וימשיך לגבות אותה
    if path and Path(path).resolve() != VAULT_FILE.resolve() and not VAULT_FILE.exists():
        write_private(VAULT_FILE, Path(path).read_bytes())
    return out


def _safe_msg(e):
    m = str(e)
    return re.sub(r"[A-Za-z0-9_\-]{24,}", "…", m)[:300]


# ─────────────────────────── Drive: מצב + כניסה בדפדפן ───────────────────────────
def drive_state(conf=None):
    """connected (יש טוקן) · needs-login (יש מפתח, אין כניסה) · no-client (אין חיבור gdrive בכלל)."""
    g = _gdrive_section(conf)
    if not g:
        return "no-client"
    return "connected" if g.get("token") else "needs-login"


def drive_login_script(done_file=None):
    """שורות bash לחלון השחור: פותח-דפדפן של ווינדוס + rclone config reconnect. אותו מנגנון כמו בחלון התוכנה."""
    shim = DATA / "bin" / "xdg-open"
    src = REPO / "setup" / "wsl_open.sh"
    if src.is_file() and (not shim.is_file() or shim.read_bytes() != src.read_bytes()):
        shim.parent.mkdir(parents=True, exist_ok=True)
        shim.write_bytes(src.read_bytes())
        os.chmod(shim, 0o755)
    import shlex
    q = shlex.quote
    s = ("export PATH=%s:\"$HOME/.local/bin:$PATH\"\nexport BROWSER=%s\n" % (q(str(shim.parent)), q(str(shim))) +
         "echo 'ייפתח דפדפן: לבחור את חשבון הגוגל של הערוץ ולאשר (Allow / המשך).'\n"
         "echo 'שאלות באנגלית בחלון הזה: על Shared Drive / Team Drive עונים n; על כל השאר — Enter.'\n"
         "rclone config reconnect gdrive:\n")
    if done_file:
        s += "echo $? > %s\n" % q(str(done_file))
    return s


# ─────────────────────────── ערכת השחזור (התיקייה ב-Drive) ───────────────────────────
KIT_FILES = ("restore_kit.py", "restore.ps1", "שחזור למחשב חדש.bat", "קרא אותי - שחזור.txt")


def kit_status(out=None):
    out = Path(out or KIT_DIR)
    try:
        k = json.loads((out / "kit" / "kit.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"exists": False}
    return {"exists": True, "version": k.get("version"), "signed": bool(k.get("signed")), "made": k.get("made"),
            "has_vault": (out / "vault.enc").is_file()}


def _git_head(repo):
    try:
        return subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception:
        return ""


def _signed_release(ver):
    """תיקיית גרסה שפורסמה וחתומה (release_work/releases/<ver>) שהחתימה שלה נבדקת — או None."""
    import make_short_release as R
    d = DATA / "release_work" / "releases" / ver
    z = d / ("code-%s.zip" % ver)
    if not ((d / "manifest.json").is_file() and (d / "manifest.sig").is_file() and z.is_file()):
        return None
    pubs = list(R.source()[1])
    try:
        import make_short_publish as P
        if P.have_key():
            pubs.append(P.public_key_b64())
    except Exception:
        pass
    raw = (d / "manifest.json").read_bytes()
    sig = (d / "manifest.sig").read_text(encoding="ascii").strip()
    for p in pubs:
        if R.ed25519_verify(base64.b64decode(p), raw, base64.b64decode(sig)):
            m = json.loads(raw.decode("utf-8"))
            if m.get("archive", {}).get("sha256") == R.sha256(z.read_bytes()):
                return d, p
    return None


def _shared_wsl_blocks(installer_text):
    blocks = {}
    for name in ("A", "B"):
        m = re.search(r"# <SHARED-WSL-%s-BEGIN>\r?\n(.*?)# <SHARED-WSL-%s-END>" % (name, name), installer_text, re.S)
        if not m:
            raise VaultError("במתקין חסר הקטע המשותף %s (SHARED-WSL) — לא בונים ערכת שחזור." % name)
        blocks[name] = m.group(1)
    return blocks


def compose_restore_ps1(repo=None):
    """restore.ps1 = התבנית + הקטעים של WSL מתוך install_windows.ps1 (אותו קוד, לא העתק שמתיישן)."""
    repo = Path(repo or REPO)
    tpl = (repo / "windows" / "restore" / "restore.ps1.txt").read_text(encoding="utf-8")
    b = _shared_wsl_blocks((repo / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig"))
    if "#<<SHARED-WSL-A>>" not in tpl or "#<<SHARED-WSL-B>>" not in tpl:
        raise VaultError("בתבנית תוכנית השחזור חסר מקום לקטעים המשותפים.")
    return tpl.replace("#<<SHARED-WSL-A>>", b["A"]).replace("#<<SHARED-WSL-B>>", b["B"])


def build_kit(repo=None, out=None, force=False, say=print):
    """בונה את תיקיית השחזור. קוד: הגרסה החתומה האחרונה שפורסמה (אם זו הגרסה המותקנת), אחרת ארכיון לא-חתום מאותה
    אריזה בדיוק (נבדקים בו גיבובים בלבד). מחזיר kit_status()."""
    import make_short_release as R
    import make_short_publish as P
    repo, out = Path(repo or REPO), Path(out or KIT_DIR)
    ver = R.installed_version(repo)
    head = _git_head(repo)
    sr = _signed_release(ver)
    cur = kit_status(out)
    try:
        old = json.loads((out / "kit" / "kit.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        old = {}
    fresh = (old.get("version") == ver and old.get("head") == head and bool(old.get("signed")) == bool(sr)
             and (out / "kit" / ("code-%s.zip" % ver)).is_file())
    if not (fresh and not force):
        stage = Path(tempfile.mkdtemp(prefix="ys_kit_", dir=str(DATA) if DATA.is_dir() else None))
        try:
            kd = stage / "kit"
            kd.mkdir()
            if sr:
                d, pub = sr
                for n in ("manifest.json", "manifest.sig", "code-%s.zip" % ver):
                    shutil.copy2(d / n, kd / n)
            else:
                pub = ""
                rd = P.build_release(repo, ver, ver, ["ערכת שחזור (לא חתומה)"], False, None, stage / "rel", None,
                                     say=lambda *_: None, include_channel=False)
                for n in ("manifest.json", "code-%s.zip" % ver):
                    shutil.copy2(rd / n, kd / n)
                shutil.rmtree(stage / "rel", ignore_errors=True)
            (kd / "kit.json").write_text(json.dumps({"format": 1, "version": ver, "head": head, "signed": bool(sr), "pub": pub,
                                                     "manifest_sha256": hashlib.sha256((kd / "manifest.json").read_bytes()).hexdigest(),
                                                     "key_id": R.key_id(pub) if pub else "", "made": time.strftime("%Y-%m-%d %H:%M"),
                                                     "archive": "kit/code-%s.zip" % ver}, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
            shutil.copy2(repo / "windows" / "restore" / "restore_kit.py", stage / "restore_kit.py")
            (stage / "restore.ps1").write_bytes(b"\xef\xbb\xbf" + compose_restore_ps1(repo).replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8"))
            bat = (repo / "windows" / "restore" / "restore.bat.txt").read_bytes()
            bat.decode("ascii")                                  # קובץ bat נשאר ASCII בלבד (cmd מקלקל UTF-8)
            (stage / "שחזור למחשב חדש.bat").write_bytes(bat.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
            (stage / "קרא אותי - שחזור.txt").write_bytes(
                b"\xef\xbb\xbf" + (repo / "windows" / "restore" / "readme.txt").read_text(encoding="utf-8").replace("\n", "\r\n").encode("utf-8"))
            sys.path.insert(0, str(repo / "windows" / "restore"))
            import restore_kit as RK
            rep = RK.verify(str(stage))
            if not rep["ok"]:
                raise VaultError("ערכת השחזור שנבנתה לא עוברת את הבדיקה של עצמה: %s" % rep["msg"])
            _scan_kit_texts(stage)
            # החלפה: התיקייה הישנה נמחקת רק אחרי שהחדשה שלמה (ואת ה-zip הישן לא משאירים — רק הגרסה האחרונה)
            if out.exists():
                shutil.rmtree(out)
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(stage), str(out))
            say("✓ ערכת שחזור: גרסה %s (%s)" % (ver, "חתומה" if sr else "לא חתומה — עוד אין גרסה מפורסמת"))
        finally:
            shutil.rmtree(stage, ignore_errors=True)
    # הכספת: העותק העדכני תמיד ליד הערכה (היא מוצפנת; הסיסמה לא שם)
    if VAULT_FILE.is_file():
        h = _header()
        if h and h.get("ct"):
            if not (out / "vault.enc").is_file() or (out / "vault.enc").read_bytes() != VAULT_FILE.read_bytes():
                shutil.copy2(VAULT_FILE, out / "vault.enc")
                os.chmod(out / "vault.enc", 0o600)
    elif (out / "vault.enc").exists():
        (out / "vault.enc").unlink()
    return kit_status(out)


def _scan_kit_texts(d):
    import make_short_share as SH
    for p in Path(d).rglob("*"):
        if p.is_file() and p.suffix in (".py", ".ps1", ".bat", ".txt", ".json"):
            b = p.read_bytes()
            if any(pt.search(b) for pt in SH.SECRET_PATTERNS):
                raise VaultError("🚨 בערכת השחזור נמצא משהו שנראה כמו סוד (%s) — לא מעלים." % p.name)


# ─────────────────────────── שורת פקודה ───────────────────────────
def _cli_restore(args):
    import getpass
    f = None
    if "--file" in args:
        f = args[args.index("--file") + 1]
    overwrite = "--overwrite" in args
    print("🔓 שחזור מהכספת")
    print("   מקלידים את סיסמת הכספת (מה שמוקלד לא מוצג על המסך — זה תקין) ולוחצים Enter.")
    print("   שכחתם? Enter ריק = לדלג. התוכנה והנתונים משוחזרים גם בלי הכספת; את Gemini ו-Modal מחברים אז ביד.")
    for attempt in range(3):
        try:
            pw = getpass.getpass("   סיסמה: ")
        except (EOFError, KeyboardInterrupt):
            pw = ""
        if not pw:
            print("   ← דילגנו על הכספת.")
            return 3
        try:
            rep = restore(pw, f, overwrite=overwrite)
        except VaultError as e:
            print("   ✗ %s" % e)
            continue
        pw = None
        for r in rep:
            word = {"restored": "שוחזר", "same": "כבר היה (זהה)", "kept": "לא הוחלף", "failed": "נכשל"}.get(r["result"], r["result"])
            print("   • %s — %s%s%s" % (r["label"], word, (" · " + r["check"]) if r.get("check") else "", (" · " + r["note"]) if r.get("note") else ""))
        return 0 if all(r["result"] != "failed" for r in rep) else 2
    print("   ✗ שלוש פעמים סיסמה שגויה — מדלגים על הכספת. אפשר להריץ שוב את תוכנית השחזור, או לשחזר מהחלון:")
    print("     הגדרות ← 🔐 כספת ושחזור ← «🔓 שחזר מהכספת».")
    return 3


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "status"
    if cmd == "status":
        s = status()
        print(json.dumps({k: s[k] for k in ("exists", "made", "items", "stale", "new", "kit")}, ensure_ascii=False, indent=1))
        return 0
    if cmd == "restore":
        return _cli_restore(argv[2:])
    if cmd == "drive-state":
        print(drive_state())
        return 0
    if cmd == "drive-login":
        return subprocess.run(["bash", "-c", drive_login_script()]).returncode
    if cmd == "kit":
        try:
            build_kit(force="--force" in argv, say=(lambda *_: None) if "--quiet" in argv else print)
        except Exception as e:                    # גם UpdateError של בניית הארכיון (סריקת סודות/זהות) — הודעה, בלי traceback
            print(_safe_msg(e), file=sys.stderr)
            return 2
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
