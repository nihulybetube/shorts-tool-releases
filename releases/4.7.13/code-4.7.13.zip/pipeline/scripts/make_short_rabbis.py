# -*- coding: utf-8 -*-
"""פרופיל לכל רב (כרטיס 25, 1/11/2026) — רק מה שכבר סוכם, לא ניתוח חדש של כל רב.

למה: הכללים לכל רב חיו אצל Claude בזיכרון ("אצל הרב כץ יש חזרות", "אצל בן שושן המצלמה מתחילה
ב-0.8/0.055", "SHORTS_SUB_GAP=1.5 לדוברים איטיים") — והתוכנה לא ידעה אותם. כאן הם נכנסים לתוכנה.

מה בפרופיל (כל שדה לא חובה):
  sub_gap          — SHORTS_SUB_GAP: כמה שניות עצירה שוברות שורת כתובית (ברירת מחדל של הפייפליין 0.30)
  dedupe_repeats   — הסרה אוטומטית של מילה שחוזרת מיד על עצמה ("הוא הוא" → "הוא"), גם מהקול (make_short_repeats)
  camera           — {"trigger_sec", "max_pan"}: face_track.TRIGGER_SEC / MAX_PAN_RATE לרב הזה בלבד
  words            — מילים ושמות שהרב הזה אומר (נכנסים להנחיית הבחירה, לעורך החכם ולרמז של התמלול)
  seen / dismissed — כמה פעמים תיקן אותו זוג אצל הרב הזה, ומה הוא סירב להוסיף (הצעה "להוסיף לפרופיל?")

איפה: ברירות המחדל (SEEDS) בקוד — נשלחות עם החבילה ואין בהן שום סוד; קובץ בתיקייה
~/.config/yeshiva-shorts/rabbis/<רב>.json נוצר רק כשהוא ערך/למד משהו (נכנס לגיבוי, לא לחבילה).
זיהוי הרב לפי השם המלא (name_key: בלי תארים/מירכאות) — "הרב יהודה מלמד" ≠ "הרב זלמן ברוך מלמד".
"""
import contextlib
import copy
import json
import os
import re
import time
from pathlib import Path

import make_short_guard as GUARD
import make_short_settings as SET
import shorts_layout as SL

DIR = Path(os.environ.get("MAKE_SHORT_RABBIS") or SET.CONFIG / "rabbis")

# ברירות מחדל שסוכמו (זיכרון הפרויקט, yeshiva-shorts-setup). אין פרופיל לפרלמן: שיעור אחד שבו עמד — לא תכונה שלו.
SEEDS = [
    {"name": "הרב חיים בן שושן", "sub_gap": 1.5, "camera": {"trigger_sec": 0.8, "max_pan": 0.055}},
    {"name": "הרב משה גנץ", "sub_gap": 1.5},
    {"name": "הרב בן ציון אוריאל", "sub_gap": 1.5},
    {"name": "הרב יוסף וייצן", "sub_gap": 1.5, "aliases": ["הרב ש. יוסף וייצן"]},
    {"name": "הרב עידו יעקובי", "sub_gap": 1.5},
    {"name": "הרב יהודה מלמד", "sub_gap": 1.5},
    {"name": "הרב חיים כץ", "sub_gap": 1.5, "dedupe_repeats": True},
]

# מילים שחוזרות בכוונה ("מאוד מאוד", "ממש ממש") — הדגשה של הרב, לא גמגום: לא נוגעים (make_short_repeats)
KEEP_REPEATS = ("מאוד", "ממש", "שוב", "הרבה", "לאט", "חזק", "רחוק", "קרוב", "עוד", "כל",
                "לא", "כן", "נכון", "נו", "מה", "למה", "איך")      # תשובות ושאלות שחוזרות הן דיבור, לא גמגום

FIELDS = ("sub_gap", "dedupe_repeats", "camera", "words")
OFFER_AT = 2          # אותו תיקון אצל אותו רב פעמיים → מציעים להוסיף לפרופיל


def key(name):
    """מפתח זיהוי: אותיות בלבד, בלי תואר ובלי ראשי תיבות בודדים ("ש." ב"הרב ש. יוסף וייצן")."""
    s = " ".join(str(name or "").split())
    s = re.sub(r"(^|\s)[א-ת][.׳']\s*", " ", s)
    return SL.name_key(s, rabbi=True)


def _file(name):
    return DIR / (re.sub(r"[^\w]+", "_", SL.clean_rabbi(name) or name or "x").strip("_") + ".json")


def _blank(name):
    return {"name": SL.clean_rabbi(name) or name, "sub_gap": None, "dedupe_repeats": False,
            "camera": {"trigger_sec": None, "max_pan": None}, "words": [], "seen": {}, "dismissed": []}


def seed_of(name):
    k = key(name)
    for s in SEEDS:
        if key(s["name"]) == k or any(key(a) == k for a in s.get("aliases", [])):
            return s
    return None


def _merge(base, over):
    out = copy.deepcopy(base)
    for f in FIELDS + ("seen", "dismissed", "name"):
        if f in over:
            out[f] = copy.deepcopy(over[f])
    cam = dict(base.get("camera") or {})
    cam.update({k: v for k, v in (over.get("camera") or {}).items()})
    out["camera"] = cam
    return out


def _read(f):
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def _stored(name):
    """הקובץ שלו (אם יש) — לפי המפתח, לא לפי שם הקובץ, כדי ששינוי כתיב קל ("הרה"ג X") ימצא את אותו קובץ."""
    k = key(name)
    if not k or not DIR.is_dir():
        return None, None
    for f in sorted(DIR.glob("*.json")):
        if f.name.endswith(".prev.json"):
            continue
        d = _read(f)
        if d and key(d.get("name")) == k:
            return f, d
    return None, None


def get(name):
    """הפרופיל בפועל (ברירת מחדל + מה שערך). None = אין לרב הזה שום פרופיל (לא ברירת מחדל ולא קובץ)."""
    if not key(name):
        return None
    seed, (f, d) = seed_of(name), _stored(name)
    if not seed and not d:
        return None
    base = _merge(_blank(seed["name"] if seed else name), seed or {})
    out = _merge(base, d) if d else base
    out["custom"] = bool(d)
    return out


def listing():
    """כל הרבנים עם פרופיל (ברירות מחדל + קבצים), לפי שם — לכרטיס ההגדרות."""
    names = {key(s["name"]): s["name"] for s in SEEDS}
    if DIR.is_dir():
        for f in DIR.glob("*.json"):
            if not f.name.endswith(".prev.json"):
                d = _read(f)
                if d and d.get("name"):
                    names.setdefault(key(d["name"]), d["name"])
    out = []
    for n in sorted(names.values()):
        p = get(n)
        if p:
            out.append(dict(p, file=bool(_stored(n)[0]), seed=bool(seed_of(n)),
                            offers=offers(n), can_undo=_prev_path(n).exists()))
    return out


def _prev_path(name):
    return _file(name).with_suffix(".prev.json")


def _write(name, data):
    GUARD.assert_not_real_config(DIR)                 # 4.1.2: בדיקה לא כותבת רבנים בתיקייה האמיתית
    DIR.mkdir(parents=True, exist_ok=True)
    f, old = _stored(name)
    f = f or _file(name)
    if old is not None:                               # שלב אחד אחורה — כמו "בטל" בשאר ההגדרות
        _prev_path(name).write_text(json.dumps(old, ensure_ascii=False, indent=1), encoding="utf-8")
    elif not _prev_path(name).exists():
        _prev_path(name).write_text(json.dumps({"_default": True}, ensure_ascii=False), encoding="utf-8")
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def _clean_num(v, lo, hi):
    if v in (None, ""):
        return None
    v = float(v)
    if not lo <= v <= hi:
        raise ValueError("ערך מחוץ לטווח (%s–%s)" % (lo, hi))
    return round(v, 3)


def save(name, fields):
    """שומר שדות (sub_gap / dedupe_repeats / camera / words) של הרב. רב חדש (בלי פרופיל) נוצר בעצמו."""
    name = SL.clean_rabbi(name)
    if not name:
        raise ValueError("צריך שם רב")
    cur = get(name) or _blank(name)
    new = {f: copy.deepcopy(cur[f]) for f in FIELDS + ("seen", "dismissed")}
    new["name"] = cur["name"]
    if "sub_gap" in fields:
        new["sub_gap"] = _clean_num(fields["sub_gap"], 0.1, 5.0)
    if "dedupe_repeats" in fields:
        new["dedupe_repeats"] = bool(fields["dedupe_repeats"])
    if "camera" in fields:
        c = fields["camera"] or {}
        new["camera"] = {"trigger_sec": _clean_num(c.get("trigger_sec"), 0.1, 5.0),
                         "max_pan": _clean_num(c.get("max_pan"), 0.01, 0.3)}
    if "words" in fields:
        new["words"] = [{"right": " ".join(str(w.get("right", "")).split())[:60],
                         "wrong": (" ".join(str(w.get("wrong") or "").split())[:60] or None)}
                        for w in fields["words"] if " ".join(str(w.get("right", "")).split())][:200]
    _write(name, new)
    return get(name)


def reset(name):
    """חוזר לברירת המחדל (קובץ נמחק; הגרסה הקודמת נשמרת ל"בטל")."""
    GUARD.assert_not_real_config(DIR)
    f, d = _stored(name)
    if f:
        _prev_path(name).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        f.unlink()
    return get(name)


def undo(name):
    GUARD.assert_not_real_config(DIR)
    p = _prev_path(name)
    if not p.exists():
        raise ValueError("אין מה לבטל")
    d = _read(p)
    f, cur = _stored(name)
    if d is None or d.get("_default"):      # הקודם = ברירת מחדל (אין קובץ)
        if f:
            f.unlink()
    else:
        (f or _file(name)).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    p.unlink()
    return get(name)


# ─────────────── מה כל חלק בתוכנה לוקח מהפרופיל ───────────────

def gap_for(name):
    p = get(name)
    return p["sub_gap"] if p and p.get("sub_gap") else None


def dedupe_on(name):
    p = get(name)
    return bool(p and p.get("dedupe_repeats"))


def camera_env(name):
    """משתני סביבה למצלמה (camera_path.apply_env קורא אותם). ריק = המצלמה הרגילה."""
    c = (get(name) or {}).get("camera") or {}
    env = {}
    if c.get("trigger_sec"):
        env["CAM_TRIGGER"] = repr(float(c["trigger_sec"]))
    if c.get("max_pan"):
        env["CAM_PAN"] = repr(float(c["max_pan"]))
    return env


def apply_gap(name):
    """קובע את build_ass.GAP_THRESHOLD לפי הרב (או חזרה לברירת המחדל של הפייפליין כשאין). נקרא בתחילת כל
    פעולה שמחלקת כתוביות; GAP_THRESHOLD הוא גלובלי של המודול, לכן תמיד מציבים במפורש — גם כשאין פרופיל."""
    import build_ass as B
    B.GAP_THRESHOLD = gap_for(name) or float(os.environ.get("SHORTS_SUB_GAP", 0.30))
    return B.GAP_THRESHOLD


def words_for(names):
    """מילים של הרבנים האלה (לפי הסדר, בלי כפילויות) — [{"right","wrong","rabbi"}]."""
    out, seen = [], set()
    for n in names:
        p = get(n)
        for w in (p or {}).get("words", []):
            k = (w["right"], w.get("wrong"))
            if k not in seen:
                seen.add(k)
                out.append(dict(w, rabbi=p["name"]))
    return out


def prompt_text(names, limit=40):
    """בלוק להנחיות (בחירה / עורך חכם): מילים ושמות שהרב הזה אומר."""
    ws = words_for(names)[:limit]
    if not ws:
        return ""
    return ("\nמילים ושמות שהרב הזה אומר (מהפרופיל שלו; כשנשמע דומה — כנראה זה הנכון):\n" +
            "\n".join("- %s%s" % (w["right"], (" (במקום \"%s\")" % w["wrong"]) if w.get("wrong") else "") for w in ws) + "\n")


def hint_words(name):
    return [w["right"] for w in words_for([name])]


# ─────────────── למידה מהתיקונים שלו ───────────────

def _pair_key(wrong, right):
    return "%s>%s" % (wrong or "", right)


def note_corrections(name, pairs, where=""):
    """pairs = [(wrong, right)] מתיקון שהוא שמר. סופר לכל רב לפי מקום ייחודי (שיעור/קליף) — שמירה חוזרת של אותו קליף
    לא נספרת פעמיים; בלי פרופיל קיים — עדיין סופר (נוצר קובץ), כך שגם רב בלי ברירת מחדל יקבל הצעה.
    לא מוסיף כלום לפרופיל לבד: ההצעה (offers) היא לחיצה שלו."""
    name = SL.clean_rabbi(name)
    if not name or not pairs:
        return 0
    p = get(name) or _blank(name)
    seen = dict(p.get("seen") or {})
    for wrong, right in pairs:
        k = _pair_key(wrong, right)
        v = seen.get(k)
        v = list(v) if isinstance(v, list) else ["?"] * int(v or 0)
        if where not in v or not where:
            v.append(where or "?%d" % len(v))
        seen[k] = v
    new = {f: copy.deepcopy(p[f]) for f in FIELDS + ("dismissed",)}
    new.update(name=p["name"], seen=seen)
    _write(name, new)
    return len(pairs)


def offers(name):
    """זוגות שתוקנו אצל הרב הזה OFFER_AT פעמים ויותר, שעוד לא בפרופיל ולא נדחו."""
    p = get(name)
    if not p:
        return []
    have = {(w["right"], w.get("wrong")) for w in p["words"]}
    out = []
    cnt = {k: (len(v) if isinstance(v, list) else int(v or 0)) for k, v in (p.get("seen") or {}).items()}
    for k, n in sorted(cnt.items(), key=lambda kv: -kv[1]):
        wrong, _, right = k.partition(">")
        if n >= OFFER_AT and (right, wrong or None) not in have and k not in p.get("dismissed", []):
            out.append({"wrong": wrong or None, "right": right, "n": n})
    return out


def answer_offer(name, wrong, right, accept):
    p = get(name)
    if not p:
        raise ValueError("אין פרופיל")
    new = {f: copy.deepcopy(p[f]) for f in FIELDS + ("seen", "dismissed")}
    new["name"] = p["name"]
    if accept:
        if not any(w["right"] == right and w.get("wrong") == (wrong or None) for w in new["words"]):
            new["words"].append({"right": right, "wrong": wrong or None})
    else:
        new["dismissed"] = list(new["dismissed"]) + [_pair_key(wrong, right)]
    _write(name, new)
    return get(name)


def view():
    return {"rabbis": listing(), "path": str(DIR), "keep_repeats": list(KEEP_REPEATS), "offer_at": OFFER_AT}


@contextlib.contextmanager
def gap_scope(name):
    """לבדיקות / שימוש חד-פעמי: מציב gap ומחזיר מה שהיה."""
    import build_ass as B
    old = B.GAP_THRESHOLD
    try:
        apply_gap(name)
        yield
    finally:
        B.GAP_THRESHOLD = old


if __name__ == "__main__":
    import sys
    for p in listing():
        print(json.dumps(p, ensure_ascii=False))
    if len(sys.argv) > 1:
        print(sys.argv[1], "→", get(sys.argv[1]))
