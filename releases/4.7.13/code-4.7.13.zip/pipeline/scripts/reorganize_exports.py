# -*- coding: utf-8 -*-
"""סידור השורטסים שכבר ייצאו למבנה החדש (כרטיס 16, 22/10/2026).

    python3 reorganize_exports.py --plan      # רק תוכנית: מה יעבור לאן — שום דבר לא זז
    python3 reorganize_exports.py --apply     # רק אחרי שהוא אישר את התוכנית!

היום:   <הרב>/<הסדרה>/<תיקיית שיעור>/shorts/clipN_<כותרת>/<קובץ>
אחרי:   <הרב>/<הסדרה>/<כותרת השורט>/<קובץ>  (+ «תיאור להעתקה.txt»)

--apply: העברה בתוך אותו דיסק (rename — לא העתקה, לא מחיקה), אימות גודל לכל קובץ, תיקיות שהתרוקנו יורדות
(רק ריקות — תיקייה שנשאר בה משהו נשארת), היומן exports.jsonl מקבל שורת "reorganize" לכל שיעור, מצב התוכנה
(make_short.json) של כל שיעור מעודכן לתיקיות החדשות, ובסוף גיבוי לדרייב עם --allow-delete = מספר הקבצים
שעברו (בדרייב: הנתיבים הישנים → הפח של הדרייב, 30 יום; החדשים עולים). שום דבר לא נמחק.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import shorts_layout as SL  # noqa: E402
from export_clips import sanitize_filename, LEDGER  # noqa: E402

ROOT = Path(os.path.expanduser(os.environ.get("SHORTS_EXPORT_DIR") or SL.ROOT_DEFAULT))
PROJECTS = Path(os.environ.get("SHORTS_PROJECTS") or os.path.expanduser("~/.local/share/yeshiva-shorts/projects"))
def _plan_out():
    """4.1.0: איפה נכתבת התוכנית — בלי שם משתמש כתוב בקוד. תיקיית yeshiva-shorts בווינדוס אם יש; אחרת תיקיית הבית."""
    name = "תוכנית סידור תיקיות.txt"
    if os.environ.get("SHORTS_PLAN_OUT"):
        return Path(os.environ["SHORTS_PLAN_OUT"])
    for d in sorted(Path("/mnt/c/Users").glob("*/yeshiva-shorts")) if Path("/mnt/c/Users").is_dir() else []:
        if d.is_dir():
            return d / name
    return Path(os.path.expanduser("~")) / name


PLAN_OUT = _plan_out()
CLIP_RE = re.compile(r"^(clip\d+)(?:_(.*))?$")
AUTO_RE = re.compile(r"^\d{4}-\d{2}-\d{2}_")            # תיקיית שיעור שהמערכת קראה לה (תאריך_slug)


def title_index():
    """כל הכותרות שהופקו אי-פעם: שם-קובץ → (פרויקט, clipN, כותרת). מהעבודה (meta.json), כולל קליפים שהוצאו
    הצידה (work/old_shorts, work/plain) — כך שגם קובץ ששמו שונה מוצא את הכותרת המלאה שלו."""
    by_stem, by_short = {}, {}
    for meta in PROJECTS.rglob("meta.json"):
        rel = meta.relative_to(PROJECTS).parts
        if "shorts" not in rel and "work" not in rel:
            continue
        try:
            d = json.loads(meta.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        t = d.get("title") or ""
        if not t:
            continue
        m = CLIP_RE.match(meta.parent.name)
        proj = rel[0] if rel[0] != "תוכנה" else "/".join(rel[:2])
        rec = (proj, m.group(1) if m else "", t)
        by_stem.setdefault(sanitize_filename(t), rec)
        by_short.setdefault(sanitize_filename(t.split("|")[0], 40), rec)
    return by_stem, by_short


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f%s" % (n, u)
        n /= 1024.0
    return "%.1fTB" % n


def build_plan():
    by_stem, by_short = title_index()
    moves, skipped, leftovers, groups, renamed, already = [], [], [], set(), [], 0
    planned = set()
    clipdirs = {}
    for f in sorted(ROOT.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in SL.VIDEO_EXT or f.name.endswith(".part"):
            continue
        rel = f.relative_to(ROOT).parts
        if len(rel) == 4 and rel[2] != "shorts":
            already += 1
            continue
        if len(rel) < 4:
            skipped.append((f, "סרטון שלא בתוך תיקיית שורט — לא יודע לאן"))
            continue
        clipdirs.setdefault(f.parent, []).append(f)
    for cd, vids in sorted(clipdirs.items()):
        rel = cd.relative_to(ROOT).parts
        rabbi, series = rel[0], rel[1]
        heads = {v.stem.split("   ")[0] for v in vids}
        if len(vids) > 1 and len(heads) > 1:
            skipped.append((cd, "יש בה %d סרטונים בשמות שונים — לא יודע איזה הוא השורט" % len(vids)))
            continue
        f = min(vids, key=lambda v: len(v.name))       # שתי גרסאות של אותו שורט (למשל "- ללא מוזיקה") — עוברות יחד
        m = CLIP_RE.match(cd.name)
        rec = by_stem.get(f.stem) or (by_short.get(m.group(2)) if m and m.group(2) else None)
        # הכותרת = מה שכתוב בשם הקובץ ("כותרת   הרב X") — גם כשהוא שינה אותו בעצמו לכותרת שהעלה ליוטיוב.
        # שם קובץ בלי הדפוס הזה ("בוצע כבר.mp4" — סימון שלו) → הכותרת מהעבודה, השם שלו נשאר
        if "   " in f.stem:
            title = f.stem.split("   ")[0]
        else:
            title = rec[2] if rec else (m.group(2) if m and m.group(2) else cd.name)
            if rec:
                renamed.append((f, rec[2]))
        mid = rel[2:-1]
        lesson = ROOT.joinpath(*rel[:2 + mid.index("shorts")]) if "shorts" in mid else cd.parent
        for g in mid:
            if g != "shorts" and not CLIP_RE.match(g) and not AUTO_RE.match(g) and ROOT.joinpath(*rel[:rel.index(g) + 1]) != lesson:
                groups.add(ROOT.joinpath(*rel[:rel.index(g) + 1]))
        sdir = ROOT / rabbi / series
        base = SL.folder_name(title, f.name, sdir)
        for i in range(1, 100):
            tgt = sdir / (base if i == 1 else "%s (%d)" % (base, i))
            if str(tgt) not in planned and not tgt.exists():
                break
        planned.add(str(tgt))
        files = list(vids) + [x for x in cd.iterdir() if x.is_file() and x.name == SL.DESC_FILE]
        for x in cd.iterdir():
            if x.is_file() and x not in files:
                leftovers.append(x)
        moves.append({"from": cd, "to": tgt, "files": files, "title": title, "lesson": lesson,
                      "clip": m.group(1) if m else "", "project": rec[0] if rec else "",
                      "bytes": sum(x.stat().st_size for x in files)})
    # קבצים שלא בתוך תיקיית שורט (gemini/, "מה יש כאן.txt") — נשארים במקום
    moving = {x for mv in moves for x in mv["files"]}
    for x in sorted(ROOT.rglob("*")):
        if x.is_file() and x not in moving and x not in leftovers and x.suffix.lower() not in SL.VIDEO_EXT:
            rel = x.relative_to(ROOT).parts
            if not (len(rel) == 4 and rel[2] != "shorts"):
                leftovers.append(x)
    return {"moves": moves, "skipped": skipped, "leftovers": leftovers, "groups": sorted(groups),
            "renamed": renamed, "already": already}


def r(p):
    return str(Path(p).relative_to(ROOT)).replace("/", " › ")


def write_plan(plan, out):
    mv = plan["moves"]
    nfiles = sum(len(m["files"]) for m in mv)
    L = ["תוכנית סידור תיקיות — השורטסים המוכנים",
         "נוצרה: %s   (שום דבר עוד לא זז — זו רק תוכנית)" % datetime.now().strftime("%d/%m/%Y %H:%M"),
         "",
         "מה ישתנה: כל שורט יעבור לתיקייה משלו בשם הכותרת, ישר בתוך תיקיית הסדרה:",
         "   הרב › סדרה › כותרת השורט › (הסרטון + «תיאור להעתקה.txt»)",
         "במקום היום: הרב › סדרה › תיקיית שיעור › shorts › clip1_כותרת › הסרטון",
         "שם התיקייה = הכותרת שבשם הקובץ (גם אם שינית אותה בעצמך). שמות הקבצים עצמם לא משתנים.",
         "",
         "• %d שורטסים יעברו (%d קבצים, %s). העברה בתוך אותו דיסק — שום דבר לא נמחק ולא מועתק."
         % (len(mv), nfiles, human(sum(m["bytes"] for m in mv))),
         "• תיקיות שיישארו ריקות אחרי ההעברה — יורדות. תיקייה שנשאר בה משהו — נשארת.",
         "• בגוגל דרייב: %d הקבצים בנתיבים הישנים יעברו לפח של הדרייב (נשמרים שם 30 יום), ואותם קבצים"
         " יעלו בנתיבים החדשים — העלאה של כ-%s." % (nfiles, human(sum(m["bytes"] for m in mv))),
         "• התוכנה ו-Claude ימשיכו למצוא כל שורט (שמירה חוזרת, החלפת מנגינה, ויתור) — הרישום שלהם מתעדכן.",
         ]
    if plan["already"]:
        L.append("• %d שורטסים כבר במבנה החדש — לא נוגעים בהם." % plan["already"])
    L += ["", "=" * 60, ""]
    cur = None
    for m in sorted(mv, key=lambda m: (str(m["to"].parent), m["to"].name)):
        head = r(m["to"].parent)
        if head != cur:
            L += ["", "📁 " + head]
            cur = head
        L.append("   ✦ %s" % m["to"].name)
        L.append("        היה ב: %s" % r(m["from"]))
    if plan["groups"]:
        L += ["", "=" * 60, "", "⚠️ תיקיות שסידרת בעצמך — אחרי ההעברה השורטסים שבהן יהיו ישר בתיקיית הסדרה:"]
        for g in plan["groups"]:
            L.append("   • " + r(g))
        L.append("   (אם אתה רוצה לשמור את החלוקה הזאת — תגיד, ואשאיר אותן כתת-תיקיות.)")
    if plan["renamed"]:
        L += ["", "✏️ קבצים שהשם שלהם אינו כותרת (סימנת אותם בעצמך) — שם הקובץ נשאר, התיקייה מקבלת את הכותרת המקורית:"]
        for f, t in plan["renamed"]:
            L.append("   • «%s» ← הכותרת: %s" % (f.name, t.split("|")[0].strip()))
    if plan["leftovers"]:
        L += ["", "📎 קבצים שאינם שורט — נשארים בדיוק איפה שהם (ולכן גם התיקייה שלהם נשארת):"]
        for x in plan["leftovers"]:
            note = "  (שארית של מיקס מוזיקה — לא עולה לדרייב; אפשר למחוק אם תרצה)" if x.suffix in (".wav", ".raw") else ""
            L.append("   • %s%s" % (r(x), note))
    if plan["skipped"]:
        L += ["", "❓ לא ידעתי לשבץ — נשארים במקום:"]
        for x, why in plan["skipped"]:
            L.append("   • %s — %s" % (r(x), why))
    L += ["", "=" * 60, "",
          "כדי לבצע: תכתוב לי בצ'אט \"מאשר את סידור התיקיות\". בלי האישור שלך שום דבר לא זז.", ""]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(L), encoding="utf-8-sig")
    return out


def apply(plan):
    done, bad = [], []
    for m in plan["moves"]:
        m["to"].mkdir(parents=True, exist_ok=False)
        for f in m["files"]:
            size = f.stat().st_size
            dst = m["to"] / f.name
            if dst.exists():
                bad.append("%s — כבר קיים ביעד" % dst)
                continue
            os.rename(f, dst)                         # אותו דיסק — שינוי שם, לא העתקה
            if not dst.exists() or dst.stat().st_size != size:
                bad.append("%s — גודל לא תואם" % dst)
        done.append(m)
        SL.prune_empty(m["from"], ROOT)
    # יומן + מצב התוכנה
    per_lesson = {}
    for m in done:
        per_lesson.setdefault(str(m["lesson"]), []).append(m)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with LEDGER.open("a", encoding="utf-8") as fh:
        for lesson, ms in per_lesson.items():
            proj = next((x["project"] for x in ms if x["project"]), "")
            fh.write(json.dumps({"at": now, "event": "reorganize", "project": proj.split("/")[-1], "layout": "short",
                                 "moved_from": lesson, "target": str(ms[0]["to"].parent),
                                 "clips": {x["clip"]: str(x["to"]) for x in ms if x["clip"]}},
                                ensure_ascii=False) + "\n")
    states = 0
    for stf in (PROJECTS / "תוכנה").glob("*/make_short.json"):
        try:
            st = json.loads(stf.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        ms = per_lesson.get(str(st.get("export_target") or ""))
        if not ms:
            continue
        st["export_dirs"] = {x["clip"]: str(x["to"]) for x in ms if x["clip"]}
        st["export_target"] = str(ms[0]["to"].parent)
        st["export_layout"] = "short"
        tmp = stf.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(stf)
        states += 1
    nfiles = sum(len(m["files"]) for m in done)
    print("✓ הועברו %d שורטסים (%d קבצים); %d שיעורים של התוכנה עודכנו" % (len(done), nfiles, states))
    for b in bad:
        print("✗ " + b)
    if os.environ.get("REORG_NO_DRIVE") == "1":       # בדיקות בלבד
        print("(בדיקה: בלי גיבוי לדרייב)")
        return 1 if bad else 0
    print("☁ גיבוי לדרייב (הישנים לפח של הדרייב, החדשים עולים) — --allow-delete %d" % nfiles)
    rc = subprocess.run(["bash", str(HERE.parent.parent / "drive_backup.sh"), "--allow-delete", str(nfiles)]).returncode
    print("גיבוי: %s" % ("✓" if rc == 0 else "קוד %d — להריץ שוב drive_backup.sh מאוחר יותר" % rc))
    return 1 if bad else 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--plan", action="store_true")
    g.add_argument("--apply", action="store_true")
    ap.add_argument("--out", default=str(PLAN_OUT))
    a = ap.parse_args()
    plan = build_plan()
    if a.plan:
        out = write_plan(plan, Path(a.out))
        print("תוכנית: %d שורטסים יעברו, %d נשארים במקום, %d לא שובצו → %s"
              % (len(plan["moves"]), len(plan["leftovers"]), len(plan["skipped"]), out))
        return 0
    return apply(plan)


if __name__ == "__main__":
    raise SystemExit(main())
