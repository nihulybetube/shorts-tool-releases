# -*- coding: utf-8 -*-
"""
בונה את הגרסה ה"נקייה" (בלי כתוביות) של קליפ:
ייצוב תמונה (vidstab, מנותח על ה-raw המקורי) -> חיתוך-רך של שקטים
(crossfade עדין, לא קאט קשה) -> קרופ ל-9:16 -> לוגו בפינה שמאלית עליונה.
הכל במעבר קידוד אחד כדי למנוע איבוד איכות מצטבר.

חשוב: הייצוב תמיד רץ על ה-raw *לפני* החיתוך, לא אחריו - ניתוח תנועה על
קטעים עם crossfade מבלבל את האלגוריתם ומייצר טשטוש/קפיצות.
"""
import os
import subprocess
import sys
sys.path.insert(0, ".")
from smooth_cut import compute_keep_segments, get_duration as _duration

XFADE_DUR = 0.18       # משך מעבר הדיסולב בין קטעים
LOGO_WIDTH = 252         # רוחב הלוגו על גבי 1080px (180% מ-140, לבקשת המשתמש)
LOGO_MARGIN = 40         # מרחק מהקצוות
# 🚨 הילה לבנה אחידה סביב הלוגו (בחירת המשתמש, 24/9/2026, "אפשרות 3 — הילה עדינה אחידה").
# על רקע כהה (וילון, ארון קודש) הכיתוב "קרית הישיבה בית אל" נבלע. ההילה בנויה מצורת
# הלוגו עצמו (ערוץ השקיפות): מרחיבים אותה (dilation) עד שהרווחים בין האותיות נסגרים,
# מטשטשים, וצובעים לבן — כך הכול, כולל הכיתוב, מקבל זוהר שווה. נדחו: זוהר מטושטש בלבד
# (חלש מדי על הכיתוב), קו צמוד לכל אות, והילה חזקה ("נראה כמו מדבקה").
# SHORTS_LOGO_GLOW=0 מכבה.
LOGO_GLOW_PAD = 40        # מרווח שקוף סביב הלוגו כדי שההילה לא תיחתך
LOGO_GLOW_DILATE = 12     # מעברי הרחבה של 1px — סוגרים את הרווחים בין האותיות
LOGO_GLOW_BLUR = 12       # רדיוס הטשטוש
LOGO_GLOW_GAIN = 0.8      # עוצמה. 29/9/2026 הוא ביקש שקופה יותר ובחר 0.8 מתוך 1.1/0.8/0.6/0.45
                          # (ב-0.45 הכיתוב נבלע שוב על וילון כהה; 1.8 נראה כמו מדבקה)


def _logo_chain(logo_in, out_label, base_label, side="left", glow=None, sfx=""):
    """מחרוזת filter שמניחה את הלוגו (עם ההילה, אם פעילה) על base_label.

    side: "left" (כמו תמיד) או "right" — אותם שוליים, במראה (21/10/2026: הוא ביקש סמל
    שני בפינה הימנית). glow: גודל ההילה (1 = היום); None = מ-SHORTS_LOGO_GLOW_SCALE.
    sfx: סיומת לתוויות הפנימיות, כדי ששני לוגואים ייכנסו לאותו filter בלי התנגשות.
    לוגו שמאלי בלי סיומת נותן בדיוק את המחרוזת של פעם (נבדק פיקסל-פיקסל)."""
    m, w = LOGO_MARGIN, LOGO_WIDTH
    # SHORTS_LOGO_GLOW_SCALE: גודל ההילה ביחס לנבחר (1 = היום). נוסף 20/10/2026 ל"הגדרות
    # מתקדמות" של make_short_app — הוא רוצה לכוון אותה בעצמו. 0 = בלי הילה.
    scale = glow
    if scale is None:
        try:
            scale = float(os.environ.get("SHORTS_LOGO_GLOW_SCALE", "1"))
        except ValueError:
            scale = 1.0

    def x(pad=0):          # מיקום אופקי של שכבה ברוחב הלוגו + 2*pad
        if side == "right":
            return f"main_w-overlay_w-{m}+{pad}" if pad else f"main_w-overlay_w-{m}"
        return f"{m}-{pad}" if pad else f"{m}"
    if os.environ.get("SHORTS_LOGO_GLOW", "1") == "0" or scale <= 0.04:
        return (f"[{logo_in}]scale={w}:-1[lg{sfx}];"
                f"[{base_label}][lg{sfx}]overlay={x()}:{m}[{out_label}]")
    dilate = max(1, round(LOGO_GLOW_DILATE * scale))
    blur = max(1, round(LOGO_GLOW_BLUR * scale))
    p = max(LOGO_GLOW_PAD, dilate + 2 * blur + 8)       # שההילה הגדולה לא תיחתך בשוליים
    dil = ",".join(["dilation"] * dilate)
    return (f"[{logo_in}]scale={w}:-1,format=rgba,pad=iw+2*{p}:ih+2*{p}:{p}:{p}:color=black@0,"
            f"split=3[lgp{sfx}][ga{sfx}][gw{sfx}];"
            f"[ga{sfx}]alphaextract,{dil},boxblur={blur}:2,"
            f"lut=y=min(255\\,val*{LOGO_GLOW_GAIN})[gmask{sfx}];"
            f"[gw{sfx}]lutrgb=r=255:g=255:b=255[gwhite{sfx}];"
            f"[gwhite{sfx}][gmask{sfx}]alphamerge[glow{sfx}];"
            f"[{base_label}][glow{sfx}]overlay={x(p)}:{m}-{p}[gbase{sfx}];"
            f"[gbase{sfx}][lgp{sfx}]overlay={x(p)}:{m}-{p}[{out_label}]")


def logos_chain(logos, first_input, out_label, base_label):
    """כמה לוגואים במעבר אחד. logos = [(נתיב, "left"/"right", הילה)], הקלטים שלהם
    ב-ffmpeg הם first_input, first_input+1, ... (באותו סדר). לוגו אחד = _logo_chain הרגיל."""
    parts, cur = [], base_label
    for i, (_, side, glow) in enumerate(logos):
        last = i == len(logos) - 1
        nxt = out_label if last else f"lgo{i}"
        parts.append(_logo_chain(f"{first_input + i}:v", nxt, cur, side, glow, "" if i == 0 else f"_{i}"))
        cur = nxt
    return ";".join(parts)


def _raw_to_edited(t, segments, xfade=XFADE_DUR):
    """ממפה זמן ב-raw לזמן בטיימליין הערוך (אחרי חיתוך שקטים ו-xfade)."""
    elapsed = 0.0
    for i, (a, b) in enumerate(segments):
        if t < a:                       # נפל בתוך שקט שהוסר -> תחילת הקטע הבא
            return max(0.0, elapsed - (xfade if i else 0.0))
        if t <= b:
            off = elapsed + (t - a)
            return max(0.0, off - (xfade * i))
        elapsed += (b - a)
    return max(0.0, elapsed - xfade * max(0, len(segments) - 1))


def _centering_expr(raw_path, segments, out_w=1080, subject_x=0.5):
    """
    מריץ את מעקב-המרכז על ה-raw וממיר את התוצאה לביטוי x עבור crop
    בטיימליין הערוך. אם המעקב נכשל - חוזרים לקרופ מרכזי רגיל.

    שתי שיטות, לפי סדר עדיפות:
    1. **מעקב פנים** (`face_track`, YuNet) — ממרכז את הראש. זו השיטה הנכונה.
    2. מעקב תנועה (`center_track`) — נפילה לאחור כשאין מודל/cv2, או כשהזיהוי
       נכשל ברוב הדגימות. הוא מודד את מרכז ה**תנועה**, שאצל דובר שמדבר עם
       הידיים הוא הידיים ולא הפנים. ראה את ההסבר ב-`face_track.py`.
    """
    try:
        import face_track as FT
        res = FT.track_faces(raw_path)
    except Exception:
        res = None
    if res and res.get("nodes"):
        nodes = [(_raw_to_edited(t, segments), v) for t, v in res["nodes"]]
        # אחרי חיתוך שקטים כמה נקודות עלולות ליפול על אותו זמן — משאירים
        # את האחרונה, אחרת האינטרפולציה מקבלת span אפסי וקופצת.
        dedup = []
        for t, v in nodes:
            if dedup and t <= dedup[-1][0] + 0.02:
                dedup[-1] = (t, v)
            else:
                dedup.append((t, v))
        if dedup:
            dedup[0] = (0.0, dedup[0][1])
        return FT.crop_x_expr(dedup, out_w=out_w, subject_x=subject_x), \
            [{"start": t, "center": round(v, 4)} for t, v in dedup]

    try:
        import center_track as CT
    except Exception:
        return None, None
    try:
        wins, _ = CT.track(raw_path, window=10.0)
        runs = CT.build_runs(wins, path=raw_path, window=10.0)
    except Exception:
        return None, None
    if not runs:
        return None, None

    edited = []
    for r in runs:
        er = dict(r)
        er["start"] = round(_raw_to_edited(r["start"], segments), 2)
        edited.append(er)
    # מיזוג ריצות שנמעכו לאותו זמן אחרי החיתוך
    merged = []
    for r in edited:
        if merged and r["start"] <= merged[-1]["start"] + 0.05:
            merged[-1] = r
        else:
            merged.append(r)
    if merged:
        merged[0]["start"] = 0.0
    return CT.crop_x_expr(merged, out_w=out_w, subject_x=subject_x), merged


FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
_VIDSTAB = None


def has_vidstab():
    """האם ל-ffmpeg שבמכונה הזאת יש vidstab.

    🚨 זה לא נבדק פעם אחת בהתקנה אלא כאן, כי `brew install ffmpeg` ובניות
    לינוקס של הפצות **אינן** כוללות אותו כברירת מחדל, וההודעה שמתקבלת
    בלעדיו היא `No such filter: 'vidstabdetect'` באמצע ריצה של 40 דקות —
    שנראית כמו באג בפייפליין ואינה. בלי ייצוב הקליף עדיין תקין.
    """
    global _VIDSTAB
    if _VIDSTAB is None:
        try:
            out = subprocess.run([FFMPEG, "-hide_banner", "-filters"],
                                 capture_output=True, text=True).stdout
        except OSError:
            out = ""
        _VIDSTAB = "vidstabdetect" in out and "vidstabtransform" in out
    return _VIDSTAB


def build_clean(raw_path, trf_path, output_path, logo_path=None, center=True,
                reuse_trf=True, subject_x=0.5, cut_silence=True, segments=None,
                stabilize=None, preview=None, preview_at=0.0):
    """`subject_x` — מיקום הדובר ברוחב הפריים (0=שמאל, 1=ימין). ראה
    `center_track.crop_x_expr`: דובר שפונה הצידה צריך מרחב מבט לפניו.

    `cut_silence=False` — **בלי חיתוך שקטים בכלל**. הקליף יוצא רציף,
    בדיוק כמו ה-raw, רק מיוצב וחתוך ל-9:16.

    🚨 למה זה קיים (26/8/2026, תלונה של המשתמש על קליפי הרב חיים בן שושן):
    *"דילוגים באמצע סרטון שמאבדים תוכן חשוב"*. `compute_keep_segments`
    חותך כל שקט מעל 0.9ש' ומחבר ב-crossfade של 0.18ש'. אצל דובר שנושם
    בין משפטים זה עשרות חיתוכים בדקה, וכל אחד מהם אוכל את ה-onset של
    המילה שאחריו. בקליף של דקה החיסכון הוא כמה שניות — והמחיר הוא תוכן.
    **בקליפים קצרים ברירת המחדל צריכה להיות בלי חיתוך.**

    `segments` — רשימת (התחלה, סוף) מפורשת בזמן ה-raw, שגוברת על שתי
    האפשרויות. זה לא "חיתוך שקטים אוטומטי" אלא **החלטת עריכה מודעת**:
    המקום היחיד שבו הוא נחוץ הוא קטע שבאמת אי אפשר לתמלל (ארבע שמיעות
    עצמאיות שכולן חלוקות), שבו כתובית תהיה ניחוש והיעדר כתובית ייראה
    כמו תקלה. חותכים בתוך שתיקה, לא באמצע מילה."""
    # שלב 1: ניתוח יציבות בלבד (זול - בלי קידוד וידאו) - תמיד על ה-RAW.
    # ה-trf תלוי אך ורק ב-raw, ולכן כשבונים מחדש אחרי שינוי בחיתוך השקטים
    # אפשר לעשות בו שימוש חוזר במקום לנתח שוב (זה החלק האיטי של השלב).
    # 🚨 ייצוב על צילום מחצובה מזיז את כל התמונה (16/9/2026). vidstab מפרש
    # תנועות ידיים וגוף של הדובר כרעידת מצלמה ו"מתקן" אותן. נמדד בקיר ברקע:
    # עם ייצוב — קפיצות עד 131px ונדידה של 557px; בלי — 0.2px. זה מה שנראה
    # כמו "מצלמה שזזה מהר מדי" גם כשמעקב הפנים עצמו היה נעול לגמרי.
    # SHORTS_STABILIZE=0 בהגדרות מכבה; להדליק רק למקור שבאמת צולם ביד.
    if stabilize is None:
        stabilize = os.environ.get("SHORTS_STABILIZE", "1") != "0"
    if stabilize and not has_vidstab():
        print("⚠️  ל-ffmpeg הזה אין vidstab — מדלג על הייצוב. הקליף ייצא תקין, "
              "רק פחות יציב אם המקור רועד. ffmpeg עם vidstab: install.sh")
        stabilize = False
    if stabilize and not (reuse_trf and os.path.exists(trf_path)
                          and os.path.getsize(trf_path) > 0):
        subprocess.run(
            [FFMPEG, "-y", "-i", raw_path, "-vf",
             f"vidstabdetect=shakiness=6:accuracy=15:result={trf_path}",
             "-f", "null", "-"],
            check=True, capture_output=True
        )

    if segments is not None:
        segments = [tuple(x) for x in segments]
    elif cut_silence:
        segments = compute_keep_segments(raw_path)
    else:
        # קטע יחיד = הקליף כולו. שאר הפייפליין (מיפוי זמנים, xfade) מטפל
        # בזה נכון כמקרה פרטי — n==1 מדלג על שרשרת ה-xfade לגמרי.
        segments = [(0.0, _duration(raw_path))]
    n = len(segments)

    inputs = ["-i", raw_path]
    if stabilize:
        parts = [f"[0:v]vidstabtransform=input={trf_path}:zoom=0:smoothing=15:crop=black[stab];"]
    else:
        # null במקום הייצוב: שאר הגרף ממשיך לקרוא [stab] בלי תנאים בכל שורה.
        parts = ["[0:v]null[stab];"]
    for i, (a, b) in enumerate(segments):
        parts.append(f"[stab]trim={a}:{b},setpts=PTS-STARTPTS[v{i}];")
        parts.append(f"[0:a]atrim={a}:{b},asetpts=PTS-STARTPTS[a{i}];")

    cur_v, cur_a = "v0", "a0"
    if n == 1:
        pass
    else:
        cur_dur = segments[0][1] - segments[0][0]
        for i in range(1, n):
            seg_dur = segments[i][1] - segments[i][0]
            offset = max(0.0, cur_dur - XFADE_DUR)
            nv, na = f"vx{i}", f"ax{i}"
            parts.append(f"[{cur_v}][v{i}]xfade=transition=fade:duration={XFADE_DUR}:offset={offset:.3f}[{nv}];")
            parts.append(f"[{cur_a}][a{i}]acrossfade=d={XFADE_DUR}[{na}];")
            cur_v, cur_a = nv, na
            cur_dur = cur_dur - XFADE_DUR + seg_dur

    # קרופ 9:16 שממורכז על הדובר. ברוב השיעורים הדובר לא יושב במרכז
    # הפריים, וקרופ-מרכז "עיוור" חותך אותו לצד. הביטוי נבנה מטיימליין ערוך,
    # נעול כל עוד המיסגור לא השתנה (בדיקה כל 10 שניות).
    #
    # `flags=lanczos` נוסף כשיפור להגדלה (המקור הוא שידור חי חלש, וכל
    # הגדלה עולה באיכות). **הוא לא פותר את הפגם של clip3** - שם נצרבים
    # על המצח כתמים בהירים "שרופים", והם חוזרים גם עם lanczos. הפגם נולד
    # איפשהו בפונקציה הזאת: הפריים הגולמי נקי, ושרשור ידני של אותו
    # ייצוב+scale+crop יוצא נקי - אבל הפלט של build_clean פגום. עוד לא
    # מבודד. אל תסמוך על הקומנט הזה כאילו הבעיה נסגרה.
    crop_expr, crop_runs = (_centering_expr(raw_path, segments, subject_x=subject_x)
                            if center else (None, None))
    if crop_expr:
        parts.append(
            f"[{cur_v}]scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,"
            # ב-ffmpeg 8 אין יותר eval=frame ב-crop: x/y מסומנים 'T'
            # (tunable) ומחושבים מחדש בכל פריים ממילא.
            f"crop=1080:1920:x='{crop_expr}':y=0[cropped];"
        )
    else:
        parts.append(f"[{cur_v}]scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920[cropped];")

    if logo_path:
        inputs += ["-i", logo_path]
        parts.append(f"[1:v]scale={LOGO_WIDTH}:-1[logo];")
        parts.append(f"[cropped][logo]overlay={LOGO_MARGIN}:{LOGO_MARGIN}[outv]")
    else:
        # מחליף את התג האחרון כדי שיהיה [outv]
        parts[-1] = parts[-1].replace("[cropped];", "[outv]")

    # preview = שניות: תצוגה מקדימה של מצלמה (21/10/2026, "הגדרות מהירות") — אותו מסלול מצלמה
    # בדיוק, רק ההתחלה, ברזולוציה נמוכה ובקידוד מהיר, כדי שיחזור בשניות ולא בדקות
    if preview:
        parts[-1] = parts[-1].replace("[outv]", ",scale=540:960[outv]").replace("[cropped];", ",scale=540:960[outv]")
    filter_complex = "".join(parts)
    # preview_at (28/10/2026, כרטיס 22): תצוגה שמתחילה ברגע שבו הרב יוצא מהמסגרת. -ss אחרי הקלט =
    # מפענחים ומדלגים, כך שזמן t של ביטוי המצלמה נשאר זמן הקליף האמיתי
    enc = ((["-ss", f"{float(preview_at):.2f}"] if preview_at else []) +
           ["-t", f"{float(preview):.2f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "26"] if preview
           else ["-c:v", "libx264", "-preset", "medium", "-crf", "16"])
    cmd = [
        FFMPEG, "-y", *inputs,
        "-filter_complex", filter_complex,
        "-map", "[outv]", "-map", f"[{cur_a}]",
        *enc, "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        output_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return {"segments": segments, "centering": crop_runs}


def _filter_path(p):
    """מכין נתיב להטמעה בתוך filter_complex של ffmpeg.

    נתיב ווינדוס מוחלט שובר את המנתח: ב-`fontsdir=C:\\Users\\...` הנקודתיים
    נקראת כמפריד-אפשרויות והלוכסנים ההפוכים נבלעים כתווי בריחה, כך שהערך
    הערך הגיע מרוקן מהלוכסנים ו-ffmpeg נפל על "No option name".

    הבריחה חייבת להיות **כפולה** (`C\\\\:/Users/...`, שני לוכסנים ממשיים)
    כי ffmpeg מפרק את המחרוזת בשני מפלסים: קודם הפילטר-גרף מפצל על ':',
    ואז ערך האפשרות עצמו עובר הסרת-בריחה. לוכסן בודד נאכל במפלס הראשון
    ו-ffmpeg עדיין נופל. נבדק בפועל על שלושת הווריאנטים.
    """
    return p.replace("\\", "/").replace(":", r"\\:").replace("'", r"\\'")


def burn_subtitles(clean_path, ass_path, output_path, fonts_dir, logo_path=None, logos=None):
    """צורב כתוביות + לוגו במעבר קידוד אחד.

    **כאן מקומו של הלוגו, לא ב-build_clean.** ב-build_clean הוא נצרב לפני
    שלב הכתוביות, ולכן כל תיקון בלוגו חייב חיתוך מחדש של הווידאו - מה
    שמזיז את הטיימינג ושובר את יישור הכתוביות. הפרמטר `logo_path` של
    build_clean נשמר לתאימות אחורה בלבד; אל תעביר אותו בשני המקומות.
    הלוגו מורכב *אחרי* ה-ass כדי שכתובית לא תעבור מעליו.
    logos (21/10/2026) = [(נתיב, "left"/"right", הילה)] — עד שני סמלים, אחד בכל פינה.
    """
    ass_f, fonts_f = _filter_path(ass_path), _filter_path(fonts_dir)
    if logos:
        fc = (f"[0:v]ass={ass_f}:fontsdir={fonts_f}[sub];"
              + logos_chain(logos, 1, "outv", "sub"))
        cmd = ["ffmpeg", "-y", "-i", clean_path]
        for lp, _, _ in logos:
            cmd += ["-i", lp]
        cmd += ["-filter_complex", fc, "-map", "[outv]", "-map", "0:a"]
    elif logo_path:
        fc = (f"[0:v]ass={ass_f}:fontsdir={fonts_f}[sub];"
              + _logo_chain("1:v", "outv", "sub"))
        cmd = ["ffmpeg", "-y", "-i", clean_path, "-i", logo_path,
               "-filter_complex", fc, "-map", "[outv]", "-map", "0:a"]
    else:
        cmd = ["ffmpeg", "-y", "-i", clean_path,
               "-vf", f"ass={ass_f}:fontsdir={fonts_f}"]
    cmd += [
        "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        output_path,
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
    if res.returncode != 0:
        # בלי זה הכישלון חוזר כקוד יציאה עירום ו-stderr של ffmpeg נבלע
        tail = "\n".join((res.stderr or "").strip().splitlines()[-12:])
        raise RuntimeError(f"ffmpeg burn failed ({res.returncode}):\n{tail}")
