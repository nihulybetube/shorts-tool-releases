# -*- coding: utf-8 -*-
"""
make_short_music.py — ניהול ספריית המוזיקה מתוך החלון (20/10/2026).

הוא רוצה לשמוע, להסיר ולהוסיף מנגינות בעצמו. הכול הפיך:
  הסר   → ה-mp3 וקובץ הרישיון עוברים ל-music/_rejected, ונרשם דירוג "לא" (rate --bad).
  החזר  → חוזרים ל-tracks/, והדירוג שנרשם בהסרה נמחק — המנגינה בדיוק כמו קודם.
  הוסף  → mp3 שהעלה + שורת קרדיט שכתב → <שם>.mp3.license.json + שורה ב-index.json.
          מנגינה חדשה נכנסת לבחירה האוטומטית רק אחרי "אשר" (או אחרי שבחר בה ידנית בשורט
          ושמע אותה) — כמו הכלל של pick_track: רק מה שכבר נשמע בשורט אמיתי.
"""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

import music_library as ML

REMOVE_NOTE = "הוסר מהחלון"


def _idx():
    return ML.load_index()


def _find(idx, uuid):
    for t in idx.get("tracks", []):
        if t.get("uuid") == uuid:
            return t
    raise ValueError("המנגינה לא נמצאה")


def rejected_dir():
    return ML.data_dir() / "_rejected"


# ─────────────── ❤ לייק · נשמע · מושבת (22/10/2026, כרטיס 13) ───────────────
# כולם במשוב שלו (music-feedback.json), לא באינדקס: זה הטעם שלו, וחבילת השיתוף לא לוקחת את המשוב —
# המקבל מתחיל בלי לייקים, בלי "נשמע" ובלי השבתות.
#   ❤   = דירוג "good" עם הערה LIKE_NOTE (אותו מאגר דירוגים; לייק = +1 בניקוד, וביטול מוחק רק אותו)
#   נשמע = heard_at (שמע את התצוגה ≥5 ש' / שורט ששמר) או שימוש בשורט אחרי האיפוס האחרון
#   מושבת = disabled: נשאר ברשימה ובמקום, אבל לא נבחר לבד ולא מוצע ב-‹ ›
LIKE_NOTE = "❤ לייק מהחלון"


def _fb_entry(fb, uuid):
    return fb.setdefault("tracks", {}).setdefault(uuid, {"uses": [], "ratings": []})


def liked(fb, uuid):
    return any(r.get("note") == LIKE_NOTE for r in fb.get("tracks", {}).get(uuid, {}).get("ratings", []))


def heard(fb, uuid):
    """שמע אותה: heard_at, או שימוש בשורט מאז "איפוס הלייקים" / "לא שמעתי" ידני."""
    e = fb.get("tracks", {}).get(uuid, {})
    if e.get("heard_at"):
        return True
    since = max(fb.get("heard_reset_at", ""), e.get("heard_cleared_at", ""))
    return any(u.get("at", "") > since for u in e.get("uses", []))


def disabled(fb, uuid):
    return bool(fb.get("tracks", {}).get(uuid, {}).get("disabled"))


def set_like(uuid, on=True):
    _find(_idx(), uuid)
    fb = ML.load_feedback()
    e = _fb_entry(fb, uuid)
    e["ratings"] = [r for r in e.get("ratings", []) if r.get("note") != LIKE_NOTE]
    if on:
        e["ratings"].append({"at": ML.now(), "verdict": "good", "note": LIKE_NOTE, "clip": "", "used_at": ""})
        e.setdefault("heard_at", ML.now())           # לייק = שמע אותה
    ML.save_json(ML.feedback_path(), fb)


def set_heard(uuid, on=True):
    _find(_idx(), uuid)
    fb = ML.load_feedback()
    e = _fb_entry(fb, uuid)
    if on:
        e.setdefault("heard_at", ML.now())
    else:                                            # "לא שמעתי" — גם שימושים ישנים לא נספרים יותר
        e.pop("heard_at", None)
        e["heard_cleared_at"] = ML.now()
    ML.save_json(ML.feedback_path(), fb)


def mark_heard_many(uuids):
    """שורט נשמר → המנגינות שבו נשמעו (גם במצב בדיקה, שבו "used" לא נרשם)."""
    uuids = [u for u in uuids if u]
    if not uuids:
        return
    fb = ML.load_feedback()
    for u in uuids:
        _fb_entry(fb, u).setdefault("heard_at", ML.now())
    ML.save_json(ML.feedback_path(), fb)


def set_disabled(uuid, on=True):
    _find(_idx(), uuid)
    fb = ML.load_feedback()
    e = _fb_entry(fb, uuid)
    if on:
        e["disabled"] = ML.now()
    else:
        e.pop("disabled", None)
    ML.save_json(ML.feedback_path(), fb)


def undo_path():
    return Path(str(ML.feedback_path()) + ".likes-undo.json")


def reset_likes():
    """"איפוס כל הלייקים": כל ה-❤ וכל ה"נשמע" מתאפסים (השבתות נשארות). צילום לפני — "בטל" מחזיר בדיוק."""
    fb = ML.load_feedback()
    snap = {"at": ML.now(), "heard_reset_at": fb.get("heard_reset_at", ""), "tracks": {}}
    for uuid, e in fb.get("tracks", {}).items():
        likes = [r for r in e.get("ratings", []) if r.get("note") == LIKE_NOTE]
        keep = {k: e[k] for k in ("heard_at", "heard_cleared_at") if k in e}
        if likes or keep:
            snap["tracks"][uuid] = {"likes": likes, **keep}
        e["ratings"] = [r for r in e.get("ratings", []) if r.get("note") != LIKE_NOTE]
        e.pop("heard_at", None)
        e.pop("heard_cleared_at", None)
    fb["heard_reset_at"] = ML.now()
    ML.save_json(undo_path(), snap)
    ML.save_json(ML.feedback_path(), fb)


def undo_reset():
    snap = ML.load_json(undo_path(), None)
    if not snap:
        raise ValueError("אין איפוס לבטל")
    fb = ML.load_feedback()
    if snap.get("heard_reset_at"):
        fb["heard_reset_at"] = snap["heard_reset_at"]
    else:
        fb.pop("heard_reset_at", None)
    for uuid, s in snap["tracks"].items():
        e = _fb_entry(fb, uuid)
        e["ratings"] = [r for r in e.get("ratings", []) if r.get("note") != LIKE_NOTE] + s.get("likes", [])
        for k in ("heard_at", "heard_cleared_at"):
            if k in s:
                e[k] = s[k]
    ML.save_json(ML.feedback_path(), fb)
    undo_path().unlink()


def listing():
    idx, fb = _idx(), ML.load_feedback()
    out = []
    for t in idx.get("tracks", []):
        p = Path(t.get("path") or "")
        if not t.get("downloaded") or not p.exists():
            continue
        e = fb.get("tracks", {}).get(t["uuid"], {})
        uses = len(e.get("uses", []))
        score = ML.track_score(fb, t["uuid"])
        removed = "_rejected" in str(p)
        buck = "buckley" in json.dumps(t).lower()
        lk = liked(fb, t["uuid"])
        if removed:
            status = "removed"
        elif score <= -2:
            status = "disliked"
        elif disabled(fb, t["uuid"]):
            status = "disabled"
        elif uses > 0 or t.get("approved") or lk:      # ❤ = אישור: נכנסת לסבב
            status = "active"
        else:
            status = "pending"          # עוד לא נשמע בשורט — לא נבחר אוטומטית
        lic = ML.load_json(str(p) + ".license.json", {})
        out.append({"uuid": t["uuid"], "title": t.get("title") or p.stem, "seconds": t.get("seconds", 0),
                    "uses": uses, "score": score, "status": status, "user_added": bool(t.get("user_added")),
                    "credit": lic.get("credit_line", ""), "suits": t.get("suits", ""),
                    "liked": lk, "heard": heard(fb, t["uuid"]),
                    "family": "Scott Buckley" if buck else (lic.get("composer") or "")})
    order = {"active": 0, "pending": 1, "disabled": 2, "disliked": 3, "removed": 4}
    out.sort(key=lambda r: (order[r["status"]], r["title"].lower()))
    return out


def smart_ready(rows):
    """הבחירה החכמה פועלת: כל המנגינות שבסבב נשמעו, ויש לפחות ❤ אחד. בלי אף לייק כל המשקלות שווים —
    ואז עדיף הכלל של תמיד (הכי פחות משומשת) על הגרלה עיוורת. (22/10: 27 מתוך 27 כבר "נשמעו" — היו בשורטס.)"""
    act = [r for r in rows if r["status"] == "active"]
    return bool(act) and all(r["heard"] for r in act) and any(r["liked"] for r in act)


def summary(rows):
    """"שמעת X מתוך Y" — מתוך המנגינות שבסבב (לא ממתינות/מושבתות/נפסלות/הוסרו) — אלה שהבחירה החכמה מחכה להן."""
    act = [r for r in rows if r["status"] == "active"]
    return {"heard": sum(1 for r in act if r["heard"]), "total": len(act),
            "liked": sum(1 for r in rows if r["liked"]), "smart_ready": smart_ready(rows),
            "can_undo_reset": undo_path().exists()}


def audio_path(uuid):
    return Path(_find(_idx(), uuid)["path"])


def _move_pair(src, dst_dir):
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    if dst.exists():
        raise ValueError("כבר יש קובץ בשם הזה ב-%s" % dst_dir.name)
    shutil.move(str(src), str(dst))
    lic = Path(str(src) + ".license.json")
    if lic.exists():
        lic_dst = Path(str(dst) + ".license.json")
        if lic_dst.exists():                        # רישיון ישן שנשאר בהסרה קודמת
            lic_dst.unlink()
        shutil.move(str(lic), str(lic_dst))
    return dst


def remove(uuid):
    idx = _idx()
    t = _find(idx, uuid)
    src = Path(t["path"])
    if "_rejected" in str(src):
        return
    t["path"] = str(_move_pair(src, rejected_dir()))
    t["removed_from"] = str(src.parent)
    ML.save_json(ML.index_path(), idx)
    fb = ML.load_feedback()
    e = fb["tracks"].setdefault(uuid, {"uses": [], "ratings": []})
    e["ratings"].append({"at": ML.now(), "verdict": "bad", "note": REMOVE_NOTE, "clip": "", "used_at": ""})
    ML.save_json(ML.feedback_path(), fb)


def restore(uuid):
    idx = _idx()
    t = _find(idx, uuid)
    src = Path(t["path"])
    if "_rejected" not in str(src):
        return
    back = Path(t.pop("removed_from", "") or ML.tracks_dir())
    if not back.is_dir():            # 4.1.0: תיקייה של מחשב אחר / שכבר לא קיימת — חוזר לתיקיית הקטעים המקומית
        back = ML.tracks_dir()
    t["path"] = str(_move_pair(src, back))
    ML.save_json(ML.index_path(), idx)
    fb = ML.load_feedback()
    rs = fb.get("tracks", {}).get(uuid, {}).get("ratings", [])
    for k in range(len(rs) - 1, -1, -1):           # רק הדירוג שההסרה רשמה
        if rs[k].get("note") == REMOVE_NOTE:
            del rs[k]
            break
    ML.save_json(ML.feedback_path(), fb)


def approve(uuid, on=True):
    idx = _idx()
    t = _find(idx, uuid)
    t["approved"] = bool(on)
    ML.save_json(ML.index_path(), idx)


def add(filename, data, credit, title=""):
    credit = (credit or "").strip()
    if len(credit) < 5:
        raise ValueError("צריך שורת קרדיט — מי הלחין ובאיזה רישיון (בלי קרדיט אסור להשתמש)")
    if not filename.lower().endswith(".mp3") or len(data) < 20000:
        raise ValueError("צריך קובץ mp3")
    title = (title or Path(filename).stem).strip()
    uuid = "user-" + hashlib.md5(data).hexdigest()[:12]
    idx = _idx()
    if any(t.get("uuid") == uuid for t in idx.get("tracks", [])):
        raise ValueError("המנגינה הזאת כבר בספרייה")
    dst = ML.tracks_dir() / (ML.safe_name(title) + ".mp3")
    if dst.exists():
        dst = ML.tracks_dir() / (ML.safe_name(title) + "_" + uuid[-4:] + ".mp3")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)
    try:
        sec = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                                    "csv=p=0", str(dst)], capture_output=True, text=True).stdout.strip())
    except ValueError:
        dst.unlink()
        raise ValueError("הקובץ לא נקרא כקובץ שמע")
    Path(str(dst) + ".license.json").write_text(json.dumps({
        "title": title, "credit_line": credit, "attribution_required": True,
        "source": "הועלה בחלון יצירת שורטס", "user_added": True, "downloaded": ML.now(),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    idx.setdefault("tracks", []).append({
        "uuid": uuid, "title": title, "seconds": int(sec), "length": "%d:%02d" % (sec // 60, sec % 60),
        "moods": [], "suits": "", "downloaded": ML.now(), "path": str(dst),
        "user_added": True, "approved": False})
    ML.save_json(ML.index_path(), idx)
    return uuid
