# -*- coding: utf-8 -*-
"""
make_short_emph.py — "🔠 הגדלת מילים" (כרטיס 15, 22/10/2026).

הרקע: ב-12/10 נוספה הגדלת המילה שהרב התעכב עליה (פי 1.3); ב-15/10 הוא ביטל אותה כי הבחירה האוטומטית לא קלעה
למילה הנכונה. ב-22/10 ביקש להחזיר אותה **רק כשהוא מדליק**: המודל תמיד מציע מילים (המילה שנושאת את המשמעות),
אבל הן נחשפות ונצרבות רק כשהמתג "🔠 הגדלת מילים" דולק ליד תיבת הטקסט — והוא יכול לערוך אותן.

לכל קליף: work/subtitles/<clip>_emph.json =
  {"on": false,                     ← המתג. כבוי = הצריבה בדיוק כמו תמיד (בלי שום הגדלה)
   "picks": null | [pick, ...],     ← null = ההצעה כמו שהיא; רשימה = מה שהוא ערך
   "proposed": null | [pick, ...],  ← מה שהוצע (null = עוד לא חושב — ההצעה האוטומטית תחושב כשצריך)
   "src": "gemini" | "chat" | "auto"}
pick = {"w": "המילה", "q": "כמה מילים סביבה (ציטוט)", "at": מיקום יחסי 0..1 בטקסט, או null}

המילים נשמרות כ*טקסט* ולא כמספרי מילים: אחרי תיקון טקסט, הזזת גבולות או יישור מחדש המספרים משתנים, אבל המילה
והמילים שסביבה נשארות. resolve() מוצא כל מילה מחדש (התאמה מלאה → עם תחילית/סיומת → דומה מאוד), בוחר את
המופע שהמילים שסביבו הכי דומות לציטוט, ומילה שלא נמצאה בכלל יורדת — וחוזרת ברשימה "lost" כדי לומר לו.
אותו אלגוריתם בדיוק רץ גם בדף (emResolve) לסימון החי בתוך התיבה.
"""
import difflib
import json
import re
from pathlib import Path

CTX = 3            # מילים מכל צד שנשמרות כציטוט כשהוא מסמן מילה בעצמו
WIN = 6            # כמה מילים מכל צד בודקים מול הציטוט
SRC_LABEL = {"gemini": "Gemini הציע", "chat": "הצ'אט הציע", "auto": "הצעה אוטומטית"}


def norm(w):
    return re.sub(r"[^א-תA-Za-z0-9]", "", w or "")


def path(P, name):
    return Path(P) / "work" / "subtitles" / ("%s_emph.json" % name)


def load(P, name):
    try:
        d = json.load(open(path(P, name), encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def save(P, name, d):
    f = path(P, name)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".json.tmp")
    json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    tmp.replace(f)


def clean_picks(raw, limit=60):
    """מה שהגיע מהמודל או מהדף → [{"w", "q", "at"}]. סובלני: מחרוזות, "...*מילה*...", מילונים."""
    out = []
    for r in raw or []:
        w, q, at = "", "", None
        if isinstance(r, str):
            m = re.search(r"\*([^*]+)\*", r)
            w, q = (m.group(1), r.replace("*", "")) if m else (r, r)
        elif isinstance(r, dict):
            w = str(r.get("w") or r.get("word") or r.get("מילה") or "")
            q = str(r.get("q") or r.get("quote") or r.get("context") or r.get("ציטוט") or "")
            try:
                at = None if r.get("at") is None else max(0.0, min(1.0, float(r["at"])))
            except (TypeError, ValueError):
                at = None
        w = w.strip().split()[0] if w.strip() else ""         # "מילה" אחת — אם הגיעו כמה, הראשונה
        if norm(w):
            out.append({"w": w, "q": " ".join(q.split())[:120], "at": at})
        if len(out) >= limit:
            break
    return out


def _sim(a, b):
    return difflib.SequenceMatcher(None, a, b, autojunk=False).ratio()


def resolve(picks, toks):
    """toks = המילים של הטקסט, מנורמלות (norm). מחזיר (אינדקס לכל pick או None, [picks שלא נמצאו]).
    שני picks לא נופלים על אותה מילה."""
    used, out, lost = set(), [], []
    n = len(toks)
    for p in picks or []:
        w = norm(p.get("w"))
        cands = [i for i, t in enumerate(toks) if t == w and i not in used]
        if not cands and len(w) >= 3:
            # "תשובה" ↔ "והתשובה" / "בתשובתו" (תחילית או סיומת), או כתיב קצת אחר ("מלחמה" שתוקן ל"מלחמות").
            # שתי הדרגות יחד — ההקשר מכריע ביניהן (בבדיקה: "מלחמה" שתוקנה קפצה ל"במלחמה" שבמשפט הבא)
            cands = [i for i, t in enumerate(toks) if i not in used and len(t) >= 3 and (
                t.endswith(w) or w.endswith(t) or t.startswith(w) or (len(w) >= 4 and _sim(t, w) >= 0.7))]
        if not cands:
            out.append(None)
            lost.append(p)
            continue
        q = [norm(x) for x in (p.get("q") or "").split() if norm(x)]
        qs = set(q)

        def score(i):
            around = set(toks[max(0, i - WIN):i] + toks[i + 1:i + 1 + WIN])    # מילים שונות — לא סופרים חזרות
            s = len(around & qs)
            adj = sum(1 for j in (i - 1, i + 1) if 0 <= j < n and toks[j] in qs)   # השכנות הצמודות — שובר שוויון
            near = -abs(i / max(1, n - 1) - p["at"]) if p.get("at") is not None else -i / max(1, n) * 0.001
            return (s, adj, near)
        best = max(cands, key=score)
        used.add(best)
        out.append(best)
    return out, lost


def make_pick(toks_raw, i):
    """pick ממילה בטקסט (הגדלה שהוא סימן, או ההצעה האוטומטית): המילה, 3 מילים מכל צד, מיקום יחסי."""
    n = len(toks_raw)
    return {"w": toks_raw[i], "q": " ".join(toks_raw[max(0, i - CTX):i + 1 + CTX]),
            "at": round(i / max(1, n - 1), 4)}


def picks_of(d):
    if not d:
        return []
    return d["picks"] if d.get("picks") is not None else (d.get("proposed") or [])


def is_on(P, name):
    d = load(P, name)
    return bool(d and d.get("on"))


def idx_for_words(P, name, words):
    """לצריבה: קבוצת האינדקסים ב-words (words.json המיושר) להגדלה, או None כשהמתג כבוי
    (None = karaoke_ass בונה בדיוק כמו תמיד). מחזיר (idx, lost)."""
    d = load(P, name)
    if not d or not d.get("on"):
        return None, []
    live = [k for k, w in enumerate(words) if w["word"].strip()]
    toks = [norm(words[k]["word"]) for k in live]
    got, lost = resolve(picks_of(d), toks)
    return {live[i] for i in got if i is not None}, lost


def auto_proposal(words, duration):
    """אין הצעה של מודל (זמנים ידניים / שיעור ישן): ההיוריסטיקה הישנה של karaoke_ass (התעכבות + נדירות),
    מסומנת "הצעה אוטומטית". words = המילים המיושרות של הטקסט."""
    import karaoke_ass as KA
    items, _ = KA.make_items(words, duration, None, with_index=True)
    plan = KA.plan_emphasis(items)
    live = [k for k, w in enumerate(words) if w["word"].strip()]
    pos = {k: j for j, k in enumerate(live)}
    raw = [words[k]["word"].strip() for k in live]
    out = []
    for ci, k in sorted(plan.items()):
        ws = [w for w in items[ci][2] if w["word"].strip()]
        if k < len(ws) and ws[k].get("i") in pos:
            out.append(make_pick(raw, pos[ws[k]["i"]]))
    return out
