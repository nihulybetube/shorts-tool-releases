# -*- coding: utf-8 -*-
"""מוסיף מוזיקת רקע לקליפ מוכן.

- מנרמל את הטראק ל-loudness אחיד, כך שכל קובץ במאגר מתנהג אותו דבר
- מלווּפ אותו לאורך הקליפ אם הוא קצר מדי
- ducking אוטומטי: המוזיקה יורדת כשהדובר מדבר וחוזרת בהפסקות
- fade in/out בקצוות

מאגר המוזיקה הוא של המשתמש ונבחר ב-`shorts.sh setup` ($SHORTS_MUSIC_DIR).
הוא לא מגיע עם הסקיל — ראה `assets/music/README.md`.

שימוש:
    shorts.sh py add_music.py shorts/clip1/video.mp4 "$SHORTS_MUSIC_DIR/track.mp3"
    shorts.sh py add_music.py shorts/clip1/video.mp4 "$SHORTS_MUSIC_DIR/track.mp3" -16
"""
import os
import subprocess
import sys

MUSIC_LUFS = -20      # נרמול הטראק לפני המיקס
# 🚨 תוקן 26/8/2026 אחרי מדידה. הערכים הקודמים (-20dB + סף sidechain של
# 0.03) ייצרו מוזיקה **בלתי נשמעת**: אות ההפרש בין הגרסה עם המוזיקה
# לגרסה בלעדיה נמדד ב--44dB, והעוצמה הכוללת הייתה זהה עד 0.1dB.
# שתי סיבות, שתיהן תוקנו:
#   1. -20dB **מעל** נרמול ל--20 LUFS = מוזיקה ב--40 LUFS. מתחת לרעש החדר.
#   2. סף ה-sidechain 0.03 (≈-30dBFS) נמוך מרעש החדר בהקלטה (-28.5dB),
#      ולכן הדאקינג עבד **ברציפות** והמוזיקה מעולם לא חזרה בהפסקות.
# הערכים כאן נמדדו: +4dB בהפסקות דיבור, +2.4dB בלבד תחת דיבור.
DEFAULT_DUCK_DB = -4
SIDECHAIN_THRESHOLD = 0.16   # מעל רעש החדר, כדי שהדאקינג ישחרר בהפסקות
SIDECHAIN_RATIO = 6
FADE = 0.8


def probe_duration(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", path], capture_output=True, text=True, check=True)
    return float(out.stdout.strip())


def add_music(video_path, music_path, out_path=None, duck_db=DEFAULT_DUCK_DB):
    dur = probe_duration(video_path)
    if out_path is None:
        base, ext = os.path.splitext(video_path)
        out_path = f"{base}_music{ext}"

    fc = (
        f"[1:a]loudnorm=I={MUSIC_LUFS}:TP=-2:LRA=11,"
        f"volume={duck_db}dB,"
        f"aformat=sample_rates=48000:channel_layouts=stereo,"
        f"atrim=0:{dur},afade=t=in:d={FADE},afade=t=out:st={max(0, dur - FADE)}:d={FADE}[m];"
        f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,asplit=2[sp][key];"
        # ה-sidechain מקבל את הדיבור כמפתח ומוריד את המוזיקה בזמן אמת
        f"[m][key]sidechaincompress=threshold={SIDECHAIN_THRESHOLD}:"
        f"ratio={SIDECHAIN_RATIO}:attack=5:release=350[md];"
        f"[sp][md]amix=inputs=2:duration=first:normalize=0[a]"
    )
    cmd = [
        "ffmpeg", "-y", "-i", video_path,
        "-stream_loop", "-1", "-i", music_path,
        "-filter_complex", fc,
        "-map", "0:v", "-map", "[a]",
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
        "-shortest", out_path,
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return out_path


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    duck = float(sys.argv[3]) if len(sys.argv) > 3 else DEFAULT_DUCK_DB
    print(add_music(sys.argv[1], sys.argv[2], duck_db=duck))
