# -*- coding: utf-8 -*-
"""
make_short_share.py — "שיתוף תוכנה": קובץ zip אחד שמתקין את הכלי במחשב ווינדוס אחר, בלי GitHub (21/10/2026).

למה: הוא רוצה לתת את התוכנה לאחרים בקלות — לשלוח קובץ אחד, והמקבל לוחץ פעמיים. ההתקנה
הרגילה (windows/install_windows.ps1) מושכת קוד מ-GitHub הפרטי ומוזיקה מה-Drive שלו — שני
דברים שלמקבל אין. כאן כל מה שצריך נארז בתוך ה-zip עצמו.

מה בפנים:
  code/      הקוד בגרסה הנוכחית (git archive של ה-commit — בלי היסטוריה, בלי שינויים שלא נשמרו)
  extras/    ספריית המוזיקה (קטעים + רישיונות + אינדקס + mix.py + רישיונות הנפסלים),
             הלוגו של הישיבה (קובץ שאפשר להחליף אחר כך בהגדרות), ההנחיות האישיות (guidelines.txt)
  התקנה.bat  לחיצה כפולה (אחרי "חלץ הכול") → code/windows/install_windows.ps1 במצב חבילה
  קרא אותי.txt, package.json (מה נכלל, מאיזה commit — בלי שום סוד)
ההגדרות: לא שלו — המקבל מתחיל מברירות המחדל של התוכנה (אין make_short_settings.json בחבילה).

🚨 מה לא נכנס לעולם: config.env, מפתחות, התחברות Modal, עוגיות יוטיוב, חיבור הדרייב (rclone),
פרויקטים, ייצואים, יומנים. הקבצים נאספים מרשימה מפורשת בלבד, ובסוף כל ה-zip נסרק (כולל
פתיחת כל קובץ דחוס) לחיפוש סודות — נמצא משהו → ה-zip נמחק והבנייה נכשלת.
החשבונות (Modal / Gemini) — המקבל מתחבר עם שלו; ההתקנה מדריכה אותו בעברית.

16/11 (3.5) "פרופיל למקבל": חבילה מותאמת לישיבה / ערוץ אחר — הלוגו, השורות הקבועות בסוף התיאור, שם הישיבה
(ומשפט הרשמה, לא חובה) של המקבל במקום שלו, והנחיות ניטרליות (assets/guidelines/shorts_default.txt — בלי
קישורים של אף אחד). הפרופילים נשמרים בנפרד מההגדרות שלו: ~/.config/yeshiva-shorts/share_profiles/<id>/
(profile.json + logo.png). ההגדרות, הלוגו והשורות שלו לא משתנים אף פעם. בחבילת פרופיל נבדק בסוף שאין
בשום קובץ את הלוגו שלו (השוואת hash) ואת המחרוזות שלו (מקובץ ההגדרות שלו + רשימה קבועה מקודדת).
אצל המקבל ההתקנה כותבת את ערכי הפרופיל רק למפתחות שעוד אין לו (apply-profile), והלוגו — בלי לדרוס.

שימוש:  shorts.sh py make_short_share.py build [--drive] [--out DIR] [--profile ID] [--prune]
  --drive  ההתקנה אצל המקבל תציע לו לחבר Google Drive *משלו* לגיבוי (בלי זה: הגיבוי כבוי אצלו)
  --out    תיקיית יעד (ברירת מחדל: SHORTS_SHARE_DIR, אחרת <תיקיית הפרויקט בווינדוס>\\שיתוף)
  --profile חבילה עם פרופיל למקבל (בלי זה: החבילה הרגילה, בדיוק כמו עד 3.4)
        shorts.sh py make_short_share.py profiles            רשימת הפרופילים (json)
        python3 make_short_share.py apply-profile <profile.json> <make_short_settings.json>   (ההתקנה אצל המקבל)
        python3 make_short_share.py receiver-init <make_short_settings.json>   (4.0: תצוגה פשוטה + צעדים ראשונים, בלי לדרוס)
        python3 make_short_share.py merge-music <extras/music> <~/.local/share/yeshiva-shorts/music>   (4.1.0, אצל המקבל)
פלט: שורות התקדמות, ובסוף FILE=<נתיב ה-zip>.

4.1.0 (ביקורת קוד חיצונית): אינדקס המוזיקה נארז עם נתיבים יחסיים (לא /home/<שם משתמש>); מסמכים אישיים (היסטוריית שינויים,
מדריך ההעברה) לא נארזים ו-HANDOFF בלי סעיף האנשים; מחרוזות זהות מוחלפות בטקסט הנארז, ההתקנה בחבילה בלי זרימת GitHub;
בדיקת הזהות רצה גם בחבילה רגילה (שם משתמש / בית / GitHub), בלי רגישות לאותיות ועם UTF-16; בחבילת פרופיל גם "בית אל"
והשוואת פיקסלים ללוגו; "zip זר" בתיקיית השיתוף לא נספר ולא נמחק; התקנה מחדש ממזגת מוזיקה חדשה ומחליפה mix.py.
"""
import base64
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
import time
import unicodedata
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
MUSIC = DATA / "music"

# סריקת סודות: דפוסים כלליים (מפתח גוגל, טוקן Modal, עוגיות, טוקן OAuth) + הערכים האמיתיים שלו
#   4.1.0: הסריקה לא רגישה לאותיות (הערך מוצא גם באותיות קטנות) וגם מפענחת UTF-16; נוספו סוד לקוח של גוגל
#   (GOCSPX-...) ומפתח פרטי (הכותרת + גוף, כדי שהמילה בלבד בקוד לא תפסול)
SECRET_PATTERNS = [re.compile(p, re.I) for p in (
    rb"AIza[0-9A-Za-z_\-]{30,}", rb"\b(?:ak|as)-[0-9A-Za-z]{16,}", rb"youtube\.com\tTRUE", rb"ya29\.[0-9A-Za-z_\-]{20,}",
    rb'"refresh_token"\s*:', rb"1//0[0-9A-Za-z_\-]{30,}", rb"token_secret\s*=",
    rb"GOCSPX-[0-9A-Za-z_\-]{20,}",
    rb"-----BEGIN [A-Z ]{0,30}PRIVATE KEY-----\s*[A-Za-z0-9+/=\r\n]{40,}")]

# מחרוזות זהות של הבעלים — בנויות בחיבור/קידוד כדי שהקוד עצמו (שנכנס לחבילה) לא יכיל אותן (4.1.0)
_OWNER = "nihuly" + "betube"
_OWN_HOME = "<user>" + "4"
_OWN_USER = "ita" + "i"
IDENT_NEEDLES = (_OWNER, _OWN_HOME, "/home/" + _OWN_USER, _OWN_USER)
# רק בחבילת פרופיל (בחבילה הרגילה ההנחיות והלוגו של בית אל נשארים בכוונה)
_PROFILE_NEEDLES_B64 = ("QmVpdCBFbA==", "15HXmdeqINeQ15w=")


def say(s):
    print(s, flush=True)


def win_profile():
    """תיקיית המשתמש בווינדוס, כנתיב WSL (/mnt/c/Users/...)."""
    try:
        w = subprocess.run(["/mnt/c/Windows/System32/cmd.exe", "/c", "echo %USERPROFILE%"], capture_output=True,
                           text=True, timeout=20, cwd="/mnt/c").stdout.strip().splitlines()[-1].strip()
        return Path(subprocess.run(["wslpath", "-u", w], capture_output=True, text=True, timeout=10).stdout.strip())
    except Exception:
        return None


def default_out():
    if os.environ.get("SHORTS_SHARE_DIR"):
        return Path(os.environ["SHORTS_SHARE_DIR"])
    prof = win_profile()
    if not prof or not prof.exists():
        raise SystemExit("❌ לא מצאתי את תיקיית המשתמש בווינדוס — אפשר לתת תיקייה עם --out")
    return prof / "yeshiva-shorts" / "שיתוף"


def tool_version():
    """16/11 (3.4): הגרסה מהקובץ VERSION (מקור אחד) — נכנסת לשם קובץ השיתוף ול-package.json."""
    try:
        return (REPO / "VERSION").read_text(encoding="utf-8").strip() or "?"
    except OSError:
        return "?"


def git(*a):
    return subprocess.run(["git", "-C", str(REPO), *a], capture_output=True, text=True).stdout.strip()


def logo_file():
    reg = os.environ.get("SHORTS_LOGO") or ""
    for p in (reg, str(CONFIG / "brand" / "logo.png")):
        if p and os.path.isfile(p):
            return Path(p)
    return None


def music_files():
    """[(נתיב בחבילה, קובץ)] — אותה רשימה ש-backup_extras.sh מגבה (בלי _build/_reference)."""
    out = []
    tr = MUSIC / "tracks"
    for f in sorted(tr.iterdir()) if tr.exists() else []:
        if f.is_file():
            out.append(("extras/music/tracks/" + f.name, f))
    rej = MUSIC / "_rejected"
    for f in sorted(rej.glob("*.license.json")) if rej.exists() else []:
        out.append(("extras/music/_rejected/" + f.name, f))
    # index.json לא נארז כמו שהוא (יש בו נתיבים מוחלטים של המחשב שלו) — build כותב גרסה ניידת (portable_index)
    for rel in ("_refs/mix.py",):
        if (MUSIC / rel).is_file():
            out.append(("extras/music/" + rel, MUSIC / rel))
    return out


def portable_index(path=None):
    """4.1.0: האינדקס כפי שנכנס לחבילה — נתיבי הקטעים יחסיים ('tracks/x.mp3'), בלי שם משתמש ובלי תיקיות של המחשב שלו.
    מחזיר (bytes, מספר קטעים שירדו). קטע שהקובץ שלו לא נארז (ירד אבל נעלם) — מסומן כלא-מורד."""
    p = Path(path) if path else MUSIC / "index.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return b"", 0
    if not isinstance(d, dict):
        return b"", 0
    packed = {f.name for f in (MUSIC / "tracks").iterdir() if f.is_file()} if (MUSIC / "tracks").exists() else set()
    n = 0
    for t in d.get("tracks", []) or []:
        if not isinstance(t, dict):
            continue
        t.pop("removed_from", None)
        if t.get("path"):
            base = str(t["path"]).replace("\\", "/").rsplit("/", 1)[-1]
            if "_rejected" in str(t["path"]) or base not in packed:
                t.pop("path", None)              # נפסל / לא קיים בחבילה — המקבל לא מקבל נתיב
                t.pop("downloaded", None)
                n += 1
            else:
                t["path"] = "tracks/" + base
    return json.dumps(d, ensure_ascii=False, indent=2).encode("utf-8"), n


def merge_music(src, dst):
    """4.1.0, אצל המקבל (נקרא מההתקנה, גם בהתקנה מחדש מעל קיימת): קטעים חדשים מהחבילה נכנסים לאינדקס שלו, ומה שכבר
    יש לו (כולל קטע שהוא הסיר, ודירוגים — הם בקובץ נפרד) לא משתנה. mix.py מוחלף תמיד (זה קוד, לא נתונים שלו).
    מחזיר (קטעים שנוספו, האם mix.py הוחלף)."""
    src, dst = Path(src), Path(dst)

    def rd(p):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}
    new, cur = rd(src / "index.json"), rd(dst / "index.json")
    tracks = [t for t in (cur.get("tracks") or []) if isinstance(t, dict)]
    have = {t.get("uuid") for t in tracks}
    changed = False
    for t in tracks:                             # נתיב יחסי (הועתק מהחבילה) → נתיב מלא אצלו
        if t.get("path") and not os.path.isabs(str(t["path"])):
            t["path"] = str(dst / str(t["path"]))
            changed = True
    added = 0
    for t in new.get("tracks") or []:
        if not isinstance(t, dict) or t.get("uuid") in have:
            continue
        t = dict(t)
        pth = t.get("path")
        if pth:
            f = dst / "tracks" / str(pth).replace("\\", "/").rsplit("/", 1)[-1]
            if f.exists():
                t["path"] = str(f)
            else:
                t.pop("path", None)
                t.pop("downloaded", None)
        tracks.append(t)
        have.add(t.get("uuid"))
        added += 1
        changed = True
    if changed or not (dst / "index.json").exists():
        out = dict(new) if not cur else dict(cur)
        out["tracks"] = tracks
        dst.mkdir(parents=True, exist_ok=True)
        tmp = dst / "index.json.tmp"
        tmp.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, dst / "index.json")
    mixed = False
    if (src / "_refs" / "mix.py").is_file():
        d = dst / "_refs" / "mix.py"
        data = (src / "_refs" / "mix.py").read_bytes()
        if not d.is_file() or d.read_bytes() != data:
            d.parent.mkdir(parents=True, exist_ok=True)
            tmp = d.with_suffix(".tmp")
            tmp.write_bytes(data)
            os.replace(tmp, d)
            mixed = True
    return added, mixed


def info():
    """לחלון: מה ייכנס לחבילה (בלי לבנות)."""
    mf = music_files()
    size = sum(f.stat().st_size for _, f in mf)
    dirty = [l for l in git("status", "--porcelain", "--untracked-files=no").splitlines() if l.strip()]
    return {"commit": git("log", "-1", "--format=%h %cs"), "dirty": len(dirty),
            "tracks": sum(1 for p, _ in mf if p.endswith(".mp3")), "music_mb": round(size / 1e6),
            "logo": bool(logo_file()), "guidelines": (CONFIG / "guidelines.txt").is_file()}


def zip_list(out_dir, profile=None):
    """קבצי השיתוף שבתיקייה, מהחדש לישן (בלי קבצי .part של בנייה שנקטעה).
    3.5: profile=None → רק החבילות הרגילות (בלי פרופיל) — כך "ישן / בנה מחדש / הישן לסל" של החבילה הרגילה לא
    נוגעים אף פעם בחבילות של פרופילים. profile=<id> → רק החבילות של הפרופיל הזה."""
    if not out_dir or not Path(out_dir).is_dir():
        return []
    zs = sorted((f for f in Path(out_dir).glob("*.zip") if f.is_file()), key=lambda f: f.stat().st_mtime, reverse=True)
    out = []
    for z in zs:
        m = zip_meta(z)
        if not is_ours(m):                       # 4.1.0: zip זר בתיקייה (לא של "שיתוף תוכנה") — אף פעם לא נוגעים
            continue
        if ((m.get("profile") or {}).get("id") or None) == (profile or None):
            out.append(z)
    return out


def is_ours(meta):
    """חבילה שלנו = package.json עם format ו-commit (4.1.0). כל zip אחר בתיקיית השיתוף לא נספר ולא נמחק."""
    return isinstance(meta, dict) and bool(meta.get("format")) and bool(meta.get("commit"))


def zip_meta(z):
    try:
        with zipfile.ZipFile(z) as zz:
            d = json.loads(zz.read("package.json").decode("utf-8"))
            return d if isinstance(d, dict) else {}
    except (OSError, KeyError, ValueError, zipfile.BadZipFile):
        return {}


def stale_info(out_dir=None, profile=None):
    """22/10 (כרטיס 14): האם קובץ השיתוף החדש ביותר בתיקייה בנוי מהגרסה הנוכחית (ה-commit האחרון).
    3.5: עם profile — אותה שאלה על החבילה האחרונה של הפרופיל הזה. בלי — רק החבילה הרגילה, כמו תמיד."""
    out_dir = out_dir or default_out()
    zs = zip_list(out_dir, profile)
    cur = git("log", "-1", "--format=%h %cs")
    head = git("rev-parse", "HEAD")
    if not zs:
        return {"file": "", "current": cur, "stale": False, "count": 0}
    m = zip_meta(zs[0])
    ver = m.get("commit") or ""
    short = ver.split(" ")[0]
    return {"file": zs[0].name, "path": str(zs[0]), "version": ver, "current": cur, "count": len(zs),
            "drive_offer": bool(m.get("drive_offer")), "stale": not (short and head.startswith(short))}


def prune(out_dir, keep, profile=None):
    """רק הקובץ החדש נשאר; הישנים — לסל המיחזור של ווינדוס בדרך הבטוחה (win_recycle: העתקה, אימות, סל,
    בדיקה שהגיע לסל, ורק אז הסרה). בבדיקה (SHORTS_SHARE_DIR בתוך WSL, בלי סל) — לתיקייה _old בצד.
    3.5: רק קבצים מאותו סוג — החבילה הרגילה מנקה רק רגילות, ופרופיל רק את החבילות שלו."""
    sys.path.insert(0, str(HERE))
    import win_recycle as WR
    out_dir, moved = Path(out_dir), []
    for z in zip_list(out_dir, profile):
        if z.resolve() == Path(keep).resolve():
            continue
        stage = out_dir / "_old" / ("%s_%d" % (time.strftime("%Y%m%d_%H%M%S"), len(moved)))
        stage.mkdir(parents=True, exist_ok=True)
        os.replace(z, stage / z.name)
        if os.environ.get("MAKE_SHORT_NO_EXPORT") == "1" and not str(out_dir).startswith("/mnt/"):
            moved.append(z.name + " (בדיקה: נשאר ב-_old)")
            continue
        try:
            WR.recycle(stage, out_dir, "share")
            moved.append(z.name)
        except Exception as e:                   # לא הצליח לסל — הקובץ נשאר ב-_old, לא נמחק
            say("   ⚠️ %s לא הועבר לסל המיחזור (%s) — נשאר בתיקייה _old" % (z.name, e))
    try:
        (out_dir / "_old").rmdir()               # רק אם ריקה
    except OSError:
        pass
    return moved


# ─────────────── 3.5: פרופילים למקבל ───────────────

PROFILES = Path(os.environ.get("SHORTS_SHARE_PROFILES") or CONFIG / "share_profiles")
PROFILE_KEYS = ("footer_lines", "org_name", "subscribe_text")      # = מפתחות ההגדרות של 3.4 (📝 תיאור ותגיות)
NEUTRAL_GUIDELINES = REPO / "assets" / "guidelines" / "shorts_default.txt"
# המחרוזות שלו שאסור שיופיעו בחבילת פרופיל — מקודדות, כדי שהקוד עצמו (שנכנס לחבילה) לא יכיל אותן
_HIS_FIXED = ("eWJlLm9yZy5pbA==", "eWVzaGl2YS5vcmcuaWwvbWlkcmFzaA==", "15nXqdeZ15HXqiDXkdeZ16og15DXnA==")
_BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def _pdir(pid):
    pid = str(pid or "")
    if not re.fullmatch(r"p[0-9a-f]{6,32}", pid):
        raise ValueError("פרופיל לא מוכר")
    return PROFILES / pid


def _clean_profile(d):
    """אותם כללים כמו בהגדרות (make_short_settings.clean): שורות, שורה אחת, אורך."""
    name = " ".join(str(d.get("name") or "").split())[:40]
    if not name:
        raise ValueError("צריך לתת לפרופיל שם (למשל: ישיבת ההר)")
    if _BAD_NAME.search(name):
        raise ValueError('בשם הפרופיל אי אפשר להשתמש בסימנים \\ / : * ? " < > |')
    foot = "\n".join(l.rstrip() for l in str(d.get("footer_lines") or "").replace("\r", "").split("\n")).strip("\n")[:2000]
    return {"name": name, "footer_lines": foot,
            "org_name": " ".join(str(d.get("org_name") or "").split())[:80],
            "subscribe_text": " ".join(str(d.get("subscribe_text") or "").split())[:300],
            "auto_rebuild": bool(d.get("auto_rebuild"))}


def profiles():
    """כל הפרופילים, לפי שם. תיקייה שמתחילה ב-_ (פחי מחיקה) לא נחשבת."""
    out = []
    for d in sorted(PROFILES.iterdir()) if PROFILES.is_dir() else []:
        if d.name.startswith("_") or not (d / "profile.json").is_file():
            continue
        try:
            p = json.loads((d / "profile.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        p = dict(_clean_profile(dict(p, name=p.get("name") or d.name)), id=d.name, logo=(d / "logo.png").is_file())
        out.append(p)
    return sorted(out, key=lambda p: p["name"])


def profile_get(pid):
    return next((p for p in profiles() if p["id"] == pid), None)


def profile_save(d, logo=None):
    """פרופיל חדש (בלי id) או עריכה. logo = בייטים של PNG (לא חובה; בעריכה בלי לוגו — הקודם נשאר)."""
    p = _clean_profile(d)
    if any(x["name"] == p["name"] and x["id"] != d.get("id") for x in profiles()):
        raise ValueError("כבר יש פרופיל בשם הזה")
    if logo is not None and not logo.startswith(b"\x89PNG"):
        raise ValueError("צריך קובץ PNG (עם רקע שקוף)")
    if d.get("id"):
        pd = _pdir(d["id"])
        if not (pd / "profile.json").is_file():
            raise ValueError("הפרופיל לא נמצא (אולי נמחק)")
    else:
        pd = PROFILES / ("p" + hashlib.sha1(("%s%f" % (p["name"], time.time())).encode()).hexdigest()[:10])
    sys.path.insert(0, str(HERE))
    import make_short_guard
    make_short_guard.assert_not_real_config(PROFILES)     # 4.1.2
    pd.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(PROFILES, 0o700)
    except OSError:
        pass
    if logo is not None:
        (pd / "logo.tmp").write_bytes(logo)
        os.replace(pd / "logo.tmp", pd / "logo.png")
    tmp = pd / "profile.tmp"
    tmp.write_text(json.dumps(dict(p, saved=time.strftime("%Y-%m-%d %H:%M")), ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, pd / "profile.json")
    return dict(p, id=pd.name, logo=(pd / "logo.png").is_file())


def profile_delete(pid):
    """לא rm: התיקייה עוברת ל-share_profiles/_deleted/<זמן>/ ומשם לסל המיחזור של ווינדוס (win_recycle, עם
    אימות). לא הצליח לסל / בבדיקה — נשארת ב-_deleted (אפשר להחזיר ידנית). חבילות ה-zip שנבנו לא נמחקות."""
    pd = _pdir(pid)
    if not (pd / "profile.json").is_file():
        raise ValueError("הפרופיל לא נמצא (אולי כבר נמחק)")
    sys.path.insert(0, str(HERE))
    import make_short_guard
    make_short_guard.assert_not_real_config(PROFILES)
    stage =PROFILES / "_deleted" / ("%s_%s" % (time.strftime("%Y%m%d_%H%M%S"), pd.name))
    stage.mkdir(parents=True, exist_ok=True)
    os.replace(pd, stage / pd.name)
    if os.environ.get("MAKE_SHORT_NO_EXPORT") == "1":
        return "_deleted"
    try:
        sys.path.insert(0, str(HERE))
        import win_recycle as WR
        WR.recycle(stage, PROFILES, "share_profile")
        try:
            (PROFILES / "_deleted").rmdir()
        except OSError:
            pass
        return "bin"
    except Exception:
        return "_deleted"


def profiles_view(out_dir=None):
    """לחלון: כל פרופיל + החבילה האחרונה שלו (אם יש) והאם היא ישנה."""
    res, ps = [], profiles()
    if ps and not out_dir:
        try:
            out_dir = default_out()              # פעם אחת (מציאת התיקייה בווינדוס לוקחת שנייה)
        except (SystemExit, Exception):
            out_dir = None
    for p in ps:
        try:
            s = stale_info(out_dir, p["id"])
        except (SystemExit, Exception):
            s = {}
        res.append(dict(p, zip=s.get("file", ""), zip_version=s.get("version", ""), stale=bool(s.get("stale")),
                        count=s.get("count", 0)))
    return res


def his_strings():
    """המחרוזות שלו שאסור שיופיעו בחבילת פרופיל: הרשימה הקבועה + הערכים מקובץ ההגדרות שלו (האמיתי, ואם הוגדר
    קובץ הגדרות אחר — גם ממנו). שורות קצרות / סימנים בלבד לא נחשבות (כדי לא לפסול "◄" או "──")."""
    out = {base64.b64decode(x).decode("utf-8") for x in _HIS_FIXED}
    generic = ""
    try:
        sys.path.insert(0, str(HERE))
        import make_short_settings as MSS
        generic = MSS.GENERIC_SUBSCRIBE
    except Exception:
        pass
    for f in {CONFIG / "make_short_settings.json", Path(os.environ.get("MAKE_SHORT_SETTINGS") or CONFIG / "make_short_settings.json")}:
        try:
            v = json.loads(f.read_text(encoding="utf-8")).get("values", {})
        except (OSError, ValueError, AttributeError):
            continue
        for line in str(v.get("footer_lines") or "").splitlines():
            out.add(line.strip())
        out.add(str(v.get("org_name") or "").strip())
        if str(v.get("subscribe_text") or "").strip() != generic:
            out.add(str(v.get("subscribe_text") or "").strip())
    return sorted(s for s in out if len(s) >= 6 and re.search(r"\w{3}", s))


def his_logo_hashes():
    """hash של כל לוגו שלו: תיקיית brand (logo.png + כל מה שהעלה), SHORTS_LOGO, והנתיבים בהגדרות."""
    files = set(CONFIG.joinpath("brand").glob("*.png")) if (CONFIG / "brand").is_dir() else set()
    if os.environ.get("SHORTS_LOGO"):
        files.add(Path(os.environ["SHORTS_LOGO"]))
    try:
        v = json.loads((CONFIG / "make_short_settings.json").read_text(encoding="utf-8")).get("values", {})
        files |= {Path(v[k]) for k in ("logo_path", "logo2_path") if v.get(k)}
    except (OSError, ValueError, AttributeError):
        pass
    out = set()
    for f in files:
        try:
            out.add(hashlib.sha256(f.read_bytes()).hexdigest())
        except OSError:
            pass
    return out


def _variants(data):
    """תוכן הקובץ כפי שצריך לסרוק: אותיות קטנות, ואם הוא UTF-16 (BOM או אפסים) — גם מפוענח (4.1.0)."""
    out = [data.lower()]
    if data[:2] in (b"\xff\xfe", b"\xfe\xff") or data[:400].count(b"\x00") > 20:
        for enc in ("utf-16", "utf-16-le", "utf-16-be"):
            try:
                out.append(data.decode(enc).encode("utf-8").lower())
            except (UnicodeError, ValueError):
                pass
    return out


def _png_rgba(data):
    """פענוח PNG בלי ספריות (zlib בלבד): 8 ביט, בלי שזירה, סוגי צבע 0/2/3/4/6 → (רוחב, גובה, bytearray RGBA). אחר → None.
    (ב-venv של התוכנה אין PIL — ובלי פענוח לא אפשר לזהות לוגו שנשמר מחדש.)"""
    import struct
    import zlib
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        return None
    pos, idat, plte, trns, hdr = 8, [], b"", b"", None
    while pos + 8 <= len(data):
        ln, typ = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            hdr = struct.unpack(">IIBBBBB", body)
        elif typ == b"PLTE":
            plte = body
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            idat.append(body)
        elif typ == b"IEND":
            break
    if not hdr:
        return None
    w, h, depth, ctype, _c, _f, inter = hdr
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if depth != 8 or inter or not ch or w * h > 40_000_000:
        return None
    raw = zlib.decompress(b"".join(idat))
    stride, prev = w * ch, bytearray(w * ch)
    out, i = bytearray(w * h * 4), 0
    for y in range(h):
        f = raw[i]
        line = bytearray(raw[i + 1:i + 1 + stride])
        i += 1 + stride
        if f == 1:
            for x in range(ch, stride):
                line[x] = (line[x] + line[x - ch]) & 255
        elif f == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif f == 3:
            for x in range(stride):
                line[x] = (line[x] + (((line[x - ch] if x >= ch else 0) + prev[x]) >> 1)) & 255
        elif f == 4:
            for x in range(stride):
                a = line[x - ch] if x >= ch else 0
                b, c = prev[x], (prev[x - ch] if x >= ch else 0)
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else (b if pb <= pc else c))) & 255
        elif f != 0:
            return None
        prev = line
        o = y * w * 4
        if ctype == 6:
            out[o:o + w * 4] = line
            continue
        for x in range(w):
            if ctype == 6:
                out[o + 4 * x:o + 4 * x + 4] = line[4 * x:4 * x + 4]
            elif ctype == 2:
                out[o + 4 * x:o + 4 * x + 4] = line[3 * x:3 * x + 3] + b"\xff"
            elif ctype == 0:
                out[o + 4 * x:o + 4 * x + 4] = bytes((line[x],) * 3) + b"\xff"
            elif ctype == 4:
                out[o + 4 * x:o + 4 * x + 4] = bytes((line[2 * x],) * 3) + bytes((line[2 * x + 1],))
            else:
                k = line[x]
                out[o + 4 * x:o + 4 * x + 4] = plte[3 * k:3 * k + 3] + bytes((trns[k] if k < len(trns) else 255,))
    return w, h, out


def _logo_sigs(data):
    """(hash של הפיקסלים המפוענחים, חתימה תפיסתית 16x16) — מזהה לוגו שלו גם אחרי שנשמר מחדש בדחיסה אחרת או הוקטן.
    PNG פשוט מפוענח כאן; אחר — דרך PIL אם קיים; אחרת None."""
    try:
        dec = _png_rgba(data)
    except Exception:
        dec = None
    if dec is None:
        try:
            from PIL import Image
            im = Image.open(io.BytesIO(data)).convert("RGBA")
            dec = (im.size[0], im.size[1], bytearray(im.tobytes()))
        except Exception:
            return None
    w, h, px = dec
    exact = hashlib.sha256(("%dx%d" % (w, h)).encode() + bytes(px)).hexdigest()
    # חתימה תפיסתית: 16x16 תאים, ממוצע בהירות על רקע לבן (שקיפות נחשבת), מול הממוצע הכללי
    cells = [[0.0, 0] for _ in range(256)]
    for y in range(h):
        cy = min(15, y * 16 // h)
        for x in range(w):
            r, g, b, a = px[4 * (y * w + x):4 * (y * w + x) + 4]
            lum = (0.299 * r + 0.587 * g + 0.114 * b) * a / 255 + 255 * (255 - a) / 255
            c = cells[cy * 16 + min(15, x * 16 // w)]
            c[0] += lum
            c[1] += 1
    vals = [c[0] / c[1] if c[1] else 255.0 for c in cells]
    avg = sum(vals) / 256
    return exact, sum(1 << k for k, v in enumerate(vals) if v >= avg)


def his_logo_sigs():
    sigs = []
    files = set(CONFIG.joinpath("brand").glob("*.png")) if (CONFIG / "brand").is_dir() else set()
    if os.environ.get("SHORTS_LOGO"):
        files.add(Path(os.environ["SHORTS_LOGO"]))
    for f in files:
        try:
            s = _logo_sigs(f.read_bytes())
        except OSError:
            continue
        if s:
            sigs.append(s)
    return sigs


def identity_needles(profile):
    """כל מה שמזהה אותו — בכל חבילה: שם המשתמש/הבית שלו; בחבילת פרופיל גם 'בית אל'."""
    n = list(IDENT_NEEDLES)
    if profile:
        n += [base64.b64decode(x).decode("utf-8") for x in _PROFILE_NEEDLES_B64]
    return [x.lower().encode("utf-8") for x in n]


RELEASE_BASE_RE = re.compile(r"^https://raw\.githubusercontent\.com/([A-Za-z0-9-]{1,39})/([A-Za-z0-9._-]{1,100})/main$")


def release_base_parts(base):
    """4.7.8: כתובת הריפו הציבורי של העדכונים (https://raw.githubusercontent.com/<חשבון>/<ריפו>/main) → (חשבון, ריפו) או None.
    הבעלים החליט שהריפו יושב בחשבון שלו, לכן שם החשבון (ורק הוא, ורק בכתובת הזאת) מותר ב-assets/release_source.json."""
    m = RELEASE_BASE_RE.match(base or "")
    return (m.group(1), m.group(2)) if m else None


def _scrub_release_source(data):
    """מוציא מתוך assets/release_source.json את כתובת הבסיס המאושרת (בדיוק בתבנית למעלה, ושם הריפו עצמו ניטרלי) לפני סריקת הזהות."""
    try:
        d = json.loads(data.decode("utf-8"))
        base = d.get("base", "")
        if d.get("account_approved") is not True:       # הדגל נכתב רק ע"י setup(allow_account=True) — החלטה מפורשת של הבעלים
            return data
    except (ValueError, UnicodeDecodeError, AttributeError):
        return data
    parts = release_base_parts(base)
    if not parts or any(n in parts[1].lower().encode() for n in identity_needles(False)):
        return data
    return data.replace(base.encode("utf-8"), b"")


def identity_scan(zpath, profile=True, logos_dup=True):
    """3.5: בחבילת פרופיל — אף קובץ (חוץ ממוזיקה) לא מכיל את המחרוזות שלו ואף קובץ אינו הלוגו שלו.
    4.1.0: גם בחבילה רגילה (profile=False) נבדקים שם המשתמש/הבית/GitHub שלו; הבדיקה לא רגישה לאותיות ומפענחת UTF-16;
    בחבילת פרופיל הלוגו נבדק גם בהשוואת פיקסלים (לא רק hash של הקובץ), ונתיב /home/ אסור בכל extras/."""
    needles = identity_needles(profile)
    if profile:
        needles += [s.lower().encode("utf-8") for s in his_strings()]
    logos = his_logo_hashes() if profile else set()
    sigs = his_logo_sigs() if profile and logos_dup else []
    bad = []
    with zipfile.ZipFile(zpath) as z:
        for i in z.infolist():
            if i.filename.endswith(".mp3"):
                continue
            data = z.read(i)
            if profile and hashlib.sha256(data).hexdigest() in logos:
                bad.append(i.filename + " (הלוגו שלך)")
                continue
            if profile and i.filename.lower().endswith(".png") and sigs:
                s = _logo_sigs(data)
                if s and any(s[0] == e or bin(s[1] ^ a).count("1") <= 8 for e, a in sigs):
                    bad.append(i.filename + " (נראה כמו הלוגו שלך)")
                    continue
            if i.filename == "assets/release_source.json":
                data = _scrub_release_source(data)
            vs = _variants(data)
            if any(n in v for n in needles for v in vs):
                bad.append(i.filename)
            elif i.filename.startswith("extras/") and any(b"/home/" in v for v in vs):
                bad.append(i.filename + " (נתיב /home/)")
    return bad


def apply_profile(pjson, settings):
    """אצל המקבל (נקרא מההתקנה): ערכי הפרופיל נכתבים רק למפתחות שעוד אין בקובץ ההגדרות שלו — מה שהוא כבר
    שינה לא נדרס לעולם. משפט הרשמה ריק בפרופיל = לא נכתב (נשארת ברירת המחדל הכללית)."""
    try:
        prof = json.loads(Path(pjson).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        prof = None
    if not isinstance(prof, dict):               # קובץ פרופיל חסר / שבור / לא אובייקט — ההתקנה לא קורסת, פשוט אין מה לכתוב
        return []
    sp = Path(settings)
    d = _read_settings(sp)
    if not isinstance(d.get("values"), dict):
        d["values"] = {}
    vals = d["values"]
    added = []
    for k in PROFILE_KEYS:
        v = prof.get(k)
        if k in vals or not isinstance(v, str) or (k == "subscribe_text" and not v.strip()):
            continue
        vals[k] = v
        added.append(k)
    # 4.0: איזה פרופיל הגיע עם החבילה — להודעה במסך "🧭 צעדים ראשונים". רק בהתקנה הראשונה עם פרופיל (לא נדרס)
    name = " ".join(str(prof.get("name") or "").split())[:60]
    if name and "profile_from" not in vals:
        vals["profile_from"] = name
        added.append("profile_from")
    if added:
        _write_settings(sp, d)
    return added


def _read_settings(sp):
    """4.1.0: רק 'הקובץ לא קיים' = הגדרות ריקות. קובץ שבור (או שאינו אובייקט) לא נדרס בשקט: הוא נשמר כ-.bak ורק אז
    נכתב חדש. קובץ שאי אפשר לקרוא (הרשאות, דיסק) — עוצרים עם הודעה, בלי לכתוב כלום."""
    try:
        text = Path(sp).read_text(encoding="utf-8")
    except FileNotFoundError:
        return {}
    except OSError as e:
        raise SystemExit("❌ אי אפשר לקרוא את קובץ ההגדרות (%s) — לא שיניתי כלום. לבדוק הרשאות ומקום פנוי ולהריץ שוב." % e.strerror)
    try:
        d = json.loads(text)
        if isinstance(d, dict):
            return d
    except ValueError:
        pass
    bak = Path(str(sp) + ".bak")
    n = 1
    while bak.exists():
        n += 1
        bak = Path("%s.bak%d" % (sp, n))
    try:
        os.replace(sp, bak)
    except OSError as e:
        raise SystemExit("❌ קובץ ההגדרות פגום ואי אפשר לשמור ממנו עותק (%s) — לא שיניתי כלום." % e.strerror)
    print("  ⚠️ קובץ ההגדרות היה פגום — נשמר עותק בשם %s" % bak.name, flush=True)
    return {}


def _write_settings(sp, d):
    try:
        sp.parent.mkdir(parents=True, exist_ok=True)
        tmp = sp.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, sp)
    except OSError as e:
        raise SystemExit("❌ אי אפשר לכתוב את קובץ ההגדרות (%s). לבדוק מקום פנוי והרשאות ולהריץ שוב." % e.strerror)


def receiver_init(settings):
    """4.0, אצל המקבל (נקרא מההתקנה מחבילה, תמיד — עם פרופיל או בלי): תצוגה פשוטה ומסך "🧭 צעדים ראשונים" שעוד לא
    נראה — רק אם עוד אין לו בחירה משלו. כך התקנה מחדש לא מחזירה לפשוט מי שעבר למתקדם, ולא פותחת שוב את המסך.
    (קובץ הגדרות קיים בלי view_mode היה נחשב "מלפני 4.0" = מתקדם; כאן ההתקנה אומרת במפורש שזה מקבל.)"""
    sp = Path(settings)
    d = _read_settings(sp)
    if not isinstance(d.get("values"), dict):
        d["values"] = {}
    vals, added = d["values"], []
    for k, v in (("view_mode", "simple"), ("first_steps_seen", False)):
        if k not in vals:
            vals[k] = v
            added.append(k)
    if added:
        _write_settings(sp, d)
    return added


def known_secrets():
    """הערכים האמיתיים שלו — רק כדי לוודא שהם *לא* בחבילה. נקראים כאן ולא מודפסים לעולם."""
    vals = []
    try:
        for line in (CONFIG / "config.env").read_text(encoding="utf-8").splitlines():
            if line.startswith("GEMINI_API_KEY=") and len(line) > 30:
                k = line.split("=", 1)[1].strip().strip('"')
                vals += [k.encode(), k[-8:].encode()]
    except OSError:
        pass
    for f in (os.environ.get("MODAL_CONFIG_PATH"), os.path.expanduser("~/.modal.toml"),
              os.path.expanduser("~/.config/rclone/rclone.conf")):
        try:
            for m in re.finditer(r"(?:token_id|token_secret|refresh_token|access_token|client_secret)\W+([\w./\-]{16,})",
                                 Path(f).read_text(encoding="utf-8", errors="replace")):
                vals.append(m.group(1).encode())
        except (OSError, TypeError):
            pass
    try:
        for line in (CONFIG / "youtube_cookies.txt").read_text(encoding="utf-8", errors="replace").splitlines():
            f = line.split("\t")
            if len(f) >= 7 and len(f[6]) >= 20:
                vals.append(f[6].encode())
    except OSError:
        pass
    return [v for v in set(vals) if len(v) >= 8]


def scan(zpath):
    """כל קובץ בחבילה (פתוח מהדחיסה) + הקובץ הגולמי — אף סוד. מחזיר רשימת שמות חשודים."""
    vals, bad = known_secrets(), []
    with zipfile.ZipFile(zpath) as z:
        for i in z.infolist():
            name_l = i.filename.lower()
            # 22/10 (כרטיס 14): גם מה שאישי בלי להיות סוד — לייקים, הגדרות, מכסות, תור, גיבוי ממתין
            if re.search(r"(^|/)(config\.env|\.modal\.toml|rclone\.conf|youtube_cookies\.txt)$|\.env$|"
                         r"(^|/)(music-feedback[^/]*\.json|make_short_settings[^/]*\.json|gemini_usage[^/]*\.json|"
                         r"build_queue[^/]*\.json|drive_(pending|status)[^/]*\.json|app_tabs\.json|\.git-credentials)$", name_l):
                bad.append(i.filename)
                continue
            data = z.read(i)
            text_like = not i.filename.endswith(".mp3")
            vs = _variants(data)             # 4.1.0: אותיות קטנות + UTF-16 מפוענח
            if text_like and any(p.search(v) for p in SECRET_PATTERNS for v in vs):
                bad.append(i.filename)
            elif any(v.lower() in x for v in vals if text_like or len(v) >= 16 for x in vs):
                bad.append(i.filename)
    return bad


INSTALL_BAT = (REPO / "windows" / "package_setup.bat.txt")

# 4.1.0: מה שלא נארז בחבילה — מסמכים אישיים של הבעלים (היסטוריית שינויים, מדריך ההעברה שלו)
PACKAGE_EXCLUDE = ("CHANGELOG.md", "docs/\u05de\u05d3\u05e8\u05d9\u05da-\u05d4\u05e2\u05d1\u05e8\u05d4-\u05dc\u05de\u05d7\u05e9\u05d1-\u05d0\u05d7\u05e8.md")
_TEXT_EXT = (".py", ".md", ".sh", ".ps1", ".html", ".txt", ".bat", ".json", ".cfg", ".toml", ".yml", ".yaml")
GH_BEGIN, GH_END = "# <GITHUB-FLOW-BEGIN>", "# <GITHUB-FLOW-END>"


def strip_github_flow(text):
    """בחבילה ההתקנה לא מדברת עם GitHub של הבעלים: הקטע שבין הסימונים (כתובת הריפו, הטוקן, זהות הגיט) יוצא (4.1.0)."""
    return re.sub(re.escape(GH_BEGIN) + r".*?" + re.escape(GH_END) + r"[ \t]*\r?\n", "", text, flags=re.S)


def neutralize(text, profile):
    """החלפת מחרוזות הזהות שלו בטקסט שנארז (הערות, מדריכים): לא משנה התנהגות — רק מילים בתוך הערות ומסמכים."""
    t = text.replace("C:\\Users\\" + _OWN_HOME, "C:\\Users\\<user>").replace(_OWN_HOME, "<user>")
    t = t.replace("/home/" + _OWN_USER, "/home/<user>").replace(_OWNER, "<owner>")
    t = re.sub(r"\b" + _OWN_USER + r"\b", "<user>", t, flags=re.I)
    if profile:
        b, h = (base64.b64decode(x).decode("utf-8") for x in _PROFILE_NEEDLES_B64)
        t = t.replace(b, "the yeshiva").replace(h, "\u05d4\u05d9\u05e9\u05d9\u05d1\u05d4")
    return t


def handoff_for_package(text):
    """docs/HANDOFF.md כפי שהוא נארז: בלי הסעיף על האנשים וההיסטוריה (§10) — השאר נשאר, כי חלון 'עבודה עם צ'אט' מסתמך עליו."""
    m = re.search(r"^## 10\..*?(?=^## 11\.|\Z)", text, flags=re.S | re.M)
    return text[:m.start()] + text[m.end():] if m else text


def package_member(name, data, profile):
    """(שם, bytes) כפי שייכנס ל-zip, או None אם לא נארז."""
    rel = name
    if unicodedata.normalize("NFC", rel) in {unicodedata.normalize("NFC", x) for x in PACKAGE_EXCLUDE}:
        return None
    if not rel.lower().endswith(_TEXT_EXT):
        return name, data
    try:
        text = data.decode("utf-8-sig")
    except UnicodeError:
        return name, data
    bom = data.startswith(b"\xef\xbb\xbf")
    if rel == "windows/install_windows.ps1":
        text = strip_github_flow(text)
    if rel == "docs/HANDOFF.md":
        text = handoff_for_package(text)
    text = neutralize(text, profile)
    return name, text.encode("utf-8-sig" if bom else "utf-8")


def readme(meta):
    return """יצירת שורטס — התקנה במחשב ווינדוס
=====================================
נוצר: {made} · גרסה: {commit}{prof}

מה עושים:
  1. לחיצה ימנית על קובץ ה-zip ← "חלץ הכול" (Extract All) ← חלץ.
     (בלי לחלץ ההתקנה לא תעבוד — היא צריכה את כל הקבצים שבתיקייה.)
  2. בתיקייה שנוצרה: לחיצה כפולה על "התקנה.bat".
  3. לעקוב אחרי ההוראות בחלון. בפעם הראשונה ווינדוס עשוי לבקש הפעלה מחדש —
     אחריה לוחצים שוב על התקנה.bat, וההתקנה ממשיכה מאותו מקום.

מה צריך: ווינדוס 10 (גרסה 2004 ומעלה) או 11, חיבור לאינטרנט, כ-5GB פנויים.
אורך: 15–40 דקות (הרבה ממנו הורדות).

מה מגיע מוכן בחבילה: התוכנה, {tracks} מנגינות רקע עם הרישיונות, הלוגו, ההנחיות לבחירת קטעים.
מה אפשר לחבר בעצמכם — הכול לא חובה, ואת כל החיבורים מסביר המסך "🧭 צעדים ראשונים" שנפתח לבד בפעם הראשונה בחלון התוכנה:
  - Modal (תמלול מהיר בענן) — חשבון משלכם (modal.com; דורש כרטיס אשראי, קרדיט חינמי 30$ בחודש). ההתקנה תציע לחבר אותו;
    אם אין לכם עדיין — אפשר לדלג ולחבר אחר כך. בלעדיו התמלול רץ על המחשב, איטי מאוד.
    רוצים תמלול מהיר? פתחו חשבון ב-modal.com לפני ההתקנה (או דלגו וחברו אחר כך).
  - Gemini (לא חובה) — בחירת קטעים אוטומטית. בלעדיו: "העתק לצ'אט" עם כל צ'אט חינמי.
  - עוגיות יוטיוב (לא חובה) — רק לשיעורים מתוזמנים או פרטיים.{drive}

אחרי ההתקנה: קיצור "יצירת שורטס" על שולחן העבודה.
התקנה מחדש מעל התקנה קיימת שומרת את ההגדרות, המפתחות והמוזיקה שכבר יש לכם.
""".format(made=meta["made"], commit=meta["commit"], tracks=meta["music_tracks"],
           prof=("\nמותאם ל: %s (הלוגו, השורות בסוף כל תיאור ושם הישיבה — אפשר לשנות בהגדרות)" % meta["profile"]["name"])
           if meta.get("profile") else "",
           drive="\n  - Google Drive משלכם (לא חובה) — גיבוי של כל שורט מוכן; מחברים מתוך \"🧭 צעדים ראשונים\" (מפתח אישי, כ-15 דקות)."
           if meta["drive_offer"] else "")


def build(out_dir, drive, profile_id=None):
    out_dir.mkdir(parents=True, exist_ok=True)
    commit = git("rev-parse", "--short", "HEAD")
    if not commit:
        raise SystemExit("❌ זה לא ריפו גיט — אין ממה לארוז קוד")
    prof = None
    if profile_id:
        prof = profile_get(profile_id)
        if not prof:
            raise SystemExit("❌ הפרופיל לא נמצא (אולי נמחק) — לבחור פרופיל אחר או \"בלי פרופיל\"")
    if git("status", "--porcelain", "--untracked-files=no"):
        say("⚠️ יש שינויים בקוד שעוד לא נשמרו (commit) — הם לא ייכנסו לחבילה. נכנסת הגרסה %s." % commit)
    day = time.strftime("%Y-%m-%d")
    ver = tool_version()
    tag = " - %s" % prof["name"] if prof else ""            # 3.5: שם הפרופיל בשם הקובץ, כדי שלא יתבלבלו
    name = "יצירת שורטס %s%s - %s.zip" % (ver, tag, day)
    n = 2
    while (out_dir / name).exists():
        name = "יצירת שורטס %s%s - %s (%d).zip" % (ver, tag, day, n)
        n += 1
    final = out_dir / name
    part = out_dir / (name + ".part")
    mf = music_files()
    meta = {"format": 1, "made": time.strftime("%Y-%m-%d %H:%M"), "version": ver, "commit":git("log", "-1", "--format=%h %cs"),
            "music_tracks": sum(1 for p, _ in mf if p.endswith(".mp3")), "drive_offer": bool(drive),
            "accounts": "none — the receiver connects their own Modal / Gemini"}
    if prof:
        meta["profile"] = {"id": prof["id"], "name": prof["name"]}
    if not INSTALL_BAT.exists():
        raise SystemExit("❌ חסר windows/package_setup.bat.txt")
    say("📦 בונה חבילה מגרסה %s%s ..." % (commit, " — פרופיל: %s" % prof["name"] if prof else ""))
    with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        # 1. הקוד — רק מה שב-commit
        tar = subprocess.run(["git", "-C", str(REPO), "archive", "--format=tar", "HEAD"], capture_output=True, check=True).stdout
        nfiles = 0
        with tarfile.open(fileobj=io.BytesIO(tar)) as t:
            for m in t.getmembers():
                if not m.isfile():
                    continue
                pm = package_member(m.name, t.extractfile(m).read(), bool(prof))   # 4.1.0: בלי מסמכים אישיים ובלי זהות
                if pm is None:
                    continue
                zi = zipfile.ZipInfo("code/" + pm[0], time.localtime(m.mtime)[:6])
                zi.external_attr = (m.mode & 0o777 | 0o100000) << 16
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, pm[1])
                nfiles += 1
        try:                                     # 4.4: ערוץ ההצעות למנהל — חבילות חדשות יכולות לשלוח הצעות מהרגע הראשון
            import make_short_proposals as PRP
            cb = PRP.channel_file_bytes()
            if cb:
                zi = zipfile.ZipInfo("code/" + PRP.CHANNEL_ASSET, time.localtime()[:6])
                zi.external_attr = (0o644 | 0o100000) << 16
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, cb)
                nfiles += 1
        except Exception:
            pass
        say("   ✓ קוד: %d קבצים" % nfiles)
        # 2. מוזיקה — mp3 בלי דחיסה (כבר דחוס); האינדקס עם נתיבים יחסיים (בלי שם המשתמש שלו)
        for arc, f in mf:
            z.write(f, arc, compress_type=zipfile.ZIP_STORED if f.suffix == ".mp3" else zipfile.ZIP_DEFLATED)
        idx_bytes, dropped = portable_index()
        if idx_bytes:
            z.writestr("extras/music/index.json", idx_bytes)
            if dropped:
                say("   ℹ️ %d קטעים באינדקס בלי קובץ בחבילה — הוצאו מהם הנתיבים" % dropped)
        say("   ✓ מוזיקה: %d מנגינות (%d MB)" % (meta["music_tracks"], sum(f.stat().st_size for _, f in mf) / 1e6))
        # 3. לוגו + הנחיות
        if prof:                                 # 3.5: של הפרופיל בלבד — אף פעם לא נופלים חזרה ללוגו / להנחיות שלו
            plogo = _pdir(prof["id"]) / "logo.png"
            if plogo.is_file():
                z.write(plogo, "extras/config/brand/logo.png")
                say("   ✓ הלוגו של %s" % prof["name"])
            else:
                say("   ⚠️ בפרופיל אין לוגו — המקבל יעלה אחד בהגדרות")
            z.write(NEUTRAL_GUIDELINES, "extras/config/guidelines.txt")
            say("   ✓ הנחיות כלליות (בלי קישורים של אף אחד)")
            z.writestr("extras/config/profile.json", json.dumps({k: prof[k] for k in ("name",) + PROFILE_KEYS},
                                                                 ensure_ascii=False, indent=1))
            say("   ✓ השורות בסוף התיאור, שם הישיבה%s" % (" ומשפט ההרשמה" if prof["subscribe_text"] else ""))
        else:
            lg = logo_file()
            if lg:
                z.write(lg, "extras/config/brand/logo.png")
                say("   ✓ הלוגו")
            else:
                say("   ⚠️ אין לוגו — המקבל יעלה אחד בהגדרות")
            if (CONFIG / "guidelines.txt").is_file():
                z.write(CONFIG / "guidelines.txt", "extras/config/guidelines.txt")
                say("   ✓ ההנחיות (guidelines.txt)")
        # 4. קבצי ההתחלה של המקבל
        z.writestr("התקנה.bat", INSTALL_BAT.read_bytes())
        z.writestr("קרא אותי.txt", readme(meta).replace("\n", "\r\n").encode("utf-8-sig"))
        z.writestr("package.json", json.dumps(meta, ensure_ascii=False, indent=1))
    say("🔎 בודק שאין בחבילה שום מפתח, עוגייה או טוקן ...")
    bad = scan(part)
    if bad:
        part.unlink()
        raise SystemExit("🚨 נמצא בחבילה משהו שנראה כמו סוד (%s) — החבילה נמחקה ולא נשלחה לשום מקום." % ", ".join(bad[:5]))
    say("🔎 בודק שאין בחבילה פרטים מזהים שלך%s ..." % (" (הלוגו, הקישורים ושם הישיבה)" if prof else ""))
    mine = identity_scan(part, profile=bool(prof))
    if mine and prof:
        part.unlink()
        raise SystemExit("🚨 בחבילה של %s נמצא משהו שלך (%s) — החבילה נמחקה. אם העלית לפרופיל את הלוגו או השורות "
                         "שלך — להחליף אותם בשל המקבל." % (prof["name"], ", ".join(mine[:5])))
    if mine:
        part.unlink()
        raise SystemExit("🚨 בחבילה נמצאו פרטים מזהים שלך (%s) — החבילה נמחקה ולא נשלחה לשום מקום." % ", ".join(mine[:5]))
    os.replace(part, final)
    say("   ✓ נקי")
    say("✅ נוצר: %s (%d MB)" % (final.name, final.stat().st_size / 1e6))
    print("FILE=%s" % final, flush=True)
    return final


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] not in ("build", "info", "profiles", "apply-profile", "receiver-init", "merge-music"):
        sys.exit(__doc__)
    if a[0] == "merge-music":                    # 4.1.0: ההתקנה אצל המקבל — קטעים חדשים לאינדקס שלו + mix.py עדכני
        n, mixed = merge_music(a[1], a[2])
        print("מוזיקה: %d קטעים חדשים באינדקס%s" % (n, " · mix.py עודכן" if mixed else ""))
        sys.exit(0)
    if a[0] == "info":
        print(json.dumps(info(), ensure_ascii=False))
        sys.exit(0)
    if a[0] == "profiles":
        print(json.dumps(profiles(), ensure_ascii=False))
        sys.exit(0)
    if a[0] == "apply-profile":                  # ההתקנה אצל המקבל
        got = apply_profile(a[1], a[2])
        print("פרופיל: " + ("נכתבו %s" % ", ".join(got) if got else "לא היה מה לכתוב (הערכים שלו כבר קיימים)"))
        sys.exit(0)
    if a[0] == "receiver-init":                  # 4.0: ההתקנה מחבילה — תצוגה פשוטה + צעדים ראשונים
        got = receiver_init(a[1])
        print("תצוגה: " + ("פשוטה, וצעדים ראשונים ייפתחו פעם אחת" if got else "נשארה הבחירה הקיימת"))
        sys.exit(0)
    out = Path(a[a.index("--out") + 1]) if "--out" in a else default_out()
    pid = a[a.index("--profile") + 1] if "--profile" in a else None
    f = build(out, "--drive" in a, pid)
    if "--prune" in a:                           # "🔁 בנה מחדש" / בנייה אחרי עדכון: רק החדש נשאר בתיקייה
        gone = prune(out, f, pid)
        if gone:
            say("🗑️ הקובץ הישן הועבר לסל המיחזור: %s" % ", ".join(gone))
