"""4.1.2 — שומר בטיחות: בדיקות לא נוגעות בהגדרות האמיתיות של הבעלים.

מקרה אמיתי (17–19/11/2026): ריצת בדיקות יצרה קבצי רב ושכתבה את make_short_settings.json האמיתי שלו, כי כמה נתיבים
(רבנים, ספריית הגדרות) לא הוגדרו מחדש בסביבת הבדיקה. עכשיו: במצב בדיקה (MAKE_SHORT_NO_EXPORT=1 או
MAKE_SHORT_TEST_GUARD=1) כל כתיבה לתיקיית ההגדרות האמיתית (~/.config/yeshiva-shorts, לפי משתמש המערכת ולא לפי $HOME —
כך HOME זמני לא מטעה) נעצרת בשגיאה רועמת. בלי תלות בשום מודול אחר, כדי שכולם יוכלו לייבא אותו ראשון.
"""
import os
from pathlib import Path


class RealConfigTouched(RuntimeError):
    pass


def real_home():
    try:
        import pwd
        return Path(pwd.getpwuid(os.getuid()).pw_dir)
    except Exception:
        return Path(os.path.expanduser("~"))


def real_dirs():
    h = real_home()
    return [(h / ".config" / "yeshiva-shorts").resolve(), (h / ".local" / "share" / "yeshiva-shorts").resolve()]


def test_mode():
    return os.environ.get("MAKE_SHORT_NO_EXPORT") == "1" or os.environ.get("MAKE_SHORT_TEST_GUARD") == "1"


def inside_real(path):
    p = Path(path).resolve()
    return any(p == r or r in p.parents for r in real_dirs())


def assert_not_real_config(path):
    """במצב בדיקה: כתיבה לנתיב בתוך התיקיות האמיתיות של הבעלים — שגיאה. מחוץ למצב בדיקה — לא עושה כלום."""
    if test_mode() and inside_real(path):
        raise RealConfigTouched("מצב בדיקה: ניסיון לכתוב בתיקייה האמיתית של הבעלים (%s) — עוצר. "
                                "בדיקה חייבת לרוץ עם HOME / SHORTS_CONFIG_DIR / SHORTS_DATA_DIR זמניים." % path)
