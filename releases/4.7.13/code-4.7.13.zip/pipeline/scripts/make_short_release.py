# -*- coding: utf-8 -*-
"""4.3 — עדכונים חתומים דרך האינטרנט: החלק המשותף (חתימה, מניפסט, בניית ארכיון) והצד של המקבל (בדיקה, החלה לפי סדר, חזרה).

למה ככה (ההחלטות של הבעלים, 19/11/2026):
  • הקוד אינו סוד — מה שחשוב הוא *מי חתם*. כל גרסה = ארכיון קוד נקי + מניפסט (JSON) + חתימה Ed25519.
    המפתח הציבורי נמצא בקוד (assets/release_source.json), המפתח הפרטי רק אצל הבעלים (מוצפן בסיסמה).
  • אימות החתימה כתוב בפייתון טהור (RFC 8032) — עובד בכל התקנה, בלי ספריות נוספות. החתימה עצמה (רק אצל הבעלים)
    משתמשת ב-cryptography.
  • העדכון על המחשב של המקבל הוא git: כל גרסה = commit + תגית rel-X.Y.Z. כך "חזרה לגרסה האחרונה התקינה" = git reset לתגית,
    ושלוש הגרסאות האחרונות נשארות. הטבלה: ראו HANDOFF §8m.
  • לעולם לא מדלגים על גרסה: מי שפספס כמה — מקבל אותן אחת אחת, כל אחת מאומתת לבדה.
  • עדכון שנקטע (חשמל, kill) מתוקן בהפעלה הבאה: shorts.sh (bash) או make_short_app (פייתון) מחזירים ל-commit שנרשם ביומן.

שימוש (לדיבוג):  shorts.sh py make_short_release.py check|status|recover|verify-manifest <dir>
"""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
STATE_DIR = DATA / "release_updates"
LOCAL_CHANGES = DATA / "local_changes"
SUPPORTED_FORMAT = 1
KEEP_TAGS = 3
MAX_LATEST, MAX_MANIFEST, MAX_ARCHIVE = 1 << 20, 4 << 20, 120 << 20
_VER = re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$")
GIT_ID = ["-c", "user.name=עדכון אוטומטי (יצירת שורטס)", "-c", "user.email=updates@invalid.local", "-c", "commit.gpgsign=false"]


class UpdateError(Exception):
    """הודעה בעברית פשוטה — אפשר להציג למשתמש כמו שהיא."""


class SimulatedCrash(BaseException):
    """רק לבדיקות: מדמה הפסקת חשמל — לא נתפסת ע"י except Exception, כך שהיומן נשאר (MAKE_SHORT_UPDATE_CRASH_AT)."""


def _crashpoint(name):
    if os.environ.get("MAKE_SHORT_UPDATE_CRASH_AT") == name:
        raise SimulatedCrash(name)


def _guard(path):
    try:
        import make_short_guard as G
        G.assert_not_real_config(path)
    except ImportError:
        pass


# ─────────────────────────── 4.5.x: זהות תהליך (מספר תהליך לבד חוזר על עצמו אחרי הפעלה מחדש של המחשב) ───────────────────────────
def _boot_id():
    try:
        return Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    except OSError:
        return ""


def proc_ident(pid=None):
    """'<boot_id>:<זמן התחלת התהליך>' (שדה 22 ב-/proc/<pid>/stat). '' אם אין /proc או שהתהליך לא קיים."""
    try:
        s = Path("/proc/%d/stat" % int(pid or os.getpid())).read_text()
        start = s[s.rindex(")") + 2:].split()[19]
    except (OSError, ValueError, IndexError):
        return ""
    b = _boot_id()
    return "%s:%s" % (b, start) if b else ""


def owner_alive(pid, ident, mtime=None, window=1200):
    """האם התהליך שכתב יומן עדיין רץ. עם זהות (4.5.x) — רק אם אותו אתחול ואותו זמן התחלה (לא תהליך אחר שקיבל את אותו מספר).
    יומן ישן בלי זהות — הכלל הישן: תהליך קיים + יומן טרי."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0 or pid == os.getpid():
        return False
    if ident:
        return proc_ident(pid) == ident
    if mtime is not None and time.time() - mtime >= window:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# ─────────────────────────── 4.5.x: נעילת git שנשארה מקריסה ───────────────────────────
def _gitdir(repo):
    g = Path(repo) / ".git"
    if g.is_file():
        try:
            t = g.read_text(encoding="utf-8").strip()
            if t.startswith("gitdir:"):
                p = Path(t[7:].strip())
                return p if p.is_absolute() else (Path(repo) / p)
        except OSError:
            pass
    return g


def git_busy(repo):
    """יש תהליך git חי שעובד על העץ הזה (לפי התיקייה שלו או שורת הפקודה)."""
    rp = str(Path(repo).resolve())
    try:
        procs = os.listdir("/proc")
    except OSError:
        return False
    for d in procs:
        if not d.isdigit() or int(d) == os.getpid():
            continue
        try:
            if Path("/proc", d, "comm").read_text().strip() != "git":
                continue
            cwd = os.readlink("/proc/%s/cwd" % d)
            cmd = Path("/proc", d, "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
        except OSError:
            continue
        if cwd == rp or cwd.startswith(rp + "/") or rp in cmd:
            return True
    return False


def unlock_stale(repo):
    """מוחק index.lock שנשאר מ-git שמת (כיבוי באמצע commit). לא נוגע אם git חי עובד עכשיו. מחזיר True אם נמחק."""
    lk = _gitdir(repo) / "index.lock"
    if lk.exists() and not git_busy(repo):
        try:
            lk.unlink()
            return True
        except OSError:
            pass
    return False


def _git_ok(repo, *a):
    try:
        return subprocess.run(["git", "-C", str(repo)] + list(a), capture_output=True, timeout=120).returncode == 0
    except Exception:
        return False


def hard_reset(repo, rev):
    """reset --hard שלא נכשל בגלל נעילה ישנה או אינדקס שבור: מסיר נעילה ישנה, ואם עדיין נכשל — בונה את האינדקס והקבצים
    מחדש מה-commit התקין (read-tree + checkout-index) ומעדכן את HEAD. נכשל לגמרי → UpdateError ברור."""
    for _ in range(2):
        unlock_stale(repo)
        if _git_ok(repo, "reset", "--hard", "-q", rev):
            return "reset"
    unlock_stale(repo)
    idx = _gitdir(repo) / "index"
    if _git_ok(repo, "read-tree", "--reset", "-u", rev) and _git_ok(repo, "update-ref", "HEAD", rev):
        return "read-tree"
    try:                                     # אינדקס פגום — מעבירים הצידה ובונים חדש מה-commit התקין
        if idx.exists():
            os.replace(idx, idx.with_name("index.broken-%d" % int(time.time())))
    except OSError:
        pass
    unlock_stale(repo)
    if _git_ok(repo, "read-tree", rev) and _git_ok(repo, "checkout-index", "-a", "-f") and _git_ok(repo, "update-ref", "HEAD", rev):
        _git_ok(repo, "reset", "--hard", "-q", rev)
        return "rebuild"
    raise UpdateError("לא הצלחנו להחזיר את קבצי התוכנה לגרסה התקינה (git נכשל). לא לעבוד עכשיו — לסגור ולפתוח שוב; "
                      "אם זה חוזר, לפנות למנהל.")


# ─────────────────────────── Ed25519 (RFC 8032) — אימות בפייתון טהור ───────────────────────────
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _inv(x):
    return pow(x, _P - 2, _P)


def _xrecover(y):
    xx = (y * y - 1) * _inv(_D * y * y + 1)
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if x % 2:
        x = _P - x
    return x


_BY = 4 * _inv(5) % _P
_B = (_xrecover(_BY) % _P, _BY)


def _add(a, b):
    x1, y1 = a
    x2, y2 = b
    t = _D * x1 * x2 * y1 * y2
    return ((x1 * y2 + x2 * y1) * _inv(1 + t) % _P, (y1 * y2 + x1 * x2) * _inv(1 - t) % _P)


def _mul(pt, e):
    r, q = (0, 1), pt
    while e:
        if e & 1:
            r = _add(r, q)
        q = _add(q, q)
        e >>= 1
    return r


def _decode(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= _P:
        return None
    x = _xrecover(y)
    if (-x * x + y * y - 1 - _D * x * x * y * y) % _P:
        return None
    if x == 0 and sign:
        return None
    if x & 1 != sign:
        x = _P - x
    return (x, y)


def ed25519_verify(pub, msg, sig):
    """True רק אם sig (64 בתים) היא חתימה תקפה של msg ע"י המפתח הציבורי pub (32 בתים). אף פעם לא זורק."""
    try:
        if len(pub) != 32 or len(sig) != 64:
            return False
        a, r = _decode(pub), _decode(sig[:32])
        s = int.from_bytes(sig[32:], "little")
        if a is None or r is None or s >= _Q:
            return False
        if _mul(a, 8) == (0, 1) or _mul(r, 8) == (0, 1):        # נקודות מסדר קטן — חתימה "מקרית" שמתאימה לכל הודעה
            return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _Q
        return _mul(_B, s) == _add(r, _mul(a, h))
    except Exception:
        return False


# ─────────────────────────── מקור העדכונים (כתובת + מפתח ציבורי) ───────────────────────────
def source():
    """(כתובת בסיס, [מפתחות ציבוריים base64]) — מהקובץ שבקוד (assets/release_source.json). משתני סביבה — לבדיקות בלבד."""
    base, keys = os.environ.get("MAKE_SHORT_RELEASES_BASE"), os.environ.get("MAKE_SHORT_RELEASE_PUBKEY")
    if base is None or keys is None:
        try:
            d = json.loads((REPO / "assets" / "release_source.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        base = d.get("base", "") if base is None else base
        keys = d.get("pubkey", "") if keys is None else keys
    return base.strip().rstrip("/"), [k.strip() for k in keys.split(",") if k.strip()]


def key_id(pub_b64):
    return hashlib.sha256(base64.b64decode(pub_b64)).hexdigest()[:8]


def ver_tuple(v):
    if not isinstance(v, str) or not _VER.match(v):
        raise UpdateError("מספר גרסה לא תקין: %r" % (v,))
    return tuple(int(x) for x in v.split("."))


def installed_version(repo=None):
    try:
        return ((repo or REPO) / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


# ─────────────────────────── מניפסט: אימות ───────────────────────────
def verify_manifest(raw, sig_b64, pubkeys):
    """raw = בתים של manifest.json כפי שהורדו. מחזיר את המילון רק אם החתימה תקפה לפחות במפתח אחד. אחרת UpdateError."""
    try:
        sig = base64.b64decode(sig_b64.strip(), validate=True)
    except Exception:
        raise UpdateError("החתימה של העדכון פגומה — לא מתקינים.")
    if not pubkeys:
        raise UpdateError("אין בתוכנה מפתח אימות לעדכונים — אי אפשר לבדוק חתימה.")
    if not any(ed25519_verify(base64.b64decode(k), raw, sig) for k in pubkeys):
        raise UpdateError("החתימה של העדכון לא תקינה (לא נחתם ע\"י הבעלים, או שהקובץ שונה בדרך) — לא מתקינים.")
    try:
        m = json.loads(raw.decode("utf-8"))
    except Exception:
        raise UpdateError("קובץ העדכון פגום — לא מתקינים.")
    if not isinstance(m, dict) or m.get("format") != SUPPORTED_FORMAT:
        raise UpdateError("העדכון בפורמט חדש שהגרסה הזאת עוד לא מכירה — צריך קודם עדכון ביניים.")
    ver_tuple(m.get("version"))
    for k in ("archive", "files", "notes"):
        if k not in m:
            raise UpdateError("במניפסט חסר: %s" % k)
    a = m["archive"]
    if not (isinstance(a, dict) and re.fullmatch(r"[0-9a-f]{64}", str(a.get("sha256", ""))) and isinstance(a.get("size"), int)):
        raise UpdateError("במניפסט פרטי הארכיון לא תקינים.")
    if not isinstance(m["files"], dict) or not m["files"] or not isinstance(m["notes"], list):
        raise UpdateError("במניפסט רשימת הקבצים או ההערות לא תקינה.")
    for p, f in m["files"].items():
        if not isinstance(f, dict) or not isinstance(f.get("mode", 0o644), int):
            raise UpdateError("במניפסט פרטי קובץ לא תקינים: %s" % str(p)[:80])
        if not _safe_path(p) or not re.fullmatch(r"[0-9a-f]{64}", str(f.get("sha256", ""))):
            raise UpdateError("במניפסט נתיב או חתימת קובץ לא תקינים: %s" % p)
    return m


FORBIDDEN_NAME = re.compile(r"(^|/)(config\.env|.*\.env|.*cookie.*|.*token.*|.*secret.*|.*\.toml|rclone\.conf|.*\.key|.*\.pem|"
                            r".*credential.*|.*\.vault|state\.json|release_key\.enc|.*\.enc)$", re.I)


def _safe_path(p):
    if not isinstance(p, str) or not p or p.startswith("/") or "\\" in p or "\x00" in p:
        return False
    parts = p.split("/")
    if any(x in ("", ".", "..") for x in parts) or parts[0] == ".git" or ".git" in parts:
        return False
    return not FORBIDDEN_NAME.search(p)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


# ─────────────────────────── הורדה (https, או file:// בבדיקות בלבד) ───────────────────────────
class UpdateCancelled(UpdateError):
    """המשתמש ביטל (רק בנקודות בטוחות: הורדה ואימות — אף פעם לא באמצע ההחלפה)."""


def fetch(base, rel, maxbytes, timeout=8, progress=None):
    """progress(בתים שירדו, סה"כ או None) — נקרא בכל חתיכה; יכול לזרוק UpdateCancelled כדי לעצור."""
    url = base.rstrip("/") + "/" + rel
    if not (url.startswith("https://") or (url.startswith("file://") and os.environ.get("MAKE_SHORT_RELEASES_BASE"))):
        raise UpdateError("כתובת העדכונים חייבת להיות https.")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "yeshiva-shorts-updater", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            try:
                total = int(r.headers.get("Content-Length") or 0) or None
            except (TypeError, ValueError):
                total = None
            if progress is None:
                data = r.read(maxbytes + 1)
            else:
                buf = bytearray()
                progress(0, total)
                while True:
                    chunk = r.read(262144)
                    if not chunk:
                        break
                    buf += chunk
                    if len(buf) > maxbytes:
                        break
                    progress(len(buf), total)
                data = bytes(buf)
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError("אין חיבור לשרת העדכונים (%s)" % type(e).__name__)
    if len(data) > maxbytes:
        raise UpdateError("קובץ עדכון גדול מהמותר — לא מורידים.")
    return data


def fetch_index(base):
    return fetch_index_bytes(fetch(base, "latest.json", MAX_LATEST))


def fetch_index_bytes(raw):
    try:
        d = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise UpdateError("רשימת העדכונים פגומה.")
    if not isinstance(d, dict) or d.get("format") != SUPPORTED_FORMAT or not isinstance(d.get("releases"), list):
        raise UpdateError("רשימת העדכונים בפורמט שלא מוכר.")
    out = []
    for r in d["releases"]:
        try:
            ver_tuple(r.get("version"))
            if not re.fullmatch(r"releases/\d+\.\d+\.\d+", str(r.get("path", ""))):
                continue
            out.append(r)
        except UpdateError:
            continue
    return sorted(out, key=lambda r: ver_tuple(r["version"]))


def next_entry(installed, entries, skip=()):
    """הגרסה הבאה לפי הסדר = הקטנה ביותר שגדולה מהמותקנת (לא דורסים סדר, לא קופצים לחדשה ביותר).
    skip = גרסאות שהמשתמש חזר מהן ידנית — לא מציעים שוב אוטומטית."""
    inst = ver_tuple(installed)
    for e in entries:
        if ver_tuple(e["version"]) > inst and e["version"] not in skip:
            return e
    return None


def effective_skip(entries, skip):
    """4.5.x (B1): גרסה שחזרו ממנה ידנית מדולגת רק כל עוד היא האחרונה. ברגע שיש גרסה חדשה ממנה — הדילוג מתבטל
    (הגרסה החדשה בנויה עליה ודורשת אותה; בלי זה ההתקנה הייתה נתקעת לתמיד בלי הודעה). מחזיר (דילוגים שנשארים, שבוטלו)."""
    vs = [ver_tuple(e["version"]) for e in entries]
    keep, dropped = [], []
    for s in skip or ():
        try:
            st = ver_tuple(s)
        except UpdateError:
            continue
        (dropped if any(v > st for v in vs) else keep).append(s)
    return keep, dropped


def skip_note(dropped, entries):
    if not dropped:
        return ""
    return ("גרסה %s, שחזרתם ממנה, מוצעת שוב: יצאה גרסה חדשה יותר (%s) שבנויה עליה, ומתעדכנים לפי הסדר. "
            "אם משהו לא עובד אחרי העדכון — אפשר שוב לחזור לגרסה הקודמת." % (", ".join(dropped), entries[-1]["version"]))


def fetch_release(base, entry, pubkeys):
    """מוריד מניפסט + חתימה ומאמת. מחזיר (מניפסט, בתים)."""
    raw = fetch(base, entry["path"] + "/manifest.json", MAX_MANIFEST)
    sig = fetch(base, entry["path"] + "/manifest.sig", 4096).decode("ascii", "replace")
    m = verify_manifest(raw, sig, pubkeys)
    if m["version"] != entry["version"]:
        raise UpdateError("המניפסט לא תואם לגרסה שברשימה — לא מתקינים.")
    return m, raw


def check_chain(m, installed):
    """תקינות מול המותקן: לא לאחור, ושרשרת/מינימום."""
    if ver_tuple(m["version"]) <= ver_tuple(installed):
        raise UpdateError("העדכון אינו חדש יותר מהגרסה המותקנת (%s) — לא מחזירים אחורה." % installed)
    mr = m.get("min_required") or m.get("previous")
    if mr and ver_tuple(installed) < ver_tuple(mr):
        raise UpdateError("כדי לעדכן ל-%s צריך קודם גרסה %s — מתעדכנים לפי הסדר." % (m["version"], mr))


def check(installed=None, skip=(), pubkeys=None, base=None):
    """בדיקה בלי להתקין: מה הגרסה הבאה, מה חדש. מחזיר dict. שגיאת רשת = UpdateError (המתקשר שותק)."""
    b, ks = source()
    base, pubkeys = base or b, pubkeys or ks
    installed = installed or installed_version()
    if not base:
        return {"configured": False, "available": False, "installed": installed}
    entries = fetch_index(base)
    latest = entries[-1]["version"] if entries else installed
    skip, dropped = effective_skip(entries, skip)
    e = next_entry(installed, entries, skip)
    out = {"configured": True, "available": False, "installed": installed, "latest": latest, "at": int(time.time()),
           "skip": skip, "skip_note": skip_note(dropped, entries)}
    if not e:
        return out
    m, _ = fetch_release(base, e, pubkeys)
    check_chain(m, installed)
    steps = [x["version"] for x in entries if ver_tuple(x["version"]) > ver_tuple(installed) and x["version"] not in skip]
    out.update(available=True, version=m["version"], notes=m["notes"], date=m.get("date", ""), size=m["archive"]["size"],
               must_not_skip=bool(m.get("must_not_skip")), steps=steps)
    return out


def download_release(base, entry, m, stage_root, progress=None):
    """מוריד את הארכיון, מאמת sha256 של הארכיון ושל כל קובץ, ומחלץ ל-stage_root/<ver>/tree. מחזיר את תיקיית העץ."""
    data = fetch(base, entry["path"] + "/" + m["archive"]["name"], MAX_ARCHIVE, timeout=60, progress=progress)
    return unpack_verified(data, m, stage_root)


def unpack_verified(data, m, stage_root):
    if len(data) != m["archive"]["size"] or sha256(data) != m["archive"]["sha256"]:
        raise UpdateError("הארכיון שהורד לא תואם לחתימה (פגום או שונה) — לא מתקינים.")
    root = Path(stage_root) / m["version"]
    tree = root / "tree"
    shutil.rmtree(root, ignore_errors=True)
    tree.mkdir(parents=True)
    names = set()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            if not _safe_path(i.filename) or ((i.external_attr >> 16) & 0o170000) == 0o120000:
                raise UpdateError("בארכיון נתיב אסור: %s" % i.filename)
            f = m["files"].get(i.filename)
            b = z.read(i)
            if f is None or sha256(b) != f["sha256"]:
                raise UpdateError("קובץ בארכיון לא תואם לחתימה: %s" % i.filename)
            dest = tree / i.filename
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(b)
            names.add(i.filename)
    if names != set(m["files"]):
        raise UpdateError("בארכיון חסרים או מיותרים קבצים לעומת המניפסט — לא מתקינים.")
    if (tree / "VERSION").read_text(encoding="utf-8").strip() != m["version"]:
        raise UpdateError("קובץ הגרסה שבארכיון לא תואם למניפסט — לא מתקינים.")
    return tree


# ─────────────────────────── git ───────────────────────────
def git(repo, *a, check=True, inp=None):
    r = subprocess.run(["git", "-C", str(repo)] + list(a), capture_output=True, input=inp, timeout=120)
    if check and r.returncode != 0:
        raise UpdateError("git נכשל (%s): %s" % (a[0], r.stderr.decode("utf-8", "replace").strip()[-200:]))
    return r.stdout.decode("utf-8", "replace").strip()


def rel_tags(repo):
    out = git(repo, "tag", "--list", "rel-*", check=False).split()
    vs = []
    for t in out:
        try:
            vs.append((ver_tuple(t[4:]), t))
        except UpdateError:
            pass
    return [t for _, t in sorted(vs)]


def update_mode(repo=None):
    """'owner' = עץ הפיתוח של הבעלים (יש origin ואין סימון חבילה) — לא מתעדכן מהאינטרנט. 'receiver' = התקנה מחבילה.
    'none' = אין git. MAKE_SHORT_UPDATE_MODE — לבדיקות."""
    ov = os.environ.get("MAKE_SHORT_UPDATE_MODE")
    if ov in ("owner", "receiver", "none"):
        return ov
    repo = repo or REPO
    if not (repo / ".git").exists():
        return "none"
    if (repo / ".from_package").exists():
        return "receiver"
    return "owner" if git(repo, "remote", "get-url", "origin", check=False) else "receiver"


# ─────────────────────────── יומן עדכון שנקטע + התאוששות ───────────────────────────
def _journal(sd=None):
    return (sd or STATE_DIR) / "pending.json", (sd or STATE_DIR) / "pending.sha"


def _write_journal(repo, data, sd=None):
    sd = sd or STATE_DIR
    _guard(sd)
    sd.mkdir(parents=True, exist_ok=True)
    jp, sp = _journal(sd)
    ident = proc_ident()
    data = dict(data, repo=str(repo), pid=os.getpid(), ident=ident)
    for p, txt in ((jp, json.dumps(data, ensure_ascii=False)),
                   (sp, data["base"] + "\n" + str(repo) + "\n" + str(os.getpid()) + "\n" + ident + "\n")):
        tmp = p.with_suffix(p.suffix + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(txt)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)


def _clear_journal(sd=None):
    for p in _journal(sd):
        try:
            p.unlink()
        except OSError:
            pass


def _restore(repo, base, added, tag=None):
    hard_reset(repo, base)
    for p in added:
        f = repo / p
        try:
            if f.is_file() and not git(repo, "ls-files", "--", p, check=False):
                f.unlink()
        except OSError:
            pass
    if tag:
        git(repo, "tag", "-d", tag, check=False)


def recover(repo=None, sd=None):
    """הפעלה: מתאוששים מעדכון רשמי שנקטע, ואז (4.5) מהחלה-מחדש של שינויים אישיים שנקטעה. מחזיר טקסט להצגה או ''."""
    msg = _recover_release(repo, sd)            # כשל אמיתי → UpdateError (האפליקציה מציגה אותו בדף, לא רק ביומן)
    try:
        import make_short_personal as PC
    except Exception:
        PC = None
    m2 = ""
    if PC is not None:
        try:
            m2 = PC.recover(repo)
        except Exception as e:                  # 4.5.x (C4): לא בולעים — מציגים
            m2 = "⚠ החזרת השינויים האישיים שנקטעה לא הסתיימה (%s). השינויים שמורים; לפתוח את 'שינויים אישיים שלי'." % (
                str(e)[:160] if isinstance(e, UpdateError) else type(e).__name__)
    return " ".join(x for x in (msg, m2) if x)


def _recover_release(repo=None, sd=None):
    """הפעלה: אם נשאר יומן — עדכון נקטע באמצע; חוזרים ל-commit התקין האחרון. מחזיר טקסט להצגה או ''."""
    repo, sd = repo or REPO, sd or STATE_DIR
    jp, sp = _journal(sd)
    if not jp.exists() and not sp.exists():
        return ""
    try:
        d = json.loads(jp.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
        try:
            ls = sp.read_text(encoding="utf-8").split("\n")
            d = {"base": ls[0].strip(), "added": [], "target": "?", "pid": ls[2].strip() if len(ls) > 2 else "",
                 "ident": ls[3].strip() if len(ls) > 3 else ""}
        except (OSError, IndexError):
            pass
    if not d.get("base"):
        _clear_journal(sd)
        return ""
    try:
        mt = (jp if jp.exists() else sp).stat().st_mtime
    except OSError:
        mt = None
    # עדכון שרץ *עכשיו* בתהליך אחר (למשל שרת הבדיקה של הבדיקה העצמית שאחרי ההחלה) — לא נוגעים; רק יומן של תהליך שמת.
    # 4.5.x (B4): לפי boot_id + זמן התחלת התהליך — מספר תהליך שחזר אחרי הפעלה מחדש של המחשב לא נחשב "חי"
    if owner_alive(d.get("pid"), d.get("ident"), mt):
        return ""
    # 4.5.x (B3): ביומן של "חזרה לגרסה קודמת" target = הגרסה הקודמת — התגית שלה היא הגרסה הטובה האחרונה; לא מוחקים אותה
    tag = "rel-" + d["target"] if d.get("target") not in (None, "?") and d.get("kind") != "rollback" else None
    _restore(repo, d["base"], d.get("added", []), tag)
    for dp, dns, fns in os.walk(repo):
        dns[:] = [x for x in dns if x != ".git"]
        for fn in fns:
            if fn.startswith(".") and fn.endswith(".ysnew"):
                try:
                    os.unlink(os.path.join(dp, fn))
                except OSError:
                    pass
    _clear_journal(sd)
    return "עדכון לגרסה %s נקטע באמצע (כנראה כיבוי או הפסקת חשמל) — חזרנו לגרסה התקינה האחרונה (%s)." % (
        d.get("target", "?"), installed_version(repo))


# ─────────────────────────── החלה ───────────────────────────
def _ensure_base_tag(repo):
    v = installed_version(repo)
    if v and f"rel-{v}" not in rel_tags(repo) and not git(repo, "status", "--porcelain", "--untracked-files=no"):
        git(repo, "tag", f"rel-{v}", "HEAD", check=False)


def save_local_changes(repo, installed, target, stage_tree=None):
    """שינויים מקומיים (בעץ או ב-commit של "תיבת העדכון") לעומת הגרסה המותקנת — נשמרים כקובץ patch לפני שדורסים. מחזיר נתיב או ''."""
    PC = _pc(repo)
    if PC:                                       # 4.5: עריכות ידניות שלא ב-commit נרשמות כשינוי אישי (לא רק קובץ patch בצד)
        try:
            PC.capture_manual(repo, installed, target, stage_tree)
        except Exception:
            pass
    tag = f"rel-{installed}"
    base = tag if tag in rel_tags(repo) else "HEAD"
    patch = subprocess.run(["git", "-C", str(repo), "diff", "--binary", base, "--"], capture_output=True, timeout=60).stdout
    extra = []
    if stage_tree is not None:
        for p in git(repo, "ls-files", "--others", "--exclude-standard").splitlines():
            if (stage_tree / p).exists():
                extra.append(p)
    if not patch.strip() and not extra:
        return ""
    _guard(LOCAL_CHANGES)
    LOCAL_CHANGES.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    out = LOCAL_CHANGES / ("%s_%s_לפני_%s.patch" % (ts, installed, target))
    out.write_bytes(patch)
    for p in extra:
        d = LOCAL_CHANGES / (ts + "_untracked") / p
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / p, d)
    if PC:
        PC.note_backup_file(out)                 # גיבוי בטיחות בלבד — לא יירשם שוב בהגירה
    return str(out)


def _pc(repo=None):
    """4.5: מודול השינויים האישיים (ייבוא מאוחר — הוא עצמו מייבא את המודול הזה). None אם לא מקבל או לא זמין."""
    try:
        import make_short_personal as PC
        return PC if PC.active(repo) else None
    except Exception:
        return None


def light_selfcheck(repo, files):
    """קומפילציה של כל קובץ .py, פענוח .json, bash -n לכל .sh — על מה שבדיסק (בלי להריץ כלום)."""
    bad = []
    for p in files:
        f = repo / p
        try:
            if p.endswith(".py"):
                compile(f.read_bytes(), p, "exec")
            elif p.endswith(".json"):
                json.loads(f.read_text(encoding="utf-8-sig"))
            elif p.endswith(".sh") and shutil.which("bash"):
                r = subprocess.run(["bash", "-n", str(f)], capture_output=True, timeout=30)
                if r.returncode:
                    bad.append(p)
        except Exception:
            bad.append(p)
    return bad


def apply_release(tree, m, repo=None, sd=None, check_fn=None, log=print, prog=None):
    """מחיל גרסה אחת מעץ מאומת. אטומי מבחינת התוצאה: או הגרסה החדשה (commit+תגית), או חזרה מלאה לקודמת. מחזיר dict."""
    repo, sd = repo or REPO, sd or STATE_DIR
    ver, installed = m["version"], installed_version(repo)
    check_chain(m, installed)
    if git(repo, "rev-parse", "--git-dir", check=False) == "":
        raise UpdateError("זו לא התקנה עם git — אי אפשר לעדכן.")
    if (sd / "pending.json").exists():
        raise UpdateError("יש עדכון שנקטע ועוד לא טופל — מפעילים מחדש את התוכנה.")
    _ensure_base_tag(repo)
    base = git(repo, "rev-parse", "HEAD")
    patch = save_local_changes(repo, installed, ver, tree)
    tracked = set(p for p in git(repo, "ls-files", "-z").split("\0") if p)
    files = m["files"]
    removed = sorted(tracked - set(files))
    added = sorted(set(files) - tracked)
    tag = "rel-" + ver
    _p = prog or (lambda pct, label: None)         # התקדמות ההחלה (0–100) עם תווית בעברית; מכאן אין ביטול — ההחלפה אטומית
    _write_journal(repo, {"base": base, "target": ver, "added": added, "removed": removed, "from": installed}, sd)
    tmps = []
    try:
        _p(5, "מכין את הקבצים החדשים")
        log("מכין את הקבצים החדשים ...")
        for p, meta in files.items():
            src, dst = Path(tree) / p, repo / p
            if dst.is_file() and not dst.is_symlink() and sha256(dst.read_bytes()) == meta["sha256"]:
                if (meta.get("mode", 0o644) & 0o111) and not os.access(dst, os.X_OK):
                    os.chmod(dst, 0o755)
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_name("." + dst.name + ".ysnew")
            shutil.copyfile(src, tmp)
            os.chmod(tmp, 0o755 if meta.get("mode", 0o644) & 0o111 else 0o644)
            tmps.append((tmp, dst))
        _crashpoint("before_rename")
        _p(35, "מחליף את הקבצים")
        for i, (tmp, dst) in enumerate(tmps):
            if dst.is_symlink():
                dst.unlink()
            os.replace(tmp, dst)
            if i == 0:
                _crashpoint("mid_rename")
        for p in removed:
            try:
                (repo / p).unlink()
            except OSError:
                pass
        _crashpoint("before_commit")
        _p(55, "שומר את הגרסה")
        git(repo, "add", "-f", "--", *sorted(files)) if files else None
        _crashpoint("mid_git")                         # 4.5.x (B2): כיבוי בתוך שלב ה-git (הבדיקה משאירה index.lock "מת")
        if removed:
            git(repo, "rm", "-q", "--cached", "--ignore-unmatch", "--", *removed)
        git(repo, *GIT_ID, "commit", "-q", "--allow-empty", "-m", "עדכון לגרסה %s" % ver)
        git(repo, "tag", "-f", tag, "HEAD")
        _crashpoint("after_commit")
        _p(70, "בודק שהכול תקין")
        log("בודק שהכול תקין ...")
        wrong = [p for p, meta in files.items() if sha256((repo / p).read_bytes()) != meta["sha256"]]
        if wrong:
            raise UpdateError("אחרי ההתקנה קבצים לא תואמים (%s)" % ", ".join(wrong[:3]))
        if installed_version(repo) != ver:
            raise UpdateError("קובץ הגרסה אחרי ההתקנה לא תואם")
        bad = light_selfcheck(repo, [p for p in files if p.endswith((".py", ".json", ".sh"))])
        if bad:
            raise UpdateError("בדיקה עצמית נכשלה בקבצים: %s" % ", ".join(bad[:3]))
        if check_fn:
            _p(80, "בדיקה עצמית של התוכנה החדשה")
            ok, why = check_fn()
            if not ok:
                raise UpdateError("הבדיקה העצמית של התוכנה נכשלה: %s" % str(why)[-200:])
        _p(97, "מסיים")
        if installed_version(repo) != ver or git(repo, "rev-parse", f"{tag}^{{commit}}", check=False) != git(repo, "rev-parse", "HEAD") \
                or any(sha256((repo / p).read_bytes()) != meta["sha256"] for p, meta in files.items()):
            raise UpdateError("אחרי הבדיקה העצמית העץ לא תואם לגרסה שהותקנה — לא ממשיכים.")
    except Exception as e:
        log("משהו השתבש — חוזרים לגרסה התקינה הקודמת ...")
        for tmp, _dst in tmps:                         # 4.5.x (B6): קבצי ביניים שלא הוחלפו — לא משאירים
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass
        _restore(repo, base, added, tag)               # נכשל → UpdateError והיומן נשאר (ההפעלה הבאה תנסה שוב)
        _clear_journal(sd)
        if isinstance(e, UpdateError):
            raise
        raise UpdateError("העדכון נכשל (%s: %s) — חזרנו לגרסה הקודמת, שום דבר לא נפגע." % (type(e).__name__, str(e)[:120]))
    _clear_journal(sd)
    _prune_tags(repo)
    return {"version": ver, "from": installed, "local_patch": patch, "base": base, "notes": list(m.get("notes", []))}


def _prune_tags(repo):
    tags = rel_tags(repo)
    for t in tags[:-KEEP_TAGS]:
        git(repo, "tag", "-d", t, check=False)


def rollback_previous(repo=None, sd=None, check_fn=None, personal_check=None):
    """"↩ חזור לגרסה הקודמת": לתגית rel- הקודמת. הגרסה שמחזירים ממנה לא תוצע שוב אוטומטית (רק חדשה ממנה)."""
    repo, sd = repo or REPO, sd or STATE_DIR
    cur = installed_version(repo)
    tags = [t for t in rel_tags(repo) if ver_tuple(t[4:]) < ver_tuple(cur)]
    if not tags:
        raise UpdateError("אין גרסה קודמת שמורה לחזור אליה.")
    prev = tags[-1]
    if (sd / "pending.json").exists():
        raise UpdateError("יש עדכון שנקטע ועוד לא טופל — מפעילים מחדש את התוכנה.")
    base = git(repo, "rev-parse", "HEAD")
    patch = save_local_changes(repo, cur, prev[4:])
    _write_journal(repo, {"base": base, "target": prev[4:], "added": [], "removed": [], "from": cur, "kind": "rollback"}, sd)
    try:
        hard_reset(repo, prev)
        _crashpoint("mid_rollback")
        if installed_version(repo) != prev[4:]:
            raise UpdateError("אחרי החזרה קובץ הגרסה לא תואם")
        if check_fn:
            ok, why = check_fn()
            if not ok:
                raise UpdateError("הבדיקה העצמית אחרי החזרה נכשלה: %s" % str(why)[-200:])
    except Exception:
        hard_reset(repo, base)                     # נכשל → UpdateError והיומן נשאר להפעלה הבאה
        _clear_journal(sd)
        raise
    git(repo, "tag", "-d", "rel-" + cur, check=False)
    _clear_journal(sd)
    st = load_state()
    st["skip"] = sorted(set(st.get("skip", [])) | {cur}, key=ver_tuple)
    save_state(st)
    personal = None
    PC = _pc(repo)
    if PC:                         # 4.5: הרישום נשאר שלם; השינויים הפעילים מוחלים מחדש על הגרסה הקודמת (כשל שלהם לא מבטל את החזרה)
        personal = PC.reapply(repo, personal_check, kind="rollback")
    return {"version": prev[4:], "from": cur, "local_patch": patch, "personal": personal}


def has_previous(repo=None):
    repo = repo or REPO
    cur = installed_version(repo)
    try:
        return any(ver_tuple(t[4:]) < ver_tuple(cur) for t in rel_tags(repo))
    except UpdateError:
        return False


# ─────────────────────────── 4.5.x (B7): הפעלות ראשונות של גרסה שהותקנה עכשיו ───────────────────────────
def official_commit(repo=None, version=None):
    """4.5.62: ה-commit *הרשמי* של גרסה (תגית rel-X) — לא ה-HEAD, שיכול להכיל שינויים אישיים. '' אם אין תגית."""
    repo = repo or REPO
    v = version or installed_version(repo)
    return git(repo, "rev-parse", "--verify", "-q", "rel-%s^{commit}" % v, check=False) if v else ""


def trial_begin(versions, prev_commit, repo=None, sd=None, official=""):
    """לפני ההפעלה מחדש אחרי עדכון: shorts.sh סופר הפעלות שלא הגיעו ל"תקין" (ראו הקטע ב-shorts.sh).
    official (4.5.62) = ה-commit הרשמי של הגרסה שלפני העדכון — shorts.sh מחזיר לו את התגית אם חוזרים ממנו."""
    sd = sd or STATE_DIR
    _guard(sd)
    sd.mkdir(parents=True, exist_ok=True)
    (sd / "trial").write_text("%s\n%s\n%s\n0\n%s\n" % (" ".join(versions), prev_commit, str(repo or REPO), official or ""),
                              encoding="utf-8")


def trial_ok(sd=None):
    """התוכנה רצה תקין — הגרסה החדשה עברה את ההפעלה הראשונה."""
    try:
        ((sd or STATE_DIR) / "trial").unlink()
    except OSError:
        pass


def startup_notes(sd=None, skip_update=False):
    """בהפעלה: הודעות מ-shorts.sh (שחזור שנכשל / גרסה שלא עלתה וחזרנו ממנה). מעדכן את מצב הדילוגים. מחזיר [(טקסט, כשל?)]."""
    sd = sd or STATE_DIR
    out = []
    f = sd / "recover_failed"
    if f.exists():
        out.append(("עדכון שנקטע באמצע לא הוחזר עד הסוף (git נכשל). לא לעבוד עכשיו — לסגור את התוכנה ולפתוח שוב; "
                    "אם ההודעה חוזרת — לפנות למנהל.", True))
        try:
            f.unlink()
        except OSError:
            pass
    f = sd / "trial_failed"
    if f.exists():
        try:
            vs = f.read_text(encoding="utf-8").split()
        except OSError:
            vs = []
        if vs:
            st = load_state()
            st["skip"] = sorted(set(st.get("skip", [])) | {vs[-1]}, key=ver_tuple)
            save_state(st)
            out.append(("הגרסה החדשה (%s) לא נפתחה כמו שצריך פעמיים — חזרנו לבד לגרסה הקודמת (%s). לא צריך לעשות כלום."
                        % (vs[-1], installed_version()), False))
        try:
            f.unlink()
        except OSError:
            pass
    elif skip_update and (sd / "trial").exists():
        out.append(("הגרסה החדשה לא נפתחה כמו שצריך בפעם הקודמת. אם משהו לא עובד — לחצו '↩ חזור לגרסה הקודמת' (בחלון «מה השתנה», או בהגדרות המתקדמות). "
                    "(אם גם הפעם היא לא תיפתח — נחזור לבד.)", False))
    return out


# ─────────────────────────── מצב (בדיקה אחרונה, גרסאות שדולגו) ───────────────────────────
def load_state():
    try:
        return json.loads((STATE_DIR / "state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_state(st):
    _guard(STATE_DIR)
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_DIR / "state.json.tmp"
    tmp.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, STATE_DIR / "state.json")


def run_updates(repo=None, check_fn=None, log=print, stage_root=None, sd=None, max_steps=20, progress=None, cancel=None,
                personal_check=None, on_installed=None):
    """progress(dict): stage = checking | downloading | verifying | applying; label (עברית), pct (0–100 של השלב), done/total בתים
    (בהורדה), step/steps ("גרסה 2 מתוך 3"), cancellable (נכון בהורדה ובאימות; שקר בהחלפה עצמה). cancel() → True = לעצור."""
    """מתקין לפי הסדר כל גרסה שפוספסה, אחת אחת (כל אחת מאומתת ונבדקת). נעצר אחרי גרסה עם must_not_skip (או פורמט חדש) —
    כדי שהקוד החדש יטען ויבדוק את הבאה. אם גרסה נכשלה — הקודמות נשארות (כל אחת הייתה תקינה) והכישלון מוחזר."""
    repo = repo or REPO
    base, keys = source()
    done, restart, err = [], False, ""
    st = load_state()
    P = progress or (lambda d: None)
    n_total = [0]

    def stop():
        if cancel and cancel():
            raise UpdateCancelled("העדכון בוטל — לא שונה כלום.")
    for _ in range(max_steps):
        installed = installed_version(repo)
        try:
            stop()
            P({"stage": "checking", "label": "בודק מה חדש", "pct": 0, "cancellable": True})
            entries = fetch_index(base)
            keep, dropped = effective_skip(entries, st.get("skip", []))
            if dropped:                                  # 4.5.x (B1): גרסה חדשה בנויה על גרסה שדילגנו עליה → מציעים אותה שוב
                st["skip"] = keep
                st["skip_note"] = skip_note(dropped, entries)
                save_state(st)
            e = next_entry(installed, entries, st.get("skip", []))
            if not e:
                break
            if not done:
                n_total[0] = len([x for x in entries if ver_tuple(x["version"]) > ver_tuple(installed) and x["version"] not in st.get("skip", [])])
            idx = len(done) + 1
            base_info = {"step": idx, "steps": max(n_total[0], idx), "version": e["version"]}
            m, _raw = fetch_release(base, e, keys)
            check_chain(m, installed)
            log("מוריד את גרסה %s ..." % m["version"])

            def dl(got, total, info=base_info):
                stop()
                P(dict(info, stage="downloading", label="מוריד", done=got, total=total or m["archive"]["size"],
                       pct=int(100 * got / (total or m["archive"]["size"] or 1)), cancellable=True))
            tree = download_release(base, e, m, stage_root or STATE_DIR / "stage", progress=dl)
            stop()
            P(dict(base_info, stage="verifying", label="מאמת חתימה וקבצים", pct=100, cancellable=True))
            log("מתקין את גרסה %s ..." % m["version"])
            stop()                                       # הנקודה הבטוחה האחרונה — מכאן ההחלפה אטומית ואין ביטול
            r = apply_release(tree, m, repo, sd, check_fn, log,
                              prog=lambda pct, label, info=base_info: P(dict(info, stage="applying", label=label, pct=pct, cancellable=False)))
            done.append(r)
            shutil.rmtree(Path(stage_root or STATE_DIR / "stage") / m["version"], ignore_errors=True)
            if m.get("must_not_skip"):
                restart = True
                break
        except UpdateCancelled as ex:
            err = str(ex)
            break
        except UpdateError as ex:
            err = str(ex)
            break
    personal = None
    if done and on_installed:
        try:                          # 4.5.62: סימן ה-trial ו"מה השתנה" נכתבים *לפני* ההחלה מחדש של השינויים האישיים (כיבוי באמצעה לא מאבד אותם)
            on_installed(done)
        except Exception:
            pass
    PC = _pc(repo) if done else None
    if PC:
        # 4.5: פעם אחת אחרי הגרסה האחרונה — השינויים האישיים הפעילים מוחלים מחדש (מיזוג תלת-כיווני) ואז בדיקה מהירה.
        # כשל כאן לעולם לא מבטל ולא חוסם את העדכון הרשמי שכבר הותקן: השינוי נשמר ומוצג למשתמש.
        try:
            PC.migrate_legacy(repo)
            if [c for c in PC.load()["changes"] if PC._enabled(c)]:
                P({"stage": "personal", "label": "מחיל מחדש את השינויים האישיים שלך (2 מתוך 3)", "pct": 0, "cancellable": False})
            personal = PC.reapply(repo, personal_check, log=log, kind="update",
                                  prog=lambda pct, label: P({"stage": "personal", "label": "מחיל מחדש את השינויים האישיים שלך (2 מתוך 3) — " + label,
                                                             "pct": pct, "cancellable": False}))
        except Exception as ex:
            personal = {"results": [], "error": "לא הצלחנו להחיל את השינויים האישיים כרגע (%s) — הם שמורים." % type(ex).__name__}
    st = load_state()
    st["last_apply"] = {"at": int(time.time()), "versions": [d["version"] for d in done], "error": err}
    st.pop("available", None)
    if done and not err:
        st["continue_check"] = restart
    save_state(st)
    return {"applied": done, "error": err, "needs_restart_to_continue": restart, "personal": personal,
            "local_patch": next((d["local_patch"] for d in done if d.get("local_patch")), "")}


# ─────────────────────────── שורת פקודה (דיבוג) ───────────────────────────
def _main(a):
    if not a:
        sys.exit(__doc__)
    if a[0] == "check":
        try:
            print(json.dumps(check(skip=load_state().get("skip", [])), ensure_ascii=False))
        except UpdateError as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False))
    elif a[0] == "status":
        print(json.dumps({"mode": update_mode(), "version": installed_version(), "has_previous": has_previous(),
                          "tags": rel_tags(REPO), "source_set": bool(source()[0])}, ensure_ascii=False))
    elif a[0] == "recover":
        print(recover() or "אין עדכון שנקטע")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    _main(sys.argv[1:])
