# -*- coding: utf-8 -*-
"""כתוביות "קריוקי": כל כתובית מופיעה שלמה (שורה אחת או שתיים), והמילה שהרב
אומר כרגע מודגשת — הסימון זז ממילה למילה. בקשת המשתמש, 22/9/2026:
  teal    — המילה הנוכחית נצבעת בטורקיז (בחר בזה מבין teal/box)
  tealbox — ריבוע טורקיז מאחורי המילה הנוכחית, הטקסט נשאר לבן
            (כמו הדוגמה lRSNWR8sAc4 ששלח, שם הריבוע סגול)
  box     — צהוב על מלבן שחור (הניסיון הראשון, נדחה)

🚨 למה לא פשוט תגית צבע על מילה: libass מחשב כיווניות (bidi) בנפרד לכל
קטע-עיצוב, ותגית צבע באמצע שורה עברית מסדרת את הקטעים הפוך (נבדק בעבר:
"מילימטר RPGחטפתי את ה-"). לכן כל אירוע טקסט כאן הוא **הכתובית המלאה בקטע
עיצוב אחד**; ההדגשה היא שכבה נוספת — אותה כתובית בצבע אחר חתוכה ב-\\clip
למלבן של המילה, או ריבוע מצויר מאחוריה. את מלבן כל מילה לוקחים מ-libass
עצמו: מרנדרים את הכתובית פעם אחת על רקע שחור, מחלקים לשורות לפי שורות
פיקסלים ריקות, וכל שורה למילים לפי רווחים. כך אין הערכה של רוחב פונט.

🚨 גרסה קודמת חשפה את המילים אחת-אחת; המשתמש דחה: *"שכל השורה תופיע
מתחילה, ורק סימון הצבע יזוז"*.

שימוש:
  shorts.sh py karaoke_ass.py <words.json> <out.ass> --duration=<שניות> --style=teal|tealbox|box
      [--color=random|teal|yellow|purple|green]   (ברירת מחדל: random — צבע אחד לכל סרטון)
      [--emphasis=on|off]   הגדלת המילה שהרב התעכב עליה (ברירת מחדל: off — המשתמש ביטל ב-15/10/2026; לא להפעיל בלי בקשה שלו)
      [--mode=karaoke|plain|marker|float|box]  סגנון (ברירת מחדל karaoke = הטורקיז/צבעים). marker = תיבה מעוגלת [--rgb=RRGGBB
          מתוך karaoke_styles.MARKER_COLORS, --opacity=0..100]; float = ריחוף מילים, לדיבור איטי [--rgb=1AC8A8|FFE600 הדגשה]
      [--show-captions]     מדפיס כל כתובית ממוספרת, מילה-מילה, ואיזו מילה מוגדלת
      [--emphasis-fix=<json>]  תיקון ידני: {"5": 2, "9": null} — כתובית 5 → מילה 2; בכתובית 9 בלי
"""
import json
import os
import subprocess
import sys
import tempfile

import cv2
import numpy as np

import build_ass as B
from subtitle_terms import fix_words

FF = os.environ.get("FFMPEG", "ffmpeg")
FONTS = os.path.join(os.environ.get("SHORTS_LIB", ""), "fonts")
TEAL = "&H00A8C81A"      # RGB 1A C8 A8
SUB_DELAY = 0.10         # שניות — ראה build()
# 🚨 צבעי ההדגשה (בחירת המשתמש, 5/10/2026, מתוך דגימות על כתובית אמיתית): כל
# סרטון מקבל צבע אחד באקראי, ובתוך הסרטון הצבע קבוע. "random" נבחר לפי נתיב קובץ
# ה-ass — בנייה מחדש של אותו קליף (תיקון מילה) מקבלת שוב את אותו צבע.
HIGHLIGHT_RGB = {
    "teal":   "1AC8A8",   # המקורי
    "yellow": "FFE600",   # Y2 — צהוב חם
    "purple": "B14EFF",   # P2 — סגול עז
    "green":  "39FF14",   # G1 — ירוק ניאון
}


# 28/10/2026 — סגנונות הכתוביות (הוא מתכנן להוסיף עוד): לכל סגנון מה קורה למילה שנאמרת עכשיו, ומה קורה למילים
# שסימן ("🔠" — עד היום הגדלה). "karaoke" = כמו תמיד. "plain" = "ללא צבע": הכול לבן, בלי הדגשה רצה; המילים
# המסומנות הן היחידות בצבע (צבע אחד לכל הקליף), בגודל רגיל. סגנון חדש = עוד רשומה כאן (+ אסימון בהגדרות).
SUB_STYLES = {
    "karaoke": {"word_highlight": True, "marked": "enlarge"},
    "plain":   {"word_highlight": False, "marked": "color"},
    # 30/10/2026: שני סגנונות מ-karaoke_styles.py (קובץ משלהם — ציור תיבה / ריחוף, לא שכבות הקריוקי). marked: none =
    # מילים מסומנות לא משנות כלום; color = צבע ההדגשה שבחר (אם בחר). הצבע/השקיפות מגיעים כ-rgb/opacity ל-build()
    "marker":  {"word_highlight": False, "marked": "none", "module": True},
    "float":   {"word_highlight": False, "marked": "color", "module": True},
    "box":     {"word_highlight": False, "marked": "none", "module": True},     # 31/10 (כרטיס 24): "קופסה" — תיבה קבועה, המילה בצבע טקסט
}
STYLE_TAG = "; ys-style: %s"       # שורה בקובץ ה-ass — כך יודעים אחר כך באיזה סגנון הקליף נצרב


def ass_color(rgb):
    return "&H00%s%s%s" % (rgb[4:6], rgb[2:4], rgb[0:2])     # ASS = &HAABBGGRR


def pick_color(color, out_ass):
    if color in HIGHLIGHT_RGB:
        return color
    import hashlib
    key = os.path.abspath(out_ass).encode("utf-8")
    names = sorted(HIGHLIGHT_RGB)
    return names[int(hashlib.md5(key).hexdigest(), 16) % len(names)]

_BASE_TEAL = ("Style: Base,Heebo900,122,&H00FFFFFF,&H000000FF,&H00101010,&H64000000,"
              "0,0,0,0,100,100,0,0,1,8,3,2,60,60,320,1")
STYLES = {
    "teal": dict(base=_BASE_TEAL, mode="color",
                 hi=f"Style: Hi,Heebo900,122,{TEAL},&H000000FF,&H00101010,&H00000000,"
                    "0,0,0,0,100,100,0,0,1,8,0,2,60,60,320,1"),
    "tealbox": dict(base=_BASE_TEAL, mode="box",
                    hi=f"Style: Hi,Heebo900,122,{TEAL},&H000000FF,{TEAL},&H00000000,"
                       "0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1"),
    "box": dict(mode="color",
                base="Style: Base,Heebo900,122,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,"
                     "0,0,0,0,100,100,0,0,3,14,0,2,60,60,320,1",
                hi="Style: Hi,Heebo900,122,&H0000D4FF,&H000000FF,&H00000000,&H00000000,"
                   "0,0,0,0,100,100,0,0,1,0,0,2,60,60,320,1"),
}
MEASURE_STYLE = ("Style: Base,Heebo900,122,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,"
                 "0,0,0,0,100,100,0,0,1,0,0,2,60,60,320,1")
WORD_GAP_PX = 14   # רווח בין מילים ב-Heebo 900/122 ≈ 25-34px; בין אותיות < 10px
ROW_GAP_PX = 12    # שורות ריקות שמפרידות בין שתי שורות כתובית
CLIP_PAD = 10      # מלבן המילה נפתח מעט לצדדים — שלא ייחתך קצה של אות
BOX_PAD_X, BOX_PAD_Y = 14, 12

# --- הגדלת מילה (הרעיון מהסקיל המקורי 3.4.0; המשתמש בחר לקחת רק אותו, 12/10/2026) ---
# המילה שהרב התעכב עליה ביחס לשכנותיה מוצגת גדולה פי 1.3. הקריטריון הוא
# התעכבות בפועל, לא ניחוש משמעות מהטקסט. ונדיר בכוונה: מילה אחת לכתובית
# לכל היותר, לא בשתי כתוביות רצופות, ומילה שכבר הוגדלה לא מוגדלת שוב —
# בבדיקה שלו, בלי הכללים האלה כל כתובית שנייה הוגדלה וזה נראה כרעש.
# 🚨 כתובית עם מילה מוגדלת לא יכולה להיות אירוע אחד: תגית גודל באמצע שורה
# עברית מסדרת את המילים הפוך ב-libass. לכן בכתובית כזאת כל מילה מצוירת לבד,
# במיקום שנגזר מהמדידה של הכתובית הרגילה (measure_words) — אותן שורות, אותם
# רווחים, רק המילה הגדולה רחבה יותר והשורה ממורכזת מחדש.
EMPHASIS_SIZE = 159                # 122 × 1.3
EMPHASIS_MIN_DURATION_RATIO = 1.25
EMPHASIS_MIN_LETTERS = 3
MIN_GAP = 2                        # כתוביות רגילות לפחות בין שתי הגדלות
LINE_MAX_PX = 960                  # 1080 פחות שולי הסגנון; שורה רחבה מזה — בלי הגדלה
BOTTOM_Y = B.PLAY_RES_Y - 320      # תחתית בלוק הכתובית (MarginV של הסגנון)
FUNCTION_WORDS = {
    "של", "את", "אל", "על", "עם", "כי", "אם", "או", "גם", "רק", "כל", "לא",
    "זה", "זו", "הוא", "היא", "הם", "הן", "אני", "אתה", "אנחנו", "אתם",
    "מה", "מי", "איך", "כך", "כן", "אבל", "אז", "יש", "אין", "היה", "היו",
    "ולא", "וזה", "שזה", "שהוא", "שלא", "בו", "בה", "בין", "עד", "לפי",
    "אחרי", "לפני", "כמו", "יותר", "פחות", "הזה", "הזאת", "ואז", "ואם",
    "כאילו", "שבו", "שבה", "שאתה", "שאני", "שהם", "אותו", "אותה", "אותי", "אותם",
    "לו", "לה", "לי", "לנו", "להם", "אצל", "פה", "שם", "ככה", "בעצם", "פשוט",
}
_PREFIXES = ("וה", "וב", "ול", "וש", "שה", "וכש", "ה", "ב", "ל", "מ", "כ", "ו", "ש")


def _bare(word):
    return word.strip().strip(" ,.!?;:׳״\"'()־-")


def _stem(word):
    """"בסוכה" ו"הסוכה" — אותה מילה לצורך "לא להגדיל פעמיים"."""
    w = _bare(word)
    for p in _PREFIXES:
        if w.startswith(p) and len(w) - len(p) >= 3:
            return w[len(p):]
    return w


def pick_emphasis(chunk):
    """אינדקס המילה שהרב התעכב עליה הכי הרבה בכתובית, או None."""
    durs = [w["end"] - w["start"] for w in chunk]
    avg = sum(durs) / len(durs) if durs else 0
    if avg <= 0:
        return None
    best = None
    for i, w in enumerate(chunk):
        bare = _bare(w["word"])
        if len(bare) < EMPHASIS_MIN_LETTERS or bare in FUNCTION_WORDS:
            continue
        ratio = durs[i] / avg
        if ratio >= EMPHASIS_MIN_DURATION_RATIO and (best is None or ratio > best[0]):
            best = (ratio, i)
    return best[1] if best else None


def plan_emphasis(items):
    """{אינדקס כתובית: אינדקס מילה} — ברמת הקליף כולו, עם כללי הנדירות.
    🚨 בכלל של המקור (רק "לא ברצף") הוגדלו 13 מ-31 כתוביות בקליף אמיתי
    (מקץ, 12/10/2026) — כמעט כל שנייה. לכן לפחות MIN_GAP כתוביות בין הגדלות."""
    plan, seen, last = {}, set(), -99
    for ci, (_s, _e, chunk) in enumerate(items):
        k = pick_emphasis(chunk)
        if k is None or ci - last <= MIN_GAP or _stem(chunk[k]["word"]) in seen:
            continue
        plan[ci] = k
        seen.add(_stem(chunk[k]["word"]))
        last = ci
    return plan


def calibrate(tmp):
    """שני מספרים שנמדדים ברינדור: הירידה (מקו הבסיס עד תחתית תיבת \\an2) לכל
    פיקסל של גודל פונט, ומרווח השורות בגודל הבסיס. כך המילה הגדולה יושבת על
    אותו קו בסיס כמו שכנותיה, ולא גבוה מהן."""
    ass, png = os.path.join(tmp, "c.ass"), os.path.join(tmp, "c.png")
    esc = lambda p: p.replace("\\", "/").replace(":", "\\:")

    def ink_rows(text):
        with open(ass, "w", encoding="utf-8-sig") as f:
            f.write(header([MEASURE_STYLE]))
            f.write(f"Dialogue: 0,0:00:00.00,0:00:01.00,Base,,0,0,0,,{text}\n")
        subprocess.run([FF, "-nostdin", "-y", "-v", "error", "-f", "lavfi",
                        "-i", f"color=black:s={B.PLAY_RES_X}x{B.PLAY_RES_Y}:d=1",
                        "-vf", f"ass={esc(ass)}:fontsdir={esc(FONTS)}", "-frames:v", "1", png], check=True)
        return _runs((cv2.imread(png, cv2.IMREAD_GRAYSCALE) > 100).any(axis=1), ROW_GAP_PX)

    flat = "‫שמם‬"          # בלי אותיות יורדות: התחתית שלה = קו הבסיס
    (_, y1), = ink_rows(f"{{\\an2\\pos(540,{BOTTOM_Y})}}{flat}")
    drop_per_px = (BOTTOM_Y - y1) / 122.0
    two = ink_rows(f"{flat}\\N{flat}")
    pitch = float(two[1][1] - two[0][1]) if len(two) == 2 else 122 * 1.2
    return drop_per_px, pitch


def emphasized_layout(boxes, row_counts, k, cal):
    """[(x, y, גודל)] ל-\\an2\\pos של כל מילה כשהמילה k מוגדלת; None אם שורה לא נכנסת.
    k = אינדקס אחד, או כמה (22/10/2026, כרטיס 15: עד שתי מילים בכתובית שהוא בחר)."""
    ks = {k} if isinstance(k, int) else set(k)
    drop_per_px, pitch = cal
    scale = EMPHASIS_SIZE / 122.0
    out, rows, i = [None] * len(boxes), [], 0
    for n in row_counts:
        rows.append(list(range(i, i + n)))
        i += n
    big_rows = {r for r, idx in enumerate(rows) if ks & set(idx)}
    for r, idx in enumerate(rows):
        w = [(boxes[j][1] - boxes[j][0]) * (scale if j in ks else 1) for j in idx]
        g = [boxes[a][0] - boxes[b][1] for a, b in zip(idx, idx[1:])]   # RTL: a מימין ל-b
        total = sum(w) + sum(g)
        if total > LINE_MAX_PX:
            return None
        # שורה עליונה מורמת במרווח שורות אחד, מוגדל אם יש מילה גדולה בשורה שמתחתיה
        lift = sum(pitch * (scale if rr in big_rows else 1) for rr in range(r + 1, len(rows)))
        base_y = BOTTOM_Y - drop_per_px * 122 - lift                     # קו הבסיס
        x = B.PLAY_RES_X / 2 + total / 2
        for m, j in enumerate(idx):
            size = EMPHASIS_SIZE if j in ks else 122
            out[j] = (x - w[m] / 2, base_y + drop_per_px * size, size)
            x -= w[m] + (g[m] if m < len(g) else 0)
    return out


EMPH_PER_SUB = 2       # כרטיס 15: לכל היותר שתי מילים מוגדלות בכתובית אחת


def plan_from_idx(items, idx):
    """הגדלה מפורשת (כרטיס 15, 22/10/2026 — המילים שהמודל הציע והוא אישר/ערך): idx = אינדקסים ברשימת
    המילים של words.json. מחזיר ({כתובית: [מיקום המילה בכתובית, ...]}, [כתוביות שהיו בהן יותר משתיים]).
    המילים בכתובית צריכות לשאת "i" (build מוסיף אותו כשיש הגדלה מפורשת)."""
    plan, over = {}, []
    for ci, (_s, _e, chunk) in enumerate(items):
        ws = [w for w in chunk if w["word"].strip()]
        ks = [k for k, w in enumerate(ws) if w.get("i") in idx]
        if len(ks) > EMPH_PER_SUB:
            over.append(ci)
            ks = ks[:EMPH_PER_SUB]
        if ks:
            plan[ci] = ks
    return plan, over


def make_items(words, duration, rows_layout=None, with_index=False):
    """החלוקה לכתוביות בדיוק כמו בצריבה (לצריבה ולתצוגה המקדימה בדף): (items, rows_by_first).
    with_index — כל מילה נושאת "i" = המיקום שלה ב-words (בשביל הגדלה מפורשת); לא משנה שום זמן."""
    if rows_layout:
        return layout_items(words, duration, rows_layout)
    if with_index:
        words = [dict(w, i=k) for k, w in enumerate(words)]
    chunks, hard = B.chunk_words(B.cap_word_durations(words), ())
    return B.polish_chunks(chunks, duration, hard), {}


def header(styles):
    return (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {B.PLAY_RES_X}\nPlayResY: {B.PLAY_RES_Y}\n"
            "WrapStyle: 2\nScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
            "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
            "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
            + "\n".join(styles) + "\n\n[Events]\n"
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")


def _runs(mask, gap):
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    out, start, prev = [], idx[0], idx[0]
    for i in idx[1:]:
        if i - prev > gap:
            out.append((int(start), int(prev)))
            start = i
        prev = i
    out.append((int(start), int(prev)))
    return out


def measure_words(text, row_counts, tmp):
    """מרנדר את הכתובית ומחזיר [(x0, x1, y0, y1)] לכל מילה בסדר הקריאה:
    שורה עליונה קודם, ובכל שורה מימין לשמאל. None אם החלוקה לא יוצאת מדויקת."""
    ass = os.path.join(tmp, "m.ass")
    png = os.path.join(tmp, "m.png")
    with open(ass, "w", encoding="utf-8-sig") as f:
        f.write(header([MEASURE_STYLE]))
        f.write(f"Dialogue: 0,0:00:00.00,0:00:01.00,Base,,0,0,0,,{text}\n")
    esc = lambda p: p.replace("\\", "/").replace(":", "\\:")
    subprocess.run([FF, "-nostdin", "-y", "-v", "error", "-f", "lavfi",
                    "-i", f"color=black:s={B.PLAY_RES_X}x{B.PLAY_RES_Y}:d=1",
                    "-vf", f"ass={esc(ass)}:fontsdir={esc(FONTS)}", "-frames:v", "1", png], check=True)
    img = cv2.imread(png, cv2.IMREAD_GRAYSCALE) > 100
    rows = _runs(img.any(axis=1), ROW_GAP_PX)
    if len(rows) != len(row_counts):
        return None
    boxes = []
    for (y0, y1), n in zip(rows, row_counts):
        cols = img[y0:y1 + 1].any(axis=0)
        # 🚨 סף הרווח נבחר לפי מה שמוציא בדיוק n מילים — עדיין מדידה, לא ניחוש.
        # 14px מתאים לרוב; מקף ("האי-נעימות") או פיסוק מרוחק יוצרים "רווח" מדומה,
        # ואז סף גבוה יותר מאחד אותם. שורה שלא נמדדה מוצגת בלי הדגשה — המשתמש
        # שאל (22/9) למה שורה תישאר לבנה; ככה זה קורה רק כשאין שום סף שמתאים.
        words = None
        for gap in (WORD_GAP_PX, 18, 11, 22, 26, 8, 30):
            cand = _runs(cols, gap)
            if len(cand) == n:
                words = cand
                break
        if words is None:
            return None
        boxes += [(x0, x1, y0, y1) for x0, x1 in reversed(words)]   # RTL
    return boxes


def layout_items(words, duration, layout):
    """פריסה שנקבעה ביד (make_short_layout, 21/10/2026): הכתוביות והשורות כמו שקבע, הזמנים מהמילים.
    כל כתובית = גבול "קשה" — polish_chunks לא ממזג אותן בחזרה (רק ההחזקה, הגישור וההלוואה פועלים).
    מחזיר (items, {אינדקס המילה הראשונה: השורות})."""
    ws = B.cap_word_durations([dict(w, i=k) for k, w in enumerate(words)])
    chunks = [[ws[i] for r in ch for i in r] for ch in layout]
    return B.polish_chunks(chunks, duration, [True] * len(chunks)), {ch[0][0]: ch for ch in layout}


def layout_rows(tokens, chunk, words, rows_by_first):
    """השורות שקבע לכתובית הזאת, אחרי תיקון המונחים (fix_words). לא מתאים אחד-לאחד — None (חלוקה רגילה)."""
    lay = rows_by_first.get((chunk[0] if chunk else {}).get("i"))
    if not lay:
        return None
    rt = [fix_words([words[i]["word"].strip() for i in r], color=False).split() for r in lay]
    return rt if all(rt) and [t for r in rt for t in r] == tokens else None


def build(words_json, out_ass, duration, style, color="random", emphasis=False, fix=None, show=False, rows_layout=None,
          emph_idx=None, mode="karaoke", rgb=None, opacity=None, text=None, shadow=None, box_rgb=None):
    """rows_layout = "📐 פריסת שורות" שקבע (make_short_layout). שם נפרד בכוונה: `layout` למטה הוא מיקום
    המילים של ההגדלה, ונדרס בכל כתובית (בבדיקה הראשונה הפריסה חלה רק על הכתובית הראשונה).
    emph_idx = הגדלה מפורשת (כרטיס 15): קבוצת אינדקסים ב-words — רק המילים האלה מוגדלות, עד שתיים בכתובית,
    בלי הבחירה האוטומטית. None = כמו תמיד (בלי הגדלה, אלא אם emphasis=True — הדרך הישנה)."""
    words = json.load(open(words_json, encoding="utf-8"))["words"]
    # הכתובית עלתה עם הנשימה שלפני המילה, מעט לפני שהמילה נשמעת (נמדד בגרסה
    # 3.4.0 של הסקיל המקורי). מזיזים את המילים עצמן, כך שגם ההדגשה זזה איתן.
    words = [dict(w, start=w["start"] + SUB_DELAY, end=w["end"] + SUB_DELAY) for w in words]
    if SUB_STYLES[mode].get("module"):
        # "מרקר" / "ריחוף מילים": שאר הקריוקי (סגנון, צבע אקראי, הגדלה) לא חל עליהם
        import karaoke_styles as KS
        out_text, n, unmeasured, colored = KS.build(sys.modules[__name__], words, duration, mode, rgb, opacity, rows_layout, emph_idx, text, shadow, box_rgb)
        with open(out_ass, "w", encoding="utf-8-sig") as f:
            f.write(out_text)
        print(f"{n} כתוביות · {unmeasured} בלי תיבה/מיקום (לא נמדדו) · סגנון {mode} · צבע {rgb or '—'}"
              + (f" · נצבעו {colored} מילים" if colored else ""))
        return
    items, rows_by_first = make_items(words, duration, rows_layout, with_index=emph_idx is not None)
    st = dict(STYLES[style])
    color = pick_color(color, out_ass)
    if style in ("teal", "tealbox"):
        st["hi"] = st["hi"].replace(TEAL, ass_color(HIGHLIGHT_RGB[color]))
    sm = SUB_STYLES[mode]
    lines = [header([st["base"], st["hi"]])]
    if mode != "karaoke":
        lines[0] = lines[0].replace("[Script Info]\n", "[Script Info]\n%s\n" % (STYLE_TAG % mode), 1)
    fallback = 0
    explicit = emph_idx is not None
    emphasis = (emphasis or explicit) and st["mode"] == "color"
    if explicit:
        plan, over = plan_from_idx(items, set(emph_idx)) if emphasis else ({}, [])
        for ci in over:
            print(f"  ⚠️ כתובית {ci + 1}: יותר משתי מילים להגדלה — הוגדלו שתי הראשונות")
    else:
        plan = plan_emphasis(items) if emphasis else {}
    # תיקון ידני: הבחירה האוטומטית לפי התעכבות לא תמיד קולעת למילה שנושאת את
    # המשמעות (המשתמש, 12/10/2026). {"מספר כתובית": מספר מילה, או null = בלי}
    # — שניהם מ-1, כמו בהדפסה של --show-captions.
    for c, w in (json.load(open(fix, encoding="utf-8")) if fix and emphasis and not explicit else {}).items():
        if w is None:
            plan.pop(int(c) - 1, None)
        else:
            plan[int(c) - 1] = int(w) - 1
    plan = {ci: ([k] if isinstance(k, int) else list(k)) for ci, k in plan.items()}
    enlarged = []
    with tempfile.TemporaryDirectory() as tmp:
        cal = calibrate(tmp) if plan and sm["marked"] == "enlarge" else None
        for ci, (start, end, chunk) in enumerate(items):
            tokens = fix_words([w["word"].strip() for w in chunk], color=False).split()
            n = len(tokens)
            if show:
                mark = f"  ← {','.join(str(k + 1) for k in plan[ci])}" if ci in plan else ""
                print(f"  {ci + 1:>2}. " + " ".join(f"{j + 1}:{t}" for j, t in enumerate(tokens)) + mark)
            rows = layout_rows(tokens, chunk, words, rows_by_first) if rows_layout else None
            rows = rows or B.split_rows(tokens)
            text = B.ass_text(tokens, rows)
            boxes = measure_words(text, [len(r) for r in rows], tmp)
            ws = [w for w in chunk if w["word"].strip()]
            layout = None
            # הגדלה רק כשהמילים אחרי תיקון המונחים מתאימות אחת-לאחת לחותמות הזמן
            if ci in plan and boxes is not None and len(ws) == n and max(plan[ci]) < n and sm["marked"] == "enlarge":
                layout = emphasized_layout(boxes, [len(r) for r in rows], plan[ci], cal)
                # שתי מילים גדולות לא נכנסות בשורה — לפחות הראשונה (עדיף מכלום)
                if layout is None and len(plan[ci]) > 1:
                    plan[ci] = plan[ci][:1]
                    layout = emphasized_layout(boxes, [len(r) for r in rows], plan[ci], cal)
            if layout:
                enlarged.append(f"{ci + 1}:{'+'.join(tokens[k] for k in plan[ci])}")
            elif ci in plan:
                print(f"  ⚠️ כתובית {ci + 1}: ההגדלה לא נכנסה (שורה רחבה מדי או מילים שלא תואמות)")

            def word_event(layer, style_name, j, a, b):
                x, y, size = layout[j]
                fs = f"\\fs{size}" if size != 122 else ""
                return (f"Dialogue: {layer},{B.fmt_time(a)},{B.fmt_time(b)},{style_name},,0,0,0,,"
                        f"{{\\an2\\pos({x:.1f},{y:.1f}){fs}}}‫{tokens[j]}‬\n")

            # שכבה 1: הכתובית המלאה, לכל אורכה. בסגנון ריבוע היא מעל הריבוע (שכבה 0).
            if layout:
                lines += [word_event(1, "Base", j, start, end) for j in range(n)]
            else:
                lines.append(f"Dialogue: 1,{B.fmt_time(start)},{B.fmt_time(end)},Base,,0,0,0,,{text}\n")
            if boxes is None:
                fallback += 1              # לא נמדד — בלי הדגשה, לא מנחשים מיקום
                print(f"  ⚠️ בלי הדגשה ({B.fmt_time(start)}): {' '.join(tokens)}")
                continue
            if not sm["word_highlight"]:
                # "ללא צבע": רק המילים המסומנות — בצבע, לכל אורך הכתובית (אותו \clip על המלבן שנמדד; בלי תגית
                # צבע בתוך השורה, שמהפכת עברית ב-libass)
                if sm["marked"] == "color" and ci in plan and len(ws) == n:
                    for k in plan[ci]:
                        if k < n:
                            x0, x1, y0, y1 = boxes[k]
                            clip = (f"{{\\clip({max(0, x0 - CLIP_PAD)},{max(0, y0 - 30)},"
                                    f"{min(B.PLAY_RES_X, x1 + CLIP_PAD)},{min(B.PLAY_RES_Y, y1 + 30)})}}")
                            lines.append(f"Dialogue: 2,{B.fmt_time(start)},{B.fmt_time(end)},Hi,,0,0,0,,{clip}{text}\n")
                            enlarged.append(f"{ci + 1}:{tokens[k]}")
                continue
            # זמן תחילת כל מילה, מוצמד לתוך חלון הכתובית (ה"הלוואה" יכולה להזיז אותו)
            t = [min(max(ws[min(k, len(ws) - 1)]["start"], start), end) for k in range(n)]
            t[0] = start
            for k in range(n):
                a = t[k]
                b = t[k + 1] if k + 1 < n else end
                if b - a < 0.02:
                    continue
                x0, x1, y0, y1 = boxes[k]
                ta, tb = B.fmt_time(a), B.fmt_time(b)
                if layout:
                    lines.append(word_event(2, "Hi", k, a, b))
                elif st["mode"] == "color":
                    clip = (f"{{\\clip({max(0, x0 - CLIP_PAD)},{max(0, y0 - 30)},"
                            f"{min(B.PLAY_RES_X, x1 + CLIP_PAD)},{min(B.PLAY_RES_Y, y1 + 30)})}}")
                    lines.append(f"Dialogue: 2,{ta},{tb},Hi,,0,0,0,,{clip}{text}\n")
                else:
                    bx0, bx1 = x0 - BOX_PAD_X, x1 + BOX_PAD_X
                    by0, by1 = y0 - BOX_PAD_Y, y1 + BOX_PAD_Y
                    draw = (f"{{\\an7\\pos(0,0)\\p1\\bord0\\shad0}}"
                            f"m {bx0} {by0} l {bx1} {by0} l {bx1} {by1} l {bx0} {by1}{{\\p0}}")
                    lines.append(f"Dialogue: 0,{ta},{tb},Hi,,0,0,0,,{draw}\n")
    with open(out_ass, "w", encoding="utf-8-sig") as f:
        f.writelines(lines)
    print(f"{len(items)} כתוביות · {fallback} בלי הדגשה (לא נמדדו) · סגנון {style}/{mode} · צבע {color}")
    if emphasis:
        print(f"{'הוגדלו' if sm['marked'] == 'enlarge' else 'נצבעו'} {len(enlarged)}: {' · '.join(enlarged) or '—'}")


if __name__ == "__main__":
    argv = [a for a in sys.argv[1:] if not a.startswith("--")]
    opts = dict(a[2:].split("=", 1) for a in sys.argv[1:] if a.startswith("--") and "=" in a)
    build(argv[0], argv[1], float(opts["duration"]) if "duration" in opts else None,
          opts.get("style", "teal"), opts.get("color", "random"),
          opts.get("emphasis", "off") == "on", opts.get("emphasis-fix"), "--show-captions" in sys.argv,
          mode=opts.get("mode", "karaoke"), rgb=opts.get("rgb", "").lstrip("#") or None, text=opts.get("text"),
          opacity=int(opts["opacity"]) if "opacity" in opts else None,
          shadow=(opts["shadow"] != "off", int(opts.get("shadow-opacity", 50)), int(opts.get("shadow-size", 3))) if "shadow" in opts else None,
          box_rgb=opts.get("box-rgb", "").lstrip("#") or None)
