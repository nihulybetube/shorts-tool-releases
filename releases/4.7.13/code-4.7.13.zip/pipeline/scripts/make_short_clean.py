# -*- coding: utf-8 -*-
"""
make_short_clean.py — "🧹 נקה": שורט שהועלה (או שיעור שלם) יוצא מהמחשב יחד עם כל קבצי העבודה שלו.

למה (22/10/2026, כרטיס 17): עד היום, אחרי שהעלה שורטס, הוא ביקש מ-Claude למחוק אותם עם כל קבצי העבודה —
הוא לא רוצה שאריות נסתרות שהוא לא יודע למצוא. עכשיו זה בחלון, בלחיצה, ובדיוק באותה דרך זהירה:
  • הכול עובר לסל המיחזור של ווינדוס (win_recycle: העתקה לתיקייה זמנית, אימות מספר קבצים וגדלים,
    DeleteDirectory → SendToRecycleBin, בדיקה שהפריט בסל — ורק אז הסרת המקור ב-WSL). אפשר לשחזר משם.
  • שום נתיב מחוץ ל-projects/תוכנה/ ולתיקיית השורטס; לא השורש עצמו; לא שיעור אחר; אף פעם rm בשורת פקודה.
  • שורט אחד: התיקייה שלו בתיקיית השורטס + רק הקבצים של הקליף הזה בתיקיית העבודה (חיתוכים, נקי/בלי
    מוזיקה/צרוב, תמלולים, תצוגות מקדימות). קבצים משותפים לשיעור (הסרטון המלא, תמלול השיעור, ההצעות)
    נשארים — עד שהשורט האחרון של השיעור מנוקה, ואז כל תיקיית השיעור הולכת.
  • אחרי מחיקה בתיקיית השורטס: סימון לגיבוי ברקע עם מספר הקבצים המדויק שיימחקו בדרייב (מגיעים לפח של
    הדרייב), שורה ביומן exports.jsonl, ותיקיות סדרה/רב שהתרוקנו יורדות.
שיעורים ש-Claude עשה (מחוץ ל-projects/תוכנה/) — לא כאן: מנקים אותם כמו היום, בבקשה מ-Claude.

שימוש (החלון מריץ את זה כעבודה):  python make_short_clean.py run <items.json>
  items.json = [{"project": "<תיקיית שיעור>", "clip": "clip2"}, {"project": "<…>"}]   (בלי clip = כל השיעור)
"""
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import shorts_layout as SL  # noqa: E402

TOOL = MS.TOOL_DIR
PROJECTS = TOOL.parent
EDIT_DIR = MS.EDIT_DIR
# סל המיחזור של ווינדוס מוגבל בגודל (אצלו ~14GB) — מה שגדול ממנו נמחק לצמיתות בלי שאלה. ניקוי אחד לא עובר את זה.
MAX_BYTES = int(float(os.environ.get("MAKE_SHORT_CLEAN_MAX_GB", "12")) * 1e9)
SPECS = PROJECTS.parent / "app_specs"
STAGE_PREFIX = "_ys_clean_"


def _rx(name):
    """קובץ/תיקייה ששייכים לקליף: clip2, clip2.wav, clip2_clean.mp4, clip2_<כותרת>, dropped_clip2_…, old_… — לא clip21."""
    return re.compile(r"(^|_)%s(?=$|[_.\s])" % re.escape(name))


def _inside(p, root, min_depth=1):
    try:
        rp, rr = Path(p).resolve(), Path(root).resolve()
    except OSError:
        return False
    return rr in rp.parents and len(rp.relative_to(rr).parts) >= min_depth


def size_of(p):
    """(בייטים, קבצים) — תיקייה או קובץ. קישורים סמליים לא נספרים ולא נעקבים."""
    p = Path(p)
    if p.is_symlink():
        return 0, 0
    if p.is_file():
        return p.stat().st_size, 1
    n = b = 0
    for dp, dns, fns in os.walk(p):
        for f in fns:
            fp = os.path.join(dp, f)
            if not os.path.islink(fp):
                try:
                    b += os.path.getsize(fp)
                    n += 1
                except OSError:
                    pass
    return b, n


def load_state(P):
    P = Path(P).resolve()
    if P.parent != TOOL.resolve():
        raise ValueError("רק שיעורים שהתוכנה עשתה (projects/תוכנה/) — שיעורים של Claude מנקים דרך Claude")
    f = P / MS.STATE
    if not f.exists():
        return P, None
    return P, json.load(open(f, encoding="utf-8"))


def save_state(P, st):
    f = Path(P) / MS.STATE
    tmp = f.with_suffix(".json.tmp")
    json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    tmp.replace(f)


def clip_work_files(P, name):
    """רק הקבצים של הקליף הזה בתיקיית העבודה. לא: קובץ העריכה (הכותרת נשארת לרשימה), source/, קבצים בשורש."""
    rx = _rx(name)
    out = []
    for dp, dns, fns in os.walk(P):
        rel = Path(dp).relative_to(P)
        if rel.parts and rel.parts[0] in (EDIT_DIR, "source") or (rel.parts and rel.parts[0].startswith(STAGE_PREFIX)):
            dns[:] = []
            continue
        for f in fns:
            r = rel / f
            if len(r.parts) > 1 and any(rx.search(x) for x in r.parts) and not os.path.islink(os.path.join(dp, f)):
                out.append(r)
    return sorted(out)


def clip_exports(P, st, name, root):
    """התיקיות של השורט בתיקיית השורטס: מבנה חדש (כרטיס 16) — export_dirs[name]; מבנה ישן — <שיעור>/shorts/clipN*."""
    if not root:
        return []
    mine = (st.get("export_dirs") or {}).get(name)
    if mine:
        return [Path(mine)] if Path(mine).is_dir() and _inside(mine, root, 3) else []
    t = Path(st.get("export_target") or "")
    if str(t) in ("", ".") or not (t / "shorts").is_dir() or not _inside(t, root, 3):
        return []
    return [d for d in sorted((t / "shorts").glob(name + "*"))
            if d.is_dir() and re.match(re.escape(name) + r"(_|$)", d.name)]


def lesson_exports(P, st, root):
    """כל מה שהשיעור שם בתיקיית השורטס. מבנה ישן: תיקיית השיעור עצמה — רק אם יש בה shorts/ ורק קליפים שלנו."""
    if not root or not st:
        return []
    out = []
    for n, d in (st.get("export_dirs") or {}).items():
        if Path(d).is_dir() and _inside(d, root, 3):
            out.append(Path(d))
    t = Path(st.get("export_target") or "")
    if not st.get("export_dirs") and str(t) not in ("", ".") and (t / "shorts").is_dir() and _inside(t, root, 3):
        kids = [d for d in t.iterdir()]
        if all(d.name in ("shorts",) for d in kids) and all(re.match(r"clip\d+(_|$)", d.name) for d in (t / "shorts").iterdir()):
            out.append(t)                        # תיקיית שיעור במבנה הישן — רק השורטס שלו בתוכה
        else:
            for c in st.get("clips", []):
                out += clip_exports(P, st, c["name"], root)
    return sorted(set(out))


def clip_title(P, c):
    """4.3.1: השם של השורט עצמו — מהשדה בקובץ המצב, ואם עוד ריק (בדרך כלל כי הוא נכתב רק בקובץ העריכה) — מכותרת קובץ העריכה."""
    t = (c.get("title") or "").strip()
    if t or not P or not c.get("edit"):
        return t
    try:
        import make_short as MS
        return (MS.read_edit_raw(Path(P) / c["edit"]).get("title") or "").strip()
    except Exception:
        return ""


def _clip_row(st, c, P=None):
    saved = c["name"] in ((st.get("saved") or {}).get("clips") or [])
    return {"name": c["name"], "title": clip_title(P, c), "uploaded": c.get("uploaded") or "",
            "saved": saved, "dropped": bool(c.get("dropped")) and not c.get("cleaned"), "cleaned": c.get("cleaned") or ""}


def _title_of(P, st):
    if st:
        return st.get("video_title") or P.name
    try:
        import make_short_pick as PICK
        return json.load(open(P / PICK.PICK, encoding="utf-8")).get("title") or P.name
    except (OSError, ValueError, ImportError):
        return P.name


def plan(items, root=None):
    """מה יקרה — בלי לגעת בכלום. שורט שהוא האחרון שנשאר בשיעור → כל השיעור."""
    root = root if root is not None else MS.export_root()
    by = {}
    for it in items:
        P = Path(it["project"]).resolve()
        e = by.setdefault(str(P), {"P": P, "clips": set(), "whole": False})
        if it.get("clip"):
            e["clips"].add(it["clip"])
        else:
            e["whole"] = True
    out, total, ex_files = [], 0, 0
    for k, e in by.items():
        P, st = load_state(e["P"])
        if not P.is_dir():
            raise ValueError("השיעור כבר לא קיים: %s" % P.name)
        clips = (st or {}).get("clips") or []
        names = {c["name"] for c in clips}
        bad = e["clips"] - names
        if bad:
            raise ValueError("אין קליף בשם %s" % ", ".join(sorted(bad)))
        if st is None:
            e["whole"] = True
        if not e["whole"]:
            rest = [c for c in clips if not c.get("dropped") and c["name"] not in e["clips"]]
            if not rest:
                e["whole"] = True                # השורט האחרון של השיעור — כל השיעור הולך
        row = {"project": str(P), "name": P.name, "title": _title_of(P, st), "whole": e["whole"],
               "playlist": "_playlist-" in P.name, "exports": [], "clips": []}
        if e["whole"]:
            exp = lesson_exports(P, st, root)
            wb, wn = size_of(P)
            row["clips"] = [_clip_row(st, c, P) for c in clips if not c.get("cleaned")]
        else:
            exp, wb, wn = [], 0, 0
            for n in sorted(e["clips"]):
                exp += clip_exports(P, st, n, root)
                for f in clip_work_files(P, n):
                    b, _ = size_of(P / f)
                    wb, wn = wb + b, wn + 1
            row["clips"] = [_clip_row(st, c, P) for c in clips if c["name"] in e["clips"]]
        for d in exp:
            b, n = size_of(d)
            row["exports"].append({"path": str(d), "win": MS.win_path(d), "bytes": b, "files": n})
            ex_files += n
        row["export_bytes"] = sum(x["bytes"] for x in row["exports"])
        row["work_bytes"], row["work_files"] = wb, wn
        total += row["export_bytes"] + wb
        out.append(row)
    shorts = [c for r in out for c in r["clips"] if not c["dropped"]]
    return {"lessons": out, "total_bytes": total, "export_files": ex_files, "n_shorts": len(shorts),
            "n_dropped": sum(1 for r in out for c in r["clips"] if c["dropped"]),
            "not_uploaded": ["%s — %s" % (r["title"], c["title"] or c["name"]) for r in out for c in r["clips"]
                             if not c["dropped"] and not c["uploaded"]],
            # 31/10 (כרטיס 23): "✓ סמן שהועלו ונקה" — מה שאפשר לסמן מתוך החלון (רק שורטס שנשמרו לתיקייה)
            "mark_items": [{"project": r["project"], "clip": c["name"]} for r in out for c in r["clips"]
                           if not c["dropped"] and not c["uploaded"] and c["saved"]],
            "too_big": total > MAX_BYTES, "max_gb": round(MAX_BYTES / 1e9)}


# ─────────────── הביצוע ───────────────

def _say(m):
    print(m, flush=True)


def _step(key, state, detail=""):
    print("STEP=%s\t%s\t%s" % (key, state, detail.replace("\n", " ")), flush=True)


def recycle(src, root, label):
    """לסל המיחזור — הדרך המוגנת בלבד. MAKE_SHORT_FAKE_BIN (בדיקות יחידה בלבד): "סל" = תיקייה מקומית, אותן בדיקות."""
    src, root = Path(src).resolve(), Path(root).resolve()
    if root not in src.parents or len(src.relative_to(root).parts) < 2:
        raise RuntimeError("נתיב מחוץ לתחום — לא נוגע בו: %s" % src)
    fake = os.environ.get("MAKE_SHORT_FAKE_BIN")
    if fake:
        want = {str(f.relative_to(src)): f.stat().st_size for f in src.rglob("*") if f.is_file()}
        dst = Path(fake) / ("%s_%d" % (label, time.time_ns()))
        shutil.copytree(src, dst / src.name)
        got = {str(f.relative_to(dst / src.name)): f.stat().st_size for f in (dst / src.name).rglob("*") if f.is_file()}
        if got != want:
            raise RuntimeError("ההעתקה לא אומתה")
        shutil.rmtree(src)
        return dst.name
    import win_recycle as WR
    return WR.recycle(src, root, label)


def _label(P, extra=""):
    pid = P.name.split("_")[-1].split("-")[-1]
    return re.sub(r"[^A-Za-z0-9_-]", "", ("clean_%s%s" % (pid, ("_" + extra) if extra else "")))[:30] or "clean"


def _stage_clip(P, name):
    """הקבצים של קליף אחד → תיקייה אחת בתוך השיעור (העברה בתוך אותו דיסק, לא מחיקה) — כך עוברים לסל כפריט אחד."""
    files = clip_work_files(P, name)
    if not files:
        return None, []
    stage = P / ("%s%s_%s" % (STAGE_PREFIX, name, time.strftime("%Y%m%d_%H%M%S")))
    moved = []
    try:
        for r in files:
            dst = stage / r
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(P / r), str(dst))
            moved.append(r)
    except Exception:
        _unstage(P, stage, moved)
        raise
    return stage, moved


def _unstage(P, stage, moved):
    for r in moved:
        if (stage / r).exists():
            (P / r).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(stage / r), str(P / r))
    if stage.exists():
        _empty_dirs_below(stage)
        try:
            stage.rmdir()                          # רק אם התרוקנה — קובץ שלא חזר נשאר שם, לא נמחק
        except OSError:
            pass


def _empty_dirs_below(P):
    """תיקיות ריקות שנשארו בתוך תיקיית העבודה אחרי הוצאת קבצי קליף (rmdir בלבד)."""
    for dp, dns, fns in os.walk(P, topdown=False):
        if Path(dp) != Path(P) and not os.listdir(dp):
            try:
                os.rmdir(dp)
            except OSError:
                pass


def _ledger(row):
    try:
        from export_clips import LEDGER
        LEDGER.parent.mkdir(parents=True, exist_ok=True)
        with LEDGER.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception as e:
        _say("(לא נרשם ביומן: %s)" % e)


def _specs_of(P):
    """קבצי ההכנה (app_specs) שמצביעים רק על השיעור הזה — הולכים איתו לסל."""
    out = []
    for sp in sorted(SPECS.glob("spec_*.json")) if SPECS.exists() else []:
        try:
            if Path(json.load(open(sp, encoding="utf-8")).get("project") or "").resolve() == P:
                out.append(sp)
        except (OSError, ValueError):
            pass
    return out


def run(items):
    pl = plan(items)
    if pl["too_big"]:
        raise ValueError("זה יותר מ-%dGB בבת אחת — סל המיחזור לא מחזיק כל כך הרבה (מה שגדול ממנו נמחק לצמיתות). "
                         "לנקות בכמה פעמים." % pl["max_gb"])
    root = MS.export_root()
    steps = []
    for r in pl["lessons"]:
        steps.append(["L%d" % len(steps), "%s%s" % ("🧹 " if r["whole"] else "", r["title"][:60]),
                      max(5, int((r["export_bytes"] + r["work_bytes"]) / 40e6))])
    print("PLAN=" + json.dumps(steps, ensure_ascii=False), flush=True)
    removed_exp = 0
    done_rows = []
    for (key, _, _), r in zip(steps, pl["lessons"]):
        _step(key, "run")
        P, st = load_state(r["project"])
        bins, gone = [], []
        try:
            for x in r["exports"]:
                d = Path(x["path"])
                if not d.is_dir():
                    continue
                if not root or not _inside(d, root, 3):
                    raise RuntimeError("תיקייה מחוץ לתיקיית השורטס — לא נוגע: %s" % d)
                _say("🗑️ %s → סל המיחזור" % x["win"])
                bins.append(recycle(d, root, _label(P, "s")))
                gone.append(x["win"])
                removed_exp += x["files"]
                SL.prune_empty(d.parent, root)       # סדרה/רב שהתרוקנו — לא נשארות תיקיות ריקות
            if r["whole"]:
                if not _inside(P, PROJECTS, 2) or P.parent != TOOL.resolve():
                    raise RuntimeError("שיעור מחוץ ל-projects/תוכנה — לא נוגע")
                specs = []
                for sp in _specs_of(P):            # קבצי ההכנה שלו — לתוך השיעור, ואיתו לסל
                    (P / "_app_specs").mkdir(exist_ok=True)
                    shutil.move(str(sp), str(P / "_app_specs" / sp.name))
                    specs.append(sp)
                _say("🗑️ תיקיית העבודה %s → סל המיחזור" % P.name)
                try:
                    bins.append(recycle(P, PROJECTS, _label(P, "w")))
                except Exception:
                    for sp in specs:               # לא הגיע לסל — קבצי ההכנה חוזרים למקומם
                        if (P / "_app_specs" / sp.name).exists():
                            shutil.move(str(P / "_app_specs" / sp.name), str(sp))
                    raise
            else:
                for c in r["clips"]:
                    stage, moved = _stage_clip(P, c["name"])
                    if stage:
                        try:
                            _say("🗑️ קבצי העבודה של %s (%d) → סל המיחזור" % (c["name"], len(moved)))
                            bins.append(recycle(stage, TOOL, _label(P, c["name"])))
                        except Exception:
                            _unstage(P, stage, moved)       # לא הגיע לסל — הכול חוזר למקום
                            raise
                    _empty_dirs_below(P)
                    st = json.load(open(P / MS.STATE, encoding="utf-8"))
                    cc = next(x for x in st["clips"] if x["name"] == c["name"])
                    cc.update(dropped=True, cleaned=time.strftime("%Y-%m-%d %H:%M"))
                    cc.setdefault("dropped_at", cc["cleaned"])
                    cc.pop("dropped_park", None)
                    (st.get("export_dirs") or {}).pop(c["name"], None)
                    if st.get("saved"):
                        (st["saved"].get("snap") or {}).pop(c["name"], None)
                        st["saved"]["clips"] = [n for n in st["saved"].get("clips", []) if n != c["name"]]
                    save_state(P, st)
        except Exception as e:
            _step(key, "fail", str(e)[:200])
            if removed_exp:
                MS.mark_drive_pending("ניקוי (חלקי)", allow_delete=removed_exp)
            raise
        _step(key, "done", " · ".join(bins))
        row = {"event": "clean", "at": time.strftime("%Y-%m-%d %H:%M:%S"), "project": r["name"], "title": r["title"],
               "whole": r["whole"], "clips": [c["name"] for c in r["clips"]], "removed_exports": gone,
               "bytes": r["export_bytes"] + r["work_bytes"], "bin": bins, "by": "make_short_app"}
        _ledger(row)
        done_rows.append(row)
    if removed_exp:
        MS.mark_drive_pending("ניקוי: %d שורטס" % pl["n_shorts"], allow_delete=removed_exp)
    gb = pl["total_bytes"] / 1e9
    _say("✅ נוקה: %d שורטס%s · %s פונו — הכול בסל המיחזור של ווינדוס (אפשר לשחזר משם)"
         % (pl["n_shorts"], (" ו-%d שוויתרת עליהם" % pl["n_dropped"]) if pl["n_dropped"] else "",
            ("%.1f GB" % gb) if gb >= 1 else ("%d MB" % round(pl["total_bytes"] / 1e6))))
    print("CLEANED=" + json.dumps([x["project"] for x in done_rows if x["whole"]], ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    try:
        if len(sys.argv) == 3 and sys.argv[1] == "run":
            sys.exit(run(json.load(open(sys.argv[2], encoding="utf-8"))))
        if len(sys.argv) == 3 and sys.argv[1] == "plan":
            print(json.dumps(plan(json.load(open(sys.argv[2], encoding="utf-8"))), ensure_ascii=False, indent=1))
            sys.exit(0)
        print(__doc__)
        sys.exit(2)
    except Exception as e:
        print("❌ %s" % e, flush=True)
        sys.exit(1)
