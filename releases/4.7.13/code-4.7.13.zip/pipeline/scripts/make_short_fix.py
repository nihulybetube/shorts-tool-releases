# -*- coding: utf-8 -*-
"""
make_short_fix.py — "🛠️ תקן שורט זה בצ'אט" (כרטיס 27, 12/11/2026).

למה: קליף מוכן עם פגם קטן (חלק מהכתוביות בצבע אחר — באג D9; כתובית שזזה; נקישה בקול) לא חייב להיזרק.
הוא מעלה את הסרטון לצ'אט רגיל ב-claude.ai (התוכנה לא יכולה להעלות קבצים בשבילו), מדביק בלוק הקשר אחד שהתוכנה
בנתה, וכותב במילים שלו מה הפגם. הצ'אט עונה בתיקון אחד שאפשר להריץ — והתוכנה מריצה אותו בבידוד, מציגה לפני/אחרי,
ורק באישורו הגרסה החדשה נכנסת (הישנה נשמרת: "↩ חזור לגרסה הקודמת"). זה כמו כרטיס 19 (make_short_chat.py), אבל
לקליף אחד ולקובץ מדיה — לא לקוד של התוכנה.

שני סוגי תיקון בתשובה:
  1. «=== תיקון קליפ ===» + «=== החלפה: subtitles.ass ===» (חפש והחלף בקובץ הכתוביות) — התוכנה צורבת מחדש בדיוק כמו
     הצריבה הרגילה (אותו קובץ בסיס, אותם גופנים/סמלים, loudnorm, אותה מוזיקה). בטוח לגמרי: אין קוד.
  2. «=== סקריפט: fix.py ===» (פייתון) — לפגם שאי אפשר בכתוביות (קול, תמונה). רץ בתיקיית עבודה זמנית, על עותקים של
     הקבצים (בשמות באנגלית), בבידוד אמיתי של bubblewrap (4.1.0): מערכת לקריאה בלבד, בית ריק, כתיבה רק ל-OUT_DIR, בלי
     רשת, בלי תיקיית ההגדרות/מפתחות/הפרויקט, סביבה נקייה; בלי bwrap — לא מריצים. הסריקה הסטטית רק מסננת מוקדם
     (אינה הגבול); ורשימת הקבצים של הקליף נבדקת לפני ואחרי. הוא חייב לכתוב OUT_DIR/plain.mp4 (הסרטון בלי מוזיקה);
     התוכנה מנרמלת קול ומערבבת את אותה מוזיקה בעצמה.
בשני המקרים: בדיקה עצמית (ffprobe, גודל/קצב/משך, פריימים לא שחורים, עוצמה), לפני/אחרי, ורק "✓ אשר" מחליף. 🔒 שום סוד
בבלוק (CHAT.guard). הגרסאות הישנות ב-work/fix/versions/<clip>/.

שימוש (בדיקות):  make_short_fix.py block <project> <clip> "<מה הפגם>" [--at=12.5]
                 make_short_fix.py check <project> <clip> <answer.txt>
                 make_short_fix.py apply <project> <clip> <fixid>      (העבודה שהשרת מריץ)
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short_update as UPD  # noqa: E402

FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")
PY = sys.executable
BLOCK_CAP = 90000            # תווים — הודעה אחת לצ'אט
ASS_FULL_CAP = 45000
REVIEW_OVER_MB = 30          # מעל זה מציעים עותק קטן לסקירה
SCRIPT_TIMEOUT = 900


# ─────────────── קבצי הקליף ───────────────

def _read_st(P):
    return json.load(open(Path(P) / "make_short.json", encoding="utf-8"))


def _clip(st, name):
    for c in st["clips"]:
        if c["name"] == name:
            return c
    raise ValueError("אין קליף בשם %s" % name)


def _safe_name(name):
    return re.sub(r"[^\w]", "", str(name))


def final_of(P, name):
    """(תיקייה, קובץ) של הטיוטה הנוכחית — shorts/<clip>[_כותרת]/video.mp4."""
    ds = [d for d in sorted((Path(P) / "shorts").glob(name + "*")) if d.is_dir() and re.match(re.escape(name) + r"(_|$)", d.name)]
    for d in ds:
        v = sorted(d.glob("*.mp4"))
        if v:
            return d, v[0]
    raise ValueError("ל-%s עוד אין שורט מוכן — קודם \"צור את השורטס\"" % name)


def burn_source(P, c):
    """הסרטון שממנו נצרבות הכתוביות: עם הוק — work/hook/<clip>_clean.mp4, אחרת הבסיס הנקי."""
    P = Path(P)
    if c.get("hook_built"):
        h = P / ("work/hook/%s_clean.mp4" % c["name"])
        if h.exists():
            return h
    return P / c["clean"]


def sig(f):
    try:
        s = Path(f).stat()
        return "%d:%d" % (s.st_size, s.st_mtime_ns)
    except OSError:
        return ""


_WIN = {}


def win(path):
    p = str(path)
    if p not in _WIN:
        try:
            _WIN[p] = subprocess.run(["wslpath", "-w", p], capture_output=True, text=True, timeout=10).stdout.strip() or p
        except (OSError, subprocess.SubprocessError):
            _WIN[p] = p
    return _WIN[p]


def probe(f):
    """עובדות על קובץ וידאו: רזולוציה, קצב, משך, קול."""
    try:
        r = subprocess.run([FFPROBE, "-v", "error", "-show_entries",
                            "stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels,bit_rate:format=duration,size",
                            "-of", "json", str(f)], capture_output=True, text=True, timeout=60)
        d = json.loads(r.stdout or "{}")
    except (OSError, subprocess.SubprocessError, ValueError):
        return {}
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), {})
    fps = 0.0
    m = re.match(r"(\d+)/(\d+)", v.get("r_frame_rate", "") or "")
    if m and int(m.group(2)):
        fps = int(m.group(1)) / int(m.group(2))
    return {"w": v.get("width"), "h": v.get("height"), "fps": round(fps, 3), "vcodec": v.get("codec_name"),
            "acodec": a.get("codec_name"), "ar": a.get("sample_rate"), "ch": a.get("channels"),
            "dur": round(float((d.get("format") or {}).get("duration") or 0), 3),
            "size": int((d.get("format") or {}).get("size") or 0), "has_audio": bool(a)}


def loudness(f):
    """LUFS משולב, LRA ופסגה — ebur128 על כל הקובץ (שניות בודדות)."""
    try:
        r = subprocess.run([FFMPEG, "-hide_banner", "-nostats", "-nostdin", "-i", str(f), "-af", "ebur128=peak=true", "-f", "null", "-"],
                           capture_output=True, text=True, errors="replace", timeout=300)
    except (OSError, subprocess.SubprocessError):
        return {}
    tail = r.stderr[r.stderr.rfind("Summary:"):] if "Summary:" in r.stderr else ""
    i = re.search(r"I:\s+(-?[\d.]+) LUFS", tail)
    lra = re.search(r"LRA:\s+([\d.]+) LU", tail)
    pk = re.search(r"Peak:\s+(-?[\d.]+) dBFS", tail)
    return {"lufs": float(i.group(1)) if i else None, "lra": float(lra.group(1)) if lra else None,
            "peak": float(pk.group(1)) if pk else None}


def files_view(P, name):
    """הקבצים של הקליף שאפשר לתת לצ'אט: [{key,label,path (יחסי),abs,win,size,exists,default,note}]."""
    P = Path(P)
    st = _read_st(P)
    c = _clip(st, name)
    d, final = final_of(P, name)
    out = []

    def add(key, label, p, default=False, note=""):
        p = Path(p)
        ex = p.exists()
        out.append({"key": key, "label": label, "path": str(p.relative_to(P)) if P in p.parents else str(p), "abs": str(p),
                    "win": win(p) if ex else "", "size": p.stat().st_size if ex else 0, "exists": ex, "default": default, "note": note})

    add("final", "הסרטון הנוכחי של הקליף (עם כתוביות ומוזיקה) — זה שמעלים לצ'אט", final, True,
        "זו הטיוטה שרואים בכרטיס — בלי לשנות אותה")
    add("plain", "אותו סרטון בלי מוזיקה (הבסיס שממנו מערבבים מוזיקה)", P / ("work/plain/%s.mp4" % name), False,
        "שימושי לפגם בכתוביות או בתמונה — הקול נקי מהמוזיקה")
    src = burn_source(P, c)
    add("clean", "הסרטון הנקי בלי כתוביות%s" % (" (עם ההוק)" if c.get("hook_built") else ""), src, False,
        "המקור לצריבה מחדש — שימושי כשהפגם נראה בכתוביות")
    add("ass", "קובץ הכתוביות (ASS)", P / ("work/subtitles/%s.ass" % name), False, "טקסט — אפשר גם להדביק אותו בהודעה")
    rv = P / ("work/fix/review_%s.mp4" % name)
    if rv.exists():
        add("review", "עותק קטן לסקירה (איכות נמוכה — לא מחליף את המקורי)", rv, False, "רק לצפייה/העלאה מהירה")
    return out


# ─────────────── ASS ───────────────

TIME_RX = re.compile(r"^(\d+):(\d\d):(\d\d)[.:](\d\d)$")
COL_RX = re.compile(r"\\([1-4]?)c&H([0-9A-Fa-f]{2,8})&")


def _t(s):
    m = TIME_RX.match(s.strip())
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 100 if m else None


def ass_events(text):
    """[(מס' שורה 0-based, שכבה, התחלה, סוף, סגנון, שורה גולמית)] לכל Dialogue."""
    out = []
    for i, line in enumerate(text.split("\n")):
        if line.startswith("Dialogue:"):
            parts = line[9:].split(",", 9)
            if len(parts) >= 10:
                a, b = _t(parts[1]), _t(parts[2])
                if a is not None and b is not None:
                    try:
                        out.append((i, int(parts[0].strip() or 0), a, b, parts[3].strip(), line))
                    except ValueError:
                        pass
    return out


def _rgb(bgr):
    b = bgr.rjust(6, "0")[-6:]
    return (b[4:6] + b[2:4] + b[0:2]).upper()


def colour_summary(text):
    """אילו צבעים מופיעים ב-{\\c&H…&} ובסגנונות, כמה פעמים ומתי — כך רואים מיד כתובית "בצבע אחר" (באג D9)."""
    styles = re.findall(r"^Style:\s*([^,]+),(?:[^,]*,){2}(&H[0-9A-Fa-f]{6,8})", text, re.M)
    out = ["סגנונות (PrimaryColour, פורמט BGR של ASS): " + "; ".join("%s=%s" % (n.strip(), c) for n, c in styles[:12])]
    seen = {}
    for _, layer, a, b, sty, raw in ass_events(text):
        for tag, col in COL_RX.findall(raw):
            k = (tag or "1", _rgb(col))
            e = seen.setdefault(k, {"n": 0, "first": a, "last": b, "lines": []})
            e["n"] += 1
            e["last"] = max(e["last"], b)
            if len(e["lines"]) < 6:
                e["lines"].append("%.2f" % a)
    if seen:
        out.append("צבעים שנקבעים באמצע השורות (\\c / \\1c…), בפורמט RGB רגיל:")
        for (tag, rgb), e in sorted(seen.items(), key=lambda kv: -kv[1]["n"]):
            out.append("  \\%sc → #%s · %d פעמים · מ-%.2f עד %.2f (למשל בשניות %s)" % (tag, rgb, e["n"], e["first"], e["last"], ", ".join(e["lines"])))
    else:
        out.append("אין שינויי צבע באמצע שורות (הכול לפי הסגנון).")
    return "\n".join(out)


def ass_excerpt(text, at=None, span=3.0, cap=14000):
    """ראש הקובץ (סגנונות + הערות ys-) ושורות Dialogue סביב הזמן. בלי זמן — ראש + 12 הראשונות."""
    lines = text.split("\n")
    ev = ass_events(text)
    first = ev[0][0] if ev else len(lines)
    head = lines[:first]
    if at is not None:
        pick = [e for e in ev if e[3] >= at - span and e[2] <= at + span]
        note = "שורות Dialogue בחלון %.1f–%.1f שניות (הזמן הוא בסרטון הסופי)" % (max(0, at - span), at + span)
    else:
        pick = ev[:12]
        note = "12 שורות Dialogue ראשונות"
    body, used = [], 0
    for e in pick:
        if used + len(e[5]) > cap:
            body.append("… (נחתך)")
            break
        body.append(e[5])
        used += len(e[5])
    return "\n".join(head[:60] + ["", "; ── %s (מתוך %d שורות Dialogue בקובץ) ──" % (note, len(ev))] + body)


def words_excerpt(P, name, at, span=3.0):
    wj = Path(P) / ("work/hook/%s_words.json" % name)
    if not wj.exists():
        wj = Path(P) / ("work/subtitles/%s_words.json" % name)
    try:
        w = json.load(open(wj, encoding="utf-8"))["words"]
    except (OSError, ValueError, KeyError):
        return ""
    rows = [x for x in w if at is None or (x.get("end", 0) >= at - span and x.get("start", 0) <= at + span)]
    rows = rows[:120] if at is not None else rows[:60]
    return "קובץ: %s\n" % wj.name + " ".join("%s[%.2f-%.2f]" % (x.get("word") or x.get("text") or "?", x.get("start", 0), x.get("end", 0)) for x in rows)


# ─────────────── עובדות על הקליף ───────────────

def facts(P, name, at=None):
    P = Path(P)
    import make_short as MS
    import make_short_settings as SET
    st = _read_st(P)
    c = _clip(st, name)
    cfg = SET.load()
    d, final = final_of(P, name)
    plain = P / ("work/plain/%s.mp4" % name)
    L = ["שם הקליף: %s · רב: %s · סדרה: %s" % (name, st.get("rabbi", ""), st.get("series", ""))]
    try:
        t = (MS.read_edit_raw(P / c["edit"]).get("title") or "").strip()
        if t:
            L.append("כותרת: " + t)
    except Exception:
        pass
    pf, pp = probe(final), (probe(plain) if plain.exists() else {})
    L.append("אורך: %.2f שניות (מתוכנן %.1f) · קטעים מהשיעור (cuts): %s" % (pf.get("dur", 0), c.get("seconds", 0),
                                                                          ", ".join("%.2f–%.2f" % tuple(x) for x in c.get("cuts", [])[:12])))
    L.append("סרטון סופי: %sx%s · %s fps · וידאו %s · קול %s %s Hz %s ערוצים · %.1f MB" % (
        pf.get("w"), pf.get("h"), pf.get("fps"), pf.get("vcodec"), pf.get("acodec"), pf.get("ar"), pf.get("ch"), pf.get("size", 0) / 1e6))
    if pp:
        L.append("בסיס בלי מוזיקה (plain): %sx%s · %s fps · %.2f שניות" % (pp.get("w"), pp.get("h"), pp.get("fps"), pp.get("dur", 0)))
    ld, lp = loudness(final), (loudness(plain) if plain.exists() else {})
    L.append("עוצמה (EBU R128): סרטון סופי %s LUFS (LRA %s, פסגה %s dBFS); בלי מוזיקה %s LUFS — היעד הוא -14" % (
        ld.get("lufs"), ld.get("lra"), ld.get("peak"), lp.get("lufs")))
    L.append("סגנון כתוביות (לפי ה-ASS): %s · מה שנבחר לקליף: %s" % (MS.clip_rgb(name, base=str(P)) or "?", c.get("sub_rgb_user") or "ברירת המחדל הכללית"))
    fr = (c.get("framing") or {}).get("text", "")
    L.append("מצלמה: %s%s" % (c.get("camera") or "default", " · " + fr if fr else ""))
    if c.get("hook_built"):
        h = c.get("hook") or {}
        L.append("🎬 הוק: כן — «%s» (מקור: %s); הסרטון הסופי מתחיל בהוק ואחריו הבזק לבן ב-%.2f שניות (Tc), ואז השורט מההתחלה. "
                 "כל הזמנים בסרטון הסופי כוללים את ההוק; מקור הצריבה: work/hook/%s_clean.mp4" % (h.get("text", ""), h.get("src", "?"), c.get("hook_extra") or 0, name))
    else:
        L.append("הוק: לא")
    tr = c.get("track")
    L.append("מוזיקה: %s · עוצמה יחסית לקליף: %+d dB · רמות הערבוב (mix_music): %s" % (
        tr.get("title") if tr else "בלי", int(c.get("music_db") or 0), " ".join(map(str, SET.music_levels(clip_db=int(c.get("music_db") or 0))))))
    logos = SET.logos(cfg)
    emp = P / ("work/subtitles/%s_emph.json" % name)
    emp_on = emp.exists() and '"on": true' in emp.read_text(encoding="utf-8", errors="replace")
    L.append("סמלים: %s · 🔠 הגדלת מילים: %s · פריסת שורות ידנית: %s" % (
        ", ".join("%s(%s)" % (Path(p).name, pos) for p, pos, _ in logos) or "אין", "דולק" if emp_on else "כבוי",
        "כן" if (P / ("work/subtitles/%s_layout.json" % name)).exists() else "לא"))
    if c.get("chat_fixes"):
        L.append("תיקונים קודמים מצ'אט בקליף הזה: " + " | ".join("%s: %s" % (x.get("at", ""), x.get("desc", "")) for x in c["chat_fixes"][-5:]))
    ed = P / ("work/subtitles/%s_final.txt" % name)
    return "\n".join(L), (ed.read_text(encoding="utf-8", errors="replace") if ed.exists() else "")


PIPELINE = """\
סדר הצינור ואיך כל צעד רץ (make_short.finish / make_short.restyle; הפקודות כאן הן מה שהקוד עושה בפועל):
 1. חיתוך + מצלמה וירטואלית: multi_piece_clip.py → הסרטון הנקי (בלי כתוביות), 1080x1920.
 2. שתי תמלולים (אוזניים) → קובץ עריכה → יישור (align_clean_text) → work/subtitles/<clip>_words.json (מילה, התחלה, סוף).
 3. (אם יש הוק) hook_clip.py → work/hook/<clip>_clean.mp4 + work/hook/<clip>_words.json (הזמנים מוזזים ב-Tc).
 4. כתוביות: karaoke_ass.py / karaoke_styles.py → work/subtitles/<clip>.ass (סגנון טורקיז/מרקר/ריחוף/ללא צבע; שורות
    «; ys-style:» «; ys-rgb:» בראש הקובץ). הגופנים בתיקייה assets/fonts (Heebo900, YSMarkerBold, YSFloatHeebo).
 5. צריבה: build_clean_video.burn_subtitles(מקור, ass, work/burn/<clip>.mp4, fonts_dir, logos=[…]) =
    ffmpeg -i <מקור> [-i logo…] -filter_complex "[0:v]ass=<ass>:fontsdir=<fonts>[sub];…overlay סמלים…" -c:v libx264 -preset medium -crf 16
    -pix_fmt yuv420p -c:a aac -b:a 192k
 6. נרמול קול: make_short.loudnorm(burn → work/plain/<clip>.mp4) = loudnorm שני מעברים I=-14 TP=-1.5 LRA=11 linear=true, -c:v copy,
    -c:a aac -b:a 192k -ar 48000.   (work/plain/<clip>.mp4 = «הבסיס בלי מוזיקה»)
 7. מוזיקה: mix_music.py plain.mp4 <track.mp3> <out.mp4> <רמות הערבוב מלמעלה> → shorts/<clip>/video.mp4 (הטיוטה הסופית).
 8. תיאור ותגיות (meta.json, «תיאור להעתקה.txt») — לא קשור לתמונה/קול.
איך אפשר לתקן: (א) לשנות את קובץ ה-ASS ולהחזיר «=== החלפה: subtitles.ass ===» — התוכנה צורבת מחדש בצעדים 5–7 בדיוק כמו תמיד;
(ב) סקריפט פייתון שמקבל עותקים בשמות באנגלית ומחזיר OUT_DIR/plain.mp4 (הצעד 6 והמוזיקה — התוכנה עושה בעצמה)."""

RULES = """\
כללי ברזל (מההנחיות של בעל הפרויקט — הפרה = התיקון נדחה):
 • פורמט: 1080x1920, אותו קצב פריימים, yuv420p, H.264 + AAC. אורך הסרטון נשאר כמו שהוא (עד ±0.5 שנייה, אלא אם הפגם הוא באורך).
 • עוצמת קול -14 LUFS (לפני המוזיקה). לא להחליש/להגביר "בשביל הבטחון". המוזיקה נשארת אותה מוזיקה.
 • גופנים: רק דרך assets/fonts (fontsdir). לעולם לא לשנות/להגדיר SHORTS_LIB ולא להחליף את הגופן — צריבה עם גופן חלופי נראית אחרת מיד.
 • המילים המדוברות נשארות בדיוק כפי שנאמרו. לא לתקן/לשפר/להשמיט מילה בכתוביות בלי לומר במפורש מה שונה ולמה.
 • נאמנות: לשנות רק את הפגם שתואר. בלי "שיפורים" נוספים (צבעים, מיקום, גודל, חיתוך) שלא התבקשו.
 • הקבצים המקוריים של המשתמש לא נדרסים: התוכנה כותבת גרסה חדשה ליד הישנה, מראה לפני/אחרי, והוא מאשר.
 • בלי רשת, בלי מחיקות, בלי כתיבה מחוץ ל-OUT_DIR, בלי קריאה/כתיבה של config.env, עוגיות או מפתחות.
 • לא ברור אם הפגם הוא בקליפ או באג בתוכנה עצמה: אם נראה שהתוכנה גורמת לו שוב ושוב (לא רק בקליפ הזה) — ענה בשורה אחת:
   «זה באג בתוכנה: <הסבר קצר>» ואל תתקן את הקליפ."""

ANSWER = """\
=== איך עונים (חשוב — התוכנה מפרקת את התשובה אוטומטית) ===
1. הסרטון המצורף להודעה הוא הקליף הנוכחי. הסתכל עליו, מצא את הפגם שתואר (והשווה לעובדות/לקובץ ה-ASS שלמטה).
   לא ברור מה הפגם או איפה? שאל שאלה אחת קצרה בעברית — ואל תנחש.
2. אחרת — תשובה אחת, בתוך ההודעה עצמה (לא artifact, לא קובץ מצורף), בסדר הזה:
   א. שורה: «תיאור: <משפט אחד בעברית פשוטה — מה הפגם ומה מתקנים>»
   ב. פסקה קצרה בעברית פשוטה (המשתמש לא מתכנת): מה גילית ומה הוא אמור לראות אחרי התיקון.
   ג. תיקון אחד בלבד, באחד משני הפורמטים. עדיף (א) כשהפגם בכתוביות:

   (א) חפש-והחלף בקובץ הכתוביות:
=== תיקון קליפ ===
=== החלפה: subtitles.ass ===
<<<<<<< לפני
Dialogue: 0,0:00:12.30,0:00:13.10,Hi,,0,0,0,,{\\1c&H00FFD7&}דוגמה
=======
Dialogue: 0,0:00:12.30,0:00:13.10,Hi,,0,0,0,,{\\1c&H00A8C81A&}דוגמה
>>>>>>> אחרי
=== סוף החלפה ===
=== סוף תיקון ===
   הטקסט «לפני» — העתקה מדויקת מקובץ ה-ASS שלמטה (כולל כל תו), ומספיק קצר+ייחודי כדי שיופיע פעם אחת.
   כמה מופעים זהים? בשורה הראשונה בתוך «לפני» כתוב @all (החלפת כל המופעים, טקסט מילולי) או @regex (ביטוי רגולרי של
   פייתון, re.sub) — והתוכנה תציג כמה מופעים יוחלפו לפני שמריצים.

   (ב) סקריפט פייתון — רק כשאי אפשר בכתוביות (פגם בקול/בתמונה):
=== תיקון קליפ ===
=== סקריפט: fix.py ===
import os, subprocess
IN, OUT = os.environ["IN_DIR"], os.environ["OUT_DIR"]
# IN_DIR: final.mp4 plain.mp4 clean.mp4 subtitles.ass words.json info.json ; FONTS_DIR = תיקיית הגופנים
# חובה לכתוב OUT_DIR/plain.mp4 (הסרטון בלי מוזיקה: אותו אורך, 1080x1920, אותו קצב). אפשר גם OUT_DIR/subtitles.ass אם שונה.
subprocess.run([os.environ["FFMPEG"], "-y", "-i", IN + "/plain.mp4", "...", OUT + "/plain.mp4"], check=True)
=== סוף סקריפט ===
=== סוף תיקון ===
   הסקריפט רץ בלי רשת, בתיקייה זמנית, עם ffmpeg ו-python (numpy זמין). שמות קבצים רק מהסביבה (IN_DIR/OUT_DIR/FFMPEG/FFPROBE/FONTS_DIR) —
   בלי נתיבים מוחלטים, בלי «..», בלי מחיקות, בלי רשת. subprocess עם רשימת ארגומנטים (לא shell).
3. אחרי שהמשתמש מדביק את התשובה: התוכנה בודקת אותה, מריצה בבידוד, בודקת את התוצאה (פורמט, אורך, פריימים, עוצמה) ומראה לו לפני/אחרי.
   רק באישורו הגרסה החדשה נכנסת, והישנה נשמרת. נכשל? הוא ידביק לך את הסיבה — תקן ושלח את התיקון כולו מחדש."""


def parse_hms(s):
    """'12.5' / '0:12' / '1:02.5' → שניות, או None."""
    s = (s or "").strip().replace(",", ".")
    if not s:
        return None
    try:
        if ":" in s:
            t = 0.0
            for x in [float(x) for x in s.split(":")]:
                t = t * 60 + x
            return t
        return float(s)
    except ValueError:
        return None


def build_block(P, name, defect, at=None, inc=None):
    """הבלוק המלא לצ'אט. inc = {"facts","ass","ass_full","words","edit","pipeline"} (ברירת מחדל: הכול חוץ מ-ass_full).
    → {"text","chars","sections":[{name,chars}],"files":[...],"redacted":n,"over":bool}"""
    import make_short_chat as CHAT
    P = Path(P)
    inc = dict({"facts": True, "ass": True, "ass_full": False, "words": True, "edit": True, "pipeline": True}, **(inc or {}))
    name = _safe_name(name)
    secs = []

    def add(title, body):
        secs.append((title, body))

    st = _read_st(P)
    c = _clip(st, name)
    add("בקשה", "=== בקשה ל-Claude: תיקון חד-פעמי של קליף אחד בתוכנה «יצירת שורטס» (נבנה בתוכנה, %s) ===\n"
        "המשתמש לא מתכנת ועונים לו בעברית פשוטה. הוא מעלה לצ'אט את קובץ הסרטון של הקליף בנפרד (התוכנה לא יכולה לצרף קבצים) — "
        "הבלוק הזה מסביר את ההקשר שלו.\n\nהפגם שהוא ראה (במילים שלו):\n%s\n%s" % (
            time.strftime("%Y-%m-%d %H:%M"), (defect or "").strip() or "(לא כתב — שאל אותו מה לא בסדר)",
            ("הוא סימן מקום בסרטון: שנייה %.2f (%s) — בסרטון הסופי%s.\n" % (at, "%d:%05.2f" % (int(at // 60), at % 60),
                                                                           ", כולל ההוק" if c.get("hook_built") else "")) if at is not None else ""))
    add("כללים", RULES)
    add("פורמט תשובה", ANSWER)
    txt = ""
    if inc["facts"]:
        f, txt = facts(P, name, at)
        add("עובדות על הקליף", "=== עובדות על הקליף (נמדדו עכשיו) ===\n" + f)
    fv = files_view(P, name)
    add("קבצים", "=== קבצי הקליף במחשב (לידיעה; הצ'אט אינו רואה אותם — התוכנה נותנת לסקריפט עותקים) ===\n" + "\n".join(
        "  %s: %s · %.1f MB%s" % (x["key"], x["path"], x["size"] / 1e6, "" if x["exists"] else " (לא קיים)") for x in fv if x["key"] != "review"))
    if inc["pipeline"]:
        add("צינור", "=== הצינור ===\n" + PIPELINE)
    ap = P / ("work/subtitles/%s.ass" % name)
    if (inc["ass"] or inc["ass_full"]) and ap.exists():
        t = ap.read_text(encoding="utf-8-sig", errors="replace")
        add("צבעים", "=== סיכום צבעים בקובץ ה-ASS ===\n" + colour_summary(t))
        if inc["ass_full"] and len(t) <= ASS_FULL_CAP:
            add("ass", "=== subtitles.ass — כל הקובץ (%d תווים) ===\n%s\n=== סוף subtitles.ass ===" % (len(t), t))
        else:
            note = "" if not inc["ass_full"] else " (הקובץ גדול מ-%d תווים — נשלח קטע)" % ASS_FULL_CAP
            add("ass", "=== subtitles.ass — קטע%s ===\n%s\n=== סוף subtitles.ass ===" % (note, ass_excerpt(t, at)))
    if inc["words"]:
        w = words_excerpt(P, name, at)
        if w:
            add("מילים", "=== המילים והזמנים (הזמנים בסרטון הצריבה) ===\n" + w)
    if inc["edit"] and txt:
        add("טקסט", "=== הטקסט הסופי של הכתוביות (נבדק על ידי המשתמש) ===\n" + txt[:6000])
    add("סיום", "=== סוף הבקשה ===\nעכשיו: שאלה אחת קצרה (אם חסר מידע), או תיאור + פסקה בעברית + תיקון אחד בפורמט (=== תיקון קליפ ===). הכול בתוך ההודעה.")
    text = "\n\n".join(b for _, b in secs)
    text, red = CHAT.guard(text)
    return {"text": text, "chars": len(text), "redacted": red, "over": len(text) > BLOCK_CAP,
            "sections": [{"name": a, "chars": len(b)} for a, b in secs], "files": fv}


# ─────────────── פירוק התשובה ───────────────

SCRIPT_START = re.compile(r"^===\s*(?:סקריפט|SCRIPT)\s*:\s*(.+?)\s*===$")
SCRIPT_END = re.compile(r"^===\s*(?:סוף סקריפט|END SCRIPT)\s*===$")
TOOL_BUG = re.compile(r"זה\s+באג\s+בתוכנה\s*[:：]\s*(.+)")


def _edit_apply_one(cur, mode, old, new):
    """→ (תוכן חדש, כמה מופעים). mode: one (ייחודי, סלחני) / all (מילולי) / regex."""
    if mode == "all":
        n = cur.count(old)
        if not n:
            raise UPD.EditMiss("@all: הטקסט «לפני» לא נמצא בכתוביות: %s" % old[:70])
        return cur.replace(old, new), n
    if mode == "regex":
        try:
            rx = re.compile(old, re.M)
        except re.error as e:
            raise UPD.EditMiss("@regex: ביטוי לא תקין (%s)" % e)
        try:
            new2, n = rx.subn(new, cur)
        except (re.error, IndexError) as e:
            raise UPD.EditMiss("@regex: ההחלפה לא תקינה (%s)" % e)
        if not n:
            raise UPD.EditMiss("@regex: הביטוי לא התאים לאף שורה: %s" % old[:70])
        return new2, n
    return UPD.apply_edit(cur, old, new), 1


def parse(text):
    """→ {"kind": ass|script|tool_bug|question|none, "desc", "edits":[(mode,old,new)], "script", "errors":[], "bug"}"""
    t = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = t.split("\n")
    out = {"kind": "none", "desc": "", "edits": [], "script": "", "errors": [], "bug": ""}
    m = TOOL_BUG.search(t)
    if m and "=== תיקון" not in t:
        out.update(kind="tool_bug", bug=m.group(1).strip()[:400])
        return out
    rest, i = [], 0
    while i < len(lines):
        c = UPD._marker(lines[i])
        ms = SCRIPT_START.match(c)
        me = UPD.START_RX.match(c)
        if ms:
            body, j = [], i + 1
            while j < len(lines) and not SCRIPT_END.match(UPD._marker(lines[j])):
                body.append(lines[j])
                j += 1
            if j >= len(lines):
                out["errors"].append("חסרה השורה «=== סוף סקריפט ===» — כנראה התשובה נקטעה באמצע. לבקש מהצ'אט לשלוח את התיקון כולו שוב")
            else:
                out["script"] = UPD.LEAD_BIDI.sub("", "\n".join(UPD._unfence(body))).strip("\n") + "\n"
            i = j + 1
            continue
        if me and me.group(1) in ("החלפה", "EDIT"):
            path = me.group(2).strip().strip("`\"'*")
            if Path(path).name.lower() != "subtitles.ass":
                out["errors"].append("החלפה בקובץ «%s» — מותר רק subtitles.ass (לשינויים אחרים: סקריפט)" % path)
            body, j = [], i + 1
            while j < len(lines):
                cc = UPD._marker(lines[j])
                if UPD.END_RX.match(cc) or UPD.START_RX.match(cc):
                    break
                body.append(lines[j])
                j += 1
            errs = []
            for old, new in UPD._pairs(body, path, errs):
                mode = "one"
                ol = old.split("\n")
                if ol and ol[0].strip() in ("@all", "@regex"):
                    mode = ol[0].strip()[1:]
                    old = "\n".join(ol[1:])
                out["edits"].append((mode, old, new))
            out["errors"] += errs
            i = j + 1 if j < len(lines) and UPD.END_RX.match(UPD._marker(lines[j])) else j
            continue
        rest.append(lines[i])
        i += 1
    rest = UPD.LEAD_BIDI.sub("", "\n".join(rest))
    mm = re.search(r"^[\s*_#>]*(?:תיאור|Description)\s*[*_]*\s*:\s*[*_]*\s*(.+?)[*_\s]*$", rest, re.M)
    if mm:
        out["desc"] = mm.group(1).strip()[:200]
    if out["edits"] and out["script"]:
        out["errors"].append("יש גם החלפה בכתוביות וגם סקריפט — צריך תיקון אחד בלבד")
    elif out["edits"]:
        out["kind"] = "ass"
    elif out["script"]:
        out["kind"] = "script"
    elif not out["errors"]:
        q = rest.strip()
        out["kind"] = "question" if "?" in q and len(q) < 1500 else "none"
        if out["kind"] == "none":
            out["errors"].append("לא מצאתי בתשובה תיקון בפורמט «=== תיקון קליפ ===» (החלפה ב-subtitles.ass או סקריפט). "
                                 "לבקש מהצ'אט לענות לפי ההוראות שהועתקו לו")
    return out


# סקריפט: סריקה סטטית (חוסמת דברים שכמעט תמיד מעידים על בעיה; הבידוד האמיתי — unshare + תיקייה זמנית + בדיקת קבצי הקליף)
BAD_SCRIPT = [
    (r"\b(?:import|from)\s+(socket|urllib|requests|http|ftplib|smtplib|paramiko|webbrowser|ctypes|pty|telnetlib|xmlrpc)\b", "ייבוא רשת/מערכת (%s) אסור"),
    (r"\b(rmtree|os\.remove|os\.unlink|os\.rmdir|os\.removedirs|shutil\.move)\b|\.unlink\s*\(|\.rmdir\s*\(", "מחיקה/העברה אסורה"),
    (r"\b(eval|exec|compile|__import__)\s*\(", "eval/exec ודומיהם אסורים (עקיפה של הסריקה)"),
    (r"os\.system|os\.popen|shell\s*=\s*True|os\.exec|os\.spawn|os\.chmod|os\.chown|os\.symlink|os\.link\s*\(", "הרצת shell/הרשאות אסורה — subprocess עם רשימת ארגומנטים בלבד"),
    (r"['\"](curl|wget|rclone|ssh|scp|nc|ncat|sudo|rm|dd|mkfs|chmod|kill|pkill)['\" ]", "פקודת מערכת אסורה"),
    (r"config\.env|cookies?\.txt|rclone\.conf|GEMINI|MODAL_TOKEN|\.ssh\b|\bSHORTS_LIB\b", "קבצי הגדרות/מפתחות או SHORTS_LIB אסורים"),
    (r"(?<![\w.])\.\./|\.\.\\|[\"'](?:/home|/mnt|/root|/etc|/usr|/var|/tmp|~|[A-Za-z]:\\)", "נתיב מחוץ לתיקיית העבודה (להשתמש ב-IN_DIR/OUT_DIR)"),
]


def scan_script(src):
    errs = []
    for rx, msg in BAD_SCRIPT:
        m = re.search(rx, src)
        if m:
            line = src[:m.start()].count("\n") + 1
            errs.append("שורה %d: %s — «%s»" % (line, msg.replace("(%s)", "").replace("  ", " "), src.split("\n")[line - 1].strip()[:80]))
    try:
        compile(src, "fix.py", "exec")
    except SyntaxError as e:
        errs.append("שגיאת תחביר בסקריפט: שורה %s — %s" % (e.lineno, e.msg))
    return errs


def _plain_words(ass):
    out = []
    for _, _, _, _, _, raw in ass_events(ass):
        t = raw.split(",", 9)[9]
        t = re.sub(r"\{[^}]*\}", "", t).replace("\\N", " ").replace("\\n", " ")
        out += re.findall(r"[\w\u0590-\u05ff']+", t)
    return out


def check(P, name, text):
    """בדיקה בלי להריץ: מה סוג התיקון, כמה מופעים יוחלפו, האם הסקריפט עבר סריקה. → dict לדף."""
    P = Path(P)
    name = _safe_name(name)
    r = parse(text)
    res = {"kind": r["kind"], "desc": r["desc"], "errors": list(r["errors"]), "notes": [], "bug": r["bug"], "ok": False}
    if r["kind"] == "tool_bug":
        res["notes"].append("הצ'אט חושב שזה באג בתוכנה עצמה: " + r["bug"])
        return res
    if r["kind"] == "question":
        res["notes"].append("הצ'אט שואל שאלה — עונים לו באותו צ'אט")
        return res
    if r["kind"] == "ass":
        ap = P / ("work/subtitles/%s.ass" % name)
        if not ap.exists():
            res["errors"].append("אין קובץ כתוביות לקליף הזה")
            return res
        cur = ap.read_text(encoding="utf-8-sig", errors="replace")
        orig = cur
        for k, (mode, old, new) in enumerate(r["edits"], 1):
            try:
                cur, n = _edit_apply_one(cur, mode, old, new)
                res["notes"].append("החלפה %d: %d מופעים יוחלפו" % (k, n))
            except UPD.EditMiss as e:
                res["errors"].append("החלפה %d: %s" % (k, e))
        if not res["errors"] and cur == orig:
            res["errors"].append("התיקון לא משנה כלום בכתוביות")
        if not res["errors"]:
            n0, n1 = len(ass_events(orig)), len(ass_events(cur))
            if n0 != n1:
                res["errors"].append("מספר שורות ה-Dialogue השתנה (%d→%d) — תיקון כתוביות לא אמור להוסיף/להוריד אירועים" % (n0, n1))
            w0, w1 = _plain_words(orig), _plain_words(cur)
            if w0 != w1:
                res["notes"].append("⚠ המילים המדוברות שבכתוביות השתנו — לבדוק בעין לפני אישור")
    elif r["kind"] == "script":
        res["errors"] += scan_script(r["script"])
        if not sandbox_available()[0]:
            res["errors"].append(NO_SANDBOX_MSG)
        res["notes"].append("סקריפט פייתון (%d שורות): ירוץ בלי רשת, בתיקייה זמנית, על עותקים של הקבצים" % r["script"].count("\n"))
    res["ok"] = r["kind"] in ("ass", "script") and not res["errors"]
    return res


# ─────────────── תיקייה, סטטוס, גרסאות ───────────────

def fix_dir(P, fid=""):
    d = Path(P) / "work" / "fix"
    return d / fid if fid else d


def meta_path(P, fid):
    return fix_dir(P, fid) / "result.json"


def load_meta(P, fid):
    try:
        return json.load(open(meta_path(P, fid), encoding="utf-8"))
    except (OSError, ValueError):
        return None


def save_meta(P, fid, m):
    p = meta_path(P, fid)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def stage(P, name, text, defect="", at=None):
    """שומר את התשובה שהודבקה (לפני ההרצה): work/fix/<id>/answer.txt + result.json (state=queued). → fid"""
    P = Path(P)
    name = _safe_name(name)
    ch = check(P, name, text)
    if not ch["ok"]:
        raise ValueError("; ".join(ch["errors"]) or "התשובה לא ניתנת להרצה")
    fid = time.strftime("%Y%m%d_%H%M%S") + "_" + name
    d = fix_dir(P, fid)
    d.mkdir(parents=True, exist_ok=True)
    (d / "answer.txt").write_text(text, encoding="utf-8")
    save_meta(P, fid, {"id": fid, "clip": name, "state": "queued", "kind": ch["kind"], "desc": ch["desc"], "defect": (defect or "")[:1000],
                       "at": at, "created": time.strftime("%Y-%m-%d %H:%M:%S"), "notes": ch["notes"]})
    return fid


def list_fixes(P, name):
    out = []
    d = fix_dir(P)
    if not d.exists():
        return out
    for x in sorted(d.glob("*_%s" % name)):
        m = load_meta(P, x.name)
        if m:
            out.append(m)
    return out


def state_view(P, name):
    """הסטטוס שהדף מצייר: התיקון האחרון (ממתין / רץ / מוכן לאישור / אושר / נכשל / בוטל) + האם אפשר לחזור."""
    P = Path(P)
    name = _safe_name(name)
    fx = [m for m in list_fixes(P, name) if m.get("state") != "discarded"]
    last = fx[-1] if fx else None
    acc = [m for m in fx if m.get("state") == "accepted"]
    return {"last": last, "can_undo": bool(acc), "undo_desc": acc[-1].get("desc", "") if acc else "",
            "history": [{"id": m["id"], "state": m["state"], "desc": m.get("desc", ""), "at": m.get("created", "")} for m in fx[-8:]]}


# ─────────────── הרצה ───────────────

def _clip_manifest(P, c):
    """רשימת הקבצים של הקליף (גודל, mtime) — לפני ואחרי סקריפט, כדי לתפוס כתיבה מחוץ לתיקיית העבודה."""
    P = Path(P)
    n = c["name"]
    pats = ["shorts/%s*/**/*" % n, "work/plain/%s*" % n, "work/burn/%s*" % n, "work/subtitles/%s*" % n, "work/hook/%s*" % n,
            "work/clean/%s*" % n, c["clean"], c["edit"]]
    out = {}
    for pat in pats:
        for f in P.glob(pat):
            if f.is_file():
                try:
                    s = f.stat()
                    out[str(f.relative_to(P))] = (s.st_size, s.st_mtime_ns)
                except OSError:
                    pass
    return out


NO_SANDBOX_MSG = ("התכונה הזאת דורשת רכיב שלא מותקן במחשב הזה (bubblewrap — בידוד לסקריפט של הצ'אט). "
                   "בלעדיו לא מריצים סקריפט של צ'אט כדי שלא יוכל לגעת בקבצים שלך. אפשר לבקש מהצ'אט תיקון כתוביות "
                   "(החלפת טקסט) במקום סקריפט, או להתקין: sudo apt install bubblewrap")
_SB_OK = {}


def _sb_system_args():
    """קישורי המערכת לקריאה בלבד: /usr וכו'. השורש הוא tmpfs ריק — כל מה שלא כאן לא קיים בתוך הבידוד."""
    a = []
    for p in ("/usr", "/bin", "/sbin", "/lib", "/lib64", "/lib32"):
        if os.path.islink(p):
            a += ["--symlink", os.readlink(p), p]
        elif os.path.isdir(p):
            a += ["--ro-bind", p, p]
    for p in ("/etc/ld.so.cache", "/etc/fonts", "/etc/passwd", "/etc/group", "/etc/localtime", "/etc/alternatives"):
        if os.path.exists(p):
            a += ["--ro-bind", p, p]
    return a


def sandbox_available():
    """האם bwrap קיים ועובד (נבדק בהרצה קצרה אמיתית). → (True, "") או (False, הסבר)."""
    if "v" in _SB_OK:
        return _SB_OK["v"]
    exe = shutil.which("bwrap")
    if not exe:
        res = (False, "bwrap לא מותקן")
    else:
        try:
            r = subprocess.run([exe, "--unshare-all", "--die-with-parent"] + _sb_system_args() + ["--proc", "/proc", "--dev", "/dev",
                                                                                                "/usr/bin/true"],
                               capture_output=True, text=True, timeout=15)
            res = (True, "") if r.returncode == 0 else (False, "bwrap לא עובד כאן: " + (r.stderr or "").strip()[:120])
        except (OSError, subprocess.SubprocessError) as e:
            res = (False, "bwrap לא עובד כאן: %s" % e)
    _SB_OK["v"] = res
    return res


def _sandbox_cmd(script, inn=None, out=None, fonts=None):
    """פקודת bubblewrap: שורש tmpfs ריק, מערכת לקריאה בלבד, בית ריק (tmpfs), רשת מנותקת, כל התהליכים נקשרים להורה.
    כתיבה — רק ל-OUT_DIR (ול-/tmp הריק שנעלם בסוף). IN_DIR לקריאה בלבד. תיקיית ההגדרות/מפתחות/rclone/הפרויקט — לא קיימים שם.
    → (פקודה, True), או (None, False) כשאין בידוד אמיתי — אז לא מריצים."""
    ok_, _why = sandbox_available()
    if not ok_:
        return None, False
    home = os.path.expanduser("~")
    cmd = [shutil.which("bwrap"), "--unshare-all", "--die-with-parent", "--new-session", "--clearenv"] + _sb_system_args()
    cmd += ["--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp", "--tmpfs", home]
    ro = []
    for p in (sys.prefix, sys.base_prefix, sys.exec_prefix, os.path.dirname(os.path.realpath(sys.executable)),
              os.path.dirname(os.path.dirname(os.path.realpath(sys.executable)))):
        if p and p not in ro and os.path.isdir(p) and p != "/":
            ro.append(p)
    for p in ro:
        cmd += ["--ro-bind", p, p]
    tools = {}
    for key, exe in (("FFMPEG", FFMPEG), ("FFPROBE", FFPROBE)):
        real = shutil.which(exe) or exe
        tools[key] = real
        if os.path.isfile(real):
            cmd += ["--ro-bind", os.path.realpath(real), real]
    if fonts and os.path.isdir(fonts):
        cmd += ["--ro-bind", fonts, fonts]
    if inn:
        cmd += ["--ro-bind", str(inn), str(inn)]
    if out:
        cmd += ["--bind", str(out), str(out)]
    cmd += ["--ro-bind", script, "/sandbox/fix.py", "--chdir", "/tmp"]
    for k, v in (("PATH", "/usr/bin:/bin"), ("HOME", home), ("TMPDIR", "/tmp"), ("LANG", "C.UTF-8"), ("PYTHONDONTWRITEBYTECODE", "1"),
                 ("IN_DIR", str(inn or "")), ("OUT_DIR", str(out or "")), ("FFMPEG", tools["FFMPEG"]), ("FFPROBE", tools["FFPROBE"]),
                 ("FONTS_DIR", str(fonts or ""))):
        cmd += ["--setenv", k, v]
    return cmd + [PY, "-B", "-I", "/sandbox/fix.py"], True


def _frame(video, t, out, h=480):
    subprocess.run([FFMPEG, "-y", "-v", "error", "-nostdin", "-ss", "%.3f" % max(0, t), "-i", str(video), "-frames:v", "1",
                    "-vf", "scale=-2:%d" % h, "-q:v", "3", str(out)], capture_output=True, timeout=120)


def _gray_stats(video, t):
    """ממוצע וסטיית תקן של פריים קטן באפור — להבחין בפריים שחור/ריק."""
    try:
        import numpy as np
        r = subprocess.run([FFMPEG, "-v", "error", "-nostdin", "-ss", "%.3f" % max(0, t), "-i", str(video), "-frames:v", "1",
                            "-vf", "scale=72:128,format=gray", "-f", "rawvideo", "-"], capture_output=True, timeout=120)
        a = np.frombuffer(r.stdout, dtype="uint8")
        return (float(a.mean()), float(a.std())) if a.size else (None, None)
    except Exception:
        return (None, None)


def verify(old, new):
    """בדיקה עצמית של הגרסה החדשה מול הישנה. → (ok, [שורות {ok, text}])"""
    rows, ok = [], True

    def row(good, text, hard=True):
        nonlocal ok
        rows.append({"ok": bool(good), "text": text})
        if not good and hard:
            ok = False

    po, pn = probe(old), probe(new)
    row(pn.get("has_audio") and pn.get("w"), "יש וידאו וקול בקובץ החדש")
    row((pn.get("w"), pn.get("h")) == (po.get("w"), po.get("h")), "רזולוציה %sx%s (כמו הקודם: %sx%s)" % (pn.get("w"), pn.get("h"), po.get("w"), po.get("h")))
    row(abs((pn.get("fps") or 0) - (po.get("fps") or 0)) < 0.6, "קצב %s fps (קודם %s)" % (pn.get("fps"), po.get("fps")))
    row(abs((pn.get("dur") or 0) - (po.get("dur") or 0)) <= 0.75, "אורך %.2f שניות (קודם %.2f)" % (pn.get("dur", 0), po.get("dur", 0)))
    row(pn.get("vcodec") == "h264" and pn.get("acodec") == "aac", "קידוד %s + %s" % (pn.get("vcodec"), pn.get("acodec")))
    lo, ln = loudness(old), loudness(new)
    if ln.get("lufs") is not None:
        row(-16.5 <= ln["lufs"] <= -11.5, "עוצמה %.1f LUFS (קודם %s) — היעד סביב -14 עם מוזיקה" % (ln["lufs"], lo.get("lufs")), hard=False)
        if ln.get("peak") is not None:
            row(ln["peak"] <= -0.5, "פסגה %.1f dBFS (בלי קליפינג)" % ln["peak"], hard=False)
    dur = pn.get("dur") or 0
    bad = 0
    for k in range(1, 6):
        t = dur * k / 6
        mn, sn = _gray_stats(new, t)
        mo, so = _gray_stats(old, t)
        if mn is not None and (mn < 3 and (sn or 0) < 2) and not (mo is not None and mo < 3 and (so or 0) < 2):
            bad += 1
    row(bad == 0, "5 פריימים לדוגמה — לא ריקים/שחורים" if not bad else "%d פריימים שחורים בגרסה החדשה" % bad)
    return ok, rows


def _log(msg):
    print(msg, flush=True)


def apply_job(project, name, fid):
    """העבודה שהשרת מריץ (cwd = הפרויקט): בונה גרסה חדשה בתיקיית work/fix/<id>/ — לא נוגעת בטיוטה. מסיימת ב-state=ready/failed."""
    import make_short as MS
    import make_short_settings as SET
    P = Path(project).resolve()
    os.chdir(P)
    name = _safe_name(name)
    meta = load_meta(P, fid)
    if not meta or meta["clip"] != name:
        raise ValueError("אין תיקון כזה")
    meta.update(state="running", started=time.strftime("%H:%M:%S"))
    save_meta(P, fid, meta)
    d = fix_dir(P, fid)
    try:
        st = _read_st(P)
        c = _clip(st, name)
        MS.use_rabbi(st.get("rabbi"))
        r = parse((d / "answer.txt").read_text(encoding="utf-8"))
        old_dir, old_final = final_of(P, name)
        plain = P / ("work/plain/%s.mp4" % name)
        ap = P / ("work/subtitles/%s.ass" % name)
        if not plain.exists() or not ap.exists():
            raise ValueError("חסרים קבצי עבודה של הקליף (בסיס בלי מוזיקה / כתוביות) — צריך ליצור את השורט מחדש")
        base = {"final": sig(old_final), "plain": sig(plain), "ass": sig(ap)}
        new_plain, new_ass = d / "plain_new.mp4", d / "subtitles_new.ass"
        if r["kind"] == "ass":
            cur = ap.read_text(encoding="utf-8-sig", errors="replace")
            for mode, old, new in r["edits"]:
                cur, n = _edit_apply_one(cur, mode, old, new)
                _log("✎ החלפה: %d מופעים" % n)
            new_ass.write_text(cur, encoding="utf-8")
            import build_clean_video as BCV
            src = burn_source(P, c)
            logos = SET.logos(SET.load())
            _log("⑤ צורב מחדש את הכתוביות המתוקנות%s (דקה-שתיים)" % (" עם הסמלים" if logos else ""))
            burn = d / "burn.mp4"
            with MS.heavy(name):
                BCV.burn_subtitles(str(src), str(new_ass), str(burn), os.path.join(MS.LIB, "fonts"), logos=logos)
            _log("⑥ מנרמל קול")
            MS.loudnorm(str(burn), str(new_plain))
            burn.unlink()
        else:
            err = scan_script(r["script"])
            if err:
                raise ValueError("הסקריפט נדחה: " + "; ".join(err))
            inn, out = d / "in", d / "out"
            for x in (inn, out, d / "tmp"):
                x.mkdir(exist_ok=True)
            for src, dst in ((old_final, "final.mp4"), (plain, "plain.mp4"), (burn_source(P, c), "clean.mp4"), (ap, "subtitles.ass")):
                shutil.copy2(src, inn / dst)       # עותק אמיתי (לא קישור קשיח) — כתיבה לעותק לא משנה את המקור
            wj = P / ("work/hook/%s_words.json" % name)
            if not wj.exists():
                wj = P / ("work/subtitles/%s_words.json" % name)
            if wj.exists():
                shutil.copy2(wj, inn / "words.json")
            ftxt, _ = facts(P, name)
            (inn / "info.json").write_text(json.dumps({"facts": ftxt, "at": meta.get("at"), "defect": meta.get("defect")},
                                                      ensure_ascii=False, indent=1), encoding="utf-8")
            (d / "fix.py").write_text(r["script"], encoding="utf-8")
            before = _clip_manifest(P, c)
            cmd, isolated = _sandbox_cmd(str(d / "fix.py"), inn, out, os.path.join(MS.LIB, "fonts"))
            if not isolated:
                raise RuntimeError(NO_SANDBOX_MSG)
            _log("⑤ מריץ את הסקריפט של הצ'אט בבידוד מלא (בלי רשת, בלי גישה לקבצים שלך — רק לתיקיית העבודה שלו)")
            env = {"PATH": os.environ.get("PATH", ""), "LANG": "C.UTF-8"}   # bwrap --clearenv; המשתנים האמיתיים נקבעים בתוך הבידוד
            with MS.heavy(name):
                try:
                    p = subprocess.run(cmd, cwd=str(d), env=env, capture_output=True, text=True, errors="replace", timeout=SCRIPT_TIMEOUT)
                except subprocess.TimeoutExpired:
                    raise RuntimeError("הסקריפט רץ יותר מ-%d דקות — נעצר" % (SCRIPT_TIMEOUT // 60))
            for l in ((p.stdout or "") + (p.stderr or "")).strip().splitlines()[-25:]:
                _log("   | " + l[:200])
            if p.returncode:
                raise RuntimeError("הסקריפט נכשל (קוד %d) — השורות האחרונות ביומן" % p.returncode)
            if _clip_manifest(P, c) != before:
                raise RuntimeError("🚨 הסקריפט נגע בקבצים של הקליף מחוץ לתיקיית העבודה שלו — נדחה (כדאי לבדוק את הטיוטה מול הגרסה השמורה)")
            outp = out / "plain.mp4"
            if not outp.exists() or outp.stat().st_size < 10000:
                raise RuntimeError("הסקריפט לא כתב OUT_DIR/plain.mp4")
            _log("⑥ מנרמל קול")
            MS.loudnorm(str(outp), str(new_plain))
            if (out / "subtitles.ass").exists():
                shutil.copy2(out / "subtitles.ass", new_ass)
        # מוזיקה — אותה מנגינה כמו בקליף
        new_final = d / "final_new.mp4"
        track = MS.track_by_uuid_safe(c["track"]) if c.get("track") else None
        if track:
            _log("⑦ מערבב את «%s»" % track["title"])
            MS.add_music(str(new_plain), str(new_final), track, int(c.get("music_db") or 0))
        else:
            shutil.copyfile(new_plain, new_final)
        ok, rows = verify(old_final, new_final)
        at = meta.get("at")
        if at is None:
            at = (probe(new_final).get("dur") or 10) * 0.3
        _frame(old_final, at, d / "before.jpg")
        _frame(new_final, at, d / "after.jpg")
        meta.update(state="ready" if ok else "failed", checks=rows, base=base, frame_at=at, finished=time.strftime("%H:%M:%S"),
                    has_ass=new_ass.exists(),
                    error="" if ok else "הבדיקה העצמית נכשלה — הגרסה החדשה לא תוחלף. " + "; ".join(x["text"] for x in rows if not x["ok"]))
        save_meta(P, fid, meta)
        for x in rows:
            _log("   %s %s" % ("✓" if x["ok"] else "✗", x["text"]))
        _log("✅ הגרסה החדשה מוכנה לבדיקה — לפני/אחרי בכרטיס" if ok else "❌ " + meta["error"])
        return 0 if ok else 1
    except Exception as e:
        meta.update(state="failed", error=str(e)[:600], finished=time.strftime("%H:%M:%S"))
        save_meta(P, fid, meta)
        _log("❌ %s" % e)
        return 1


def _vdir(P, name):
    return fix_dir(P) / "versions" / name


def accept(P, name, fid):
    """"✓ אשר": הגרסה החדשה נכנסת, הישנה (סרטון סופי, בסיס בלי מוזיקה, כתוביות) נשמרת ב-work/fix/versions/<clip>/<id>_*."""
    P = Path(P)
    name = _safe_name(name)
    m = load_meta(P, fid)
    if not m or m["clip"] != name or m.get("state") != "ready":
        raise ValueError("אין תיקון מוכן לאישור")
    d = fix_dir(P, fid)
    old_dir, old_final = final_of(P, name)
    plain, ap = P / ("work/plain/%s.mp4" % name), P / ("work/subtitles/%s.ass" % name)
    b = m.get("base") or {}
    if sig(old_final) != b.get("final") or sig(plain) != b.get("plain"):
        raise ValueError("הקליף השתנה בזמן שהתיקון חיכה (צבע/מוזיקה/צריבה) — להריץ את התיקון שוב על הגרסה הנוכחית")
    v = _vdir(P, name)
    v.mkdir(parents=True, exist_ok=True)
    shutil.copy2(old_final, v / ("%s_final_before.mp4" % fid))
    shutil.copy2(plain, v / ("%s_plain_before.mp4" % fid))
    if ap.exists():
        shutil.copy2(ap, v / ("%s_ass_before.ass" % fid))
    shutil.copy2(d / "plain_new.mp4", str(plain) + ".part")
    os.replace(str(plain) + ".part", plain)
    shutil.copy2(d / "final_new.mp4", str(old_final) + ".part")
    os.replace(str(old_final) + ".part", old_final)
    if (d / "subtitles_new.ass").exists():
        shutil.copy2(d / "subtitles_new.ass", ap)
    m.update(state="accepted", accepted=time.strftime("%Y-%m-%d %H:%M:%S"), accepted_sig=sig(old_final))
    save_meta(P, fid, m)
    _set_clip_fix(P, name, {"id": fid, "desc": m.get("desc", ""), "at": m["accepted"]}, add=True)
    return state_view(P, name)


def undo(P, name):
    """"↩ חזור לגרסה הקודמת": משחזר את האחרון שאושר. הסרטון הסופי — בדיוק מהקובץ השמור אם לא השתנה מאז; אחרת מערבבים מחדש מהבסיס."""
    P = Path(P)
    name = _safe_name(name)
    acc = [m for m in list_fixes(P, name) if m.get("state") == "accepted"]
    if not acc:
        raise ValueError("אין תיקון לבטל")
    m = acc[-1]
    fid = m["id"]
    v = _vdir(P, name)
    pb, fb, ab = v / ("%s_plain_before.mp4" % fid), v / ("%s_final_before.mp4" % fid), v / ("%s_ass_before.ass" % fid)
    if not pb.exists() or not fb.exists():
        raise ValueError("הגרסה הקודמת לא נמצאה בתיקיית הגרסאות")
    old_dir, final = final_of(P, name)
    plain, ap = P / ("work/plain/%s.mp4" % name), P / ("work/subtitles/%s.ass" % name)
    same = sig(final) == m.get("accepted_sig")
    part = str(final) + ".part"
    if same:
        shutil.copy2(fb, part)
    else:                                    # אחרי התיקון שונתה המוזיקה/העוצמה — מערבבים מחדש מהבסיס המשוחזר
        import make_short as MS
        st = _read_st(P)
        c = _clip(st, name)
        track = MS.track_by_uuid_safe(c["track"]) if c.get("track") else None
        if track:
            MS.add_music(str(pb), part, track, int(c.get("music_db") or 0))
        else:
            shutil.copy2(pb, part)
    shutil.copy2(pb, str(plain) + ".part")
    os.replace(str(plain) + ".part", plain)
    if ab.exists():
        shutil.copy2(ab, ap)
    os.replace(part, final)
    m.update(state="undone", undone=time.strftime("%Y-%m-%d %H:%M:%S"))
    save_meta(P, fid, m)
    _set_clip_fix(P, name, {"id": fid}, add=False)
    return state_view(P, name)


def discard(P, name, fid):
    m = load_meta(P, fid)
    if not m or m["clip"] != _safe_name(name) or m.get("state") not in ("ready", "failed", "queued"):
        raise ValueError("אין מה לזרוק")
    m.update(state="discarded")
    save_meta(P, fid, m)
    for x in ("plain_new.mp4", "final_new.mp4", "burn.mp4"):
        try:
            (fix_dir(P, fid) / x).unlink()
        except OSError:
            pass
    return state_view(P, name)


def _set_clip_fix(P, name, entry, add):
    """chat_fixes בקליף (ב-make_short.json). קורא טרי וכותב אטומית — מי שקורא לפונקציה מחזיק את נעילת הקובץ."""
    f = Path(P) / "make_short.json"
    st = json.load(open(f, encoding="utf-8"))
    c = _clip(st, name)
    lst = [x for x in c.get("chat_fixes", []) if x.get("id") != entry["id"]]
    if add:
        lst.append(entry)
    if lst:
        c["chat_fixes"] = lst
    else:
        c.pop("chat_fixes", None)
    tmp = f.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def review_copy(P, name):
    """עותק קטן (540x960, איכות נמוכה) לצפייה/העלאה מהירה. לא מחליף את המקורי."""
    P = Path(P)
    name = _safe_name(name)
    d, final = final_of(P, name)
    out = fix_dir(P) / ("review_%s.mp4" % name)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".part.mp4")
    r = subprocess.run([FFMPEG, "-y", "-v", "error", "-nostdin", "-i", str(final), "-vf", "scale=540:-2", "-c:v", "libx264", "-preset", "veryfast",
                        "-crf", "30", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", str(tmp)], capture_output=True, text=True, timeout=600)
    if r.returncode:
        raise RuntimeError("יצירת העותק הקטן נכשלה: " + (r.stderr or "").strip().splitlines()[-1][:200])
    os.replace(tmp, out)
    return {"path": str(out), "win": win(out), "size": out.stat().st_size}


def file_for(P, name, key):
    for f in files_view(P, name):
        if f["key"] == key and f["exists"]:
            return Path(f["abs"])
    raise ValueError("אין קובץ כזה")


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if a[:1] == ["block"] and len(a) >= 4:
            at = next((float(x[5:]) for x in a[4:] if x.startswith("--at=")), None)
            print(build_block(a[1], a[2], a[3], at)["text"])
        elif a[:1] == ["check"] and len(a) == 4:
            print(json.dumps(check(a[1], a[2], Path(a[3]).read_text(encoding="utf-8")), ensure_ascii=False, indent=1))
        elif a[:1] == ["apply"] and len(a) == 4:
            sys.exit(apply_job(a[1], a[2], a[3]))
        else:
            sys.exit(__doc__)
    except ValueError as e:
        print("❌ %s" % e)
        sys.exit(1)
