# -*- coding: utf-8 -*-
"""תמלול על Modal — חלופה ל-Colab (colab_asr.py) כשאין GPU חינמי זמין.

בניגוד ל-Colab, Modal לא צריך את כל ריקוד ה-run/poll/pull/stop: קריאה
לפונקציה חוסמת עד שהיא מסיימת, Modal מנהל את ה-retry/reconnect בעצמו,
ואין VM שנשאר פתוח בסרק לשלם עליו — scale-to-zero אוטומטי.

התקנה חד-פעמית (על השרת, ה-venv של shorts):
    pip install modal
    modal token new        # פותח דפדפן, לחיצה אחת

שימוש (אותה חתימת פלט בדיוק כמו colab_asr.py — words.json + segments.json + txt):
    python modal_asr.py run --media a.mp4 b.mp4 --out-dir work/subtitles
"""
import argparse
import json
import sys
from pathlib import Path

import modal

MODEL = "ivrit-ai/whisper-large-v3-ct2"
FALLBACK = "ivrit-ai/whisper-large-v3-turbo-ct2"
LANG = "he"

app = modal.App("shorts-asr")

image = (
    # debian_slim לא מביא את ספריות ה-CUDA runtime (libcublas/libcudnn)
    # שה-CTranslate2 backend של faster-whisper צריך על GPU — נכשל עם
    # RuntimeError: Library libcublas.so.12 is not found. תמונת ה-nvidia/cuda
    # runtime מביאה אותן מובנה, בדיוק כמו שדוגמאות faster-whisper הרשמיות
    # של Modal עושות.
    modal.Image.from_registry(
        "nvidia/cuda:12.1.1-cudnn8-runtime-ubuntu22.04", add_python="3.11"
    )
    .apt_install("ffmpeg")
    .pip_install("faster-whisper", "torch", "huggingface_hub")
)

# מוריד את המודל פעם אחת ושומר אותו בין ריצות — בלי זה כל קריאה מורידה
# מחדש כמה GB, וזה בדיוק ה"קור" שהופך את המחיר לגרוע.
model_cache = modal.Volume.from_name("shorts-asr-model-cache", create_if_missing=True)


# 🚨 מסלול CPU — נוסף 17/9/2026. Modal חוסם GPU בלי כרטיס אשראי (מוקש 17),
# אבל CPU לא דורש GPU. המחשב הביתי לא מחזיק את המודל המלא (OOM, מוקש 15),
# אז בענן על CPU מקבלים את ivrit-ai המלא במקום turbo. בלי torch ובלי CUDA:
# ctranslate2 מביא את ה-backend של CPU בעצמו, והתמונה קטנה בהרבה.
cpu_image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("ffmpeg")
    .pip_install("faster-whisper", "huggingface_hub")
)
CPU_CORES = 8
# App נפרד: `app.run()` רושם את כל הפונקציות של ה-App, כולל זו עם ה-GPU —
# ו-Modal דוחה את כולן ("add a payment method to use T4") גם כשקוראים רק ל-CPU.
cpu_app = modal.App("shorts-asr-cpu")


@app.function(
    image=image,
    gpu="T4",
    volumes={"/cache": model_cache},
    timeout=900,
    scaledown_window=120,
)
def transcribe_job(audio_bytes: bytes, stem: str, prompt: str = "", fast: bool = False,
                   model: str = "") -> dict:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("אין GPU בקונטיינר — עוצר")
    return _transcribe(audio_bytes, stem, prompt, fast, "cuda", "float16", model)


@cpu_app.function(
    image=cpu_image,
    cpu=float(CPU_CORES),
    memory=8192,
    volumes={"/cache": model_cache},
    timeout=1800,
    scaledown_window=60,
)
def transcribe_job_cpu(audio_bytes: bytes, stem: str, prompt: str = "", fast: bool = False,
                       model: str = "") -> dict:
    return _transcribe(audio_bytes, stem, prompt, fast, "cpu", "int8", model)


def _transcribe(audio_bytes, stem, prompt, fast, device, compute_type, model=""):
    import subprocess
    import tempfile
    import time

    from faster_whisper import WhisperModel

    extra = {"cpu_threads": CPU_CORES} if device == "cpu" else {}
    with tempfile.TemporaryDirectory() as td:
        raw = Path(td) / "raw"
        raw.write_bytes(audio_bytes)
        wav = Path(td) / "prep.wav"
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw),
             "-vn", "-ac", "1", "-ar", "16000",
             "-af", "highpass=f=70,dynaudnorm=f=200:g=12:p=0.9",
             "-c:a", "pcm_s16le", str(wav)],
            check=True)

        import os
        os.environ["HF_HOME"] = "/cache/hf"
        # fast=True: מודל כללי קטן, greedy, בלי חותמות מילה — למציאת קטעים
        # בלבד, לא לציטוט מדויק. הרבה יותר מהיר וזול. לקליפים הסופיים
        # תמיד fast=False (ivrit-ai, beam search מלא, חותמות מילה).
        # model מפורש (--model) = אוזן שנייה בענן; אין לו נפילה-לאחור שקטה,
        # כי "אוזן שנייה" שחזרה בשקט למודל הראשי כבר לא בלתי תלויה.
        model_id = model or ("small" if fast else MODEL)
        try:
            model = WhisperModel(model_id, device=device, compute_type=compute_type,
                                  download_root="/cache/models", **extra)
        except Exception:
            if model_id != MODEL:
                raise
            model_id = FALLBACK
            model = WhisperModel(model_id, device=device, compute_type=compute_type,
                                  download_root="/cache/models", **extra)
        model_cache.commit()

        t0 = time.time()
        if fast:
            segments, _ = model.transcribe(
                str(wav), language=LANG, task="transcribe",
                beam_size=1, word_timestamps=False,
                vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=250),
            )
        else:
            segments, _ = model.transcribe(
                str(wav),
                language=LANG, task="transcribe",
                beam_size=5, best_of=5, patience=1.0,
                temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                compression_ratio_threshold=2.4,
                log_prob_threshold=-1.0,
                no_speech_threshold=0.6,
                condition_on_previous_text=False,
                repetition_penalty=1.05,
                initial_prompt=prompt or "שיעור תורני. לשון תורנית, ציטוטי גמרא ומדרש.",
                word_timestamps=True,
                vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=500, speech_pad_ms=250),
            )

        words, segs = [], []
        for s in segments:
            segs.append({"start": round(s.start, 3), "end": round(s.end, 3),
                         "text": s.text.strip(),
                         "avg_logprob": round(s.avg_logprob, 4),
                         "no_speech_prob": round(s.no_speech_prob, 4)})
            for w in (s.words or []):
                words.append({"word": w.word, "start": round(w.start, 3),
                              "end": round(w.end, 3),
                              "prob": round(getattr(w, "probability", 0.0) or 0.0, 4)})

        return {"stem": stem, "model": model_id, "words": words, "segments": segs,
                "elapsed_sec": round(time.time() - t0, 1)}


def cmd_run(a):
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    jobs = []
    for m in a.media:
        p = Path(m)
        if not p.exists():
            raise SystemExit(f"קובץ לא קיים: {p}")
        jobs.append((p.stem, p.read_bytes()))

    mode = a.model or ("מודל קטן/מהיר (גילוי קטעים בלבד)" if a.fast else "ivrit-ai מלא (איכות סופית)")
    if a.cpu:
        run_app, fn, hw = cpu_app, transcribe_job_cpu, f"CPU {CPU_CORES} ליבות"
    else:
        run_app, fn, hw = app, transcribe_job, "GPU T4"
    print(f"שולח {len(jobs)} עבודות ל-Modal ({hw}) — {mode}...")
    with run_app.run():
        results = list(fn.starmap(
            [(data, stem, a.prompt, a.fast, a.model) for stem, data in jobs]))

    for r in results:
        stem = r["stem"]
        (out_dir / f"{stem}_words.json").write_text(
            json.dumps({"source": stem, "model": r["model"], "words": r["words"]},
                       ensure_ascii=False, indent=2), encoding="utf-8")
        (out_dir / f"{stem}.segments.json").write_text(
            json.dumps(r["segments"], ensure_ascii=False, indent=1), encoding="utf-8")
        (out_dir / f"{stem}.txt").write_text(
            " ".join(s["text"] for s in r["segments"]).strip(), encoding="utf-8")
        print(f"✓ {stem} — {len(r['words'])} מילים, {r['elapsed_sec']}ש' עיבוד")

    print(f"נכתב ל-{out_dir}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("run")
    p.add_argument("--media", nargs="+", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--wait", action="store_true", help="לתאימות עם הממשק של colab_asr — Modal תמיד חוסם עד סיום")
    p.add_argument("--fast", action="store_true", help="מודל קטן/greedy, בלי חותמות מילה — לגילוי קטעים בלבד, לא לקליפים סופיים")
    p.add_argument("--cpu", action="store_true", help="CPU בענן במקום GPU — עובד גם בלי כרטיס אשראי ב-Modal")
    p.add_argument("--model", default="",
                   help="מודל אחר במקום ivrit-ai המלא — אוזן שנייה, למשל ivrit-ai/yi-whisper-large-v3-turbo-ct2")
    # 28/10 (המילון האישי): רמז מילים ל-whisper. ריק = ברירת המחדל ("שיעור תורני..."). make_short שולח אותו רק
    # לאוזן 1, ובודק מול אוזן 2 (בלי רמז) שלא נבלעה התחלה — ריצה עם רמז פעם החמיצה 15 שניות (זיכרון, 9/2026)
    p.add_argument("--prompt", default="")
    a = ap.parse_args()
    if a.cmd == "run":
        cmd_run(a)


if __name__ == "__main__":
    sys.exit(main() or 0)
