# -*- coding: utf-8 -*-
"""
win_recycle.py — מעביר תיקייה מתוך WSL לסל המיחזור של ווינדוס, כך שאפשר לשחזר אותה משם.

למה ככה (כלל קבוע שלו): קבצים מוכנים לא נמחקים — הם עוברים לסל המיחזור, והוא מרוקן בעצמו.
נתיב \\\\wsl אי אפשר לשלוח ישר לסל, ולכן:
  1. מעתיקים לתיקייה זמנית בדיסק C (שם באנגלית בלבד — עברית בשורת פקודה של PowerShell מתעוותת)
  2. מאמתים: אותו מספר קבצים ואותו גודל לכל קובץ
  3. PowerShell: FileSystem.DeleteDirectory(..., SendToRecycleBin)
  4. מוודאים שהפריט באמת בסל (Shell.Application, NameSpace(10))
  5. רק אז מוחקים את המקור — ורק אם הוא בתוך root שנמסר, ולפחות שתי רמות מתחתיו.
שום שלב לא מדלג: כישלון בכל אחד = המקור נשאר כמו שהוא.

שימוש: python win_recycle.py <dir> <root> [label]   → מדפיס BIN=<שם הפריט בסל>
"""
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

PS = "/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"
CMD = "/mnt/c/Windows/System32/cmd.exe"


def _win_localappdata():
    r = subprocess.run([CMD, "/c", "echo %LOCALAPPDATA%"], capture_output=True, text=True, cwd="/mnt/c", timeout=30)
    w = r.stdout.strip().splitlines()[-1].strip()
    u = subprocess.run(["wslpath", "-u", w], capture_output=True, text=True, timeout=30).stdout.strip()
    if not u or not Path(u).is_dir():
        raise RuntimeError("לא מצאתי את תיקיית Temp של ווינדוס")
    return Path(u)


def _files(d):
    return {str(f.relative_to(d)): f.stat().st_size for f in Path(d).rglob("*") if f.is_file()}


def _ps(script):
    r = subprocess.run([PS, "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True, text=True,
                       cwd="/mnt/c", timeout=300)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def recycle(src, root, label="shorts"):
    src, root = Path(src).resolve(), Path(root).resolve()
    if root not in src.parents or len(src.relative_to(root).parts) < 2:
        raise RuntimeError("נתיב מחוץ לתיקיית השורטס — לא נוגע בו: %s" % src)
    if not src.is_dir():
        raise RuntimeError("התיקייה לא קיימת: %s" % src)
    want = _files(src)
    if not want:
        raise RuntimeError("התיקייה ריקה")
    name = "%s_%s" % ("".join(ch for ch in label if ch.isascii() and (ch.isalnum() or ch in "-_"))[:30] or "shorts",
                      time.strftime("%Y%m%d_%H%M%S"))
    stage_root = _win_localappdata() / "Temp" / "ys_recycle"
    stage = stage_root / name / src.name
    stage.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, stage)
    got = _files(stage)
    if got != want:
        shutil.rmtree(stage.parent, ignore_errors=True)
        raise RuntimeError("ההעתקה לסל לא אומתה — לא נמחק כלום")
    wstage = subprocess.run(["wslpath", "-w", str(stage.parent)], capture_output=True, text=True).stdout.strip()
    rc, out = _ps("Add-Type -AssemblyName Microsoft.VisualBasic; "
                  "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory('%s','OnlyErrorDialogs','SendToRecycleBin')"
                  % wstage.replace("'", "''"))
    if rc or stage.parent.exists():
        raise RuntimeError("השליחה לסל המיחזור נכשלה — לא נמחק כלום: %s" % out.strip()[-200:])
    rc, out = _ps("$b=(New-Object -ComObject Shell.Application).NameSpace(10); "
                  "($b.Items() | Where-Object { $_.Name -eq '%s' } | Measure-Object).Count" % name)
    if rc or not out.strip().splitlines() or out.strip().splitlines()[-1].strip() == "0":
        raise RuntimeError("לא מצאתי את הפריט בסל המיחזור — המקור לא נמחק")
    shutil.rmtree(src)                      # רק אחרי שהעותק אומת ונמצא בסל
    return name


if __name__ == "__main__":
    try:
        print("BIN=%s" % recycle(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "shorts"))
    except Exception as e:
        print("❌ %s" % e)
        sys.exit(1)
