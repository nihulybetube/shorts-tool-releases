# -*- coding: utf-8 -*-
"""
make_short_settings.py — "הגדרות מתקדמות" של התוכנה (make_short + החלון).

למה קובץ נפרד (20/10/2026): המשתמש רוצה לשנות בעצמו מה שעד היום היה קבוע בקוד —
מוזיקה, לוגו, צבע כתוביות, כללי עריכה, גיבוי — בלי לבקש מסוכן. ההגדרות נשמרות
ב-~/.config/yeshiva-shorts/make_short_settings.json (ליד שאר ההגדרות שלו, מחוץ לריפו).
ברירות המחדל = מה שהתוכנה עשתה עד היום, כך שקובץ חסר לא משנה כלום.

איפוס וביטול (בקשתו, 20/10): כל איפוס — של הגדרה אחת או "אפס הכול" — שומר את הערכים
שהיו לפניו בקובץ עצמו (undo), כך ש"בטל" מחזיר אותם בדיוק, גם אחרי רענון הדף.
"""
import json
import os
import re
import time
from pathlib import Path

import make_short_guard as GUARD

CONFIG =Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
PATH = Path(os.environ.get("MAKE_SHORT_SETTINGS") or CONFIG / "make_short_settings.json")   # לבדיקות: קובץ אחר

# צבעי ההדגשה שהוא בחר ב-5/10 (karaoke_ass.HIGHLIGHT_RGB) — "אקראי" בוחר מתוכם
DEFAULT_COLORS = {"teal": "1AC8A8", "yellow": "FFE600", "purple": "B14EFF", "green": "39FF14"}
# 28/10: סגנונות כתוביות שאינם "צבע להדגשה" — אסימון במקום RRGGBB, בכל מקום שצבע נבחר (ההגדרה, 🎲, הקליף).
# השם בהגדרה (sub_color) → האסימון → הסגנון ב-karaoke_ass.SUB_STYLES. סגנון חדש = עוד שורה כאן ושם.
STYLE_TOKENS = {"plain": "PLAIN"}            # "ללא צבע": כתוביות לבנות, בלי הדגשת מילה; המילים המסומנות — בצבע
STYLE_NAMES = {"PLAIN": "ללא צבע"}
# 30/10: "מרקר" ו"ריחוף מילים" (karaoke_styles.py) — הבחירה לקליף היא מחרוזת אחת (כמו RRGGBB / PLAIN):
#   MARKER:RRGGBB (צבע התיבה מתוך MARKER_COLORS) · FLOAT (בלי הדגשה) · FLOAT:RRGGBB (צבע הדגשה). בכוונה לא ב-STYLE_TOKENS:
#   "אקראי" לא בוחר אותם — הם נבחרים ביד (ברירת מחדל נשארת הטורקיז).
import karaoke_styles as KS   # noqa: E402  (הצבעים והגדרות הסגנונות במקום אחד)

MARKER_COLORS, FLOAT_EMPH_COLORS = KS.MARKER_COLORS, KS.FLOAT_EMPH_COLORS
# 1/11: הסגנונות שאפשר להשבית מהאקראי (styles_off) — המפתח = מה ש-parse_choice מחזיר
STYLE_KEYS = {"karaoke": "קריוקי (צבע המילה)", "plain": "ללא צבע", "marker": "מרקר", "float": "ריחוף מילים", "box": "קופסה"}


def parse_choice(choice):
    """הבחירה לקליף → (סגנון, צבע או None): karaoke/plain/marker/float. לא תקין → (None, None)."""
    c = str(choice or "").strip().upper()
    if c == "PLAIN":
        return "plain", None
    if re.fullmatch(r"[0-9A-F]{6}", c):
        return "karaoke", c
    # 30/10 (בקשתו): כל צבע hex תקין — הרשימות (marker_palette / float_palette) הן רק מה שמוצע בבורר, ואפשר לשנות/להוסיף/להסיר
    if c == "MARKER":
        return "marker", KS.MARKER_DEFAULT
    if re.fullmatch(r"MARKER:[0-9A-F]{6}", c):
        return "marker", c[7:]
    if c == "FLOAT":
        return "float", None
    if re.fullmatch(r"FLOAT:[0-9A-F]{6}", c):
        return "float", c[6:]
    if c == "BOX":                                  # 31/10 (כרטיס 24): "קופסה" — הצבע = צבע המילה הנאמרת (ברירת מחדל טורקיז)
        return "box", KS.BOX_HILITE_DEFAULT
    if re.fullmatch(r"BOX:[0-9A-F]{6}", c):
        return "box", c[4:]
    return None, None


def valid_choice(choice):
    return parse_choice(choice)[0] is not None


def choice_name(choice):
    """השם בעברית לדוח ולדף."""
    st, rgb = parse_choice(choice)
    if st == "plain":
        return STYLE_NAMES["PLAIN"]
    if st == "marker":
        return "מרקר — " + MARKER_COLORS.get(rgb, "#" + rgb)
    if st == "box":
        return "קופסה — מילה ב" + KS.BOX_COLORS.get(rgb, "#" + rgb)
    if st == "float":
        return "ריחוף מילים" + (" + הדגשה ב" + FLOAT_EMPH_COLORS.get(rgb, "#" + rgb) if rgb else "")
    return "בצבע #" + (rgb or "")
# צלילי ההתראה (נוצרים בדף ב-WebAudio — בלי קבצים מבחוץ). "chime" = הצליל שהיה עד 22/10
NOTIF_SOUNDS = ("chime", "bell", "drop", "marimba", "soft", "twinkle", "harp")

GENERIC_SUBSCRIBE = "🔔 הירשמו לערוץ ולחצו על הפעמון כדי לקבל התראה על כל שיעור חדש"

DEFAULTS = {
    # מוזיקה
    "music_on": True,
    "music_level": 0,          # dB מעל/מתחת לרמות של היום (מתחת לדיבור -13 / הפסקה -9 / הפסקה ארוכה -3)
    "smart_music": True,       # 22/10: אחרי שכל המנגינות שבסבב נשמעו — ❤ נבחרות פי 3 (השאר פחות, אף פעם לא אפס)
    # סמלים — שתי פינות (21/10/2026, בקשתו). השמאלי שומר את שמות ההגדרות של הלוגו היחיד
    # מפעם, כך שמה שכבר כיוון (קובץ, הילה, כבוי) עובר אליו כמו שהוא — בלי שום המרה.
    "logo_on": True,           # שמאל
    "logo_path": "",           # ריק = הלוגו הרגיל (SHORTS_LOGO)
    "logo_glow": 100,          # גודל ההילה הלבנה באחוזים מהיום; 0 = בלי הילה
    "logo2_on": False,         # ימין — כבוי עד שיפעיל
    "logo2_path": "",          # ריק = הלוגו הרגיל
    "logo2_glow": 100,
    # כתוביות
    "sub_color": "random",     # random / teal / yellow / purple / green / plain (ללא צבע, 28/10) / custom:RRGGBB
    "custom_colors": [],
    "marker_opacity": KS.MARKER_OPACITY_DEFAULT,   # 30/10: שקיפות תיבת המרקר, 0–100 (100 = מלא; 94 = כמו שאושר בדוגמה)
    # 31/10 (כרטיס 23, בקשתו): לכל צבע רק שני מצבים — פעיל (בבחירה ביד וגם ב-🎲) או מושבת (מוסתר משניהם, נשמר עם
    # הקוד שלו, לחיצה מחזירה). הרשימה = בחירות שלמות: RRGGBB (קריוקי) / PLAIN / MARKER:RRGGBB / FLOAT / FLOAT:RRGGBB —
    # כך כל סגנון והרשימה שלו נפרדים. מחליף את random_off (רק מהאקראי) ואת marker_off (רק מהבורר) — עוברים לכאן ב-_read
    "colors_off": [],
    # 1/11: סגנון שלם מושבת מ-🎲 האקראי (karaoke/plain/marker/float/box). רק האקראי — בחירה ביד של כל סגנון נשארת. ריק = כמו תמיד
    "styles_off": [],
    # 30/10 (בקשתו): הרשימות ניתנות לעריכה — להוסיף, לשנות, להסיר. ברירת המחדל = מה שאושר (karaoke_styles)
    "marker_palette": list(KS.MARKER_COLORS),
    "float_palette": list(KS.FLOAT_EMPH_COLORS),
    # 31/10 (כרטיס 24): צל הריחוף — ברירת המחדל = המראה שהיה (צל קשיח קל, 50%, גודל 3); ערך אחר = צל רך
    "float_shadow": True, "float_shadow_opacity": KS.FLOAT_SHADOW_DEFAULT[1], "float_shadow_size": KS.FLOAT_SHADOW_DEFAULT[2],
    # "קופסה": צבע התיבה (שחור) ושקיפותה (60%); box_palette = צבעי המילה הנאמרת שמוצעים בבורר (כמו float_palette)
    "box_color": KS.BOX_COLOR_DEFAULT, "box_opacity": KS.BOX_OPACITY_DEFAULT, "box_palette": list(KS.BOX_COLORS),
    "marker_text": {},         # {RRGGBB: "dark"|"light"} — עקיפה ידנית של צבע הטקסט על התיבה (אחרת אוטומטי לפי ניגודיות)
    # 6/11 — 🎬 הוק: 1–3 שניות חזקות בהתחלה, הבזק לבן, ואז השורט (כולל אותו רגע שוב). דולק מראש; בכל קליף אפשר לבטל
    "hook_on": True,
    "hook_sfx": True,          # צליל הבזק עדין
    "emph_default": False,     # 22/10 (כרטיס 15): "🔠 הגדלת מילים" דולק מראש בקליפים חדשים (כבוי = כמו תמיד)
    # 22/10 (כרטיס 14) — זרימה
    "skip_text_check": False,  # אחרי ההכנה — ישר לטיוטה עם הטקסט של התוכנה; מתקנים אחר כך ליד הסרטון הצרוב
    "auto_burn": False,        # 28/10: "אוטומטי עד הצריבה" — Gemini בוחר, ובלי עצירה להצעות ולטקסט: טיוטות צרובות (לא נשמר לבד)
    # 28/10 — "העורך החכם": אחרי התמלול, Gemini שומע את הקליפים ומכריע בין שתי האוזניים (make_short_editor.py)
    "smart_editor": True,      # כבוי = כמו קודם: [א / ב] לכל מחלוקת, ובלי הכרעה — האוזן הראשונה
    "editor_window_min": 3,    # דקות לחכות לשיעור נוסף שייפתח, כדי לשלוח יחד (בקשה אחת). 0 = לא לחכות אף פעם
    "editor_cap_min": 20,      # הכי הרבה שמחכים לשיעורים שבדרך, ואז שולחים מה שמוכן
    "glossary_asr_hint": True,  # המילים מהמילון האישי גם כרמז לתמלול (אוזן 1)
    # 28/10 (בקשתו): לכל שלב שמשתמש ב-Gemini — "key" = ישירות דרך המפתח (ברירת המחדל) / "chat" = תמיד "העתק לצ'אט"
    # (חוסך בקשות חינמיות ביום עמוס). בכל מקרה: מפתח חסר / חסום / מכסה — השלב עובר ל"העתק לצ'אט", אף פעם לא תקוע.
    "gm_pick": "key",          # בחירת קטעים משיעור
    "gm_rank": "key",          # פלייליסט גדול — דירוג השיעורים (שלב א')
    "gm_playlist": "key",      # פלייליסט — הצעות קטעים
    "gm_editor": "key",        # העורך החכם
    "gm_alts": "key",          # "🔍 חפש הצעות אחרות"
    "gemini_recent_fail_min": 15,   # 4.1.1: אחרי עומס/אין-תשובה של Gemini — כמה דקות העורך החכם לא מופעל לבד (0 = כבוי)
    "editor_timeout_sec": 240,      # 4.1.1: כמה שניות מחכים לתשובה של העורך לפני שמוותרים (היה 15 דקות)
    "gemini_margin": 2,       # עוצרים לבד X בקשות לפני הגבול היומי (0 = רק כש-Google עצמו עוצר)
    "share_auto_rebuild": False,   # לבנות מחדש את קובץ השיתוף אחרי כל עדכון של התוכנה (אף פעם לא בזמן עבודה)
    "notif_sound": "chime",    # הצליל של ההתראה (🔊 בסרגל העליון מדליק/מכבה)
    # מצלמה
    "camera_check": True,      # בדיקת מיסגור אחרי כל בנייה
    # 28/10 (כרטיס 22): רב שיוצא מהקרופ — "offer" = הכרטיס מראה אזהרה + "בנה שוב במצלמה זריזה" (ברירת המחדל,
    # הוא רואה לפני/אחרי ומחליט) · "auto" = ההכנה בונה לבד במצלמה זריזה כשהמדידה מראה שהיא טובה יותר
    "exit_fix": "offer",
    "camera_default": "default",   # המצלמה לקליפים חדשים: default רגילה / smooth חלקה / zippy זריזה
    # גיבוי
    "drive_on": True,
    # כללי עריכה — כרגע אזהרות; בשלב הבא (בחירה אוטומטית) — הוראות
    "ideal_min": 30, "ideal_max": 45, "max_len": 60,
    "short_min": 10, "short_max": 20,
    "max_long": 2,             # עד כמה שורטס לשיעור בדרך כלל
    "min_short_for_extra": 1,  # כמה קליפים קצרים צריך כדי לפתוח עוד
    "max_with_short": 3,       # ואז עד כמה
    "playlist_picks": 1,       # כמה קטעים מכל שיעור כשסורקים פלייליסט
    # בחירה אוטומטית (שלב 2) — המפתח עצמו לא כאן אלא ב-config.env (600)
    "gemini_model": "gemini-flash-latest",   # 🚨 לא מוחלף לבד כשהמכסה נגמרת — רק הוא משנה
    "chat_chunk_chars": 60000,               # גודל הדבקה לצ'אט חינמי (תווים)
    "gemini_chunk_chars": 200000,            # כמה טקסט בבקשה אחת ל-Gemini בפלייליסט
    "chat_code_chars": 150000,               # 27/10: גודל הבלוק ל-Claude בצ'אט ("עבודה עם צ'אט") — כמה קוד נכנס
    # 21/10 — דילוגים פנימיים ותמלול מדויק לבחירה
    "auto_skips": True,        # בחירה אוטומטית מציעה קטע מכמה חלקים (דילוג על גמגום/חזרה/צדדי); כבוי = רצף אחד
    "modal_all_lessons": True,   # פלייליסט: כל שיעור מתומלל ב-Modal (turbo, אודיו בלבד, כ-5 סנט) ובוחרים ממנו
    "modal_missing": True,       # שיעור בלי כתוביות מתומלל לבד ב-Modal (תקף כשהקודם כבוי)
    # 22/10: תקרה ליום במקום אישור לכל בקשה (בקשתו). מחליפה את modal_confirm_usd — ערך ישן עובר לכאן לבד (_read)
    "modal_day_cap": 1.0,        # עד כמה דולרים ביום ב-Modal בלי לשאול; רק עבודה שתעבור את זה שואלת. 0 = תמיד לשאול
    "asr_engine": "modal",       # modal (מומלץ) · cpu = תמלול במחשב — רק כגיבוי (אין חשבון Modal / נגמר הקרדיט / מי ששיתפו איתו)
    # 21/10 (כרטיס 11) — פלייליסט גדול בשני שלבים, ופריסת הלשוניות
    "playlist_mode": "auto",     # auto = "קטע מכל שיעור" עד playlist_auto_max שיעורים, מעל זה "רק החזקים" · each · strong
    "playlist_auto_max": 15,     # עד כמה שיעורים בפלייליסט "קטע מכל שיעור" (מעל זה — שני שלבים)
    "playlist_top_n": 3,         # שלב ב: כמה מהשיעורים החזקים מסומנים מראש לעבודה מדויקת
    "tab_layout": "rows",        # rows = לשוניות בשורות (כמו תמיד) · rail = מסילה אופקית אחת עם חצים
    # 16/11 (גרסה 3.4) — 📝 תיאור ותגיות. עד היום הקישורים של בית אל, שם הישיבה ומשפט ההרשמה היו כתובים בתוך הקוד,
    # וכל מי שקיבל את התוכנה פרסם את הקישורים שלו. עכשיו ברירת המחדל ריקה/כללית; הערכים של הבעלים בקובץ ההגדרות שלו
    # (שלא נכנס לחבילת השיתוף).
    "footer_lines": "",          # שורות קבועות בסוף כל תיאור (קישורים לאתר וכו'); ריק = בלי
    "org_name": "",              # שם הישיבה / הערוץ: בשורת הסדרה, כתגית, ובהנחיות ל-Gemini; ריק = בלי
    "subscribe_text": GENERIC_SUBSCRIBE,   # משפט ההרשמה מתחת לקישור לשיעור המלא; ריק = בלי שורת הרשמה
    "fixed_tags": "שיעור תורה",  # תגיות שנוספות לכל שורט (מופרדות בפסיקים). הרב והסדרה מתווספים לבד
    # 16/11 (גרסה 4.0) — תצוגה פשוטה + "🧭 צעדים ראשונים". התצוגה רק מסתירה; שום הגדרה לא משתנה בגללה.
    # ברירת המחדל כאן = התקנה חדשה (מקבל): פשוט, והמסך נפתח פעם אחת. קובץ הגדרות *קיים* בלי view_mode = התקנה
    # מלפני 4.0 (הבעלים) → מתקדם ו"כבר ראה" (ראו _read). ההתקנה מחבילה כותבת "simple" במפורש (make_short_share).
    "view_mode": "simple",       # simple = 🙂 פשוט · advanced = 🛠️ מתקדם (הכול גלוי, כמו עד 4.0)
    "first_steps_seen": False,   # המסך "🧭 צעדים ראשונים" נפתח לבד רק כשזה False — ומיד נהיה True
    "profile_from": "",          # שם הפרופיל שהגיע עם החבילה (נכתב בהתקנה, להודעה "הפרטים האלה הגיעו מוכנים")
}
# "אפס הכול" לא נוגע בזהות של הערוץ (תיאור ותגיות) — רק ↺ ליד כל אחת מהן
IDENTITY_KEYS = ("footer_lines", "org_name", "subscribe_text", "fixed_tags")
# 4.0: גם לא בתצוגה ובמסך הפתיחה — "אפס הכול" של מתקדם לא אמור להעביר אותו לפשוט או לפתוח שוב את הצעדים הראשונים
VIEW_KEYS = ("view_mode", "first_steps_seen", "profile_from")


def _read():
    try:
        d = json.loads(PATH.read_text(encoding="utf-8"))
        d = d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}
    vals = d.get("values")
    if isinstance(vals, dict) and "modal_confirm_usd" in vals:
        # 22/10: "אישור מעל $X לבקשה" הפך ל"תקרה ליום" — הסכום שהוא בחר עובר כמו שהוא (נשמר בכתיבה הבאה)
        old = vals.pop("modal_confirm_usd")
        if "modal_day_cap" not in vals:
            try:
                vals["modal_day_cap"] = max(0.0, min(30.0, float(old)))
            except (TypeError, ValueError):
                pass
    if isinstance(vals, dict):
        migrate_off(vals)
        if "view_mode" not in vals:
            # 4.0: קובץ שנכתב לפני 4.0 (אצל הבעלים, או מקבל ותיק בלי התקנה חדשה) — הכול נשאר כמו שהיה:
            # מתקדם, ובלי מסך פתיחה. נשמר בכתיבה הבאה (ensure_view() בפתיחת השרת).
            vals["view_mode"] = "advanced"
            vals.setdefault("first_steps_seen", True)
    elif d:
        d["values"] = {"view_mode": "advanced", "first_steps_seen": True}
    if isinstance(d.get("undo"), dict) and isinstance(d["undo"].get("values"), dict):
        migrate_off(d["undo"]["values"])
    return d


def migrate_off(vals):
    """31/10 (כרטיס 23): random_off ("לא באקראי") ו-marker_off ("לא בבורר") → colors_off ("מושבת" — לא בשניהם).
    מה שהוא השבית עד היום נשאר מושבת (נשמר בכתיבה הבאה)."""
    if "random_off" not in vals and "marker_off" not in vals:
        return
    off = list(vals.get("colors_off") or [])
    for c in list(vals.pop("random_off", None) or []) + ["MARKER:" + str(x) for x in (vals.pop("marker_off", None) or [])]:
        c = str(c).strip().lstrip("#").upper()
        if valid_choice(c) and c not in off:
            off.append(c)
    vals["colors_off"] = off


HISTORY_DAYS = 14


def history_dir():
    return Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts")) / "settings_history"


def snapshot_history(label=""):
    """4.1.2: עותק יומי מתגלגל של קובץ ההגדרות (14 ימים) — איפוס לא רצוי תמיד ניתן לשחזור. נלקח לפני הכתיבה הראשונה
    של כל יום (ו-label="pre-reset" לפני איפוס). לעולם לא מפיל את הכתיבה עצמה. במצב בדיקה לא כותב לתיקייה האמיתית."""
    try:
        if not PATH.exists():
            return
        hd = history_dir()
        if GUARD.test_mode() and GUARD.inside_real(hd):
            return
        hd.mkdir(parents=True, exist_ok=True)
        day = time.strftime("%Y-%m-%d")
        dst = hd / ("%s%s.json" % (day, "-" + label if label else ""))
        if label:
            dst = hd / ("%s-%s-%s.json" % (day, time.strftime("%H%M%S"), label))
        elif dst.exists():
            return
        dst.write_bytes(PATH.read_bytes())
        keep = sorted(hd.glob("*.json"))
        cutoff = time.time() - HISTORY_DAYS * 86400
        for f in keep:
            if f.stat().st_mtime < cutoff:
                f.unlink()
    except Exception:
        pass


def _write(d):
    # 4.0: קובץ חדש (התקנה חדשה) נכתב עם התצוגה שלו — אחרת הקריאה הבאה הייתה חושבת שזה קובץ מלפני 4.0.
    # קובץ ישן כבר קיבל "advanced" בקריאה (_read), כך שכאן זה חל רק על קובץ שנוצר עכשיו.
    d.setdefault("values", {}).setdefault("view_mode", DEFAULTS["view_mode"])
    GUARD.assert_not_real_config(PATH)           # 4.1.2: בדיקה לא כותבת בהגדרות האמיתיות שלו
    snapshot_history()
    PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(PATH)


def load():
    """הערכים בתוקף: ברירת מחדל + מה שהוא שינה."""
    v = dict(DEFAULTS)
    v.update({k: x for k, x in _read().get("values", {}).items() if k in DEFAULTS})
    return v


def ensure_view():
    """4.0, בפתיחת השרת: קובץ הגדרות מלפני 4.0 מקבל בכתב "advanced" + "כבר ראה" (בקריאה זה כבר כך — כאן רק
    נשמר, כדי ששום כלי אחר לא יפרש אותו אחרת). קובץ שלא קיים — לא נוצר (התקנה חדשה נשארת "פשוט")."""
    try:
        raw = json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if isinstance(raw, dict) and isinstance(raw.get("values"), dict) and "view_mode" in raw["values"]:
        return False
    _write(_read())
    return True


UNDO_TTL = 24 * 3600


def _undo_expired(u):
    try:
        t = time.mktime(time.strptime(str(u.get("at", "")), "%Y-%m-%d %H:%M"))
    except (ValueError, OverflowError):
        return True                          # בלי תאריך תקין אי אפשר לדעת מתי — לא משאירים לנצח
    return time.time() - t > UNDO_TTL


def dismiss_undo():
    """"✕ הסתר": מסלק את הפס בלי להחזיר כלום — ההגדרות נשארות כמו שהן עכשיו."""
    d = _read()
    if d.pop("undo", None) is not None:
        _write(d)
    return state()


def state():
    """לחלון: הערכים, ברירות המחדל, ומה אפשר לבטל."""
    d = _read()
    # 4.6.3: רשומת ה"בטל" של איפוס לא נשארת לנצח (פס "אופס…" שחוזר בכל כניסה להגדרות, גם שבועות אחרי): פגה אחרי UNDO_TTL
    u = d.get("undo")
    if isinstance(u, dict) and _undo_expired(u):
        d.pop("undo", None)
        _write(d)
    return {"values": load(), "defaults": DEFAULTS, "default_colors": DEFAULT_COLORS,
            "style_tokens": STYLE_TOKENS, "style_names": STYLE_NAMES, "undo": d.get("undo"),
            "marker_colors": MARKER_COLORS, "float_colors": FLOAT_EMPH_COLORS, "box_colors": KS.BOX_COLORS,
            "float_max_wps": KS.FLOAT_MAX_WPS, "style_lists": style_lists(), "style_keys": STYLE_KEYS}


def clean(key, val):
    """בודק ומיישר ערך לפני שמירה — ערך שבור לא נכנס לקובץ."""
    dv = DEFAULTS[key]
    if isinstance(dv, bool):
        return bool(val)
    if isinstance(dv, float):                  # דולרים — עם סנטים
        val = float(val)
        if val != val:                         # NaN
            raise ValueError("מספר לא תקין")
        return round(max(0.0, min(30.0, val)), 2)
    if key == "asr_engine":
        if str(val) not in ("modal", "cpu"):
            raise ValueError("מנוע תמלול לא מוכר")
        return str(val)
    if isinstance(dv, int):
        val = int(round(float(val)))
        # מוזיקה עד +6: מעבר לזה ההפסקות כבר חזקות מהדיבור (-9+6 = -3)
        lim = {"music_level": (-8, 6), "logo_glow": (0, 250), "logo2_glow": (0, 250), "chat_chunk_chars": (8000, 1000000),
               "gemini_chunk_chars": (20000, 3000000), "chat_code_chars": (30000, 1000000),
               "playlist_auto_max": (1, 1000), "playlist_top_n": (1, 100),
               "editor_window_min": (0, 30), "editor_cap_min": (1, 120), "gemini_margin": (0, 50),
               "gemini_recent_fail_min": (0, 240), "editor_timeout_sec": (30, 900),
               "marker_opacity": (0, 100), "float_shadow_opacity": (0, 100), "float_shadow_size": (0, 12),
               "box_opacity": (0, 100)}.get(key, (0, 600))
        return max(lim[0], min(lim[1], val))
    if key.startswith("gm_"):
        if str(val) not in ("key", "chat"):
            raise ValueError("בחירה לא מוכרת (ישירות / העתק לצ'אט)")
        return str(val)
    if key == "playlist_mode":
        if str(val) not in ("auto", "each", "strong"):
            raise ValueError("מצב פלייליסט לא מוכר")
        return str(val)
    if key == "view_mode":
        if str(val) not in ("simple", "advanced"):
            raise ValueError("תצוגה לא מוכרת")
        return str(val)
    if key == "profile_from":
        return " ".join(str(val or "").split())[:60]
    if key == "tab_layout":
        if str(val) not in ("rows", "rail"):
            raise ValueError("פריסת לשוניות לא מוכרת")
        return str(val)
    if key == "sub_color":
        val = str(val)
        if val in ("random",) + tuple(DEFAULT_COLORS) + tuple(STYLE_TOKENS) or re.fullmatch(r"custom:[0-9A-Fa-f]{6}", val):
            return val.upper().replace("CUSTOM:", "custom:") if val.startswith("custom:") else val
        if val.lower() in ("marker", "float", "box") or re.fullmatch(r"(marker|float|box):[0-9A-Fa-f]{6}", val, re.I):
            if valid_choice(val):                       # "marker:10206E" → "MARKER:10206E" (הבחירה עצמה)
                return val.upper()
        raise ValueError("צבע לא מוכר")
    if key == "box_color":
        c = str(val).strip().lstrip("#").upper()
        if not re.fullmatch(r"[0-9A-F]{6}", c):
            raise ValueError("צבע לא תקין")
        return c
    if key in ("marker_palette", "float_palette", "box_palette"):
        out = []
        for c in val or []:
            c = str(c).strip().lstrip("#").upper()
            if re.fullmatch(r"[0-9A-F]{6}", c) and c not in out:
                out.append(c)
        if not out:
            raise ValueError("צריך להשאיר לפחות צבע אחד ברשימה")
        return out[:24]
    if key == "marker_text":
        return {str(k).lstrip("#").upper(): v for k, v in (val or {}).items()
                if re.fullmatch(r"#?[0-9A-Fa-f]{6}", str(k)) and v in ("dark", "light")}
    if key == "exit_fix":
        if str(val) not in ("offer", "auto"):
            raise ValueError("אפשרות לא מוכרת")
        return str(val)
    if key == "camera_default":
        if str(val) not in ("default", "smooth", "zippy"):
            raise ValueError("מצלמה לא מוכרת")
        return str(val)
    if key == "notif_sound":
        if str(val) not in NOTIF_SOUNDS:
            raise ValueError("צליל לא מוכר")
        return str(val)
    if key == "custom_colors":
        out = []
        for c in val or []:
            c = str(c).strip().lstrip("#").upper()
            if re.fullmatch(r"[0-9A-F]{6}", c) and c not in out:
                out.append(c)
        return out[:60]
    if key == "colors_off":
        out = []
        for c in val or []:
            c = str(c).strip().lstrip("#").upper()
            if valid_choice(c) and c != "MARKER" and c not in out:
                out.append(c)
        return out[:200]
    if key == "styles_off":
        return [k for k in STYLE_KEYS if k in {str(x).strip().lower() for x in (val or [])}]
    if key == "gemini_model":
        val = str(val or "").strip().removeprefix("models/")
        if not re.fullmatch(r"[a-z0-9][a-z0-9.\-]{2,60}", val):
            raise ValueError("שם מודל לא תקין (למשל gemini-flash-latest)")
        return val
    if key == "footer_lines":                   # כמה שורות; שורות ריקות באמצע נשמרות (רווח בין קבוצות קישורים)
        lines = [l.rstrip() for l in str(val or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")]
        return "\n".join(lines).strip("\n")[:3000]
    if key in ("org_name", "subscribe_text"):   # שורה אחת
        return " ".join(str(val or "").split())[:80 if key == "org_name" else 300]
    if key == "fixed_tags":
        out = []
        for t in str(val or "").replace("،", ",").split(","):
            t = " ".join(t.split()).lstrip("#")
            if t and t not in out:
                out.append(t)
        return ", ".join(out[:30])
    if key in ("logo_path", "logo2_path"):
        val = str(val or "")
        if val and not os.path.isfile(val):
            raise ValueError("קובץ הלוגו לא נמצא")
        return val
    return val


def channel_phrase(s=None):
    """3.4: איך ההנחיות ל-Gemini קוראות לערוץ. עם שם ישיבה: "ערוץ השיעורים של <שם>" (הנוסח של תמיד);
    בלי: "ערוץ של שיעורי תורה"."""
    org = ((s or load()).get("org_name") or "").strip()
    return "ערוץ השיעורים של " + org if org else "ערוץ של שיעורי תורה"


def logos(s=None):
    """[(נתיב, "left"/"right", הילה)] לצריבה — רק הפינות הפעילות שיש להן קובץ.
    קובץ שהועלה ונעלם → הלוגו הרגיל, לא בלי לוגו (כמו תמיד)."""
    s = s or load()
    out = []
    for on, path, glow, side in (("logo_on", "logo_path", "logo_glow", "left"),
                                 ("logo2_on", "logo2_path", "logo2_glow", "right")):
        if not s[on]:
            continue
        p = s[path] if s[path] and os.path.exists(s[path]) else os.environ.get("SHORTS_LOGO", "")
        if p and os.path.exists(p):
            out.append((p, side, s[glow] / 100.0))
    return out


def update(changes):
    d = _read()
    vals = d.setdefault("values", {})
    for k, x in changes.items():
        if k in DEFAULTS:
            vals[k] = clean(k, x)
    _write(d)
    return state()


def reset(keys=None):
    """keys=None → הכול. שומר את הערכים הקודמים של מה שאופס, ל"בטל"."""
    d = _read()
    vals = d.setdefault("values", {})
    cur = load()
    every = not keys
    keys = [k for k in (keys or [k for k in DEFAULTS if k not in IDENTITY_KEYS + VIEW_KEYS]) if k in DEFAULTS]
    snapshot_history("pre-reset")
    # 4.1.2: איפוס שני לפני "בטל" לא מוחק את מה שבטל היה מחזיר: מפתח שעכשיו על ברירת המחדל (אין מה לאבד בו)
    # שומר את הערך מהאיפוס הקודם
    prev = (d.get("undo") or {}).get("values") or {}
    d["undo"] = {"values": {k: (prev[k] if k in prev and cur[k] == DEFAULTS[k] else cur[k]) for k in keys},
                 "all": every or bool((d.get("undo") or {}).get("all")), "at": time.strftime("%Y-%m-%d %H:%M")}
    for k in keys:
        vals.pop(k, None)
    _write(d)
    return state()


def undo():
    d = _read()
    u = d.pop("undo", None)
    if u:
        vals = d.setdefault("values", {})
        for k, x in u["values"].items():
            if k in DEFAULTS:
                if x == DEFAULTS[k]:
                    vals.pop(k, None)
                else:
                    vals[k] = x
    _write(d)
    return state()


# ─────────────── מה ההגדרות אומרות לשאר הקוד ───────────────

CLIP_DB = (-8, 6)          # 22/10: עוצמת המוזיקה בקליף אחד, יחסית לרמה הכללית


def music_levels(s=None, clip_db=0):
    """הארגומנטים ל-mix_music.py: הרמות של היום + ההזזה שהוא בחר + ההזזה של הקליף הזה (22/10).
    התקרה הכוללת +6 — מעבר לזה ההפסקות כבר חזקות מהדיבור."""
    s = s or load()
    off = max(-16, min(6, s["music_level"] + max(CLIP_DB[0], min(CLIP_DB[1], int(clip_db or 0)))))
    return ["--under", str(-13 + off), "--pause", str(-9 + off), "--swell", str(min(0, -3 + off))]


def sub_color(s=None):
    """(שם, RGB) לצריבה, או ("random", None) — אז karaoke_ass בוחר מתוך ארבעת הצבעים."""
    s = s or load()
    c = s["sub_color"]
    if c.startswith("custom:"):
        return "custom", c.split(":", 1)[1]
    if c in DEFAULT_COLORS:
        return c, DEFAULT_COLORS[c]
    if c in STYLE_TOKENS:
        return c, STYLE_TOKENS[c]
    if valid_choice(c) and parse_choice(c)[0] in ("marker", "float", "box"):
        return c.split(":")[0].lower(), c.upper()
    return "random", None


def float_shadow(s=None):
    """(פעיל, שקיפות, גודל) של צל הריחוף כשהוא שונה מברירת המחדל; None = המראה המקורי (כך שום דבר לא משתנה)."""
    s = s or load()
    t = (bool(s["float_shadow"]), int(s["float_shadow_opacity"]), int(s["float_shadow_size"]))
    return None if t == KS.FLOAT_SHADOW_DEFAULT else t


def random_pool(s=None):
    """(הצבעים ש"אקראי" בוחר מהם, נפל_לטורקיז). 22/10 (כרטיס 14): צבע עם "השבת מהאקראי" לא נבחר לבד;
    השבית את כולם — טורקיז (הצבע המקורי), והסיום אומר את זה."""
    s = s or load()
    g = random_groups(s)
    pool = [x for grp in g.values() for x in grp]
    return (pool, False) if pool else ([DEFAULT_COLORS["teal"]], True)


def random_groups(s=None):
    """30/10 (הצעתו): "אקראי" בוחר בין שלושת הסגנונות — קריוקי (הצבעים + "ללא צבע") / מרקר / ריחוף — ובתוך הסגנון בין הצבעים
    שלו. {סגנון: [בחירות]} בלי הריקים. צבע מושבת (colors_off, כרטיס 23) לא נכלל."""
    s = s or load()
    off, soff = set(s.get("colors_off") or []), set(s.get("styles_off") or [])
    ok = lambda x: x not in off and parse_choice(x)[0] not in soff        # noqa: E731  (סגנון שלם מושבת = כל הבחירות שלו)
    return {k: [x for x in v if ok(x)] for k, v in style_lists(s).items() if [x for x in v if ok(x)]}


def style_lists(s=None):
    """31/10 (כרטיס 23): שלוש הרשימות הנפרדות, כל האפשרויות (פעילות ומושבתות) — קריוקי (ארבעת הצבעים, הצבעים
    שהוסיף לקריוקי, "ללא צבע") / מרקר (צבעי התיבה) / ריחוף ("בלי הדגשה" + צבעי ההדגשה). צבע קריוקי שהוסיף נכנס
    עכשיו גם ל-🎲 (פעיל = בשניהם; עד היום הוא נכנס רק ל-🎲 שבדף)."""
    s = s or load()
    kara = []
    for x in list(DEFAULT_COLORS.values()) + [c.upper() for c in s.get("custom_colors") or []] + list(STYLE_TOKENS.values()):
        if x not in kara:
            kara.append(x)
    return {"karaoke": kara, "marker": ["MARKER:" + c for c in s["marker_palette"]],
            "float": ["FLOAT"] + ["FLOAT:" + c for c in s["float_palette"]],
            "box": ["BOX:" + c for c in s["box_palette"]]}


def random_pick(h, groups):
    """בחירה דטרמיניסטית לפי hash (נתיב ה-ass): קודם סגנון (שווה בין הסגנונות), אחר כך צבע בתוכו."""
    names = sorted(groups)
    grp = groups[names[h % len(names)]]
    return grp[(h // len(names)) % len(grp)]


def em_pool(s=None):
    """"ללא צבע" (28/10): המילים המסומנות נצבעות באחד הצבעים שבאקראי (רק צבעים אמיתיים); אין כאלה — טורקיז."""
    pool = [x for x in random_pool(s)[0] if re.fullmatch(r"[0-9A-F]{6}", x)]
    return pool or [DEFAULT_COLORS["teal"]]


def rule_warnings(seconds, s=None):
    """אזהרות על אורך וכמות — לפי הכללים שלו. seconds = אורך כל קליף בשניות.
    🚨 אלה אזהרות, לא חסימה: את הקטעים הוא בוחר בעצמו, והבחירה שלו."""
    s = s or load()
    out = []
    for n, sec in enumerate(seconds, 1):
        name = "קליף %d" % n
        if sec > s["max_len"]:
            out.append("%s: %.0f שניות — מעל %d" % (name, sec, s["max_len"]))
        elif sec > s["ideal_max"]:
            out.append("%s: %.0f שניות — מומלץ להשתדל ל-%d–%d (רק השתדלות; קטע שלם וטוב עדיף)"
                       % (name, sec, s["ideal_min"], s["ideal_max"]))
        elif sec < s["short_min"]:
            out.append("%s: %.0f שניות — קצר מאוד (פחות מ-%d)" % (name, sec, s["short_min"]))
    shorts = sum(1 for x in seconds if s["short_min"] <= x <= s["short_max"])
    n = len(seconds)
    if n > s["max_long"]:
        if shorts < s["min_short_for_extra"]:
            out.append("%d קליפים מאותו שיעור — הכלל הוא עד %d, ועד %d רק אם לפחות %d מהם קצר (%d–%d שניות)"
                       % (n, s["max_long"], s["max_with_short"], s["min_short_for_extra"],
                          s["short_min"], s["short_max"]))
        elif n > s["max_with_short"]:
            out.append("%d קליפים מאותו שיעור — גם עם קליף קצר, עד %d" % (n, s["max_with_short"]))
    return out


def rules_text(s=None):
    """הכללים כטקסט — לשלב הבא (בחירה אוטומטית), שיקבל אותם כהוראות."""
    s = s or load()
    return ("אורך: להשתדל ל-%(ideal_min)d–%(ideal_max)d שניות, לא יותר מ-%(max_len)d. "
            "קליף קצר (%(short_min)d–%(short_max)d שניות) מותר כשהוא עומד בפני עצמו. "
            "עד %(max_long)d שורטס לשיעור; אם לפחות %(min_short_for_extra)d מהם קצר — עד %(max_with_short)d. "
            "בסריקת פלייליסט: %(playlist_picks)d קטעים מכל שיעור." % s)
