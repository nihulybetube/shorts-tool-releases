# -*- coding: utf-8 -*-
"""hook_clip.py — "הוק" פותח לשורט (6/11/2026, אושר על ידו אחרי דוגמאות).

הרעיון: 1–3 השניות החזקות ביותר של השורט מושמעות בהתחלה (עם כתוביות), אחריהן הבזק לבן, ואז השורט כרגיל —
כולל אותו רגע שוב במקומו הטבעי. שימוש במנוע של הסקיל ושל תוכנת "יצירת שורטס" כאחד.

מה שהוא קבע בדוגמאות (5/11):
  · מעבר לבן בלבד (בלי זהב, בלי זום), עם צליל הבזק עדין — לא מכסה את הדיבור.
  · ההוק נשמע עד הסוף: אחרי המילה האחרונה זנב טבעי (TAIL) שיורד בעדינות, ורק אז ההבזק עולה (GAP) ומגיע ללבן מלא ברגע החיתוך.
  · מוזיקה מההתחלה (המיקס הרגיל על כל הסרטון).
  · ברירת מחדל דולק, אפשר לבטל בקליף.

הפונקציות עובדות על מילים מיושרות (words = [{"word","start","end"}] לפי ציר הזמן של הסרטון הנקי), כך שהשכבות
האחרות — כתוביות (karaoke_ass), פריסת שורות, הגדלת מילים — מקבלות רשימת מילים רגילה, שבה ההוק מוקדם בהתחלה.

שימוש מהשורה (בדיקה / סקיל):
  shorts.sh py hook_clip.py build <clean.mp4> <words.json> <out_dir> [--text="..." | --i0=N --i1=M]
      → <out_dir>/hooked_clean.mp4 + hooked_words.json (+ מדפיס את ההוק שנבחר).  ואז karaoke_ass על hooked_words.json
        עם --duration=<total> וצריבה כרגיל על hooked_clean.mp4.
  shorts.sh py hook_clip.py suggest <words.json>      → הצעה היוריסטית (בלי מודל)
"""
import json
import os
import re
import subprocess
import sys

import numpy as np

FF = os.environ.get("FFMPEG", "ffmpeg")
SR = 16000
TAIL = 0.14           # זנב טבעי אחרי המילה האחרונה של ההוק, יורד בעדינות (5/11: "עדיין לא שומעים את המילה האחרונה")
LEAD_MAX = 0.25       # כמה שקט לפני המילה הראשונה של ההוק מותר לחפש בו נקודת חיתוך (לא כל ההפסקה)
TAIL_SEARCH_MAX = 0.30  # כמה אחרי סוף המילה האחרונה מותר לחפש נקודת חיתוך שקטה (לא כל ההפסקה)
GAP = 0.10           # ההבזק עולה אחרי הזנב ומגיע ללבן מלא ברגע החיתוך
FADE_OUT = 0.32       # דעיכת ההבזק אל השורט
FLASH_RGB = "0xFFF7E6"      # הלבן החם שאישר
SFX_DB = -22          # עוצמת צליל ההבזק מעל הקול (עדין)
MIN_S, MAX_S = 1.2, 3.6     # אורך מומלץ להוק (שניות דיבור)
NEG = {"לא", "אסור", "דווקא", "אבל", "מוזר", "משונה", "אף", "פעם", "כולם", "אין", "בלי", "רק", "מה"}


def _n(w):
    return re.sub(r"[^א-תA-Za-z0-9]", "", w or "")


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", stdin=subprocess.DEVNULL)
    if r.returncode:
        raise RuntimeError("hook_clip: ffmpeg נכשל:\n" + "\n".join((r.stderr or "").strip().splitlines()[-12:]))
    return r


def duration(p):
    return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)]).stdout)


# ───────────── בחירת ההוק ─────────────

def find_span(words, text):
    """(i0, i1) של הרצף ב-words שמתאים לטקסט (מנורמל, בלי פיסוק) — מדויק; אחרת ההתאמה הטובה ביותר שמכסה ≥85%."""
    import difflib
    want = [_n(x) for x in re.split(r"\s+", text.strip()) if _n(x)]
    live = [(i, _n(w["word"])) for i, w in enumerate(words) if _n(w["word"])]
    have = [n for _, n in live]
    if not want or not have:
        return None
    L = len(want)
    for k in range(0, len(have) - L + 1):
        if have[k:k + L] == want:
            return live[k][0], live[k + L - 1][0]
    best, bk = 0.0, None
    for k in range(0, max(1, len(have) - L + 1)):
        r = difflib.SequenceMatcher(None, want, have[k:k + L], autojunk=False).ratio()
        if r > best:
            best, bk = r, k
    if bk is not None and best >= 0.85:
        return live[bk][0], live[min(bk + L, len(have)) - 1][0]
    return None


def span_ok(words, i0, i1):
    if i0 is None or i1 is None or not (0 <= i0 <= i1 < len(words)):
        return False
    return True


def span_seconds(words, i0, i1):
    return words[i1]["end"] - words[i0]["start"]


def suggest(words, min_start=5.0):
    """הצעה היוריסטית בלי מודל: משפט שלם של 4–11 מילים בן 1.3–3.5 שניות, לא מהתחלת השורט. שאלה/קריאה/ניגוד מנצחים.
    מחזיר {"i0","i1","text","src":"auto"} או None. הוא רק *הצעה* — העורך בכל קליף יכול לשנות."""
    sents, cur = [], []
    for i, w in enumerate(words):
        if not w["word"].strip():
            continue
        cur.append(i)
        if re.search(r"[.?!]$", w["word"].strip()):
            sents.append(cur); cur = []
    if cur:
        sents.append(cur)
    best, bs = None, 0.0
    for idx in sents:
        a, b = idx[0], idx[-1]
        sec = words[b]["end"] - words[a]["start"]
        n = len(idx)
        if words[a]["start"] < min_start or not (MIN_S + 0.1 <= sec <= MAX_S - 0.1) or not (4 <= n <= 11):
            continue
        txt = [_n(words[i]["word"]) for i in idx]
        score = 0.0
        last = words[b]["word"].strip()
        score += 3 if last.endswith("?") else 2 if last.endswith("!") else 0
        score += 0.6 * len(NEG & set(txt))
        score -= 2 * sum(1 for x, y in zip(txt, txt[1:]) if x == y)          # גמגום
        score -= sum(1 for p, q in zip(idx, idx[1:]) if words[q]["start"] - words[p]["end"] > 0.6)
        score += min(1.0, words[a]["start"] / 60.0)
        if score > bs:
            best, bs = idx, score
    if best is None or bs < 0.6:
        return None
    return {"i0": best[0], "i1": best[-1], "src": "auto",
            "text": " ".join(words[i]["word"].strip() for i in best)}


def resolve(hook, words):
    """הוק שמור ({"text","i0","i1"}) → (i0, i1) לפי המילים של עכשיו; None אם הטקסט כבר לא שם."""
    if not hook:
        return None
    if hook.get("text"):
        sp = find_span(words, hook["text"])
        if sp:
            return sp
    return None


# ───────────── נקודות חיתוך מדודות ─────────────

def load_audio(path, sr=SR):
    r = subprocess.run([FF, "-v", "error", "-i", str(path), "-f", "f32le", "-ac", "1", "-ar", str(sr), "-"],
                       capture_output=True, stdin=subprocess.DEVNULL)
    return np.frombuffer(r.stdout, dtype=np.float32).astype(np.float64)


def quiet_point(audio, a, b, sr=SR):
    """הנקודה השקטה ביותר (חלון 20ms) בין a ל-b — חיתוך על שקט נמדד."""
    w = int(0.02 * sr)
    i0, i1 = int(a * sr), max(int(b * sr) - w, int(a * sr) + 1)
    best, bi = 9.0, i0
    for i in range(i0, i1, w // 2):
        r = float(np.sqrt(np.mean(audio[i:i + w] ** 2))) if i + w <= len(audio) else 9.0
        if r < best:
            best, bi = r, i
    return (bi + w / 2) / sr


def plan(words, i0, i1, audio):
    """{"h0","h1","Th","Tc","i0","i1","text"} — h0/h1 על שקט נמדד; Th = אורך ההוק כולל הזנב; Tc = רגע החיתוך (אחרי ההבזק העולה)."""
    # 10/11: החיפוש מוגבל סביב המילים. בלי הגבלה, כשאחרי ההוק יש הפסקה ארוכה (למשל שנייה) הנקודה "השקטה ביותר"
    # נבחרה באמצע ההפסקה — ההוק קיבל ~1 שנייה של שקט עם הרב עומד (נמדד בבדיקה על פרלמן: 2.47s במקום ~1.6s).
    prev_end = words[i0 - 1]["end"] if i0 > 0 else max(0.0, words[i0]["start"] - 0.2)
    lo = max(prev_end, words[i0]["start"] - LEAD_MAX) if i0 > 0 else None
    h0 = quiet_point(audio, lo, words[i0]["start"] + 0.01) if i0 > 0 else words[i0]["start"] - 0.05
    nxt = words[i1 + 1]["start"] if i1 + 1 < len(words) else words[i1]["end"] + 0.3
    h1 = quiet_point(audio, words[i1]["end"] - 0.01,
                     max(min(nxt, words[i1]["end"] + TAIL_SEARCH_MAX), words[i1]["end"] + 0.05))
    h0 = max(0.0, h0)
    Th = h1 - h0 + TAIL
    return {"h0": h0, "h1": h1, "Th": Th, "Tc": Th + GAP, "i0": i0, "i1": i1,
            "text": " ".join(w["word"].strip() for w in words[i0:i1 + 1])}


# ───────────── מילים וציר זמן משולבים ─────────────

def combine(words, pl):
    """(מילים משולבות, K) — K מילות ההוק בהתחלה (זמנים מ-0), אחריהן כל מילות השורט מוסטות ב-Tc.
    המילה האחרונה של ההוק מקבלת נקודה אם אין לה פיסוק — כדי שהכתובית תיגמר שם (פיסוק בלבד, לא מילה)."""
    i0, i1 = pl["i0"], pl["i1"]
    out = []
    for k, w in enumerate(words[i0:i1 + 1]):
        w = dict(w)
        w["start"] = round(w["start"] - pl["h0"], 3)
        w["end"] = round(w["end"] - pl["h0"], 3)
        if k == i1 - i0 and w["word"].strip() and w["word"].strip()[-1] not in ".?!,":
            w["word"] = w["word"] + "."
        out.append(w)
    K = len(out)
    for w in words:
        w = dict(w)
        w["start"] = round(w["start"] + pl["Tc"], 3)
        w["end"] = round(w["end"] + pl["Tc"], 3)
        out.append(w)
    return out, K


def shift_idx(idx, K):
    """הגדלת מילים (קבוצת אינדקסים) → אחרי שהוקדמו K מילות הוק."""
    return None if idx is None else {i + K for i in idx}


def shift_layout(chunks, K, comb_words):
    """פריסת שורות שנקבעה על המילים הרגילות → על המשולבות: חלוקה אוטומטית להוק, והשאר מוסט ב-K.
    chunks=None (אוטומטי) נשאר None — karaoke_ass מחלק הכול לבד."""
    if chunks is None:
        return None
    import make_short_layout as LAY
    head = LAY.auto_chunks(comb_words, list(range(K)))
    return head + [[[i + K for i in r] for r in ch] for ch in chunks]


def trim_ass(ass_path, Tc):
    """כתובית שהתחילה בהוק לא נשארת מעל הסצנה הבאה: נחתכת ברגע החיתוך."""
    def sec(s):
        h, m, x = s.split(":")
        return int(h) * 3600 + int(m) * 60 + float(x)

    def fmt(v):
        cs = int(round(v * 100))
        return "%d:%02d:%02d.%02d" % (cs // 360000, cs // 6000 % 60, cs // 100 % 60, cs % 100)
    out = []
    with open(ass_path, encoding="utf-8-sig") as f:
        for ln in f.read().splitlines(True):
            if ln.startswith("Dialogue:"):
                p = ln.split(",", 9)
                if sec(p[1]) < Tc - 0.05 and sec(p[2]) > Tc - 0.02:
                    p[2] = fmt(Tc - 0.02)
                    ln = ",".join(p)
            out.append(ln)
    with open(ass_path, "w", encoding="utf-8-sig") as f:
        f.write("".join(out))


# ───────────── הווידאו עצמו ─────────────

def sfx_wav(path, d=0.30):
    """שוש-נחיתה עדין: רעש ורוד מסונן שעולה ונגמר בפגיעה רכה בנקודת ההבזק."""
    run([FF, "-y", "-f", "lavfi", "-i", "anoisesrc=d=%s:c=pink:r=48000:a=0.6" % d,
         "-af", "highpass=f=500,lowpass=f=7000,afade=t=in:st=0:d=%.2f,afade=t=out:st=%.2f:d=%.2f,volume=0.8,"
                "aformat=channel_layouts=stereo" % (d * 0.8, d * 0.8, d * 0.2), str(path)])


def build_video(clean, pl, out, sfx_path=None, threads=2, preset="veryfast", crf=14):
    """ההוק + הבזק לבן + הסרטון כולו, בקובץ אחד (אותו קידוד כמו הסרטון הנקי: 1080x1920, 30fps).
    🚨 הקלט נפתח פעמיים (-i clean -i clean): trim ו-concat על אותו קלט היו שומרים את כל הסרטון בזיכרון."""
    Th, Tc, h0, h1 = pl["Th"], pl["Tc"], pl["h0"], pl["h1"]
    total = Tc + duration(clean)
    sfx_chain = ""
    ins = [FF, "-y", "-threads", str(threads), "-i", str(clean), "-i", str(clean)]
    if sfx_path:
        ins += ["-i", str(sfx_path)]
        d = int(Th * 1000)                      # מתחיל כשההוק נגמר — לא מכסה את הקול שלו
        sfx_chain = ("[2:a]adelay=%d|%d,volume=%ddB[sx];[ac][sx]amix=inputs=2:normalize=0:duration=first[a]" % (d, d, SFX_DB))
    else:
        sfx_chain = "[ac]anull[a]"
    fc = ("[0:v]trim=start=%.3f:end=%.3f,setpts=PTS-STARTPTS[va];"
          "[1:v]setpts=PTS-STARTPTS[vb];[va][vb]concat=n=2:v=1:a=0[vc];[vc]fps=30[vz];"
          "color=c=%s:s=1080x1920:r=30:d=%.3f,format=rgba,"
          "fade=t=in:st=%.3f:d=%.3f:alpha=1,fade=t=out:st=%.3f:d=%.3f:alpha=1[fl];"
          "[vz][fl]overlay=format=auto:shortest=1,format=yuv420p[v];"
          "[0:a]atrim=start=%.3f:end=%.3f,asetpts=PTS-STARTPTS,afade=t=in:d=0.012,"
          "afade=t=out:st=%.3f:d=%.3f:curve=hsin,apad=whole_dur=%.3f[aa];"
          "[1:a]asetpts=PTS-STARTPTS[ab];[aa][ab]concat=n=2:v=0:a=1[ac];%s"
          % (h0, h1 + TAIL + GAP, FLASH_RGB, total, Th, GAP, Tc + 0.04, FADE_OUT,
             h0, h1 + TAIL, Th - TAIL, TAIL, Tc, sfx_chain))
    tmp = str(out) + ".part.mp4"
    run(ins + ["-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-crf", str(crf),
               "-preset", preset, "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "192k", tmp])
    os.replace(tmp, out)
    return total


def prepare(clean, words, hook, out_dir, tag="hook", sfx=True):
    """הכול במכה אחת: מקבל סרטון נקי + מילים + הוק ({"i0","i1"} או {"text"}), כותב
    <out_dir>/<tag>_clean.mp4 ו-<tag>_words.json ומחזיר {"plan","total","clean","words_json","K","comb"}.
    None אם ההוק לא נמצא / לא תקין."""
    i0i1 = resolve(hook, words) if hook.get("text") else ((hook.get("i0"), hook.get("i1")) if span_ok(words, hook.get("i0"), hook.get("i1")) else None)
    if not i0i1:
        return None
    audio = load_audio(clean)
    pl = plan(words, i0i1[0], i0i1[1], audio)
    comb, K = combine(words, pl)
    os.makedirs(out_dir, exist_ok=True)
    sx = None
    if sfx:
        sx = os.path.join(out_dir, "%s_sfx.wav" % tag)
        sfx_wav(sx)
    cl = os.path.join(out_dir, "%s_clean.mp4" % tag)
    total = build_video(clean, pl, cl, sx)
    wj = os.path.join(out_dir, "%s_words.json" % tag)
    with open(wj, "w", encoding="utf-8") as f:
        json.dump({"words": comb}, f, ensure_ascii=False)
    return {"plan": pl, "total": total, "clean": cl, "words_json": wj, "K": K, "comb": comb}


def _main(argv):
    if len(argv) >= 2 and argv[0] == "suggest":
        ws = json.load(open(argv[1], encoding="utf-8"))["words"]
        print(json.dumps(suggest(ws), ensure_ascii=False))
        return 0
    if len(argv) == 3 and argv[0] == "trim":          # trim <ass> <Tc> — אחרי karaoke_ass על hook_words.json
        trim_ass(argv[1], float(argv[2]))
        return 0
    if len(argv) >= 4 and argv[0] == "build":
        clean, wj, out = argv[1:4]
        opts = dict(a[2:].split("=", 1) for a in argv[4:] if a.startswith("--") and "=" in a)
        ws = json.load(open(wj, encoding="utf-8"))["words"]
        hook = {"text": opts["text"]} if "text" in opts else (
            {"i0": int(opts["i0"]), "i1": int(opts["i1"])} if "i0" in opts else suggest(ws))
        if not hook:
            print("אין הוק מתאים — אפשר לציין --text=... או --i0=N --i1=M")
            return 2
        r = prepare(clean, ws, hook, out)
        if not r:
            print("ההוק לא נמצא במילים")
            return 2
        print(json.dumps({"hook": r["plan"]["text"], "h0": round(r["plan"]["h0"], 2), "h1": round(r["plan"]["h1"], 2),
                          "Tc": round(r["plan"]["Tc"], 2), "total": round(r["total"], 2), "K": r["K"]}, ensure_ascii=False))
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
