# -*- coding: utf-8 -*-
"""תאימות אחורה — חתימה ישנה, מנוע חדש.

    python transcribe.py <input_media> <output_words_json> [--lang he]

הנתיב האמיתי הוא `asr.py`, שבוחר בין תמלול מקומי לענן לפי מה שנבחר
ב-`shorts.sh setup`. הקובץ הזה קיים כדי ששלב שקורא ל-`transcribe.py`
ימשיך לעבוד.

⚠️ לקליפ בודד זה בזבזני — כל קריאה טוענת את המודל מחדש. לאצווה:
`shorts.sh py asr.py run --media a.mp4 b.mp4 --out-dir <dir>`.
"""
import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def transcribe(input_path, output_json_path, language="he"):
    inp = Path(input_path).resolve()
    out = Path(output_json_path).resolve()
    with tempfile.TemporaryDirectory() as td:
        r = subprocess.run([sys.executable, str(HERE / "asr.py"), "run",
                            "--media", str(inp), "--out-dir", td])
        if r.returncode != 0:
            raise SystemExit("התמלול נכשל (קוד %d)" % r.returncode)
        hits = sorted(Path(td).glob("*_words.json"))
        if not hits:
            raise SystemExit("לא חזר קובץ תמלול")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(hits[0].read_bytes())
    return len(json.loads(out.read_text(encoding="utf-8")).get("words", []))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--lang", default="he")
    a = ap.parse_args()
    print("%d words -> %s" % (transcribe(a.input, a.output, a.lang), a.output))
