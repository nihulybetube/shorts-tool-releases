# -*- coding: utf-8 -*-
"""4.4 — הצעות, רעיונות ותקלות מהמשתמשים אל המנהל (הבעלים), עם התראה לטלפון דרך ntfy.

מה זה ולמה ככה (הבקשה של הבעלים, 19/11/2026):
  • "העתק לצ'אט" נשאר כמו שהוא. כאן הוסף: (א) "📨 שלח למנהל רעיון / תקלה" — טקסט חופשי + פרטי מערכת מנוקים;
    (ב) "📤 תיקנתי לעצמי — להציע למנהל" — תיקון קוד (patch) + תיאור + גרסה + תוצאת בדיקה מהירה.
  • שום דבר לא נשלח מעצמו: בונים *טיוטה*, מציגים תצוגה מקדימה של בדיוק מה שיישלח (כולל גודל), ורק לחיצת אישור שולחת.
    האישור קשור ל-digest של הטיוטה — אם משהו השתנה מאז התצוגה, לא שולחים.
  • הובלה = ntfy (נושא = סוד באמצעות אקראיות: ≥192 ביט). המגבלות שנבדקו (ntfy.sh, 11/2026): גוף הודעה עד 4096 בתים; הודעות נשמרות
    ~12 שעות בשרת; קבצים מצורפים עד 15MB אבל נמחקים אחרי 3 שעות; 60 בקשות בפרץ ואז אחת ל-5 שניות. לכן *לא* משתמשים בקבצים מצורפים:
    ההצעה מכווצת (zlib+base64) ונשלחת כמה הודעות קצרות ("חלקים", כל אחת ≤3200 תווים) לנושא ה-inbox, ובסוף הודעת התראה קצרה
    לנושא ה-alert (זה מה שהטלפון של הבעלים מנוי עליו). תקרה: 64 אלף תווים בקו.
  • פער זמן: השרת שומר רק 12 שעות. לכן התוכנה של הבעלים שולפת תיבה לדיסק מקומי בזמן שהיא רצה (ובהפעלה — תופסת מה שנשאר), ושולח
    שלא קיבל אישור שולח שוב (פעם ב-12 שעות, עד 6 ימים) — והבעלים עונה על כפילות בסטטוס הנוכחי. כך לא אובדים.
  • 4.5.x (הצפנה וחתימה — הנושאים נשלחים בכל גרסה, ולכן כל אחד יכול לקרוא אותם):
    כל הצעה מוצפנת למפתח ציבורי של הבעלים (X25519 + HKDF-SHA256 + ChaCha20-Poly1305, "sealed box") — רק הבעלים קורא אותה
    (טקסט, שם, פרטי מערכת, patch, נושא התשובה). תשובות/סטטוסים של הבעלים חתומים במפתח Ed25519 של הבעלים; השולח מאמת מול
    המפתח הציבורי שבקובץ הערוץ (שנכנס רק לגרסה החתומה) ודוחה כל דבר לא חתום. המפתחות הפרטיים: קובץ 0600 בתיקיית ההגדרות של
    הבעלים (proposals_owner.key), מחוץ לריפו ולכל חבילה. מה שנשאר: הנושאים עצמם ציבוריים ⇒ ספאם אפשרי (מכסה כללית + סיבוב).
  • ערוץ התשובה: לכל הצעה נושא תשובה אקראי (בתוך ההצעה המוצפנת). הבעלים מפרסם שם סטטוס (התקבל / התקבלה לגרסה הבאה /
    נדחתה / תשובה) חתום; השולח מאמת ומתעלם מכל מה שלא חתום (או ישן יותר מהסטטוס שכבר הוא מכיר).
  • כל מה שמתקבל = *נתונים לא מהימנים*: תקרות גודל, הסרת תווי בקרה, אף פעם לא מריצים, אף פעם לא מציגים כ-HTML, ו-patch אף פעם
    לא מוחל אוטומטית — הבדיקה שלו רק בארגז חול (bubblewrap, בלי רשת, בלי תיקיית ההגדרות) על עותק זמני.
  • ספאם: מכסה לשולח (5 ביום) ולכל שולח אצל הבעלים (10 ביום, 100 סך הכול); הבעלים יכול להחליף נושאים בגרסה חתומה (סיבוב).
    הערה כנה: הנושא נשלח בתוך הקוד לכל המקבלים — מי שהתקין יכול למצוא אותו. לכן ההגנה היא מכסות + סינון + סיבוב, לא סודיות מוחלטת.
  • הערוץ (assets/proposals_channel.json) נכנס רק לגרסאות החתומות ולחבילות החדשות (הבעלים יוצר אותו אצלו, מחוץ לריפו);
    בלי הקובץ — התכונה כבויה ("עוד לא פעיל אצל המנהל"). חבילות שנבנו לפני 4.4 לא יכולות להתעדכן — כמו תמיד לפני 4.3.

שימוש (לדיבוג):  shorts.sh py make_short_proposals.py status|setup-channel|rotate|fetch|sync
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
REPO = HERE.parent.parent
CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts"))
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
PDIR = DATA / "proposals"
OUTBOX, INBOX, DRAFTS, PARTIALS = PDIR / "outbox", PDIR / "inbox", PDIR / "drafts", PDIR / "partials"
CFG_FILE = CONFIG / "proposals.json"                 # השולח: שרת, שם/יצירת קשר, מזהה אקראי
OWNER_FILE = CONFIG / "proposals_owner.json"          # הבעלים בלבד: הערוץ הנוכחי + היסטוריה + מצביעי שליפה
CHANNEL_ASSET = "assets/proposals_channel.json"
DEFAULT_SERVER = "https://ntfy.sh"

OWNER_KEY = CONFIG / "proposals_owner.key"            # הבעלים בלבד: המפתחות הפרטיים (פענוח הצעות + חתימת תשובות), 0600
SENT_LOG = PDIR / "sent_log.json"                     # השולח: מונה שליחות ל-24 שעות (לא נמחק ב"הסר מהרשימה")


def _set_dirs(config, data, repo=None):
    """לבדיקות: מחליף את התיקיות (מדמה "התקנה" אחרת — שולח / בעלים — באותו תהליך)."""
    global CONFIG, DATA, PDIR, OUTBOX, INBOX, DRAFTS, PARTIALS, CFG_FILE, OWNER_FILE, REPO, OWNER_KEY, SENT_LOG
    CONFIG, DATA = Path(config), Path(data)
    PDIR = DATA / "proposals"
    OUTBOX, INBOX, DRAFTS, PARTIALS = PDIR / "outbox", PDIR / "inbox", PDIR / "drafts", PDIR / "partials"
    CFG_FILE, OWNER_FILE, OWNER_KEY = CONFIG / "proposals.json", CONFIG / "proposals_owner.json", CONFIG / "proposals_owner.key"
    SENT_LOG = PDIR / "sent_log.json"
    if repo is not None:
        REPO = Path(repo)


PFX, RPFX = "YSP2", "YSR2"           # 4.5.x: v2 = מוצפן לבעלים + תשובות חתומות. v1 (גלוי, HMAC) לא נתמך — מעולם לא פורסם
CAPS = {"text": 4000, "diag": 12000, "patch": 120000, "name": 80, "selftest": 1500, "wire": 64000, "chunk": 3200,
        "files": 40, "msg_body": 4096, "resp": 2 << 20, "parts": 25, "decomp": 600000, "line": 16384, "pages": 20}
SENDER_DAY, OWNER_TOTAL_DAY = 5, 100
OWNER_SENDER_DAY = OWNER_TOTAL_DAY   # 4.5.x (A3): אין יותר מכסה "לשולח" — מזהה השולח נבחר ע"י השולח, ותוקף היה חוסם בו משתמש אחר
REPUBLISH_EVERY = 6 * 3600           # 4.5.x (A3): כפילות של הצעה מוכרת → פרסום חוזר של הסטטוס לכל היותר פעם ב-6 שעות
RESEND_EVERY, RESEND_MAX = 12 * 3600, 12
KINDS = {"idea": "רעיון / שינוי שאני רוצה", "bug": "תקלה / באג", "patch": "תיקון שעשיתי לעצמי"}
FINAL = ("accepted", "rejected", "handled")
RANK = {"queued": 0, "sent": 1, "received": 2, "replied": 3, "accepted": 4, "rejected": 4, "handled": 4}
STATUS_HE = {"queued": "ממתינה לשליחה (אין חיבור — תישלח כשיהיה)", "sent": "נשלחה", "received": "התקבלה אצל המנהל",
             "replied": "המנהל השיב", "accepted": "התקבלה לגרסה הבאה", "rejected": "נדחתה", "handled": "טופלה"}
# קבצים שהצעה לא יכולה לגעת בהם: סודות, ושלמות העדכונים (מפתח חתימה, ערוץ ההצעות, מספר גרסה)
PROTECTED = {"assets/release_source.json", CHANNEL_ASSET, "VERSION"}
SECRET_NAMES = re.compile(r"(config\.env|cookies?|\.enc$|id_rsa|id_ed25519|\.pem$|\.key$|token|rclone|\.netrc|credentials|\.ssh/|\.aws/)", re.I)
RISK_WORDS = re.compile(r"\b(socket|urllib|requests|http\.client|subprocess|os\.system|os\.popen|eval|exec|__import__|ctypes|"
                        r"shutil\.rmtree|os\.remove|os\.unlink|rm\s+-rf|curl|wget|config\.env|cookies|\.ssh|rclone|chmod|"
                        r"base64\.b64decode|pickle|marshal)\b|/\.config/|~/\.config|SHORTS_CONFIG_DIR")


class ProposalError(Exception):
    """הודעה בעברית פשוטה — אפשר להציג כמו שהיא."""


def _guard(path):
    try:
        import make_short_guard as G
        G.assert_not_real_config(path)
    except ImportError:
        pass


def _test_mode():
    try:
        import make_short_guard as G
        return G.test_mode()
    except ImportError:
        return False


# ─────────────────────────── ניקוי טקסט ───────────────────────────
_CTRL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def clean(text, cap, keep_nl=True):
    """הסרת תווי בקרה ותווי כיוון נסתרים (סכנת הטעיה בתצוגה), נרמול שורות, חיתוך לתקרה. תמיד str."""
    if not isinstance(text, str):
        text = "" if text is None else str(text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _CTRL.sub("", text)
    if not keep_nl:
        text = " ".join(text.split())
    return text[:cap]


_WIN_SKIP = {"public", "default", "default user", "all users", "desktop.ini", "wsiaccount", "defaultapppool"}


def _win_users():
    """4.5.x (A6): שם המשתמש בווינדוס שונה בדרך כלל משם המשתמש בלינוקס (WSL) — נגזר מ-/mnt/c/Users ומ-%USERNAME%."""
    names = set()
    for k in ("USERNAME", "MAKE_SHORT_WIN_USERS"):
        for n in (os.environ.get(k) or "").split(","):
            if n.strip():
                names.add(n.strip())
    try:
        for d in os.listdir("/mnt/c/Users"):
            if d.lower() not in _WIN_SKIP and not d.startswith("."):
                names.add(d)
    except OSError:
        pass
    return sorted((n for n in names if len(n) >= 3), key=len, reverse=True)


def privacy(text):
    """נתיבים אישיים: תיקיית הבית ושמות המשתמש (לינוקס וגם ווינדוס) בנתיבים → סימן כללי. (HEALTH.scrub עושה את הסודות.)"""
    if not isinstance(text, str) or not text:
        return text or ""
    try:
        import getpass
        user = getpass.getuser()
    except Exception:
        user = ""
    home = os.path.expanduser("~")
    if home and len(home) > 3:
        text = text.replace(home, "~")
    for u in ([user] if user and len(user) >= 3 else []) + _win_users():
        text = re.sub(r"(?i)([\\/](?:home|users)[\\/]+)" + re.escape(u) + r"(?![A-Za-z0-9_.\-])", r"\1<user>", text)
        text = re.sub(r"(?i)(wsl[.$a-z]*[\\/]+[A-Za-z0-9_.\-]+[\\/]+home[\\/]+)" + re.escape(u) + r"(?![A-Za-z0-9_.\-])", r"\1<user>", text)
    return text


def scrub_text(text):
    """HEALTH.scrub (מפתחות/טוקנים/מחרוזות ארוכות) + CHAT.guard (ערכי מפתחות אמיתיים) + נתיבים אישיים."""
    text = privacy(text)
    try:
        import make_short_health as H
        text = H.scrub(text)
    except ImportError:
        pass
    try:
        import make_short_chat as C
        text, _n = C.guard(text)
    except ImportError:
        pass
    return text


# ─────────────────────────── patch: בדיקת בטיחות ───────────────────────────
_HDR = re.compile(r"^diff --git a/(.+?) b/(.+)$")


def _path_ok(p):
    """נתיב יחסי בתוך הריפו, בלי הברחות, בלי .git, בלי שמות של סודות ובלי קבצים מוגנים."""
    if not p or p.startswith(("/", "~")) or "\\" in p or "\x00" in p or ":" in p.split("/")[0]:
        return "נתיב לא יחסי"
    parts = p.split("/")
    if any(x in ("", ".", "..") for x in parts):
        return "נתיב עם .. או סימן חשוד"
    if parts[0] == ".git" or ".git" in parts:
        return "נוגע בתיקיית git"
    if p in PROTECTED:
        return "קובץ מוגן (%s)" % p
    if SECRET_NAMES.search(p):
        return "שם שנראה כמו קובץ סודות"
    return ""


def validate_patch(text):
    """→ {"ok", "problems":[...], "files":[...], "risks":[...], "added", "removed"}. לא מריץ כלום; רק קורא טקסט."""
    problems, files, risks = [], [], []
    added = removed = 0
    if not text.strip():
        return {"ok": False, "problems": ["ה-patch ריק"], "files": [], "risks": [], "added": 0, "removed": 0}
    if len(text) > CAPS["patch"]:
        problems.append("ה-patch גדול מדי (%d תווים; מותר %d)" % (len(text), CAPS["patch"]))
    if "\x00" in text:
        problems.append("יש בו תו NUL")
    for ln in text.split("\n"):
        m = _HDR.match(ln)
        if m:
            for p in {m.group(1), m.group(2)}:
                why = _path_ok(p)
                if why:
                    problems.append("%s — %s" % (p[:80], why))
            files.append(m.group(2))
        elif ln.startswith(("--- ", "+++ ")):
            p = ln[4:].split("\t")[0].strip()
            if p != "/dev/null":
                if p.startswith(("a/", "b/")):
                    p = p[2:]
                why = _path_ok(p)
                if why:
                    problems.append("%s — %s" % (p[:80], why))
            if ln.startswith("+++ "):
                pass
        elif re.match(r"^(rename|copy) (from|to) ", ln):
            why = _path_ok(ln.split(" ", 2)[2].strip())
            if why:
                problems.append("%s — %s" % (ln[:80], why))
        elif re.match(r"^(new|old|deleted) (file )?mode (120000|160000)", ln) or re.match(r"^index .* 120000$", ln):
            problems.append("קישור סימבולי או תת-מודול")
        elif ln.startswith(("GIT binary patch", "Binary files")):
            problems.append("קובץ בינארי (לא מקבלים)")
        elif ln.startswith("+") and not ln.startswith("+++"):
            added += 1
            if RISK_WORDS.search(ln):
                risks.append(ln[1:].strip()[:100])
        elif ln.startswith("-") and not ln.startswith("---"):
            removed += 1
    if len(set(files)) > CAPS["files"]:
        problems.append("יותר מדי קבצים (%d)" % len(set(files)))
    if not files:
        problems.append("לא נמצאה אף כותרת diff")
    return {"ok": not problems, "problems": problems[:12], "files": sorted(set(files)), "risks": risks[:15],
            "added": added, "removed": removed}


def local_patch(repo=None):
    """שינויי הקוד המקומיים של המשתמש מול הגרסה הרשמית שהותקנה (rel-X). בלי קבצים מוגנים. → (patch_text, הסבר)."""
    repo = Path(repo or REPO)
    if not (repo / ".git").exists():
        return "", "ההתקנה הזאת בלי git — אין עם מה להשוות."
    try:
        import make_short_release as R
        v = R.installed_version(repo)
        tags = R.rel_tags(repo)
    except Exception:
        v, tags = "", []
    base = ("rel-%s" % v) if v and ("rel-%s" % v) in tags else ""
    if not base:
        r = subprocess.run(["git", "-C", str(repo), "tag", "--list", "v%s" % v], capture_output=True, text=True)
        base = ("v%s" % v) if v and r.stdout.strip() else ""
    if not base:
        return "", "לא נמצאה נקודת השוואה לגרסה הרשמית (%s)." % (v or "?")
    ex = ["--", "."] + [":(exclude)%s" % p for p in sorted(PROTECTED)]
    r = subprocess.run(["git", "-C", str(repo), "diff", "--no-color", "--no-ext-diff", base] + ex, capture_output=True, timeout=60)
    raw = r.stdout
    if b"GIT binary patch" in raw or b"Binary files" in raw:
        return "", "בין השינויים יש קובץ בינארי — שולחים רק שינויי טקסט."
    text = raw.decode("utf-8", "replace")
    if not text.strip():
        return "", "אין שינויים מקומיים מול הגרסה הרשמית."
    return text, ""


# ─────────────────────────── הגדרות ערוץ ───────────────────────────
def _read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {} if default is None else default


def _write_json(path, obj, mode=None):
    path = Path(path)
    _guard(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp%d" % os.getpid())
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    if mode:
        os.chmod(tmp, mode)
    os.replace(tmp, path)


def new_topic():
    return "ysp-" + secrets.token_urlsafe(24)            # 192 ביט; אותיות/ספרות/_/- ≤ 64 תווים (מגבלת ntfy)


def _valid_topic(t):
    return isinstance(t, str) and re.fullmatch(r"[A-Za-z0-9_\-]{20,64}", t) is not None


def _valid_server(s, allow_loop=None):
    if not isinstance(s, str):
        return False
    u = urllib.parse.urlparse(s)
    loop = u.hostname in ("127.0.0.1", "::1", "localhost")
    if allow_loop is None:
        allow_loop = True
    if u.scheme == "https" and u.hostname and not loop:
        return not _test_mode() or os.environ.get("MAKE_SHORT_ALLOW_REAL_NTFY") == "1"   # בבדיקות — לעולם לא לשרת אמיתי
    return u.scheme in ("http", "https") and loop and allow_loop


# ─────────────────────────── 4.5.x (A1): הצפנה לבעלים + חתימת תשובות ───────────────────────────
SEAL_INFO = b"yeshiva-shorts proposal seal v2"


def _b64u(b):
    return base64.urlsafe_b64encode(b).decode("ascii")


def _unb64(s, n=None):
    try:
        b = base64.b64decode(str(s).encode("ascii"), altchars=b"-_", validate=False) if s else b""
    except Exception:
        return None
    return b if (n is None or len(b) == n) else None


def _crypto():
    try:
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        from cryptography.hazmat.primitives import hashes, serialization
        return X25519PrivateKey, X25519PublicKey, Ed25519PrivateKey, ChaCha20Poly1305, HKDF, hashes, serialization
    except ImportError:
        raise ProposalError("חסר רכיב ההצפנה (cryptography) בהתקנה — אי אפשר לשלוח/לקרוא הצעות. להריץ שוב את ההתקנה.")


def _raw(pub):
    S = _crypto()[6]
    return pub.public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)


def seal(data, pub32):
    """מצפין לבעלים: מפתח זמני X25519 → סוד משותף → HKDF → ChaCha20-Poly1305. רק בעל המפתח הפרטי פותח."""
    X, XP, _E, CC, HKDF, hashes, _S = _crypto()
    eph = X.generate()
    epub = _raw(eph.public_key())
    shared = eph.exchange(XP.from_public_bytes(pub32))
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=epub + pub32, info=SEAL_INFO).derive(shared)
    nonce = os.urandom(12)
    return epub + nonce + CC(key).encrypt(nonce, data, PFX.encode())


def unseal(blob, priv):
    """→ בתים, או ProposalError (לא מוצפן אלינו / שונה בדרך / מפתח זמני פגום)."""
    X, XP, _E, CC, HKDF, hashes, _S = _crypto()
    if len(blob) < 32 + 12 + 16:
        raise ProposalError("תוכן ההצפנה קצר מדי")
    epub, nonce, ct = blob[:32], blob[32:44], blob[44:]
    try:
        shared = priv.exchange(XP.from_public_bytes(epub))
        key = HKDF(algorithm=hashes.SHA256(), length=32, salt=epub + _raw(priv.public_key()), info=SEAL_INFO).derive(shared)
        return CC(key).decrypt(nonce, ct, PFX.encode())
    except Exception:
        raise ProposalError("ההצעה לא מוצפנת אל המפתח של המנהל (או ששונתה בדרך)")


def _owner_keys(create=False):
    """(X25519 פרטי, Ed25519 פרטי) של הבעלים מקובץ 0600 בתיקיית ההגדרות. create — יוצר אם חסר."""
    X, _XP, E, *_r = _crypto()
    d = _read_json(OWNER_KEY)
    xb, eb = _unb64(d.get("x25519"), 32), _unb64(d.get("ed25519"), 32)
    if xb and eb:
        return X.from_private_bytes(xb), E.from_private_bytes(eb)
    if not create:
        raise ProposalError("אין אצלך מפתח ההצעות (proposals_owner.key) — ליצור ערוץ קודם.")
    S = _crypto()[6]
    xk, ek = X.generate(), E.generate()
    raw = lambda k: k.private_bytes(S.Encoding.Raw, S.PrivateFormat.Raw, S.NoEncryption())   # noqa: E731
    _guard(OWNER_KEY)
    OWNER_KEY.parent.mkdir(parents=True, exist_ok=True)
    tmp = OWNER_KEY.with_name(OWNER_KEY.name + ".tmp%d" % os.getpid())
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)       # 0600 כבר מהיצירה
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(json.dumps({"v": 1, "x25519": _b64u(raw(xk)), "ed25519": _b64u(raw(ek))}))
    os.replace(tmp, OWNER_KEY)
    return xk, ek


def _owner_pubs(create=False):
    xk, ek = _owner_keys(create)
    return _b64u(_raw(xk.public_key())), _b64u(_raw(ek.public_key()))


def _sign_reply(pid, body_b64):
    _xk, ek = _owner_keys()
    return _b64u(ek.sign(("%s|%s|%s" % (RPFX, pid, body_b64)).encode("ascii")))


def _verify_reply(sign_pubs, pid, body_b64, sig_b64):
    import make_short_release as REL                  # אימות Ed25519 בפייתון טהור (אותו קוד שמאמת עדכונים)
    sig = _unb64(sig_b64, 64)
    if not sig:
        return False
    msg = ("%s|%s|%s" % (RPFX, pid, body_b64)).encode("ascii")
    return any(REL.ed25519_verify(pk, msg, sig) for pk in (_unb64(p, 32) for p in sign_pubs) if pk)


def owner_visible():
    """"פרסם עדכון" ו"הצעות ממשתמשים" — רק איפה שיש מפתח חתימה (או מצב בדיקה מפורש)."""
    try:
        import make_short_publish as P
        return bool(P.have_key() or os.environ.get("MAKE_SHORT_PUBLISH_SCREEN") == "1" or P.owner_screens_on())   # 4.6.5: + הכפתור בכספת
    except Exception:
        return False


def load_channel():
    """הערוץ שהתוכנה הזאת שולחת אליו: קובץ הערוץ שבקוד (נכנס בגרסה החתומה) — ורק אם הוא תקין. אצל הבעלים — הקובץ שלו."""
    for src in (_read_json(REPO / CHANNEL_ASSET), (_read_json(OWNER_FILE).get("channel") if owner_visible() else None) or {}):
        if _valid_topic(src.get("inbox")) and _valid_topic(src.get("alert")) and src.get("inbox") != src.get("alert") \
                and _unb64(src.get("enc_pub"), 32) and _unb64(src.get("sign_pub"), 32):     # 4.5.x: בלי מפתחות הבעלים — כבוי
            server = (_read_json(CFG_FILE).get("server") or os.environ.get("SHORTS_NTFY_SERVER") or src.get("server") or DEFAULT_SERVER).rstrip("/")
            if not _valid_server(server):
                return None
            return {"server": server, "inbox": src["inbox"], "alert": src["alert"], "epoch": int(src.get("epoch") or 1),
                    "enc_pub": src["enc_pub"], "sign_pub": src["sign_pub"]}
    return None


def sender_cfg():
    c = _read_json(CFG_FILE)
    if not re.fullmatch(r"[0-9a-f]{16}", str(c.get("sender_id") or "")):
        c["sender_id"] = secrets.token_hex(8)
        _write_json(CFG_FILE, c, 0o600)
    return c


def set_contact(name, server=None):
    c = sender_cfg()
    c["contact"] = clean(name, CAPS["name"], False)
    if server is not None:
        server = server.strip().rstrip("/")
        if server and not _valid_server(server):
            raise ProposalError("כתובת שרת ההתראות לא תקינה (https://… בלבד)")
        c["server"] = server
    _write_json(CFG_FILE, c, 0o600)
    return c


# ─────────────────────────── קידוד קו ───────────────────────────
def _digest(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def encode(payload, enc_pub=None):
    """payload → רשימת הודעות ("חלקים"); כל אחת ≤ 4096 בתים. 4.5.x: מכווץ ואז מוצפן למפתח הבעלים (enc_pub, ברירת מחדל — מהערוץ)."""
    if enc_pub is None:
        enc_pub = (load_channel() or {}).get("enc_pub")
    pub = _unb64(enc_pub, 32)
    if not pub:
        raise ProposalError("אין מפתח הצפנה של המנהל — השליחה לא פעילה.")
    raw = seal(zlib.compress(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8"), 9), pub)
    b = base64.urlsafe_b64encode(raw).decode("ascii")
    if len(b) > CAPS["wire"]:
        raise ProposalError("ההצעה גדולה מדי אחרי כיווץ (%d אלף תווים; מותר %d אלף) — לקצר את התיאור או את התיקון."
                            % (len(b) // 1000, CAPS["wire"] // 1000))
    parts = [b[i:i + CAPS["chunk"]] for i in range(0, len(b), CAPS["chunk"])] or [""]
    h = hashlib.sha256(b.encode()).hexdigest()[:16]
    return ["%s %s %d %d %s %s" % (PFX, payload["pid"], i + 1, len(parts), h, p) for i, p in enumerate(parts)]


_WIRE = re.compile(r"^YSP2 ([0-9a-f]{16}) (\d{1,2}) (\d{1,2}) ([0-9a-f]{16}) ([A-Za-z0-9_=\-]*)$")


def parse_part(msg):
    """הודעת חלק → (pid, i, n, digest, b64) או None. קפדני: כל סטייה = זריקה."""
    if not isinstance(msg, str) or len(msg.encode("utf-8", "replace")) > CAPS["msg_body"]:
        return None
    m = _WIRE.match(msg.strip())
    if not m:
        return None
    pid, i, n, h, b = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4), m.group(5)
    if not (1 <= n <= CAPS["parts"] and 1 <= i <= n) or len(b) > CAPS["chunk"]:
        return None
    return pid, i, n, h, b


def decode(b64):
    """base64 מצטבר → payload מאומת, או ProposalError. רק אצל הבעלים: פענוח במפתח הפרטי, ואז פריסה עם תקרה (נגד פצצת דחיסה)."""
    try:
        blob = base64.urlsafe_b64decode(b64.encode("ascii"))
    except Exception:
        raise ProposalError("תוכן ההצעה פגום")
    raw = unseal(blob, _owner_keys()[0])
    try:
        d = zlib.decompressobj()
        txt = d.decompress(raw, CAPS["decomp"])
        if d.unconsumed_tail:
            raise ProposalError("פצצת דחיסה")
        obj = json.loads(txt.decode("utf-8"))
    except ProposalError:
        raise
    except Exception:
        raise ProposalError("תוכן ההצעה פגום")
    return validate_payload(obj)


def validate_payload(o):
    if not isinstance(o, dict) or o.get("v") != 1:
        raise ProposalError("גרסת פורמט לא מוכרת")
    pid = o.get("pid")
    if not isinstance(pid, str) or not re.fullmatch(r"[0-9a-f]{16}", pid):
        raise ProposalError("מזהה הצעה לא תקין")
    kind = o.get("kind")
    if kind not in KINDS:
        raise ProposalError("סוג הצעה לא מוכר")
    rep = o.get("reply") if isinstance(o.get("reply"), dict) else {}
    if not _valid_topic(rep.get("topic")):
        raise ProposalError("ערוץ תשובה לא תקין")
    sid = str(o.get("sender_id") or "")
    if not re.fullmatch(r"[0-9a-f]{16}", sid):
        raise ProposalError("מזהה שולח לא תקין")
    out = {"v": 1, "pid": pid, "kind": kind, "sender_id": sid, "reply": {"topic": rep["topic"]},
           "ts": int(o.get("ts") or 0) if isinstance(o.get("ts"), (int, float)) else 0,
           "app_version": clean(o.get("app_version"), 20, False), "name": clean(o.get("name"), CAPS["name"], False),
           "text": clean(o.get("text"), CAPS["text"]), "diag": clean(o.get("diag"), CAPS["diag"]),
           "patch": clean(o.get("patch"), CAPS["patch"]), "selftest": clean(o.get("selftest"), CAPS["selftest"]),
           "epoch": int(o.get("epoch") or 0) if isinstance(o.get("epoch"), (int, float)) else 0}
    if not out["text"].strip() and not out["patch"].strip():
        raise ProposalError("הצעה ריקה")
    if kind == "patch" and not out["patch"].strip():
        raise ProposalError("הצעת תיקון בלי patch")
    return out


# ─────────────────────────── רשת (ntfy) ───────────────────────────
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """4.5.x (A7): לא הולכים אחרי הפניה (שרת זדוני/פרוץ יכול להפנות ל-127.0.0.1 או לכתובת פנימית)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProposalError("שרת ההתראות ניסה להפנות לכתובת אחרת — נחסם")


_OPENER = urllib.request.build_opener(_NoRedirect)


def _open(method, url, body=None, headers=None, timeout=20):
    u = urllib.parse.urlparse(url)
    if not _valid_server("%s://%s" % (u.scheme, u.netloc)):
        raise ProposalError("כתובת שרת ההתראות לא מותרת")
    req = urllib.request.Request(url, data=body, method=method, headers=dict(headers or {}))
    return _OPENER.open(req, timeout=timeout)


def _http(method, url, body=None, headers=None, timeout=20):
    with _open(method, url, body, headers, timeout) as r:
        data = r.read(CAPS["resp"] + 1)
    if len(data) > CAPS["resp"]:
        raise ProposalError("תשובת השרת גדולה מדי")
    return data


def publish(server, topic, message, title=None, priority=None, tags=None):
    """ntfy: POST JSON לשורש השרת (תומך ב-UTF-8 בכותרת, בלי בעיות כותרות HTTP)."""
    if len(message.encode("utf-8")) > CAPS["msg_body"]:
        raise ProposalError("הודעה ארוכה מדי לשרת")
    obj = {"topic": topic, "message": message}
    if title:
        obj["title"] = title
    if priority:
        obj["priority"] = priority
    if tags:
        obj["tags"] = tags
    try:
        _http("POST", server.rstrip("/") + "/", json.dumps(obj).encode("utf-8"), {"Content-Type": "application/json"})
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise ProposalError("אין חיבור לשרת ההתראות (%s)" % str(getattr(e, "reason", e))[:80])


def poll_page(server, topics, since="all", max_bytes=None):
    """ntfy: poll=1, נקרא שורה-שורה (4.5.x, A2). → (אירועים לפי הסדר, יש_עוד). הצפה: עוצרים בתקרה ומחזירים "יש עוד" —
    המתקשר מתקדם ל-id האחרון שעובד וממשיך, במקום להיכשל ולהיתקע לתמיד על אותה הצפה."""
    out, more, used = [], False, 0
    cap = max_bytes or CAPS["resp"]
    topics = [t for t in topics if _valid_topic(t)]
    for i in range(0, len(topics), 100):
        url = "%s/%s/json?poll=1&since=%s" % (server.rstrip("/"), ",".join(topics[i:i + 100]), urllib.parse.quote(str(since)))
        try:
            with _open("GET", url) as r:
                while True:
                    ln = r.readline(CAPS["line"] + 1)
                    if not ln:
                        break
                    if len(ln) > CAPS["line"]:                 # שורה ענקית — מדלגים עליה עד סופה
                        while ln and not ln.endswith(b"\n"):
                            ln = r.readline(CAPS["line"] + 1)
                        continue
                    used += len(ln)
                    if used > cap:
                        more = True
                        break
                    try:
                        ev = json.loads(ln.decode("utf-8", "replace"))
                    except ValueError:
                        continue
                    if isinstance(ev, dict) and ev.get("event") == "message" and isinstance(ev.get("message"), str):
                        out.append(ev)
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            raise ProposalError("אין חיבור לשרת ההתראות (%s)" % str(getattr(e, "reason", e))[:80])
        if more:
            break
    return out, more


def poll(server, topics, since="all"):
    """תאימות: רק העמוד הראשון (תשובות לשולח — מעט הודעות לכל הצעה)."""
    return poll_page(server, topics, since)[0]


# ─────────────────────────── השולח: טיוטה, תצוגה מקדימה, שליחה ───────────────────────────
def _version():
    try:
        return (REPO / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def day_count(box=None, now=None):
    """4.5.x (A8): לפי מונה שליחות נפרד (sent_log) — "הסר מהרשימה" לא מאפס את המכסה. (ועוד תיבת היוצא, למקרה של לוג חסר.)"""
    now = now or time.time()
    n = 0
    if box is None or box == OUTBOX:
        log = [t for t in _read_json(SENT_LOG, []) if isinstance(t, (int, float)) and now - t < 86400]
        n = len(log)
    m = sum(1 for f in (box or OUTBOX).glob("*.json") if now - _read_json(f).get("created", 0) < 86400) if (box or OUTBOX).exists() else 0
    return max(n, m)


def _log_sent(now=None):
    now = now or time.time()
    log = [t for t in _read_json(SENT_LOG, []) if isinstance(t, (int, float)) and now - t < 86400] + [now]
    _write_json(SENT_LOG, log[-200:], 0o600)


_URLISH = re.compile(r"(?i)\b(?:[a-z][a-z0-9+.\-]*://\S+|www\.\S+|\S+\.(?:com|net|org|io|sh|co|il|me|ly|app|dev)(?:/\S*)?)")


def alert_text(payload):
    """ההתראה לטלפון: בלי קישורים (4.5.x, A9) — לא נותנים להתראה להוביל לשום מקום."""
    snippet = _URLISH.sub("[קישור]", " ".join((payload["text"] or payload["patch"][:60]).split()))[:60]
    return "%s · גרסה %s · %s" % (KINDS[payload["kind"]], payload["app_version"] or "?", snippet)


def prepare(kind, text, contact="", diag="", patch="", selftest="", with_diag=False, with_patch=False, app_version=None):
    """בונה טיוטה (לא שולח!) → {draft, digest, preview, bytes, parts}. ProposalError עם הסבר אם אי אפשר."""
    if kind not in KINDS:
        raise ProposalError("סוג הצעה לא מוכר")
    if load_channel() is None:
        raise ProposalError("השליחה למנהל עוד לא פעילה (המנהל עוד לא הגדיר ערוץ).")
    if day_count() >= SENDER_DAY:
        raise ProposalError("כבר נשלחו %d הצעות ב-24 השעות האחרונות — להמתין קצת." % SENDER_DAY)
    text = scrub_text(clean(text, CAPS["text"]))
    if kind != "patch" and not text.strip():
        raise ProposalError("לכתוב קודם מה ההצעה / מה קרה")
    if kind == "patch":
        if not text.strip():
            raise ProposalError("לכתוב כמה מילים על מה תיקנת ולמה")
        v = validate_patch(patch or "")
        if not v["ok"]:
            raise ProposalError("אי אפשר לשלוח את התיקון: " + "; ".join(v["problems"][:3]))
        try:
            import make_short_chat as C
            patch, n = C.guard(patch)
            if n:
                raise ValueError("secret")
        except ValueError:
            raise ProposalError("בתיקון יש משהו שנראה כמו מפתח או סיסמה — לא שולחים. להוציא אותו ולנסות שוב.")
        except ImportError:
            pass
    c = sender_cfg()
    pid = secrets.token_hex(8)
    # 4.5.x (A6): privacy() על *כל* שדה שנשלח (גם patch, תוצאת הבדיקה והשם) — והתצוגה המקדימה בנויה מאותו payload בדיוק
    payload = {"v": 1, "pid": pid, "kind": kind, "sender_id": c["sender_id"], "ts": int(time.time()), "app_version": app_version or _version(),
               "name": privacy(clean(contact or c.get("contact") or "", CAPS["name"], False)), "text": text,
               "diag": scrub_text(clean(diag, CAPS["diag"])) if (with_diag and diag) else "",
               "patch": privacy(clean(patch, CAPS["patch"])) if kind == "patch" else "",
               "selftest": scrub_text(clean(selftest, CAPS["selftest"])) if kind == "patch" else "",
               "reply": {"topic": new_topic()}, "epoch": (load_channel() or {}).get("epoch", 0)}
    validate_payload(payload)                           # אותו אימות שהמקבל יעשה — שלא נשלח משהו שיידחה
    msgs = encode(payload)                              # גם בודק את תקרת הגודל
    d = {"payload": payload, "digest": _digest(payload), "bytes": sum(len(m.encode("utf-8")) for m in msgs), "parts": len(msgs)}
    _guard(DRAFTS)
    DRAFTS.mkdir(parents=True, exist_ok=True)
    for old in DRAFTS.glob("*.json"):                   # טיוטות ישנות (מעל יום) נמחקות
        if time.time() - old.stat().st_mtime > 86400:
            old.unlink(missing_ok=True)
    _write_json(DRAFTS / (pid + ".json"), d, 0o600)
    d["preview"] = render_preview(payload, d["bytes"], len(msgs))
    d["draft"] = pid
    return d


def render_preview(p, nbytes, nparts):
    """בדיוק מה שיישלח — שדה אחרי שדה (הטקסט המלא, לא תקציר) + הערה על מה שלא נשלח לעולם."""
    L = ["סוג: " + KINDS[p["kind"]], "גרסת התוכנה: " + (p["app_version"] or "?"),
         "שם / יצירת קשר: " + (p["name"] or "(אנונימי)"), "", "הטקסט:", p["text"] or "(אין)"]
    if p["diag"]:
        L += ["", "פרטי מערכת (מנוקים מסודות):", p["diag"]]
    if p["patch"]:
        L += ["", "התיקון (שינויי קוד מול הגרסה הרשמית):", p["patch"]]
    if p["selftest"]:
        L += ["", "תוצאת בדיקה מהירה:", p["selftest"]]
    L += ["", "מזהה אקראי של ההתקנה (כדי להגביל ספאם, לא מזהה אותך): " + p["sender_id"],
          "התראה לטלפון של המנהל: " + alert_text(p),
          "", "גודל: %d בתים ב-%d הודעות קצרות. לא נשלחים: מפתחות, סיסמאות, עוגיות, קבצי הגדרות, שם משתמש בנתיבים." % (nbytes, nparts)]
    return "\n".join(L)


def _save_rec(rec):
    _guard(OUTBOX)
    OUTBOX.mkdir(parents=True, exist_ok=True)
    _write_json(OUTBOX / (rec["pid"] + ".json"), rec, 0o600)


def confirm(draft_id, digest):
    """רק כאן נשלח משהו. ה-digest חייב להיות זה של התצוגה המקדימה והטיוטה בדיסק חייבת להתאים לו."""
    if not re.fullmatch(r"[0-9a-f]{16}", str(draft_id)):
        raise ProposalError("טיוטה לא מוכרת")
    d = _read_json(DRAFTS / (draft_id + ".json"))
    if not d or d.get("digest") != digest or _digest(d.get("payload") or {}) != digest:
        raise ProposalError("הטיוטה השתנתה מאז התצוגה המקדימה — להכין תצוגה חדשה.")
    p = validate_payload(d["payload"])
    if day_count() >= SENDER_DAY:
        raise ProposalError("כבר נשלחו %d הצעות ב-24 השעות האחרונות — להמתין קצת." % SENDER_DAY)
    ch = load_channel() or {}
    rec = {"pid": p["pid"], "created": time.time(), "kind": p["kind"], "status": "queued", "attempts": 0, "last_attempt": 0,
           "payload": p, "reply_text": "", "reply_at": 0, "history": [],
           "sign_pubs": [ch["sign_pub"]] if ch.get("sign_pub") else [], "enc_pub": ch.get("enc_pub", "")}
    _save_rec(rec)
    _log_sent()
    (DRAFTS / (draft_id + ".json")).unlink(missing_ok=True)
    try_send(rec)
    return _read_json(OUTBOX / (p["pid"] + ".json"))


def try_send(rec, alert=True):
    """שולח את כל החלקים (ואחריהם התראה — רק בשליחה הראשונה). כישלון = נשאר בתור. מחזיר True אם נשלח."""
    ch = load_channel()
    if ch is None:
        return False
    rec["last_attempt"] = time.time()
    rec["attempts"] = rec.get("attempts", 0) + 1
    ok = False
    try:
        for m in encode(rec["payload"]):
            publish(ch["server"], ch["inbox"], m, tags=["ysp"], priority=1)
        if alert and rec["status"] == "queued":
            publish(ch["server"], ch["alert"], alert_text(rec["payload"]), title="הצעה חדשה בתוכנת השורטס", priority=3,
                    tags=["incoming_envelope"])
        ok = True
    except ProposalError as e:
        rec["last_error"] = str(e)
    if ok:
        rec.pop("last_error", None)
        if rec["status"] == "queued":
            rec["status"] = "sent"
            rec.setdefault("history", []).append({"at": time.time(), "status": "sent"})
    _save_rec(rec)
    return ok


def _recs():
    out = []
    for f in sorted(OUTBOX.glob("*.json")) if OUTBOX.exists() else []:
        r = _read_json(f)
        if r.get("pid"):
            out.append(r)
    return out


def sync_sender(now=None):
    """תור: שולח מה שממתין, שולח שוב מה שלא נענה (פעם ב-12 שעות, עד 6 ימים), ומושך תשובות. אין חיבור — לא קורה כלום."""
    now = now or time.time()
    ch = load_channel()
    res = {"sent": 0, "resent": 0, "updated": 0, "error": ""}
    if ch is None:
        return res
    for r in _recs():
        if r["status"] == "queued":
            if try_send(r):
                res["sent"] += 1
        elif r["status"] == "sent" and now - r.get("last_attempt", 0) >= RESEND_EVERY and r.get("attempts", 0) < RESEND_MAX:
            if try_send(r, alert=False):
                res["resent"] += 1
    topics = {r["payload"]["reply"]["topic"]: r for r in _recs() if r["status"] not in FINAL or now - r.get("reply_at", 0) < 86400}
    if topics:
        try:
            for ev in poll(ch["server"], list(topics)):
                tp = ev.get("topic")
                if tp in topics and apply_reply(topics[tp], ev.get("message", ""), now):
                    res["updated"] += 1
        except ProposalError as e:
            res["error"] = str(e)
    return res


def make_reply(rec_payload, status, text="", ts=None):
    """בעלים בלבד: סטטוס/תשובה חתומים ב-Ed25519 של הבעלים (4.5.x, A1). הגוף כולל את מזהה ההצעה ואת נושא התשובה —
    חתימה של הצעה אחת לא תקפה להצעה אחרת."""
    body = json.dumps({"pid": rec_payload["pid"], "topic": rec_payload["reply"]["topic"], "status": status, "text": clean(text, 1500),
                       "ts": round(time.time() if ts is None else ts, 3)}, ensure_ascii=False)
    b = _b64u(body.encode("utf-8"))
    return "%s %s %s %s" % (RPFX, rec_payload["pid"], _sign_reply(rec_payload["pid"], b), b)


def apply_reply(rec, msg, now=None):
    """תשובת בעלים מאומתת (חתימת Ed25519 מול המפתח הציבורי שבערוץ), רק אם חדשה יותר ולא נסוגה בדרגה. → True אם השתנה.
    לא חתום / חתום במפתח אחר / של הצעה אחרת → נדחה."""
    now = now or time.time()
    parts = (msg or "").strip().split(" ")
    if len(parts) != 4 or parts[0] != RPFX or parts[1] != rec["pid"] or len(parts[3]) > 4000 or len(parts[2]) > 100:
        return False
    pubs = list(rec.get("sign_pubs") or []) + [(load_channel() or {}).get("sign_pub", "")]
    if not _verify_reply([p for p in pubs if p], rec["pid"], parts[3], parts[2]):
        return False
    try:
        o = json.loads(base64.urlsafe_b64decode(parts[3].encode("ascii")).decode("utf-8"))
        status, text, ts = o["status"], clean(o.get("text"), 1500), float(o["ts"])
        if o.get("pid") != rec["pid"] or o.get("topic") != rec["payload"]["reply"]["topic"]:
            return False
    except Exception:
        return False
    if status not in RANK or status in ("queued", "sent") or ts > now + 86400 or ts <= rec.get("reply_at", 0):
        return False
    new = status
    if status == "replied" and RANK[rec["status"]] >= RANK["accepted"]:
        new = rec["status"]                                  # תשובה חופשית לא מורידה סטטוס סופי
    elif RANK[status] < RANK[rec["status"]]:
        return False
    changed = new != rec["status"] or (text and text != rec.get("reply_text"))
    rec["status"], rec["reply_at"] = new, ts
    if text:
        rec["reply_text"] = text
    rec.setdefault("history", []).append({"at": now, "status": status})
    rec["history"] = rec["history"][-30:]
    _save_rec(rec)
    return bool(changed)


def outbox_view():
    now = time.time()
    out = []
    for r in sorted(_recs(), key=lambda x: -x.get("created", 0)):
        p = r["payload"]
        stuck = r["status"] == "sent" and now - r.get("last_attempt", 0) > 2 * RESEND_EVERY
        out.append({"pid": r["pid"], "kind": KINDS.get(r["kind"], ""), "created": r["created"], "status": r["status"],
                    "status_he": STATUS_HE.get(r["status"], r["status"]), "reply_text": r.get("reply_text", ""),
                    "text": p["text"][:300], "final": r["status"] in FINAL, "error": r.get("last_error", ""),
                    "attempts": r.get("attempts", 0), "stuck": stuck})
    return out


def resend_now(pid):
    r = _read_json(OUTBOX / (re.sub(r"[^0-9a-f]", "", pid) + ".json"))
    if not r or r["status"] in FINAL:
        raise ProposalError("אין מה לשלוח שוב")
    r["attempts"] = 0
    return try_send(r, alert=False)


def forget(pid):
    """מסיר מהרשימה. לא מאפס את מכסת היום (מונה נפרד — 4.5.x, A8)."""
    f = OUTBOX / (re.sub(r"[^0-9a-f]", "", pid) + ".json")
    f.unlink(missing_ok=True)


def sender_status():
    ch = load_channel()
    return {"active": ch is not None, "server": (ch or {}).get("server", ""), "contact": sender_cfg().get("contact", "") if ch else
            _read_json(CFG_FILE).get("contact", ""), "limit": SENDER_DAY, "today": day_count(), "caps": {"text": CAPS["text"]}}


# ─────────────────────────── הבעלים: ערוץ, תיבה, פעולות ───────────────────────────
def setup_channel(server=DEFAULT_SERVER, force=False):
    """יוצר ערוץ חדש (נושאים אקראיים) אצל הבעלים — מקומי בלבד, בלי רשת. הקובץ נכנס לגרסה/לחבילה רק בפרסום."""
    o = _read_json(OWNER_FILE)
    if o.get("channel") and not force:
        raise ProposalError("כבר יש ערוץ (נושאים). להחליף — רק דרך 'סיבוב'.")
    if not _valid_server(server) and not (_test_mode() and server.startswith("http://127.0.0.1")):
        raise ProposalError("כתובת שרת לא תקינה")
    enc_pub, sign_pub = _owner_pubs(create=True)          # 4.5.x (A1): מפתחות הבעלים (פרטיים — רק אצלו, 0600)
    ch = {"v": 2, "server": server.rstrip("/"), "inbox": new_topic(), "alert": new_topic(), "epoch": 1,
          "enc_pub": enc_pub, "sign_pub": sign_pub}
    o["channel"] = ch
    o.setdefault("history", [])
    o.setdefault("cursor", {})
    o["created"] = time.time()
    _write_json(OWNER_FILE, o, 0o600)
    return ch


def rotate():
    """סיבוב: נושאים חדשים (epoch+1), הישנים ממשיכים להישלף (מי שעוד לא התעדכן). נכנס לגרסה הבאה שמפרסמים."""
    o = _read_json(OWNER_FILE)
    old = o.get("channel")
    if not old:
        raise ProposalError("אין ערוץ לסובב — קודם יוצרים")
    o.setdefault("history", []).append({"inbox": old["inbox"], "alert": old["alert"], "epoch": old["epoch"], "retired": time.time()})
    enc_pub, sign_pub = _owner_pubs(create=True)
    o["channel"] = {"v": 2, "server": old["server"], "inbox": new_topic(), "alert": new_topic(), "epoch": old["epoch"] + 1,
                    "enc_pub": enc_pub, "sign_pub": sign_pub}
    _write_json(OWNER_FILE, o, 0o600)
    return o["channel"]


def channel_file_bytes():
    """לבניית גרסה/חבילה: הקובץ שייכנס ל-assets/proposals_channel.json, או None אם אין ערוץ."""
    ch = _read_json(OWNER_FILE).get("channel")
    if not ch:
        return None
    if not (ch.get("enc_pub") and ch.get("sign_pub")):      # ערוץ מ-4.4 (בלי מפתחות): מוסיפים את המפתחות הציבוריים של הבעלים
        ch["enc_pub"], ch["sign_pub"] = _owner_pubs(create=True)
        ch["v"] = 2
        o = _read_json(OWNER_FILE)
        o["channel"] = ch
        _write_json(OWNER_FILE, o, 0o600)
    return (json.dumps({k: ch[k] for k in ("v", "server", "inbox", "alert", "epoch", "enc_pub", "sign_pub")}, indent=1) + "\n").encode("utf-8")


# ───────── 4.5.62 (#8): גיבוי מוצפן של מפתח ההצעות של הבעלים ─────────
# בלי הגיבוי, אובדן המחשב = הצעות שכבר נשלחו לא קריאות + צריך ערוץ חדש שיוצא בגרסה. הקובץ proposals_owner.enc מוצפן בסיסמה
# (scrypt + AES-GCM, כמו release_key.enc) ו-backup_extras.sh מעלה אותו ל-Drive (ורק אותו; *.key לעולם לא). הוא ייכנס
# לכספת המוצפנת כשתיבנה (queued-checks-and-restore-plan) — אותה סיסמה, אותה תבנית קובץ.
BACKUP_AAD = b"yeshiva-shorts-proposals-owner-v1"


def _backup_file():
    return CONFIG / "proposals_owner.enc"


def _src_hash():
    import hashlib
    try:
        return hashlib.sha256(OWNER_KEY.read_bytes()).hexdigest()
    except OSError:
        return ""


def backup_status():
    """{has_key, has_backup, stale} — stale = המפתח השתנה (או הגיבוי נוצר לפני שיש מפתח) מאז הגיבוי האחרון."""
    f = _backup_file()
    d = {"has_key": OWNER_KEY.is_file(), "has_backup": f.is_file(), "stale": False, "at": 0}
    if f.is_file():
        j = _read_json(f)
        d["at"] = int(j.get("made") or 0)
        d["stale"] = bool(d["has_key"] and j.get("src") != _src_hash())
    return d


def backup_encrypt(passphrase):
    """מצפין את proposals_owner.key + proposals_owner.json לקובץ אחד בתיקיית ההגדרות. מחזיר backup_status()."""
    if not OWNER_KEY.is_file():
        raise ProposalError("אין עדיין מפתח הצעות לגבות — קודם יוצרים ערוץ.")
    if len(passphrase or "") < 10:
        raise ProposalError("הסיסמה קצרה מדי — לפחות 10 תווים (ואי אפשר לשחזר אותה אם תישכח; לרשום על נייר).")
    import hashlib
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt, nonce = os.urandom(16), os.urandom(12)
    n = 2 ** 17
    plain = json.dumps({"key": OWNER_KEY.read_text(encoding="utf-8"),
                        "owner": OWNER_FILE.read_text(encoding="utf-8") if OWNER_FILE.is_file() else ""}, ensure_ascii=False).encode("utf-8")
    ct = AESGCM(hashlib.scrypt(passphrase.encode("utf-8"), salt=salt, n=n, r=8, p=1, maxmem=2 ** 29, dklen=32)).encrypt(nonce, plain, BACKUP_AAD)
    _write_json(_backup_file(), {"v": 1, "kind": "proposals-owner", "kdf": "scrypt", "n": n, "r": 8, "p": 1,
                                 "salt": base64.b64encode(salt).decode(), "nonce": base64.b64encode(nonce).decode(),
                                 "ct": base64.b64encode(ct).decode(), "made": int(time.time()), "src": _src_hash()}, 0o600)
    return backup_status()


def backup_restore(passphrase, overwrite=False):
    """שחזור במחשב חדש: מפענח ומחזיר את proposals_owner.key (+ .json). לא דורס מפתח קיים אלא אם overwrite."""
    import hashlib
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    j = _read_json(_backup_file())
    if not j.get("ct"):
        raise ProposalError("אין קובץ גיבוי של מפתח ההצעות (proposals_owner.enc).")
    if not (isinstance(j.get("n"), int) and 2 ** 14 <= j["n"] <= 2 ** 18 and j.get("r") == 8 and j.get("p") == 1):
        raise ProposalError("קובץ הגיבוי פגום (פרמטרי הצפנה לא מוכרים).")
    try:
        plain = AESGCM(hashlib.scrypt((passphrase or "").encode("utf-8"), salt=base64.b64decode(j["salt"]), n=j["n"], r=8, p=1,
                                      maxmem=2 ** 29, dklen=32)).decrypt(base64.b64decode(j["nonce"]), base64.b64decode(j["ct"]), BACKUP_AAD)
    except InvalidTag:
        raise ProposalError("הסיסמה שגויה.")
    d = json.loads(plain.decode("utf-8"))
    if OWNER_KEY.exists() and not overwrite:
        raise ProposalError("כבר יש מפתח הצעות במחשב הזה — לא דורסים אותו.")
    for path, txt in ((OWNER_KEY, d.get("key", "")), (OWNER_FILE, d.get("owner", ""))):
        if not txt:
            continue
        _guard(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp%d" % os.getpid())
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(txt)
        os.replace(tmp, path)
    return backup_status()


def owner_status():
    o = _read_json(OWNER_FILE)
    ch = o.get("channel")
    d = {"visible": owner_visible(), "has_channel": bool(ch)}
    d["backup"] = backup_status()
    if ch:
        d.update(server=ch["server"], epoch=ch["epoch"], alert_url="%s/%s" % (ch["server"], ch["alert"]),
                 alert_topic=ch["alert"], subscribe_link="ntfy://%s/%s" % (urllib.parse.urlparse(ch["server"]).netloc, ch["alert"]))
    items = inbox_list()
    d["new"] = sum(1 for i in items if i["status"] == "new")
    d["total"] = len(items)
    d["release_list"] = [i for i in items if i["status"] == "accepted"]
    dr = o.get("drops") or {}
    today = dr.get("day") == time.strftime("%Y-%m-%d")
    d["drops"] = {"quota": dr.get("quota", 0) if today else 0, "invalid": dr.get("invalid", 0) if today else 0}
    # 4.5.x (A9): כל אחד שיודע את נושא ההתראה יכול לשלוח לטלפון — ההתראה רק מודיעה; לא לוחצים על קישורים/כפתורים בה
    d["push_warning"] = ("התראות בטלפון: כל מי שמכיר את הנושא יכול לשלוח התראה. התראה אמיתית רק מודיעה שיש הצעה — "
                         "לא ללחוץ על קישורים או כפתורים בתוך התראה; פותחים את התוכנה ושם קוראים.")
    return d


def _count_drop(kind, n=1):
    o = _read_json(OWNER_FILE)
    day = time.strftime("%Y-%m-%d")
    dr = o.get("drops") if (o.get("drops") or {}).get("day") == day else {"day": day, "quota": 0, "invalid": 0}
    dr[kind] = dr.get(kind, 0) + n
    o["drops"] = dr
    _write_json(OWNER_FILE, o, 0o600)


def _topics():
    o = _read_json(OWNER_FILE)
    ch = o.get("channel")
    if not ch:
        return None, []
    return ch["server"], [ch["inbox"]] + [h["inbox"] for h in o.get("history", []) if _valid_topic(h.get("inbox"))]


def notify_test():
    o = _read_json(OWNER_FILE)
    ch = o.get("channel")
    if not ch:
        raise ProposalError("קודם יוצרים ערוץ התראות")
    publish(ch["server"], ch["alert"], "בדיקה: ההתראות מהתוכנה מגיעות לטלפון ✓", title="בדיקת התראה", priority=3, tags=["white_check_mark"])
    return True


def _inbox_dir(pid):
    return INBOX / re.sub(r"[^0-9a-f]", "", pid)


def inbox_list():
    out = []
    for d in sorted(INBOX.glob("*/meta.json")) if INBOX.exists() else []:
        m = _read_json(d)
        if m.get("pid"):
            out.append(m)
    return sorted(out, key=lambda m: -m.get("received", 0))


def _rate_ok(sid, now):
    """4.5.x (A3): רק מכסה כללית (הצעות תקינות ומפוענחות ב-24 שעות). מזהה השולח נבחר ע"י השולח — לא חוסמים לפיו."""
    return sum(1 for m in inbox_list() if now - m.get("received", 0) < 86400) < OWNER_TOTAL_DAY


def _partial(pid):
    return _read_json(PARTIALS / (pid + ".json"))


def ingest(msg, now=None):
    """הודעה אחת מה-inbox. → ("part"|"stored"|"dup"|"drop", הסבר). לא זורק על קלט עוין."""
    now = now or time.time()
    pr = parse_part(msg)
    if not pr:
        return "drop", "לא בפורמט"
    pid, i, n, h, b = pr
    if (_inbox_dir(pid) / "meta.json").is_file():
        m = _read_json(_inbox_dir(pid) / "meta.json")
        # כפילות (שולח שוב) — מפרסמים לו שוב את הסטטוס הנוכחי. 4.5.x (A3): לכל היותר פעם ב-6 שעות לכל הצעה —
        # "YSP2 <מזהה מוכר>" חוזר מתוקף לא יגרום לבעלים לפרסם שוב ושוב
        if i == 1 and now - m.get("republished_at", 0) >= REPUBLISH_EVERY:
            m["republished_at"] = now
            _write_json(_inbox_dir(pid) / "meta.json", m, 0o600)
            _republish_status(m)
        return "dup", pid
    _guard(PARTIALS)
    PARTIALS.mkdir(parents=True, exist_ok=True)
    pp = _partial(pid) or {"n": n, "h": h, "first": now, "parts": {}}
    if pp["n"] != n or pp["h"] != h:
        return "drop", "חלקים לא תואמים"
    pp["parts"][str(i)] = b
    if len(pp["parts"]) < n:
        files = sorted(PARTIALS.glob("*.json"), key=lambda f: f.stat().st_mtime)
        for f in files[:-200]:                           # תקרה: 200 הצעות חלקיות
            f.unlink(missing_ok=True)
        _write_json(PARTIALS / (pid + ".json"), pp)
        return "part", pid
    (PARTIALS / (pid + ".json")).unlink(missing_ok=True)
    joined = "".join(pp["parts"][str(k)] for k in range(1, n + 1))
    if hashlib.sha256(joined.encode()).hexdigest()[:16] != h:
        return "drop", "חתימת תוכן לא תואמת"
    try:
        p = decode(joined)
    except ProposalError as e:
        _count_drop("invalid")
        return "drop", str(e)
    if p["pid"] != pid:
        _count_drop("invalid")
        return "drop", "מזהה לא תואם"
    if not _rate_ok(p["sender_id"], now):
        _count_drop("quota")
        return "drop", "חריגה ממכסה (ספאם?)"
    pv = validate_patch(p["patch"]) if p["patch"] else None
    meta = {"pid": pid, "received": now, "republished_at": now, "status": "new", "kind": p["kind"], "sender_id": p["sender_id"], "name": p["name"],
            "app_version": p["app_version"], "title": " ".join(p["text"].split())[:90] or "(תיקון בלי טקסט)",
            "has_patch": bool(p["patch"]), "patch_ok": bool(pv and pv["ok"]), "patch_problems": (pv or {}).get("problems", []),
            "patch_risks": (pv or {}).get("risks", []), "patch_files": (pv or {}).get("files", []), "reply_text": "",
            "check": None, "epoch": p["epoch"]}
    d = _inbox_dir(pid)
    _guard(d)
    d.mkdir(parents=True, exist_ok=True)
    _write_json(d / "payload.json", p, 0o600)
    _write_json(d / "meta.json", meta, 0o600)
    _republish_status(meta, payload=p)
    return "stored", pid


def _republish_status(meta, payload=None):
    payload = payload or _read_json(_inbox_dir(meta["pid"]) / "payload.json")
    if not payload:
        return
    status = {"new": "received", "read": "received", "accepted": "accepted", "rejected": "rejected", "handled": "handled",
              "replied": "replied"}.get(meta["status"], "received")
    server, _t = _topics()
    if not server:
        return
    try:
        publish(server, payload["reply"]["topic"], make_reply(payload, status, meta.get("reply_text", "")), tags=["ysr"], priority=1)
    except ProposalError:
        meta["reply_pending"] = True
        _write_json(_inbox_dir(meta["pid"]) / "meta.json", meta, 0o600)
        return
    if meta.pop("reply_pending", None):
        _write_json(_inbox_dir(meta["pid"]) / "meta.json", meta, 0o600)


def fetch_inbox(now=None):
    """שולף את ה-inbox (הנוכחי + ישנים שסובבו). הפעלה ראשונה/אחרי הפסקה: since=all (השרת שומר ~12 שעות). → {stored, dropped, error}."""
    now = now or time.time()
    server, topics = _topics()
    res = {"stored": 0, "dropped": 0, "parts": 0, "dup": 0, "error": ""}
    if not server:
        return res
    cur = _read_json(OWNER_FILE).get("cursor", {})
    since = cur.get("since", "all")
    if since != "all" and not re.fullmatch(r"[A-Za-z0-9]{1,40}", str(since)):
        since = "all"
    seen = list(cur.get("seen", []))
    # 4.5.x (A2): עמוד אחר עמוד, בתקרה; אחרי כל עמוד שומרים את ה-id האחרון שעובד — הצפה לא חוסמת את התיבה
    for _page in range(CAPS["pages"]):
        try:
            evs, more = poll_page(server, topics, since=since)
        except ProposalError as e:
            res["error"] = str(e)
            break
        sset = set(seen)
        for ev in evs:                                            # הסדר של השרת (כרונולוגי)
            eid = str(ev.get("id") or "")
            if re.fullmatch(r"[A-Za-z0-9]{1,40}", eid):
                since = eid
            if eid in sset:
                continue
            seen.append(eid)
            sset.add(eid)
            kind, _why = ingest(ev["message"], now)
            res[{"stored": "stored", "part": "parts", "dup": "dup"}.get(kind, "dropped")] += 1
        o = _read_json(OWNER_FILE)                                # קריאה טרייה (ingest כותב מונים לאותו קובץ)
        o["cursor"] = {"since": since, "seen": seen[-600:]}
        _write_json(OWNER_FILE, o, 0o600)
        if not more:
            break
        res["more"] = True
    for m in inbox_list():                                # תשובות שנכשלו קודם
        if m.get("reply_pending"):
            _republish_status(m)
    return res


def get_item(pid):
    d = _inbox_dir(pid)
    m, p = _read_json(d / "meta.json"), _read_json(d / "payload.json")
    if not m:
        raise ProposalError("הצעה לא נמצאה")
    return m, p


def mark_read(pid):
    m, _p = get_item(pid)
    if m["status"] == "new":
        m["status"] = "read"
        _write_json(_inbox_dir(pid) / "meta.json", m, 0o600)
    return m


def act(pid, action, text=""):
    """accept | reject | reply | handled. מעדכן ומפרסם סטטוס חתום לשולח. accept רק *אוסף* לרשימת הגרסה הבאה — לא מפרסם כלום."""
    if action not in ("accept", "reject", "reply", "handled"):
        raise ProposalError("פעולה לא מוכרת")
    m, p = get_item(pid)
    text = clean(text, 1500)
    if action == "reply" and not text.strip():
        raise ProposalError("לכתוב את התשובה")
    m["status"] = {"accept": "accepted", "reject": "rejected", "reply": "replied", "handled": "handled"}[action] \
        if not (action == "reply" and m["status"] in FINAL) else m["status"]
    if text:
        m["reply_text"] = text
    m["acted"] = time.time()
    _write_json(_inbox_dir(pid) / "meta.json", m, 0o600)
    _republish_status(m, p)
    return _read_json(_inbox_dir(pid) / "meta.json")


def release_notes_list():
    """ההצעות שנאספו ("✅ לצרף לגרסה הבאה") — כרשימה לפרסום הבא. לא מפרסם."""
    return [{"pid": m["pid"], "title": m["title"], "kind": KINDS.get(m["kind"], ""), "has_patch": m["has_patch"]}
            for m in inbox_list() if m["status"] == "accepted"]


# ─────────────────────────── בדיקת patch בארגז חול (בעלים) ───────────────────────────
def _base_ref(repo, ver):
    for ref in ("v%s" % ver, "rel-%s" % ver):
        r = subprocess.run(["git", "-C", str(repo), "rev-parse", "--verify", "-q", ref + "^{commit}"], capture_output=True, text=True)
        if r.returncode == 0:
            return ref
    return ""


SB_LIMITS = {"as": 3 << 30, "fsize": 256 << 20, "nproc_extra": 256, "tmp": 512 << 20, "home": 64 << 20, "work": 1 << 30, "out": 1 << 20}


def _user_procs():
    n, uid = 0, os.getuid()
    try:
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    if os.stat("/proc/" + d).st_uid == uid:
                        n += 1
                except OSError:
                    pass
    except OSError:
        pass
    return n


_SIZE_OK = {}


def _bwrap_size():
    """bwrap ≥0.10 מכיר ‎--size (תקרה ל-tmpfs). ישן יותר — בלי תקרת tmpfs (RLIMIT_FSIZE עדיין חל על כל קובץ)."""
    if "v" not in _SIZE_OK:
        try:
            r = subprocess.run([shutil.which("bwrap") or "bwrap", "--help"], capture_output=True, text=True, timeout=10)
            _SIZE_OK["v"] = "--size" in (r.stdout + r.stderr)
        except Exception:
            _SIZE_OK["v"] = False
    return _SIZE_OK["v"]


def _limits(cpu):
    """4.5.x (A5): מגבלות משאבים שעוברות בירושה לכל מה שרץ בארגז: זיכרון, גודל קובץ, זמן מעבד, מספר תהליכים."""
    import resource
    nproc = _user_procs() + SB_LIMITS["nproc_extra"]

    def pre():
        for lim, val in ((resource.RLIMIT_AS, SB_LIMITS["as"]), (resource.RLIMIT_FSIZE, SB_LIMITS["fsize"]),
                         (resource.RLIMIT_CPU, int(cpu)), (resource.RLIMIT_NPROC, nproc), (resource.RLIMIT_CORE, 0)):
            try:
                soft, hard = resource.getrlimit(lim)
                v = val if hard == resource.RLIM_INFINITY else min(val, hard)
                resource.setrlimit(lim, (v, v))
            except (ValueError, OSError):
                pass
    return pre


def _bwrap(tree, argv, timeout, ro_tree=False):
    """bubblewrap: שורש ריק, מערכת לקריאה בלבד, בית ריק, בלי רשת, בלי תיקיית ההגדרות.
    4.5.x (A5): /tmp, הבית ו-/work הם tmpfs עם תקרת גודל; ro_tree — העץ נכנס לקריאה בלבד ב-/src (העבודה מעתיקה אותו ל-/work);
    מגבלות משאבים (_limits); הפלט נכתב לקובץ עם תקרה (לא לזיכרון)."""
    import make_short_fix as FIX
    ok_, why = FIX.sandbox_available()
    if not ok_:
        raise ProposalError("אין בידוד (bubblewrap) — לא בודקים patch בלעדיו. %s" % why)
    home = os.path.expanduser("~")
    cmd = [shutil.which("bwrap"), "--unshare-all", "--die-with-parent", "--new-session", "--clearenv"] + FIX._sb_system_args()
    sz = (lambda k: ["--size", str(SB_LIMITS[k])]) if _bwrap_size() else (lambda k: [])
    cmd += ["--proc", "/proc", "--dev", "/dev"] + sz("tmp") + ["--tmpfs", "/tmp"] + sz("home") + ["--tmpfs", home]
    seen = []
    for p in (sys.prefix, sys.base_prefix, sys.exec_prefix, os.path.dirname(os.path.realpath(sys.executable)),
              os.path.dirname(os.path.dirname(os.path.realpath(sys.executable)))):
        if p and p not in seen and os.path.isdir(p) and p != "/":
            seen.append(p)
            cmd += ["--ro-bind", p, p]
    if ro_tree:
        cmd += ["--ro-bind", str(tree), "/src"] + sz("work") + ["--tmpfs", "/work", "--chdir", "/work"]
    else:
        cmd += ["--bind", str(tree), "/work", "--chdir", "/work"]
    for k, v in (("PATH", "/usr/bin:/bin"), ("HOME", home), ("TMPDIR", "/tmp"), ("LANG", "C.UTF-8"), ("PYTHONDONTWRITEBYTECODE", "1"),
                 ("SHORTS_CONFIG_DIR", "/tmp/cfg"), ("SHORTS_DATA_DIR", "/tmp/data"), ("MAKE_SHORT_TEST_GUARD", "1"),
                 ("MAKE_SHORT_UPDATE_NO_SELFTEST", "1")):
        cmd += ["--setenv", k, v]
    with tempfile.TemporaryFile() as out:
        try:
            r = subprocess.run(cmd + argv, stdout=out, stderr=subprocess.STDOUT, timeout=timeout, preexec_fn=_limits(timeout + 5))
            rc = r.returncode
        except subprocess.TimeoutExpired:
            return 124, "נתקע / ארך יותר מדי"
        size = out.seek(0, 2)
        out.seek(max(0, min(size, SB_LIMITS["out"]) - 1500))
        txt = out.read(1500).decode("utf-8", "replace")
    return rc, txt


def check_patch(pid, repo=None, selftest_args=("units",), timeout=600):
    """עותק זמני של אותה גרסה ← git apply (בארגז חול) ← בדיקה מהירה. לא נוגע בעץ החי. → תוצאה שמורה ב-meta["check"]."""
    repo = Path(repo or REPO)
    m, p = get_item(pid)
    res = {"at": time.time(), "applied": False, "selftest": None, "text": "", "risks": m.get("patch_risks", [])}
    pv = validate_patch(p.get("patch", "")) if p.get("patch") else None
    if not pv or not pv["ok"]:
        res["text"] = "נדחה לפני שהוחל: " + ("; ".join((pv or {}).get("problems", [])) or "אין patch")
        return _save_check(m, res)
    ref = _base_ref(repo, p["app_version"])
    if not ref:
        res["text"] = "לא נמצאה אצלך הגרסה %s (תגית) — אי אפשר לבנות עותק זהה לבדיקה." % (p["app_version"] or "?")
        return _save_check(m, res)
    import make_short_personal as PC
    touched = PC.touches_checks(pv.get("files", []))
    res["untrusted"] = True                       # 4.5.x (A4): תוצאה לא מחייבת — רצה על קוד שאיש עוד לא בדק
    res["check_files_restored"] = touched
    tmp = Path(tempfile.mkdtemp(prefix="ysp_check_", dir=str(PDIR) if PDIR.exists() else None))
    try:
        base = tmp / "src"                         # נכנס לארגז לקריאה בלבד כ-/src; העבודה ב-/work (tmpfs עם תקרה)
        src = base / "tree"
        src.mkdir(parents=True)
        tar = subprocess.run(["git", "-C", str(repo), "archive", "--format=tar", ref], capture_output=True, check=True, timeout=120).stdout
        subprocess.run(["tar", "-x", "-C", str(src), "--no-same-owner", "--no-same-permissions"], input=tar, check=True, timeout=120)
        (base / "patch").write_text(p["patch"], encoding="utf-8")
        # 4.5.x (A4): מנגנון הבדיקה (selftest, tests, הבדיקה העצמית) — תמיד מהגרסה הרשמית, לקריאה בלבד: patch לא "מאשר את עצמו"
        pristine = base / "pristine"
        pristine.mkdir()
        for f in PC.CHECK_MACHINERY:
            s = src / f
            if s.is_file():
                (pristine / f).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, pristine / f)
            elif s.is_dir():
                shutil.copytree(s, pristine / f, symlinks=True)
        script = ("set -u\ncp -a /src/tree/. /work/ || exit 90\n"
                  "git apply --check --whitespace=nowarn /src/patch >/tmp/apply.txt 2>&1 || { cat /tmp/apply.txt; exit 91; }\n"
                  "git apply --whitespace=nowarn /src/patch >/tmp/apply.txt 2>&1 || { cat /tmp/apply.txt; exit 92; }\n"
                  "cp -a /src/pristine/. /work/ || exit 93\n"
                  "echo '@@APPLIED@@'\n"
                  "exec python3 -B -I pipeline/scripts/make_short_selftest.py " + " ".join(
                      "'%s'" % a.replace("'", "") for a in selftest_args) + "\n")
        (base / "run.sh").write_text(script, encoding="utf-8")
        rc, out = _bwrap(base, ["sh", "/src/run.sh"], timeout, ro_tree=True)
        if rc == 91:
            res["text"] = "ה-patch לא מתאים לגרסה %s: %s" % (p["app_version"], out.strip()[-300:])
            return _save_check(m, res)
        if rc in (90, 92, 93):
            res["text"] = "החלה נכשלה: " + out.strip()[-300:]
            return _save_check(m, res)
        res["applied"] = True                      # הגענו לבדיקה (קודי 90–93 = לפני; 124 = נתקע בבדיקה עצמה)
        res["selftest"] = rc == 0
        note = " (קבצי הבדיקה שה-patch שינה הוחזרו לרשמיים: %s)" % ", ".join(touched[:3]) if touched else ""
        res["text"] = ("הבדיקה המהירה עברה ✓ — תוצאה לא מחייבת (רצה על קוד לא בדוק; לקרוא את השינוי בעיניים)" + note if rc == 0 else
                       "הבדיקה המהירה נכשלה ✗ — " + out.replace("@@APPLIED@@", "").strip()[-500:] + note)
        return _save_check(m, res)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _save_check(m, res):
    m["check"] = res
    _write_json(_inbox_dir(m["pid"]) / "meta.json", m, 0o600)
    return res


def sync_owner():
    res = fetch_inbox()
    return res


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "status"
    if cmd == "setup-channel":
        ch = setup_channel(argv[2] if len(argv) > 2 else DEFAULT_SERVER)
        print("נוצר ערוץ (epoch %d); נשמר רק אצלך. נושא ההתראה לטלפון: %s" % (ch["epoch"], ch["alert"]))
    elif cmd == "rotate":
        print("סיבוב בוצע, epoch", rotate()["epoch"])
    elif cmd == "fetch":
        print(json.dumps(fetch_inbox(), ensure_ascii=False))
    elif cmd == "sync":
        print(json.dumps(sync_sender(), ensure_ascii=False))
    else:
        print(json.dumps({"sender": sender_status(), "owner": owner_status()}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except ProposalError as e:
        print("✗", e)
        sys.exit(1)
