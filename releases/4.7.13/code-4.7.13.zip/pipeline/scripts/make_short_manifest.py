"""4.1.2 — מניפסט תכונות: שום דבר לא נעלם בשקט.

`extract()` סורק את הקוד הנוכחי: מפתחות הגדרות (DEFAULTS), פקדים עם data-k, מזהי אלמנטים, תוויות של כפתורים סטטיים,
נתיבי /api/ ושמות אזורי ההגדרות. `pipeline/tests/feature_manifest.json` הוא הצילום של הגרסה האחרונה שאושרה.
הבדיקה העצמית נכשלת אם משהו מהמניפסט חסר בקוד — אלא אם הוא ברשימה `removed_on_request` עם תאריך וציטוט של הבעלים.

יצירה מחדש (רק אחרי שהבעלים אישר שתכונה יוצאת, או כשנוספו דברים):
    python3 make_short_manifest.py write
"""
import html
import json
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
MANIFEST = REPO / "pipeline" / "tests" / "feature_manifest.json"
KINDS = ("settings_keys", "data_k", "ids", "button_labels", "api_routes", "settings_sections")


def _clean(t):
    return " ".join(html.unescape(re.sub(r"<[^>]+>", "", t)).split())


def extract():
    sys.path.insert(0, str(HERE))
    import make_short_settings as SET
    page = (HERE / "make_short_page.html").read_text(encoding="utf-8")
    app = (HERE / "make_short_app.py").read_text(encoding="utf-8")
    out = {"settings_keys": sorted(SET.DEFAULTS)}
    out["data_k"] = sorted(set(re.findall(r"""data-k=\\?["']?([A-Za-z0-9_]+)""", page)))
    out["ids"] = sorted({i for i in re.findall(r"""\bid=\\?["']([A-Za-z0-9_\-]+)["']""", page)})
    labels = set()
    for m in re.finditer(r"<button\b[^>]*>(.*?)</button>", page, re.S):
        t = _clean(m.group(1))
        if 2 <= len(t) <= 60 and "${" not in t and "`" not in t and "'+" not in t and "+'" not in t and "{" not in t:
            labels.add(t)
    out["button_labels"] = sorted(labels)
    out["api_routes"] = sorted(set(re.findall(r'"(/api/[A-Za-z0-9_/\-]+)"', app)))
    secs = set()
    for m in re.finditer(r"<summary\b[^>]*>(.*?)</summary>", page, re.S):
        t = _clean(m.group(1))
        if 2 <= len(t) <= 80 and "${" not in t and "{" not in t:
            secs.add(t)
    out["settings_sections"] = sorted(secs)
    return out


def load():
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


def missing(manifest, cur):
    """מה שבמניפסט וחסר עכשיו, למעט מה שהוסר לבקשת הבעלים (עם תאריך וציטוט)."""
    removed = {(r.get("kind"), r.get("item")) for r in manifest.get("removed_on_request", [])
               if r.get("date") and r.get("quote")}
    out = []
    for k in KINDS:
        have = set(cur.get(k, []))
        for item in manifest.get(k, []):
            if item not in have and (k, item) not in removed:
                out.append((k, item))
    return out


def write():
    old = load() if MANIFEST.exists() else {}
    cur = extract()
    cur["generated"] = time.strftime("%Y-%m-%d")
    cur["version"] = (REPO / "VERSION").read_text().strip()
    cur["removed_on_request"] = old.get("removed_on_request", [])
    MANIFEST.write_text(json.dumps(cur, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return {k: len(cur[k]) for k in KINDS}


if __name__ == "__main__":
    if sys.argv[1:] == ["write"]:
        print(write())
    else:
        sys.exit(__doc__)
