# -*- coding: utf-8 -*-
"""הסרת מילה שחוזרת מיד על עצמה ("הוא הוא" → "הוא") — כרטיס 25, 1/11/2026. רק לרב שהפרופיל שלו מדליק את זה
(הרב חיים כץ; make_short_rabbis.dedupe_on), לעולם לא כלל כללי.

למה גם מהקול: אם רק הכתובית מדלגת על המילה, הקול עדיין אומר אותה פעמיים — הכתובית לא תתאים למה שנשמע.
לכן החזרה נחתכת מהשמע עצמו — בדיוק כמו הכלל הקיים "לחתוך את הגמגום של הדובר": חיתוך רק בתוך שקט שנמדד
(לא לפי חותמות whisper), ובכל צד של החיתוך שקט של לפחות MIN_QUIET (=2×החפיפה של 0.18 ש' + שוליים),
כדי שה-crossfade לא יאכל קצה של מילה. אין שקט כזה משני הצדדים — המילה נשארת, והדבר נרשם בכרטיס ("נשארה חזרה").

הקלט הוא מה שכבר קיים בשלב "הצמדת הגבולות" (תמלול turbo של חלון סביב כל חתיכה + השמע שלו), לכן לא צריך
שום תמלול נוסף: החיתוך מפצל חתיכה לשתיים בזמני השיעור, והבנייה והתמלול בשתי האוזניים רצים על התוצאה כמו תמיד.
הפונקציות כאן טהורות (מילים + מערך שמע → חתיכות), כך שאפשר לבדוק אותן בלי וידאו.
"""
import re
import unicodedata

import numpy as np

SR = 16000
WIN = 0.01           # חלון RMS של 10ms — כמו quietest ב-make_short
MIN_QUIET = 0.36     # שקט רציף מינימלי לכל נקודת חיתוך (crossfade 0.18 × 2)
EDGE = 0.6           # לא חותכים בתוך 0.6 ש' מקצה החתיכה (שם מתחיל/נגמר משפט שנבחר בכוונה)
MIN_PIECE = 3.0      # שום חתיכה קצרה מזה אחרי החיתוך (כמו כלל הדילוגים)
MIN_OPEN = 6.0       # חתיכת הפתיחה של הקליף — לפחות 6 ש' (קפיצות מצלמה)


def norm(w):
    """מילה להשוואה: בלי ניקוד, פיסוק, סימני כיוון."""
    s = unicodedata.normalize("NFKD", str(w or ""))
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"[^א-תA-Za-z0-9]", "", s)


def rms_curve(audio):
    n = int(WIN * SR)
    m = len(audio) // n
    if m < 1:
        return np.zeros(0)
    return np.sqrt((np.asarray(audio[:m * n], dtype=float).reshape(m, n) ** 2).mean(1))


def threshold(r):
    """סף "שקט": 10% מעוצמת הדיבור (אחוזון 90) — יחסי, כדי שיעבוד גם בהקלטה שקטה."""
    if not len(r):
        return 0.0
    return max(0.004, 0.10 * float(np.percentile(r, 90)))


def quiet_point(r, thr, lo, t0, t1):
    """הריצה השקטה הארוכה ביותר שנוגעת בחלון [t0,t1] (זמני שיעור; lo = זמן השיעור של תחילת השמע).
    מחזיר (אמצע הריצה, אורכה בשניות) או None."""
    if not len(r) or t1 <= t0:
        return None
    i0 = max(0, int((t0 - lo) / WIN))
    i1 = min(len(r) - 1, int((t1 - lo) / WIN))
    if i1 < i0:
        return None
    best = None
    q = r < thr
    i = i0
    while i <= i1:
        if q[i]:
            a = i
            while a > 0 and q[a - 1]:
                a -= 1
            b = i
            while b + 1 < len(q) and q[b + 1]:
                b += 1
            ln = (b - a + 1) * WIN
            if best is None or ln > best[1]:
                best = (lo + (a + b + 1) / 2.0 * WIN, ln)
            i = b + 1
        else:
            i += 1
    return best


def repeats_in(words, a, b, keep=()):
    """אינדקסים i שבהם words[i] ו-words[i+1] אותה מילה (מילה של 2 אותיות ומעלה, לא מהרשימה של הדגשות),
    כשהזוג כולו בתוך [a,b] ובמרחק EDGE משני הקצוות."""
    out = []
    keep = {norm(k) for k in keep}
    for i in range(len(words) - 1):
        n1, n2 = norm(words[i]["word"]), norm(words[i + 1]["word"])
        if len(n1) < 2 or n1 != n2 or n1 in keep:
            continue
        # "מה? מה?" / "נכון. נכון." — שאלה או משפט שלם שחוזרים הם דיבור, לא גמגום (נמדד על שיעורי הרב כץ: רובם כאלה)
        if str(words[i]["word"]).strip().strip("\"'״׳”“)]")[-1:] in ("?", "!", ".", ":", ";"):
            continue
        if words[i]["start"] < a + EDGE or words[i + 1]["end"] > b - EDGE:
            continue
        out.append(i)
    return out


def _cut_for(words, i, r, thr, lo, a, b):
    """אפשרות להסיר את אחת משתי המילים: מחזיר (c1, c2, איזו) או (None, None, סיבה)."""
    prev_end = words[i - 1]["end"] if i > 0 and words[i - 1]["end"] > a else a
    nxt = words[i + 2]["start"] if i + 2 < len(words) and words[i + 2]["start"] < b else b
    w1, w2 = words[i], words[i + 1]
    tries = (("first", (prev_end - 0.1, w1["start"] + 0.1), (w1["end"] - 0.1, w2["start"] + 0.1), w1),
             ("second", (w1["end"] - 0.1, w2["start"] + 0.1), (w2["end"] - 0.1, nxt + 0.1), w2))
    why = "אין שקט של לפחות %.2f ש' משני צדי המילה" % MIN_QUIET
    for which, win1, win2, tgt in tries:
        q1, q2 = quiet_point(r, thr, lo, *win1), quiet_point(r, thr, lo, *win2)
        if not q1 or not q2 or q1[1] < MIN_QUIET or q2[1] < MIN_QUIET:
            continue
        c1, c2 = q1[0], q2[0]
        if c1 <= tgt["start"] + 0.05 and c2 >= tgt["end"] - 0.05 and c2 > c1:
            return c1, c2, which
    return None, None, why


def plan_piece(words, audio, lo, a, b, keep=(), opening=False):
    """חתיכה (a,b) בזמני שיעור → (חתיכות חדשות, רשומות). words = מילי החלון בזמני שיעור, audio = שמע החלון (lo = תחילתו).
    רשומה: {word, t, action: removed|kept, why, removed: [c1,c2], which}. אין חזרות = ([(a,b)], [])."""
    ws = [w for w in words if w["end"] > a - 0.5 and w["start"] < b + 0.5 and norm(w["word"])]
    idx = repeats_in(ws, a, b, keep)
    if not idx:
        return [(a, b)], []
    r = rms_curve(audio)
    thr = threshold(r)
    recs, cuts = [], []
    for i in idx:
        c1, c2, extra = _cut_for(ws, i, r, thr, lo, a, b)
        rec = {"word": ws[i]["word"].strip().strip(",.?!:;"), "t": round(ws[i]["start"], 2)}
        if c1 is None:
            recs.append(dict(rec, action="kept", why=extra))
        else:
            cuts.append((c1, c2))
            recs.append(dict(rec, action="removed", which=extra, removed=[round(c1, 3), round(c2, 3)]))
    # החתיכות שנשארות; חיתוך שיוצר חתיכה קצרה מדי (או פתיחה קצרה) — מבוטל ונרשם כ"נשארה"
    while True:
        cuts.sort()
        pcs, cur = [], a
        for c1, c2 in cuts:
            pcs.append((cur, c1))
            cur = c2
        pcs.append((cur, b))
        bad = next((k for k, (x, y) in enumerate(pcs)
                    if y - x < (MIN_OPEN if (opening and k == 0) else MIN_PIECE)), None)
        if bad is None or not cuts:
            break
        drop = cuts[min(bad, len(cuts) - 1)] if bad < len(cuts) else cuts[-1]
        cuts.remove(drop)
        for rec in recs:
            if rec.get("removed") == [round(drop[0], 3), round(drop[1], 3)]:
                rec.update(action="kept", why="החיתוך היה משאיר חתיכה קצרה מדי")
                rec.pop("removed", None)
                rec.pop("which", None)
    if not cuts:
        return [(a, b)], recs
    return [(round(x, 3), round(y, 3)) for x, y in pcs], recs


def rejoin(cuts, removed, tol=0.55):
    """ביטול הסרה: חתיכות הקליף (זמני שיעור) כשהחור [c1,c2] נסגר בחזרה — החתיכה שנגמרת ב-c1 והבאה שמתחילה ב-c2 מתאחדות.
    None אם לא נמצא זוג כזה (הגבולות כבר זזו ידנית)."""
    c1, c2 = removed
    for k in range(len(cuts) - 1):
        if abs(cuts[k][1] - c1) <= tol and abs(cuts[k + 1][0] - c2) <= tol:
            return [list(x) for x in cuts[:k]] + [[cuts[k][0], cuts[k + 1][1]]] + [list(x) for x in cuts[k + 2:]]
    return None
