# -*- coding: utf-8 -*-
"""
make_short_pick.py — בחירת קטעים אוטומטית לתוכנה (שלב 2, 20/10/2026).

למה: בשלב 1 הוא כתב זמנים בעצמו — וזה בדיוק החלק שעד היום עשה Claude. כאן מודל שפה
קורא את **תמלול השיעור** (טקסט עם זמנים, לעולם לא את הווידאו) ומציע קטעים, כותרת,
תיאור ותגיות; הוא בודק, מתקן ומסמן, ואז "הכן" ממשיך בדיוק כמו בשלב 1.

שתי דרכים למודל:
  א. Gemini — כשיש מפתח שעובד: בקשה אחת לשיעור (בפלייליסט — כמה שיעורים בבקשה).
  ב. "העתק לצ'אט" — כשאין מפתח / חסום / נגמרה המכסה: התמלול + כל ההוראות מועתקים,
     מדביקים בכל צ'אט חינמי, ומדביקים את התשובה בחזרה. תוכנית לא יכולה להשתמש במנוי
     של Claude — זו הדרך החינמית.

🚨 מגינים (מה שכבר השתבש בעבר):
  - שם הרב **רק מכותרת הסרטון** — Gemini המציא דוברים (אזכרה לראי"ה) ושמות בתגיות (17/9).
  - כל ציטוט פתיחה/סיום נבדק מול התמלול; ציון נמוך מסומן באדום ולא מסומן אוטומטית לבנייה.
  - שער הנאמנות 1ב — רשימת "שים לב" לכל קטע: כל שאלה עם תשובת המודל עצמו; באדום רק "לא" או ציטוט שלא
    נמצא, ואישור אחד לפני הבנייה רק כשיש משהו באדום (21/10 — לא עוד תיבות סימון שמסמנים בלי לקרוא).
  - מכסת Gemini: עוצרים רק כש-Gemini עצמו אומר שנגמרה (429, quotaId …PerDay), לא לפי
    ספירה מקומית; לא מחליפים מודל לבד; לא מנסים שוב בלולאה. 403 = המפתח/החשבון חסום.

שימוש (החלון מריץ את זה כעבודה ברקע):
  shorts.sh py make_short_pick.py scan <dir>      ← תמלול/כתוביות + שאלת Gemini אם אפשר
  shorts.sh py make_short_pick.py gemini <dir>    ← רק לשאול את Gemini על החלקים שעוד לא נענו
"""
import concurrent.futures as CF
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import make_short_settings as SET  # noqa: E402
import make_short_emph as EM  # noqa: E402
import make_short_rabbis as RB  # noqa: E402

DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
USAGE = Path(os.environ.get("MAKE_SHORT_GEMINI_USAGE") or DATA / "gemini_usage.json")   # בדיקות: קובץ אחר
CONFIG_ENV = SET.CONFIG / "config.env"
COOKIES = SET.CONFIG / "youtube_cookies.txt"
GUIDELINES = SET.CONFIG / "guidelines.txt"
PICK = "pick.json"
PT = ZoneInfo("America/Los_Angeles")          # המכסה היומית של Google מתאפסת בחצות שעון פסיפיק
NOMINAL_DAY = 20                              # מה שידענו עד היום (זיכרון: "Gemini 20/day") — עד שגוגל אומר אחרת
API = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"
BLOCKED_MSG = "המפתח/החשבון חסום — הדביקו מפתח חדש (בהגדרות המתקדמות), או השתמשו ב\"העתק לצ'אט\""
say = MS.say


# ═══════════════════════ מכסת Gemini ═══════════════════════

def pt_day():
    return datetime.now(PT).strftime("%Y-%m-%d")


def next_reset():
    now = datetime.now(PT)
    return (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()


def _usage_read():
    try:
        d = json.loads(USAGE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if d.get("day") != pt_day():
        # יום חדש אצל Google: הספירה והחסימות היומיות מתאפסות; המכסה שגוגל עצמו אמר — נשמרת
        d = {"day": pt_day(), "key_block": d.get("key_block"), "last_fail": d.get("last_fail"),
             "models": {m: {k: v[k] for k in ("limit", "limit_src", "quota_id") if k in v}
                        for m, v in (d.get("models") or {}).items()}}
    for v in d["models"].values():
        if v.get("blocked_until") and time.time() >= v["blocked_until"]:
            v.pop("blocked_until", None)
            v.pop("block_msg", None)
    return d


def _usage_edit(fn):
    """קריאה-שינוי-כתיבה תחת נעילה: כמה עבודות יכולות לשאול את Gemini באותו זמן."""
    import fcntl
    USAGE.parent.mkdir(parents=True, exist_ok=True)
    with open(str(USAGE) + ".lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        d = _usage_read()
        fn(d)
        tmp = USAGE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(USAGE)
        return d


def current_key():
    return (os.environ.get("GEMINI_API_KEY") or "").strip()


# ─────────── 4.1.1: "Gemini לא עובד כרגע" — זוכרים את הכישלון האחרון (עומס / אין תשובה בזמן) ───────────
# נשמר ב-gemini_usage.json (כתיבה אטומית, בלי מפתח): {"kind": "busy"|"timeout", "at": epoch}. הצלחה מוחקת.
FAIL_KINDS = ("busy", "timeout")
# מה לומר למשתמש לכל סוג עצירה, אחרי "העורך החכם לא הופעל כי …"
SKIP_WHY = {"busy": "Gemini עמוס כרגע", "timeout": "Gemini לא ענה בזמן",
            "quota_day": "הגעתם למכסה היומית של Gemini", "quota_minute": "Gemini ביקש לחכות דקה",
            "quota_margin": "נשארו מעט בקשות להיום והתוכנה שומרת אותן",
            "key_blocked": "המפתח של Gemini חסום", "key_invalid": "המפתח של Gemini לא תקין",
            "no_key": "אין מפתח Gemini", "chat_mode": "בהגדרות נבחר «העתק לצ'אט» לעורך"}


def fail_note(kind, msg=""):
    _usage_edit(lambda d: d.__setitem__("last_fail", {"kind": kind, "at": time.time(), "msg": str(msg)[:120]}))


def fail_clear():
    if _usage_read().get("last_fail"):
        _usage_edit(lambda d: d.pop("last_fail", None))


def recent_fail(minutes=None, now=None):
    """הכישלון האחרון (busy / timeout) אם קרה ב-N הדקות האחרונות, אחרת None. N = gemini_recent_fail_min (0 = כבוי)."""
    n = float(SET.load().get("gemini_recent_fail_min", 15) if minutes is None else minutes)
    f = _usage_read().get("last_fail") or {}
    if n <= 0 or f.get("kind") not in FAIL_KINDS:
        return None
    return f if (now or time.time()) - float(f.get("at") or 0) <= n * 60 else None


def skip_msg(kind, raw=""):
    """"העורך החכם לא הופעל כי …" לסוגי עצירה מוכרים; אחרת — הנוסח הישן."""
    return ("העורך החכם לא הופעל כי %s" % SKIP_WHY[kind]) if kind in SKIP_WHY else "העורך החכם לא נשלח: %s" % raw


def gemini_unusable(P=None, step="editor", now=None):
    """4.1.1: האם Gemini ידוע כלא-שמיש *עכשיו*, בלי לשאול אותו. מחזיר (kind, הודעה בעברית) או None.
    בודק: מפתח חסום / אין מפתח / שלב מוגדר לצ'אט / מכסה יומית או שולי הבטיחות / כישלון עומס או זמן
    ב-N הדקות האחרונות (גם משלב בחירת הקטעים באותו שיעור, או שבחירת הקטעים עברה ל"העתק לצ'אט")."""
    st = gemini_status()
    if not st["has_key"]:
        return "no_key", skip_msg("no_key")
    if st["key_blocked"]:
        return "key_blocked", skip_msg("key_blocked")
    if not step_direct(step):
        return "chat_mode", skip_msg("chat_mode")
    m = st["models"].get(st["model"]) or {}
    if m.get("blocked_until"):
        k = "quota_day" if "יומית" in m.get("block_msg", "") else "quota_minute"
        return k, skip_msg(k)
    if st.get("margin_stop"):
        return "quota_margin", skip_msg("quota_margin")
    f = recent_fail(now=now)
    if f:
        return f["kind"], skip_msg(f["kind"])
    if P is not None:                       # שלב הבחירה של אותו שיעור כבר נפל לצ'אט בגלל Gemini
        try:
            ps = json.load(open(Path(P) / PICK, encoding="utf-8")).get("gemini_stop") or {}
        except (OSError, ValueError):
            ps = {}
        n = float(SET.load().get("gemini_recent_fail_min", 15))
        age = ((now or time.time()) - float(ps["ts"])) / 60 if ps.get("ts") else None
        if ps.get("kind") in ("busy", "timeout", "quota_day", "quota_minute", "quota_margin", "key_blocked") \
                and n > 0 and age is not None and age <= n:
            return ps["kind"], skip_msg(ps["kind"])
    return None


def key_fp(key):
    return hashlib.sha256(key.encode()).hexdigest()[:12] if key else ""


def gemini_status():
    """לחלון — המונה הקבוע בצד: כמה בקשות היום לכל מודל, המכסה, וחסימות. בלי המפתח עצמו."""
    d = _usage_read()
    key = current_key()
    kb = d.get("key_block") or {}
    models = {}
    for m, v in d["models"].items():
        models[m] = {"used": v.get("used", 0), "limit": v.get("limit") or NOMINAL_DAY,
                     "limit_src": v.get("limit_src") or "nominal", "blocked_until": v.get("blocked_until"),
                     "block_msg": v.get("block_msg", ""), "quota_id": v.get("quota_id", "")}
    model = SET.load()["gemini_model"]
    models.setdefault(model, {"used": 0, "limit": NOMINAL_DAY, "limit_src": "nominal", "blocked_until": None,
                              "block_msg": "", "quota_id": ""})
    return {"model": model, "models": models, "has_key": bool(key),
            "key_tail": key[-4:] if key else "",
            "key_blocked": bool(key and kb.get("fp") == key_fp(key)), "key_block_msg": kb.get("msg", ""),
            "key_block_at": kb.get("at", ""), "reset_at": next_reset(), "day": d["day"],
            # 28/10: עצירה מוקדמת לפני הגבול + מה נבחר לכל שלב
            "margin": int(SET.load().get("gemini_margin", 2) or 0), "margin_left": margin_left(model),
            "margin_stop": (margin_left(model) is not None and margin_left(model) < 1),
            "steps": {k: SET.load().get("gm_" + k, "key") for k in ("pick", "rank", "playlist", "editor", "alts")}}


class GeminiStop(Exception):
    """Gemini לא ייקרא עכשיו. kind: no_key / key_blocked / key_invalid / quota_day / quota_minute / error"""
    def __init__(self, kind, msg):
        super().__init__(msg)
        self.kind = kind


def _retry_secs(s):
    m = re.match(r"([\d.]+)s", str(s or ""))
    return float(m.group(1)) if m else None


def _on_429(model, err):
    """🚨 קוראים את גוף השגיאה של Google: quotaId (PerDay / PerMinute), המכסה האמיתית, ומתי לנסות.
    יומית → חסום עד חצות פסיפיק, והמונה מכויל למכסה שגוגל אמר. לדקה → חסום לזמן שגוגל אמר.
    לעולם לא ניסיון חוזר אוטומטי ולא מעבר למודל אחר — הוא מחליט (בקשתו המפורשת)."""
    qids, limit, retry = [], None, None
    for det in err.get("details") or []:
        t = det.get("@type", "")
        if t.endswith("QuotaFailure"):
            for v in det.get("violations") or []:
                qids.append(v.get("quotaId") or v.get("quotaMetric") or "")
                if v.get("quotaValue"):
                    try:
                        limit = int(v["quotaValue"])
                    except ValueError:
                        pass
        elif t.endswith("RetryInfo"):
            retry = _retry_secs(det.get("retryDelay"))
    msg = err.get("message", "")
    per_day = any("perday" in q.lower() for q in qids) or (not qids and "per day" in msg.lower())
    qid = ", ".join(q for q in qids if q)

    def upd(d):
        v = d["models"].setdefault(model, {})
        v["quota_id"] = qid
        if per_day:
            if limit:
                v["limit"], v["limit_src"] = limit, "google"
                v["used"] = max(v.get("used", 0), limit)     # גוגל אמר שנגמר — זה מה שנספר
            v["blocked_until"] = next_reset()
            v["block_msg"] = "המכסה היומית של %s נגמרה (לפי Google)" % model
        else:
            v["blocked_until"] = time.time() + (retry or 60)
            v["block_msg"] = "יותר מדי בקשות בדקה (לפי Google) — אפשר לנסות שוב בעוד %d שניות" % (retry or 60)
    _usage_edit(upd)
    if per_day:
        return GeminiStop("quota_day", "המכסה היומית של Gemini (%s) נגמרה — לפי Google עצמו%s. "
                          "מתאפסת בחצות שעון פסיפיק (%s אצלנו). עד אז: \"העתק לצ'אט\"."
                          % (model, " (מכסה: %d ביום)" % limit if limit else "",
                             time.strftime("%H:%M", time.localtime(next_reset()))))
    return GeminiStop("quota_minute", "Gemini: יותר מדי בקשות בדקה האחרונה. אפשר ללחוץ שוב בעוד %d שניות, "
                      "או \"העתק לצ'אט\"." % (retry or 60))


def margin_left(model=None):
    """28/10 (בקשתו: "לעצור בזמן לפני ש-Gemini יסרב לעבוד"): כמה בקשות עוד מותר היום לפני "X לפני הגבול".
    הגבול = מה ש-Google אמר (מכויל מ-429), אחרת 20. None = ההגדרה 0 (רק העצירה של Google עצמו)."""
    model = model or SET.load()["gemini_model"]
    margin = int(SET.load().get("gemini_margin", 2) or 0)
    if margin <= 0:
        return None
    v = (_usage_read()["models"].get(model) or {})
    return (v.get("limit") or NOMINAL_DAY) - margin - v.get("used", 0)


def margin_msg(model=None):
    model = model or SET.load()["gemini_model"]
    v = (_usage_read()["models"].get(model) or {})
    return ("נשארו רק %d בקשות היום ל-%s, והתוכנה עוצרת %d לפני הגבול (הגדרה מתקדמת) — כדי ש-Gemini לא יחסום. "
            "מעכשיו כל שלב עובר ל\"העתק לצ'אט\" עד שהמכסה מתאפסת בחצות שעון פסיפיק (%s אצלנו)."
            % (max(0, (v.get("limit") or NOMINAL_DAY) - v.get("used", 0)), model, int(SET.load().get("gemini_margin", 2)),
               time.strftime("%H:%M", time.localtime(next_reset()))))


def step_direct(step):
    """28/10: השלב הזה הולך ישירות דרך המפתח (ברירת המחדל), או שבחר בהגדרות "תמיד העתק לצ'אט"."""
    return SET.load().get("gm_" + step, "key") != "chat"


CHAT_MODE_MSG = "בהגדרות המתקדמות נבחר לשלב הזה \"תמיד העתק לצ'אט\" — מעתיקים, מדביקים בצ'אט ומדביקים את התשובה כאן"


def gemini_call(prompt, model=None, json_mode=True, timeout=420, max_tokens=None, key=None, parts=None,
                temperature=0.4, thinking=None):
    """key = מפתח לבדיקה בלבד (מהתיבה, לפני שמירה); בלי — המפתח השמור.
    parts = חלקים נוספים אחרי הטקסט (28/10, העורך החכם: שמע של הקליפים כ-inline_data) — אותה ספירה ואותן עצירות."""
    model = model or SET.load()["gemini_model"]
    test_key = bool(key)
    key = key or current_key()
    if not key:
        raise GeminiStop("no_key", "אין מפתח Gemini — אפשר להדביק מפתח בהגדרות המתקדמות, או \"העתק לצ'אט\"")
    st = gemini_status()
    if (_usage_read().get("key_block") or {}).get("fp") == key_fp(key):
        raise GeminiStop("key_blocked", BLOCKED_MSG)
    m = st["models"].get(model) or {}
    if m.get("blocked_until"):
        kind = "quota_day" if "יומית" in m.get("block_msg", "") else "quota_minute"
        raise GeminiStop(kind, "%s. Gemini לא נקרא שוב עד %s — בינתיים: \"העתק לצ'אט\"."
                         % (m["block_msg"], time.strftime("%H:%M", time.localtime(m["blocked_until"]))))
    left = margin_left(model)
    if left is not None and left < 1 and not test_key:
        raise GeminiStop("quota_margin", margin_msg(model))
    gen = {"temperature": temperature}
    if json_mode:
        gen["responseMimeType"] = "application/json"
    if max_tokens:
        gen["maxOutputTokens"] = max_tokens
    if thinking is not None:                     # העורך: חשיבה מוגבלת — בלי זה 6 קליפים לא חזרו גם אחרי 10 דקות (28/10)
        gen["thinkingConfig"] = {"thinkingBudget": int(thinking)}
    body = json.dumps({"contents": [{"parts": [{"text": prompt}] + list(parts or [])}],
                       "generationConfig": gen}).encode("utf-8")
    # המפתח בכותרת ולא בכתובת — כך הוא לא מופיע בשום הודעת שגיאה או יומן
    req = urllib.request.Request(API % model, data=body, method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": key})

    def count(d):
        v = d["models"].setdefault(model, {})
        v["used"] = v.get("used", 0) + 1
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            res = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode("utf-8", "replace")).get("error") or {}
        except ValueError:
            err = {}
        msg = err.get("message", "")
        if e.code == 429:
            raise _on_429(model, err)
        if e.code == 403:
            _usage_edit(lambda d: d.__setitem__("key_block", {"fp": key_fp(key), "at": time.strftime("%Y-%m-%d %H:%M"),
                                                              "msg": msg[:200]}))
            raise GeminiStop("key_blocked", BLOCKED_MSG)
        if e.code == 400 and "api key" in msg.lower():
            raise GeminiStop("key_invalid", "המפתח לא תקין (Google לא מכיר אותו) — הדביקו מפתח אחר")
        if e.code == 404:
            raise GeminiStop("error", "המודל %s לא קיים אצל Google — לשנות את שם המודל בהגדרות" % model)
        # 21/10: "This model is currently experiencing high demand" (503) הגיע אליו באנגלית. עומס אצל גוגל =
        # המפתח עבר אימות; לא נספר במכסה, ולא מנסים שוב לבד — הוא לוחץ שוב בעוד דקה.
        if e.code in (500, 502, 503, 504):
            fail_note("busy", "HTTP %d" % e.code)             # 4.1.1: השלבים הבאים לא ינסו עד שיעבור זמן
            raise GeminiStop("busy", "השרתים של Gemini עמוסים כרגע (תקלה זמנית אצל Google, לא אצלכם). "
                             "לנסות שוב בעוד דקה-שתיים, או בינתיים \"העתק לצ'אט\".")
        _usage_edit(count)
        raise GeminiStop("error", "Gemini החזיר שגיאה: %s" % hebrew_error(e.code, err))
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        if isinstance(e, TimeoutError) or isinstance(getattr(e, "reason", None), TimeoutError) \
                or "timed out" in str(e).lower():
            fail_note("timeout", "%ds" % timeout)
            raise GeminiStop("timeout", "Gemini לא ענה תוך %s — כנראה עומס אצל Google. אפשר לנסות שוב בעוד כמה דקות, "
                             "או \"העתק לצ'אט\"." % ("%d שניות" % timeout if timeout < 120 else "%d דקות" % round(timeout / 60)))
        raise GeminiStop("error", "אין חיבור ל-Gemini (%s)" % str(e)[:120])

    def count_ok(d):
        count(d)
        d.pop("last_fail", None)                  # תשובה אמיתית = Gemini עובד שוב
    _usage_edit(count_ok)
    cand = (res.get("candidates") or [{}])[0]
    text = "".join(p.get("text", "") for p in (cand.get("content") or {}).get("parts", []) if not p.get("thought"))
    if not text.strip():
        raise GeminiStop("error", "Gemini החזיר תשובה ריקה (%s)" % (cand.get("finishReason") or
                                                                   (res.get("promptFeedback") or {}).get("blockReason") or "?"))
    return text


def hebrew_error(code, err):
    """שגיאה של Google בעברית. המקור באנגלית נשאר בסוגריים, קצר — כדי שעוזר יוכל לזהות אותו."""
    status, msg = err.get("status", ""), err.get("message", "")
    low = msg.lower()
    if "location" in low and "not supported" in low:
        he = "Gemini לא זמין מהמיקום הזה"
    elif status == "INVALID_ARGUMENT":
        he = "הבקשה לא התקבלה (ייתכן שהטקסט ארוך מדי או שהמודל לא תומך בבקשה כזו)"
    elif status == "FAILED_PRECONDITION":
        he = "החשבון עוד לא מוכן לשימוש (למשל חסרה הגדרת חיוב או מגבלת אזור)"
    elif status == "UNAUTHENTICATED" or code == 401:
        he = "המפתח לא התקבל — להדביק אותו שוב"
    elif status == "DEADLINE_EXCEEDED":
        he = "התשובה לקחה יותר מדי זמן — לנסות שוב"
    else:
        he = "שגיאה %d" % code
    return "%s (Google: %s)" % (he, msg[:120]) if msg else he


def check_key(key=None):
    """"בדוק מפתח": בקשה אחת קטנה (נספרת במכסה). מחזיר (ok, הודעה).
    key = מפתח שהודבק בתיבה ועוד לא נשמר (21/10: הוא ציפה ש"בדוק" יבדוק את מה שבתיבה, לפני שמירה)."""
    key = normalize_key(key) if key else current_key()
    fp = key_fp(key)

    def unblock(d):                     # מפתח שעבד מבטל חסימה ישנה — רק אם החסימה נרשמה על *אותו* מפתח
        if (d.get("key_block") or {}).get("fp") == fp:
            d["key_block"] = None
    tail = "" if key == current_key() else " — עוד לא נשמר: ללחוץ \"שמור ובדוק\" כדי להשתמש בו"
    try:
        gemini_call("ענה במילה אחת: שלום", json_mode=False, timeout=60, max_tokens=200, key=key)
        _usage_edit(unblock)
        return True, "המפתח עובד ✓ (נספרה בקשה אחת במכסה של היום)" + tail
    except GeminiStop as e:
        if e.kind == "busy":
            # עומס זמני מגיע רק אחרי שגוגל קיבל את המפתח — חסום היה מקבל 403, לא מוכנס לתור
            _usage_edit(unblock)
            return True, ("המפתח התקבל ✓ — אבל השרתים של Gemini עמוסים ממש עכשיו, אז לא הגיעה תשובה. "
                          "זו תקלה זמנית אצל Google; לנסות שוב בעוד דקה-שתיים." + tail)
        return False, str(e)


def normalize_key(key):
    """ניקוי מפתח שהודבק + בדיקה בסיסית. כל פורמט של גוגל (גם החדש, 21/10) — רק בלי רווחים."""
    key = (key or "").strip().strip('"').strip("'")
    if key.startswith("GEMINI_API_KEY="):                    # הודבקה השורה כולה
        key = key.split("=", 1)[1].strip().strip('"').strip("'")
    key = re.sub(r"\s+", "", key)                            # שבירת שורה באמצע הדבקה
    if not (16 <= len(key) <= 1024) or "'" in key or not key.isprintable() or not key.isascii():
        raise ValueError("זה לא נראה כמו מפתח — להעתיק אותו שוב מ-aistudio.google.com/apikey, בלי רווחים")
    return key


def save_key(key):
    """מפתח חדש ל-config.env (הרשאות 600 — רק המשתמש קורא). לעולם לא מודפס."""
    # 21/10/2026: גוגל עברה לפורמט מפתחות חדש, והבדיקה הישנה ([A-Za-z0-9_-], 30–80 תווים, "AIza...")
    # דחתה מפתח תקין שהוא הדביק. עכשיו: כל מפתח בלי רווחים — גוגל עצמה תגיד ב"בדוק מפתח" אם הוא טוב.
    key = normalize_key(key)
    lines = CONFIG_ENV.read_text(encoding="utf-8").splitlines() if CONFIG_ENV.exists() else []
    if CONFIG_ENV.exists():                                  # הקודם נשמר בצד, לא נמחק
        bak = CONFIG_ENV.with_name("config.env.bak")
        fd = os.open(bak, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        os.chmod(bak, 0o600)
    # במירכאות בודדות: shorts.sh טוען את הקובץ כסקריפט, ותו כמו & ; $ במפתח החדש היה שובר אותו
    out = [l for l in lines if not l.startswith("GEMINI_API_KEY=")] + ["GEMINI_API_KEY='%s'" % key]
    tmp = CONFIG_ENV.with_name("config.env.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, CONFIG_ENV)
    os.environ["GEMINI_API_KEY"] = key                       # העבודות הבאות של החלון יורשות אותו


# ═══════════════════════ זמנים וטקסט ═══════════════════════

def to_secs(v):
    """"12:30" / "1:02:03" / "750" / 750.5 / "12:30.5" → שניות. None אם לא מובן."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().strip("[]()").replace("״", "").replace("'", "")
    if re.fullmatch(r"\d+(\.\d+)?", s):
        return float(s)
    m = re.fullmatch(r"(\d+):(\d{1,2})(?::(\d{1,2}))?(?:[.,](\d+))?", s)
    if not m:
        return None
    a, b, c = int(m.group(1)), int(m.group(2)), m.group(3)
    v = a * 3600 + b * 60 + int(c) if c is not None else a * 60 + b
    return float(v) + (float("0." + m.group(4)) if m.group(4) else 0.0)


def mmss(t):
    t = int(round(t or 0))
    return "%d:%02d:%02d" % (t // 3600, t % 3600 // 60, t % 60) if t >= 3600 else "%d:%02d" % (t // 60, t % 60)


def mmss_t(t):
    t = round(t or 0, 1)
    h, r = divmod(t, 3600)
    return ("%d:%02d:%04.1f" % (h, r // 60, r % 60)) if h else ("%d:%04.1f" % (r // 60, r % 60))


def cues_to_words(cues):
    """כתוביות יוטיוב (מתגלגלות — כל שורה חוזרת) → רצף מילים עם זמן משוער לכל מילה."""
    seq = []
    for s, e, t in cues:
        w = t.split()
        k = next((k for k in range(min(len(w), len(seq)), 0, -1) if [x["word"] for x in seq[-k:]] == w[:k]), 0)
        new = w[k:]
        for i, x in enumerate(new):
            a = s + (e - s) * i / max(1, len(new))
            seq.append({"word": x, "start": round(a, 2), "end": round(a + (e - s) / max(1, len(new)), 2)})
    return seq


def words_to_lines(words, span=18.0):
    """שורות של ~18 שניות עם [זמן] בתחילת כל שורה — מה שהמודל קורא. נשבר רק אחרי פיסוק/הפסקה כשאפשר."""
    lines, cur, t0 = [], [], None
    for i, w in enumerate(words):
        if t0 is None:
            t0 = w["start"]
        cur.append(_BIDI.sub("", w["word"]).strip())
        gap = words[i + 1]["start"] - w["end"] if i + 1 < len(words) else 9
        long_ = w["end"] - t0
        if (long_ >= span and (w["word"].strip()[-1:] in ".?!,:" or gap > 0.5)) or long_ >= span * 1.7:
            lines.append((t0, " ".join(x for x in cur if x)))
            cur, t0 = [], None
    if cur:
        lines.append((t0, " ".join(x for x in cur if x)))
    return lines


def lines_text(lines):
    return "\n".join("[%s] %s" % (mmss(t), x) for t, x in lines)


# ═══════════════════════ ציטוטים מול התמלול ═══════════════════════

def _toks(s):
    return [MS.norm(x) for x in str(s or "").split() if MS.norm(x)]


def find_quote(words, quote, near, window=45.0, at_end=False):
    """מחפש את הציטוט ברצף המילים ליד הזמן שהוצע; אם לא נמצא טוב — בכל השיעור.
    מחזיר {"score", "t" (תחילת הציטוט / סוף הציטוט), "far"} או None."""
    q = _toks(quote)
    if not q or not words:
        return None
    qs = " ".join(q)
    nw = [MS.norm(w["word"]) for w in words]

    def best(idx):
        top = (0.0, None, None)
        for i in idx:
            for n in (len(q) - 1, len(q), len(q) + 1):
                if n < 1 or i + n > len(words):
                    continue
                s = " ".join(x for x in nw[i:i + n] if x)
                r = difflib.SequenceMatcher(None, qs, s, autojunk=False).ratio()
                if r > top[0]:
                    top = (r, i, i + n - 1)
        return top
    local = [i for i, w in enumerate(words) if near is None or abs(w["start"] - near) <= window]
    r, i, j = best(local)
    far = False
    if r < 0.75 and near is not None:
        r2, i2, j2 = best(range(len(words)))
        if r2 >= 0.75 and r2 > r + 0.1:
            r, i, j, far = r2, i2, j2, True
    if i is None:
        return None
    return {"score": round(r, 2), "i": i, "j": j, "t": words[j]["end"] if at_end else words[i]["start"], "far": far}


def context_text(words, a, b, pad=60.0):
    before = " ".join(w["word"].strip() for w in words if a - pad <= w["start"] < a)
    inside = " ".join(w["word"].strip() for w in words if a <= w["start"] < b)
    after = " ".join(w["word"].strip() for w in words if b <= w["start"] < b + pad)
    return before, inside, after


CAM_MIN_PIECE = 6.0        # כמו make_short / multi_piece_clip: חלק פתיחה קצר מזה גרם לקפיצות מצלמה (12/10)
TINY_PIECE = 3.0
LONG_SKIP = 40.0


def _word_text(words, a, b):
    return " ".join(w["word"].strip() for w in words if a - 0.05 <= w["start"] < b - 0.05)


def apply_pieces(p, words, cuts, old_skips=None, default_reason="ידני", reasons=None):
    """cuts = [(a, b), ...] בשניות מקור → p["pieces"] (המחרוזת שהוא עורך), הדילוגים (הטקסט שבין החלקים
    + סיבה), אורך, הקשר להצגה, ודגלים על החלקים. משמש גם את הבדיקה הראשונה וגם את העריכה בחלון."""
    cuts = [(float(a), float(b)) for a, b in cuts]
    p["pieces"] = ", ".join("%s-%s" % (mmss_t(a), mmss_t(b)) for a, b in cuts)
    p["seconds"] = round(sum(b - a for a, b in cuts), 1)
    p["start"], p["end"] = round(cuts[0][0], 2), round(cuts[-1][1], 2)
    skips = []
    for k in range(len(cuts) - 1):
        f, t = cuts[k][1], cuts[k + 1][0]
        reason = default_reason
        if reasons and k < len(reasons) and reasons[k]:
            reason = reasons[k]
        else:
            for o in old_skips or []:       # אותה סיבה לדילוג שנשאר פחות או יותר באותו מקום
                ov = min(t, o["to"]) - max(f, o["from"])
                if ov > 0.5 * max(0.1, min(t - f, o["to"] - o["from"])):
                    reason = o.get("reason") or default_reason
                    break
        skips.append({"from": round(f, 2), "to": round(t, 2), "text": _word_text(words, f, t)[:500], "reason": reason})
    p["skips"] = skips
    fl = []
    for k, (a, b) in enumerate(cuts):
        if b - a < TINY_PIECE:
            fl.append("חלק %d קצר מאוד (%.1f ש')" % (k + 1, b - a))
        elif k == 0 and len(cuts) > 1 and b - a < CAM_MIN_PIECE:
            fl.append("חלק הפתיחה קצר מ-%d שניות (%.1f) — עלול לגרום לקפיצות מצלמה" % (CAM_MIN_PIECE, b - a))
        if k and a < cuts[k - 1][1]:
            fl.append("חלקים %d ו-%d חופפים" % (k, k + 1))
    for k, sk in enumerate(skips):
        if sk["to"] - sk["from"] > LONG_SKIP:
            fl.append("דילוג %d ארוך (%.0f ש') — לוודא שלא מחבר שני עניינים נפרדים" % (k + 1, sk["to"] - sk["from"]))
    p["flags_pieces"] = fl
    s = SET.load()
    if p["seconds"] > s["max_len"]:
        fl.append("%.0f שניות — מעל %d" % (p["seconds"], s["max_len"]))
    bef, _, aft = context_text(words, cuts[0][0], cuts[-1][1])
    parts = []
    for k, (a, b) in enumerate(cuts):
        parts.append({"text": _word_text(words, a, b), "skip": False})
        if k < len(skips):
            parts.append({"text": skips[k]["text"], "skip": True, "reason": skips[k]["reason"]})
    p["context"] = {"before": bef[-600:], "inside": " ".join(x["text"] for x in parts if not x["skip"]),
                    "after": aft[:600], "parts": parts}
    p["flags"] = list(p.get("flags_q", [])) + fl
    return p


def _lesson_cap_score(cap, quote, near, at_end=False):
    """הציטוט מול כתוביות יוטיוב (קריאה שנייה): ציון ההתאמה, או None אם אין כתוביות."""
    if not cap or not quote:
        return None
    r = find_quote(cap, quote, near, window=60.0, at_end=at_end)
    return r["score"] if r else 0.0


def _segs_of(p):
    if p.get("segs"):
        return p["segs"]
    return [{"start": p.get("start"), "end": p.get("end"), "opening": p.get("opening"), "closing": p.get("closing")}]


def verify_pick(p, words, cap=None):
    """בודק פתיחה וסיום של *כל חלק* מול התמלול, מזיז את הזמנים לציטוטים שנמצאו, ומסמן מה לבדוק.
    cap = כתוביות יוטיוב כקריאה שנייה (רק כשהתמלול הראשי הוא Modal): ציטוט שהכתוביות שומעות אחרת — מסומן כספק."""
    flags = []
    segs = _segs_of(p)
    multi = len(segs) > 1
    cuts, checks = [], []
    uncertain = False
    for k, sg in enumerate(segs):
        pre = ("חלק %d: " % (k + 1)) if multi else ""
        a, b = sg.get("start"), sg.get("end")
        last = k == len(segs) - 1
        o = find_quote(words, sg.get("opening"), a) if sg.get("opening") else None
        c = find_quote(words, sg.get("closing"), b, at_end=True) if sg.get("closing") else None
        ck = {"opening": o and {x: o[x] for x in ("score", "far")},
              "closing": c and {x: c[x] for x in ("score", "far")}}
        if not sg.get("opening"):
            flags.append(pre + "אין ציטוט פתיחה — אי אפשר לוודא שהזמן נכון")
        elif not o or o["score"] < 0.6:
            flags.append(pre + "משפט הפתיחה לא נמצא בתמלול")
        else:
            if o["score"] < 0.8:
                flags.append(pre + "משפט הפתיחה נמצא רק בחלקו (%.0f%%)" % (o["score"] * 100))
            if o["far"]:
                flags.append(pre + "משפט הפתיחה נמצא ב-%s, רחוק מהזמן שהוצע (%s)" % (mmss(o["t"]), mmss(a or 0)))
            a = o["t"]
            cs = _lesson_cap_score(cap, sg.get("opening"), a)
            if cs is not None:
                ck["opening"]["cap"] = round(cs, 2)
                if cs < 0.6:
                    uncertain = True
                    flags.append(pre + "משפט הפתיחה נשמע אחרת בכתוביות יוטיוב (%.0f%%) — ייתכן שהתמלול טעה, לבדוק באוזן"
                                 % (cs * 100))
        if not sg.get("closing"):
            flags.append(pre + "אין ציטוט סיום")
        elif not c or c["score"] < 0.6:
            flags.append(pre + "משפט הסיום לא נמצא בתמלול")
        else:
            if c["score"] < 0.8:
                flags.append(pre + "משפט הסיום נמצא רק בחלקו (%.0f%%)" % (c["score"] * 100))
            if c["far"]:
                flags.append(pre + "משפט הסיום נמצא ב-%s, רחוק מהזמן שהוצע (%s)" % (mmss(c["t"]), mmss(b or 0)))
            b = c["t"]
            cs = _lesson_cap_score(cap, sg.get("closing"), b, at_end=True)
            if cs is not None:
                ck["closing"]["cap"] = round(cs, 2)
                if cs < 0.6:
                    uncertain = True
                    flags.append(pre + "משפט הסיום נשמע אחרת בכתוביות יוטיוב (%.0f%%) — ייתכן שהתמלול טעה, לבדוק באוזן"
                                 % (cs * 100))
            if last:
                # "לא לסיים כשהמשפט עוד נמשך" (12/10): אחרי הסיום — מה הרב אומר מיד אחר כך
                nxt = [w["word"].strip() for w in words[c["j"] + 1:c["j"] + 9]]
                p["after"] = " ".join(nxt)
                lw = words[c["j"]]["word"].strip()
                gap = words[c["j"] + 1]["start"] - words[c["j"]]["end"] if c["j"] + 1 < len(words) else 9
                if lw[-1:] not in ".?!" and gap < 0.35:
                    flags.append("ייתכן שהמשפט נמשך אחרי הסיום — לבדוק את ההמשך")
        if a is None or b is None or b <= a:
            flags.append(pre + "הזמנים לא הגיוניים — לתקן ידנית")
        else:
            cuts.append((a, b))
        checks.append(ck)
    p["check"] = checks[0] if not multi else {"opening": checks[0]["opening"], "closing": checks[-1]["closing"]}
    p["check_pieces"] = checks
    p["uncertain"] = uncertain
    p["flags_q"] = flags
    p["flags"] = list(flags)
    if cuts and len(cuts) == len(segs):
        reasons = []          # הסיבה ששלח המודל — לדילוג שאחרי כל חלק
        for sg in segs[:-1]:
            sk = sg.get("skip")
            reasons.append(str(sk.get("reason") or "").strip() if isinstance(sk, dict) else str(sk or "").strip())
        apply_pieces(p, words, cuts, default_reason="לא צוינה סיבה", reasons=reasons)
        if multi:
            p["opening"], p["closing"] = segs[0].get("opening", ""), segs[-1].get("closing", "")
    else:
        flags.append("הזמנים לא הגיוניים — לתקן ידנית")
        p["flags_q"] = flags
        p["flags"] = list(flags)
    p["bad"] = any(("לא נמצא" in f or "לא הגיוני" in f or "אין ציטוט פתיחה" in f or "חופפים" in f) for f in p["flags"])
    return p


def collapse_segs(p):
    """הגדרת "דילוגים אוטומטיים" כבויה: כל שורט הוא רצף אחד — מהפתיחה של החלק הראשון עד הסיום של האחרון."""
    sg = p.get("segs") or []
    if len(sg) > 1:
        p["segs"] = [{"start": sg[0].get("start"), "end": sg[-1].get("end"),
                      "opening": sg[0].get("opening"), "closing": sg[-1].get("closing")}]
        return True
    return False


def snapshot(p):
    """מה שהמודל הציע — כדי ש"↺ חזרה להצעה של Gemini" תחזיר בדיוק אותו (נשמר פעם אחת, לפני העריכה הראשונה)."""
    return {k: json.loads(json.dumps(p.get(k))) for k in ("pieces", "segs", "start", "end", "opening", "closing")}


def ctx_words(words, p, pad=45.0):
    """הטקסט המלא של הקטע לבחירה בעכבר: מילים בחלון סביב הקטע — [אינדקס בשיעור, מילה, התחלה, סוף, מצב];
    מצב 1 = בתוך השורט, 2 = דילוג בתוך הקטע, 0 = מחוץ לו."""
    try:
        cuts = MS.parse_pieces(p.get("pieces") or "")
    except Exception:
        cuts = []
    if not cuts or not words:
        return []
    a0, b0 = cuts[0][0] - pad, cuts[-1][1] + pad
    out = []
    for i, w in enumerate(words):
        if w["end"] < a0:
            continue
        if w["start"] > b0:
            break
        t = _BIDI.sub("", w["word"]).strip()
        if not t:
            continue
        mid = (w["start"] + w["end"]) / 2
        inside = any(a - 0.02 <= mid <= b + 0.02 for a, b in cuts)
        span = cuts[0][0] - 0.02 <= mid <= cuts[-1][1] + 0.02
        out.append([i, t, round(w["start"], 2), round(w["end"], 2), 1 if inside else (2 if span else 0)])
    return out


def _gap_before(words, i):
    w = words[i]
    if i == 0:
        return max(0.0, w["start"] - 0.05)
    prev = words[i - 1]["end"]
    gap = w["start"] - prev
    return round(prev + gap / 2, 2) if gap > 0.12 else round(max(prev, w["start"] - 0.03), 2)


def _gap_after(words, i):
    w = words[i]
    if i + 1 >= len(words):
        return round(w["end"] + 0.05, 2)
    nxt = words[i + 1]["start"]
    gap = nxt - w["end"]
    return round(w["end"] + gap / 2, 2) if gap > 0.12 else round(min(nxt, w["end"] + 0.03), 2)


def merge_cuts(cuts, join=0.35):
    out = []
    for a, b in sorted(cuts):
        if out and a <= out[-1][1] + join:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def subtract_cuts(cuts, s, e):
    out = []
    for a, b in cuts:
        if e <= a or s >= b:
            out.append((a, b))
            continue
        if s - a > 0.05:
            out.append((a, s))
        if b - e > 0.05:
            out.append((e, b))
    return out


def retarget(p, words, cap, cuts):
    """חלקים חדשים (cuts) → ציטוטי פתיחה/סיום מהתמלול עצמו, ואז אותה בדיקה כמו להצעה של המודל
    (ציטוטים, אורך, דגלים). הסיבות של דילוגים קיימים נשמרות לדילוג שנשאר בערך באותו מקום."""
    old = p.get("skips") or []
    segs = []
    for k, (a, b) in enumerate(cuts):
        ws = [x for x in words if a - 0.02 <= (x["start"] + x["end"]) / 2 <= b + 0.02 and _BIDI.sub("", x["word"]).strip()]
        t = [_BIDI.sub("", x["word"]).strip() for x in ws]
        seg = {"start": a, "end": b, "opening": " ".join(t[:8]), "closing": " ".join(t[-8:])}
        if k < len(cuts) - 1:
            f, to = cuts[k][1], cuts[k + 1][0]
            reason = "ידני"
            for o in old:
                ov = min(to, o["to"]) - max(f, o["from"])
                if ov > 0.5 * max(0.1, min(to - f, o["to"] - o["from"])):
                    reason = o.get("reason") or "ידני"
                    break
            seg["skip"] = {"text": "", "reason": reason}
        segs.append(seg)
    p["segs"] = segs
    p["start"], p["end"] = cuts[0][0], cuts[-1][1]
    p["opening"], p["closing"] = segs[0]["opening"], segs[-1]["closing"]
    p["edited_times"] = True
    p["user_edited"] = True
    verify_pick(p, words, cap)
    return p


def edit_words(p, words, cap, op, i0, i1):
    """בחירה בעכבר בטקסט המלא: op="add" — המילים i0..i1 נכנסות לשורט; op="remove" — יוצאות (דילוג).
    גבולות במרכז ההפסקה שבין המילים; 'הכן' מצמיד אותם אחר כך להפסקה הנמדדת."""
    if not words:
        raise ValueError("אין תמלול לשיעור הזה")
    i0, i1 = sorted((int(i0), int(i1)))
    if i0 < 0 or i1 >= len(words):
        raise ValueError("הבחירה מחוץ לטקסט")
    cuts = MS.parse_pieces(p.get("pieces") or "")
    s, e = _gap_before(words, i0), _gap_after(words, i1)
    if op == "add":
        cuts = merge_cuts(list(cuts) + [(s, e)])
    elif op == "remove":
        cuts = subtract_cuts(cuts, s, e)
    else:
        raise ValueError("פעולה לא מוכרת")
    cuts = [c for c in cuts if c[1] - c[0] >= 0.3]
    if not cuts:
        raise ValueError("זה כל הקטע — אם לא רוצים אותו, \"🗑️ ויתרתי\"")
    p.setdefault("orig", snapshot(p))
    return retarget(p, words, cap, cuts)


def revert_pick(p, words, cap):
    """↺ חזרה להצעה של Gemini — הזמנים והציטוטים כמו שהוצעו, ואותה בדיקה."""
    o = p.pop("orig", None)
    if not o:
        raise ValueError("אין מה להחזיר — הקטע לא שונה")
    for k, v in o.items():
        if v is None:
            p.pop(k, None)
        else:
            p[k] = v
    p.pop("edited_times", None)
    verify_pick(p, words, cap)
    return p


def edit_skips(p, words, op, arg):
    """עריכה ידנית של דילוגים (החלון): op="drop" — arg=אינדקס הדילוג (מחבר את שני החלקים);
    op="add" — arg="12:40-12:46" (חותך את החלק שמכיל אותו לשניים)."""
    import make_short as _MS
    cuts = _MS.parse_pieces(p.get("pieces", ""))
    if not p.get("manual"):
        p.setdefault("orig", snapshot(p))
    if op == "drop":
        k = int(arg)
        if not 0 <= k < len(cuts) - 1:
            raise ValueError("אין דילוג כזה")
        cuts[k:k + 2] = [(cuts[k][0], cuts[k + 1][1])]
    elif op == "add":
        a, b = _MS.parse_pieces(arg)[0]
        for k, (ca, cb) in enumerate(cuts):
            if ca - 0.05 <= a and b <= cb + 0.05:
                new = [x for x in ((ca, a), (b, cb)) if x[1] - x[0] > 0.2]
                if len(new) < 2 and (a - ca < 0.2 or cb - b < 0.2) and len(new) == 1:
                    raise ValueError("הדילוג בקצה הקטע — לקצר את הזמנים בשדה במקום")
                cuts[k:k + 1] = new
                break
        else:
            raise ValueError("הדילוג צריך להיות בתוך אחד החלקים")
    else:
        raise ValueError("פעולה לא מוכרת")
    apply_pieces(p, words, cuts, old_skips=p.get("skips"))
    p["edited_times"] = True
    p["user_edited"] = True
    return p


# ═══════════════════════ קריאת התשובה ═══════════════════════

ALIASES = {
    "start": ["start", "from", "begin", "התחלה", "זמן התחלה", "מ"], "end": ["end", "to", "finish", "סיום", "זמן סיום", "עד"],
    "opening": ["opening", "opening_quote", "first_words", "משפט פתיחה", "פתיחה", "ציטוט פתיחה"],
    "closing": ["closing", "closing_quote", "last_words", "משפט סיום", "ציטוט סיום"],
    "title": ["title", "כותרת"], "description": ["description", "desc", "תיאור"], "tags": ["tags", "תגיות"],
    "hook": ["hook", "hook_why", "ההוק", "הוק"], "type": ["type", "סוג"], "message": ["message", "מסר"],
    "lesson": ["lesson", "lesson_number", "שיעור", "מספר שיעור"], "score": ["score", "ציון"],
    "why": ["why", "reason", "נימוק", "למה"], "fidelity": ["fidelity", "נאמנות"],
    "pieces": ["pieces", "segments", "parts", "חלקים"],
    "skip": ["skip_after", "skip", "skipped", "דילוג"],
    "emphasis": ["emphasis", "enlarge", "big_words", "emphasis_words", "הגדלה", "מילים להגדלה"],
    "hook_quote": ["hook_quote", "hook_line", "opening_hook", "משפט הוק", "ציטוט הוק"],     # 🎬 6/11
}


def _get(d, key):
    for k in ALIASES[key]:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return None


def _repair(s):
    """JSON שהודבק מצ'אט: מירכאות "חכמות", ז"ל/רז"ל בתוך מחרוזת, פסיקים מיותרים."""
    s = s.replace("“", '"').replace("”", '"').replace("„", '"')
    s = re.sub(r'(?<=[א-ת])"(?=[א-ת])', "״", s)
    s = re.sub(r",\s*([\]}])", r"\1", s)
    return s


def _json_chunks(text):
    fences = re.findall(r"```(?:json|JSON)?\s*(.*?)```", text, re.S)
    for body in fences + [text]:
        body = body.strip()
        for o, c in (("[", "]"), ("{", "}")):
            a, b = body.find(o), body.rfind(c)
            if a != -1 and b > a:
                yield body[a:b + 1]


def parse_answer(text, notes=None):
    """תשובת המודל (מ-Gemini או מהדבקה) → רשימת הצעות. סובלני: גדרות קוד, מירכאות, mm:ss.
    notes (כרטיס 25) — אם ניתנה רשימה, נכנסים אליה אובייקטים "לא מצאתי": {"lesson", "note"} (בקשה חופשית שאין לה מקום בתמלול)."""
    data = None
    for chunk in _json_chunks(text or ""):
        for s in (chunk, _repair(chunk)):
            try:
                data = json.loads(s)
                break
            except ValueError:
                continue
        if data is not None:
            break
    raw = []
    if isinstance(data, dict):
        for k in ("picks", "clips", "shorts", "segments", "הצעות", "קטעים"):
            if isinstance(data.get(k), list):
                raw = data[k]
                break
        else:
            lessons = [v for v in data.values() if isinstance(v, list)]
            raw = [x for v in lessons for x in v] if lessons else [data]
    elif isinstance(data, list):
        raw = data
    if not raw:
        raw = _parse_loose(text or "")
    out = []
    for r in raw:
        if not isinstance(r, dict):
            continue
        nf = r.get("not_found", r.get("notfound", r.get("לא_נמצא")))
        if nf is True or str(nf).lower() in ("true", "כן") :
            if notes is not None:
                try:
                    nl = int(re.sub(r"\D", "", str(r.get("lesson", ""))) or 0) or None
                except ValueError:
                    nl = None
                notes.append({"lesson": nl, "note": str(r.get("note") or r.get("why") or r.get("הערה") or "").strip()})
            continue
        p = {"start": to_secs(_get(r, "start")), "end": to_secs(_get(r, "end"))}
        if str(r.get("for_request", "")).lower() in ("true", "כן", "1"):
            p["for_request"] = True              # הקטע הזה נבחר בגלל הבקשה החופשית שלו
        for k in ("opening", "closing", "title", "description", "hook", "type", "message", "why"):
            v = _get(r, k)
            p[k] = str(v).strip() if v is not None else ""
        raw_segs = _get(r, "pieces")
        if isinstance(raw_segs, list):
            segs = []
            for sg in raw_segs:
                if not isinstance(sg, dict):
                    continue
                s_, e_ = to_secs(_get(sg, "start")), to_secs(_get(sg, "end"))
                if s_ is None and e_ is None and not _get(sg, "opening"):
                    continue
                sk = _get(sg, "skip")
                if isinstance(sk, dict):
                    sk = {"text": str(sk.get("text") or sk.get("quote") or "").strip(),
                          "reason": str(sk.get("reason") or sk.get("why") or sk.get("סיבה") or "").strip()}
                segs.append({"start": s_, "end": e_, "opening": str(_get(sg, "opening") or "").strip(),
                             "closing": str(_get(sg, "closing") or "").strip(), "skip": sk})
            if segs:
                p["segs"] = segs
                p["start"], p["end"] = segs[0]["start"], segs[-1]["end"]
                p["opening"], p["closing"] = segs[0]["opening"], segs[-1]["closing"]
        tags = _get(r, "tags")
        p["tags"] = ", ".join(str(t).strip().lstrip("#") for t in tags) if isinstance(tags, list) else str(tags or "")
        les = _get(r, "lesson")
        try:
            p["lesson"] = int(re.sub(r"\D", "", str(les))) if les is not None and re.search(r"\d", str(les)) else None
        except ValueError:
            p["lesson"] = None
        sc = _get(r, "score")
        try:
            p["score"] = float(sc) if sc is not None else None
        except (TypeError, ValueError):
            p["score"] = None
        fid = _get(r, "fidelity")
        p["fidelity"] = fid if isinstance(fid, dict) else ({"note": str(fid)} if fid else {})
        # 🔠 כרטיס 15: המילים שהמודל מציע להגדיל — נשמרות תמיד עם הקטע; נחשפות רק כשהוא מדליק את המתג
        em = _get(r, "emphasis")
        p["emphasis"] = EM.clean_picks(em if isinstance(em, list) else ([em] if isinstance(em, str) else []))
        hq = _get(r, "hook_quote")                     # 🎬 6/11: משפט ההוק — מאומת מול התמלול הסופי בצריבה (hook_clip.find_span)
        p["hook_quote"] = " ".join(str(hq).split()) if isinstance(hq, (str, int, float)) else ""
        if p["start"] is None and p["end"] is None and not p["opening"]:
            continue
        out.append(p)
    return out


def _parse_loose(text):
    """כשאין JSON בכלל — תשובה בטקסט חופשי: "12:30-13:15" + שורות "כותרת: ..."."""
    rng = re.compile(r"(\d{1,2}:\d{2}(?::\d{2})?)\s*[-–—עד]+\s*(\d{1,2}:\d{2}(?::\d{2})?)")
    blocks, cur = [], None
    for line in text.splitlines():
        m = rng.search(line)
        if m:
            cur = {"start": m.group(1), "end": m.group(2)}
            blocks.append(cur)
            lm = re.search(r"שיעור\s*(\d+)", line)
            if lm:
                cur["lesson"] = lm.group(1)
            continue
        if cur is None:
            continue
        fm = re.match(r"\W*(כותרת|תיאור|תגיות|משפט פתיחה|משפט סיום|פתיחה|סיום|שיעור)\W*[:：]\s*(.+)", line.strip())
        if fm:
            k = {"פתיחה": "משפט פתיחה", "סיום": "משפט סיום"}.get(fm.group(1), fm.group(1))
            cur[k] = fm.group(2).strip().strip('"«»')
    return blocks


def clean_desc(desc, rabbi):
    """התיאור — רק הגוף. קישורים, הרשמה וסדרה מתווספים לבד; מודל שהוסיף אותם — יוצאים."""
    # 3.4: שם הישיבה מההגדרות (📝), לא שם קבוע בקוד — שורה שנגמרת בו היא שורת סדרה שהמודל הוסיף
    org = (SET.load().get("org_name") or "").strip()
    pat = r"https?://|לצפייה ב|הירשמו|◄|^#" + (r"|" + re.escape(org) + r"\s*$" if org else "")
    keep = [l for l in (desc or "").splitlines() if not re.search(pat, l.strip())]
    return "\n".join(keep).strip()


def clean_tags(tags, rabbi):
    """🚨 Gemini המציא את "הרב חיים ירבי" בתגיות (17/9) — תגית עם "הרב" שאינה הרב מהכותרת יוצאת."""
    out = []
    for t in re.split(r"[,\n]", tags or ""):
        t = t.strip().lstrip("#").replace("_", " ").strip()
        if not t or t in out:
            continue
        if re.search(r"(^|\s)(הרב|הרה\"ג|רבי)\s", t + " ") and MS.norm(t) != MS.norm(rabbi or ""):
            continue
        if "אתר ישיבה" in t:
            continue
        out.append(t)
    return ", ".join(out[:15])


# ═══════════════════════ ההוראות למודל ═══════════════════════

FIDELITY_Q = ["המסר מובן לצופה שלא שמע שום דבר אחר מהשיעור",
              "זה מה שהרב התכוון לומר — לא חיבור של שני עניינים, לא עמדה שהוא מביא כדי לדחות, לא משמעות שמתהפכת בלי ההקשר",
              "עומד בהנחיות התוכן של הערוץ",
              "הסוף לא נקטע באמצע משפט או לפני מסקנה, וההתחלה לא באמצע מחשבה"]


def guidelines_text():
    """ההנחיות האישיות שלו (עם הקישורים של בית אל) — בלי פורמט התשובה ובלי "טיפול בתקלות" שנכתבו
    לקישור וידאו; הפורמט כאן הוא JSON."""
    try:
        g = GUIDELINES.read_text(encoding="utf-8")
    except OSError:
        return ""
    g = re.sub(r"ב\. פורמט התשובה:.*?(?=ג\. תוכן התיאור)", "", g, flags=re.S)
    g = re.split(r"טיפול בתקלות:", g)[0]
    return g.strip()


def _rules(s, playlist):
    if playlist:
        return ("- מכל שיעור: עד %(playlist_picks)d קטעים — הטוב ביותר בלבד (בסריקת סדרה אין קטע נוסף, גם כשהקטע קצר).\n"
                "- אורך: להשתדל ל-%(ideal_min)d–%(ideal_max)d שניות, לעולם לא יותר מ-%(max_len)d. "
                "קטע של %(short_min)d–%(short_max)d שניות מצוין כשהוא עומד לבד.\n" % s)
    return ("- אורך: להשתדל ל-%(ideal_min)d–%(ideal_max)d שניות, לעולם לא יותר מ-%(max_len)d. קטע של "
            "%(short_min)d–%(short_max)d שניות מצוין כשהוא עומד לבד (משפט חד, פאנץ', תשובה קצרה וחזקה).\n"
            "- כמות: בדרך כלל עד %(max_long)d שורטס מהשיעור; אם לפחות %(min_short_for_extra)d מהם קצר "
            "(%(short_min)d–%(short_max)d שניות) — עד %(max_with_short)d. זו תקרה, לא יעד: קטע חלש לא מציעים כדי להשלים מספר.\n"
            "- החזר עד %(n)d הצעות, מהטובה לחלשה (אני אבחר מהן).\n" % dict(s, n=s["max_with_short"] + 1))


def exclude_text(exclude):
    """"אל תציע שוב" — קטעים שהמשתמש ויתר עליהם (מכפתור "חפש קטעים אחרים בשיעור")."""
    if not exclude:
        return ""
    rows = "\n".join("  • %s–%s%s" % (mmss(e["from"]), mmss(e["to"]), (" «%s»" % e["title"]) if e.get("title") else "")
                     for e in exclude)
    return ("🚨 המשתמש כבר ראה וויתר על הקטעים הבאים — אל תציע אותם שוב, וגם לא קטע שחופף להם במידה ניכרת "
            "(חפש מקומות אחרים בשיעור):\n" + rows)


def request_text(lessons, request="", playlist=False):
    """כרטיס 25 (1/11/2026): "מה לחפש" — בקשה חופשית שלו לצד הקישור ("הקטע שבו הרב דיבר על הילדות שלו", "ובנוסף עוד
    שני קטעים חזקים"). בלוק אחד שנכנס להנחיות; ריק = לא נכנס שום דבר (ההנחיות זהות לתמיד). בקשה אחת לכולם, או (כשכמה
    שיעורים בודדים נשאלים יחד) בקשה לכל שיעור. המודל חייב לומר "לא מצאתי" במקום להמציא."""
    request = " ".join(str(request or "").split())
    per = {l["n"]: " ".join(str(l.get("request") or "").split()) for l in lessons}
    if request:
        who = "הבקשה חלה על כל שיעור לחוד" if len(lessons) > 1 else "הבקשה"
        body = "%s: «%s»" % (who, request)
    elif any(per.values()):
        body = "בקשות לפי שיעור:\n" + "\n".join("  • שיעור %d: %s" % (n, ("«%s»" % t) if t else "(אין בקשה מיוחדת — בחירה רגילה)")
                                              for n, t in per.items())
    else:
        return ""
    return ("🎯 בקשה מיוחדת של המשתמש — היא קובעת מה לבחור:\n" + body + "\n"
            "- אם הבקשה היא על קטע מסוים (נושא, סיפור, אדם, מקום) — החזר את הקטע/ים שמתאימים לה, ובכל אחד \"for_request\": true. "
            "אם הבקשה רק על קטע מסוים (בלי \"ובנוסף\"/\"עוד\") — החזר רק אותו (ואם יש כמה מקומות שמתאימים, עד שלושה מהטוב לחלש), בלי הצעות כלליות.\n"
            "- מספר קטעים: אם הבקשה מציינת מספר (\"עוד שני קטעים\", \"שלושה\") — זה המספר. אם לא — כללי הכמות הרגילים למעלה "
            "(תקרה, לא יעד). \"ובנוסף קטעים חזקים\" = קטעים חזקים לפי הכללים הרגילים, בלי \"for_request\".\n"
            "- 🚨 אם מה שביקשו לא מופיע בתמלול — אל תמציא, ואל תציג קטע אחר כאילו הוא מתאים. החזר במקומו אובייקט "
            "{\"not_found\": true, \"lesson\": מספר השיעור, \"note\": \"שורה אחת: מה לא נמצא, ואם יש משהו קרוב — על מה הרב כן מדבר שם\"}.\n"
            "- כל שאר הכללים (ציטוטים מילה במילה, נאמנות, אורך, שם הרב) נשארים בדיוק כמו שהם.")


def build_prompt(lessons, playlist=False, series_title="", multi=False, exclude=None, mixed=False, request=""):
    """lessons = [{"n", "title", "rabbi", "duration", "text"}]. מחזיר טקסט אחד — אותו טקסט ל-Gemini
    ולהעתקה לצ'אט, כדי ששתי הדרכים יקבלו בדיוק אותן הוראות.
    playlist = סריקת פלייליסט "קטע מכל שיעור" (ציון, קטע אחד לשיעור). multi = שלב ב' של פלייליסט גדול:
    כמה שיעורים בבקשה, אבל לכל שיעור כללי שיעור רגיל (כמה קטעים, דילוגים) + שדה lesson. exclude = ויתורים."""
    s = SET.load()
    names = sorted({l["rabbi"] for l in lessons if l.get("rabbi")})
    many = playlist or multi or mixed
    head = ("אתה עורך שורטס (סרטונים אנכיים קצרים) ל%s. " % SET.channel_phrase(s) +
            "לפניך תמלול אוטומטי של %s, עם זמן [דקות:שניות] בתחילת כל שורה. "
            "התמלול אוטומטי ויש בו שגיאות מילים — זה בסדר; את הציטוטים העתק בדיוק כפי שהם כתובים בתמלול.\n"
            % ("כמה שיעורים נפרדים" if mixed else
               "כמה שיעורים מתוך סדרה" + (" (\"%s\")" % series_title if series_title else "") if many else "שיעור"))
    task = []
    if mixed:
        # 28/10: שיעורים בודדים שנשלחו בסמוך — בקשה אחת (חיסכון במכסה), אבל כל שיעור לגמרי לחוד
        task.append("המשימה: לבחור מכל שיעור את הקטעים הכי טובים לשורטס — כל שיעור לחוד, כאילו הוא היחיד, לפי הכללים "
                    "למטה. השיעורים לא קשורים זה לזה. בכל קטע ציין את מספר השיעור (lesson).")
    elif multi:
        task.append("המשימה: לבחור מכל שיעור את הקטעים הכי טובים לשורטס — כל שיעור לחוד, לפי הכללים למטה. "
                    "אלה שיעורים שנבחרו כחזקים בסדרה, ולכן הדגש הוא על קטעים שמבטאים את הרעיון המרכזי של הסדרה. "
                    "חפש גם \"פאנץ'\": משפט חד שעומד לבד. בכל קטע ציין את מספר השיעור (lesson).")
    elif playlist:
        task.append("המשימה: לבחור מכל שיעור את הקטע הכי טוב לשורט. 🚨 בסדרה הדגש הוא על קטעים שמבטאים את "
                    "הרעיון המרכזי של הסדרה — לא על הסיפור הכי משעשע. חפש גם \"פאנץ'\": משפט חד שעומד לבד "
                    "(\"אין דבר כזה...\", \"תדעו לכם...\"), לא רק סיפורים ומשלים. "
                    "לכל קטע תן ציון 1–10 (score): כמה הוא חזק לשורט וכמה הוא מבטא את עיקר הסדרה.")
    else:
        task.append("המשימה: לבחור את הקטעים הכי טובים לשורטס מתוך השיעור.")
    task.append("כללי אורך וכמות (גוברים על כל מספר אחר שמופיע בהנחיות למטה):\n" + _rules(s, playlist))
    task.append("🚨 שם הרב: %s — רק מכותרת הסרטון. אל תכתוב שם של רב אחר בשום מקום (גם לא בתגיות), "
                "ואל תייחס דברים לדובר אחר." % (" / ".join(names) if names else "לא ידוע — אל תכתוב שם רב בכלל"))
    rbw = RB.prompt_text(names)             # כרטיס 25: מילים ושמות שהרב הזה אומר (מהפרופיל) — ריק לרוב הרבנים
    if rbw:
        task.append(rbw.strip())
    rq = request_text(lessons, request, playlist)
    if rq:
        task.append(rq)
    skips = s["auto_skips"]
    if skips:
        span = ("- pieces — מערך של חלקים לפי הסדר. כל חלק: start / end (דקות:שניות כפי שבתמלול), opening — 6–12 המילים "
                "הראשונות של החלק ו-closing — 6–12 המילים האחרונות שלו, מועתקות מילה במילה מהתמלול. "
                "בדוק שהמילים שאחרי ה-closing של החלק האחרון לא ממשיכות את אותו משפט — אם כן, סיים מאוחר יותר או במקום אחר.\n"
                "  • חלק אחד בלבד כשהקטע נקי — זה המצב הרגיל. אל תמציא דילוגים כדי שיהיה.\n"
                "  • דילוג = קטע של 2 שניות ומעלה שנחתך מתוך האמצע, רק כשהוא פוגע בקטע: גמגום, חזרה על אותה מילה/משפט, "
                "הערה צדדית, סוגריים שקוטעים את הרעיון, חיפוש ציטוט או בקשת עזרה מהשומעים. ה-skip_after של חלק = "
                "{\"text\": 5–10 מילים מהטקסט שדולג (מילה במילה), \"reason\": סיבה בשורה אחת}. לחלק האחרון אין skip_after.\n"
                "  • 🚨 נאמנות (שער 1ב): לעולם לא מדלגים כך שנוצרת טענה שהרב לא טען — לא מחברים שני עניינים נפרדים, "
                "תיקון עצמי נשאר יחד עם הטענה שהוא מתקן, «קודם כל… ועוד… אבל…» נכנסים יחד או לא נכנסים, «כנראה» לא הופך לקביעה. "
                "אם הדילוג משנה את המשמעות — לא מדלגים.\n"
                "  • חלק הפתיחה — לפחות 6 שניות (חלקים קצרים בפתיחה גורמים לקפיצות מצלמה); שום חלק לא קצר מ-3 שניות; "
                "עד 3 דילוגים בקטע. האורך שנספר הוא סכום החלקים בלבד.\n")
    else:
        span = ("- start / end — זמן התחלה וסיום (דקות:שניות), כפי שהם בתמלול. קטע אחד רצוף, בלי דילוגים.\n"
                "- opening — 6–12 המילים הראשונות של הקטע, מועתקות מילה במילה מהתמלול.\n"
                "- closing — 6–12 המילים האחרונות של הקטע, מועתקות מילה במילה מהתמלול. בדוק שהמילים שאחריהן "
                "בתמלול לא ממשיכות את אותו משפט — אם כן, סיים מאוחר יותר או במקום אחר.\n")
    task.append("לכל קטע:\n" + span +
                "- title — כותרת קצרה ומסקרנת, עדיף משפט חד מתוך דברי הרב עצמו (\"הבטחה שלא יכולה להתקיים\") "
                "ולא שאלה ארוכה ומסבירה. בלי שם הרב ובלי האשטגים.\n"
                "- description — רק גוף התיאור (2–4 שורות): השאלה, המתח והרמז — ועצור. 🚨 לא לגלות את התשובה "
                "ולא לסיים ב\"הרב מבאר ש...\". בלי קישורים, בלי שורת הרשמה, בלי שם הסדרה — הם מתווספים לבד.\n"
                "- tags — 5–10 תגיות מופרדות בפסיק, בלי #.\n"
                "- hook — שורה אחת: למה 5 השניות הראשונות מחזיקות צופה.\n"
                "- type — סיפור / משל / פאנץ' / עיקרון.\n"
                "- message — המסר של הקטע במשפט אחד, מתוך הקטע בלבד.\n"
                "- emphasis — מילים שכדאי להגדיל בכתוביות. הכתוביות מוצגות בשורות של עד כ-7 מילים; בכל שורה כזאת "
                "0–2 מילים לכל היותר (ברוב השורות — אף אחת). בחר את המילה שנושאת את המשמעות או את הניגוד "
                "(\"דווקא\", \"אסור\", \"כולם\", מילת המפתח של הרעיון) — לא מילת קישור, ולא סתם המילה שהרב האריך בה. "
                "לכל מילה: {\"word\": המילה כפי שהיא בתמלול, \"quote\": 3–6 מילים רצופות מהתמלול שכוללות אותה, "
                "מועתקות מילה במילה}. רק מתוך הקטע עצמו.\n"
                "- hook_quote — 🎬 ההוק: הרגע החזק ביותר *בתוך הקטע* (4–10 מילים, 1.5–3.2 שניות דיבור), שישמע בהתחלה לפני "
                "הקטע עצמו כדי לתפוס את הצופה, ואז הקטע מתחיל כרגיל כולל אותו רגע שוב. רצף מילים אחד מהקטע, מועתק מילה "
                "במילה, משפט או חצי משפט שלם ונקי (בלי גמגום), ושעומד בפני עצמו. לא משפט שמגלה את התשובה/המסקנה "
                "(ספוילר), לא ציטוט שמטעה מחוץ להקשרו, ולא משפט שכבר פותח את הקטע. עדיף חידה, קביעה מפתיעה או שאלה.\n"
                "- fidelity — שער הנאמנות: ענה true/false על כל שאלה, ו-note אם יש ספק:\n"
                + "".join("    q%d: %s\n" % (i + 1, q) for i, q in enumerate(FIDELITY_Q)))
    if many:
        task.append("- lesson — מספר השיעור (כפי שמופיע בכותרת \"### שיעור N\").")
    if playlist:
        task.append("- score — 1–10.")
    where = ('"pieces": [{"start": "12:30", "end": "12:52", "opening": "...", "closing": "...", '
             '"skip_after": {"text": "...", "reason": "גמגום וחזרה"}}, '
             '{"start": "12:58", "end": "13:21", "opening": "...", "closing": "..."}], ' if skips else
             '"start": "12:30", "end": "13:05", "opening": "...", "closing": "...", ')
    fmt = ("פורמט התשובה: JSON בלבד — מערך של אובייקטים, בלי שום טקסט לפניו או אחריו. דוגמה למבנה:\n"
           '[{%s%s"title": "...", '
           '"description": "...", "tags": "..., ...", "hook": "...", "type": "סיפור", "message": "...", '
           '"emphasis": [{"word": "...", "quote": "..."}], "hook_quote": "...", '
           '"fidelity": {"q1": true, "q2": true, "q3": true, "q4": true, "note": ""}%s}]'
           % ('"lesson": 1, ' if many else "", where, ', "score": 8' if playlist else ""))
    parts = [head, "\n".join(task), fmt]
    if exclude:
        parts.append(exclude_text(exclude))
    g = guidelines_text()
    if g:
        parts.append("הנחיות הערוץ (סגנון, הוק, תיאור — לפי מה שכתוב כאן; כללי האורך והכמות שלמעלה גוברים):\n" + g)
    body = []
    for l in lessons:
        body.append("### שיעור %d: %s%s\n%s" % (l["n"], l["title"],
                                                 " (אורך %s)" % mmss(l["duration"]) if l.get("duration") else "",
                                                 l["text"]))
    parts.append("התמלול:\n\n" + "\n\n".join(body))
    parts.append("זכור: JSON בלבד, ציטוטים מילה במילה מהתמלול.")
    return "\n\n".join(parts)


# ═══════════════════════ מצב הבחירה (pick.json) ═══════════════════════

def load(P):
    return json.load(open(Path(P) / PICK, encoding="utf-8"))


def save(P, st):
    tmp = Path(P) / (PICK + ".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(Path(P) / PICK)


def lesson_words(P, les):
    f = Path(P) / les["words"]
    return json.load(open(f, encoding="utf-8"))["words"] if f.exists() else []


def lesson_cap(P, les):
    """כתוביות יוטיוב כקריאה שנייה — רק כשהתמלול הראשי הוא Modal (אחרת זה אותו טקסט)."""
    if not les.get("cap_words") or not str(les.get("source", "")).startswith("Modal"):
        return None
    f = Path(P) / les["cap_words"]
    return json.load(open(f, encoding="utf-8"))["words"] if f.exists() else None


def make_chunks(st):
    """את השיעורים לחלקים: לכל חלק — הוראות + תמלולים, בגודל שהצ'אט / Gemini מקבלים."""
    s = SET.load()
    strong = st.get("mode") == "strong"          # פלייליסט גדול: הצעות רק לשיעורים שנבחרו בשלב ב' (stage_b)
    ok = [l for l in st["lessons"] if l.get("text_file") and (not strong or l.get("stage_b"))]
    texts = {l["n"]: (Path(st["dir"]) / l["text_file"]).read_text(encoding="utf-8") for l in ok}
    chunks = {}
    for mode, lim in (("chat", s["chat_chunk_chars"]), ("gemini", s["gemini_chunk_chars"])):
        cur, size, out = [], 0, []
        for l in ok:
            n = len(texts[l["n"]])
            if cur and size + n > lim:
                out.append(cur)
                cur, size = [], 0
            cur.append(l["n"])
            size += n
        if cur:
            out.append(cur)
        chunks[mode] = [{"mode": mode, "lessons": ls, "id": "%s%d" % (mode[0], i + 1), "status": _old_status(st, mode, ls)}
                        for i, ls in enumerate(out)]
        # "🔍 חפש קטעים אחרים בשיעור" — בקשה נפרדת לשיעור אחד, עם רשימת מה שוויתר עליו
        for m in st.get("more", []):
            if any(l["n"] == m["lessons"][0] for l in ok):
                chunks[mode].append({"mode": mode, "lessons": m["lessons"], "id": "%sx%d" % (mode[0], m["k"]),
                                     "status": m.get("status", "pending"), "exclude": m["exclude"]})
    st["chunks"] = chunks
    make_rank_chunks(st)
    return texts


def make_rank_chunks(st):
    """שלב א' (פלייליסט גדול): כרטיסי השיעורים נארזים לבקשות דירוג — מעט בקשות (כרטיס ≈ 1,200 תווים)."""
    if st.get("mode") != "strong":
        st.pop("rchunks", None)
        return
    s = SET.load()
    st["rchunks"] = {}
    for mode, lim, pre in (("chat", s["chat_chunk_chars"], "rc"), ("gemini", s["gemini_chunk_chars"], "rg")):
        cur, size, out = [], 0, []
        for l in st["lessons"]:
            n = len(rank_card_text(l))
            if cur and size + n > lim:
                out.append(cur)
                cur, size = [], 0
            cur.append(l["n"])
            size += n
        if cur:
            out.append(cur)
        st["rchunks"][mode] = [{"mode": mode, "lessons": ls, "id": "%s%d" % (pre, i + 1),
                                "status": "answered" if all(_ranked(l) for l in st["lessons"] if l["n"] in ls) else "pending"}
                               for i, ls in enumerate(out)]


def _ranked(l):
    return l.get("rank_score") is not None


def _old_status(st, mode, nums):
    done = {p.get("lesson") for p in st.get("picks", [])} | {n.get("lesson") or 1 for n in st.get("request_notes", [])}
    return "answered" if all(n in done for n in nums) else "pending"


def all_chunks(st, cid):
    """הרשימה והמקום של חלק לפי המזהה (c1/g1/cx2 — הצעות; rc1/rg1 — דירוג)."""
    if cid.startswith("r"):
        return (st.get("rchunks") or {}).get("chat" if cid.startswith("rc") else "gemini", [])
    return st["chunks"]["chat" if cid.startswith("c") else "gemini"]


def chunk_prompt(st, cid):
    ch = next(c for c in all_chunks(st, cid) if c["id"] == cid)
    les = []
    for l in st["lessons"]:
        if l["n"] in ch["lessons"]:
            if cid.startswith("r"):
                les.append(l)
            else:
                les.append(dict(l, text=(Path(st["dir"]) / l["text_file"]).read_text(encoding="utf-8")))
    if cid.startswith("r"):
        return rank_prompt(les, st.get("title", ""))
    strong = st["kind"] == "playlist" and st.get("mode") == "strong"
    return build_prompt(les, st["kind"] == "playlist" and not strong, st.get("title", ""), multi=strong,
                        exclude=ch.get("exclude"), request=st.get("request", ""))


# ═══════════════════ דירוג שיעורים (שלב א' של פלייליסט גדול) ═══════════════════

def rank_card_text(l):
    c = (l.get("card") or "").strip()
    if not c:
        c = "   (אין כתוביות לשיעור הזה — דרג לפי הכותרת בלבד)"
    # הכרטיס מתחיל ב"## שיעור N" משלו; כאן הכותרת באה מכותרת השיעור
    c = "\n".join(x for x in c.splitlines() if not x.startswith("## "))
    return "### שיעור %d: %s%s\n%s" % (l["n"], l.get("title") or "?",
                                       " (אורך %s)" % mmss(l["duration"]) if l.get("duration") else "", c)


def rank_prompt(lessons, series_title=""):
    head = ("אתה עוזר לבחור אילו שיעורים בסדרה%s מתאימים לשורטס (סרטונים אנכיים קצרים) ב%s. "
            "לפניך כרטיס קצר לכל שיעור (נבנה אוטומטית מכתוביות יוטיוב — פתיחה, סיום, ורמזים: ניסוחי עיקרון, סיפורים ומשלים, "
            "עם זמנים). הכתוביות גסות, והכרטיס הוא רמז ולא פסק דין.\n" % (" (\"%s\")" % series_title if series_title else "",
                                                                       SET.channel_phrase()))
    task = ("המשימה: לדרג את *כל* השיעורים שברשימה. לכל שיעור — ציון 1–10: כמה הוא מבטא את הרעיון המרכזי של הסדרה, "
            "וכמה סביר שיש בו קטע חזק שעומד לבד לשורט (פאנץ' חד, סיפור או משל קצר, עיקרון בניסוח ברור). "
            "🚨 הדגש הוא על הרעיון המרכזי של הסדרה — לא על הסיפור הכי משעשע. שיעור בלי כתוביות — דרג לפי הכותרת בלבד "
            "וציין זאת. הציונים צריכים להבחין בין השיעורים (לא הכול באותו ציון); ענה על כל שיעור.")
    fmt = ('פורמט התשובה: JSON בלבד — מערך אחד, בלי שום טקסט לפניו או אחריו, איבר לכל שיעור: '
           '[{"lesson": 1, "score": 8, "why": "משפט אחד: על מה השיעור ולמה הוא חזק או חלש לשורט"}]')
    body = "\n\n".join(rank_card_text(l) for l in lessons)
    return "\n\n".join([head, task, fmt, "הכרטיסים:\n\n" + body, "זכור: JSON בלבד, איבר לכל שיעור."])


def parse_ranking(text):
    """תשובת דירוג (Gemini או הדבקה) → {מספר שיעור: (ציון, למה)}. סובלני כמו parse_answer."""
    data = None
    for chunk in _json_chunks(text or ""):
        for s in (chunk, _repair(chunk)):
            try:
                data = json.loads(s)
                break
            except ValueError:
                continue
        if data is not None:
            break
    raw = []
    if isinstance(data, dict):
        for k in ("ranking", "lessons", "scores", "דירוג", "שיעורים"):
            if isinstance(data.get(k), list):
                raw = data[k]
                break
        else:
            raw = [dict(v, lesson=k) if isinstance(v, dict) else {"lesson": k, "score": v} for k, v in data.items()]
    elif isinstance(data, list):
        raw = data
    out = {}
    for r in raw:
        if not isinstance(r, dict):
            continue
        n = next((r[k] for k in ("lesson", "n", "id", "שיעור", "מספר שיעור") if r.get(k) not in (None, "")), None)
        sc = next((r[k] for k in ("score", "rank", "ציון") if r.get(k) not in (None, "")), None)
        try:
            n = int(re.sub(r"\D", "", str(n)))
            sc = float(str(sc).replace(",", ".").split("/")[0])
        except (TypeError, ValueError):
            continue
        out[n] = (round(max(0.0, min(10.0, sc)), 1), str(r.get("why") or r.get("reason") or r.get("נימוק") or "").strip())
    return out


def add_rank_answer(st, text, cid=""):
    """דירוג → ציון ו"למה" על כל שיעור. מחזיר (כמה שיעורים דורגו, אזהרות)."""
    got = parse_ranking(text)
    if not got:
        raise ValueError("לא מצאתי בתשובה דירוג. ודאו שהעתקתם את כל התשובה (כולל הסוגריים [ ]), "
                         "או בקשו מהצ'אט: \"תחזיר את הדירוג כ-JSON בלבד\"")
    by_n = {l["n"]: l for l in st["lessons"]}
    warns, n_ok = [], 0
    for n, (sc, why) in got.items():
        if n in by_n:
            by_n[n]["rank_score"], by_n[n]["rank_why"] = sc, why
            n_ok += 1
        else:
            warns.append("שיעור %d לא קיים בפלייליסט — דילגתי" % n)
    if cid:
        ch = next((c for c in all_chunks(st, cid) if c["id"] == cid), None)
        miss = [n for n in (ch["lessons"] if ch else []) if n not in got]
        if miss:
            warns.append("אין דירוג לשיעורים: %s" % ", ".join(map(str, miss[:30])) + ("…" if len(miss) > 30 else ""))
    make_rank_chunks(st)
    return n_ok, warns


def add_answer(st, text, cid="", src="chat"):
    """תשובה (Gemini או הדבקה) → הצעות מאומתות בתוך st. מחזיר (כמה נוספו, אזהרות).
    src = מאיפה (gemini / chat) — לתווית של המילים להגדלה ("Gemini הציע" / "הצ'אט הציע")."""
    notes = []
    picks = parse_answer(text, notes)
    for p in picks:
        p["emph_src"] = src
    if notes:                       # כרטיס 25: "לא מצאתי" — נשמר ומוצג לו, במקום ניחוש של קטע אחר
        nl = [n for n in st.get("request_notes", []) if n.get("lesson") not in {x["lesson"] for x in notes}]
        st["request_notes"] = nl + [dict(n, at=time.strftime("%H:%M"), request=st.get("request", "")) for n in notes]
    elif st.get("request_notes") and picks:
        got = {p.get("lesson") or 1 for p in picks}
        st["request_notes"] = [n for n in st["request_notes"] if (n.get("lesson") or 1) not in got]
    if not picks and not notes:
        raise ValueError("לא מצאתי בתשובה אף קטע עם זמנים. ודאו שהעתקתם את כל התשובה (כולל הסוגריים [ ]), "
                         "או בקשו מהצ'אט: \"תחזיר את התשובה כ-JSON בלבד\"")
    playlist = st["kind"] == "playlist"
    strong = playlist and st.get("mode") == "strong"
    expected, ch = None, None
    if cid:
        ch = next((c for c in all_chunks(st, cid) if c["id"] == cid), None)
        expected = ch and ch["lessons"]
    more = bool(cid and len(cid) > 1 and cid[1] == "x")           # "חפש קטעים אחרים" — מוסיף, לא מחליף
    warns, added = [], 0
    by_n = {l["n"]: l for l in st["lessons"]}
    s = SET.load()
    for p in picks:
        if not playlist:
            p["lesson"] = 1
        elif p.get("lesson") not in by_n:
            if strong and expected and len(expected) == 1:       # בקשה של שיעור אחד — המספר ידוע גם אם המודל השמיט אותו
                p["lesson"] = expected[0]
            else:
                warns.append("קטע בלי מספר שיעור תקין (%s) — דילגתי" % p.get("lesson"))
                continue
        les = by_n[p["lesson"]]
        p["title"] = re.sub(r"\s*[|｜]\s*(הרב|הרה\"ג).*$", "", p["title"]).strip()
        p["description"] = clean_desc(p["description"], les.get("rabbi"))
        p["tags"] = clean_tags(p["tags"], les.get("rabbi"))
        if not s["auto_skips"] and collapse_segs(p):
            p.setdefault("notes", []).append("הוצעו דילוגים אבל ההגדרה \"דילוגים אוטומטיים\" כבויה — הוחזר לרצף אחד")
        verify_pick(p, lesson_words(st["dir"], les), lesson_cap(st["dir"], les))
        for n_ in p.pop("notes", []):
            p["flags"].append(n_)
        for e in (ch or {}).get("exclude", []) if more else []:      # חופף למשהו שוויתר עליו
            ov = min(p.get("end") or 0, e["to"]) - max(p.get("start") or 0, e["from"])
            if ov > 0.5 * max(1.0, min((p.get("end") or 0) - (p.get("start") or 0), e["to"] - e["from"])):
                p["flags"].append("חופף לקטע שוויתרת עליו (%s–%s)" % (mmss(e["from"]), mmss(e["to"])))
                break
        p["id"] = "p%d" % (st.setdefault("seq", 0) + 1)
        st["seq"] += 1
        p["checked_fidelity"] = [False] * len(FIDELITY_Q)
        added += 1
        st["picks"].append(p)
    # בכל שיעור: ההצעות הישנות מאותו מקור מתחלפות בחדשות (תשובה שהודבקה שוב / Gemini שנשאל שוב)
    new_ids = {p["id"] for p in picks if "id" in p}
    if not more:
        for n in {p["lesson"] for p in picks if "id" in p}:
            st["picks"] = [p for p in st["picks"] if p["lesson"] != n or p["id"] in new_ids or p.get("user_edited")
                           or p.get("dropped")]
    if playlist and not strong:
        for n in {p["lesson"] for p in picks if "id" in p}:
            mine = [p for p in st["picks"] if p["lesson"] == n and p["id"] in new_ids]
            for p in mine:
                p.setdefault("selected", False)          # בפלייליסט הוא מסמן בעצמו אילו שיעורים נכנסים
            if len(mine) > s["playlist_picks"]:
                warns.append("שיעור %d: הוצעו %d קטעים (ההגדרה: %d)" % (n, len(mine), s["playlist_picks"]))
    else:
        preselect(st, {p["lesson"] for p in picks if "id" in p}, new_ids if more else None)
    if more:
        mm_ = next((m for m in st.get("more", []) if cid.endswith("x%d" % m["k"])), None)
        if mm_:
            mm_["status"] = "answered"
    if expected:
        got = {p["lesson"] for p in st["picks"] if not p.get("dropped") or p["id"] in new_ids}
        noted = {(n.get("lesson") or (expected[0] if len(expected) == 1 else 1)) for n in notes}
        miss = [n for n in expected if n not in got and n not in noted]
        if miss:
            warns.append("אין הצעה לשיעורים: %s" % ", ".join(map(str, miss)))
        for mode in ("chat", "gemini"):
            for c in st["chunks"][mode]:
                if c["id"][1:2] == "x":                   # בקשת "חפש אחרים": התשובה שלה נרשמה ב-st["more"]
                    c["status"] = "answered" if more_answered(st, c["id"]) else "pending"
                else:
                    c["status"] = _old_status(st, mode, c["lessons"])
    return added, warns


def more_answered(st, cid):
    m = next((m for m in st.get("more", []) if cid[2:] == str(m["k"])), None)
    return bool(m and m.get("status") == "answered")


def preselect(st, lessons=None, only_ids=None):
    """מסמן מראש לפי הכלל המורכב — עד max_long, ועד max_with_short אם יש קצר — לכל שיעור לחוד (בשיעור בודד:
    השיעור היחיד). הצעה שהציטוט שלה לא נמצא לא מסומנת לעולם מעצמה; הצעה ש"ויתרתי" עליה — גם לא.
    only_ids: "חפש קטעים אחרים" — רק ההצעות החדשות נבחנות, מעל מה שכבר סומן."""
    s = SET.load()
    nums = sorted(lessons) if lessons else sorted({p["lesson"] for p in st["picks"]})
    for n in nums:
        mine = [p for p in st["picks"] if p["lesson"] == n and not p.get("dropped")]
        chosen = [p for p in mine if only_ids is not None and p.get("selected") and p["id"] not in only_ids]
        for p in mine:
            if (only_ids is not None and p["id"] not in only_ids) or p.get("bad") or \
                    any(f.startswith("חופף לקטע שוויתרת") for f in p.get("flags", [])):
                continue
            trial = [x["seconds"] for x in chosen + [p] if x.get("seconds")]
            if not SET.rule_warnings(trial, s) or len(chosen) < 1:
                chosen.append(p)
        for p in mine:
            if not p.get("user_edited"):
                p["selected"] = p in chosen


# ═══════════════════════ סריקה: שיעור בודד ═══════════════════════

def yt_info(url):
    out = MS.run([MS.SHORTS, "yt-dlp", "--skip-download", "--no-warnings", "--print",
                  "%(id)s\t%(title)s\t%(channel_url)s\t%(duration)s", "--", url]).strip().splitlines()[-1].split("\t")
    return out[0], out[1], (out[2] if len(out) > 2 else ""), to_secs(out[3]) if len(out) > 3 and out[3] != "NA" else None


CHUNK = 600.0
_BIDI = re.compile("[‎‏‪-‮⁦-⁩]")      # Modal מחזיר לפעמים סימוני כיוון בתוך הטקסט
PICK_MODEL = MS.TURBO


def whole_lesson_asr(audio, out, model=PICK_MODEL):
    """תמלול כל השיעור — רק בשביל *לבחור* קטעים; הקליף עצמו מתומלל אחר כך בשתי אוזניים (large-v3 + turbo).
    🚨 נמדד 20/10 על שיעור של 42 דקות: large-v3 כקובץ אחד עבר את מגבלת 900 השניות של Modal ונפל;
    בחמישה חלקים במקביל — 13 דקות וכ-60 סנט. turbo (14/10: 33 דקות ב-131 שניות, 90% הסכמה עם large-v3)
    הוא מה שמתאים לבחירה. בחלקים של 10 דקות במקביל, והזמנים מוזזים חזרה. המודל תמיד מפורש ונבדק."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    full = MS.duration(audio)
    parts = []
    k = 0
    while k * CHUNK < full:
        w = out / ("part%02d.wav" % k)
        if not w.exists():
            MS.run([MS.FFMPEG, "-y", "-v", "error", "-ss", "%.3f" % (k * CHUNK), "-t", "%.3f" % CHUNK, "-i", audio,
                    "-vn", "-ac", "1", "-ar", str(MS.SR), "-c:a", "pcm_s16le", w])
        parts.append((k * CHUNK, w))
        k += 1
    out = out / model.split("/")[-1]           # תיקייה לכל מודל — לא לקבל תמלול ישן של מודל אחר
    out.mkdir(parents=True, exist_ok=True)
    if SET.load().get("asr_engine") == "cpu":  # 22/10: "מנוע תמלול: המחשב" — גיבוי בלבד, איטי (בערך כאורך השיעור)
        r = subprocess.run([MS.PY, str(HERE / "asr.py"), "run", "--media", *[str(w) for _, w in parts], "--out-dir", str(out)],
                           env=dict(os.environ, SHORTS_MODEL=model), capture_output=True, text=True, errors="replace")
        if r.returncode:
            raise RuntimeError("התמלול במחשב נכשל:\n" + (r.stderr or r.stdout)[-600:])
    else:
        MS.run([MS.PY, HERE / "modal_asr.py", "run", "--media", *[w for _, w in parts], "--out-dir", out,
                "--model", model])
    words = []
    for off, w in parts:
        data = json.load(open(out / (w.stem + "_words.json"), encoding="utf-8"))
        if data.get("model") and data["model"] != model:
            raise RuntimeError("התמלול רץ על %s במקום %s" % (data["model"], model))
        words += [dict(x, word=_BIDI.sub("", x["word"]), start=round(x["start"] + off, 2), end=round(x["end"] + off, 2))
                  for x in data["words"] if _BIDI.sub("", x["word"]).strip()]
    return words


def scan_lesson(P, st):
    url = st["url"]
    say("① פרטי השיעור")
    vid, title, chan, dur = yt_info(url)
    rabbi, series = MS.guess_names(title)
    les = {"n": 1, "id": vid, "url": url, "title": title, "duration": dur,
           "rabbi": (st.get("rabbi") or rabbi).strip(), "series": (st.get("series") or series).strip()}
    st.update(title=title, channel_url=chan, lessons=[les])
    say("TITLE=%s" % title)
    say("   %s · רב: %s" % (title, les["rabbi"] or "?"))
    save(P, st)
    pk = P / "pick"
    pk.mkdir(exist_ok=True)
    words = None
    audio = pk / "audio.m4a"
    st.pop("modal_plan", None)
    cpu = SET.load().get("asr_engine") == "cpu"
    est = est_cost([dur])
    ok, info = MS.MD.check(est)
    if cpu or not ok:
        # 22/10: "מנוע תמלול: המחשב" — קודם כתוביות יוטיוב (שניות); המחשב רק כשאין כתוביות (איטי).
        # מעל תקרת Modal היומית — לא שולחים בלי אישור: בוחרים מהכתוביות, והחלון מציע "אשר ותמלל" עם המספרים
        if cpu:
            say("③ תמלול במחשב לפי ההגדרות — קודם כתוביות יוטיוב (מהיר); אם אין — המחשב (איטי)")
        else:
            st["modal_plan"] = {"mode": "all", "n": 1, "est": est, "spent": info["spent"], "cap": info["cap"],
                                "needs_confirm": True, "lessons": None, "text": info["text"]}
            say("③ ⛔ תמלול Modal יעבור את תקרת היום (%s) — בוחרים מכתוביות יוטיוב עד שתאשרו" % info["text"])
        words = cues_to_words(MS.fetch_captions(url, pk / "captions")) or None
        if words:
            les["source"] = "כתוביות יוטיוב (פחות מדויק)"
        elif not cpu:
            raise RuntimeError("לשיעור הזה אין כתוביות יוטיוב, ותמלול Modal יעבור את תקרת היום (%s) — "
                               "להעלות את התקרה בהגדרות ולנסות שוב" % info["text"])
    if words is None:
        try:
            if not audio.exists() or audio.stat().st_size < 1000:
                say("② מוריד את הקול בלבד (בלי וידאו)")
                MS.run([MS.SHORTS, "yt-dlp", "-f", "140/ba[ext=m4a]/ba", "-o", audio, "--", url])
            if cpu:
                say("③ מתמלל את כל השיעור במחשב (איטי — בערך כאורך השיעור)")
            else:
                say("③ מתמלל את כל השיעור ב-Modal (turbo, בחלקים של 10 דקות במקביל — כ-2–3 דקות, כמה סנטים)")
                MS.MD.record(est, "בחירת קטעים: " + title[:50])
            words = whole_lesson_asr(audio, pk / "asr")
            les["source"] = "המחשב (turbo)" if cpu else "Modal turbo"
            try:                                    # כתוביות יוטיוב — קריאה שנייה לציטוטים (חינם, בלי וידאו)
                cw = cues_to_words(MS.fetch_captions(url, pk / "captions"))
                if cw:
                    json.dump({"words": cw}, open(pk / "cap_words.json", "w", encoding="utf-8"), ensure_ascii=False)
                    les["cap_words"] = "pick/cap_words.json"
            except Exception:
                pass
        except Exception as ex:
            say("   ⚠️ התמלול נכשל (%s) — משתמש בכתוביות האוטומטיות של יוטיוב" % str(ex).splitlines()[-1][:150])
            cues = MS.fetch_captions(url, pk / "captions")
            words = cues_to_words(cues)
            les["source"] = "כתוביות יוטיוב (פחות מדויק)"
            if not words:
                raise RuntimeError("אין תמלול: גם התמלול נכשל וגם אין כתוביות יוטיוב לשיעור הזה")
    json.dump({"words": words}, open(pk / "words.json", "w", encoding="utf-8"), ensure_ascii=False)
    (pk / "transcript.txt").write_text(lines_text(words_to_lines(words)), encoding="utf-8")
    les.update(words="pick/words.json", text_file="pick/transcript.txt", n_words=len(words))
    say("   %d מילים · %s" % (len(words), les["source"]))


# ═══════════════════════ סריקה: פלייליסט ═══════════════════════

def list_playlist(url):
    """🚨 עם העוגיות שלו (בקשתו): בלי --cookies מפורש, --flat-playlist מסתיר שיעורים מתוזמנים/פרטיים.
    עוגיות שפגו — אומרים בבירור, ומנסים בלעדיהן (רק הציבוריים)."""
    url = MS.check_url(url)                    # 4.1.0: רק קישור יוטיוב אמיתי (ערך שמתחיל ב-- היה נקרא כאופציה של yt-dlp)
    notes = []
    fmt = ["--flat-playlist", "--print", "%(id)s\t%(title)s\t%(duration)s\t%(availability)s",
           "--print", "playlist:PLAYLIST\t%(title)s"]
    has_ck = COOKIES.exists() and COOKIES.stat().st_size > 100
    r = None
    if has_ck:
        r = subprocess.run([MS.SHORTS, "yt-dlp", "--cookies", str(COOKIES)] + fmt + ["--", url],
                           capture_output=True, text=True, errors="replace")
        err = r.stderr or ""
        if re.search(r"no longer valid|cookies are invalid|invalid cookies|rotated", err, re.I):
            notes.append("⚠️ העוגיות של יוטיוב פגו — שיעורים מתוזמנים/פרטיים לא יופיעו. כדאי להעלות קובץ "
                         "עוגיות חדש (בדיקת מערכת → העלה קובץ עוגיות) ולסרוק שוב.")
        if r.returncode:
            notes.append("⚠️ הרשימה עם העוגיות נכשלה — מנסה בלעדיהן (רק שיעורים ציבוריים יופיעו)")
            r = None
    else:
        notes.append("⚠️ אין קובץ עוגיות של יוטיוב — שיעורים מתוזמנים/פרטיים לא יופיעו ברשימה.")
    if r is None:
        r = subprocess.run([MS.SHORTS, "yt-dlp", "--no-cookies"] + fmt + ["--", url],
                           capture_output=True, text=True, errors="replace")
        if r.returncode:
            raise RuntimeError("לא הצלחתי לקרוא את הפלייליסט:\n" + "\n".join((r.stderr or "").strip().splitlines()[-4:]))
    items, ptitle = [], ""
    for line in r.stdout.splitlines():
        f = line.split("\t")
        if f[0] == "PLAYLIST":
            ptitle = f[1] if len(f) > 1 else ""
        elif len(f) >= 4 and re.fullmatch(r"[\w-]{11}", f[0]):
            items.append({"id": f[0], "title": "" if f[1] in ("NA", "[Private video]") else f[1],
                          "duration": to_secs(f[2]) if f[2] not in ("NA", "") else None, "availability": f[3]})
    return ptitle, items, notes


def lesson_captions(les, d):
    """כתוביות בלבד (בלי וידאו), ובאותה פקודה — כותרת ואורך (בפלייליסט שטוח הם חסרים לפעמים).
    דרך shorts.sh: קודם בלי עוגיות, ורק אם נדרשת התחברות — איתן (עוגיות ישנות שוברות סרטון ציבורי)."""
    d.mkdir(parents=True, exist_ok=True)
    url = "https://www.youtube.com/watch?v=" + les["id"]
    r = subprocess.run([MS.SHORTS, "yt-dlp", "--skip-download", "--no-simulate", "--write-auto-subs", "--write-subs",
                        "--sub-langs", "iw.*,he.*", "--convert-subs", "srt", "--print",
                        "INFO\t%(title)s\t%(duration)s\t%(availability)s\t%(upload_date)s\t%(release_date)s", "-o", str(d / "yt"), "--", url],
                       capture_output=True, text=True, errors="replace")
    for line in r.stdout.splitlines():
        f = line.split("\t")
        if f[0] == "INFO" and len(f) >= 4:
            les["title"] = les["title"] or f[1]
            les["duration"] = les.get("duration") or to_secs(f[2])
            les["availability"] = f[3] or les.get("availability")
            for x in f[4:6]:                     # תאריך פרסום (YYYYMMDD) — למיון הטבלה; מתוזמן: תאריך השחרור
                if re.fullmatch(r"\d{8}", x or ""):
                    les["date"] = x
                    break
    cues = []
    for f in sorted(d.glob("yt*.srt")):
        cues = _srt(f)
        if cues:
            break
    if not cues and r.returncode:
        les["error"] = "\n".join((r.stderr or "").strip().splitlines()[-2:])[:300]
    return cues


def _srt(f):
    cues = []
    for blk in re.split(r"\n\s*\n", f.read_text(encoding="utf-8", errors="replace")):
        m = re.search(r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)\s*\n(.*)", blk, re.S)
        if m:
            g = [int(x) for x in m.groups()[:8]]
            cues.append((g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000, g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000,
                         " ".join(m.group(9).split())))
    return cues


def resolve_mode(n, st, s=None):
    """"קטע מכל שיעור" (each) או "רק החזקים" (strong, שני שלבים). הגדרה אוטומטית: each עד playlist_auto_max שיעורים.
    בחירה שלו במסך הפלייליסט (mode_user) גוברת על ההגדרה."""
    s = s or SET.load()
    if st.get("mode_user") in ("each", "strong"):
        return st["mode_user"]
    m = s["playlist_mode"]
    return m if m in ("each", "strong") else ("each" if n <= s["playlist_auto_max"] else "strong")


def scan_playlist(P, st):
    say("① רשימת השיעורים בפלייליסט (עם העוגיות שלכם)")
    ptitle, items, notes = list_playlist(st["url"])
    for n in notes:
        say("   " + n)
    if not items:
        raise RuntimeError("הפלייליסט ריק או לא נגיש")
    st.update(title=ptitle or "פלייליסט", notes=notes)
    say("TITLE=%s" % st["title"])
    say("   %s · %d שיעורים (%d לא ציבוריים)" % (st["title"], len(items),
                                                  sum(1 for i in items if i["availability"] not in ("public", "NA", ""))))
    lessons = [dict(it, n=k + 1, url="https://www.youtube.com/watch?v=" + it["id"]) for k, it in enumerate(items)]
    st["lessons"] = lessons
    st["mode"] = resolve_mode(len(lessons), st)
    if st["mode"] == "strong":
        say("   📚 פלייליסט גדול (%d שיעורים) — מצב \"רק השיעורים החזקים\": שלב א' סריקה מהירה לפי כתוביות (חינם), "
            "דירוג בבקשה אחת-שתיים, ואז תמלול מדויק רק למה שתבחרו" % len(lessons))
    save(P, st)
    say("② כתוביות בלבד לכל שיעור (בלי להוריד וידאו, כ-3 שניות לשיעור)")
    # שם הסדרה — מכותרת הפלייליסט ("שמונה פרקים לרמב"ם | הרב יהודה מלמד"), כדי שכל השיעורים ייכנסו לתיקייה אחת
    p_rabbi, p_series = MS.guess_names("x | " + (ptitle or ""))

    def one(les):
        d = P / "captions" / les["id"]
        cues = lesson_captions(les, d)
        rabbi, series = MS.guess_names(les["title"] or "")
        # 🚨 הרב — מכותרת הסרטון. שגיאת הקלדה בכותרת אחת ("הרב היהודה מלמד") → השם מכותרת הפלייליסט,
        # רק כשהם כמעט זהים; שם שונה באמת (רב אורח) נשאר מהסרטון
        if p_rabbi and rabbi and rabbi != p_rabbi and \
                difflib.SequenceMatcher(None, MS.norm(rabbi), MS.norm(p_rabbi)).ratio() >= 0.85:
            rabbi = p_rabbi
        les["rabbi"] = (st.get("rabbi") or rabbi or p_rabbi).strip()
        les["series"] = (st.get("series") or p_series or series).strip()
        if not cues:
            les["source"] = ""
            return les
        words = cues_to_words(cues)
        json.dump({"words": words}, open(d / "words.json", "w", encoding="utf-8"), ensure_ascii=False)
        json.dump({"words": words}, open(d / "cap_words.json", "w", encoding="utf-8"), ensure_ascii=False)
        (d / "transcript.txt").write_text(lines_text(words_to_lines(words, 25.0)), encoding="utf-8")
        les.update(words=str((d / "words.json").relative_to(P)), text_file=str((d / "transcript.txt").relative_to(P)),
                   n_words=len(words), source="כתוביות יוטיוב", cap_words=str((d / "cap_words.json").relative_to(P)))
        return les
    with CF.ThreadPoolExecutor(4) as ex:
        for k, les in enumerate(ex.map(one, lessons), 1):
            say("   %d/%d %s %s" % (k, len(lessons), "✓" if les.get("source") else "✗ אין כתוביות", les["title"][:60]))
    if st["mode"] == "each":
        modal_step(P, st, bool(st.get("modal_ok")))
    miss = [l for l in lessons if not l.get("source")]
    if miss and st["mode"] == "each":
        say("   ⚠️ %d שיעורים בלי תמלול — אפשר לתמלל אותם ב-Modal מהחלון (כ-5 סנט לשיעור)" % len(miss))
    import series_cards as SC
    for les in lessons:
        srt = sorted((P / "captions" / les["id"]).glob("yt*.srt"))
        if srt:
            les["card"] = SC.card(str(srt[0]), "שיעור %d" % les["n"]).strip()


MODAL_USD_PER_MIN = 0.0015      # turbo, אודיו בלבד: כ-5 סנט לשיעור של ~35 דקות (נמדד 14/10 ו-20/10)
MODAL_SRC = "Modal (turbo)"


def est_cost(durations):
    """הערכת עלות תמלול Modal בדולרים — לפי אורך השיעורים (חסר = 35 דקות)."""
    return round(sum(max(0.02, ((d or 2100) / 60.0) * MODAL_USD_PER_MIN) for d in durations), 2)


def modal_todo(st, mode):
    """mode: "all" — כל שיעור שעוד לא תומלל ב-Modal; "missing" — רק בלי תמלול בכלל."""
    if mode == "all":
        return [l for l in st["lessons"] if not str(l.get("source", "")).startswith("Modal")]
    if mode == "missing":
        return [l for l in st["lessons"] if not l.get("source")]
    return []


def mode_from_settings(s=None):
    s = s or SET.load()
    return "all" if s["modal_all_lessons"] else ("missing" if s["modal_missing"] else "")


def transcribe_lesson(P, les):
    """שיעור אחד: אודיו בלבד → Modal turbo בחלקים → words.json (הטקסט שממנו בוחרים). הכתוביות של יוטיוב נשארות
    כקריאה שנייה (cap_words.json). הקליף עצמו עדיין מתומלל אחר כך בשתי אוזניים (large-v3 + turbo)."""
    d = P / "captions" / les["id"]
    d.mkdir(parents=True, exist_ok=True)
    a = d / "audio.m4a"
    if not a.exists() or a.stat().st_size < 1000:
        MS.run([MS.SHORTS, "yt-dlp", "-f", "140/ba[ext=m4a]/ba", "-o", a, "--", les["url"]])
    words = whole_lesson_asr(a, d / "asr")
    old = d / "words.json"
    if les.get("source") == "כתוביות יוטיוב" and old.exists() and not (d / "cap_words.json").exists():
        old.replace(d / "cap_words.json")
    if (d / "cap_words.json").exists():
        les["cap_words"] = str((d / "cap_words.json").relative_to(P))
    json.dump({"words": words}, open(d / "words.json", "w", encoding="utf-8"), ensure_ascii=False)
    (d / "transcript.txt").write_text(lines_text(words_to_lines(words, 25.0)), encoding="utf-8")
    les.update(words=str((d / "words.json").relative_to(P)), text_file=str((d / "transcript.txt").relative_to(P)),
               n_words=len(words), source=MODAL_SRC)
    les.pop("error", None)


def modal_step(P, st, confirmed=False, mode=None, only=None):
    """תמלול Modal לפי ההגדרות (או mode מפורש מהכפתור). קודם מציגים הערכת עלות; מעל הסכום שבהגדרות —
    לא רצים בלי אישור בחלון (st["modal_plan"]["needs_confirm"]).
    only = רשימת מספרי שיעורים (שלב ב' של פלייליסט גדול): רק הם מתומללים. מחזיר False כשמחכים לאישור."""
    s = SET.load()
    mode = mode if mode is not None else mode_from_settings(s)
    if only is not None:
        todo = [l for l in st["lessons"] if l["n"] in only and not str(l.get("source", "")).startswith("Modal")]
        mode = "stage_b"
    else:
        todo = modal_todo(st, mode)
    st.pop("modal_plan", None)
    if not todo:
        return True
    if s.get("asr_engine") == "cpu":
        # 22/10: "מנוע תמלול: המחשב" — לא מתמללים עשרות שיעורים במחשב (שעות); בוחרים מכתוביות יוטיוב
        say("③ תמלול במחשב לפי ההגדרות — הפלייליסט נבחר מכתוביות יוטיוב (תמלול של כל שיעור במחשב ייקח שעות)")
        return True
    est = est_cost([l.get("duration") for l in todo])
    # 22/10 (בקשתו): תקרה ליום במקום אישור לכל בקשה — שואלים רק כשהעבודה הזאת תעבור את תקרת היום
    ok, info = MS.MD.check(est)
    say("③ תמלול מדויק ב-Modal (turbo, אודיו בלבד): %d שיעורים · %s" % (len(todo), info["text"]))
    if not ok and not confirmed:
        st["modal_plan"] = {"mode": mode, "n": len(todo), "est": est, "spent": info["spent"], "cap": info["cap"],
                            "text": info["text"], "needs_confirm": True,
                            "lessons": sorted(only) if only is not None else None}
        say("   ⛔ יעבור את תקרת היום — מחכה לאישור בחלון (כפתור \"אשר ותמלל\")." +
            ("" if only is not None else " בינתיים בוחרים מהכתוביות."))
        save(P, st)
        return False
    MS.MD.record(est, "תמלול %d שיעורים (%s)" % (len(todo), st.get("title", "")[:40]))
    import threading
    lock = threading.Lock()
    done = [0]

    def one(les):
        err = ""
        try:
            transcribe_lesson(P, les)
        except Exception as ex:
            err = les["error"] = str(ex).splitlines()[-1][:200]
        with lock:
            done[0] += 1
            say("   %s %d/%d %s%s" % ("✗" if err else "✓", done[0], len(todo), les["title"][:60],
                                     (": " + err + (" — נשארות הכתוביות" if les.get("source") else "")) if err else ""))
            save(P, st)
    with CF.ThreadPoolExecutor(3) as ex:       # שלושה שיעורים במקביל (כל אחד כבר מתחלק לחלקים של 10 דקות)
        list(ex.map(one, todo))
    return True


def transcribe_missing(P, st, mode="missing", confirmed=False):
    """הכפתור הידני בחלון. mode "all" / "missing"."""
    if not modal_todo(st, mode):
        say("אין שיעורים לתמלל")
        return
    modal_step(P, st, confirmed, mode)


def estimate_playlist(url):
    """לפני ריצה: כמה שיעורים ובכמה זה יעלה — בלי להוריד כלום (רשימה שטוחה בלבד)."""
    s = SET.load()
    url = MS.check_url(url)
    ptitle, items, notes = list_playlist(url)
    mode = mode_from_settings(s)
    n = len(items)
    pl_mode = resolve_mode(n, {}, s)
    est = est_cost([i.get("duration") for i in items]) if mode == "all" and pl_mode == "each" else 0.0
    if s.get("asr_engine") == "cpu":
        mode, est = "", 0.0
    ok, info = MS.MD.check(est)
    return {"title": ptitle, "n": n, "est": est, "mode": mode, "pl_mode": pl_mode, "spent": info["spent"], "cap": info["cap"],
            "text": info["text"], "auto_max": s["playlist_auto_max"], "auto": s["playlist_mode"] == "auto",
            "all_est": est_cost([i.get("duration") for i in items]),
            "over": bool(est) and not ok, "notes": notes}

# ═══════════════════════ שאלת Gemini ═══════════════════════

def chunk_step(st, c):
    return "rank" if c["id"].startswith("r") else ("playlist" if st["kind"] == "playlist" else "pick")


def ask_gemini(P, st, auto=True):
    """שואל את Gemini על כל חלק שעוד לא נענה. נעצר מיד בעצירה (מכסה/חסימה) — בלי ניסיון חוזר.
    auto = נשאל לבד (סריקה). שלב שבהגדרות "תמיד העתק לצ'אט" — לא נשאל לבד; לחיצה שלו על "Gemini" (auto=False) כן."""
    st.pop("gemini_hold", None)                  # שאל בעצמו (כפתור Gemini) — כבר לא ממתין לבקשה משותפת
    pend = [c for c in (st.get("rchunks") or {}).get("gemini", []) if c["status"] != "answered"] + \
           [c for c in st["chunks"]["gemini"] if c["status"] != "answered"]
    if not pend:
        say("כל השיעורים כבר נענו")
        return True
    if auto:
        chat = [c for c in pend if not step_direct(chunk_step(st, c))]
        pend = [c for c in pend if c not in chat]
        if chat:
            st["gemini_stop"] = {"kind": "chat_mode", "msg": CHAT_MODE_MSG, "at": time.strftime("%H:%M")}
            say("   📋 %s" % CHAT_MODE_MSG)
            if not pend:
                return False
    for c in pend:
        rank = c["id"].startswith("r")
        say("④ שואל את Gemini (%s) — %s" % (SET.load()["gemini_model"],
                                            ("דירוג %d שיעורים" % len(c["lessons"])) if rank else
                                            "שיעורים %s" % ", ".join(map(str, c["lessons"])) if st["kind"] == "playlist"
                                            else "בקשה אחת לשיעור"))
        try:
            text = gemini_call(chunk_prompt(st, c["id"]))
        except GeminiStop as e:
            st["gemini_stop"] = {"kind": e.kind, "msg": str(e), "at": time.strftime("%H:%M"), "ts": time.time()}
            say("   ⛔ %s" % e)
            say("   ← אפשר להמשיך עם \"העתק לצ'אט\" בחלון")
            save(P, st)
            return False
        (P / "pick").mkdir(exist_ok=True)
        (P / "pick" / ("gemini_%s_%s.txt" % (c["id"], time.strftime("%H%M%S")))).write_text(text, encoding="utf-8")
        try:
            n, warns = add_rank_answer(st, text, c["id"]) if rank else add_answer(st, text, c["id"], src="gemini")
        except ValueError as e:
            say("   ⚠️ לא הצלחתי לקרוא את התשובה: %s" % e)
            continue
        c["status"] = "answered"
        st.pop("gemini_stop", None)
        say("   ✓ %d %s%s" % (n, "שיעורים דורגו" if rank else "הצעות", "".join("\n   ⚠️ " + w for w in warns)))
        save(P, st)
    return True


def ask_gemini_together(paths):
    """28/10 — כמה שיעורים בודדים שנשלחו בסמוך: בקשה אחת ל-Gemini במקום בקשה לכל שיעור (בקשתו: לחסוך בקשות).
    כל שיעור מקבל בבקשה מספר זמני 1..k; התשובה מתחלקת לפי lesson, וכל חלק נכנס לשיעור שלו בדיוק כמו תשובה רגילה."""
    items = []
    for p in paths:
        P = Path(p)
        st = load(P)
        st["dir"] = str(P)
        st.pop("gemini_hold", None)
        save(P, st)        # 🚨 לפני הבקשה: גם אם היא תיכשל / התהליך ייפול — לא נשלח שוב לבד (אין לולאה)
        ch = [c for c in st["chunks"]["gemini"] if c["status"] != "answered" and not c.get("exclude")]
        if st["kind"] != "lesson" or not ch or len(st["lessons"]) != 1:
            save(P, st)
            if ch:
                ask_gemini(P, st)
                save(P, st)
            continue
        l = st["lessons"][0]
        items.append((P, st, ch[0], dict(l, n=len(items) + 1, request=st.get("request", ""),
                                         text=(P / l["text_file"]).read_text(encoding="utf-8"))))
    if not items:
        return True
    if len(items) == 1:
        P, st = items[0][:2]
        ok = ask_gemini(P, st)
        save(P, st)
        return ok
    say("④ שואל את Gemini (%s) — %d שיעורים בבקשה אחת" % (SET.load()["gemini_model"], len(items)))
    try:
        text = gemini_call(build_prompt([it[3] for it in items], mixed=True))
    except GeminiStop as e:
        for P, st, *_ in items:
            st["gemini_stop"] = {"kind": e.kind, "msg": str(e), "at": time.strftime("%H:%M"), "ts": time.time()}
            save(P, st)
        say("   ⛔ %s" % e)
        return False
    data = None
    for chunk in _json_chunks(text):
        for s in (chunk, _repair(chunk)):
            try:
                data = json.loads(s)
                break
            except ValueError:
                continue
        if data is not None:
            break
    if isinstance(data, dict):
        data = next((v for v in data.values() if isinstance(v, list)), None)
    for k, (P, st, ch, _) in enumerate(items, 1):
        (P / "pick").mkdir(exist_ok=True)
        (P / "pick" / ("gemini_%s_%s.txt" % (ch["id"], time.strftime("%H%M%S")))).write_text(text, encoding="utf-8")
        mine = [dict(x, lesson=1) for x in (data or []) if isinstance(x, dict) and str(_get(x, "lesson") or "") == str(k)]
        if not mine:
            say("   ⚠️ שיעור %d: לא חזרו הצעות בתשובה המשותפת" % k)
            st["gemini_stop"] = {"kind": "error", "msg": "Gemini לא החזיר הצעות לשיעור הזה בבקשה המשותפת — "
                                 "\"Gemini\" שוב (בקשה אחת) או \"העתק לצ'אט\"", "at": time.strftime("%H:%M")}
            save(P, st)
            continue
        try:
            n, warns = add_answer(st, json.dumps(mine, ensure_ascii=False), ch["id"], src="gemini")
        except ValueError as e:
            say("   ⚠️ שיעור %d: %s" % (k, e))
            continue
        ch["status"] = "answered"
        st.pop("gemini_stop", None)
        save(P, st)
        say("   ✓ %s: %d הצעות%s" % (st.get("title") or P.name, n, "".join("\n   ⚠️ " + w for w in warns)))
    return True


def scan(P):
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    say("PROJECT=%s" % P)
    say("STAGE=working")
    if st["kind"] == "playlist":
        scan_playlist(P, st)
    else:
        scan_lesson(P, st)
    st.setdefault("picks", [])
    make_chunks(st)
    st["status"] = "ready"
    save(P, st)
    if st.get("use_gemini", True) and current_key() and st["kind"] == "lesson" and step_direct("pick") and \
            os.environ.get("MAKE_SHORT_PICK_HOLD") == "1":
        # 28/10: החלון שולח את Gemini — יחד עם שיעורים נוספים שנשלחו בסמוך (בקשה אחת, ask_gemini_together)
        st["gemini_hold"] = time.time()
        say("   ⏳ ההצעות של Gemini — יחד עם שיעורים שנשלחו בסמוך (בקשה אחת). אפשר \"שלח עכשיו\".")
    elif st.get("use_gemini", True) and current_key():
        ask_gemini(P, st)
    elif not current_key():
        st["gemini_stop"] = {"kind": "no_key", "msg": "אין מפתח Gemini — \"העתק לצ'אט\"", "at": time.strftime("%H:%M")}
        say("   (אין מפתח Gemini — ממשיכים ב\"העתק לצ'אט\")")
    save(P, st)
    say("STAGE=pick_ready")
    if st.get("mode") == "strong":
        done = all(_ranked(l) for l in st["lessons"])
        say("✅ סריקה מהירה הושלמה — %s" % ("הדירוג מוכן: בוחרים אילו שיעורים לעבוד עליהם" if done
                                           else "עכשיו מדרגים: \"העתק לצ'אט\" והדבקת התשובה, או Gemini"))
    else:
        say("✅ מוכן — %s" % ("יש הצעות לבדיקה" if st["picks"] else "עכשיו \"העתק לצ'אט\" והדבקת התשובה"))
    return 0


def stage_b(P, nums, confirmed=False):
    """שלב ב' של פלייליסט גדול: רק השיעורים שנבחרו — תמלול Modal מדויק (אחרי אישור עלות אם צריך), ואז הצעות
    בכללי שיעור רגילים (כמה קטעים, דילוגים, בדיקת ציטוטים). אפשר להריץ שוב על שיעורים נוספים."""
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    nums = {int(n) for n in nums}
    say("PROJECT=%s" % P)
    say("STAGE=working")
    for l in st["lessons"]:
        if l["n"] in nums:
            l["stage_b"] = True
    st["stage"] = "work"
    save(P, st)
    if modal_step(P, st, confirmed, only=nums) is False:
        save(P, st)
        say("STAGE=pick_ready")
        return 0
    make_chunks(st)
    save(P, st)
    if st.get("use_gemini", True) and current_key():
        ask_gemini(P, st)
    elif not current_key():
        st["gemini_stop"] = {"kind": "no_key", "msg": "אין מפתח Gemini — \"העתק לצ'אט\"", "at": time.strftime("%H:%M")}
    save(P, st)
    say("STAGE=pick_ready")
    say("✅ מוכן — %d שיעורים תומללו; עכשיו הצעות לבדיקה" % len(nums))
    return 0


def switch_mode(P, mode):
    """"קטע מכל שיעור" ↔ "רק החזקים" מתוך מסך הפלייליסט. הבחירה שלו גוברת על ההגדרה."""
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    if mode not in ("each", "strong") or st["kind"] != "playlist":
        raise ValueError("מצב לא מוכר")
    st["mode_user"] = st["mode"] = mode
    make_chunks(st)
    save(P, st)
    return st


def set_request(P, text, force=False):
    """כרטיס 25: משנה את הבקשה החופשית ("מה לחפש") של שיעור/פלייליסט שכבר נסרק. בקשה אחרת = ההצעות הישנות היו לבקשה
    אחרת: הצעות שלא נגע בהן (לא ערך/סימן/ויתר ביד; סימון אוטומטי לא נחשב) יוצאות והבקשות מוכנות מחדש — "Gemini" / "העתק לצ'אט" מקבלים את הנוסח
    החדש; מה שכבר ערך או סימן נשאר. טקסט זהה = לא משנה כלום. בקשה ריקה = התנהגות רגילה."""
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    new = " ".join(str(text or "").split())[:600]
    if new == (st.get("request") or "") and not force:
        return st, False
    if new:
        st["request"] = new
    else:
        st.pop("request", None)
    st["picks"] = [p for p in st.get("picks", []) if p.get("user_edited") or p.get("dropped")]   # selected לבד (preselect) לא נחשב נגיעה שלו
    for k in ("request_notes", "more", "gemini_stop", "auto_done", "auto_note", "auto_pause", "gemini_hold"):
        st.pop(k, None)
    make_chunks(st)
    for mode in ("chat", "gemini"):               # הבקשה השתנתה: גם שיעור שנשארו בו הצעות שערך נשאל מחדש
        for c in st["chunks"][mode]:
            if c["id"][1:2] != "x":
                c["status"] = "pending"
    save(P, st)
    return st, True


def request_more(P, n):
    """"🔍 חפש קטעים אחרים בשיעור הזה": בקשה חדשה לשיעור n, בלי מה שכבר הוצע (וויתר עליו)."""
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    n = int(n)
    ex = []
    for p in st["picks"]:
        if p["lesson"] != n:
            continue
        try:
            cuts = MS.parse_pieces(p.get("pieces") or "")
        except Exception:
            cuts = []
        if not cuts and p.get("start") is not None and p.get("end") is not None:
            cuts = [(p["start"], p["end"])]
        for a, b in cuts:
            ex.append({"from": round(a, 1), "to": round(b, 1), "title": p.get("title", "")})
    st["more_seq"] = st.get("more_seq", 0) + 1
    st.setdefault("more", []).append({"k": st["more_seq"], "lessons": [n], "exclude": ex, "status": "pending"})
    make_chunks(st)
    save(P, st)
    return st


def gemini_only(P):
    P = Path(P)
    st = load(P)
    st["dir"] = str(P)
    say("STAGE=working")
    ok = ask_gemini(P, st, auto=False)           # הוא לחץ "Gemini" — גם בשלב שבהגדרות "העתק לצ'אט"
    save(P, st)
    say("STAGE=pick_ready")
    return 0 if ok else 1


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if len(a) == 2 and a[0] == "scan":
            sys.exit(scan(a[1]))
        if len(a) == 2 and a[0] == "gemini":
            sys.exit(gemini_only(a[1]))
        if len(a) >= 2 and a[0] == "together":           # together <dir> <dir> ... (28/10)
            say("STAGE=working")
            ok = ask_gemini_together(a[1:])
            say("STAGE=pick_ready")
            sys.exit(0 if ok else 1)
        if len(a) >= 3 and a[0] == "stageb":            # stageb <dir> 3,7,12 [--yes]
            sys.exit(stage_b(a[1], [x for x in a[2].split(",") if x.strip()], "--yes" in a))
        if len(a) >= 2 and a[0] == "transcribe":        # transcribe <dir> [all|missing] [--yes]
            P = Path(a[1])
            st = load(P)
            st["dir"] = str(P)
            transcribe_missing(P, st, next((x for x in a[2:] if x in ("all", "missing")), "missing"), "--yes" in a)
            make_chunks(st)
            save(P, st)
            say("STAGE=pick_ready")
            sys.exit(0)
        print(__doc__)
        sys.exit(2)
    except Exception as e:
        say("❌ %s" % e)
        sys.exit(1)
