# -*- coding: utf-8 -*-
"""
make_short_update.py — תיבת "עדכון תוכנה" (21/10/2026).

למה: אם Claude Code לא יהיה זמין, הוא רוצה שכל עוזר בינה מלאכותית אחר (צ'אט חינמי) יוכל
לתקן או לשפר את התוכנה — בלי טרמינל ובלי git. העוזר כותב עדכון בפורמט אחד (מתועד ב-
docs/HANDOFF.md, והכפתור "העתק הוראות לעוזר" מעתיק אותו), הוא מדביק אותו בתיבה, רואה מה ישתנה,
ולוחץ "החל". אם משהו נשבר — הכול חוזר לבד.

הפורמט (פירוט: FORMAT_RULES למטה):
  (א) diff רגיל (unified, כמו `git diff`), בתוך בלוק ```diff
  (ב) החלפת קובץ שלם:  === קובץ: <נתיב> ===  …התוכן…  === סוף קובץ ===
      (או באנגלית: === FILE: <path> === … === END FILE ===)
  (ג) 27/10: "חפש והחלף" — הכי קל לצ'אט לכתוב נכון (לא צריך מספרי שורות ולא שורות הקשר מדויקות של diff):
      === החלפה: <נתיב> ===  <<<<<<< לפני  …הטקסט הקיים…  =======  …החדש…  >>>>>>> אחרי  === סוף החלפה ===
      (או: === EDIT: path === / <<<<<<< SEARCH / ======= / >>>>>>> REPLACE / === END EDIT ===)
  אפשר כמה בלוקים בעדכון אחד. שורת "תיאור: …" (לא חובה) נכנסת להיסטוריה.
  27/10: תשובה שהיא רק "צריך קבצים: a, b:120-300, c#func" = העוזר מבקש עוד קוד (check מחזיר needs).
  הקריאה סלחנית לעיצוב של צ'אטים: סימוני כיוון (RTL/LTR) בתחילת שורות, ‎**הדגשה** סביב הסימנים, ‎\\r\\n,
  רווח קשיח (NBSP) בתחילת שורות diff; "חפש" שלא נמצא כמו שהוא נמצא גם בלי רווחים בסוף שורה, בלי סימוני
  כיוון ובלי מספרי שורות שהועתקו בטעות — ושורות שלא השתנו נשמרות בדיוק כמו בקובץ.

מה נבדק לפני שמשהו משתנה (check):
  - כל נתיב בתוך הריפו, יחסי, בלי "..", לא בתוך .git, לא קובץ שמוחרג מ-git
  - אף קובץ הגדרות/מפתחות/עוגיות (config.env, ‎*.env, *cookie*, *token*, *secret*, ‎*.toml,
    rclone.conf, ‎*.key, ‎*.pem, credentials, ‎*.vault) — נדחה
  - שום שינוי בינארי (GIT binary patch / Binary files / symlink) — נדחה
  - ה-diff באמת מתאים לגרסה שכאן (git apply --check --recount)

ההחלה (apply), כעבודה עם יומן:
  1. "צילום" — git commit של המצב הנוכחי ("לפני עדכון: …")
  2. החלה + commit ("עדכון: …")
  3. בדיקה עצמית: כל קבצי הפייתון נטענים (compile), סקריפטי bash (bash -n), JSON תקין, ה-JavaScript
     בדף נטען (deno/node אם יש), ושרת בדיקה על פורט פנוי עונה ל-/ ול-/api/home
  3ב. 27/10: גם make_short_selftest.py quick — כללי הברזל + שרת + סיום אמיתי של קליף 4 שניות (בתיקייה זמנית)
  4. הבדיקה נכשלה → git reset --hard לצילום, ונאמר בבירור שהכול חזר
"בטל עדכון אחרון" (undo) = git revert של ה-commit של העדכון (ההיסטוריה נשמרת), ואז אותה בדיקה.
ההיסטוריה: ~/.local/share/yeshiva-shorts/updates.json.

שימוש:  make_short_update.py check <file>   → JSON (קבצים, תצוגה, שגיאות)
        make_short_update.py apply <file>   → יומן; יציאה 0 = הוחל ונבדק
        make_short_update.py undo           → יומן
        make_short_update.py selfcheck      → יומן (בלי לשנות כלום)
        make_short_update.py rules          → ההוראות לעוזר (טקסט)
"""
import difflib
import fnmatch
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
HISTORY = Path(os.environ.get("MAKE_SHORT_UPDATES") or DATA / "updates.json")      # לבדיקות: קובץ אחר
GIT_ID = ["-c", "user.name=עדכון מהתיבה (יצירת שורטס)", "-c", "user.email=update-box@localhost"]
FORBIDDEN = ["config.env", "*.env", "*.env.*", "*cookie*", "*token*", "*secret*", "*.toml", "rclone.conf", "*.key",
             "*.pem", "*credential*", "*.vault", "state.json"]

FORMAT_RULES = """=== איך כותבים עדכון לתוכנה "יצירת שורטס" (לעוזר: אדם או בינה מלאכותית) ===
המשתמש מדביק את התשובה שלך כמו שהיא בתיבת "עדכון תוכנה" שבתוכנה. התוכנה מציגה לו מה ישתנה,
מחילה, בודקת את עצמה, ומחזירה הכול לבד אם משהו נשבר. כדי שזה יעבוד — בדיוק בפורמט הזה:

1. שורה ראשונה:  תיאור: <משפט אחד בעברית פשוטה — מה העדכון עושה>
2. אחר כך בלוק אחד או יותר, מאחד שלושת הסוגים:

   (ג — המומלץ לשינוי בקובץ קיים) חפש והחלף: מעתיקים מהקוד את הקטע הקיים בדיוק כמו שהוא (עם ההזחה,
   בלי מספרי שורות), מספיק שורות כדי שיופיע בקובץ פעם אחת בלבד, ואחריו את הנוסח החדש:
   === החלפה: pipeline/scripts/make_short_page.html ===
   <<<<<<< לפני
   <הטקסט הקיים, מילה במילה>
   =======
   <הטקסט החדש במקומו>
   >>>>>>> אחרי
   === סוף החלפה ===
   אפשר כמה זוגות לפני/אחרי בתוך אותו בלוק (הם מוחלים לפי הסדר), וכמה בלוקים לכמה קבצים.

   (א) diff רגיל (unified diff, כמו הפלט של git diff), נתיבים יחסיים לשורש הקוד עם a/ ו-b/:
   ```diff
   --- a/pipeline/scripts/make_short_page.html
   +++ b/pipeline/scripts/make_short_page.html
   @@ -10,3 +10,3 @@
    שורת הקשר
   -שורה ישנה
   +שורה חדשה
    שורת הקשר
   ```
   קובץ חדש: --- /dev/null  ו- +++ b/<נתיב>. מחיקת קובץ: +++ /dev/null.
   שורות ההקשר חייבות להיות זהות לקובץ שאצל המשתמש — בקש ממנו את הקובץ אם אין לך אותו.

   (ב) החלפת קובץ שלם (לקובץ חדש, או לקובץ קטן שיש לך כולו):
   === קובץ: pipeline/scripts/example.py ===
   <כל התוכן החדש של הקובץ, מהשורה הראשונה עד האחרונה>
   === סוף קובץ ===

כללים:
  - רק קבצי טקסט בתוך הקוד. אסור: קבצי הגדרות/מפתחות/עוגיות (config.env, ‎*.env, *cookie*,
    *token*, *secret*, ‎*.toml, rclone.conf), קבצים בינאריים, נתיבים מחוץ לקוד או עם "..".
  - אל תבקש מהמשתמש מפתחות, סיסמאות או את config.env — אף פעם.
  - שינוי בקוד הפייתון נכנס לתוקף אחרי "הפעל מחדש" (כפתור שמופיע אחרי העדכון); שינוי בדף
    (make_short_page.html) — אחרי רענון החלון.
  - קובץ ‎.bat חייב להישאר ASCII בלבד. הפורט של התוכנה 8790, ותמיד 127.0.0.1 ולא localhost.
  - פרטים על מבנה הקוד וכללי העבודה: docs/HANDOFF.md (המשתמש יכול להעתיק גם אותו).
  - חסר לך קוד? ענה רק בשורה אחת:  צריך קבצים: <נתיב>, <נתיב>:<משורה>-<עד שורה>, <נתיב>#<שם פונקציה>
    — בלי שום דבר אחר. התוכנה מזהה את השורה הזאת ומעתיקה למשתמש בדיוק את מה שביקשת.
"""


def _pc():
    """4.5: רישום שינויים אישיים — רק אצל מקבל (התקנה מחבילה); בעץ הפיתוח של הבעלים — לא."""
    try:
        import make_short_personal as PC
        return PC if PC.active(REPO) else None
    except Exception:
        return None


def git(*a, check=False, inp=None):
    r = subprocess.run(["git", "-C", str(REPO), *GIT_ID, *a], capture_output=True, text=True, input=inp)
    if check and r.returncode:
        raise RuntimeError((r.stderr or r.stdout).strip()[-600:])
    return r


def say(s):
    print(s, flush=True)


# ─────────────── פירוק הטקסט ───────────────

FENCE_RX = re.compile(r"^```[ \t]*([\w-]*)[ \t]*\r?\n(.*?)^```[ \t]*$", re.M | re.S)
# 27/10: צ'אטים (claude.ai) מעצבים: סימוני כיוון בתחילת שורה עברית, **הדגשה** סביב סימן, רווח קשיח. בקוד עצמו יש
# סימוני כיוון אמיתיים באמצע שורות (karaoke_ass.py!) — לכן מורידים אותם רק בתחילת שורה ובשורות הסימנים, לא בכל מקום.
BIDI = "‎‏‪‫‬‭‮⁦⁧⁨⁩﻿"
LEAD_BIDI = re.compile("^[%s]+" % BIDI, re.M)
START_RX = re.compile(r"^===\s*(קובץ|FILE|החלפה|EDIT)\s*:\s*(.+?)\s*===$")
END_RX = re.compile(r"^===\s*(סוף קובץ|END FILE|סוף החלפה|END EDIT)\s*===$")
NEED_RX = re.compile(r"^[\s*_>#-]*(?:אני\s+)?(?:צריך|צריכה|חסרים|חסר|need|needed)\s+(?:את\s+)?(?:ה)?(?:קבצים|קובץ|files?)"
                     r"\s*[*_]*\s*:\s*[*_]*\s*(.+)$", re.M | re.I)
LNUM = re.compile(r"^\s*\d{1,5}\s?[|│:]\s?")       # "  123| קוד" — מספרי שורות שהועתקו בטעות מהקוד שנשלח לצ'אט


def _marker(line):
    """שורה אחרי ניקוי עיצוב של צ'אט — רק כדי לזהות סימן (=== … === / <<<<<<< / ======= / >>>>>>>).
    רווחים בתחילת השורה *לא* מורדים: שורה מוזחת בתוך קוד (כמו הדוגמאות ב-FORMAT_RULES) אינה סימן."""
    return line.strip(BIDI + "*`_").rstrip()


def _unfence(lines):
    """עוזרים עוטפים לפעמים את התוכן ב-``` — מורידים עטיפה שלמה אחת."""
    a = [x for x in lines]
    while a and not a[0].strip():
        a.pop(0)
    while a and not a[-1].strip():
        a.pop()
    if len(a) >= 2 and a[0].strip().startswith("```") and a[-1].strip() == "```":
        return a[1:-1]
    return lines


def _pairs(body, path, errors):
    """זוגות <<<<<<< לפני / ======= / >>>>>>> אחרי בתוך בלוק החלפה."""
    pairs, state, old, new = [], None, [], []
    for l in body:
        c = _marker(l)
        if re.match(r"^<{7}(\s|$)", c):
            state, old, new = "old", [], []
        elif c == "=======" and state == "old":
            state = "new"
        elif re.match(r"^>{7}(\s|$)", c) and state == "new":
            pairs.append(("\n".join(_unfence(old)), "\n".join(_unfence(new))))
            state = None
        elif state == "old":
            old.append(l)
        elif state == "new":
            new.append(l)
    if state:
        errors.append("%s: זוג לפני/אחרי לא נסגר (חסרה השורה «>>>>>>> אחרי») — אולי התשובה נקטעה באמצע" % path)
    elif not pairs:
        errors.append("%s: בבלוק ההחלפה אין זוג «<<<<<<< לפני / ======= / >>>>>>> אחרי»" % path)
    return pairs


def parse(text):
    """→ {"desc", "files": [(path, content)], "edits": [(path, old, new)], "diffs": [str], "needs": [str], "errors": [str]}"""
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    out = {"desc": "", "files": [], "edits": [], "diffs": [], "needs": [], "errors": []}
    rest, i = [], 0
    while i < len(lines):
        m = START_RX.match(_marker(lines[i]))
        if not m:
            rest.append(lines[i])
            i += 1
            continue
        kind = "edit" if m.group(1) in ("החלפה", "EDIT") else "file"
        path = m.group(2).strip().strip("`\"'*")
        body, j = [], i + 1
        while j < len(lines):
            c = _marker(lines[j])
            if END_RX.match(c) or (kind == "edit" and START_RX.match(c)):
                break
            body.append(lines[j])
            j += 1
        closed = j < len(lines) and END_RX.match(_marker(lines[j]))
        if kind == "file":
            if not closed:
                out["errors"].append("%s: חסרה שורת הסיום «=== סוף קובץ ===» — כנראה התשובה נקטעה באמצע. "
                                     "לבקש מהעוזר לכתוב שוב (או להשתמש ב«=== החלפה ===» רק לחלק שמשתנה)." % path)
            else:
                content = LEAD_BIDI.sub("", "\n".join(_unfence(body)))
                out["files"].append((path, content.rstrip("\n") + "\n"))
        else:
            out["edits"] += [(path, o, n) for o, n in _pairs(body, path, out["errors"])]
        i = j + 1 if closed else j
    rest = LEAD_BIDI.sub("", "\n".join(rest))
    rest = re.sub(r"^ ", " ", rest, flags=re.M)          # רווח קשיח בתחילת שורת הקשר של diff
    m = re.search(r"^[\s*_#>]*(?:תיאור|Description)\s*[*_]*\s*:\s*[*_]*\s*(.+?)[*_\s]*$", rest, re.M)
    if m:
        out["desc"] = m.group(1).strip()[:200]
    for f in FENCE_RX.finditer(rest):
        body = f.group(2)
        if f.group(1).lower() in ("diff", "patch") or re.search(r"^(diff --git |--- \S)", body, re.M):
            out["diffs"].append(body if body.endswith("\n") else body + "\n")
    if not out["diffs"] and not FENCE_RX.search(rest):
        m = re.search(r"^(diff --git |--- (?:a/|/dev/null|\S))", rest, re.M)
        if m and re.search(r"^\+\+\+ ", rest, re.M) and re.search(r"^@@ ", rest, re.M):
            out["diffs"].append(rest[m.start():].rstrip("\n") + "\n")
    if not out["files"] and not out["diffs"] and not out["edits"]:
        nm = NEED_RX.search(rest)
        if nm:
            items = [x.strip("`'\"*.;()[]") for x in re.split(r"[,،\s]+(?:ו-?)?", nm.group(1))]
            out["needs"] = [x for x in dict.fromkeys(items) if x and re.search(r"[./#]", x)][:30]
        if not out["needs"] and not out["errors"]:
            out["errors"].append("לא מצאתי בטקסט עדכון בפורמט הנכון (=== החלפה: … ===, בלוק ```diff או === קובץ: … ===). "
                                 "בקשו מהעוזר לכתוב לפי ההוראות שהועתקו לו.")
    return out


class EditMiss(ValueError):
    """קטע «לפני» שלא נמצא — עם השורה הכי קרובה בקובץ (כדי לשלוח לצ'אט את האזור האמיתי)."""
    def __init__(self, msg, near=0):
        super().__init__(msg)
        self.near = near


def _norm(l):
    return l.replace(" ", " ").translate({ord(c): None for c in BIDI}).rstrip()


def _indent(l):
    return l[:len(l) - len(l.lstrip(" \t"))]


def apply_edit(cur, old, new):
    """חפש והחלף אחד → התוכן החדש. קודם התאמה מדויקת; אחר כך לפי שורות, סלחני לרווחים בסוף שורה, לסימוני כיוון,
    למספרי שורות שהועתקו ולהזחה שזזה כולה. שורה ב«אחרי» שזהה (אחרי הניקוי) לשורה ישנה — נכתבת בדיוק כמו בקובץ."""
    if not old.strip():
        raise EditMiss("הקטע «לפני» ריק — לקובץ חדש להשתמש ב«=== קובץ: … ===»")
    n = cur.count(old)
    if n == 1:
        return cur.replace(old, new, 1)
    if n > 1:
        raise EditMiss("הקטע «לפני» מופיע %d פעמים בקובץ — צריך להוסיף שורות מסביב כדי שיהיה ייחודי" % n,
                       cur[:cur.index(old)].count("\n") + 1)
    fl, ol, nl = cur.split("\n"), old.split("\n"), new.split("\n")
    if all(LNUM.match(x) for x in ol if x.strip()):
        ol = [LNUM.sub("", x, 1) for x in ol]
        nl = [LNUM.sub("", x, 1) if LNUM.match(x) else x for x in nl]
    while ol and not ol[0].strip():
        ol.pop(0)
    while ol and not ol[-1].strip():
        ol.pop()
    fk = [_norm(x) for x in fl]
    for loose in (False, True):                       # True = גם ההזחה של כל הקטע זזה (הועתק בלי רווחים בהתחלה)
        key = [(_norm(x).lstrip() if loose else _norm(x)) for x in ol]
        cmp = [x.lstrip() for x in fk] if loose else fk
        hits = [i for i in range(len(fl) - len(key) + 1) if cmp[i] == key[0] and cmp[i:i + len(key)] == key]
        if len(hits) > 1:
            raise EditMiss("הקטע «לפני» מופיע %d פעמים בקובץ — צריך להוסיף שורות מסביב כדי שיהיה ייחודי" % len(hits),
                           hits[0] + 1)
        if not hits:
            continue
        i = hits[0]
        window = fl[i:i + len(key)]
        out = list(nl)
        if loose:                                     # אותו הפרש הזחה גם לשורות החדשות
            fi, oi = _indent(window[0]), _indent(ol[0])
            if fi.startswith(oi):
                out = [(fi[len(oi):] + x) if x.strip() else x for x in out]
            elif oi.startswith(fi) and all(x.startswith(oi[len(fi):]) or not x.strip() for x in out):
                out = [x[len(oi) - len(fi):] if x.strip() else x for x in out]
            else:
                raise EditMiss("הקטע נמצא אבל ההזחה שלו שונה מהקובץ — לבקש מהעוזר להעתיק את הקטע בדיוק", i + 1)
        orig = {}
        for w in window:
            orig.setdefault(_norm(w), w)
        out = [orig.get(_norm(x), x) for x in out]
        return "\n".join(fl[:i] + out + fl[i + len(key):])
    first = next((x.strip() for x in ol if x.strip()), "")
    near = difflib.get_close_matches(_norm(first).strip(), [x.strip() for x in fk], n=1, cutoff=0.55)
    line = next((k + 1 for k, x in enumerate(fk) if near and x.strip() == near[0]), 0)
    raise EditMiss("לא מצאתי בקובץ את הקטע «לפני» שמתחיל ב«%s»%s" % (
        first[:70], (" — הכי דומה לו: שורה %d" % line) if line else ""), line)


def strip_level(diff):
    plus = re.findall(r"^\+\+\+ (\S+)", diff, re.M) + re.findall(r"^--- (\S+)", diff, re.M)
    plus = [p for p in plus if p != "/dev/null"]
    return 1 if plus and all(p.startswith(("a/", "b/")) for p in plus) else 0


def diff_paths(diff, p):
    """כל הנתיבים שה-diff נוגע בהם (שני הצדדים, כולל שינוי שם)."""
    paths = set()
    # 4.1.0: כל השורה (חוץ מחותמת זמן אחרי tab), לא רק עד הרווח הראשון — נתיב עם מירכאות / רווח (git מצטט אותו בסגנון C
    # ו-\S+ היה רואה רק חלק ממנו) נכנס כמו שהוא ונדחה ב-path_problem, במקום לעקוף את בדיקות האסור וה-gitignore
    for rx in (r"^\+\+\+ (.+)$", r"^--- (.+)$"):
        for x in re.findall(rx, diff, re.M):
            x = x.split("\t")[0].rstrip("\r ")
            if x != "/dev/null":
                paths.add(x.split("/", p)[-1] if p and not x.startswith('"') else x)
    for x in re.findall(r"^(?:rename|copy) (?:from|to) (.+)$", diff, re.M):
        paths.add(x.strip())
    for line in re.findall(r"^diff --git (.+)$", diff, re.M):
        m = re.fullmatch(r"a/(\S+) b/(\S+)", line.strip())
        if m:
            paths.update(m.groups())
        else:
            paths.add(line.strip())                 # מצוטט / עם רווחים — נדחה
    return paths


def path_problem(rel):
    if rel and re.search(r"[\"\s\x00-\x1f]", rel):
        return "נתיב עם מירכאות, רווח או תו מיוחד"
    if not rel or rel.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", rel) or "\\" in rel:
        return "נתיב לא יחסי"
    parts = rel.split("/")
    if ".." in parts or "." in parts or "" in parts:
        return "נתיב עם .. או ריק"
    if parts[0] == ".git":
        return "בתוך .git"
    full = (REPO / rel).resolve()
    if REPO.resolve() not in full.parents:
        return "מחוץ לקוד"
    base = parts[-1].lower()
    for pat in FORBIDDEN:
        if fnmatch.fnmatch(base, pat):
            return "קובץ הגדרות/מפתחות — אסור לשנות מכאן"
    if (REPO / rel).is_symlink():
        return "קישור (symlink)"
    if git("check-ignore", "-q", rel).returncode == 0:
        return "קובץ שמוחרג מ-git (לא חלק מהקוד)"
    return ""


def check(text):
    """בדיקה בלי לשנות כלום → {"ok", "desc", "files": [...], "preview", "errors", "warnings", "needs", "misses"}"""
    c = plan(text)
    c.pop("contents")
    c.pop("diff_plan")
    return c


def plan(text):
    """כמו check, ועוד מה שההחלה צריכה: התוכן החדש של כל קובץ (contents) וה-diffs עם הדגלים שלהם."""
    P = parse(text)
    errors, warnings, files, preview, misses = list(P["errors"]), [], [], [], []
    contents, diff_plan = {}, []
    if not (REPO / ".git").exists():
        warnings.append("אין כאן git — ייווצר לפני העדכון (כדי שאפשר יהיה לבטל)")
    full = {p for p, _ in P["files"]}
    edited = {}
    for path, old, new in P["edits"]:
        prob = path_problem(path)
        if prob:
            errors.append("%s: %s" % (path, prob))
            continue
        if path in full:
            errors.append("%s: גם החלפת קובץ שלם וגם «החלפה» באותו קובץ — לבחור אחד" % path)
            continue
        if path not in edited:
            if not (REPO / path).is_file():
                errors.append("%s: אין קובץ כזה — לקובץ חדש להשתמש ב«=== קובץ: … ===»" % path)
                edited[path] = None
                continue
            edited[path] = (REPO / path).read_text(encoding="utf-8", errors="replace")
        if edited[path] is None:
            continue
        try:
            edited[path] = apply_edit(edited[path], old, new)
        except EditMiss as e:
            errors.append("%s: %s" % (path, e))
            misses.append({"path": path, "line": e.near, "first": next((x.strip() for x in old.split("\n") if x.strip()), "")[:120]})
    missed = {m["path"] for m in misses}                 # קובץ שאחת ההחלפות בו לא נמצאה — לא מוצג כאילו הוא משתנה
    file_list = list(P["files"]) + [(p, c) for p, c in edited.items() if c is not None and p not in missed]
    for path, content in file_list:
        prob = path_problem(path)
        if prob:
            errors.append("%s: %s" % (path, prob))
            continue
        if "\x00" in content:
            errors.append("%s: תוכן בינארי" % path)
            continue
        cur = (REPO / path).read_text(encoding="utf-8", errors="replace") if (REPO / path).is_file() else None
        if cur == content:
            warnings.append("%s: התוכן זהה למה שכבר יש — אין שינוי" % path)
        d = list(difflib.unified_diff((cur or "").splitlines(), content.splitlines(), "a/" + path, "b/" + path,
                                      lineterm="", n=2))
        plus = sum(1 for l in d if l.startswith("+") and not l.startswith("+++"))
        minus = sum(1 for l in d if l.startswith("-") and not l.startswith("---"))
        kind = "קובץ חדש" if cur is None else ("החלפה מלאה" if path in full else "שינוי (חפש והחלף)")
        files.append({"path": path, "kind": kind, "plus": plus, "minus": minus})
        contents[path] = content
        preview.append("\n".join(d[:400]) + ("\n… (עוד %d שורות)" % (len(d) - 400) if len(d) > 400 else ""))
    for diff in P["diffs"]:
        if re.search(r"^(GIT binary patch|Binary files .* differ)", diff, re.M) or \
                re.search(r"^(new file mode|new mode|old mode|deleted file mode) 120000", diff, re.M):
            errors.append("העדכון כולל שינוי בינארי או קישור — לא נתמך")
            continue
        p = strip_level(diff)
        bad = [(x, path_problem(x)) for x in sorted(diff_paths(diff, p))]
        bad = [b for b in bad if b[1]]
        if bad:
            errors += ["%s: %s" % b for b in bad]
            continue
        both = sorted(diff_paths(diff, p) & (set(contents) | set(edited)))
        if both:
            errors.append("%s: גם diff וגם החלפה/קובץ שלם באותו קובץ — לבחור אחד" % ", ".join(both))
            continue
        # 27/10: צ'אט שינה רווחים בשורות ההקשר, או כתב diff בלי שורות הקשר בכלל — עוד ניסיונות, מהזהיר לסלחני
        for flags in (["--recount"], ["--recount", "--ignore-whitespace"], ["--recount", "--ignore-whitespace", "--unidiff-zero"]):
            r = git("apply", "--check", "--whitespace=nowarn", *flags, "-p%d" % p, "-", inp=diff)
            if not r.returncode:
                break
        if r.returncode:
            why = [l for l in r.stderr.strip().splitlines() if l.startswith("error:")] or r.stderr.strip().splitlines() or ["?"]
            errors.append("ה-diff לא מתאים לגרסה שאצלכם (השורות שהוא משנה לא נמצאו כמו שהן). אפשר לבקש מהעוזר "
                          "«=== החלפה ===» (חפש והחלף) במקום. פרטים: " + why[0][:200])
            continue
        diff_plan.append((diff, p, flags))
        st = git("apply", "--numstat", *flags, "-p%d" % p, "-", inp=diff).stdout
        gone = {x.split("/", p)[-1] if p else x for x in re.findall(r"^--- (\S+)[^\n]*\n\+\+\+ /dev/null", diff, re.M)}
        for line in st.splitlines():
            a, dl, path = (line.split("\t", 2) + ["", ""])[:3]
            if a == "-":
                errors.append("%s: שינוי בינארי — לא נתמך" % path)
                continue
            exists = (REPO / path).exists()
            kind = "מחיקה" if path in gone else ("קובץ חדש" if not exists else "שינוי")
            files.append({"path": path, "kind": kind, "plus": int(a or 0), "minus": int(dl or 0)})
        preview.append(diff.rstrip("\n"))
    if any(f["path"].endswith(".py") for f in files):
        warnings.append("משנה קוד פייתון — ייכנס לתוקף אחרי \"הפעל מחדש\"")
    if any(f["path"].endswith(".bat") or f["path"].endswith(".bat.txt") for f in files):
        warnings.append("משנה קובץ הפעלה של ווינדוס — ייכנס לתוקף רק בהתקנה הבאה")
    if P["needs"]:
        warnings = []                        # תשובה של "צריך קבצים" — לא עדכון, ואין מה להזהיר
    return {"ok": not errors and bool(files), "desc": P["desc"], "files": files, "preview": "\n\n".join(preview),
            "errors": errors, "warnings": warnings, "needs": P["needs"], "misses": misses,
            "contents": contents, "diff_plan": diff_plan}


# ─────────────── בדיקה עצמית ───────────────

def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def js_check(html_path):
    """ה-JavaScript שבדף נטען (רק תחביר, בלי להריץ) — עם deno או node אם יש."""
    tool = shutil.which("node") or shutil.which("deno") or next(
        (str(p) for p in (DATA / "deno" / "bin" / "deno", Path.home() / ".deno" / "bin" / "deno") if p.exists()), None)
    if not tool:
        return None
    html = html_path.read_text(encoding="utf-8")
    scripts = re.findall(r"<script>(.*?)</script>", html, re.S)
    with tempfile.TemporaryDirectory() as td:
        for i, s in enumerate(scripts):
            f = Path(td) / ("s%d.js" % i)
            f.write_text("new Function(%s);\n" % json.dumps(s), encoding="utf-8")
            cmd = [tool, "--check", str(f)] if tool.endswith("node") else [tool, "run", "--quiet", "--no-prompt", str(f)]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60, env=dict(os.environ, NO_COLOR="1"))
            if r.returncode:
                out = re.sub(r"\x1b\[[0-9;]*m", "", r.stderr or r.stdout).strip().splitlines() or ["שגיאה"]
                return next((l.strip() for l in out if "Error" in l), out[0].strip())[:200]
    return ""


def selfcheck():
    """True/False + יומן. לא משנה כלום (שרת הבדיקה בתיקייה זמנית ובמצב בדיקה)."""
    ok = True
    files = git("ls-files").stdout.splitlines()
    py = [f for f in files if f.endswith(".py")]
    bad = []
    for f in py:
        try:
            compile((REPO / f).read_text(encoding="utf-8"), f, "exec")
        except (SyntaxError, UnicodeDecodeError, OSError) as e:
            bad.append("%s: %s" % (f, e))
    say("   %s קבצי פייתון נטענים (%d)" % ("✓" if not bad else "✗", len(py)))
    for b in bad[:5]:
        say("      " + b)
    ok &= not bad
    bad = []
    for f in (f for f in files if f.endswith(".sh")):
        r = subprocess.run(["bash", "-n", str(REPO / f)], capture_output=True, text=True)
        if r.returncode:
            bad.append("%s: %s" % (f, r.stderr.strip()[:150]))
    for f in (f for f in files if f.endswith(".json") or f.endswith(".webmanifest")):
        try:
            json.loads((REPO / f).read_text(encoding="utf-8"))
        except (ValueError, OSError) as e:
            bad.append("%s: %s" % (f, e))
    say("   %s סקריפטים ו-JSON" % ("✓" if not bad else "✗"))
    for b in bad[:5]:
        say("      " + b)
    ok &= not bad
    js = js_check(HERE / "make_short_page.html")
    if js is None:
        say("   (אין deno/node — בדיקת ה-JavaScript של הדף דולגה)")
    else:
        say("   %s ה-JavaScript של הדף%s" % ("✓" if not js else "✗", "" if not js else ": " + js))
        ok &= not js
    if not ok:
        return False
    # שרת בדיקה: פורט פנוי, מצב בדיקה, הגדרות בעותק זמני — לא נוגע בשרת שלו (8790)
    port = free_port()
    with tempfile.TemporaryDirectory() as td:
        sett = Path(td) / "settings.json"
        real = Path(os.environ.get("MAKE_SHORT_SETTINGS") or
                    Path(os.environ.get("SHORTS_CONFIG_DIR") or os.path.expanduser("~/.config/yeshiva-shorts")) /
                    "make_short_settings.json")
        if real.exists():
            shutil.copy(real, sett)
        env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_IDLE_EXIT="0", MAKE_SHORT_NO_EXPORT="1",
                   MAKE_SHORT_SETTINGS=str(sett), PYTHONUNBUFFERED="1")
        log = open(Path(td) / "server.log", "w+", encoding="utf-8")
        p = subprocess.Popen([sys.executable, str(HERE / "make_short_app.py")], env=env, stdout=log, stderr=subprocess.STDOUT,
                             cwd=td)
        got, err = {}, ""
        try:
            for _ in range(60):
                if p.poll() is not None:
                    break
                try:
                    got["/"] = urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=3).read()
                    got["/api/home"] = urllib.request.urlopen("http://127.0.0.1:%d/api/home" % port, timeout=10).read()
                    break
                except OSError:
                    time.sleep(0.5)
        finally:
            if p.poll() is None:
                p.terminate()
                try:
                    p.wait(10)
                except subprocess.TimeoutExpired:
                    p.kill()
            log.seek(0)
            err = log.read()[-600:]
            log.close()
        page_ok = b"<html" in got.get("/", b"")
        try:
            home_ok = "folders" in json.loads(got.get("/api/home", b"{}"))
        except ValueError:
            home_ok = False
        say("   %s שרת בדיקה עלה ועונה (/ ו-/api/home, פורט %d)" % ("✓" if page_ok and home_ok else "✗", port))
        if not (page_ok and home_ok):
            for l in err.strip().splitlines()[-6:]:
                say("      " + l)
        return page_ok and home_ok


# ─────────────── החלה / ביטול ───────────────

def hist_load():
    try:
        return json.loads(HISTORY.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def hist_save(h):
    HISTORY.parent.mkdir(parents=True, exist_ok=True)
    tmp = HISTORY.with_suffix(".tmp")
    tmp.write_text(json.dumps(h, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(HISTORY)


def ensure_repo():
    if not (REPO / ".git").exists():
        git("init", "-q", "-b", "main", check=True)
        git("add", "-A", check=True)
        git("commit", "-q", "-m", "גרסה התחלתית (נוצרה לפני עדכון ראשון)", check=True)


def snapshot(msg):
    """4.5.x (C1): רק קבצים שכבר במעקב (add -u). קבצים חדשים ועריכות ידניות של מקבל נרשמים קודם כשינוי אישי
    (PC.register_manual); קבצים חדשים אחרים (למשל קובץ הגדרות/מפתח שנשכח בתיקייה) לא נבלעים ל-commit."""
    git("add", "-u", check=True)
    if git("diff", "--cached", "--quiet").returncode:
        git("commit", "-q", "-m", msg, check=True)
    return git("rev-parse", "HEAD", check=True).stdout.strip()


def selftest_quick():
    """27/10: אחרי הבדיקה העצמית — גם make_short_selftest.py quick (כללי הברזל, השרת, סיום אמיתי של קליף זעיר)."""
    if os.environ.get("MAKE_SHORT_UPDATE_NO_SELFTEST") == "1":
        say("   (בדיקת האיכות המהירה דולגה — מצב בדיקה)")
        return True
    say("🧪 בדיקת איכות מהירה (make_short_selftest.py quick, פחות מדקה) ...")
    t0 = time.time()
    try:
        r = subprocess.run([sys.executable, str(HERE / "make_short_selftest.py"), "quick", "--json"], capture_output=True,
                           text=True, errors="replace", timeout=900)
        res = json.loads(next((l for l in reversed(r.stdout.splitlines()) if l.startswith("{")), "{}"))
    except (subprocess.TimeoutExpired, ValueError, OSError) as e:
        res = {"ok": False, "errors": ["בדיקת האיכות לא הסתיימה: %s" % str(e)[:150]]}
    good = bool(res.get("ok"))
    say("   %s בדיקת האיכות %s (%.0f שניות)" % ("✓" if good else "✗", "עברה" if good else "נכשלה", time.time() - t0))
    for e in (res.get("errors") or ([] if good else ["(אין פירוט)"]))[:8]:
        say("      ✗ " + e)
    return good


def apply(text):
    c = plan(text)
    if not c["ok"]:
        for e in c["errors"] or ["אין מה להחיל"]:
            say("❌ " + e)
        return 1
    desc = c["desc"] or ", ".join(f["path"] for f in c["files"])[:120]
    ensure_repo()
    PC = _pc()
    if PC:
        try:
            PC.before_box(REPO)            # 4.5: נקודת בסיס רשמית (rel-X) לפני שהעץ משתנה
        except Exception:
            pass
        try:                               # 4.5.x (C1): עריכות ידניות → שינוי אישי משלהן, לפני ה"צילום"
            m = PC.register_manual(REPO, "לפני החלה בתיבת העדכון")
            if m:
                say("🧩 עריכות ידניות שמצאתי בקבצים נשמרו כשינוי אישי (%s) — לא יאבדו." % m["id"])
        except Exception as e:
            say("❌ לא הצלחתי לשמור קודם את העריכות הידניות שבקבצים (%s) — לא ממשיכים, כדי לא לאבד אותן." % str(e)[:150])
            return 1
    snap = snapshot("לפני עדכון: " + desc)
    say("📸 נשמר מצב לפני העדכון (%s)" % snap[:7])
    try:
        for path, content in c["contents"].items():
            f = REPO / path
            f.parent.mkdir(parents=True, exist_ok=True)
            mode = f.stat().st_mode if f.exists() else None
            f.write_text(content, encoding="utf-8")
            if mode is not None:
                os.chmod(f, mode)
            elif path.endswith(".sh"):
                os.chmod(f, 0o755)
        for diff, p, flags in c["diff_plan"]:
            git("apply", *flags, "--whitespace=nowarn", "-p%d" % p, "-", inp=diff, check=True)
        git("add", "-A", "--", *sorted({f["path"] for f in c["files"]} | set(c["contents"])), check=True)   # רק מה שהתיבה שינתה
        git("commit", "-q", "-m", "עדכון: " + desc, check=True)
        new = git("rev-parse", "HEAD", check=True).stdout.strip()
        say("✏️ הוחל: %s" % ", ".join("%s (+%d −%d)" % (f["path"], f["plus"], f["minus"]) for f in c["files"]))
    except Exception as e:
        git("reset", "-q", "--hard", snap)
        say("❌ ההחלה נכשלה (%s) — הכול הוחזר למצב שלפני העדכון." % str(e)[:200])
        return 1
    say("🔎 בדיקה עצמית ...")
    if not selfcheck() or not selftest_quick():
        git("reset", "-q", "--hard", snap)
        say("↩️ הבדיקה נכשלה — העדכון בוטל אוטומטית והתוכנה חזרה בדיוק למצב שלפניו. אפשר להעתיק את היומן לעוזר.")
        h = hist_load()
        h.append({"at": time.strftime("%Y-%m-%d %H:%M"), "desc": desc, "snapshot": snap, "commit": new,
                  "files": [f["path"] for f in c["files"]], "status": "rolled_back"})
        hist_save(h)
        return 1
    h = hist_load()
    h.append({"at": time.strftime("%Y-%m-%d %H:%M"), "desc": desc, "snapshot": snap, "commit": new,
              "files": [f["path"] for f in c["files"]], "status": "applied"})
    hist_save(h)
    if PC:
        try:
            pc = PC.after_box(REPO, desc, snap, new)
            if pc:
                say("🧩 נרשם כשינוי אישי שלכם (%s): «%s» — כשיגיע עדכון רשמי הוא יוחל מחדש לבד, אם אפשר." % (pc["id"], pc["desc"][:60]))
        except Exception as e:
            say("(לא הצלחתי לרשום כשינוי אישי: %s — השינוי עצמו הוחל כרגיל)" % str(e)[:80])
    say("✅ העדכון הוחל והבדיקה עברה. %s" % ("כדי שהשינוי בקוד ייכנס לתוקף — \"הפעל מחדש את התוכנה\"."
                                           if any(f["path"].endswith(".py") for f in c["files"]) else
                                           "רעננו את החלון (F5) כדי לראות שינוי בדף."))
    return 0


def last_applied():
    return next((e for e in reversed(hist_load()) if e.get("status") == "applied"), None)


def undo():
    e = last_applied()
    if not e:
        say("אין עדכון להחזיר")
        return 1
    PC = _pc()
    if PC:
        try:                               # 4.5.x (C1): גם לפני ביטול — עריכות ידניות נרשמות קודם
            PC.register_manual(REPO, "לפני ביטול בתיבת העדכון")
        except Exception as ex:
            say("❌ לא הצלחתי לשמור קודם את העריכות הידניות שבקבצים (%s) — לא ממשיכים." % str(ex)[:150])
            return 1
    snapshot("לפני ביטול עדכון: " + e["desc"])
    r = git("revert", "--no-edit", e["commit"])
    if r.returncode:
        git("revert", "--abort")
        say("❌ אי אפשר לבטל אוטומטית — היו שינויים נוספים באותם קבצים אחרי העדכון. (%s)" % r.stderr.strip()[:200])
        return 1
    say("↩️ העדכון «%s» בוטל (%s)" % (e["desc"], git("rev-parse", "--short", "HEAD").stdout.strip()))
    PC = _pc()
    if PC:
        try:
            PC.after_undo(REPO, e["commit"])
        except Exception:
            pass
    h = hist_load()
    for x in h:
        if x["commit"] == e["commit"]:
            x["status"] = "undone"
            x["undone_at"] = time.strftime("%Y-%m-%d %H:%M")
    hist_save(h)
    say("🔎 בדיקה עצמית ...")
    good = selfcheck()
    say("✅ הביטול הושלם — \"הפעל מחדש את התוכנה\" כדי שייכנס לתוקף." if good else
        "⚠️ הביטול הושלם, אבל הבדיקה העצמית מצאה בעיה — להעתיק את היומן לעוזר.")
    return 0 if good else 1


def status():
    e = last_applied()
    return {"last": e and {k: e[k] for k in ("at", "desc", "files")}, "history": hist_load()[-5:],
            "git": (REPO / ".git").exists()}


if __name__ == "__main__":
    a = sys.argv[1:]
    cmd = a[0] if a else ""
    if cmd == "check":
        print(json.dumps(check(Path(a[1]).read_text(encoding="utf-8")), ensure_ascii=False))
    elif cmd == "apply":
        sys.exit(apply(Path(a[1]).read_text(encoding="utf-8")))
    elif cmd == "undo":
        sys.exit(undo())
    elif cmd == "selfcheck":
        sys.exit(0 if selfcheck() else 1)
    elif cmd == "rules":
        print(FORMAT_RULES)
    else:
        sys.exit(__doc__)
