# -*- coding: utf-8 -*-
"""ראשי תיבות לועזיים בכתוביות עבריות — כתיב לטיני + הדגשה.

הבעיה שנולדה מזה (26/8/2026): אחד הדוברים אמר "RPG", whisper העברי כתב
"הרפג'י", וזה נצרב לקליפ. אוסף התווים העברי הזה לא אומר כלום לצופה —
המילה צריכה להופיע באנגלית, ולהיות מודגשת.

שתי פונקציות:
  latinize(word)   "הרפג'י" → "ה-RPG"   (שומר תחילית עברית ופיסוק)
  highlight(text)  עוטף כל רצף לטיני בצבע שונה + הטמעת כיווניות LTR

הרשימה מכוונת לכתיבים ש-ASR באמת מייצר, לא לכל כתיב תיאורטי. כשמתגלה
כתיב חדש בתמלול — להוסיף אותו ל-SPELLINGS ולא לתקן ידנית בטקסט הנקי,
כדי שהריצה הבאה לא תיפול על אותו דבר.
"""
import re

# תווי כיווניות: LRE…PDF מבטיח שרצף לטיני בתוך שורה עברית לא יתהפך
LRE = "‪"
PDF = "‬"

# צבע ההדגשה בפורמט ASS (&HBBGGRR) — זהב, על רקע כתובית לבנה
HIGHLIGHT = "&H0000D7FF&"
DEFAULT_COLOR = "&H00FFFFFF&"

# כתיב עברי (אחרי ניקוי גרשיים/מקפים/נקודות) → הצורה הלטינית
SPELLINGS = {
    "רפגי": "RPG",
    "ארפגי": "RPG",
    "ארפיגי": "RPG",
    "רפיגי": "RPG",
    "ארפיג": "RPG",
    "ארפג": "RPG",
    "גיפיאס": "GPS",
    "גיפיאז": "GPS",
}

# תחיליות עבריות שיכולות להידבק לראשי התיבות ("הרפג'י", "ברפג'י")
PREFIXES = ("כשה", "ומה", "וכש", "שה", "וה", "כש", "מה", "לה", "בה",
            "ה", "ו", "ב", "ל", "כ", "מ", "ש")

_HEB_ONLY = re.compile(r"[^א-ת]")
_LATIN_RUN = re.compile(r"[A-Za-z][A-Za-z0-9]*")
_TRAILING = re.compile(r"^(.*?)([\s.,!?;:\"'׳״)\]]*)$", re.S)


def _core(token: str) -> str:
    """מוריד גרשיים, מקפים, נקודות ופיסוק — משאיר אותיות עבריות בלבד."""
    return _HEB_ONLY.sub("", token)


def latinize(token: str) -> str:
    """מחליף כתיב עברי של ראשי תיבות לועזיים בכתיב לטיני, ושומר תחילית.

    "הרפג'י," → "ה-RPG,"   ·   "רפג'י" → "RPG"   ·   מילה רגילה חוזרת כמו שהיא.
    """
    m = _TRAILING.match(token)
    body, tail = m.group(1), m.group(2)
    core = _core(body)
    if not core:
        return token

    if core in SPELLINGS:
        return SPELLINGS[core] + tail

    for pre in PREFIXES:
        if core.startswith(pre):
            rest = core[len(pre):]
            if rest in SPELLINGS:
                return pre + "-" + SPELLINGS[rest] + tail
    return token


def has_latin(text: str) -> bool:
    return bool(_LATIN_RUN.search(text))


def emphasize(text: str, color: str = HIGHLIGHT) -> str:
    """צובע את **כל** הכתובית בזהב אם יש בה ראשי תיבות לועזיים.

    🚨 למה כל השורה ולא רק המילה: libass מחשב כיווניות (bidi) בנפרד לכל
    קטע-עיצוב, ולכן תגית צבע באמצע שורה עברית מפרקת אותה לשלושה קטעים
    ומסדרת אותם בסדר הפוך — נבדק ברינדור אמיתי (26/8/2026), התוצאה הייתה
    "מילימטר RPGחטפתי את ה-". תגית אחת בתחילת השורה = קטע אחד = סדר תקין.
    אל תחזיר צביעה של מילה בודדת בלי לבדוק את זה שוב בעין.
    """
    if not has_latin(text):
        return text
    return "{\\c%s}%s" % (color, text)


def fix_words(tokens, color=True) -> str:
    # 31/10/2026: { } in a word (from Gemini, the editor or his own edit) would open an ASS override block in libass and the word
    # vanished or the layout broke. Every style (teal/marker/float/plain, burn and preview) gets its text from here, so the
    # braces become full-width ones: same word count, so alignment and layout stay consistent.
    """הצינור המלא לנתח כתובית: כתיב לטיני לכל מילה, ואז הדגשה לשורה.
    color=False — בלי צביעת הזהב (כתוביות הקריוקי, 28/10/2026): שם הזהב צבע את כל הכתובית, כולל שכבת
    ההדגשה, ולכן כתובית עם "D9" יצאה בצבע אחר מכל השאר בקליף. בקריוקי לקליף יש צבע אחד בלבד."""
    fixed = [latinize(t.replace("{", "｛").replace("}", "｝")) for t in tokens]
    line = " ".join(fixed)
    line = _LATIN_RUN.sub(lambda m: LRE + m.group(0) + PDF, line)
    return emphasize(line) if color else line


if __name__ == "__main__":
    import sys
    print(repr(fix_words(sys.argv[1:])))
