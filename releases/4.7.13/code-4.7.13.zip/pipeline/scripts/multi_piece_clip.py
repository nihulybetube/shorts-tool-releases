# -*- coding: utf-8 -*-
"""כמו make_clip.py, אבל המצלמה הווירטואלית מתחילה מחדש בכל חלק של ה-raw.

למה: קליף שבנוי מכמה רגעים רחוקים בשיעור מגיע לכל מעבר כשהרב במקום אחר. המצלמה
(אזור מת + השהיה 1.3ש' + פאן איטי — הכוונון המאושר) המשיכה מהמקום הקודם ונשארה
שם עד 3 שניות, והרב ישב בשוליים (בדיקת המיסגור נפלה: 76% ו-79%).
כאן כל חלק מקבל נקודת פתיחה משלו = אמצע הטווח שבו נמצאות הפנים ב-3 השניות הראשונות
של הקטע שבשימוש. שום קבוע של המעקב לא השתנה.
שימוש: multi_piece_clip.py <clipN> <start,end> [<start,end> ...]"""
import json, subprocess, sys
import numpy as np
import face_track
from build_clean_video import build_clean

name = sys.argv[1]
segs = [tuple(float(v) for v in a.split(",")) for a in sys.argv[2:]]
PAD, HEAD = 0.5, 3.0
pieces = [(a - PAD, b + PAD) for a, b in segs]
raw = f"work/clips/{name}_raw.mp4"
# MPC_PREVIEW=<קובץ> (21/10/2026): תצוגה מקדימה של המצלמה מ"הגדרות מהירות" — אותו raw ואותו
# מסלול מצלמה, רק MPC_PREVIEW_SEC השניות הראשונות ברזולוציה נמוכה (make_short.py preview)
PREVIEW = __import__("os").environ.get("MPC_PREVIEW")
ins, parts = [], []
for i, (a, b) in enumerate(pieces):
    ins += ["-ss", f"{a:.3f}", "-t", f"{b-a:.3f}", "-i", "source/full_video.mp4"]
    parts.append(f"[{i}:v][{i}:a]")
if not (PREVIEW and __import__("os").path.exists(raw)):
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-v", "error"] + ins +
                   ["-filter_complex", "".join(parts) + f"concat=n={len(pieces)}:v=1:a=1[v][a]",
                    "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                    "-c:a", "aac", "-b:a", "192k", raw], check=True)
rel, starts, t = [], [], 0.0
for (a, b), (pa, pb) in zip(segs, pieces):
    starts.append(t)
    rel.append((round(t + PAD, 3), round(t + PAD + (b - a), 3)))
    t += pb - pa

_orig = face_track.virtual_camera
# 28/10/2026 (כרטיס 22): המצלמה לכל חתיכה עברה ל-camera_path.py בלי שינוי, כדי שהמדידה של "הרב
# יוצא מהמסגרת" תחשב את אותו מסלול בדיוק בלי לבנות. ההיסטוריה (12/10 קבוצות, 21/10 חציון) — שם.
import camera_path
MIN_GROUP = float(__import__("os").environ.get("CAM_MIN_PIECE", "6"))
def per_piece_camera(target, fps):
    return camera_path.per_piece_camera(target, fps, starts, segs, MIN_GROUP, vc=_orig, pad=PAD, head=HEAD)
import os
# CAM_SMOOTH: חלון ההחלקה של מסלול הפנים (ברירת מחדל 1.5/1.0ש'). רב שמתנדנד מצד לצד
# (קליף 3: 0.29–0.59 מרוחב המקור, כמעט כל חלון הקרופ) — המצלמה רודפת אחרי כל תנודה
# ומאחרת בחצי מחזור. חלון ארוך = עוקבת אחרי המיקום הממוצע שלו, לא אחרי הנדנוד.
# CAM_ZIPPY=1 (28/10): מצלמה זריזה — רגילה, ומאיצה רק כשהפנים מתקרבות לקצה (face_track.ZIPPY).
camera_path.apply_env()
if os.environ.get("CAM_PER_PIECE", "1") == "1":
    face_track.virtual_camera = per_piece_camera

if PREVIEW:
    # MPC_PREVIEW_AT (28/10): התצוגה מתחילה ברגע הבעייתי (שנייה בקליף), לא בהתחלה
    build_clean(raw, f"work/clips/{name}_transforms.trf", PREVIEW, segments=rel, cut_silence=False,
                preview=float(os.environ.get("MPC_PREVIEW_SEC", "10")),
                preview_at=float(os.environ.get("MPC_PREVIEW_AT", "0")))
    print(name, "preview", PREVIEW)
    sys.exit(0)
res = build_clean(raw, f"work/clips/{name}_transforms.trf", f"work/clips/{name}_clean.mp4",
                  segments=rel, cut_silence=False)
json.dump({"source_segments": segs, "raw_segments": rel, "camera": "per-piece reset, median of the group (near the first 3s)"},
          open(f"work/clips/{name}_segments.json", "w"), indent=1)
print(name, "raw segments", rel)
