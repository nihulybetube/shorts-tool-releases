# -*- coding: utf-8 -*-
"""
make_short_app.py — החלון של make_short.py: דף בדפדפן, בלי שום התקנה נוספת.

למה דף ולא חלון של תוכנה: עברית מימין לשמאל, נגן וידאו ותיבות טקסט עובדים בדפדפן
בלי כלום, וב-Tk (חלון של פייתון) עברית יוצאת הפוכה. השרת רץ ב-WSL ומקשיב רק
ל-localhost, כך שאף אחד מחוץ למחשב לא מגיע אליו.

20/10/2026: כמה שיעורים במקביל (לשונית לכל שיעור), "הגדרות מתקדמות"
(make_short_settings.py), ספריית מוזיקה (make_short_music.py), בדיקת מערכת בפתיחה
(make_short_health.py). הבנייה הכבדה — אחת בכל פעם: התור הוא נעילה בתוך make_short.py
(heavy), כך שהוא תופס גם כשמריצים מהטרמינל.

הדף עצמו: make_short_page.html (נקרא מחדש בכל טעינה).
שימוש: shorts.sh py make_short_app.py   → http://localhost:8790
(ב-Windows: "יצירת שורטס.bat" בתיקיית הפרויקט מפעיל את זה ופותח את הדפדפן.)
"""
import base64
import itertools
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid as uuidlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import make_short_clean as CLEAN  # noqa: E402
import make_short_health as HEALTH  # noqa: E402
import make_short_engine as ENG  # noqa: E402
import make_short_modal_day as MD  # noqa: E402
import make_short_layout as LAYOUT  # noqa: E402
import make_short_emph as EMPH  # noqa: E402
import make_short_editor as ED  # noqa: E402
import make_short_rabbis as RABBIS  # noqa: E402
import make_short_music as MUSIC  # noqa: E402
import make_short_pick as PICK  # noqa: E402
import make_short_progress as PR  # noqa: E402
import make_short_settings as SET  # noqa: E402
import make_short_share as SHARE  # noqa: E402
import make_short_snap as SNAP  # noqa: E402
import make_short_update as UPD  # noqa: E402
import make_short_release as REL  # noqa: E402
import make_short_publish as PUB  # noqa: E402
import make_short_proposals as PROP  # noqa: E402
import make_short_personal as PERS  # noqa: E402
import make_short_chat as CHAT  # noqa: E402
import make_short_fix as FIX  # noqa: E402
import tool_finder as TOOLS  # noqa: E402

PORT = int(os.environ.get("MAKE_SHORT_PORT", "8790"))
PROJECTS = Path(os.environ.get("SHORTS_PROJECTS", os.path.expanduser("~/.local/share/yeshiva-shorts/projects")))
TOOL = MS.TOOL_DIR
EXPORT = Path(os.environ.get("SHORTS_EXPORT_DIR") or os.path.expanduser("~/Videos/Shorts"))
SPECS = PROJECTS.parent / "app_specs"
LOGS = PROJECTS.parent / "logs"
APP_LOG = LOGS / "make_short_app.log"
BRAND = SET.CONFIG / "brand"
APP_DIR = HERE.parent.parent / "assets" / "app"          # הסמל של התוכנה (לשורת המשימות ולקיצור)
ICONS = {"/favicon.ico": ("icon.ico", "image/x-icon"), "/icon-192.png": ("icon-192.png", "image/png"),
         "/icon-512.png": ("icon-512.png", "image/png"),
         "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json")}
HEEBO = Path(os.environ.get("SHORTS_LIB", str(HERE.parent.parent / "assets"))) / "fonts" / "Heebo900.ttf"

JOBS = {}                       # id → עבודה (הכנה / סיום / בנייה חלקה / החלפת מוזיקה / עדכון)
LOCK = threading.Lock()
IDS = itertools.count(1)
# ver עולה בכל שינוי — הדף מצייר את ההתראות מחדש מתוך /api/lessons, בלי לחכות ל"בדיקת מערכת" (22/10).
# actions = התוצאה של כפתורי התיקון (עדכון yt-dlp, חיבור הדרייב, עוגיות) — מוצגת במקום הכפתור.
HEALTH_STATE = {"running": False, "data": None, "ver": 0, "actions": {}, "rechecking": set()}
STAGES = {"queued": "בתור", "building": "נבנה", "working": "בעבודה", "ready_edit": "מוכן לעריכה", "done": "מוכן",
          "pick_ready": "הצעות לבדיקה"}
BUILD_Q = []                    # סריקת פלייליסט → "הכן" לכמה שיעורים: אחד אחרי השני (הורדות במקביל מציפות)
# 21/10/2026 (בקשתו: "שזה יהיה חזק, ויישאר"): התור נשמר לקובץ בכל שינוי, ובפתיחה הבאה ממשיך לבד —
# גם אחרי סגירת החלון השחור, כיבוי או הפסקת חשמל. בבדיקה (MAKE_SHORT_NO_EXPORT) — קובץ נפרד.
QUEUE_FILE = Path(os.environ.get("MAKE_SHORT_QUEUE") or
                  PROJECTS.parent / ("build_queue%s.json" % ("_test" if MS.TEST_MODE else "")))
QSEQ = itertools.count(1)
PREVIEWS = {}                   # תצוגות מקדימות של "הגדרות מהירות" (מוזיקה / מצלמה) — לא עבודות, לא בלשוניות
PREV_IDS = itertools.count(1)
# סגירה אוטומטית (21/10/2026 — הוא שאל אם החלון השחור נסגר עם התוכנה): הדף מחזיק חיבור פתוח
# (/api/alive). אין אף דף פתוח ~דקה, ואין עבודה רצה או ממתינה → השרת יוצא והחלון השחור נסגר.
# חיבור פתוח ולא טיימר: חלון ממוזער מאט טיימרים לפעם בדקה, והשרת היה נסגר מתחת לידיים שלו.
IDLE_EXIT = int(os.environ.get("MAKE_SHORT_IDLE_EXIT", "60"))
ALIVE = {"open": 0, "last": time.time()}
# 21/10/2026 — עדכון בלי להפיל עבודה (make_short_snap.py): כל עבודה רצה מצילום קוד קבוע; הקוד בדיסק נבדק כל כמה שניות,
# ועדכון שעבר בדיקה עצמית ייכנס לתוקף (הפעלה מחדש של השרת) ברגע שאין שום עבודה. "boot" = הקוד שהשרת הזה טען.
CODE = {"boot": SNAP.content_hash(), "sig": SNAP.stat_sig(), "pending": None, "failed": None, "checked": "", "files": []}
RESTARTING = {"on": False, "at": 0.0}
RESTART_GRACE = int(os.environ.get("MAKE_SHORT_RESTART_GRACE", "5"))   # שניות בין "מתעדכן" להפעלה — הדף שומר טקסט שהוקלד
CODE_SETTLE = int(os.environ.get("MAKE_SHORT_CODE_SETTLE", "5"))       # שניות שהקבצים צריכים להיות רגועים לפני בדיקה
SNAP_KINDS = ("prepare", "finish", "retime", "restyle", "rebuild", "swap", "save", "drop_saved", "pick", "probe", "clean",
              "editor")
CLEANING = set()                # כרטיס 17: שיעורים שבאמצע "🧹 נקה" — שום עבודה חדשה לא מתחילה עליהם
SNAP_BOOT = ""                                                          # תיקיית הצילום של הקוד הנוכחי (להשוואת "מה השתנה")


APP_LOG_MAX = 2_000_000          # 29/10 (סקירה חיצונית): היומן גדל בלי סוף


def app_log(line):
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        if APP_LOG.exists() and APP_LOG.stat().st_size > APP_LOG_MAX:
            # הישן → ‎.1 (מחליף את הקודם), והחדש מתחיל מ-300 השורות האחרונות — כך "העתק פרטים לעוזר"
            # ו"🐞 מצאתי באג" (שקוראים את הסוף) לא מקבלים יומן ריק מיד אחרי הסבב
            lines = APP_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-300:]
            os.replace(APP_LOG, APP_LOG.with_name(APP_LOG.name + ".1"))
            APP_LOG.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with open(APP_LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def busy(project, clip=""):
    """יש עבודה (רצה או בתור) על השיעור. 21/10/2026 (כרטיס 12): עבודה של קליף אחד (clip) חוסמת רק את אותו
    קליף ואת עבודות השיעור כולו — כך אפשר לשנות מוזיקה בקליף 2 בזמן שקליף 1 נבנה מחדש."""
    for j in JOBS.values():
        if j["kind"] == "save" and not j.get("launched"):      # 4.2.0: שמירה שממתינה בתור לא נחשבת "בעבודה"
            continue
        if j["running"] and (j["project"] == str(project) or str(project) in (j.get("projects") or [])):
            jc = j.get("clip") or ""
            if not clip or not jc or jc == clip:
                return True
    return False


def start_job(kind, cmd, project="", title="", extra=None, deferred=False):
    """deferred=True: העבודה נרשמת ("בתור") אבל התהליך מתחיל רק כשהתור מגיע אליה (launch)."""
    if RESTARTING["on"] or RELS["applying"]:
        raise ValueError("התוכנה מתעדכנת לגרסה חדשה (כמה שניות) — לנסות שוב ברגע")
    clip = (extra or {}).get("clip") or ""
    with LOCK:
        if kind != "engine" and any(j["running"] and j["kind"] == "engine" for j in JOBS.values()):
            raise ValueError("מנוע התמלול מוחלף עכשיו (כמה דקות) — לנסות שוב כשזה יסתיים")
        if project and str(Path(project).resolve()) in CLEANING:
            raise ValueError("השיעור הזה מתנקה עכשיו (🧹) — אי אפשר להתחיל בו עבודה")
        if project and busy(project, clip) and not (extra or {}).get("nobusy"):   # nobusy: שמירה (save_start בודק לבד)
            raise ValueError(("%s כבר בעבודה" % clip.replace("clip", "קליף ") if clip else "השיעור הזה כבר בעבודה")
                             + " — לחכות שיסתיים")
        jid = str(next(IDS))
        JOBS[jid] = {"id": jid, "kind": kind, "project": str(project), "title": title, "log": [],
                     "running": True, "ok": None, "stage": "queued" if deferred else "working",
                     "started": time.strftime("%H:%M"), "t0": time.time(), "cmd": [str(c) for c in cmd],
                     "plan": [], "steps": {}, "launched": not deferred, **(extra or {})}
    if not deferred:
        launch(jid)
    return jid


def launch(jid):
    job = JOBS[jid]
    job.update(stage="working", launched=True, started=time.strftime("%H:%M"), t0=time.time())
    kind, project, title, cmd = job["kind"], job["project"], job["title"], job["cmd"]
    try:
        precheck(kind)                         # 22/10: עוגיות / Gemini / Modal — ברקע, לפני שהעבודה נתקעת עליהם
    except Exception as e:
        app_log("=== precheck: %s" % e)
    if kind in SNAP_KINDS:
        # צילום קוד קבוע לעבודה הזאת: כל סקריפט שהיא קוראת לו נשאר בתוך הצילום, גם אם הקוד בדיסק ישתנה באמצע
        try:
            # קוד שהשתנה בדיסק ועוד לא עבר בדיקה (או נכשל בה) לא נכנס לעבודה חדשה — היא רצה מהצילום של הגרסה הבדוקה האחרונה
            live_ok = SNAP.content_hash() == CODE["boot"] or (CODE["pending"] and CODE["pending"]["hash"] == SNAP.content_hash())
            cmd, job["snap"] = SNAP.rewrite(cmd, dest=None if (live_ok or not SNAP_BOOT) else SNAP_BOOT)
            job["cmd"] = [str(c) for c in cmd]
        except Exception as e:
            app_log("=== snapshot failed (%s) — running from live code" % e)

    def work():
        app_log("=== %s %s %s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), kind, project, title))
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                                 env=dict(os.environ, PYTHONUNBUFFERED="1", **(job.get("env") or {})))
            job["pid"] = p.pid
            if job.get("stopped"):               # 4.1.1: ⛔ נלחץ לפני שהתהליך עלה
                p.terminate()
            for line in p.stdout:
                line = line.rstrip("\n")
                app_log(line)
                if line.startswith("PROJECT="):
                    job["project"] = line[8:].strip()
                elif line.startswith("TITLE="):
                    job["title"] = line[6:].strip()
                elif line.startswith("STAGE="):
                    job["stage"] = line[6:].strip()
                elif line.startswith("PLAN="):         # 21/10: מסך "בעבודה" — שלב אחרי שלב
                    try:
                        job["plan"] = json.loads(line[5:])
                    except ValueError:
                        pass
                elif line.startswith("STEP="):
                    k, _, rest = line[5:].partition("\t")
                    stt, _, det = rest.partition("\t")
                    job.setdefault("steps", {})[k] = {"state": stt, "detail": det, "at": time.time()}
                elif line.startswith("SAVED="):
                    job["saved"] = line[6:].strip()
                else:
                    job["log"].append(line)
                    if line.lstrip().startswith("❌"):
                        job["error"] = line.lstrip()[1:].strip()
            job["ok"] = p.wait() == 0
        except Exception as e:
            job["log"].append("❌ %s" % e)
            job["error"] = str(e)
            job["ok"] = False
        if not job["ok"] and not job.get("error"):
            job["error"] = next((l for l in reversed(job["log"]) if l.strip()), "העבודה נעצרה בלי הסבר")
        job["running"] = False
        job["ended"] = time.strftime("%H:%M")
        job["ended_ts"] = time.time()
        if job.get("qid"):                     # עבודה מהתור — לרשום שנגמרה ולהתחיל את הבאה
            queue_job_ended(job)
        if kind == "clean":                    # כרטיס 17: השיעורים משתחררים, שיעור שנעלם יוצא מהתור ומהלשוניות
            try:
                clean_ended(job)
            except Exception as e:
                CLEANING.difference_update(job.get("clean_projects") or [])
                app_log("=== clean_ended: %s" % e)
        if kind == "share":                    # קובץ שיתוף חדש — "ישן / מעודכן" נבדק שוב מיד
            SHARE_STALE["ts"] = 0
        if kind == "editor":                   # 28/10: העורך החכם סיים — הטיוטות האוטומטיות שחיכו לו
            try:
                editor_ended(job)
            except Exception as e:
                app_log("=== editor ended: %s" % e)
        if kind == "pick" and job["ok"]:       # 28/10: "אוטומטי עד הצריבה" — ההצעות של Gemini נבנות לבד
            for pj in job.get("projects") or [job["project"]]:     # בקשה משותפת לכמה שיעורים — כל אחד
                try:
                    auto_burn_after_pick(dict(job, project=pj))
                except Exception as e:
                    app_log("=== auto burn after pick: %s" % e)
        if kind == "update":                   # 22/10: עדכון yt-dlp → תוצאה במקום הכפתור + בדיקה מחדש
            try:
                ytdlp_update_ended(job)
            except Exception as e:
                app_log("=== ytdlp_update_ended: %s" % e)
        if kind == "engine":                   # 29/10: "נסה מנוע חדש יותר"
            try:
                engine_upgrade_ended(job)
            except Exception as e:
                app_log("=== engine_upgrade_ended: %s" % e)
        try:                                   # 22/10: התראות חיות מתוך העבודה עצמה
            job_end_alerts(job)
        except Exception as e:
            app_log("=== live alerts: %s" % e)
        if kind in MODAL_KINDS:                # כרטיס 14: מד Modal — עכשיו, ושוב כשהדוח של Modal מתעדכן
            modal_meter_refresh()
            tm = threading.Timer(240, modal_meter_refresh)
            tm.daemon = True
            tm.start()
        if job.get("snap"):                    # הצילום שלה אולי כבר לא בשימוש — לנקות (לא נוגע במה שתהליך חי עדיין קורא)
            try:
                SNAP.clean(keep={CODE["boot"]}, min_age=60)
            except Exception as e:
                app_log("=== snapshot clean: %s" % e)
    threading.Thread(target=work, daemon=True).start()


def ms_cmd(*args):
    # MAKE_SHORT_JOB_STUB: לבדיקות התור בלבד — עבודה מדומה (בלי הורדה/תמלול/קידוד) לסוגים שעוברים בתור
    stub = os.environ.get("MAKE_SHORT_JOB_STUB")
    script = stub if stub and args and str(args[0]) in QUEUE_KINDS else str(HERE / "make_short.py")
    return [sys.executable, "-u", script, *map(str, args)]


def pick_cmd(*args):
    return [sys.executable, "-u", str(HERE / "make_short_pick.py"), *map(str, args)]


# ─────────────── בחירה אוטומטית ───────────────

def is_playlist(url):
    q = parse_qs(urlparse(url).query)
    return "list" in q and ("v" not in q or "/playlist" in urlparse(url).path)


def pick_start(d):
    url = MS.check_url(d.get("url"))
    kind = d.get("kind") or ("playlist" if is_playlist(url) else "lesson")
    if kind == "playlist":
        lid = parse_qs(urlparse(url).query).get("list", ["x"])[0]
        P = TOOL / ("%s_playlist-%s" % (time.strftime("%Y-%m-%d"), re.sub(r"[^\w-]", "", lid)[:40]))
        url = "https://www.youtube.com/playlist?list=" + lid
    else:
        m = re.search(r"(?:v=|youtu\.be/|shorts/|live/)([\w-]{11})", url)
        if not m:
            raise ValueError("לא מצאתי מזהה סרטון בקישור")
        P = TOOL / ("%s_auto-%s" % (time.strftime("%Y-%m-%d"), m.group(1)))
        # סריקה חוזרת של אותו שיעור (שעוד לא עבר ל"הכן") — באותה תיקייה, בלי להוריד שוב
        again = [d for d in TOOL.glob("*_auto-%s*" % m.group(1)) if (d / PICK.PICK).exists() and not (d / MS.STATE).exists()]
        if again:
            P = max(again, key=lambda d: d.stat().st_mtime)
        elif (P / MS.STATE).exists():
            P = TOOL / ("%s_auto-%s_%s" % (time.strftime("%Y-%m-%d"), m.group(1), time.strftime("%H%M")))
    if busy(P):
        raise ValueError("הסריקה הזאת כבר רצה")
    P.mkdir(parents=True, exist_ok=True)
    old = {}
    try:
        old = PICK.load(P)
    except (OSError, ValueError):
        pass
    # כרטיס 25: "מה לחפש" — בקשה חופשית לצד הקישור (נשמרת עם השיעור; סריקה חוזרת בלי בקשה חדשה שומרת את הקודמת)
    req = " ".join(str(d.get("request") if d.get("request") is not None else old.get("request", "")).split())[:600]
    st = {"kind": kind, "url": url, "dir": str(P), "rabbi": (d.get("rabbi") or "").strip(),
          **({"request": req} if req else {}),
          "series": (d.get("series") or "").strip(), "use_gemini": bool(d.get("use_gemini", True)),
          "modal_ok": bool(d.get("modal_ok")),
          "status": "scanning", "picks": old.get("picks", []), "seq": old.get("seq", 0),
          "title": old.get("title", "")}
    PICK.save(P, st)
    # 28/10: שיעור בודד — Gemini נשאל אחר כך, יחד עם שיעורים שנשלחו בסמוך (pick_tick); 0 דקות = מיד, כמו תמיד
    hold = kind == "lesson" and st["use_gemini"] and float(SET.load().get("editor_window_min", 3)) > 0 \
        and PICK.step_direct("pick")
    return start_job("pick", pick_cmd("scan", P), P, url, extra={"env": {"MAKE_SHORT_PICK_HOLD": "1"}} if hold else None)


def pick_view(P):
    st = PICK.load(P)
    st.pop("seq", None)
    for l in st.get("lessons", []):
        l.pop("card", None)                       # כרטיסי הדירוג כבדים (140 שיעורים) והדף לא מציג אותם
    wc = {}                                       # הטקסט המלא לבחירה בעכבר: מילים עם אינדקס וזמן (רק להצגה, לא נשמר)
    for p in st.get("picks", []):
        if p.get("dropped") or not p.get("pieces"):
            continue
        les = next((l for l in st["lessons"] if l["n"] == p.get("lesson")), None)
        if not les or not les.get("words"):
            continue
        if les["n"] not in wc:
            try:
                wc[les["n"]] = PICK.lesson_words(P, les)
            except (OSError, ValueError):
                wc[les["n"]] = []
        p["ctxw"] = PICK.ctx_words(wc[les["n"]], p)
    st["queue"] = [q for q in queue_view()["items"] if q["pl"] == str(P)]
    st["fidelity_q"] = PICK.FIDELITY_Q
    st["running"] = busy(P)
    st["hold"] = PICKHOLD["view"].get(str(P)) if st.get("gemini_hold") else None   # 28/10: ממתין לבקשה משותפת
    s = SET.load()
    st["modal_info"] = {"all_n": len(PICK.modal_todo(st, "all")), "all_est": PICK.est_cost(
                            [l.get("duration") for l in PICK.modal_todo(st, "all")]),
                        "missing_n": len(PICK.modal_todo(st, "missing")),
                        # 22/10: תקרה ליום — הדף שואל רק כש"היום כבר" + ההערכה עוברים אותה
                        "spent": MD.view()["spent"], "cap": float(s["modal_day_cap"]), "engine": s["asr_engine"],
                        "auto_mode": PICK.mode_from_settings(s), "auto_skips": s["auto_skips"],
                        "per_min": PICK.MODAL_USD_PER_MIN, "top_n": s["playlist_top_n"], "auto_max": s["playlist_auto_max"],
                        "pl_mode_setting": s["playlist_mode"], "user_mode": bool(st.get("mode_user"))}
    return st


def pick_update(d):
    P, _ = load_pick(d["project"])
    with LOCK:
        st = PICK.load(P)
        by = {p["id"]: p for p in st["picks"]}
        for e in d.get("picks", []):
            p = by.get(e.get("id"))
            if not p:
                continue
            for k in ("selected", "title", "description", "tags", "checked_fidelity"):
                if k in e:
                    p[k] = e[k]
            if "pieces" in e and e["pieces"] != p.get("pieces"):
                cuts = MS.parse_pieces(e["pieces"])
                les = next((l for l in st["lessons"] if l["n"] == p.get("lesson")), None)
                words = PICK.lesson_words(P, les) if les and les.get("words") else []
                if not p.get("manual"):
                    p.setdefault("orig", PICK.snapshot(p))
                PICK.apply_pieces(p, words, cuts, old_skips=p.get("skips"))    # דילוגים, הקשר, אורך ודגלים מחדש
                p["pieces"] = e["pieces"]
                p["edited_times"] = True
            if e.get("words_edit") or e.get("revert"):
                # בחירה בעכבר בטקסט המלא ("➕ הוסף לשורט" / "➖ הוצא מהשורט") או "↺ חזרה להצעה של Gemini"
                les = next((l for l in st["lessons"] if l["n"] == p.get("lesson")), None)
                if not les or not les.get("words"):
                    raise ValueError("אין תמלול מדויק לשיעור הזה")
                words, cap = PICK.lesson_words(P, les), PICK.lesson_cap(P, les)
                if e.get("revert"):
                    PICK.revert_pick(p, words, cap)
                else:
                    we = e["words_edit"]
                    PICK.edit_words(p, words, cap, we.get("op"), we.get("i0"), we.get("i1"))
            if e.get("drop_skip") is not None or e.get("add_skip"):
                les = next((l for l in st["lessons"] if l["n"] == p.get("lesson")), None)
                words = PICK.lesson_words(P, les) if les and les.get("words") else []
                if e.get("drop_skip") is not None:
                    PICK.edit_skips(p, words, "drop", e["drop_skip"])
                else:
                    PICK.edit_skips(p, words, "add", e["add_skip"])
            p["user_edited"] = True
        # 21/10: "🗑️ ויתרתי" — ההצעה עוברת לאזור "ויתרתי" של השיעור, ואפשר להחזיר
        for rid in d.get("remove", []):
            for p in st["picks"]:
                if p["id"] == rid:
                    p["dropped"], p["selected"] = True, False
        for rid in d.get("restore", []):
            for p in st["picks"]:
                if p["id"] == rid:
                    p.pop("dropped", None)
        for n, on in (d.get("tick") or {}).items():       # סימון שיעורים לשלב ב' (נשמר, כך שלא הולך ברענון)
            for l in st["lessons"]:
                if str(l["n"]) == str(n) and not l.get("stage_b"):
                    l["rank_tick"] = bool(on)
        if d.get("add_lesson"):
            st["seq"] = st.get("seq", 0) + 1
            st["picks"].append({"id": "p%d" % st["seq"], "lesson": int(d["add_lesson"]), "pieces": "", "title": "",
                                "description": "", "tags": "", "opening": "", "closing": "", "flags": ["קטע ידני"],
                                "selected": False, "user_edited": True, "manual": True,
                                "checked_fidelity": [False] * len(PICK.FIDELITY_Q)})
        PICK.save(P, st)
    return pick_view(P)


def load_pick(project):
    p = Path(project).resolve()
    if PROJECTS.resolve() not in p.parents or not (p / PICK.PICK).exists():
        raise ValueError("תיקייה לא מוכרת")
    return p, PICK.load(p)


def auto_burn_after_pick(job, srcs=("gemini",)):
    """28/10 — "אוטומטי עד הצריבה" (הגדרה מתקדמת, כבויה מראש): Gemini בחר → בלי לעצור לבדיקת ההצעות ולא לבדיקת
    הטקסט. כל הצעה שהציטוטים שלה נמצאו (✓/~) נבנית ונצרבת לטיוטה; הצעה שציטוט שלה לא נמצא (✗) — לא נבנית, ונרשמת
    לו. בלי Gemini (מפתח חסר / מכסה / בהגדרות "העתק לצ'אט") — עוצרים כאן עם התראה; אחרי שהדביק את התשובה מהצ'אט
    (srcs כולל "chat") — ממשיכים לבד, כמו אחרי Gemini. שום דבר לא נשמר לתיקייה לבד."""
    if not SET.load().get("auto_burn"):
        return
    P = Path(job.get("project") or "")
    try:
        P, st = load_pick(P)
    except (OSError, ValueError):
        return
    if st.get("auto_done") or st.get("gemini_hold"):     # ממתין לבקשה המשותפת — ימשיך כשהיא תסתיים
        return
    gem = [p for p in st.get("picks", []) if not p.get("dropped") and p.get("emph_src") in srcs]
    with LOCK:
        cur = PICK.load(P)
        if not gem:
            if cur.get("lessons") and not any(l.get("rank") for l in cur["lessons"]):
                why = (cur.get("gemini_stop") or {}).get("msg") or "Gemini לא בחר (אין מפתח פעיל / המכסה נגמרה)"
                cur["auto_note"] = ("⏸ \"אוטומטי עד הצריבה\" עצר כאן: %s. מעתיקים לצ'אט ומדביקים את התשובה — "
                                    "ומשם התוכנה ממשיכה לבד עד הטיוטות." % why.rstrip("."))
                cur["auto_pause"] = time.strftime("%H:%M")
                PICK.save(P, cur)
            return
        cur.pop("auto_pause", None)
        PICK.preselect(cur)                         # גם בפלייליסט (שם בדרך כלל הוא מסמן לבד)
        for p in cur["picks"]:
            if p.get("bad") or p.get("dropped") or p.get("emph_src") not in srcs:
                p["selected"] = False
        skipped = [p.get("title") or p["id"] for p in cur["picks"]
                   if p.get("emph_src") in srcs and not p.get("dropped") and p.get("bad")]
        cur["auto_done"] = time.strftime("%Y-%m-%d %H:%M")
        cur["auto_note"] = ("נבחר אוטומטית ונצרב בלי בדיקה" + (" · לא נבנו (הציטוט לא נמצא בתמלול): " + " · ".join(skipped)
                                                             if skipped else ""))
        PICK.save(P, cur)
    if not any(p.get("selected") for p in cur["picks"]):
        return
    app_log("=== auto burn after pick: %s" % P.name)
    pick_build({"project": str(P), "auto": True})


def pick_build(d):
    """ההצעות המסומנות → "הכן". שיעור בודד: עבודת הכנה אחת באותה תיקייה. פלייליסט: שיעור-שיעור בתור.
    auto = "אוטומטי עד הצריבה" (28/10): ההכנה מסומנת, ובסופה הטיוטה נצרבת לבד (wants_auto_finish)."""
    P, st = load_pick(d["project"])
    more = {"auto_burn": True} if d.get("auto") else {}
    sel = [p for p in st["picks"] if p.get("selected")]
    if not sel:
        raise ValueError("לא סומן אף קטע")
    for p in sel:
        if not (p.get("pieces") or "").strip():
            raise ValueError("לקטע «%s» אין זמנים" % (p.get("title") or p["id"]))
        MS.parse_pieces(p["pieces"])

    def clip(p, refine):
        pq = [{"opening": sg.get("opening", ""), "closing": sg.get("closing", "")} for sg in p.get("segs") or []]
        return {"pieces": p["pieces"], "title": p.get("title", ""), "description": p.get("description", ""),
                "tags": p.get("tags", ""), "opening": p.get("opening", ""), "closing": p.get("closing", ""),
                "piece_quotes": pq if len(pq) > 1 and len(pq) == len(MS.parse_pieces(p["pieces"])) else [],
                # 🔠 כרטיס 15: המילים שהמודל הציע להגדיל — עוברות לקליף, נחשפות רק כשהמתג דולק
                "emphasis": p.get("emphasis") or [], "emph_src": p.get("emph_src") or "gemini",
                "hook_quote": p.get("hook_quote") or "",          # 🎬 6/11: הצעת המודל להוק
                "refine": bool(refine and not p.get("edited_times") and not p.get("manual"))}
    SPECS.mkdir(parents=True, exist_ok=True)
    by_n = {l["n"]: l for l in st["lessons"]}
    if st["kind"] == "lesson":
        les = by_n[1]
        spec = SPECS / ("spec_%s_%d.json" % (time.strftime("%Y%m%d_%H%M%S"), os.getpid()))
        # שם הרב/הסדרה: מה שהוא כתב, אחרת מכותרת הסרטון (prepare מנחש שוב מהכותרת — לא מהמודל)
        spec.write_text(json.dumps({"url": les["url"], "rabbi": st.get("rabbi", ""), "series": st.get("series", ""),
                                    "project": str(P), "clips": [clip(p, False) for p in sel]},
                                   ensure_ascii=False), encoding="utf-8")
        return {"job": enqueue("prepare", ["prepare", spec], P, st.get("title", ""), url=les["url"], **more)}
    added = 0
    linked = {}
    with QLOCK:
        for n in sorted({p["lesson"] for p in sel}):
            les = by_n[n]
            if any(q.get("pl") == str(P) and q.get("n") == n and q["status"] in ("waiting", "running") for q in BUILD_Q):
                continue
            # תיקיית השיעור נקבעת כבר עכשיו ונרשמת במפרט — כך אחרי הפעלה מחדש יודעים בדיוק לאן להמשיך
            proj = MS.project_for(les["url"]) or TOOL / ("%s_auto_%d" % (time.strftime("%Y-%m-%d_%H%M%S"), n))
            if (proj / MS.STATE).exists() or str(proj) in queued_projects():
                proj = proj.with_name(proj.name + "_" + time.strftime("%H%M%S"))
            linked[n] = proj
            spec = SPECS / ("spec_%s_%d_%d.json" % (time.strftime("%Y%m%d_%H%M%S"), os.getpid(), n))
            spec.write_text(json.dumps({"url": les["url"], "rabbi": st.get("rabbi", ""), "series": st.get("series", ""),
                                        "project": str(proj) if proj else "",
                                        "clips": [clip(p, True) for p in sel if p["lesson"] == n]},
                                       ensure_ascii=False), encoding="utf-8")
            enqueue("prepare", ["prepare", spec], str(proj) if proj else "", les.get("title", ""), url=les["url"],
                    pl=str(P), pl_title=st.get("title", ""), n=n, kick=False, **more)
            added += 1
    if linked:                                  # השיעורים שנבנים הופכים לתת-לשוניות של הפלייליסט (נשמר ב-pick.json)
        link_playlist_lessons(P, linked)
    kick_queue()
    return {"queued": added}


# ─────────────── התור העמיד (21/10/2026) ───────────────
# תור אחד לכל העבודה הכבדה — הכנה (גם פלייליסט), סיום, גבולות חדשים, צבע/מצלמה, בנייה חלקה — לפי הסדר
# שהוא קובע בחלונית "📋 תור" (▲▼, גרירה, "⏫ הבא בתור"). הסדר הזה הוא מה שבאמת רץ, ונשמר לקובץ בכל שינוי.
# כל פריט: id, kind, args (הפקודה ל-make_short.py), project, title, status = waiting/running/done/failed,
# ולפלייליסט גם pl/pl_title/n/url. "job" (מספר העבודה בשרת הזה) לא נשמר — אחרי הפעלה מחדש נרשמת חדשה.
QUEUE_KINDS = ("prepare", "finish", "retime", "restyle", "rebuild", "swap", "save")
NET_KINDS = ("prepare", "retime")              # צריכות אינטרנט (הורדה / תמלול) — בלי חיבור מחכות בתור
# 21/10/2026 (כרטיס 12, באג של job 24): החלפת מוזיקה רצה מחוץ לתור, בלי שם בחלונית, והדף איבד את הסוף שלה.
# עכשיו גם היא פריט בתור — אבל "קלה": כמה שניות, בלי וידאו, ולכן מתחילה מיד, גם כשעבודה כבדה רצה.
LIGHT_KINDS = ("swap", "save")
# 4.2.0: "💾 שמור" הוא גם פריט בתור — אבל לא מחכה לעבודות כבדות של שיעורים אחרים, רק לפעולות קודמות של *אותו* שיעור
# (ואותו קליף, או שאחד מהם "כל השיעור"): כך שמירה לא מזיזה תיקיות מתחת לבנייה, ושומרת את התוצאה המוגמרת. שמירה
# שמגיעה עוברת לפני פריטים *ממתינים* של אותו שיעור (עדיפות), אבל לא לפני אחד שכבר רץ.
QLOCK = threading.RLock()
QSTATE = {"loaded": False}


def queue_save():
    """כתיבה אטומית (קובץ זמני + fsync + שינוי שם): בהפסקת חשמל נשאר הישן או החדש, אף פעם לא קובץ חצי."""
    with QLOCK:
        live = [q for q in BUILD_Q if q["status"] in ("waiting", "running")]
        old = [q for q in BUILD_Q if q["status"] in ("done", "failed")][-30:]     # היסטוריה קצרה לתצוגה
        BUILD_Q[:] = [q for q in BUILD_Q if q in live or q in old]
        data = {"version": 2, "net_only": bool(QSTATE.get("net_only")),
                "items": [{k: v for k, v in q.items() if k not in ("job", "orphan", "last_job")} for q in BUILD_Q]}
        try:
            QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp = QUEUE_FILE.with_suffix(".json.tmp")
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=1)
                fh.flush()
                os.fsync(fh.fileno())
            tmp.replace(QUEUE_FILE)
        except OSError as e:
            app_log("=== queue save failed: %s" % e)


def _job_for(q):
    """רשומת עבודה "בתור" לפריט (בלי להתחיל תהליך) — כך הלשונית והדף רואים אותו מיד."""
    if q.get("job") in JOBS:
        return q["job"]
    extra = {"url": q.get("url", ""), "qid": q["id"], "clip": q.get("clip", ""), "env": {}}
    if q["kind"] == "save":                    # השמירה ממתינה בתור במקום להיכשל כשהשיעור בעבודה
        extra["nobusy"] = True
    if q["kind"] in LIGHT_KINDS:               # לא דורסת את רשומת העבודה הכבדה ב-progress.json (ראו job_begin)
        extra["env"]["MAKE_SHORT_NO_PROGRESS"] = "1"
    if q.get("offline_ok"):                    # "▶ המשך בלי אינטרנט": לעולם לא תמלול במחשב בלי לשאול
        extra["env"]["MAKE_SHORT_ASR_NO_CPU"] = "1"
    if q.get("settings") and Path(q["settings"]).exists():   # כרטיס 14: ההגדרות כמו שהיו כשלחץ (צילום)
        extra["env"].update(MAKE_SHORT_SETTINGS=q["settings"], MAKE_SHORT_SETTINGS_SNAP=q["settings"])
    extra["env"].update(q.get("allow_env") or {})              # 22/10: אישר תמלול במחשב / מעבר לתקרת היום
    q["job"] = start_job(q["kind"], ms_cmd(*q["args"]), q.get("project") or "", q.get("title") or q.get("url", ""),
                         extra=extra, deferred=True)
    return q["job"]


def _clips_overlap(a, b):
    return not a or not b or a == b


def lane_blocker(q):
    """4.2.0: הפריט שמונע מ-q לרוץ עכשיו *באותו שיעור* (או None). שמירה: ממתינה לכל פריט קודם / רץ של אותו קליף.
    כל פריט אחר: ממתין לשמירה שרצה או שקדמה לו (אחרת הוא היה מזיז/כותב בזמן שהשמירה מזיזה תיקיות)."""
    P = q.get("project")
    if not P:
        return None
    items = list(BUILD_Q)
    try:
        idx = items.index(q)
    except ValueError:
        return None
    for i, x in enumerate(items):
        if x is q or x.get("project") != P or x["status"] not in ("waiting", "running") \
                or not _clips_overlap(x.get("clip"), q.get("clip")):
            continue
        if q["kind"] == "save":
            if x["status"] == "running" or i < idx:
                return x
        elif x["kind"] == "save" and (x["status"] == "running" or i < idx):
            return x
    return None


def enqueue(kind, args, project, title, url="", kick=True, clip="", **more):
    """עבודה כבדה → לסוף התור. מחזיר את מספר העבודה (היא "בתור" עד שמגיע תורה).
    clip = עבודה של קליף אחד (גבולות, צבע/מצלמה/מוזיקה, בנייה חלקה, סיום של קליף אחד) — הדף מציג אותה
    בתוך הכרטיס של הקליף בלבד, ושאר השיעור נשאר פתוח לעריכה."""
    with QLOCK:
        q = {"id": "q%d_%d" % (int(time.time()), next(QSEQ)), "kind": kind, "args": [str(a) for a in args],
             "project": str(project or ""), "title": title or "", "url": url, "status": "waiting",
             "added": time.strftime("%Y-%m-%d %H:%M:%S"), **({"clip": clip} if clip else {}), **more}
        if not q.get("settings"):
            q["settings"] = settings_snapshot(q["id"])
        jid = _job_for(q)                       # בודק גם שהשיעור לא כבר בעבודה (שגיאה ברורה לדף)
        at = len(BUILD_Q)
        if kind == "save":                      # עדיפות: לפני פריטים *ממתינים* של אותו שיעור, אחרי מי שכבר רץ
            at = next((i for i, x in enumerate(BUILD_Q) if x["status"] == "waiting" and x["kind"] != "save"
                       and x.get("project") == q["project"] and _clips_overlap(x.get("clip"), q.get("clip"))), at)
        BUILD_Q.insert(at, q)
        queue_save()
    if kick:
        kick_queue()
    return jid


# 22/10/2026 (כרטיס 14, בקרת סתירות): עבודה רצה עם ההגדרות שהיו ברגע שלחץ. בלי זה: שינה צבע / מוזיקה בזמן שעבודה
# חיכתה בתור או נקטעה — והמשך העבודה היה מערבב בין הישן לחדש (חצי מהקליפים בצבע אחד, חצי באחר).
JOB_SET_DIR = PROJECTS.parent / ("job_settings_test" if MS.TEST_MODE else "job_settings")


def settings_snapshot(tag):
    """צילום של ההגדרות בתוקף (אין בהן שום מפתח — אלה ב-config.env). מחזיר נתיב, או "" אם לא הצליח."""
    try:
        JOB_SET_DIR.mkdir(parents=True, exist_ok=True)
        f = JOB_SET_DIR / ("%s.json" % re.sub(r"[^\w-]", "", str(tag)))
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps({"values": SET.load(), "snapshot_of": str(SET.PATH),
                                   "at": time.strftime("%Y-%m-%d %H:%M:%S")}, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(f)
        return str(f)
    except OSError as e:
        app_log("=== settings snapshot failed: %s" % e)
        return ""


def snapshot_values(path):
    try:
        v = dict(SET.DEFAULTS)
        v.update(json.load(open(path, encoding="utf-8")).get("values") or {})
        return v
    except (OSError, ValueError, TypeError):
        return SET.load()


def clean_settings_snaps():
    """צילומים שאף פריט בתור לא משתמש בהם ושגילם מעל שבועיים (המשך אחרי הפסקה ארוכה עדיין מוצא את שלו)."""
    try:
        used = {q.get("settings") for q in BUILD_Q}
        for f in JOB_SET_DIR.glob("*.json"):
            if str(f) not in used and time.time() - f.stat().st_mtime > 14 * 86400:
                f.unlink()
    except OSError:
        pass


def _settle_from_files(q):
    """פריט שהיה "רץ" כשהשרת נסגר: מה קרה לו באמת — לפי progress.json של השיעור."""
    P = Path(q.get("project") or "")
    js = PR.job_state(P) if q.get("project") and P.is_dir() else ""
    job = (PR.load(P).get("job") or {}) if js else {}
    same = job.get("kind") == q["kind"]
    if q["kind"] in LIGHT_KINDS:                            # קלה: לא נרשמת ב-progress.json; אם נקטעה — פשוט שוב
        q["status"] = "waiting"
        q.pop("orphan", None)
        return
    net_done = "--net-only" in (job.get("argv") or []) and PR.data(P).get("net_ready")
    if js == "running" and same:
        q["status"], q["orphan"] = "running", True          # התהליך עוד חי (רק השרת נסגר) — מחכים לו
    elif js == "done" and same and (q["kind"] != "prepare" or (P / MS.STATE).exists() or net_done):
        q["status"], q["ended"], q["ended_ts"] = "done", job.get("ended", ""), time.time()
    elif js == "failed" and same:
        q["status"], q["error"], q["ended_ts"] = "failed", job.get("error", "") or "העבודה נכשלה", time.time()
    else:                                                   # נקטע באמצע / עוד לא התחיל — ממשיכים מאיפה שעצר
        q["status"] = "waiting"
        q.pop("orphan", None)
        q["resume"] = True


def queue_load():
    """בפתיחה: התור מהקובץ. עבודה שנקטעה באמצע נשארת במקומה וממשיכה מאיפה שעצרה (progress.json)."""
    with QLOCK:
        if QSTATE["loaded"]:
            return
        QSTATE["loaded"] = True
        try:
            data = json.load(open(QUEUE_FILE, encoding="utf-8"))
            items = data.get("items", [])
            QSTATE["net_only"] = bool(data.get("net_only"))
        except (OSError, ValueError):
            items = []
        for q in items:
            if not isinstance(q, dict) or q.get("status") not in ("waiting", "running", "done", "failed"):
                continue
            if not q.get("args") and q.get("spec"):         # הפורמט הראשון (פלייליסט בלבד)
                q["kind"], q["args"] = "prepare", ["prepare", q["spec"]]
            if q.get("kind") not in QUEUE_KINDS or not q.get("args"):
                continue
            if q["status"] == "running":
                _settle_from_files(q)
            BUILD_Q.append(q)
        for q in BUILD_Q:
            if q["status"] == "waiting":
                try:
                    _job_for(q)
                except ValueError:
                    pass
        waiting = [q for q in BUILD_Q if q["status"] in ("waiting", "running")]
        if waiting:
            app_log("=== %s queue restored: %d waiting" % (time.strftime("%Y-%m-%d %H:%M:%S"), len(waiting)))
            print("  ▶ ממשיך את התור מהפעם הקודמת: %d עבודות" % len(waiting), flush=True)
        queue_save()
        clean_settings_snaps()


def queue_pending():
    return any(q["status"] in ("waiting", "running") for q in BUILD_Q)


def queued_projects():
    return {q.get("project") for q in BUILD_Q if q["status"] in ("waiting", "running")}


def queue_job_ended(job):
    with QLOCK:
        q = next((q for q in BUILD_Q if q["id"] == job["qid"]), None)
        if not q or q.get("job") != job["id"]:
            return
        q.pop("job", None)
        q["last_job"] = job["id"]               # הדף מזהה כך שהעבודה שהוא שלח (גם קצרה מאוד) הסתיימה
        q["ended_ts"] = time.time()             # הדף משווה לזה: "העבודה של הקליף נגמרה" גם אחרי הפעלה מחדש
        if job["ok"]:
            q["status"], q["ended"] = "done", time.strftime("%Y-%m-%d %H:%M:%S")
        elif q["kind"] in NET_KINDS and not q.get("offline_ok") and not MS.net_ok():   # נפל כי האינטרנט נפל — יחכה ויחזור לבד
            q["status"], q["resume"] = "waiting", True
            _job_for(q)
        else:
            q["status"], q["error"] = "failed", job.get("error", "") or "העבודה נכשלה"
        queue_save()
        auto = wants_auto_finish(q, job)

    def after():
        if auto:
            try:
                pj = job["project"] or q.get("project")
                # העורך החכם עוד לא סיים (ממתין לשיעורים נוספים / נשלח) — הצריבה תבוא אחריו (editor_ended)
                if not editor_after(pj, q.get("settings") or "", bool(q.get("auto_burn"))):
                    auto_finish(pj, q.get("settings") or "", bool(q.get("auto_burn")))
            except Exception as e:               # ההכנה עצמה הצליחה — השיעור נשאר "לתיקון", כמו בלי ההגדרה
                app_log("=== auto finish (skip text check) failed: %s" % e)
        kick_queue()
    threading.Thread(target=after, daemon=True).start()


def wants_auto_finish(q, job):
    """"לדלג על תיקון הטקסט" — רק אחרי הכנה מלאה שהצליחה, לפי ההגדרות שההכנה התחילה איתן. הכנה של "בלי אינטרנט"
    (רק הורדה ותמלול) לא צורבת: אין עוד קליפים. הטיוטה תבוא בסוף "▶ המשך בלי אינטרנט" (גם הוא prepare)."""
    # 28/10: גם כשהדליק את ההגדרה אחרי שההכנה כבר התחילה (הצילום נלקח בלחיצה על "הכן") — הוא רואה אותה דולקת
    return bool(job.get("ok") and q["kind"] == "prepare" and not q.get("net_only_run")
                and "--net-only" not in (job.get("cmd") or [])
                and (snapshot_values(q.get("settings") or "").get("skip_text_check") or SET.load()["skip_text_check"]
                     or q.get("auto_burn")))


def auto_finish(project, snap, auto_pick=False):
    """22/10/2026 (כרטיס 14) — "לדלג על תיקון הטקסט לפני הצריבה": ההכנה נגמרה → הטיוטה נבנית מיד מהטקסט של
    התוכנה (בכל [א / ב] — האוזן הראשונה, כמו תמיד כשלא הוכרע), וכל קליף מסומן "⚠ טקסט לא נבדק" עד שיתקן או יאשר
    אותו ליד הסרטון הצרוב. הסוגריים נשארים בקובץ העריכה — כך הוא רואה אחר כך בדיוק איפה היה ספק.
    קליף בלי כותרת / תיאור (זמנים שהקליד בעצמו) — לא נבנה; נשאר לתיקון עם הסבר."""
    p, st = load_state(project)
    live = [c for c in st["clips"] if not c.get("dropped")]
    # 28/10 (באג שמצא): כותרת בלי שם סדרה ("נושא | הרב X") עצרה כאן את כל הטיוטה — "ההגדרה דולקת ובכל זאת
    # עצר לתיקון". שם רב/סדרה נחוצים רק לשמירה לתיקייה; הטיוטה נבנית, והשמירה מבקשת אותם.
    names, skipped = [], []
    for c in live:
        e = MS.read_edit_raw(p / c["edit"])
        if (e.get("title") or "").strip() and (e.get("desc") or "").strip():
            names.append(c["name"])
        else:
            skipped.append(c["name"])
    note = {"at": time.strftime("%H:%M"), "skipped": skipped,
            "why": "חסרים כותרת או תיאור — הקליף נשאר לתיקון" if skipped else ""}
    if not (st.get("rabbi") or "").strip() or not (st.get("series") or "").strip():
        note["names_missing"] = True
    with SAVE_LOCK, LOCK:
        f = p / MS.STATE
        cur = json.load(open(f, encoding="utf-8"))
        cur["text_unchecked"] = sorted(set(cur.get("text_unchecked") or []) | set(names))
        cur["auto_finish"] = note
        if auto_pick:                                # "אוטומטי עד הצריבה": גם הבחירה עצמה לא נבדקה — סימון לכל קליף
            cur["auto_picked"] = sorted(set(cur.get("auto_picked") or []) | set(names))
        tmp = f.with_suffix(".json.tmp")
        json.dump(cur, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        tmp.replace(f)
    if not names:
        return None
    app_log("=== auto finish after prepare (skip text check): %s %s" % (p.name, ",".join(names)))
    return finish_clips(p, st, names, settings=snap or "", auto=True)["job"]


# ─────────────── העורך החכם (28/10/2026) ───────────────
# ההכנה נגמרה → השיעור "ממתין לעורך" (editor.status = pending ב-make_short.json). הבקשה ל-Gemini לא נשלחת מיד:
# בקשתו — לחסוך בקשות. אם יש עוד שיעורים בדרך לאותה נקודה (בתור להכנה / בהורדה / בתמלול, או נבחרים עכשיו
# ב"אוטומטי עד הצריבה") — מחכים להם, וכולם יוצאים בבקשה אחת (עד תקרה, editor_cap_min). אם אין אף אחד —
# מחכים editor_window_min דקות לשיעור שאולי ייפתח (0 = לא מחכים). שיעור שחיכינו לו ונכשל / הוצא מהתור — כבר
# לא "בדרך", והשליחה יוצאת מיד. "שלח עכשיו" בדף — מיד. העבודה עצמה: make_short_editor.py run (לא בתור הכבד).
EDITOR = {"force": set(), "view": {}, "cache": {}, "inflight": set(), "boot": True, "manual": set()}
ED_LOCK = threading.RLock()


def _ed_state(d):
    """(status, since, after) מתוך make_short.json — עם מטמון לפי זמן שינוי (נקרא כל כמה שניות)."""
    f = d / MS.STATE
    try:
        m = f.stat().st_mtime
    except OSError:
        return None
    hit = EDITOR["cache"].get(str(d))
    if hit and hit[0] == m:
        return hit[1]
    try:
        e = json.load(open(f, encoding="utf-8")).get("editor") or {}
    except (OSError, ValueError):
        return None
    v = (e.get("status"), float(e.get("since") or m), e.get("after"))
    EDITOR["cache"][str(d)] = (m, v)
    return v


def _ed_write(p, fn):
    with LOCK:
        f = Path(p) / MS.STATE
        st = json.load(open(f, encoding="utf-8"))
        e = dict(st.get("editor") or {})
        fn(e)
        st["editor"] = e
        tmp = f.with_suffix(".json.tmp")
        json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        tmp.replace(f)
        return e


def editor_pending():
    out = []
    for d in (TOOL.glob("*") if TOOL.exists() else []):
        v = _ed_state(d) if d.is_dir() else None
        if v and v[0] == "pending" and str(d) not in EDITOR["inflight"]:
            out.append((str(d), v[1]))
    return out


def editor_on_way(pending):
    """שיעורים שעוד לא הגיעו לנקודת העורך אבל בדרך אליה: הכנה בתור / רצה (לא "רק רשת"), ובחירה שרצה עכשיו
    כש"אוטומטי עד הצריבה" דולק (ממנה תצא הכנה לבד)."""
    pend = {p for p, _ in pending}
    way = []
    with QLOCK:
        for q in BUILD_Q:
            if q["kind"] == "prepare" and q["status"] in ("waiting", "running") and q.get("project") not in pend \
                    and not q.get("net_only_run"):
                way.append((q.get("project") or "", q.get("title") or q.get("url") or "שיעור"))
    if SET.load().get("auto_burn"):
        for j in list(JOBS.values()):
            if j["running"] and j["kind"] == "pick" and j["project"] not in pend:
                way.append((j["project"], j.get("title") or "שיעור"))
    return way


def editor_decide(pending, way, now, s, force=False):
    """("send", [projects]) / ("wait", way, עד מתי) / ("idle",). פונקציה טהורה — נבדקת ב-selftest."""
    if not pending:
        return ("idle",)
    projects = [p for p, _ in sorted(pending, key=lambda x: x[1])]
    t0 = min(t for _, t in pending)
    win, cap = float(s.get("editor_window_min", 3)) * 60, float(s.get("editor_cap_min", 20)) * 60
    if force or win <= 0:
        return ("send", projects)
    if way:
        return ("send", projects) if now - t0 >= cap else ("wait", way, t0 + cap)
    return ("send", projects) if now - t0 >= win else ("wait", [], t0 + win)


def _short_title(t):
    t = re.split(r"\s+\|\s+", t or "")[0].strip()
    return t[:40] + ("…" if len(t) > 40 else "")


def editor_gate(pending):
    """4.1.1: מי מהשיעורים הממתינים מדלגים על העורך כי Gemini ידוע כלא-שמיש — נרשמים ("chat" + skipped) וממשיכים
    לזרימה הרגילה; מחזיר את מי שנשאר. שיעור ב-EDITOR["manual"] (נלחץ "🔁 נסה עם Gemini" / "שלח עכשיו") — לא נבדק."""
    skipped = []
    for p, _ in list(pending):
        if p in EDITOR["manual"]:
            continue
        try:
            why = PICK.gemini_unusable(p)
        except Exception as e:
            app_log("=== gemini_unusable: %s" % e)
            why = None
        if why:
            # chat_mode = הוא בחר בהגדרות "תמיד העתק לצ'אט": שם כן עוצרים לפני הצריבה (כמו קודם)
            _ed_write(p, lambda e, why=why: e.update(status="chat", kind=why[0], msg=why[1],
                                                     skipped=why[0] != "chat_mode",
                                                     at=time.strftime("%H:%M"), auto_stop=None))
            skipped.append((p, why[0]))
    for p, k in skipped:
        try:
            editor_continue(p, "" if k == "chat_mode" else "skip")   # "אוטומטי עד הצריבה" ממשיך — לא מחכה לעורך
        except Exception as e:
            app_log("=== editor skip continue %s: %s" % (p, e))
    gone = {s[0] for s in skipped}
    return [x for x in pending if x[0] not in gone]


def editor_tick():
    with ED_LOCK:
        if EDITOR["boot"]:
            # הפעלה מחדש באמצע שליחה: התהליך נעלם יחד עם השרת — חוזרים ל"ממתין" (נשלח שוב)
            EDITOR["boot"] = False
            for d in (TOOL.glob("*") if TOOL.exists() else []):
                v = _ed_state(d) if d.is_dir() else None
                if v and v[0] == "sending":
                    _ed_write(d, lambda e: e.update(status="pending"))
        if not SET.load().get("smart_editor", True):
            EDITOR["view"] = {}
            return
        pending = editor_pending()
        if not pending:
            EDITOR["view"] = {}
            EDITOR["force"].clear()
            EDITOR["manual"].clear()
            return
        # 4.1.1: Gemini ידוע כלא-שמיש (חסום / מכסה / עומס או אין-תשובה לאחרונה, גם משלב הבחירה) — העורך לא מופעל
        # ולא מתחילה ההמתנה של 3 הדקות: מדלגים בשקט לזרימה הרגילה (אוזן ראשונה / [א / ב]) עם שורה אחת רגועה.
        # כפתור "🔁 נסה עם Gemini" (EDITOR["manual"]) עוקף את זה ושולח.
        pending = editor_gate(pending)
        if not pending:
            EDITOR["view"] = {}
            return
        force =bool(EDITOR["force"] & {p for p, _ in pending})
        g = PICK.gemini_status()
        mstat = g["models"].get(g["model"]) or {}
        usable = g["has_key"] and not g["key_blocked"] and not mstat.get("blocked_until") \
            and not g.get("margin_stop") and PICK.step_direct("editor")     # 28/10: צ'אט בהגדרות / עצירה לפני הגבול
        if not NET["ok"] and usable:
            EDITOR["view"] = {p: {"msg": "ממתין לחיבור לאינטרנט כדי לשלוח לעורך", "wait": True} for p, _ in pending}
            return
        way = editor_on_way(pending) if usable else []
        dec = editor_decide(pending, way, time.time(), SET.load(), force=force or not usable)
        if dec[0] == "wait":
            names = [_short_title(t) for _, t in dec[1]]
            msg = ("ממתין ל%s כדי לשלוח יחד" % ("שיעור «%s»" % names[0] if len(names) == 1 else
                                                "%d שיעורים (%s)" % (len(names), ", ".join("«%s»" % n for n in names[:3])))
                   if names else "ממתין כמה דקות — אם ייפתח עוד שיעור, יישלחו יחד בבקשה אחת")
            EDITOR["view"] = {p: {"msg": msg, "until": dec[2], "with": names, "wait": True,
                                  "n": len(pending)} for p, _ in pending}
            return
        if dec[0] != "send":
            return
        projects = dec[1]
        EDITOR["force"] -= set(projects)
        EDITOR["manual"] -= set(projects)
        EDITOR["inflight"] |= set(projects)
        EDITOR["view"] = {p: {"msg": "נשלח לעורך החכם%s…" % (" יחד עם עוד %d" % (len(projects) - 1)
                                                               if len(projects) > 1 else ""), "sending": True}
                          for p in projects}
    try:
        start_job("editor", [sys.executable, "-u", str(HERE / "make_short_editor.py"), "run", *projects],
                  projects[0], "🧠 העורך החכם — %d שיעורים" % len(projects) if len(projects) > 1 else "🧠 העורך החכם",
                  extra={"projects": projects, "nobusy": True})
    except ValueError as e:
        EDITOR["inflight"] -= set(projects)
        app_log("=== editor start: %s" % e)


# אותו רעיון לבחירת קטעים (28/10): שיעור בודד שנסרק — ההצעות של Gemini לא נשאלות מיד (gemini_hold ב-pick.json),
# אלא יחד עם שיעורים נוספים שנשלחו בסמוך (סריקה שרצה עכשיו = "בדרך"). פלייליסט — כמו תמיד (כבר כמה שיעורים בבקשה).
PICKHOLD = {"force": set(), "view": {}, "inflight": set()}


def pick_holds():
    out = []
    for d in (TOOL.glob("*") if TOOL.exists() else []):
        f = d / PICK.PICK
        if d.is_dir() and f.exists() and not (d / MS.STATE).exists() and str(d) not in PICKHOLD["inflight"]:
            try:
                h = json.load(open(f, encoding="utf-8")).get("gemini_hold")
            except (OSError, ValueError):
                continue
            if h and not busy(d):
                out.append((str(d), float(h)))
    return out


def pick_tick():
    pend = pick_holds()
    if not pend:
        PICKHOLD["view"] = {}
        PICKHOLD["force"].clear()
        return
    ps = {p for p, _ in pend}
    way = [(j["project"], j.get("title") or "שיעור") for j in list(JOBS.values())
           if j["running"] and j["kind"] == "pick" and j["project"] not in ps and not j.get("projects")]
    if not NET["ok"]:
        PICKHOLD["view"] = {p: {"msg": "ממתין לחיבור לאינטרנט כדי לשאול את Gemini"} for p in ps}
        return
    dec = editor_decide(pend, way, time.time(), SET.load(), force=bool(PICKHOLD["force"] & ps))
    if dec[0] == "wait":
        names = [_short_title(t) for _, t in dec[1]]
        msg = ("ממתין ל%s כדי לשאול את Gemini יחד" % ("שיעור «%s»" % names[0] if len(names) == 1 else "%d שיעורים" % len(names))
               if names else "ממתין כמה דקות — אם ייפתח עוד שיעור, Gemini יבחר לשניהם בבקשה אחת")
        PICKHOLD["view"] = {p: {"msg": msg, "until": dec[2]} for p in ps}
        return
    if dec[0] != "send":
        return
    projects = dec[1]
    PICKHOLD["force"] -= set(projects)
    PICKHOLD["inflight"] |= set(projects)
    PICKHOLD["view"] = {p: {"msg": "שואל את Gemini…"} for p in projects}
    try:
        start_job("pick", pick_cmd("together", *projects), projects[0], "🔍 בחירת קטעים — %d שיעורים" % len(projects),
                  extra={"projects": projects, "nobusy": True})
    except ValueError as e:
        app_log("=== pick together start: %s" % e)
    finally:
        PICKHOLD["inflight"] -= set(projects)


def editor_watch():
    while True:
        try:
            editor_tick()
        except Exception as e:
            app_log("=== editor watch: %s" % e)
        try:
            pick_tick()
        except Exception as e:
            app_log("=== pick hold watch: %s" % e)
        time.sleep(4)


def editor_after(p, snap, auto_burn):
    """ההכנה נגמרה והוא ביקש טיוטה אוטומטית: אם העורך עוד לא סיים — נרשם, ו-editor_ended צורב אחריו.
    מחזיר True כשנרשם (לא לצרוב עכשיו)."""
    with ED_LOCK:
        v = _ed_state(Path(p))
        if not v or v[0] not in ("pending", "sending"):
            return False
        _ed_write(p, lambda e: e.update(after={"settings": snap or "", "auto_burn": bool(auto_burn)}))
        return True


def editor_continue(p, why=""):
    """אחרי שהעורך סיים (או דילגו עליו): הטיוטה האוטומטית שחיכתה לו. "אוטומטי עד הצריבה" בלי עורך — לא צורבים
    לבד (בקשתו: בלי Gemini עוצרים עם הודעה ברורה); "לדלג על תיקון הטקסט" — צורבים, עם הודעה שהעורך לא רץ."""
    with ED_LOCK:
        e = _ed_write(p, lambda e: None)
        after = e.get("after")
        if not after:
            return
        if e.get("status") == "chat" and after.get("auto_burn") and why != "skip" and not e.get("skipped"):
            _ed_write(p, lambda e: e.update(auto_stop="העורך החכם לא זמין (%s) — עצרתי לפני הצריבה. אפשר: "
                                            "\"העתק לצ'אט\" והדבקת התשובה, או \"צרוב בלי העורך\"" %
                                            (e.get("msg") or "Gemini").replace("העורך החכם לא נשלח: ", "")))
            return
        _ed_write(p, lambda e: (e.pop("after", None), e.pop("auto_stop", None)))
    try:
        auto_finish(p, after.get("settings") or "", bool(after.get("auto_burn")))
    except Exception as ex:
        app_log("=== auto finish after editor: %s" % ex)


def editor_ended(job):
    for p in job.get("projects") or [job["project"]]:
        EDITOR["inflight"].discard(p)
        try:
            v = _ed_state(Path(p))
            if v and v[0] in ("pending", "sending") and job.get("stopped"):   # 4.1.1: ⛔ עצר בעצמו — "בלי העורך"
                _ed_write(p, lambda e: e.update(status="skipped", at=time.strftime("%H:%M"), skipped=False,
                                                msg="עצרת את העורך — הטקסט נשאר כמו שהוא, עם כל מה שתיקנת"))
                editor_continue(p, "skip")
                continue
            if v and v[0] in ("pending", "sending"):          # התהליך נפל בלי לרשום תוצאה
                _ed_write(p, lambda e: e.update(status="failed", msg="העורך נעצר באמצע (%s) — נשאר הטקסט של "
                                                "שתי האוזניים" % (job.get("error") or "שגיאה")[:120]))
            editor_continue(p)
        except Exception as e:
            app_log("=== editor ended %s: %s" % (p, e))


def editor_skip(p, why="skip"):
    """"דלג על העורך" / "צרוב בלי העורך" / סיום ידני לפני שהעורך יצא."""
    with ED_LOCK:
        v = _ed_state(Path(p))
        if v and v[0] == "sending":
            raise ValueError("העורך כבר עובד על השיעור הזה — עוד דקה-שתיים")
        _ed_write(p, lambda e: e.update(status="skipped", msg="דילגת על העורך" if why == "skip" else
                                        "סיימת לפני שהעורך רץ", at=time.strftime("%H:%M")))
    editor_continue(p, "skip")


def editor_stop(p):
    """4.1.1 "⛔ עצור את העורך": מבטל את הבקשה שבדרך (התהליך נעצר), הטקסט שלו נשאר, והמצב — "בלי העורך".
    אם הבקשה משותפת לכמה שיעורים — היא נעצרת לכולם (בקשה אחת)."""
    P = str(Path(p).resolve())
    with ED_LOCK:
        v = _ed_state(Path(p))
        if not v or v[0] != "sending":
            raise ValueError("העורך לא עובד עכשיו")
        jobs = [j for j in JOBS.values() if j["running"] and j["kind"] == "editor"
                and P in {str(Path(x).resolve()) for x in (j.get("projects") or [j["project"]])}]
        if not jobs:                         # נשאר "נשלח" בלי תהליך (נפל) — פשוט סוגרים
            _ed_write(p, lambda e: e.update(status="skipped", at=time.strftime("%H:%M"), skipped=False,
                                            msg="עצרת את העורך — הטקסט נשאר כמו שהוא, עם כל מה שתיקנת"))
            EDITOR["inflight"].discard(str(p))
            editor_continue(p, "skip")
            return
        for j in jobs:
            j["stopped"] = True
            if j.get("pid"):
                try:
                    os.kill(int(j["pid"]), signal.SIGTERM)
                except OSError:
                    pass


def editor_view(p):
    try:
        e = json.load(open(Path(p) / MS.STATE, encoding="utf-8")).get("editor") or {}
    except (OSError, ValueError):
        return None
    if not e:
        return None
    out = {k: e.get(k) for k in ("status", "msg", "at", "src", "auto_stop", "kind", "failed", "skipped")}
    out["auto"] = bool(e.get("after"))
    out.update(EDITOR["view"].get(str(p)) or {})
    return out


def kick_queue():
    """מפעיל את הפריט הבא בתור כשאין אחד שרץ. נקרא כל כמה שניות (queue_watch) — גם בלי דף פתוח."""
    if RESTARTING["on"]:                         # השרת עומד להתחדש על קוד חדש — לא מתחילים עבודה ברגע האחרון
        return
    light = []
    with QLOCK:
        # קלות (החלפת מוזיקה) — מיד, לא מחכות לכבדה ולא עוצרות אותה; רק אחת בכל פעם לכל קליף
        for q in BUILD_Q:
            if q["status"] == "waiting" and q["kind"] in LIGHT_KINDS:
                if any(x is not q and x["status"] == "running" and x.get("project") == q.get("project")
                       and x.get("clip") == q.get("clip") for x in BUILD_Q):
                    continue
                if lane_blocker(q):             # 4.2.0: אותו שיעור — לפי סדר ההגעה (שמירה מול בנייה)
                    continue
                try:
                    jid = _job_for(q)
                except ValueError:
                    continue
                q.update(status="running", started=time.strftime("%Y-%m-%d %H:%M:%S"))
                q.pop("error", None)
                light.append(jid)
        if light:
            queue_save()
    for jid in light:
        launch(jid)
    with QLOCK:
        for q in BUILD_Q:
            if q["status"] != "running" or q["kind"] in LIGHT_KINDS:
                continue
            if q.get("job"):
                return                           # רצה בשרת הזה (או שזה עתה נגמרה — queue_job_ended ירשום)
            _settle_from_files(q)                # תהליך שנשאר מהשרת הקודם — מחכים שייגמר
            if q["status"] == "running":
                return
            queue_save()
        # הראשון שממתין ויכול לרוץ עכשיו (בלי אינטרנט — מדלגים על הורדה/תמלול, סיום יכול לרוץ)
        ok = [q for q in BUILD_Q if q["status"] == "waiting" and q["kind"] not in LIGHT_KINDS
              and (NET["ok"] or q["kind"] not in NET_KINDS or q.get("offline_ok")) and not lane_blocker(q)]
        # "⏸ הכן לעבודה בלי אינטרנט" (כרטיס 12): קודם כל שלבי הרשת של כל השיעורים שבתור (הורדה + תמלול);
        # החיתוך, מעקב הפנים, הסיום — מחכים עד שאין יותר עבודת רשת (או ל"▶ המשך בלי אינטרנט")
        net_first = QSTATE.get("net_only") and NET["ok"]
        if net_first:
            nets = [q for q in ok if q["kind"] == "prepare" and not q.get("offline_ok")]
            ok = nets or [q for q in ok if q["kind"] != "prepare" or q.get("offline_ok")]
        nxt = ok[0] if ok else None
        if not nxt:
            return
        try:
            jid = _job_for(nxt)
        except ValueError:                       # השיעור הזה כבר בעבודה מחוץ לתור — ננסה שוב אחר כך
            return
        args = list(nxt["args"])
        if net_first and nxt["kind"] == "prepare" and not nxt.get("offline_ok") and "--net-only" not in args:
            args.append("--net-only")            # רק שלבי הרשת בריצה הזאת; בלי המצב — אותו פריט רץ רגיל
            JOBS[jid]["cmd"] = [str(c) for c in ms_cmd(*args)]
            JOBS[jid].setdefault("env", {})["MAKE_SHORT_ASR_NO_CPU"] = "1"
            nxt["net_only_run"] = True
        nxt.update(status="running", started=time.strftime("%Y-%m-%d %H:%M:%S"))
        nxt.pop("error", None)
        queue_save()
    launch(jid)


def queue_watch():
    while True:
        try:
            kick_queue()
        except Exception as e:                   # התור לעולם לא מת בגלל תקלה אחת
            app_log("=== queue watch: %s" % e)
        time.sleep(4)


def job_progress(plan, steps, now=None):
    """0..1 — כמה מהעבודה כבר נעשה, לפי השלבים והערכות הזמן שלהם (כמו במסך "בעבודה")."""
    return job_eta(plan, steps, now)[0]


def job_eta(plan, steps, now=None):
    """(חלק שנעשה 0..1, שם השלב הנוכחי, שניות שנשארו בערך) — אותו חישוב כמו במסך "בעבודה"."""
    now = now or time.time()
    tot = done = left = 0.0
    cur = ""
    for k, lab, est in plan or []:
        est = float(est or 1)
        s = (steps or {}).get(k) or {}
        tot += est
        if s.get("state") in ("done", "skip", "fail"):
            done += est
        elif s.get("state") == "run":
            el = max(0.0, now - float(s.get("at") or now))
            done += min(est * 0.9, el)
            left += max(est * 0.15, est - el)
            cur = cur or lab
        else:
            left += est
    return (round(done / tot, 3) if tot else None), cur, (round(left) if tot else None)


_CLIP_T = {}


def clip_label(project, clip):
    """"קליף 2 — הכותרת שלו" לפי קובץ התיקון של השיעור (בלי להפיל את התור אם משהו חסר)."""
    try:
        P = Path(project)
        st = json.load(open(P / MS.STATE, encoding="utf-8"))
        c = next(c for c in st["clips"] if c["name"] == clip)
        f = P / c["edit"]
        key = (str(f), f.stat().st_mtime)
        if key not in _CLIP_T:
            _CLIP_T[key] = (MS.read_edit_raw(f).get("title") or "").strip()
        t = _CLIP_T[key]
    except Exception:
        t = ""
    num = re.sub(r"\D", "", str(clip))
    return ("קליף %s" % num if num else str(clip)) + (" «%s»" % t if t else "")


def queue_what(q):
    """מה העבודה עושה, במילים: הכנה / סיום / שינוי צבע / החלפת מוזיקה / הזזת התחלה… וגם איזה קליף."""
    a = [str(x) for x in q.get("args") or []]
    k = q["kind"]
    clip = q.get("clip") or (a[2] if len(a) > 2 and k in ("retime", "restyle", "rebuild", "swap") else "")
    if k == "finish" and clip:
        return "סיום הקליף הזה", clip_label(q.get("project", ""), clip)
    if k == "save":
        return "שמירה לתיקייה", (clip_label(q.get("project", ""), clip) if clip and q.get("project") else "")
    if k == "swap":
        lab = " + ".join(w for f, w in (("--music=", "החלפת מוזיקה"), ("--db=", "עוצמת המוזיקה")) if any(str(x).startswith(f) for x in a))
        return lab or "החלפת מוזיקה", (clip_label(q.get("project", ""), clip) if clip and q.get("project") else "")
    if k == "prepare" and len(a) > 1:                       # כמה קליפים ובאילו שמות — מתוך ה-spec של ההכנה
        try:
            cl = json.load(open(a[1], encoding="utf-8")).get("clips") or []
            names = [c.get("title") for c in cl if c.get("title")]
            lab = "המשך בלי אינטרנט" if q.get("offline_ok") else \
                ("הכנה — רק הורדה ותמלול" if q.get("net_only_run") or (QSTATE.get("net_only") and q["status"] == "waiting") else "הכנה")
            return lab, ("%d קליפים" % len(cl) if len(cl) != 1 else "קליף אחד") + (": " + " · ".join("«%s»" % n for n in names[:3]) if names else "")
        except (OSError, ValueError):
            pass
    if k == "restyle":
        what = " + ".join(w for f, w in (("--color=", "שינוי צבע"), ("--camera=", "שינוי מצלמה"), ("--music=", "החלפת מוזיקה"),
                                         ("--subs", "פריסת שורות"), ("--db=", "עוצמת המוזיקה"))
                          if any(x.startswith(f) for x in a)) or "שינוי הגדרות"
    else:
        what = {"prepare": "הכנה", "finish": "סיום", "retime": "הזזת התחלה/סוף",
                "rebuild": "מצלמה " + MS.CAMERAS.get(a[3] if len(a) > 3 else "smooth", "חלקה")}.get(k, k)
    return what, (clip_label(q.get("project", ""), clip) if clip and q.get("project") else "")


def queue_view():
    # בלי QLOCK: kick_queue לוקח QLOCK ואז LOCK (start_job) — כאן מספיק עותק של הרשימה
    out, pos = [], 0
    for q in list(BUILD_Q):
        j = JOBS.get(q.get("job") or "")
        v = {k: q.get(k, "") for k in ("id", "kind", "pl", "pl_title", "n", "title", "url", "project", "status",
                                        "error", "added", "ended")}
        v["what"], v["clip"] = queue_what(q)
        v["cn"] = q.get("clip", "")                 # שם הקליף עצמו (clip2) — הכרטיס בדף מוצא כך את העבודה שלו
        v["ended_ts"] = q.get("ended_ts", 0)
        v["job"] = q.get("job", "")
        v["last_job"] = q.get("last_job", "")
        if j and j.get("title") and j["title"] != q.get("url"):
            v["title"] = j["title"]
        if q["status"] == "waiting":
            pos += 1
            v["pos"], v["state"] = pos, "queued"
            lb = lane_blocker(q) if q["kind"] in QUEUE_KINDS else None
            if lb:                                  # 4.2.0: "ממתין בתור (אחרי: …)"
                w, cl = queue_what(lb)
                v["after"] = (cl + " · " if cl else "") + w
            v["net_wait"] = q["kind"] in NET_KINDS and not NET["ok"]
        elif q["status"] == "running":
            v["state"] = "building" if j and j["stage"] == "building" else "working"
            v["paused"] = bool(j and j.get("paused"))      # 4.2.0: "⏸ עצרה לרגע בשביל התצוגה"
            pr = {} if j else PR.load(q["project"])
            v["progress"], v["step"], v["left"] = job_eta(j["plan"], j["steps"]) if j else \
                job_eta(pr.get("plan"), pr.get("steps"))
        else:
            v["state"] = q["status"]
        out.append(v)
    return {"items": out, "net": NET["ok"], "waiting": pos, "net_only": bool(QSTATE.get("net_only")),
            "cleans": clean_jobs_view()}


def clean_jobs_view():
    """31/10 (כרטיס 23): "🧹 נקה" רץ ברקע — חלונית התור מציגה אותו (רץ / נגמר / נכשל) גם כשחלון הניקוי סגור.
    נגמר בהצלחה — שעה ברשימה; נכשל — עד שמסירים אותו (✕ בדף)."""
    out = []
    for j in list(JOBS.values()):
        if j["kind"] != "clean" or j.get("dismissed"):
            continue
        if not j["running"] and j["ok"] and time.time() - j.get("ended_ts", 0) > 3600:
            continue
        pl, st = j.get("plan") or [], j.get("steps") or {}
        dn = sum(1 for p in pl if (st.get(p[0]) or {}).get("state") == "done")
        run = next((p[1] for p in pl if (st.get(p[0]) or {}).get("state") == "run"), "")
        out.append({"job": j["id"], "title": j.get("title", ""), "running": j["running"], "ok": j["ok"],
                    "error": j.get("error", "") if j["ok"] is False else "", "done": dn, "total": len(pl),
                    "step": run or next((l.strip() for l in reversed(j.get("log") or [])
                                         if l.strip() and not re.match(r"[A-Z_]+=", l.strip())), "")[:90],
                    "ended_ts": j.get("ended_ts", 0), "t0": j.get("t0", 0),
                    "msg": next((l for l in reversed(j.get("log") or []) if l.startswith("✅")), "")})
    return out


def offline_ready_projects():
    """שיעורים שעברו "הכן לעבודה בלי אינטרנט" ומחכים ל"▶ המשך בלי אינטרנט"."""
    return [d for d in (TOOL.glob("*") if TOOL.exists() else [])
            if d.is_dir() and not (d / MS.STATE).exists() and PR.data(d).get("net_ready")
            and str(d) not in queued_projects() and not busy(d)]


def offline_continue(project=None):
    """▶ המשך בלי אינטרנט: חיתוך, מעקב פנים והטקסט לתיקון — מהתמלול שכבר נעשה. לתור (רץ גם בלי חיבור)."""
    todo = [Path(project).resolve()] if project else offline_ready_projects()
    n = 0
    for P in todo:
        if PROJECTS.resolve() not in P.parents or not PR.data(P).get("net_ready"):
            raise ValueError("השיעור הזה לא הוכן לעבודה בלי אינטרנט")
        spec = P / "make_short_spec.json"
        enqueue("prepare", ["prepare", spec, "--local"], P, file_state(P)[1], offline_ok=True, kick=False)
        n += 1
    kick_queue()
    return n


CLIP_EST = {"swap": 12, "restyle": 90, "rebuild": 150, "retime": 160, "finish": 70}


def clip_jobs(P):
    """לכל קליף בשיעור — העבודה האחרונה שלו (בתור / רצה / נגמרה / נכשלה), לפי התור השמור.
    הדף מצייר מזה את פס ההתקדמות בתוך הכרטיס, ו"נגמרה" נקבע לפי הקובץ — לא לפי טיימר בדף שמאבד את
    הסוף כשהשרת מתחדש (באג job 24, 21/10: ההחלפה הסתיימה והכרטיס נשאר "מתעדכן…")."""
    out, act = {}, {}
    for q in queue_view()["items"]:
        if q["project"] != str(P) or not q.get("cn"):
            continue
        j = JOBS.get(q.get("job") or "")
        st = q["state"] if q["status"] == "running" else ("queued" if q["status"] == "waiting" else q["status"])
        e = {"kind": q["kind"], "what": q["what"], "state": st, "qid": q["id"], "job": q.get("job") or q.get("last_job", ""),
             "pos": q.get("pos"), "progress": q.get("progress"), "step": q.get("step", ""), "left": q.get("left"),
             "error": q.get("error", ""), "ended_ts": q.get("ended_ts", 0), "paused": bool(q.get("paused")),
             "after": q.get("after", "")}
        if q["status"] == "running" and j and e["progress"] is None and j.get("launched"):
            est = CLIP_EST.get(q["kind"], 60)        # עבודה בלי רשימת שלבים — לפי הזמן שעבר
            el = time.time() - j.get("t0", time.time())
            e["progress"], e["left"] = round(min(0.95, el / est), 3), max(3, round(est - el))
        if q["status"] == "running" and j and j.get("log"):
            e["step"] = e["step"] or next((l.strip() for l in reversed(j["log"]) if l.strip()), "")[:90]
        e["active"] = st in ("queued", "working", "building")
        e["_r"] = (2 if st in ("working", "building") else 1 if st == "queued" else 0, -(e["pos"] or 0), e["ended_ts"])
        act[q["cn"]] = act.get(q["cn"], 0) + e["active"]
        if q["cn"] not in out or e["_r"] > out[q["cn"]]["_r"]:    # רצה > בתור (הראשונה) > זו שנגמרה אחרונה
            out[q["cn"]] = e
    for cn, e in out.items():
        e.pop("_r", None)
        e["more"] = max(0, act.get(cn, 0) - 1)         # עוד שינויים שמחכים לאותו קליף
    return out


def finish_clips(p, st, names, **more):
    """28/10 (עצמאות לכל קליף): "סיים את כולם" = עבודה נפרדת בתור לכל קליף (clip=…), לא עבודה אחת של השיעור.
    כך כל קליף שנגמר מוצג מיד צרוב, ואפשר לשנות/לשמור אותו בזמן שהבא עוד נבנה. קליף שכבר בעבודה — מדלגים."""
    jobs, skipped = [], []
    for n in names:
        try:
            jobs.append(enqueue("finish", ["finish", p, "--clips=" + n], p, st.get("video_title", ""), clip=n,
                                kick=False, **more))
        except ValueError:
            skipped.append(n)
    kick_queue()
    if not jobs:
        raise ValueError("%s כבר בעבודה — לחכות שיסתיים" % ", ".join(x.replace("clip", "קליף ") for x in skipped))
    return {"job": jobs[0], "jobs": jobs, "skipped": skipped}


def busy_clips(p):
    """קליפים שיש להם עבודה בתור / רצה עכשיו (שמות). "*" = עבודה של השיעור כולו (הכנה / סיום של כולם)."""
    out = set()
    try:
        P = str(Path(p).resolve())                # 4.1.3: השוואה לפי נתיב מלא — צורת הנתיב לא משנה
    except OSError:
        P = str(p)

    def same(x):
        try:
            return bool(x) and str(Path(x).resolve()) == P
        except OSError:
            return str(x) == str(p)
    for j in list(JOBS.values()):
        if j["running"] and same(j.get("project")) and j["kind"] in QUEUE_KINDS:
            out.add(j.get("clip") or "*")
    with QLOCK:                                   # וגם עבודה שממתינה בתור — שמירה לא "נכנסת" לפניה ומזיזה לה תיקייה
        for q in BUILD_Q:
            if q["status"] in ("waiting", "running") and same(q.get("project")) and q["kind"] in QUEUE_KINDS:
                out.add(q.get("clip") or "*")
    return out


def save_start(p, st, clips=None):
    """"💾 שמור" (28/10, עצמאות לכל קליף): clips = ["clip2"] — רק הוא, גם כשקליף אחר נבנה עכשיו.
    בלי clips = כולם — חוץ ממי שבעבודה ממש עכשיו (הוא יישמר אחר כך; הדף אומר את זה). שמירה אחת בכל פעם לשיעור."""
    live = [c["name"] for c in st["clips"] if not c.get("dropped")]
    want = [x for x in (clips or live) if x in live]
    if not want:
        raise ValueError("אין קליף כזה לשמור")
    # 4.2.0: אין יותר "אפשר לשמור כשיסתיים" — השמירה נכנסת לתור של השיעור ורצה אחרי מה שקדם לה (באותו קליף),
    # ושומרת את התוצאה המוגמרת. שתי שמירות רצופות — בתור, אחת אחרי השנייה.
    part = len(want) < len(live)
    kw = {"clip": want[0]} if len(want) == 1 else {}
    jid = enqueue("save", ["save", p, *(["--clips=" + ",".join(want)] if part else [])], p,
                  st.get("video_title", ""), **kw)
    return {"job": jid, "saved": want, "skipped": []}


def drop_clip_jobs(p, clip):
    """לפני ויתור על קליף: עבודה שלו שרצה עכשיו → שגיאה ברורה; עבודות שממתינות לו בתור → יוצאות (מוחזר כמה)."""
    with QLOCK:
        mine = [q for q in BUILD_Q if q.get("project") == str(p) and q.get("clip") == clip
                and q["status"] in ("waiting", "running")]
        # רצה עכשיו (לא רק "בתור"): של הקליף הזה, או של כל השיעור (סיום של כולם כותב גם אותו)
        now = [j for j in JOBS.values() if j["running"] and j.get("launched") and j["project"] == str(p)
               and (j.get("clip") or "") in ("", clip) and j["kind"] in QUEUE_KINDS]
        if any(q["status"] == "running" for q in mine) or now:
            raise ValueError("%s בעבודה ממש עכשיו — לחכות שתסתיים (כמה דקות), ואז אפשר לוותר עליו"
                             % (clip.replace("clip", "קליף ") if any(j.get("clip") for j in now) or mine else "השיעור"))
        for q in mine:
            j = JOBS.get(q.get("job") or "")
            if j and not j.get("launched"):
                j.update(running=False, ok=None, stage="cancelled", ended=time.strftime("%H:%M"))
            BUILD_Q.remove(q)
        if mine:
            queue_save()
        return len(mine)


def queue_edit(d):
    """▲▼ / גרירה (to) / ⏫ הבא בתור (top) / הוצא מהתור / נסה שוב — רק לפריטים שעוד לא התחילו (או שנכשלו)."""
    with QLOCK:
        q = next((q for q in BUILD_Q if q["id"] == d.get("id")), None)
        if not q:
            raise ValueError("הפריט כבר לא בתור")
        act = d.get("action")
        if act == "remove":
            if q["status"] == "running":
                raise ValueError("העבודה הזאת כבר רצה — אי אפשר להוציא אותה מהתור באמצע")
            j = JOBS.get(q.get("job") or "")
            if j and not j.get("launched"):     # הרשומה "בתור" נסגרת בלי להיכשל
                j.update(running=False, ok=None, stage="cancelled", ended=time.strftime("%H:%M"))
            BUILD_Q.remove(q)
        elif act in ("up", "down", "top", "to"):
            if q["status"] != "waiting":
                raise ValueError("אפשר להזיז רק עבודה שממתינה")
            w = [x for x in BUILD_Q if x["status"] == "waiting"]
            k = w.index(q)
            k2 = {"up": k - 1, "down": k + 1, "top": 0}.get(act, int(d.get("pos", k + 1)) - 1)
            k2 = max(0, min(len(w) - 1, k2))
            w.insert(k2, w.pop(k))
            slots = [i for i, x in enumerate(BUILD_Q) if x["status"] == "waiting"]
            for i, x in zip(slots, w):          # הממתינים מתחלפים ביניהם; השאר נשארים במקום
                BUILD_Q[i] = x
        elif act == "retry":
            if q["status"] != "failed":
                raise ValueError("אפשר לנסות שוב רק עבודה שנכשלה")
            q["status"], q["resume"] = "waiting", True
            q.pop("error", None)
            q.pop("job", None)
            if allow_env(d.get("allow")):             # 22/10: "💻 תמלול במחשב" / "✓ אשר והמשך" מהשורה בתור
                q["allow_env"] = allow_env(d.get("allow"))
            BUILD_Q.remove(q)                   # חוזר לסוף התור של הממתינים
            last = max([i for i, x in enumerate(BUILD_Q) if x["status"] in ("waiting", "running")], default=-1)
            BUILD_Q.insert(last + 1, q)
            _job_for(q)
        else:
            raise ValueError("פעולה לא מוכרת")
        queue_save()
    kick_queue()
    return queue_view()


def load_state(project):
    p = Path(project).resolve()
    if PROJECTS.resolve() not in p.parents:          # רק תיקיות פרויקט, לא כל הדיסק
        raise ValueError("תיקייה לא מוכרת")
    return p, json.load(open(p / MS.STATE, encoding="utf-8"))


SAVE_LOCK = threading.Lock()


def save_edits(d):
    """שמירת התיקונים מהדף. כל קליף מגיע עם ver = הגרסה של קובץ העריכה שממנה הדף התחיל. הקובץ השתנה מאז
    (בנייה בגבולות חדשים כתבה טקסט חדש) → התיקונים שלו נמזגים לגרסה החדשה (merge3) במקום לדרוס אותה."""
    with SAVE_LOCK:
        p, st = load_state(d["project"])
        with LOCK:
            st = json.load(open(p / MS.STATE, encoding="utf-8"))     # טרי — עבודה אולי כתבה בו עכשיו
            new = {"rabbi": d["rabbi"].strip(), "series": d["series"].strip()}
            if "reviewed" in d:                      # "נבדק" לכל קליף (כרטיס 12) — נשמר כדי שלא יישכח בטעינה
                new["reviewed"] = sorted({str(x) for x in d["reviewed"]})
            if st.get("text_unchecked") and d.get("text_ok"):   # כרטיס 14: תיקן / אישר את הטקסט אחרי הצריבה האוטומטית
                new["text_unchecked"] = [n for n in st["text_unchecked"] if n not in set(map(str, d["text_ok"]))]
            if any(st.get(k) != v for k, v in new.items()):          # כותבים רק כשבאמת השתנה (פחות התנגשויות עם עבודה)
                st.update(new)
                tmp = (p / MS.STATE).with_suffix(".json.tmp")
                json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
                tmp.replace(p / MS.STATE)
        vers, merged = {}, {}
        for e in d["clips"]:
            c = next(c for c in st["clips"] if c["name"] == e["name"])
            f = p / c["edit"]
            cur, base = MS.edit_ver(f), e.get("ver") or ""
            text = e["text"]
            if base and base != cur:
                b = MS.version_text(p, f, base)
                now = MS.read_edit_raw(f)
                if b is None:                        # אין בסיס להשוואה — לא דורסים גרסה שלא ראה
                    merged[c["name"]] = {"text": now["text"], "applied": 0,
                                         "conflicts": ["הטקסט התעדכן בינתיים — התיקונים האחרונים לא נשמרו, כדאי לבדוק"]}
                    vers[c["name"]] = cur
                    continue
                if b["text"].strip() != text.strip():
                    text, n, conf = MS.merge3(b["text"], text, now["text"])
                    merged[c["name"]] = {"text": text, "applied": n, "conflicts": conf}
                else:
                    text = now["text"]               # לא תיקן כלום מאז — פשוט הגרסה החדשה
                    merged[c["name"]] = {"text": text, "applied": 0, "conflicts": []}
            MS.write_edit(f, c, p, e["title"], e["desc"], e["tags"], text, e["yt"])
            vers[c["name"]] = MS.edit_ver(f)
        return {"saved": True, "vers": vers, "merged": merged}


def MS_save_state(p, st_view):
    """רושם רק את "saved" לקובץ המצב (התצוגה מכילה שדות של החלון שלא שייכים לקובץ)."""
    with LOCK:
        f = Path(p) / MS.STATE
        st = json.load(open(f, encoding="utf-8"))
        st["saved"] = st_view["saved"]
        tmp = f.with_suffix(".json.tmp")
        json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        tmp.replace(f)


def final_dir(p, name):
    for d in sorted((p / "shorts").glob(name + "*")):
        if d.is_dir() and re.match(re.escape(name) + r"(_|$)", d.name) and list(d.glob("*.mp4")):
            return d
    return None


def lesson_state(d, st=None):
    """מצב השיעור לפי הקבצים (כשאין עבודה רצה בשרת הזה): הצעות, נקטע באמצע, נכשל, לתיקון, טיוטה,
    נשמר, או נשמר ושונה מאז ("unsaved")."""
    job = PR.load(d).get("job") or {}
    js = PR.job_state(d)
    if js == "interrupted":
        return "interrupted"
    f = d / MS.STATE
    if not f.exists() and job.get("kind") == "prepare" and js == "done" and PR.data(d).get("net_ready"):
        return "offline_ready"                 # "✓ מוכן לעבודה בלי אינטרנט" — מחכה ל"▶ המשך בלי אינטרנט"
    if not f.exists():
        try:                                   # בחירה אוטומטית שעוד לא עברה ל"הכן"
            pk = json.load(open(d / PICK.PICK, encoding="utf-8"))
            if pk.get("status") == "ready":
                return "pick_ready"
            return "interrupted" if pk.get("status") == "scanning" else "failed"
        except (OSError, ValueError):
            return "failed" if js == "failed" else "interrupted"
    if js == "failed" and job.get("kind") in ("prepare",):
        return "failed"
    try:
        st = st or json.load(open(f, encoding="utf-8"))
    except ValueError:
        return "failed"
    live = [c for c in st.get("clips", []) if not c.get("dropped")]
    if js == "failed":
        return "failed"
    if st.get("finished") and live and all(final_dir(d, c["name"]) for c in live):
        u = MS.unsaved(d, st)
        if u is None:
            return "saved" if st.get("export_target") and not st.get("saved") else "draft"
        if not u and all(c.get("uploaded") for c in live):
            return "uploaded"                   # כרטיס 17: כל השורטס סומנו "✓ הועלה" — אפשר לנקות
        return "unsaved" if u else "saved"
    if st.get("finished") and not live:
        return "saved" if st.get("saved") else "draft"
    return "ready_edit"


def file_state(d):
    title = d.name
    try:
        st = json.load(open(d / MS.STATE, encoding="utf-8"))
        title = st.get("video_title") or d.name
    except (OSError, ValueError):
        st = None
        try:
            title = json.load(open(d / PICK.PICK, encoding="utf-8")).get("title") or d.name
        except (OSError, ValueError):
            pass
    return lesson_state(d, st), title


TABS_FILE = PROJECTS.parent / "app_tabs.json"


def tabs_hidden():
    try:
        return set(json.load(open(TABS_FILE, encoding="utf-8")).get("hidden", []))
    except (OSError, ValueError):
        return set()


def set_hidden(project, hide):
    h = tabs_hidden()
    (h.add if hide else h.discard)(str(project))
    TABS_FILE.parent.mkdir(parents=True, exist_ok=True)
    json.dump({"hidden": sorted(h)}, open(TABS_FILE, "w", encoding="utf-8"), ensure_ascii=False)


def live_state(d, j):
    state, title = file_state(d)
    if j and j["running"]:
        state = j["stage"] if j["stage"] in ("queued", "building") else "working"
    elif j and j["ok"] is False:
        state = "failed"
    return state, title


def past_lessons():
    """"📂 שיעורים קודמים": רק שיעורים שהתוכנה יצרה (projects/תוכנה/), עם מצב ותאריך."""
    last = {j["project"]: j for j in JOBS.values() if j["project"]}
    links = playlist_links()
    out = []
    for d in sorted(TOOL.glob("*"), key=lambda d: d.stat().st_mtime, reverse=True) if TOOL.exists() else []:
        if not d.is_dir() or not ((d / MS.STATE).exists() or (d / PICK.PICK).exists()):
            continue
        state, title = live_state(d, last.get(str(d)))
        if state not in ("working", "building") and str(d) in queued_projects():
            state = "queued"
        m = re.match(r"(\d{4})-(\d\d)-(\d\d)", d.name)
        pl = links.get(str(d))
        if pl:
            try:
                title = "%s › %s" % (PICK.load(pl[0]).get("title") or "פלייליסט", title)
            except (OSError, ValueError):
                pass
        if str(d.resolve()) in CLEANING:
            state = "cleaning"
        out.append({"project": str(d), "title": title, "state": state,
                    "error": (last.get(str(d)) or {}).get("error") or (PR.load(d).get("job") or {}).get("error", ""),
                    "date": "%s/%s/%s" % (m.group(3), m.group(2), m.group(1)) if m else "",
                    "modified": time.strftime("%d/%m %H:%M", time.localtime(d.stat().st_mtime)),
                    "hidden": str(d) in tabs_hidden(),
                    "bytes": dir_bytes(d), "playlist": "_playlist-" in d.name,     # כרטיס 17: כמה מקום תופס
                    "clips": past_clips(d)})                # כרטיס 23: "✓ הועלה" ישר מכאן
    return out


def past_clips(d):
    """31/10 (כרטיס 23): השורטס של שיעור ב"📂 שיעורים קודמים" — לסימון "✓ הועלה" בלי לפתוח את השיעור."""
    try:
        st = json.load(open(d / MS.STATE, encoding="utf-8"))
    except (OSError, ValueError):
        return []
    saved = set((st.get("saved") or {}).get("clips") or [])
    out = []
    for c in st.get("clips", []):
        if c.get("dropped"):
            continue
        sec = c.get("seconds")
        out.append({"name": c["name"], "title": CLEAN.clip_title(d, c),        # 4.3.1: השם של השורט עצמו (לא "קליף N")
                    "seconds": round(sec) if isinstance(sec, (int, float)) else None,
                    "saved": c["name"] in saved, "uploaded": c.get("uploaded") or "",
                    "state": "uploaded" if c.get("uploaded") else "saved" if c["name"] in saved
                    else "draft" if final_dir(d, c["name"]) else "working"})
    return out


_SIZE_CACHE = {}


def dir_bytes(d):
    """גודל תיקיית שיעור (נשמר לפי זמן השינוי של הקבצים הראשיים — לא סורקים מחדש בכל פתיחה)."""
    try:
        parts = [d] + [d / s for s in ("work", "shorts", "source", "work/clips") if (d / s).exists()]
        sig = tuple(round(x.stat().st_mtime) for x in parts)
    except OSError:
        return 0
    c = _SIZE_CACHE.get(str(d))
    if not c or c[0] != sig:
        c = (sig, CLEAN.size_of(d)[0])
        _SIZE_CACHE[str(d)] = c
    return c[1]


# ─────────────── כרטיס 17: "✓ הועלה" ו-"🧹 נקה" ───────────────

def mark_uploaded(d):
    """"✓ הועלה" / "בטל סימון" לשורט שנשמר — רק סימון, שום דבר לא נמחק.
    31/10 (כרטיס 23): גם מ"📂 שיעורים קודמים" ומחלון הניקוי. only_saved = "סמן שכל השיעור הועלה": מסמן את מה שנשמר
    ומחזיר ב-skipped את מה שעוד לא נשמר (במקום להיכשל על הראשון). items = כמה שורטס/שיעורים בבקשה אחת."""
    if d.get("items") is not None:
        out = {"ok": True, "skipped": [], "states": {}}
        for it in d["items"]:
            r = mark_uploaded(dict(it, on=d.get("on", True), only_saved=d.get("only_saved")))
            out["skipped"] += r["skipped"]
            out["states"][it["project"]] = r["state"]
        return out
    p, st = load_state(d["project"])
    if str(p.resolve()) in CLEANING:
        raise ValueError("השיעור הזה מתנקה עכשיו (🧹) — אי אפשר לשנות סימון")
    skipped = []
    with LOCK:
        st = json.load(open(p / MS.STATE, encoding="utf-8"))
        names = [d["clip"]] if d.get("clip") else [c["name"] for c in st["clips"] if not c.get("dropped")]
        if d.get("clip") and d["clip"] not in {c["name"] for c in st["clips"]}:
            raise ValueError("אין קליף בשם %s" % d["clip"])
        saved = set((st.get("saved") or {}).get("clips") or [])
        for c in st["clips"]:
            if c["name"] not in names:
                continue
            if d.get("on", True):
                if c["name"] not in saved:
                    if d.get("only_saved"):
                        skipped.append("%s — %s" % (st.get("video_title") or p.name, c.get("title") or c["name"]))
                        continue
                    raise ValueError("%s עוד לא נשמר לתיקייה — קודם \"💾 שמור\"" % c["name"].replace("clip", "קליף "))
                c.setdefault("uploaded", time.strftime("%Y-%m-%d %H:%M"))
            else:
                c.pop("uploaded", None)
        MS_write_state(p, st)
    return {"ok": True, "state": lesson_state(p), "skipped": skipped}


def MS_write_state(p, st):
    f = Path(p) / MS.STATE
    tmp = f.with_suffix(".json.tmp")
    json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    tmp.replace(f)


def clean_items(d):
    """מה לנקות: items מהדף, או all_uploaded = כל השיעורים ב"📂 שיעורים קודמים" שכל השורטס שלהם סומנו "הועלה"."""
    if d.get("all_uploaded"):
        return [{"project": x["project"]} for x in past_lessons() if x["state"] == "uploaded"]
    items = []
    for it in d.get("items") or []:
        P = Path(it["project"]).resolve()
        if P.parent != TOOL.resolve():
            raise ValueError("רק שיעורים שהתוכנה עשתה — שיעורים של Claude מנקים דרך Claude, כמו היום")
        items.append({"project": str(P), **({"clip": it["clip"]} if it.get("clip") else {})})
    if not items:
        raise ValueError("אין מה לנקות")
    return items


def clean_blockers(items):
    """בקרת סתירות (ברוח כרטיס 14): לא מנקים שיעור שיש בו עבודה רצה, בתור, תצוגה מקדימה, או ניקוי אחר."""
    out = []
    links = playlist_links()
    qp = {str(Path(x).resolve()) for x in queued_projects() if x}
    for P in sorted({str(Path(it["project"]).resolve()) for it in items}):
        name = Path(P).name
        if P in CLEANING:
            out.append("%s — כבר מתנקה עכשיו" % name)
        elif busy(P) or any(j["running"] and j["project"] and str(Path(j["project"]).resolve()) == P for j in JOBS.values()):
            out.append("%s — יש בו עבודה שרצה עכשיו. לחכות שתסתיים" % file_state(Path(P))[1])
        elif P in qp:
            out.append("%s — יש לו עבודה בתור (📋 תור העבודה). להוציא אותה מהתור או לחכות" % file_state(Path(P))[1])
        elif any(pv["running"] and pv["key"][0] == P for pv in PREVIEWS.values()):
            out.append("%s — תצוגה מקדימה נבנית עכשיו. לחכות כמה שניות" % file_state(Path(P))[1])
        if "_playlist-" in name:
            kids = [k for k, v in links.items() if v[0] == P and Path(k).is_dir()]
            if kids:
                out.append("הפלייליסט «%s» — יש בו עוד %d שיעורים שלא נוקו. קודם לנקות אותם"
                           % (file_state(Path(P))[1], len(kids)))
    return out


def clean_plan(d):
    items = clean_items(d)
    if not items:
        return {"lessons": [], "total_bytes": 0, "n_shorts": 0, "n_dropped": 0, "not_uploaded": [], "blocked": [],
                "export_files": 0, "too_big": False}
    pl = CLEAN.plan(items)
    pl["blocked"] = clean_blockers(items)
    pl["items"] = items
    pl["test_mode"] = MS.TEST_MODE
    return pl


def clean_start(d):
    items = clean_items(d)
    pl = CLEAN.plan(items)
    bl = clean_blockers(items)
    if bl:
        raise ValueError("אי אפשר לנקות עכשיו:\n" + "\n".join(bl))
    if pl["too_big"]:
        raise ValueError("זה יותר מ-%dGB בבת אחת — לנקות בכמה פעמים (סל המיחזור לא מחזיק יותר)" % pl["max_gb"])
    if pl["not_uploaded"] and not d.get("yes_not_uploaded"):
        raise ValueError("יש שורטס שלא סומנו \"הועלה\" — צריך לאשר במפורש")
    projs = {str(Path(it["project"]).resolve()) for it in items}
    with LOCK:
        if projs & CLEANING:
            raise ValueError("כבר מתנקה")
        CLEANING.update(projs)
    try:
        SPECS.mkdir(parents=True, exist_ok=True)
        f = SPECS / ("clean_%s_%d.json" % (time.strftime("%Y%m%d_%H%M%S"), next(IDS)))
        f.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")
        title = pl["lessons"][0]["title"] if len(pl["lessons"]) == 1 else "%d שיעורים" % len(pl["lessons"])
        jid = start_job("clean", [sys.executable, str(HERE / "make_short_clean.py"), "run", str(f)], "", "🧹 " + title,
                        extra={"clean_projects": sorted(projs), "clean_spec": str(f),
                               "clean_whole": [r["project"] for r in pl["lessons"] if r["whole"]]})
    except Exception:
        CLEANING.difference_update(projs)
        raise
    return {"job": jid}


def clean_ended(job):
    """אחרי "🧹 נקה": השיעורים משתחררים; שיעור שנעלם — יוצא מהתור (פריטים שנכשלו), מהלשוניות הסגורות,
    וצילומי ההגדרות שרק הוא השתמש בהם נמחקים (קבצי JSON קטנים של התוכנה עצמה)."""
    projs = set(job.get("clean_projects") or [])
    gone = {p for p in projs if not Path(p).exists()}
    if gone:
        with QLOCK:
            keep = [q for q in BUILD_Q if str(Path(q.get("project") or "/").resolve()) not in gone]
            dead = [q for q in BUILD_Q if q not in keep]
            used = {q.get("settings") for q in keep}
            BUILD_Q[:] = keep
            queue_save()
        for q in dead:
            s = q.get("settings") or ""
            if s and s not in used and Path(s).parent == JOB_SET_DIR and Path(s).exists():
                try:
                    Path(s).unlink()
                except OSError:
                    pass
        h = tabs_hidden()
        if h & gone:
            TABS_FILE.parent.mkdir(parents=True, exist_ok=True)
            json.dump({"hidden": sorted(h - gone)}, open(TABS_FILE, "w", encoding="utf-8"), ensure_ascii=False)
    try:
        Path(job.get("clean_spec") or "").unlink()
    except OSError:
        pass
    CLEANING.difference_update(projs)


_PL_CACHE = {}


def playlist_links():
    """שיעור שנבנה מפלייליסט → (תיקיית הפלייליסט, מספר השיעור בו). נשמר ב-pick.json של הפלייליסט
    (lessons[i].project), כך שגם אחרי הפעלה מחדש השיעורים נשארים תת-לשוניות של הפלייליסט שלהם."""
    out = {}
    for pj in TOOL.glob("*_playlist-*/" + PICK.PICK) if TOOL.exists() else []:
        try:
            m = pj.stat().st_mtime
        except OSError:
            continue
        c = _PL_CACHE.get(str(pj))
        if not c or c[0] != m:
            try:
                d = json.load(open(pj, encoding="utf-8"))
                c = (m, {l["project"]: l["n"] for l in d.get("lessons", []) if l.get("project")})
            except (OSError, ValueError):
                c = (m, {})
            _PL_CACHE[str(pj)] = c
        for proj, n in c[1].items():
            out[proj] = (str(pj.parent), n)
    return out


def link_playlist_lessons(P, mapping):
    """mapping = {מספר שיעור: תיקיית הפרויקט שלו} — נרשם בפלייליסט (ללא דריסה של קישור קיים לאותה תיקייה)."""
    with LOCK:
        st = PICK.load(P)
        ch = False
        for l in st["lessons"]:
            proj = mapping.get(l["n"])
            if proj and l.get("project") != str(proj):
                l["project"], ch = str(proj), True
        if ch:
            PICK.save(P, st)


def migrate_playlist_links():
    """פלייליסטים שהוכנו לפני שהקישור נשמר: מזהים לפי קבצי ה-spec שנכתבו להכנה (spec_..._<pid>_<n>.json) —
    כל שיעור שהוכן מפלייליסט (לפי מזהה הסרטון) מתקשר לפלייליסט האחרון שמכיל אותו."""
    pls = []
    for pj in sorted(TOOL.glob("*_playlist-*/" + PICK.PICK)) if TOOL.exists() else []:
        try:
            pls.append((pj.parent, json.load(open(pj, encoding="utf-8"))))
        except (OSError, ValueError):
            pass
    if not pls or not SPECS.exists():
        return 0
    n_new = 0
    byp = {}
    for sp in sorted(SPECS.glob("spec_*.json")):
        if not re.fullmatch(r"spec_\d{8}_\d{6}_\d+_\d+\.json", sp.name):
            continue                                      # רק הכנות של פלייליסט (עם מספר שיעור אחרי ה-pid)
        try:
            d = json.load(open(sp, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        m = re.search(r"v=([\w-]{11})", d.get("url", ""))
        proj = d.get("project")
        if not m or not proj or not Path(proj).is_dir():
            continue
        cands = [(p, st) for p, st in pls if p.name[:10] <= sp.name[5:9] + "-" + sp.name[9:11] + "-" + sp.name[11:13]
                 and any(l.get("id") == m.group(1) for l in st.get("lessons", []))]
        if not cands:
            continue
        p, st = cands[-1]
        les = next(l for l in st["lessons"] if l.get("id") == m.group(1))
        if not les.get("project"):
            byp.setdefault(p, {})[les["n"]] = proj
    for p, mp in byp.items():
        link_playlist_lessons(p, mp)
        n_new += len(mp)
    if n_new:
        app_log("=== %s migrated %d playlist links" % (time.strftime("%Y-%m-%d %H:%M:%S"), n_new))
    return n_new


def lessons():
    """הלשוניות: כל שיעור בתיקיית התוכנה שלא נסגר (×) + עבודות שעוד אין להן תיקייה.
    שיעור שנבנה מפלייליסט מקבל parent (תיקיית הפלייליסט) — הדף מציג אותו כתת-לשונית של הפלייליסט."""
    out, seen = [], set()
    last = {}
    hidden = tabs_hidden()
    qv = [q for q in queue_view()["items"] if q["status"] in ("waiting", "running")]
    qby = {q["project"]: q for q in qv if q["project"]}
    links = playlist_links()
    for j in JOBS.values():
        if j["project"]:
            last[j["project"]] = j        # האחרונה לכל שיעור (המילון שומר סדר)
    dirs = sorted(TOOL.glob("*"), key=lambda d: d.stat().st_mtime, reverse=True) if TOOL.exists() else []
    pl_dirs = {v[0] for v in links.values()}
    dirs = dirs[:30] + [d for d in dirs[30:] if str(d) in links or str(d) in pl_dirs]
    for d in dirs:
        parent = (links.get(str(d)) or ("",))[0] or (qby.get(str(d)) or {}).get("pl", "")
        if parent and not Path(parent).is_dir():
            parent = ""
        if not d.is_dir() or str(d) in hidden or (parent and parent in hidden):
            continue
        j = last.get(str(d))
        state, title = live_state(d, j)
        if title == d.name and j and j["title"]:          # עוד אין make_short.json — הכותרת מהעבודה
            title = j["title"]
        # אחרי "הכן" באותה תיקייה — הלשונית עוברת לתצוגת השיעור הרגילה (יומן ההכנה, ואז עריכה)
        fjob = PR.load(d).get("job") or {}
        pick = (d / PICK.PICK).exists() and not (d / MS.STATE).exists() and \
            not (j and j["kind"] == "prepare" and j["ok"] is not False) and fjob.get("kind") != "prepare"
        if title == d.name and pick:
            try:
                title = json.load(open(d / PICK.PICK, encoding="utf-8")).get("title") or title
            except (OSError, ValueError):
                pass
        row = {"key": str(d), "project": str(d), "title": title, "state": state, "job": j["id"] if j else "",
               "kind": j["kind"] if j else fjob.get("kind", ""), "running": bool(j and j["running"]), "pick": pick,
               "playlist": pick and "_playlist-" in d.name, "parent": parent,
               "n": (links.get(str(d)) or ("", 0))[1] or (qby.get(str(d)) or {}).get("n") or 0,
               "error": (j or {}).get("error") or fjob.get("error", "")}
        q = qby.get(str(d))
        if q:                                 # בתור: מקום בתור; תהליך שנשאר מהשרת הקודם — "עובד"
            row["qpos"] = q.get("pos")
            if not row["running"]:
                row["state"] = "queued" if q["state"] == "queued" else ("working" if q["status"] == "running" else row["state"])
                if q["status"] == "running":
                    row["progress"] = q.get("progress")
        if j and j["running"] and j.get("launched", True):
            row["progress"] = job_progress(j["plan"], j["steps"])
        if str(d.resolve()) in CLEANING:          # כרטיס 17: באמצע "🧹 נקה"
            row["state"] = "cleaning"
        ev = EDITOR["view"].get(str(d))
        if ev:                                    # 28/10: ממתין לעורך / נשלח אליו — הלשונית "בעבודה", לא "לתיקון"
            row["editor"] = ev.get("msg", "")
            v = _ed_state(d)
            if row["state"] == "ready_edit" and v and v[2]:     # רק כשטיוטה אוטומטית מחכה לעורך (אין לו מה לעשות)
                row["state"] = "working"
        # 28/10: "אוטומטי עד הצריבה" עצר לצ'אט (בחירה / עורך) — הדף שולח התראה פעם אחת
        v = _ed_state(d) if (d / MS.STATE).exists() else None
        if v and v[0] == "chat" and v[2]:
            row["pause"] = "editor"
        elif pick:
            try:
                if json.load(open(d / PICK.PICK, encoding="utf-8")).get("auto_pause"):
                    row["pause"] = "pick"
            except (OSError, ValueError):
                pass
        out.append(row)
        seen.add(str(d))
    for j in JOBS.values():
        jpar = (qby.get(j["project"]) or {}).get("pl", "") if j["project"] else ""
        if j["kind"] == "prepare" and j["project"] not in seen and (j["running"] or j["ok"] is False) \
                and j["project"] not in hidden and not (jpar and jpar in hidden):
            out.insert(0, {"key": "job:" + j["id"], "project": j["project"], "parent": jpar,
                           "n": (qby.get(j["project"]) or {}).get("n") or 0,
                           "title": j["title"] or j.get("url", ""),
                           "state": ("queued" if j["stage"] == "queued" else "working") if j["running"] else "failed",
                           "job": j["id"], "kind": "prepare", "running": j["running"], "error": j.get("error", ""),
                           "progress": job_progress(j["plan"], j["steps"]) if j["running"] else None,
                           "qpos": (qby.get(j["project"]) or {}).get("pos")})
            seen.add(j["project"])
    return out


def allow_env(allow):
    """כפתורי האישור שבכרטיס הכישלון → משתני סביבה לעבודה החוזרת (רק היא; הבאות שוב שואלות)."""
    allow = allow or {}
    env = {}
    if allow.get("cpu"):
        env["MAKE_SHORT_ASR_ALLOW_CPU"] = "1"
    if allow.get("modal_ok"):
        env["MAKE_SHORT_MODAL_OK"] = "1"
    return env


def resume(project, allow=None):
    """▶ המשך מאיפה שעצרתי: אותה פקודה שוב — כל שלב שכבר גמור (והקובץ שלו שלם) מדולג.
    allow (22/10): {"cpu": True} = אישר תמלול במחשב אחרי ש-Modal נפל · {"modal_ok": True} = אישר לעבור את תקרת היום."""
    env = allow_env(allow)
    P = Path(project).resolve()
    if PROJECTS.resolve() not in P.parents:
        raise ValueError("תיקייה לא מוכרת")
    if busy(P):
        raise ValueError("השיעור הזה כבר בעבודה")
    job = PR.load(P).get("job") or {}
    if job.get("status") == "running" and PR.pid_alive(job.get("pid")):
        raise ValueError("העבודה הקודמת עוד נסגרת ברקע — לנסות שוב בעוד רגע")
    title = file_state(P)[1]
    if job.get("argv"):
        kind, argv = job["kind"], job["argv"]
        if kind in ("prepare", "pick") and not MS.net_ok():
            raise ValueError("אין אינטרנט — ההכנה צריכה חיבור (הורדה ותמלול). אפשר להמשיך כשהחיבור יחזור.")
        if kind in QUEUE_KINDS:                   # "המשך" של עבודה כבדה — לתור (ראשון אם אין אחר)
            snap = job.get("settings") if job.get("settings") and Path(job["settings"]).exists() else ""
            return enqueue(kind, argv, P, title, settings=snap,     # עם ההגדרות שהעבודה התחילה איתן (כרטיס 14)
                           **({"allow_env": env} if env else {}))
        return start_job(kind, ms_cmd(*argv), P, title, extra={"env": env} if env else None)
    if (P / PICK.PICK).exists() and not (P / MS.STATE).exists():       # סריקת הצעות שנקטעה
        if not MS.net_ok():
            raise ValueError("אין אינטרנט — הסריקה צריכה חיבור")
        return start_job("pick", pick_cmd("scan", P), P, title)
    raise ValueError("אין עבודה להמשיך בשיעור הזה")


def folders():
    """הרבנים והסדרות שכבר יש להם תיקייה — כדי שסדרה קיימת תיכתב בדיוק באותו שם."""
    res = {}
    root = MS.export_root() or EXPORT          # בבדיקה — תיקיית הבדיקה, שאליה גם נשמר (כרטיס 16)
    if root.exists():
        for r in root.iterdir():
            if r.is_dir():
                res[r.name] = sorted(s.name for s in r.iterdir() if s.is_dir())
    return res


def refresh_health():
    if HEALTH_STATE["running"]:
        return
    HEALTH_STATE["running"] = True

    def work():
        try:
            HEALTH_STATE["data"] = HEALTH.run_all(SET.load()["drive_on"], MS.net_ok())
        finally:
            HEALTH_STATE["running"] = False
            HEALTH_STATE["ver"] += 1
    threading.Thread(target=work, daemon=True).start()


def health_put(r):
    """תוצאה אחת נכנסת במקום הקודמת שלה (או נוספת), והדף מצייר מחדש."""
    with LOCK:
        d = HEALTH_STATE["data"] or {"at": "", "results": [], "online": True}
        d["results"] = [x for x in d["results"] if x.get("id") != r["id"]] + [r]
        d["at"] = time.strftime("%H:%M")
        HEALTH_STATE["data"] = d
        HEALTH_STATE["ver"] += 1


def recheck(ids, wait=False):
    """22/10: אחרי כל פעולת תיקון — בודקים מיד רק את מה שהיא אמורה לתקן, וההתראה מתעדכנת לבד."""
    def go():
        for i in ids:
            HEALTH_STATE["rechecking"].add(i)
            HEALTH_STATE["ver"] += 1
            try:
                health_put(HEALTH.run_one(i, SET.load()["drive_on"]))
            except Exception as e:
                app_log("=== recheck %s: %s" % (i, e))
            finally:
                HEALTH_STATE["rechecking"].discard(i)
                HEALTH_STATE["ver"] += 1
    if wait:
        go()
    else:
        threading.Thread(target=go, daemon=True).start()


def action_set(id_, state, msg=""):
    HEALTH_STATE["actions"][id_] = {"state": state, "msg": msg, "at": time.strftime("%H:%M"), "ts": time.time()}
    HEALTH_STATE["ver"] += 1


def health_view():
    d = HEALTH_STATE["data"]
    if d and JOB_ALERTS:
        # התראה שעלתה מעבודה שנכשלה (עוגיות / yt-dlp / Modal) מחליפה את הבדיקה הרגילה של אותו נושא — היא מדויקת
        # יותר ("יוטיוב ביקש התחברות בהורדה של X"), גם כשתאריכי העוגיות עוד נראים תקינים
        d = dict(d, results=[JOB_ALERTS.get(r.get("id"), r) for r in d.get("results", [])] +
                 [a for k, a in JOB_ALERTS.items() if not any(r.get("id") == k for r in d.get("results", []))])
    return {"running": HEALTH_STATE["running"], "data": d, "ver": HEALTH_STATE["ver"],
            "actions": HEALTH_STATE["actions"], "rechecking": sorted(HEALTH_STATE["rechecking"])}


# ─────────────── 22/10: התראות חיות ───────────────
# לא רק בפתיחה: בדיקה ממש לפני עבודה שצריכה את הדבר (עוגיות לפני הורדה/פלייליסט, Gemini לפני בחירה, Modal לפני
# תמלול), כל ~30 דקות, ומיד כשעבודה נכשלה בגלל אחד מהם. 🚨 אף בדיקה לא שולחת בקשת generateContent ל-Gemini
# (זה עולה מכסה) — רק המונה המקומי ומה שגוגל ענה בפעם האחרונה (gemini_status).
JOB_ALERTS = {}
HEALTH_EVERY = float(os.environ.get("MAKE_SHORT_HEALTH_EVERY", "1800"))


def gemini_health():
    g = PICK.gemini_status()
    act = {"id": "gemini_settings", "label": "להגדרות Gemini"}
    if not g["has_key"]:
        return HEALTH.res("gemini", "ok", "Gemini: אין מפתח — הבחירה דרך \"העתק לצ'אט\"")
    if g["key_blocked"]:
        return HEALTH.res("gemini", "bad", "מפתח Gemini נחסם (Google ענה 403)",
                          "הבחירה האוטומטית לא תעבוד עם המפתח הזה. בינתיים \"העתק לצ'אט\" עובד כרגיל.",
                          ["לפתוח את https://aistudio.google.com/apikey וליצור מפתח חדש (בפרויקט חדש)",
                           "בהגדרות → Gemini: להדביק אותו ו\"שמור ובדוק\""], act)
    m = g["models"].get(g["model"]) or {}
    if m.get("blocked_until"):
        until = time.strftime("%H:%M", time.localtime(m["blocked_until"]))
        day = "יומית" in (m.get("block_msg") or "")
        return HEALTH.res("gemini", "warn", ("המכסה היומית של Gemini נגמרה — מתאפסת ב-%s" if day else
                                             "Gemini: יותר מדי בקשות בדקה — אפשר שוב ב-%s") % until,
                          (m.get("block_msg") or "") + " (לפי התשובה האחרונה של Google — לא נשלחה בקשה כדי לבדוק).",
                          ["בינתיים: \"העתק לצ'אט\" במסך ההצעות — עובד בלי מכסה",
                           "או להחליף מודל בהגדרות → Gemini (לכל מודל מכסה משלו)"], act)
    return HEALTH.res("gemini", "ok", "Gemini: %d מתוך %d בקשות היום" % (m.get("used", 0), m.get("limit") or 20))


HEALTH.EXTRA["gemini"] = gemini_health

# מילים בלוג של עבודה שנכשלה → איזו התראה להרים. הסדר חשוב: "צריך להתחבר" לפני 403 כללי
JOB_PATTERNS = [
    ("cookies", re.compile(r"Sign in to confirm|cookies (are|have) (no longer valid|expired)|login required|"
                           r"members[- ]only|Private video|This video is private|use --cookies|העוגיות.*(פגו|לא תקינות)", re.I)),
    ("ytdlp", re.compile(r"HTTP Error 403|nsig extraction|Signature extraction failed|Requested format is not available|"
                         r"Unable to extract|unable to download video data|player response", re.I)),
    ("modal", re.compile(r"Modal לא זמין|modal\.exception|AuthError|Token (missing|validation)|not authenticated|"
                         r"add a payment method|spending limit|workspace.*(disabled|suspended)", re.I)),
]


def job_alert(kind, job):
    title = (job.get("title") or "")[:60]
    at = time.strftime("%H:%M")
    if kind == "cookies":
        jtext = "\n".join((job.get("log") or [])[-80:] + [str(job.get("error") or "")])
        if re.search(r"confirm you.?re not a bot", jtext, re.I) and not re.search(
                r"private video|members[- ]only|login required|cookies (are|have) (no longer valid|expired)|העוגיות.*(פגו|לא תקינות)", jtext, re.I):
            # 4.5.62: "לא רובוט" ≠ "העוגיות פגו" — לשיעור ציבורי עוגיות לא פותרות (ואין צורך בהן); אותה הנחיה כמו ב"צעדים ראשונים"
            r = HEALTH.res("cookies", "bad", "יוטיוב ביקש לאשר שאתם לא רובוט", HEALTH.BOT_NOTE +
                           " אחרי זה: \"🔁 נסה שוב\" בשיעור.",
                           ["לשיעור ציבורי: לחכות כמה שעות, או לעבור לרשת אחרת (נקודה חמה מהטלפון), ולנסות שוב",
                            "לשיעור מתוזמן או פרטי: לחדש עוגיות — השלבים בכרטיס '🍪' ב-'🧭 צעדים ראשונים'"],
                           {"id": "upload_cookies", "label": "העלה קובץ עוגיות"})
        else:
            r = HEALTH.res("cookies", "bad", "יוטיוב ביקש התחברות בהורדה — כנראה העוגיות פגו",
                           "שיעורים מתוזמנים או פרטיים לא יירדו עד שיחודשו (ציבוריים — כן). אחרי ההעלאה: \"🔁 נסה שוב\" בשיעור.",
                           HEALTH.COOKIE_STEPS, {"id": "upload_cookies", "label": "העלה קובץ עוגיות"})
    elif kind == "ytdlp":
        r = HEALTH.res("ytdlp", "bad", "ההורדה מיוטיוב נכשלה — כנראה כלי ההורדה צריך עדכון", HEALTH.YTDLP_WHY,
                       ["ללחוץ \"עדכן עכשיו\"", "ואז \"🔁 נסה שוב\" בשיעור"], {"id": "update_ytdlp", "label": "עדכן עכשיו"})
    else:
        r = HEALTH.res("modal", "bad", "Modal (התמלול בענן) לא ענה בעבודה האחרונה",
                       "העבודה נעצרה ולא עברה למחשב בלי לשאול.",
                       ["לבדוק שיש אינטרנט, ואז \"🔁 נסה שוב\" בשיעור (לרוב זה עובר אחרי כמה דקות)",
                        "אם זה נמשך: להיכנס ל-modal.com ולבדוק שהחשבון פעיל ושיש קרדיט. הגעתם לתקרת ההוצאה? זה בסדר — "
                        "זה בדיוק מה שהתקרה נועדה לעשות; התמלול יעבור למחשב עד תחילת החודש. להגדלה: modal.com ← Settings ← "
                        "Usage & Billing ← Workspace budget",
                        "אין ברירה? \"💻 תמלול במחשב\" בכרטיס השיעור — איטי ופחות מדויק"])
    r.update(from_job=title, at=at, job=job.get("id"), ts=time.time())
    return r


def job_failed_alerts(job):
    """עבודה שנכשלה בגלל עוגיות / yt-dlp / Modal — ההתראה המתאימה עולה מיד, עם השלבים לתיקון."""
    text = "\n".join((job.get("log") or [])[-80:] + [str(job.get("error") or "")])
    if job.get("kind") in MODAL_KINDS and ENGINE_RX.search(text):    # 29/10: תמלול שנפל בשגיאה של הספרייה
        try:
            r = engine_res(fail_job=job, net=NET["ok"])
        except Exception as e:
            app_log("=== engine alert: %s" % e)
            r = None
        if r is not None and ENG.newer(net=False):     # רק כשבאמת יש גרסה חדשה יותר — אחרת אין מה להציע
            r.update(from_job=(job.get("title") or "")[:60], at=time.strftime("%H:%M"), job=job.get("id"), ts=time.time())
            JOB_ALERTS["engine"] = r
            HEALTH_STATE["ver"] += 1
            app_log("=== live alert from job %s: engine" % job.get("id"))
            return "engine"
    for kind, rx in JOB_PATTERNS:
        if rx.search(text) and "תקרת Modal היומית" not in text:
            JOB_ALERTS[kind] = job_alert(kind, job)
            HEALTH_STATE["ver"] += 1
            app_log("=== live alert from job %s: %s" % (job.get("id"), kind))
            return kind
    return None


def job_end_alerts(job, wait=False):
    kind = job.get("kind")
    if kind == "engine":                       # ללוג של הבדיקה העצמית יש מילים כמו ImportError — לא התראה חדשה
        return
    if job.get("ok") is False:
        job_failed_alerts(job)
    elif job.get("ok"):
        if kind in MODAL_KINDS:
            job_alert_clear("modal", "engine")
        if kind in ("prepare", "pick"):
            job_alert_clear("ytdlp")
    if kind == "pick":                         # 403/429 של Gemini נרשמים במונה המקומי — מציגים מיד (בלי בקשה)
        recheck(["gemini"], wait=wait)


def job_alert_clear(*kinds):
    if any(JOB_ALERTS.pop(k, None) for k in kinds):
        HEALTH_STATE["ver"] += 1


def precheck(kind):
    """ממש לפני עבודה: בודקים (ברקע, בשניות, בלי לעכב) את מה שהיא צריכה — כך ההתראה מופיעה לפני שההורדה נכשלת."""
    ids = []
    if kind in ("prepare", "pick"):
        ids.append("cookies")
    if kind == "pick":
        ids.append("gemini")
    if kind in MODAL_KINDS and SET.load().get("asr_engine", "modal") == "modal" and NET["ok"]:
        ids.append("modal")
    if ids:
        recheck(ids)


def health_watch():
    """כל ~30 דקות כשהתוכנה פתוחה — בדיקת מערכת מלאה (חינם: מקומיות + pypi/rclone/דוח Modal; בלי Gemini)."""
    while True:
        time.sleep(HEALTH_EVERY)
        try:
            refresh_health()
        except Exception as e:
            app_log("=== health watch: %s" % e)


def ytdlp_update_start():
    """"עדכן עכשיו" של yt-dlp: לחיצה שנייה בזמן שהעדכון רץ לא מתחילה עוד אחד — מחזירה את אותה עבודה."""
    for j in JOBS.values():
        if j["running"] and j["kind"] == "update":
            return j["id"]
    before = HEALTH.ytdlp_version()
    action_set("update_ytdlp", "running", "מעדכן… (כמה שניות)")
    cmd = [sys.executable, "-m", "pip", "install", "-U", "yt-dlp[default]"]
    if ENG.PINS.exists():                      # 29/10: yt-dlp חופשי, אבל התלויות שלו (requests…) נשארות בגרסה הטובה
        cmd += ["-c", str(ENG.PINS)]
    fake = os.environ.get("MAKE_SHORT_FAKE_YTDLP")
    if fake and MS.TEST_MODE:                  # בדיקות: "עדכון" שכותב גרסה חדשה לקובץ, בלי לגעת בסביבה האמיתית
        cmd = ["bash", "-c", "sleep 3; echo \"${FAKE_YTDLP_NEW:-2026.10.21}\" > \"$1\"", "x", fake]
    return start_job("update", cmd, title="עדכון yt-dlp", extra={"before": before})


def ytdlp_update_ended(job):
    """התוצאה במקום הכפתור ("עודכן ל-X ✓" או השגיאה), ובדיקת yt-dlp מחדש — כך ההתראה יורדת לבד."""
    after = HEALTH.ytdlp_version()
    if job.get("ok") and after:
        action_set("update_ytdlp", "ok", ("עודכן ל-%s ✓" % after) if after != job.get("before") else
                   "כבר בגרסה האחרונה (%s) ✓" % after)
        job_alert_clear("ytdlp")
    else:
        action_set("update_ytdlp", "fail", "העדכון נכשל: %s" % HEALTH.scrub(str(job.get("error") or ""))[:200])
    recheck(["ytdlp"])


# ─────────────── 29/10: מנוע התמלול — גרסה חדשה יותר + "נסה מנוע חדש יותר" ───────────────
# הספריות מוצמדות (requirements-pinned.txt). כשתמלול נכשל בשגיאה שנראית כמו של הספרייה ויש גרסה חדשה —
# התראה אדומה במסך העבודה עם הכפתור. אחרת, כשיש גרסה חדשה — הודעה שקטה, פעם בחודש לכל היותר, שאפשר לסגור.
ENGINE_RX = re.compile(r"faster_whisper|ctranslate2|onnxruntime|ModuleNotFoundError|ImportError|cannot import name|"
                       r"client version|no longer supported|please upgrade|VersionError|DeprecationError|"
                       r"AttributeError: module 'modal'", re.I)
ENGINE_STEPS = ["ללחוץ \"נסה מנוע חדש יותר\" — כמה דקות. אם החדש לא עובר בדיקה, הקודם חוזר לבד",
                "ואז \"🔁 נסה שוב\" בשיעור"]


def engine_res(fail_job=None, net=True):
    nw = ENG.newer(net=net)
    act = {"id": "engine_upgrade", "label": "נסה מנוע חדש יותר"}
    names = " · ".join("%s: %s במקום %s" % (n, b, a) for n, (a, b) in nw.items())
    if fail_job is not None:
        return HEALTH.res("engine", "bad", "התמלול נכשל — ויש גרסה חדשה יותר של מנוע התמלול",
                          "ייתכן שהגרסה החדשה פותרת את זה (%s). התוכנה שומרת את הנוכחית וחוזרת אליה לבד אם החדשה לא "
                          "עוברת בדיקה." % names, ENGINE_STEPS, act)
    if nw and ENG.note_due():
        r = HEALTH.res("engine", "note", "יש גרסה חדשה יותר של מנוע התמלול (%s)" % names,
                       "לא חובה — הנוכחית עובדת. אפשר לנסות; אם החדשה לא עוברת בדיקה, הקודמת חוזרת לבד.", [], act)
        r["dismiss"] = "engine_dismiss"
        return r
    cur = ENG.installed()
    return HEALTH.res("engine", "ok", "מנוע התמלול: " + " · ".join("%s %s" % kv for kv in cur.items()))


HEALTH.EXTRA["engine"] = engine_res


def engine_upgrade_start():
    for j in JOBS.values():
        if j["running"] and j["kind"] == "engine":
            return j["id"]
    if any(j["running"] for j in JOBS.values()) or queue_pending():
        raise ValueError("יש עבודה שרצה או ממתינה — אפשר לנסות את המנוע החדש כשהיא תסתיים")
    action_set("engine_upgrade", "running", "מתקין ובודק… (כמה דקות)")
    return start_job("engine", [sys.executable, "-u", str(HERE / "make_short_engine.py"), "upgrade"],
                     title="מנוע תמלול חדש יותר")


def engine_upgrade_ended(job):
    log = "\n".join(job.get("log") or [])
    if job.get("ok"):
        last = next((l for l in reversed(job.get("log") or []) if l.startswith(("✅", "✓"))), "עודכן ✓")
        action_set("engine_upgrade", "ok", last.lstrip("✅ "))
        job_alert_clear("engine")
    elif "↩" in log:
        action_set("engine_upgrade", "fail", "הגרסה החדשה לא עברה בדיקה — הוחזרה הקודמת, הכול כמו שהיה")
    else:
        action_set("engine_upgrade", "fail", "משהו השתבש בהחלפה — ללחוץ \"📋 העתק פרטים לעוזר\" ולשלוח לו: %s"
                   % HEALTH.scrub(str(job.get("error") or ""))[:160])
    recheck(["engine"])


# 22/10/2026 (כרטיס 14): מד Modal שמתרענן — 🔄 בדף, אחרי כל עבודה שהשתמשה ב-Modal, וכל ~10 דקות כשהחלון פתוח.
# רק השאלה ל-Modal (שנייה-שתיים), לא כל בדיקת המערכת. Modal עצמו מעדכן את הדוח באיחור של כמה דקות —
# לכן אחרי עבודה בודקים פעמיים: מיד, ושוב אחרי 4 דקות.
MODAL_METER = {"data": None, "at": "", "ts": 0.0, "running": False}
MODAL_KINDS = ("prepare", "retime", "pick")


def modal_meter_refresh():
    if MODAL_METER["running"] or not NET["ok"] or MS.TEST_MODE and os.environ.get("MAKE_SHORT_NO_MODAL_METER"):
        return False
    MODAL_METER["running"] = True

    def go():
        try:
            r = HEALTH.check_modal()
            if r.get("spent") is not None:     # 22/10: גם "היום" — מתקן את ההערכות של תקרת היום לפי מה ש-Modal רשם
                t = HEALTH.modal_today()
                if t is not None:
                    MD.set_billing(t)
            MODAL_METER.update(data=r, at=time.strftime("%H:%M"), ts=time.time())
            d = HEALTH_STATE.get("data")
            if d and isinstance(d.get("results"), list):     # שבדיקת המערכת תראה את אותו מספר
                d["results"] = [r if x.get("id") == "modal" else x for x in d["results"]]
        except Exception as e:
            app_log("=== modal meter: %s" % e)
        finally:
            MODAL_METER["running"] = False
    threading.Thread(target=go, daemon=True).start()
    return True


def modal_meter_view():
    v = {k: MODAL_METER[k] for k in ("data", "at", "ts", "running")}
    try:
        v["today"] = {k: x for k, x in MD.view().items() if k != "jobs"}    # "היום: $X מתוך $Y" בטולטיפ
    except Exception:
        v["today"] = None
    return v


HANDOFF = HERE.parent.parent / "docs" / "HANDOFF.md"


def _git(*args):
    try:
        return subprocess.run(["git", "-C", str(HERE.parent.parent)] + list(args), capture_output=True, text=True,
                              timeout=10).stdout.strip()
    except Exception:
        return ""


def _repo_url():
    """4.1.0: כתובת הריפו נקראת מהגיט המקומי (origin), לא כתובה בקוד — מי שקיבל חבילה לא מקבל את כתובת הריפו הפרטי של
    הבעלים. בלי origin (התקנה מחבילה) — ריק. מסיר פרטי התחברות מהכתובת, ו-git@host:a/b → https://host/a/b."""
    u = _git("remote", "get-url", "origin")
    m = re.match(r"^git@([^:]+):(.+?)(?:\.git)?$", u)
    if m:
        return "https://%s/%s" % m.group(1, 2)
    u = re.sub(r"^(https?://)[^/@]+@", r"\1", u)
    return re.sub(r"\.git$", "", u)


REPO_URL = _repo_url()


def tool_version():
    """16/11 (3.4): מקור אחד לגרסה — הקובץ VERSION בשורש הריפו (מוצג בחלון, בדוח לעוזר ובשם קובץ השיתוף)."""
    try:
        return (HERE.parent.parent / "VERSION").read_text(encoding="utf-8").strip() or "?"
    except OSError:
        return "?"


def assistant_header():
    """הראש של "העתק פרטים לעוזר": איפה הקוד, איפה המדריך, באיזו גרסה אנחנו. בלי שום סוד."""
    pkgs = []
    for name in ("faster-whisper", "modal", "numpy", "opencv-python-headless"):
        try:
            from importlib.metadata import version
            pkgs.append("%s %s" % (name, version(name)))
        except Exception:
            pkgs.append("%s (חסר)" % name)
    return ["=== פרטים לעוזר (אדם או בינה מלאכותית) שעוזר לתקן תקלה בכלי יצירת השורטס ===",
            "קוד: %s · ענף %s · גרסה %s (%s)" % ((REPO_URL + " (ריפו פרטי; ההרשאה אצל הבעלים)") if REPO_URL else "(אין כתובת ריפו — הקוד רק על המחשב)",
                                                _git("rev-parse", "--abbrev-ref", "HEAD"),
                                                                       tool_version(), _git("log", "-1", "--format=%h %cs %s")),
            "הקוד על המחשב: %s (בתוך WSL Ubuntu) · מדריך מלא לעוזר: %s (docs/HANDOFF.md)" % (HERE.parent.parent, HANDOFF),
            "הרצה: ~/yeshiva-shorts-skill/shorts.sh py <סקריפט>; ההגדרות ב-~/.config/yeshiva-shorts; הנתונים ב-~/.local/share/yeshiva-shorts",
            "גרסאות: python %s · %s · ffmpeg: %s" % (sys.version.split()[0], " · ".join(pkgs),
                                                   (subprocess.run([MS.FFMPEG, "-version"], capture_output=True, text=True).stdout.splitlines() or ["?"])[0][:60]),
            "הדוח הזה מנוקה ממפתחות. אל תבקשו מהמשתמש להדביק מפתחות או את config.env.", ""]


def report_text(job_id="", full=False):
    """"העתק פרטים לעוזר": ראש עם הקוד והגרסאות + מה נכשל + שורות אחרונות + בדיקת המערכת. בלי סודות (HEALTH.scrub).
    full=True מוסיף גם את כל docs/HANDOFF.md — לעוזר שאין לו גישה לריפו הפרטי."""
    lines = ["דוח תקלה — יצירת שורטס · %s" % time.strftime("%Y-%m-%d %H:%M"), ""]
    h = HEALTH_STATE.get("data")
    if h:
        lines.append("בדיקת מערכת (%s):" % h["at"])
        lines += ["  [%s] %s %s" % (r["level"], r["title"], r["detail"]) for r in h["results"]]
        lines.append("")
    j = JOBS.get(job_id) or next((j for j in reversed(list(JOBS.values())) if j["ok"] is False), None)
    if j:
        lines.append("עבודה: %s · %s · %s · התחילה %s · %s" % (j["kind"], j["title"], j["project"], j["started"],
                                                            "רצה" if j["running"] else ("הצליחה" if j["ok"] else "נכשלה")))
        lines += j["log"][-60:]
        lines.append("")
    try:
        tail = APP_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-40:]
        lines += ["יומן החלון (שורות אחרונות):"] + tail
    except OSError:
        pass
    lines.append("yt-dlp %s · python %s" % (HEALTH.ytdlp_version(), sys.version.split()[0]))
    out = "\n".join(assistant_header()) + "\n" + HEALTH.scrub("\n".join(lines))    # הראש לא מנוקה: הנתיבים הארוכים שלו אינם סוד
    if full:
        try:
            out += "\n\n=== docs/HANDOFF.md ===\n" + HANDOFF.read_text(encoding="utf-8")
        except OSError:
            out += "\n\n(docs/HANDOFF.md לא נמצא)"
    return out


def sample_frame():
    """פריים אמיתי מהקליף האחרון שנבנה (החלק העליון — שם יושבים הסמלים), כדי לראות את
    הסמלים על וילון/ארון קודש אמיתיים. אין עדיין קליף → רקע כהה כמו פעם."""
    best = None
    for f in TOOL.glob("*/" + MS.STATE) if TOOL.exists() else []:
        try:
            st = json.load(open(f, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for c in st.get("clips", []):
            v = f.parent / c.get("clean", "")
            if c.get("clean") and v.is_file() and (best is None or v.stat().st_mtime > best.stat().st_mtime):
                best = v
    return best


def logo_files():
    """הסמלים שאפשר לבחור: הלוגו הרגיל + כל PNG שהועלה (בתיקיית brand)."""
    out = []
    reg = os.environ.get("SHORTS_LOGO", "")
    if reg and os.path.exists(reg):
        out.append({"path": "", "name": "הלוגו הרגיל של הישיבה"})
    for f in sorted(BRAND.glob("*.png"), key=lambda f: f.stat().st_mtime, reverse=True) if BRAND.exists() else []:
        if os.path.realpath(f) != os.path.realpath(reg or "/nonexistent"):
            out.append({"path": str(f), "name": f.name})
    return out


def logo_image(path):
    """תמונה ממוזערת של סמל לרשימת הבחירה — רק קבצים מהרשימה, לא כל הדיסק."""
    ok = {x["path"] for x in logo_files()}
    if path not in ok:
        raise ValueError("קובץ לא מוכר")
    return Path(path or os.environ.get("SHORTS_LOGO", "")).read_bytes()


def logo_preview():
    """שתי הפינות (עם ההילה בגודל שנבחר לכל אחת) על פריים לדוגמה — לראות לפני שיוצרים שורט."""
    import build_clean_video as BCV
    logos = SET.logos()
    vid = sample_frame()
    base = (["-ss", "1", "-i", str(vid)] if vid else ["-f", "lavfi", "-i", "color=c=0x2a2724:s=1080x1920"])
    inputs = []
    for p, _, _ in logos:
        inputs += ["-i", p]
    top = "scale=1080:1920,crop=1080:560:0:0,scale=540:-1"
    if logos:
        fc = "[0:v]%s[b0];" % "scale=1080:1920" + BCV.logos_chain(logos, 1, "lo", "b0") + \
             ";[lo]crop=1080:560:0:0,scale=540:-1[o]"
    else:
        fc = "[0:v]%s[o]" % top
    r = subprocess.run([MS.FFMPEG, "-v", "error", *base, *inputs, "-filter_complex", fc, "-map", "[o]",
                        "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    if r.returncode:
        raise ValueError(r.stderr.decode(errors="replace")[-300:])
    return r.stdout


def music_payload():
    rows = MUSIC.listing()
    return {"tracks": rows, "summary": MUSIC.summary(rows)}


EXITS_BUSY, EXITS_FAILED = set(), set()


def clip_exits(p, c):
    """כרטיס 22 (28/10/2026): כמה שניות הרב מחוץ לקרופ, מהמדידה השמורה ליד הקליף (camera_path.py).
    קליפים שנבנו לפני הכרטיס (או שהמדידה שלהם ישנה) — נמדדים כאן ברקע, כמה שניות לקליף, בלי לגעת
    ב-make_short.json; הכרטיס מתעדכן בבדיקה הבאה של הדף. None = עוד לא ידוע / הבדיקה כבויה."""
    if not SET.load().get("camera_check") or not c.get("clean"):
        return None
    import camera_path as CP
    cam = c.get("camera") or "default"
    try:                                   # כרטיס 25: מצלמת הרב מהפרופיל שלו (המדידה נפסלת כשהפרופיל משתנה)
        rabbi = json.load(open(p / MS.STATE, encoding="utf-8")).get("rabbi") or ""
    except (OSError, ValueError):
        rabbi = ""
    d = CP.load_status(c["name"], cam, str(p), rabbi)
    if d:
        return CP.summary(d)
    raw = p / ("work/clips/%s_raw.mp4" % c["name"])
    key = (str(p), c["name"], cam)
    try:
        # באמצע בנייה (ה-raw כבר חדש, הנקי עוד לא) — מחכים שתסתיים; העבודה עצמה מודדת בסוף
        rt = raw.stat().st_mtime
        fresh = time.time() - rt < 10 or rt > (p / c["clean"]).stat().st_mtime
    except OSError:
        return None
    if key in EXITS_FAILED:
        return None
    if key not in EXITS_BUSY and not fresh:
        EXITS_BUSY.add(key)

        def work():
            try:
                r = subprocess.run([MS.PY, str(MS.HERE / "camera_path.py"), "status", c["name"], cam], cwd=str(p),
                                   env=dict(os.environ, **({"CAM_RABBI": rabbi} if rabbi else {})),
                                   capture_output=True, timeout=600)
                if r.returncode:
                    EXITS_FAILED.add(key)      # לא מנסים שוב בכל רענון (אין פנים / אין מודל) — רק אחרי הפעלה מחדש
            except Exception:
                EXITS_FAILED.add(key)
            finally:
                EXITS_BUSY.discard(key)
        threading.Thread(target=work, daemon=True).start()
    return {"pending": True}


# 4.2.0 — עדיפות לתצוגה מקדימה: היא (10–15 שניות) לא מחכה לצריבה ארוכה, וגם לא רצה *במקביל* אליה (שני קידודים יחד
# הפילו את WSL פעם). הצריבה שרצה מוקפאת (SIGSTOP לתהליך ולכל ילדיו, כלומר ffmpeg) בזמן התצוגה, וממשיכה (SIGCONT) מיד
# אחריה — תמיד, גם בשגיאה (finally), אחרי 3 דקות (שומר), ובפתיחה הבאה של השרת (pause_recover) אם השרת נפל באמצע.
# שים לב: הקפאה לא משחררת זיכרון — לכן לפני תצוגה בודקים MemAvailable.
HEAVY_PAUSE_KINDS = ("prepare", "finish", "retime", "restyle", "rebuild")
PAUSE = {"n": 0, "pids": [], "since": 0.0}
PAUSE_LOCK = threading.Lock()
PAUSE_FILE = PROJECTS.parent / ("paused_pids_test.json" if MS.TEST_MODE else "paused_pids.json")
PAUSE_MAX_SEC = 180


def _descendants(pid):
    kids = {}
    try:
        names = os.listdir("/proc")
    except OSError:
        return []
    for d in names:
        if d.isdigit():
            try:
                with open("/proc/%s/stat" % d) as f:
                    s = f.read()
                kids.setdefault(int(s.rsplit(")", 1)[1].split()[1]), []).append(int(d))
            except (OSError, ValueError, IndexError):
                pass
    out, stack = [], [int(pid)]
    while stack:
        for k in kids.get(stack.pop(), []):
            out.append(k)
            stack.append(k)
    return out


def _mem_avail_mb():
    try:
        for l in open("/proc/meminfo"):
            if l.startswith("MemAvailable:"):
                return int(l.split()[1]) // 1024
    except (OSError, ValueError):
        pass
    return 99999


def _signal_all(pids, sig):
    for p in pids:
        try:
            os.kill(int(p), sig)
        except OSError:
            pass


def pause_heavy():
    """לפני תצוגה מקדימה: מקפיא עבודה כבדה שרצה. תמיד מזוהה בזוג עם resume_heavy."""
    with PAUSE_LOCK:
        PAUSE["n"] += 1
        if PAUSE["n"] > 1:
            return
        jobs = [j for j in JOBS.values() if j["running"] and j.get("launched") and j.get("pid")
                and j["kind"] in HEAVY_PAUSE_KINDS]
        pids = []
        for j in jobs:
            pids += [j["pid"]] + _descendants(j["pid"])
        PAUSE.update(pids=pids, since=time.time(), jobs=[j["id"] for j in jobs])
        if pids:
            try:
                PAUSE_FILE.write_text(json.dumps({"pids": pids, "at": time.time()}), encoding="utf-8")
            except OSError:
                pass
            _signal_all(pids, signal.SIGSTOP)
            for j in jobs:
                j["paused"] = True


def resume_heavy(force=False):
    with PAUSE_LOCK:
        PAUSE["n"] = 0 if force else max(0, PAUSE["n"] - 1)
        if PAUSE["n"] > 0:
            return
        _signal_all(PAUSE.get("pids") or [], signal.SIGCONT)
        for jid in PAUSE.get("jobs") or []:
            if jid in JOBS:
                JOBS[jid].pop("paused", None)
        PAUSE.update(pids=[], jobs=[])
        try:
            PAUSE_FILE.unlink()
        except OSError:
            pass


def pause_recover():
    """בפתיחת השרת: אם הוא נפל כשעבודה הייתה קפואה — ממשיכים אותה (אחרת היא נשארת קפואה לנצח)."""
    try:
        d = json.loads(PAUSE_FILE.read_text(encoding="utf-8"))
        _signal_all(d.get("pids") or [], signal.SIGCONT)
        app_log("=== resumed %d frozen processes left by a crashed preview" % len(d.get("pids") or []))
        PAUSE_FILE.unlink()
    except (OSError, ValueError):
        pass


def pause_watch():
    while True:
        time.sleep(10)
        try:
            if PAUSE["n"] > 0 and time.time() - PAUSE["since"] > PAUSE_MAX_SEC:
                app_log("=== preview pause exceeded %ds — resuming" % PAUSE_MAX_SEC)
                resume_heavy(force=True)
        except Exception as e:
            app_log("=== pause watch: %s" % e)


def start_preview(d):
    """תצוגה מקדימה ברקע (make_short.py preview) — מחזיר מזהה; הדף שואל עד שהקובץ מוכן."""
    p, st = load_state(d["project"])
    c = next(c for c in st["clips"] if c["name"] == d["clip"])
    info = {}
    if d["kind"] == "music":
        if "track" not in c:
            try:
                c["track"] = json.load(open(final_dir(p, c["name"]) / "meta.json", encoding="utf-8")).get("music")
            except (OSError, ValueError, TypeError):
                c["track"] = None
        if d.get("mode") == "keep":                # 22/10: רק עוצמה — אותה מנגינה של הקליף
            if not c.get("track"):
                raise ValueError("בקליף הזה אין מוזיקה")
            track = MS.track_by_uuid(c["track"]["uuid"])
        else:
            track, _, _ = MS.resolve_music(c, d.get("mode") or "swap", d.get("uuid") or "")
        arg = track["uuid"] if track else "off"
        info = {"uuid": track["uuid"] if track else "", "title": track["title"] if track else ""}
        db = d.get("db")
        db = int(c.get("music_db") or 0) if db in (None, "") else max(SET.CLIP_DB[0], min(SET.CLIP_DB[1], int(db)))
        info["db"] = db
    elif d["kind"] == "camera":
        arg = d.get("camera") or "smooth"
        if arg not in MS.CAMERAS:
            raise ValueError("מצלמה לא מוכרת")
    elif d["kind"] == "subs":                       # 30/10: תצוגה אמיתית (libass) של מרקר / ריחוף
        arg = str(d.get("color") or "").upper()
        if not SET.valid_choice(arg):
            raise ValueError("סגנון לא תקין")
    else:
        raise ValueError("סוג תצוגה לא מוכר")
    extra = ["--db=%d" % info["db"]] if d["kind"] == "music" and arg != "off" else []
    if d["kind"] == "subs":
        cfg = SET.load()
        if d.get("emph") in ("on", "off"):
            extra.append("--emph=" + d["emph"])
        info["sig"] = json.dumps([cfg.get("marker_opacity"), cfg.get("marker_text"), SET.float_shadow(cfg),
                                  cfg.get("box_color"), cfg.get("box_opacity")], sort_keys=True)   # הגדרות שמשנות את הציור
    if d["kind"] == "camera" and d.get("at"):
        # 28/10 (כרטיס 22): "לפני | אחרי" סביב הרגע שבו הרב יוצא מהמסגרת — זמן ה-raw בתוך המפתח,
        # כדי שבנייה מחדש של הקליף לא תחזיר תצוגה ישנה
        extra = ["--at=%.1f" % float(d["at"])]
        info["sbs"] = True
        try:
            info["raw"] = int(os.stat(p / ("work/clips/%s_raw.mp4" % c["name"])).st_mtime)
        except OSError:
            pass
    key = (str(p), c["name"], d["kind"], arg, *extra, SET.load()["music_level"], info.get("raw"), info.get("sig"))
    for pid, pv in PREVIEWS.items():
        if pv["key"] == key and (pv["running"] or pv["ok"]):
            if pv["running"] or Path(pv.get("file", "")).exists():
                return preview_view(pid)
    prune_previews()
    pid = str(next(PREV_IDS))
    PREVIEWS[pid] = pv = {"key": key, "running": True, "ok": None, "error": "", "file": "", "started": time.time(), **info}

    def work():
        pause_heavy()                               # 4.2.0: עדיפות — הצריבה שרצה מוקפאת עד שהתצוגה מוכנה
        try:
            for _ in range(20):                     # הקפאה לא משחררת זיכרון: מחכים עד 40 שניות לזיכרון פנוי
                if _mem_avail_mb() >= 800:
                    break
                time.sleep(2)
            r = subprocess.run(ms_cmd("preview", p, c["name"], d["kind"], arg, *extra), capture_output=True, text=True,
                               errors="replace")
        finally:
            resume_heavy()
        f = next((l[5:].strip() for l in r.stdout.splitlines() if l.startswith("FILE=")), "")
        pv["ok"] = r.returncode == 0 and bool(f)
        pv["file"] = f
        lines = (r.stdout + r.stderr).strip().splitlines()
        pv["error"] = "" if pv["ok"] else "\n".join(lines[-4:])[-400:] or "נכשל"
        pv["secs"] = round(time.time() - pv["started"], 1)
        pv["running"] = False
    threading.Thread(target=work, daemon=True).start()
    return preview_view(pid)


PREVIEW_KEEP_SEC = 3600


def prune_previews(now=None, keep_sec=PREVIEW_KEEP_SEC):
    """31/10/2026 (Gemini review): PREVIEWS and the preview mp4s under <lesson>/work/preview/ were never cleaned. Drops finished
    entries nobody has looked at for an hour (never a running one; "seen" is refreshed whenever a page polls the entry or streams
    its file) and deletes their mp4 - a generated cache rebuilt on demand (the file name is deterministic), so no Recycle Bin.
    Safe by construction: only a file directly inside a folder named "preview" under "work", and never one a kept entry uses."""
    now = time.time() if now is None else now
    dead = [pv for pv in PREVIEWS.values()
            if not pv["running"] and now - max(pv.get("seen", 0), pv.get("started", 0)) > keep_sec]
    for pid in [pid for pid, pv in PREVIEWS.items() if any(pv is d for d in dead)]:
        del PREVIEWS[pid]
    used = {str(pv.get("file")) for pv in PREVIEWS.values() if pv.get("file")}
    n = 0
    for pv in dead:
        f = pv.get("file")
        if not f or str(f) in used:
            continue
        f = Path(f)
        if f.parent.name == "preview" and f.parent.parent.name == "work" and f.suffix == ".mp4" and f.is_file():
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
    return n


def preview_view(pid):
    pv = PREVIEWS[pid]
    pv["seen"] = time.time()
    return {k: pv.get(k) for k in ("running", "ok", "error", "uuid", "title", "secs", "db")} | {"id": pid}   # sig פנימי


NET = {"ok": True, "at": 0.0}
# 22/10/2026 (כרטיס 13): הגיבוי לדרייב — עובד רקע אחד לכל תיקיית השורטס. שמירה/ויתור רק מסמנים
# "ממתין" (MS.mark_drive_pending); כאן מגבים DRIVE_DEBOUNCE שניות אחרי השינוי האחרון (כמה שמירות
# ברצף = גיבוי אחד), מיד בפתיחה אם נשאר משהו מפעם קודמת, ומיד כשהאינטרנט חוזר. אותו מנגנון גם לתור
# "בלי אינטרנט" של שלב 9 — אין שני מנגנונים. אף פעם לא מודיעים על גיבוי שהצליח (בקשתו, 18/10).
DRIVE_DEBOUNCE = int(os.environ.get("MAKE_SHORT_DRIVE_DEBOUNCE", "90"))
DRIVE_RETRY = int(os.environ.get("MAKE_SHORT_DRIVE_RETRY", "300"))       # אחרי כישלון — ניסיון חוזר לבד
DRIVE_BOOT_DELAY = 15                                                     # בפתיחה: שהחלון יעלה קודם
DRIVE_Q = {"running": False, "started": 0.0, "last_try": 0.0, "last_error": "", "kick": False,
           "boot": time.time(), "closing": False}


def net_watch():
    """21/10: בדיקת אינטרנט זולה כל 20 שניות (חיבור קצר, בלי הורדה). בלי אינטרנט — עורכים ומסיימים;
    הורדה, תמלול ובחירה מחכים. הגיבוי שממתין — drive_watch מעלה אותו כשהחיבור חוזר."""
    while True:
        was = NET["ok"]
        NET["ok"], NET["at"] = MS.net_ok(), time.time()
        if NET["ok"] and not was:
            DRIVE_Q["kick"] = True                     # חזר האינטרנט — הגיבוי שחיכה עולה עכשיו
        time.sleep(20)


def drive_due(pend):
    """האם להתחיל גיבוי עכשיו (ומה מונע)."""
    now = time.time()
    if DRIVE_Q["kick"]:
        return True
    if DRIVE_Q["last_error"] and now - DRIVE_Q["last_try"] < DRIVE_RETRY:
        return False
    last = float(pend.get("last_change") or 0)
    if last < DRIVE_Q["boot"]:                         # נשאר מפעם קודמת — בפתיחה
        return now - DRIVE_Q["boot"] >= DRIVE_BOOT_DELAY
    return now - last >= DRIVE_DEBOUNCE


def drive_watch():
    while True:
        time.sleep(3)
        try:
            pend = MS.drive_pending()
            if not pend or DRIVE_Q["running"] or DRIVE_Q["closing"] or not SET.load()["drive_on"]:
                continue
            if OWN_KEY["active"]:                      # 4.1.0: באמצע החלפת מפתח הדרייב — הגיבוי מחכה (לא נכשל ולא נרשם)
                continue
            if MS.drive_cmd()[0] is None or not NET["ok"]:
                continue
            # שמירה/ויתור כותבים לתיקיית השורטס עכשיו — מחכים שיסיימו (שנייה-שתיים), ואז מגבים הכול
            if any(j["running"] and j.get("launched", True) and j["kind"] in ("save", "drop_saved", "clean") for j in JOBS.values()):
                continue
            if not drive_due(pend):
                continue
            DRIVE_Q.update(running=True, started=time.time(), last_try=time.time(), kick=False)

            def go():
                try:
                    ok, why = MS.run_drive_backup()
                    if ok is None:                     # גיבוי ידני כבר רץ — לא כישלון, ננסה שוב בעוד דקה
                        DRIVE_Q["last_try"] = time.time() - DRIVE_RETRY + 60
                        DRIVE_Q["last_error"] = ""
                    else:
                        DRIVE_Q["last_error"] = "" if ok else why
                    app_log("=== %s drive backup: %s" % (time.strftime("%H:%M:%S"), "ok" if ok else why))
                finally:
                    DRIVE_Q["running"] = False
            threading.Thread(target=go, daemon=True).start()
        except Exception as e:                         # העובד לא מת בגלל קובץ שבור
            app_log("=== drive watch error: %s" % e)


def drive_view():
    """המחוון בפס העליון: ok · running · pending (N) · failed · off · test."""
    if not SET.load()["drive_on"]:
        return {"state": "off"}
    if MS.drive_cmd()[0] is None:
        return {"state": "test"}
    pend, st = MS.drive_pending(), MS.drive_status()
    out = {"n": int(pend.get("n", 0)) if pend else 0, "since": pend.get("since", "") if pend else "",
           "last_ok": st.get("last_ok", ""), "error": "", "fail_since": "", "net": NET["ok"]}
    if DRIVE_Q["running"]:
        return dict(out, state="running", secs=int(time.time() - DRIVE_Q["started"]))
    if pend:
        err = DRIVE_Q["last_error"] or st.get("error", "")
        if err:
            return dict(out, state="failed", error=err, fail_since=st.get("fail_since", ""),
                        retry_in=max(0, int(DRIVE_RETRY - (time.time() - DRIVE_Q["last_try"]))) if DRIVE_Q["last_try"] else 0)
        last = float(pend.get("last_change") or 0)
        wait = DRIVE_BOOT_DELAY if last < DRIVE_Q["boot"] else DRIVE_DEBOUNCE - (time.time() - last)
        return dict(out, state="pending", eta=max(0, int(wait)))
    return dict(out, state="ok")


# ─────────────── 16/11 (3.4): גיבוי "גיבוי תוכנה" פעם ביום — הגדרות, מוזיקה, לוגו, הנחיות, זיכרון Claude ───────────────
# עד היום backup_extras.sh רץ רק ביד (ובהתקנה — restore). עכשיו פעם ביום ברקע, בשקט; התראה רק אם נכשל יותר מיום.
EXTRAS_STATUS = MS.DATA_DIR / "backup_extras_status.json"
EXTRAS_EVERY = 24 * 3600
EXTRAS_RETRY = 3600
EXTRAS_Q = {"running": False}
EXTRAS_TIMEOUT = 2 * 3600


def extras_status():
    try:
        return json.load(open(EXTRAS_STATUS, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def extras_run():
    """מריץ backup_extras.sh backup ורושם תוצאה. (ok, why)."""
    st = extras_status()
    st["last_try"] = time.time()
    # 4.1.0: תהליך משלו (קבוצת תהליכים) — בפסק זמן נהרגים גם rclone ו-bash שהוא הפעיל, לא רק ה-bash
    p = subprocess.Popen(["bash", str(MS.SH / "backup_extras.sh"), "backup"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         text=True, cwd=str(MS.SH), start_new_session=True)
    try:
        out, err = p.communicate(timeout=EXTRAS_TIMEOUT)
        if p.returncode == 75:                         # הרצה אחרת (ידנית) כבר באמצע — לא כישלון, ננסה שוב בעוד שעה
            return True, ""
        ok, why = p.returncode == 0, HEALTH.scrub((err or out or "").strip()[-300:])
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, 9)                       # SIGKILL לכל הקבוצה
        except OSError:
            pass
        try:
            p.communicate(timeout=30)
        except Exception:
            pass
        ok, why = False, "הגיבוי לא הסתיים בתוך שעתיים"
    if ok:
        st.update(last_ok=time.time(), error="", fail_since=0)
    else:
        st.update(error=why or "נכשל", fail_since=st.get("fail_since") or time.time())
    tmp = EXTRAS_STATUS.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    tmp.replace(EXTRAS_STATUS)
    app_log("=== %s extras backup: %s" % (time.strftime("%H:%M:%S"), "ok" if ok else why))
    return ok, why


def extras_watch():
    time.sleep(120)                                    # שהחלון והגיבוי הרגיל יעלו קודם
    while True:
        try:
            st, now = extras_status(), time.time()
            due = now - float(st.get("last_ok") or 0) >= EXTRAS_EVERY and now - float(st.get("last_try") or 0) >= EXTRAS_RETRY
            if (due and not MS.TEST_MODE and not EXTRAS_Q["running"] and not DRIVE_Q["running"] and NET["ok"]
                    and not DRIVE_Q["closing"] and not OWN_KEY["active"] and SET.load()["drive_on"]):
                EXTRAS_Q["running"] = True
                try:
                    extras_run()
                finally:
                    EXTRAS_Q["running"] = False
        except Exception as e:                         # העובד לא מת בגלל קובץ שבור
            app_log("=== extras watch error: %s" % e)
        time.sleep(600)


def extras_health():
    """שקט כל עוד הגיבוי היומי מצליח; אזהרה רק כשהוא נכשל יותר מיום (כמו הגיבוי לדרייב)."""
    if not SET.load()["drive_on"]:
        return HEALTH.res("extras", "ok", "גיבוי ההגדרות לדרייב כבוי (עם הגיבוי לדרייב)")
    st = extras_status()
    fs = float(st.get("fail_since") or 0)
    if fs and time.time() - fs > 86400:
        return HEALTH.res("extras", "warn", "גיבוי ההגדרות והזיכרון לדרייב נכשל כבר יותר מיום",
                          "השורטסים עצמם מגובים בנפרד. מה שלא מגובה עכשיו: ההגדרות, המוזיקה, הלוגו והזיכרון של Claude "
                          "(תיקייה \"גיבוי תוכנה\" בדרייב). " + (st.get("error") or "")[:200],
                          ["לבדוק שהגיבוי לדרייב מחובר (אם לא — \"חבר מחדש את הדרייב\")",
                           "אם זה נמשך — ללחוץ \"📋 העתק פרטים לעוזר\" ולשלוח"])
    when = time.strftime("%d/%m %H:%M", time.localtime(float(st["last_ok"]))) if st.get("last_ok") else "עוד לא רץ"
    return HEALTH.res("extras", "ok", "גיבוי ההגדרות והזיכרון לדרייב (פעם ביום) · אחרון: %s" % when)


HEALTH.EXTRA["extras"] = extras_health


def drive_now():
    """"☁ … — לנסות שוב" / "גבה עכשיו": מגבה עכשיו (גם אם אין שינוי — בודק שהדרייב תואם)."""
    if not MS.drive_pending():
        MS.mark_drive_pending("גיבוי ידני מהחלון")
    DRIVE_Q.update(kick=True, last_error="")
    return drive_view()


def need_net(what):
    if not NET["ok"] and not MS.net_ok():
        raise ValueError("אין אינטרנט — בשביל %s צריך חיבור. אפשר להמשיך לערוך ולסיים שיעורים שכבר הוכנו." % what)


def source_audio(p, a, b):
    """קטע שמע מהשיעור (לשמיעת הפתיחה/הסוף החדשים בגרירה) — wav קטן, עד 20 שניות."""
    a, b = float(a), float(b)
    if not 0 < b - a <= 20.5:
        raise ValueError("קטע לא תקין")
    r = subprocess.run([MS.FFMPEG, "-v", "error", "-ss", "%.2f" % max(0, a), "-t", "%.2f" % (b - a), "-i",
                        str(p / "source/full_video.mp4"), "-vn", "-ac", "1", "-ar", "22050", "-f", "wav", "-"],
                       capture_output=True)
    if r.returncode:
        raise ValueError("לא הצלחתי לחתוך את השמע")
    return r.stdout


def idle_watch(srv):
    """יוצא כשאין דף פתוח IDLE_EXIT שניות ואין שום עבודה (גם לא בתור). באמצע עבודה — לעולם לא."""
    while True:
        time.sleep(5)
        if ALIVE["open"] > 0:
            ALIVE["last"] = time.time()
            DRIVE_Q["closing"] = False
            continue
        working = any(j["running"] for j in JOBS.values()) or queue_pending() or \
            any(p["running"] for p in PREVIEWS.values()) or \
            any(v.get("until") is not None for v in list(EDITOR["view"].values()) + list(PICKHOLD["view"].values()))
        # ↑ העורך / הבחירה מחכים לשליחה משותפת (עם סוף ידוע)
        # (בדיקת המערכת לא נחשבת — אין מה לאבד בה)
        if working:
            ALIVE["last"] = time.time()
            DRIVE_Q["closing"] = False
            continue
        # גיבוי לדרייב לא מחזיק את התוכנה פתוחה לנצח: עד 2 דקות אחרי הזמן, ומה שנשאר — בפתיחה הבאה
        over = time.time() - ALIVE["last"] - IDLE_EXIT
        if over > 0 and DRIVE_Q["running"] and over < 120:
            DRIVE_Q["closing"] = True          # גיבוי באמצע — מחכים לו עד 2 דקות, ולא מתחילים חדש
            continue
        DRIVE_Q["closing"] = over > 0
        if over > 0:
            print("\n  החלון של התוכנה נסגר — נסגר גם כאן. להפעלה מחדש: הקיצור \"יצירת שורטס\".", flush=True)
            app_log("=== %s idle exit" % time.strftime("%Y-%m-%d %H:%M:%S"))
            threading.Thread(target=srv.shutdown, daemon=True).start()
            return


OPEN_HINT = ("אם הדפדפן לא נפתח לבד — להעתיק את הקישור (בחלון: לסמן אותו בעכבר, ואז קליק ימני — "
             "לא Ctrl+C, זה עוצר), ולהדביק בכרום")


def browser_shim_lines():
    """4.0.4: שורות לראש סקריפט של חלון שחור — פותח-דפדפן של ווינדוס בראש ה-PATH וב-BROWSER (rclone ו-Modal
    מכבדים אחד מהם), והסבר מה לעשות אם בכל זאת לא נפתח. ב-WSL של הבעלים אין xdg-open בכלל (16/11)."""
    data = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))
    shim = data / "bin" / "xdg-open"
    src = Path(__file__).resolve().parents[2] / "setup" / "wsl_open.sh"
    try:                                       # נוצר / מתעדכן לפי הצורך (גם אצל מי שהתקין לפני 4.0.4)
        if src.is_file() and (not shim.is_file() or shim.read_bytes() != src.read_bytes()):
            shim.parent.mkdir(parents=True, exist_ok=True)
            shim.write_bytes(src.read_bytes())
            os.chmod(shim, 0o755)
    except OSError as e:
        app_log("=== browser shim: %s" % e)
    q = shlex.quote
    return ("export PATH=%s:\"$HOME/.local/bin:$PATH\"\nexport BROWSER=%s\necho %s\necho\n"
            % (q(str(shim.parent)), q(str(shim)), q(OPEN_HINT)))


def rclone_busy():
    """4.0.5: חלון שחור עם rclone שעוד מחכה לאישור (reconnect / create) — לא מחזירים הגדרות מתחת לרגליו."""
    try:
        return subprocess.run(["pgrep", "-f", "rclone config (reconnect|create) gdrive"],
                              capture_output=True, timeout=10).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


OWN_KEY = {"lock": threading.Lock(), "active": False}      # 4.1.0: נעילה סביב ההכנה + דגל "ניסיון מפתח אישי פעיל"


def backup_running():
    """4.1.0: האם גיבוי (שורטסים או הגדרות) רץ עכשיו — בתוכנה או ידנית. מחליפים הגדרות rclone רק כשאין."""
    if DRIVE_Q["running"] or EXTRAS_Q["running"]:
        return True
    try:
        return subprocess.run(["pgrep", "-f", r"(drive_backup|backup_extras)\.sh"], capture_output=True, timeout=10).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def own_key_startup():
    """4.0.5, בפתיחת השרת: ניסיון "מפתח אישי" שנקטע (Ctrl+C / חלון שנסגר / שרת שנסגר באמצע) → החיבור הקודם חוזר.
    אם חלון שחור עוד רץ — מחכים שייסגר (עד חצי שעה) ואז מחליטים. שום ערך לא נכתב ליומן."""
    def go():
        try:
            for _ in range(90):
                conf = HEALTH.rclone_conf()
                if conf and HEALTH.own_key_paths(conf)["pending"].exists():
                    OWN_KEY["active"] = True           # גיבוי ברקע מושהה כל עוד יש ניסיון פתוח
                st = HEALTH.own_key_recover(conf, busy=rclone_busy())
                if st != "busy":
                    if st in ("restored", "done"):
                        app_log("=== %s drive own key: %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), st))
                        if st == "restored":
                            action_set("drive_reconnect", "fail", HEALTH.INTERRUPTED)
                        recheck(["drive"])
                    return
                time.sleep(20)
        finally:
            if not OWN_KEY["lock"].locked() and (HEALTH_STATE.get("actions", {}).get("drive_reconnect") or {}).get("state") != "running":
                OWN_KEY["active"] = False
    threading.Thread(target=go, daemon=True).start()


SAFE_ARG = re.compile(r"[A-Za-z0-9_./:@+=,-]+")
RECONNECT_TRIES, RECONNECT_PAUSE = 4, 6          # 4.1.0: כמה פעמים לבדוק שהדרייב עונה אחרי חיבור שהסתיים (בדיקות מקצרות)


def launch_black_window(sh):
    """חלון שחור בווינדוס שמריץ סקריפט bash. cmd.exe מפרש בעצמו רווחים ו-& ^ % ( ) — לכן הנתיב שמגיע אליו חייב להיות
    "בטוח"; אם הוא לא (תיקיית נתונים עם רווח, למשל) — הסקריפט מועתק לנתיב בטוח ב-/tmp (4.1.0)."""
    p = str(sh)
    if not SAFE_ARG.fullmatch(p):
        safe = Path("/tmp") / ("ys_win_%s.sh" % uuidlib.uuid4().hex[:10])
        shutil.copyfile(p, safe)
        p = str(safe)
    distro = os.environ.get("WSL_DISTRO_NAME", "Ubuntu")
    if not SAFE_ARG.fullmatch(distro):
        distro = "Ubuntu"
    subprocess.Popen(["/mnt/c/Windows/System32/cmd.exe", "/c", "start", "", "wsl.exe", "-d", distro, "--", "bash", p],
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd="/mnt/c")


def drive_reconnect(on_fail=None, on_ok=None, is_connected=None, on_end=None):
    """חלון שחור בווינדוס שמריץ את חיבור הדרייב מחדש (rclone מבקש אישור בדפדפן).
    on_fail (16/11/2026, מפתח אישי): מה לעשות אם החיבור לא הצליח — מחזירים את ההגדרות הקודמות.
    on_ok (4.0.5): rclone סיים ב-0 והדרייב עונה — מסמנים שהחיבור האישי הושלם (לפני הבדיקה, כדי שתהיה ירוקה).
    is_connected (4.1.0): האם בהגדרות כבר יש טוקן חדש. אם כן — לא מחזירים את הגדרות העבר לעולם, גם אם הבדיקה נפלה
    (רשת שנפלה לרגע לא מבטלת חיבור שעבד). on_end: נקרא בכל יציאה (מסיר את דגל "ניסיון פעיל")."""
    # הפקודה בקובץ ולא בשורת הפקודה: cmd.exe מפרש בעצמו ; > ' ונתקע (נבדק 20/10)
    # 22/10: כש-rclone מסיים הוא כותב קובץ "סיימתי" — והתוכנה בודקת את הדרייב מיד ומעדכנת את ההתראה (בלי "בדוק שוב")
    # 4.1.0: שם ייחודי לכל ניסיון (חלון שחור ישן שנסגר מאוחר כותב לקובץ הישן שלו, לא לניסיון חדש)
    PROJECTS.parent.mkdir(parents=True, exist_ok=True)
    for old in list(PROJECTS.parent.glob("drive_reconnect*.done")) + list(PROJECTS.parent.glob("drive_reconnect*.sh")):
        old.unlink(missing_ok=True)
    attempt = uuidlib.uuid4().hex[:8]
    sh = PROJECTS.parent / ("drive_reconnect_%s.sh" % attempt)
    done = PROJECTS.parent / ("drive_reconnect_%s.done" % attempt)
    # 4.0: מקבל שעוד לא חיבר דרייב בכלל (אין gdrive:) — יוצרים את החיבור, כמו בהתקנה (scope drive.file)
    sh.write_text("#!/bin/bash\n" + browser_shim_lines() +
                  "if rclone listremotes 2>/dev/null | grep -qx 'gdrive:'; then rclone config reconnect gdrive:\n"
                  "else rclone config create gdrive drive scope drive.file; fi\n"
                  "echo $? > %s\necho\nread -p 'Done - press Enter to close' x\n" % shlex.quote(str(done)), encoding="utf-8")
    if os.environ.get("MAKE_SHORT_FAKE_RECONNECT"):          # בדיקות: בלי חלון — כאילו rclone הצליח
        done.write_text(os.environ["MAKE_SHORT_FAKE_RECONNECT"])
    else:
        launch_black_window(sh)
    action_set("drive_reconnect", "running", "ממתין לחלון השחור — לאשר בדפדפן ואז Enter")

    def finish():
        for f in (sh, done):
            f.unlink(missing_ok=True)
        if on_end:
            on_end()

    def wait():
        try:
            _wait()
        finally:
            if not (on_fail and rclone_busy()):                 # חלון שחור עוד פתוח — own_key_startup ממשיך לטפל
                finish()
            elif on_end:
                on_end()

    def _wait():
        for _ in range(900):                                  # עד רבע שעה
            if done.exists():
                rc = done.read_text().strip()
                verified = connected = False
                if on_ok and rc == "0":
                    for i in range(RECONNECT_TRIES):          # 4.1.0: נפילת רשת רגעית (או 40 שניות איטיות) לא מבטלת חיבור
                        if not HEALTH._run([HEALTH.RCLONE, "lsf", "gdrive:", "--max-depth", "1", "--dirs-only"], 40)[0]:
                            verified = True
                            break
                        if i + 1 < RECONNECT_TRIES:
                            time.sleep(RECONNECT_PAUSE)
                    connected = verified or bool(is_connected and is_connected())
                    if connected:
                        on_ok()
                recheck(["drive"], wait=True)
                r = next((x for x in (HEALTH_STATE["data"] or {}).get("results", []) if x.get("id") == "drive"), {})
                if connected and not verified:
                    action_set("drive_reconnect", "fail", "מחובר, הבדיקה נכשלה — לנסות שוב (כנראה בעיית אינטרנט רגעית). "
                               "החיבור החדש נשמר ולא הוחזר כלום")
                elif r.get("level") == "bad" or (on_fail and rc != "0"):
                    if on_fail:
                        on_fail()
                        action_set("drive_reconnect", "fail", "החיבור עם המפתח האישי לא הצליח — החיבור הקודם "
                                   "הוחזר והגיבוי ממשיך כרגיל. אפשר לבדוק את השלבים ולנסות שוב")
                    else:
                        action_set("drive_reconnect", "fail", "החיבור לא הצליח%s — לנסות שוב" % ("" if rc == "0" else " (rclone: %s)" % rc))
                else:
                    action_set("drive_reconnect", "ok", "הדרייב מחובר ✓")
                    if MS.drive_pending():                    # מה שחיכה לגיבוי עולה עכשיו
                        DRIVE_Q.update(kick=True, last_error="")
                return
            time.sleep(1)
        if on_fail and rclone_busy():
            # 4.0.5: החלון השחור עוד פתוח — אם נחזיר עכשיו, rclone יכתוב טוקן חדש לתוך ההגדרות הישנות.
            # ההחלטה נדחית: own_key_startup מחכה שהחלון ייסגר ואז מחזיר (או מסמן שהושלם)
            action_set("drive_reconnect", "fail", "החלון השחור עדיין פתוח — לסיים בו (Enter), או לסגור אותו; "
                       "אם נקטע, החיבור הקודם יחזור לבד")
            own_key_startup()
            return
        if on_fail:
            on_fail()
        action_set("drive_reconnect", "fail", "החלון השחור לא סיים תוך רבע שעה — אפשר ללחוץ שוב")
    threading.Thread(target=wait, daemon=True).start()


def modal_connect():
    """4.0 ("🧭 צעדים ראשונים"): חלון שחור שמריץ `modal token new` — אותו צעד כמו בהתקנה (שלב 7). Modal מדפיס
    קישור / פותח דפדפן, מאשרים שם, והטוקן נשמר אצל Modal עצמו (לא נקרא ולא מודפס כאן). בסוף — בודקים את Modal מיד."""
    cur = (HEALTH_STATE.get("actions") or {}).get("modal_connect") or {}
    if cur.get("state") == "running" and time.time() - cur.get("ts", 0) < 900:
        return
    sh = PROJECTS.parent / "modal_connect.sh"
    done = PROJECTS.parent / "modal_connect.done"
    try:
        done.unlink()
    except OSError:
        pass
    sh.write_text("#!/bin/bash\n" + browser_shim_lines() +
                  "echo 'Modal: a link will open (or be printed) - sign in and approve, then come back here.'\n"
                  "%s token new\necho $? > %s\necho\nread -p 'Done - press Enter to close' x\n"
                  % (shlex.quote(str(HEALTH.MODAL)), shlex.quote(str(done))),
                  encoding="utf-8")
    if os.environ.get("MAKE_SHORT_FAKE_RECONNECT"):          # בדיקות: בלי חלון
        done.write_text(os.environ["MAKE_SHORT_FAKE_RECONNECT"])
    else:
        launch_black_window(sh)
    action_set("modal_connect", "running", "ממתין לחלון השחור — לאשר בדפדפן")

    def wait():
        for _ in range(900):
            if done.exists():
                recheck(["modal"], wait=True)
                r = next((x for x in (HEALTH_STATE["data"] or {}).get("results", []) if x.get("id") == "modal"), {})
                action_set("modal_connect", "ok" if r.get("level") != "bad" else "fail",
                           "Modal מחובר ✓" if r.get("level") != "bad" else "Modal עדיין לא מחובר — אפשר לנסות שוב")
                return
            time.sleep(1)
        action_set("modal_connect", "fail", "החלון השחור לא סיים תוך רבע שעה — אפשר ללחוץ שוב")
    threading.Thread(target=wait, daemon=True).start()


def drive_own_key(cid, sec):
    """16/11/2026 (בקשתו: לתקן את "המפתח המשותף" בלי עזרה): מפתח גוגל אישי לגיבוי.
    שומרים עותק של הגדרות rclone, כותבים client_id/secret (+ scope=drive — כדי שהמפתח החדש יראה את
    התיקייה שהמפתח הישן יצר), ומריצים את החיבור מחדש. לא הצליח → העותק חוזר, הגיבוי ממשיך כמו קודם.
    הסוד לא מודפס ולא נכתב ליומן; הפלט של rclone נזרק."""
    cid, sec = cid.strip(), sec.strip()
    if not re.fullmatch(r"[0-9]+-[0-9A-Za-z_]+\.apps\.googleusercontent\.com", cid):
        raise ValueError("ה-Client ID לא נראה נכון — הוא נגמר ב-.apps.googleusercontent.com (להעתיק שוב מגוגל)")
    if not re.fullmatch(r"[0-9A-Za-z_\-]{10,100}", sec):
        raise ValueError("ה-Client secret לא נראה נכון (בדרך כלל מתחיל ב-GOCSPX-) — להעתיק שוב מגוגל")
    # 4.1.0: נעילה סביב כל ההכנה — שתי קריאות כמעט בו-זמנית (לשונית שנייה, לחיצה כפולה) לא דורסות זו את העותק של זו
    if not OWN_KEY["lock"].acquire(blocking=False):
        raise ValueError("החיבור כבר מתחיל — לחכות רגע ולא ללחוץ פעמיים")
    launched = False
    try:
        cur = (HEALTH_STATE.get("actions") or {}).get("drive_reconnect") or {}
        if cur.get("state") == "running" or OWN_KEY["active"]:
            raise ValueError("חיבור הדרייב כבר באמצע — לסיים אותו בחלון השחור קודם")
        if backup_running():                          # 4.1.0: גיבוי באמצע קורא את ההגדרות — לא מחליפים אותן מתחתיו
            raise ValueError("גיבוי לדרייב רץ עכשיו — לחכות שיסתיים (דקה-שתיים) ולנסות שוב")
        rc, out = HEALTH._run([HEALTH.RCLONE, "config", "file"], 15)
        conf = Path(out.strip().splitlines()[-1].strip()) if not rc and out.strip() else None
        if not conf or not conf.is_file():
            raise ValueError("לא מצאתי את הגדרות הגיבוי במחשב — ללחוץ קודם \"חבר מחדש את הדרייב\"")
        # 4.0.5: ניסיון קודם שנקטע — קודם מחזירים אותו (אחרת העותק "לפני" היה נלקח מהגדרות חצי-מוכנות)
        busy = rclone_busy()
        if busy:                                       # 4.1.0: גם בלי ניסיון קודם — rclone פתוח יכתוב את ההגדרות מחדש מעל שלנו
            raise ValueError("חלון שחור של חיבור הדרייב עוד פתוח — לסיים אותו (או לסגור) ואז לנסות שוב")
        st = HEALTH.own_key_recover(conf, busy=False)
        if st == "unknown" and HEALTH._gdrive(conf) is None:     # 4.1.0: גם הקובץ הנוכחי וגם העותק לא קריאים — לא מנחשים
            raise ValueError("קובץ הגדרות הגיבוי נראה פגום ואי אפשר לשחזר אותו לבד — ללחוץ \"חבר מחדש את הדרייב\"")
        if HEALTH._gdrive(conf) is None:
            raise ValueError("קובץ הגדרות הגיבוי נראה פגום או מוצפן — ללחוץ \"חבר מחדש את הדרייב\"")
        kp = HEALTH.own_key_paths(conf)
        bak = kp["before"]
        HEALTH.write_private(bak, conf.read_bytes())          # 0600 מההתחלה (4.1.0), אטומי
        kp["ok"].unlink(missing_ok=True)
        HEALTH.write_private(kp["pending"], time.strftime("%Y-%m-%d %H:%M") + "\n")   # מוסר רק כשהחיבור הסתיים, או כשהוחזר
        OWN_KEY["active"] = True                       # הגיבוי ברקע מושהה עד שהניסיון נגמר

        def back():
            try:
                HEALTH.restore_before(conf)            # אטומי; מנקה before / pending / ok (4.1.0)
            except OSError as e:
                app_log("=== drive own key restore: %s" % e)
            recheck(["drive"], wait=True)

        def done_ok():
            kp["ok"].write_text(time.strftime("%Y-%m-%d %H:%M") + "\n")
            kp["pending"].unlink(missing_ok=True)
            HEALTH.DRIVE_NOTE[0] = ""

        def end():
            OWN_KEY["active"] = False

        try:
            # 4.1.0: עריכה בתוך התהליך — הסוד לא עובר בשורת פקודה (נראה ב-ps), לא ביומן
            HEALTH.conf_update(conf, "gdrive", {"client_id": cid, "client_secret": sec, "scope": "drive"})
            code = 0
        except ValueError as e:
            back()
            end()
            raise ValueError("%s — שום דבר לא השתנה, הגיבוי ממשיך כרגיל" % e)
        except OSError as e:
            back()
            end()
            raise ValueError("לא הצלחתי לשמור את המפתח (%s) — שום דבר לא השתנה, הגיבוי ממשיך כרגיל" % (e.strerror or "שגיאת קובץ"))
        app_log("=== %s drive own key saved — reconnecting" % time.strftime("%Y-%m-%d %H:%M:%S"))
        try:
            drive_reconnect(on_fail=back, on_ok=done_ok, on_end=end,
                            is_connected=lambda: HEALTH.own_key_state(conf) == "done")
            launched = True
        finally:
            if not launched:
                back()
                end()
        return {"ok": True, "health": health_view()}
    finally:
        OWN_KEY["lock"].release()


# ─────────────── שיתוף ועדכון התוכנה (21/10/2026) ───────────────

def share_info():
    d = SHARE.info()
    try:
        out = SHARE.default_out()
        d["out"] = subprocess.run(["wslpath", "-w", str(out)], capture_output=True, text=True, timeout=10).stdout.strip() or str(out)
    except (SystemExit, Exception):
        d["out"] = ""
    return d


# 22/10/2026 (כרטיס 14) — קובץ השיתוף נשאר בגרסה הנוכחית:
#  (א) אחרי כל עדכון (הפעלה על קוד חדש) — make_short_selftest.py package: בונה חבילה לתיקייה זמנית, מחלץ, מריץ את
#      חלקי ההתקנה עצמם לבית זמני, ובודק גרסה + שכל קובץ הרצה בפנים. נכשל → הודעה אדומה בהגדרות → מערכת.
#  (ב) zip בתיקיית "שיתוף" שגרסתו ישנה → "קובץ השיתוף ישן — בנה מחדש"; ההגדרה share_auto_rebuild בונה לבד
#      (רק כשאין שום עבודה), והישן לסל המיחזור.
SHARE_STALE = {"ts": 0.0, "data": {}, "running": False}
SHARE_CHECK_FILE = LOGS / ("share_check%s.json" % ("_test" if MS.TEST_MODE else ""))
SHARE_CHECK = {"running": False}


def share_stale_view():
    """מצב קובץ השיתוף (נשמר במטמון דקה — מציאת התיקייה בווינדוס לוקחת שנייה)."""
    if time.time() - SHARE_STALE["ts"] > 60 and not SHARE_STALE["running"]:
        SHARE_STALE["running"] = True

        def go():
            try:
                data = SHARE.stale_info()
                try:                             # 3.5: הפרופילים למקבלים + החבילה האחרונה של כל אחד
                    data["profiles"] = SHARE.profiles_view()
                except (SystemExit, Exception) as e:
                    data["profiles"] = []
                    app_log("=== share profiles view: %s" % e)
                SHARE_STALE["data"] = data
            except (SystemExit, Exception) as e:
                SHARE_STALE["data"] = {"error": str(e)[:200]}
            finally:
                SHARE_STALE.update(ts=time.time(), running=False)
        threading.Thread(target=go, daemon=True).start()
    d = dict(SHARE_STALE["data"])
    d["busy"] = not server_idle()
    try:
        d["check"] = json.load(open(SHARE_CHECK_FILE, encoding="utf-8"))
    except (OSError, ValueError):
        d["check"] = None
    if d["check"]:                               # תוצאה של גרסה קודמת — לא מראים אותה כאילו היא של עכשיו
        d["check"]["current"] = d["check"].get("code") == CODE["boot"]
    if SHARE_CHECK["running"]:
        d["check"] = dict(d["check"] or {}, running=True)
    return d


def share_check_run():
    """בדיקת החבילה של הגרסה הזאת (רקע). פעם אחת לכל גרסת קוד — התוצאה נשמרת עם טביעת הקוד."""
    if SHARE_CHECK["running"]:
        return
    SHARE_CHECK["running"] = True

    def go():
        try:
            r = subprocess.run([sys.executable, str(HERE / "make_short_selftest.py"), "package", "--json"],
                               capture_output=True, text=True, errors="replace", timeout=1800)
            try:
                res = json.loads(r.stdout.strip().splitlines()[-1])
            except (ValueError, IndexError):
                res = {"ok": False, "errors": [(r.stdout + r.stderr).strip()[-300:] or "הבדיקה לא החזירה תוצאה"]}
            res.update(code=CODE["boot"], at=time.strftime("%Y-%m-%d %H:%M"))
            LOGS.mkdir(parents=True, exist_ok=True)
            SHARE_CHECK_FILE.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
            app_log("=== share package check: %s %s" % ("ok" if res.get("ok") else "FAILED", "; ".join(res.get("errors") or [])[:300]))
        except Exception as e:
            app_log("=== share package check could not run: %s" % e)
        finally:
            SHARE_CHECK["running"] = False
            SHARE_STALE["ts"] = 0
    threading.Thread(target=go, daemon=True).start()


def share_profile_autorebuild(s):
    """3.5: חבילות של פרופילים לא נבנות מחדש לבד — רק פרופיל שסימן בו "🔄 לבנות מחדש לבד אחרי עדכון" (כבוי
    כברירת מחדל), רק כשאין שום עבודה, אחד בכל פעם. פרופיל בלי חבילה בכלל — לא נבנה לבד."""
    if SHARE_CHECK["running"] or any(j["running"] and j["kind"] == "share" for j in JOBS.values()) or not server_idle():
        return None
    for p in s.get("profiles") or []:
        if p.get("auto_rebuild") and p.get("stale") and p.get("zip"):
            app_log("=== share zip of profile %s is old — rebuilding (auto)" % p.get("id"))
            SHARE_STALE["ts"] = 0
            return start_job("share", [sys.executable, "-u", str(HERE / "make_short_share.py"), "build", "--prune",
                                       "--profile", p["id"]], title="חבילת שיתוף ל%s (אחרי עדכון)" % p.get("name", ""))
    return None


def share_watch():
    """כל דקה: (א) קוד חדש שעוד לא נבדקה החבילה שלו → בדיקה (כשאין עבודה); (ב) בנייה מחדש לבד אם ביקש."""
    time.sleep(int(os.environ.get("MAKE_SHORT_SHARE_WATCH_DELAY", "90")))   # שהחלון יעלה קודם
    while True:
        try:
            if server_idle() and not RESTARTING["on"]:
                try:
                    last = json.load(open(SHARE_CHECK_FILE, encoding="utf-8")).get("code")
                except (OSError, ValueError):
                    last = None
                if last != CODE["boot"] and os.environ.get("MAKE_SHORT_NO_SHARE_CHECK") != "1":
                    share_check_run()
                s = share_stale_view()
                if SET.load().get("share_auto_rebuild") and s.get("stale") and not SHARE_CHECK["running"] \
                        and not any(j["running"] and j["kind"] == "share" for j in JOBS.values()):
                    app_log("=== share zip is old (%s) — rebuilding (share_auto_rebuild)" % s.get("version"))
                    SHARE_STALE["ts"] = 0
                    start_job("share", [sys.executable, "-u", str(HERE / "make_short_share.py"), "build", "--prune"]
                              + (["--drive"] if s.get("drive_offer") else []), title="חבילת שיתוף (אחרי עדכון)")
                else:
                    share_profile_autorebuild(s)
        except Exception as e:
            app_log("=== share watch: %s" % e)
        time.sleep(60)


def open_in_explorer(path):
    """פותח בסייר הקבצים של ווינדוס את התיקייה (ומסמן את הקובץ) — רק בתוך תיקיית השיתוף."""
    p = Path(path).resolve()
    out = SHARE.default_out().resolve()
    if p != out and out not in p.parents:
        raise ValueError("נתיב לא מוכר")
    w = subprocess.run(["wslpath", "-w", str(p)], capture_output=True, text=True, timeout=10).stdout.strip()
    args = ["/select,", w] if p.is_file() else [w]
    subprocess.Popen(["/mnt/c/Windows/explorer.exe", *args], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, cwd="/mnt/c")


def update_rules():
    """"העתק הוראות לעוזר": הפורמט + מבנה הקוד + הגרסה. בלי שום סוד."""
    lines = []
    for f in _git("ls-files").splitlines():
        try:
            n = sum(1 for _ in open(HERE.parent.parent / f, "rb"))
        except OSError:
            n = 0
        lines.append("  %s (%d שורות)" % (f, n))
    return "\n".join([UPD.FORMAT_RULES, "=== הגרסה אצל המשתמש ===",
                      "  %s · שורש הקוד: %s" % (_git("log", "-1", "--format=%h %cs %s"), HERE.parent.parent),
                      "", "=== מבנה הקוד (כל הקבצים) ===",
                      "  העיקריים: pipeline/scripts/make_short_app.py (השרת של החלון), make_short_page.html (הדף),",
                      "  make_short.py (בניית השורט), make_short_pick.py (בחירה אוטומטית), make_short_settings.py (הגדרות),",
                      "  windows/ (התקנה וקיצור), docs/HANDOFF.md (כללים ותקלות ידועות — כדאי לבקש מהמשתמש להדביק).",
                      *lines, "",
                      "הבקשה של המשתמש (הוא יכתוב כאן מה לשנות):", ""])


def chat_ctx(mode, job_id=""):
    """27/10 — ההקשר לבלוק של "עבודה עם צ'אט": גרסאות + עדכונים אחרונים; לבאג גם העבודה האחרונה שנכשלה, בדיקת
    המערכת, בדיקת האיכות האחרונה ויומן החלון. כל מה שמגיע מיומנים — דרך HEALTH.scrub (והבלוק כולו עוד עובר CHAT.guard)."""
    ctx = {"header": assistant_header()[1:5]}
    # נתיב מלא ב-traceback (‎/home/…/snapshots/<hash>/pipeline/scripts/x.py) נראה ל-scrub כמו מפתח ארוך ונמחק —
    # ואז הצ'אט לא יודע איזה קובץ נפל. נתיבים אינם סוד: מקצרים לנתיב בתוך הקוד *לפני* הניקוי.
    root = str(HERE.parent.parent).rstrip("/") + "/"
    rel = lambda l: re.sub(r"/[^\s\"']*/snapshots/[0-9a-f]+/", "", str(l).replace(root, ""))
    scrub = lambda l: HEALTH.scrub(rel(l))
    ctx["scrub"] = scrub
    hist = UPD.status().get("history") or []
    ctx["updates"] = ["  %s · %s · %s (%s)" % (h.get("at"), {"applied": "הוחל", "rolled_back": "נכשל והוחזר", "undone": "בוטל"}.get(
        h.get("status"), h.get("status")), HEALTH.scrub(h.get("desc", "")), ", ".join(h.get("files", [])[:4])) for h in hist]
    if mode != "bug":
        return ctx
    j = JOBS.get(job_id) or next((x for x in reversed(list(JOBS.values())) if x["ok"] is False), None)
    if j:
        ctx["job"] = {"kind": j["kind"], "title": scrub(j.get("title") or ""), "started": j.get("started"),
                      "state": "רצה" if j["running"] else ("הצליחה" if j["ok"] else "נכשלה"),
                      "error": scrub(str(j.get("error") or "")), "log": [scrub(l) for l in j["log"][-80:]]}
    h = HEALTH_STATE.get("data")
    if h:
        ctx["health"] = ["  (%s) [%s] %s %s" % (h.get("at"), r["level"], r["title"], HEALTH.scrub(r.get("detail") or ""))
                         for r in h["results"]]
    try:
        import make_short_selftest as STEST
        s = json.loads(STEST.last_path().read_text(encoding="utf-8"))
        ctx["selftest"] = "%s · %s · %s (%s שניות, גרסה %s)%s" % (
            s.get("at"), s.get("mode"), "עברה" if s.get("ok") else "נכשלה", s.get("secs"), s.get("commit", ""),
            "".join("\n  - " + HEALTH.scrub(e) for e in s.get("errors") or []))
    except (OSError, ValueError, ImportError):
        ctx["selftest"] = "(עוד לא רצה בדיקת איכות במחשב הזה)"
    try:
        ctx["app_log"] = [scrub(l) for l in APP_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-30:]]
    except OSError:
        pass
    return ctx


# ─────────────── 🛠️ תקן שורט זה בצ'אט (כרטיס 27, 12/11/2026) ───────────────

def fix_clip(d):
    p, st = load_state(d["project"])
    name = re.sub(r"[^\w]", "", str(d.get("clip") or ""))
    if not any(c["name"] == name and not c.get("dropped") for c in st["clips"]):
        raise ValueError("אין קליף כזה")
    return p, st, name


def fix_state(p, name):
    v = FIX.state_view(p, name)
    last = v["last"]
    j = next((x for x in reversed(list(JOBS.values())) if last and x.get("fix") == last["id"]), None)
    if last and last["state"] in ("queued", "running") and not (j and j["running"]):
        last.update(state="failed", error="העבודה נעצרה באמצע (התוכנה נסגרה?) — אפשר להריץ את התיקון שוב")
        FIX.save_meta(p, last["id"], last)
    v["log"] = [l for l in (j["log"][-14:] if j else [])]
    v["busy"] = bool(busy(p, name))
    return v


def fix_media(p, name, fid, which, frame):
    m = FIX.load_meta(p, fid)
    if not m or m["clip"] != name:
        raise ValueError("אין תיקון כזה")
    d = FIX.fix_dir(p, fid)
    if frame:
        f = d / ("before.jpg" if which == "old" else "after.jpg")
        ctype = "image/jpeg"
    else:
        _, cur = FIX.final_of(p, name)
        ctype = "video/mp4"
        if m["state"] == "accepted":
            f = cur if which != "old" else FIX._vdir(p, name) / ("%s_final_before.mp4" % fid)
        else:
            f = cur if which == "old" else d / "final_new.mp4"
    if not f.exists():
        raise ValueError("הקובץ לא נמצא")
    return f, ctype


def fix_api(act, d):
    """כל הפעולות של הפאנל "🛠️ תקן שורט זה בצ'אט". שום דבר לא יוצא מהמחשב; הקליף עצמו מוחלף רק ב-accept."""
    p, st, name = fix_clip(d)
    if act == "files":
        fv = FIX.files_view(p, name)
        return {"files": fv, "review_over": FIX.REVIEW_OVER_MB, "big": any(f["key"] == "final" and f["size"] > FIX.REVIEW_OVER_MB * 1e6 for f in fv),
                "state": fix_state(p, name)}
    if act == "block":
        at = FIX.parse_hms(str(d.get("at") or ""))
        return FIX.build_block(p, name, str(d.get("text") or "")[:4000], at, d.get("inc") or {})
    if act == "bug":                      # "🐞 תקלה חוזרת?" — הבלוק הכללי של כרטיס 19, עם הקליף והפגם בראשו
        txt = "בקליף %s של השיעור (%s) ראיתי: %s" % (name, st.get("video_title", ""), str(d.get("text") or "")[:3500])
        return CHAT.block("bug", txt, chat_ctx("bug"), [], [], SET.load()["chat_code_chars"])
    if act == "review":
        r = FIX.review_copy(p, name)
        return dict(r, files=FIX.files_view(p, name))
    if act == "reveal":
        f = FIX.file_for(p, name, str(d.get("key") or "final"))
        f = f.resolve()
        if p.resolve() not in f.parents:
            raise ValueError("נתיב לא מוכר")
        w = FIX.win(f)
        if not os.environ.get("MAKE_SHORT_FIX_NO_EXPLORER"):
            subprocess.Popen(["/mnt/c/Windows/explorer.exe", "/select,", w], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, cwd="/mnt/c")
        return {"ok": True, "win": w}
    if act == "check":
        return FIX.check(p, name, str(d.get("text") or ""))
    if act == "apply":
        if busy(p, name):
            raise ValueError("הקליף בעבודה עכשיו — לחכות שיסתיים")
        at = FIX.parse_hms(str(d.get("at") or ""))
        text = str(d.get("answer") or "")
        fid = FIX.stage(p, name, text, str(d.get("defect") or ""), at)
        job = start_job("fixapply", [sys.executable, "-u", str(HERE / "make_short_fix.py"), "apply", str(p), name, fid], str(p),
                        st.get("video_title", ""), extra={"clip": name, "fix": fid, "env": {"MAKE_SHORT_NO_PROGRESS": "1"}})
        return {"job": job, "id": fid, "state": fix_state(p, name)}
    if act in ("accept", "undo", "discard"):
        if busy(p, name):
            raise ValueError("הקליף בעבודה עכשיו — לחכות שיסתיים")
        with SAVE_LOCK, LOCK:
            if act == "accept":
                return FIX.accept(p, name, str(d.get("id") or ""))
            if act == "discard":
                return FIX.discard(p, name, str(d.get("id") or ""))
            return FIX.undo(p, name)
    raise ValueError("פעולה לא מוכרת")


def restart_soon():
    """הפעלה מחדש של השרת באותו חלון שחור (אחרי עדכון קוד): exec של אותה פקודה. חיבור ההאזנה
    נסגר ב-exec (פייתון לא מוריש אותו), והתהליך החדש פותח אותו מחדש; הדף מתחבר לבד."""
    def go():
        time.sleep(0.8)
        app_log("=== %s restart (after update)" % time.strftime("%Y-%m-%d %H:%M:%S"))
        sys.stdout.flush()
        os.execv(sys.executable, [sys.executable] + sys.argv)
    threading.Thread(target=go, daemon=True).start()


def server_idle():
    """אין שום עבודה — לא רצה, לא בתור, ואין תצוגה מקדימה. (טיוטות לא חוסמות: הן בדיסק.)"""
    return not (any(j["running"] for j in JOBS.values()) or queue_pending() or any(p["running"] for p in PREVIEWS.values())
                or DRIVE_Q["running"]            # גם גיבוי לדרייב באמצע — לא נוגעים בקבצים שהוא קורא
                or SHARE_CHECK["running"]        # ובדיקת חבילת השיתוף (כרטיס 14) — שלא תיקטע באמצע ותרוץ שוב ושוב
                or RELS["applying"]              # 4.3: באמצע עדכון מהאינטרנט — לא מתחילים שום דבר חדש
                or PCS["busy"])                  # 4.5: באמצע החלה/כיבוי של שינוי אישי


def _ppid(pid):
    try:
        s = Path("/proc/%d/stat" % pid).read_text()
        return int(s[s.rindex(")") + 2:].split()[1])
    except (OSError, ValueError, IndexError):
        return 0


def external_pipeline_running(root=None, me=None):
    """4.5.x (B8): ריצה של הצינור שהתחילה מחוץ לתוכנה (shorts.sh בחלון שחור, Claude) — לא מחליפים קוד מתחתיה.
    תהליכים שהם צאצאים של התוכנה עצמה (העבודות שלה) כבר נספרים ב-server_idle."""
    root = str(root or HERE.parent.parent)
    me = me or os.getpid()
    try:
        procs = os.listdir("/proc")
    except OSError:
        return False
    for d in procs:
        if not d.isdigit() or int(d) == me:
            continue
        try:
            cmd = Path("/proc", d, "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
        except OSError:
            continue
        if "make_short_app.py" in cmd or not ((root + "/shorts.sh") in cmd or (root + "/pipeline/") in cmd):
            continue
        p, ours = int(d), False
        for _ in range(64):
            p = _ppid(p)
            if p <= 1:
                break
            if p == me:
                ours = True
                break
        if not ours:
            return True
    return False


def code_selfcheck():
    """הבדיקה העצמית של "עדכון תוכנה" (קומפילציה, bash -n, JSON, JS של הדף, שרת בדיקה) על הקבצים כמו שהם בדיסק."""
    try:
        r = subprocess.run([sys.executable, str(HERE / "make_short_update.py"), "selfcheck"], capture_output=True, text=True,
                           errors="replace", timeout=240)
        return r.returncode == 0, (r.stdout + r.stderr).strip()[-900:]
    except Exception as e:
        return False, "הבדיקה העצמית לא הצליחה לרוץ: %s" % e


# ───────────── 4.3: עדכונים חתומים מהאינטרנט (כפתור אחד בשורה העליונה) + מסך "פרסם עדכון" של הבעלים ─────────────
RELS = {"checking": False, "applying": False, "phase": "", "err": "", "check": None, "last_at": 0.0, "last_error": "",
        "prog": None, "cancel": False, "restarting": False}


def rel_prog(d):
    """4.3.1: התקדמות בזמן אמת של העדכון (שלב, אחוז, בתים, "גרסה 2 מתוך 3", האם אפשר לבטל) — הדף מצייר ממנה פס."""
    RELS["prog"] = dict(d, at=time.time())
    RELS["phase"] = d.get("label", "")
PUBLISHER = {"p": None}
SKIP_UPDATE = "--skip-update" in sys.argv      # אחרי כישלון: מונע לולאת עדכון — אין בדיקה ברקע בהרצה הזאת


def rel_run_check(auto):
    RELS["checking"], RELS["err"] = True, ""
    rel_prog({"stage": "checking", "label": "בודק אם יש גרסה חדשה", "pct": 0, "cancellable": False})
    try:
        st = REL.load_state()
        c = REL.check(skip=st.get("skip", []))
        if c.get("skip_note") and c.get("skip") != st.get("skip", []):     # 4.5.x (B1): דילוג שבוטל כי יצאה גרסה חדשה ממנו
            st["skip"], st["skip_note"] = c["skip"], c["skip_note"]
            REL.save_state(st)
        RELS["check"] = c
        RELS["last_at"] = time.time()
        RELS["auto_err"] = ""
    except Exception as e:
        # 4.5.x (B1): בדיקה אוטומטית שנכשלה לא נבלעת. רק "אין חיבור" שותק (מחשב בלי אינטרנט); חתימה/סדר/פורמט — מוצג בדף
        offline = isinstance(e, REL.UpdateError) and str(e).startswith("אין חיבור")
        txt = str(e) if isinstance(e, REL.UpdateError) else "הבדיקה לא הצליחה (%s)" % type(e).__name__
        if auto:
            RELS["auto_err"] = "" if offline else "בדיקת העדכונים האוטומטית נכשלה: " + txt
        else:
            RELS["err"] = "אין חיבור לשרת העדכונים כרגע — אפשר לנסות שוב אחר כך." if offline else txt
    finally:
        RELS["checking"] = False


def rel_check_start(auto=False):
    if RELS["checking"] or RELS["applying"]:
        return
    if REL.update_mode() != "receiver" or not REL.source()[0]:
        raise ValueError("ההתקנה הזאת לא מתעדכנת מהאינטרנט")
    threading.Thread(target=rel_run_check, args=(auto,), daemon=True).start()


def rel_status():
    mode, base = REL.update_mode(), REL.source()[0]
    inst, st, c = REL.installed_version(), REL.load_state(), RELS["check"] or {}
    avail = bool(c.get("available")) and mode == "receiver" and REL.ver_tuple(c["version"]) > REL.ver_tuple(inst or "0.0.0")
    d = {"mode": mode, "configured": bool(base), "installed": inst, "checking": RELS["checking"], "applying": RELS["applying"],
         "phase": RELS["phase"], "err": RELS["err"], "available": avail, "last_error": RELS["last_error"],
         "last_txt": time.strftime("%d/%m %H:%M", time.localtime(RELS["last_at"])) if RELS["last_at"] else "",
         "prog": RELS["prog"] if (RELS["applying"] or RELS["checking"]) else None,
         "has_prev": mode == "receiver" and REL.has_previous(), "just_updated": st.get("just_updated"), "recovered": st.get("recovered", ""),
         "rec_fail": bool(st.get("recover_failed")), "auto_err": RELS.get("auto_err", ""), "skip_note": st.get("skip_note", ""),
         "personal": pc_brief(), "vault_visible": vault_visible()}
    if avail:
        d.update(version=c["version"], notes=c.get("notes", []), steps=c.get("steps", []), size=c.get("size", 0))
    try:
        d["publish"] = PUB.screen_status()
    except Exception:
        d["publish"] = None
    if PUBLISHER["p"]:
        d["run"] = PUBLISHER["p"].state()
    else:                                              # 4.3.1: רענון חלון / הפעלה מחדש — המצב האחרון של הפרסום נשמר בדיסק
        d["run"] = PUB.saved_state()
    return d


def rel_guard(what):
    if REL.update_mode() != "receiver":
        raise ValueError("ההתקנה הזאת לא מתעדכנת מהאינטרנט")
    if RELS["applying"]:
        raise ValueError("עדכון כבר רץ")
    if PCS["busy"]:
        raise ValueError("מתבצעת עכשיו פעולה על השינויים האישיים שלכם — לחכות שתסתיים (כמה דקות) ואז ל%s" % what)
    if external_pipeline_running():
        raise ValueError("רצה עכשיו עבודה של התוכנה מחוץ לחלון הזה (חלון שחור או צ'אט) — אפשר ל%s כשהיא תסתיים" % what)
    with QLOCK:
        if not server_idle():
            raise ValueError("יש עבודה שרצה או בתור — אפשר ל%s כשהיא תסתיים" % what)
        RELS["applying"] = True


def rel_apply_run():
    restarting = False
    try:
        RELS.update(phase="מוריד ומתקין …", last_error="", cancel=False, prog=None)
        try:                                        # 4.5.62: הבסיס הרשמי של הגרסה הנוכחית (עדכון של כמה גרסאות מוחק את התגית שלו)
            off_commit = REL.official_commit()
        except Exception:
            off_commit = ""
        def _early(applied):                        # 4.5.62: לפני ההחלה מחדש של השינויים האישיים — כיבוי באמצעה לא משאיר גרסה בלי הגנה
            REL.trial_begin([a["version"] for a in applied], applied[0]["base"], official=off_commit)
            _s = REL.load_state()
            _s["just_updated"] = {"version": applied[-1]["version"], "notes": [n for a in applied for n in a.get("notes", [])],
                                  "local_patch": next((a["local_patch"] for a in applied if a.get("local_patch")), ""),
                                  "at": int(time.time()), "personal": None}
            REL.save_state(_s)
        res = REL.run_updates(log=lambda s: None, check_fn=code_selfcheck, progress=rel_prog, cancel=lambda: RELS["cancel"],
                              on_installed=_early)
        if res["error"]:
            RELS["last_error"] = "%s חזרנו לגרסה %s, הכול עובד." % (res["error"], REL.installed_version()) \
                if not res["error"].startswith("העדכון בוטל") else res["error"]
            app_log("=== %s update stopped: %s" % (time.strftime("%H:%M:%S"), res["error"]))
        if res["applied"]:
            notes = []
            for a in res["applied"]:
                notes += (["גרסה %s:" % a["version"]] if len(res["applied"]) > 1 else []) + a.get("notes", [])
            st = REL.load_state()
            st["just_updated"] = {"version": res["applied"][-1]["version"], "notes": notes, "local_patch": res.get("local_patch", ""),
                                  "at": int(time.time()), "personal": pc_after_update(res.get("personal"))}
            REL.save_state(st)
            RELS["check"] = None
            try:                                    # 4.5.x (B7): אם הגרסה החדשה לא תעלה — shorts.sh יחזיר לבד (ראו REL.trial_begin)
                REL.trial_begin([a["version"] for a in res["applied"]], res["applied"][0]["base"], official=off_commit)
            except Exception as e:
                app_log("=== trial marker: %r" % e)
            app_log("=== %s updated to %s — restarting" % (time.strftime("%H:%M:%S"), res["applied"][-1]["version"]))
            rel_prog({"stage": "restart", "label": "מפעיל מחדש את התוכנה", "pct": 100, "cancellable": False})
            restarting = True
            restart_soon()
    except Exception as e:
        RELS["last_error"] = "העדכון נכשל (%s). חזרנו לגרסה %s, הכול עובד." % (type(e).__name__, REL.installed_version())
        app_log("=== update crashed: %r" % e)
    finally:
        if not restarting:                          # לפני הפעלה מחדש נשאר "מעדכן" — התהליך החדש מתחיל נקי
            RELS["applying"] = False
            RELS["prog"] = None


def rel_rollback_run():
    try:
        RELS.update(phase="חוזר לגרסה הקודמת …", last_error="")
        r = REL.rollback_previous(check_fn=code_selfcheck)
        app_log("=== %s rolled back to %s" % (time.strftime("%H:%M:%S"), r["version"]))
        if r.get("personal"):
            st = REL.load_state()
            st["just_updated"] = {"version": r["version"], "kind": "rollback", "notes": [], "local_patch": "",
                                  "at": int(time.time()), "personal": pc_after_update(r["personal"])}
            REL.save_state(st)
        restart_soon()
    except Exception as e:
        RELS["last_error"] = str(e) if isinstance(e, REL.UpdateError) else "החזרה נכשלה (%s)" % type(e).__name__
    finally:
        RELS["applying"] = False


def rel_watch():
    """בדיקה שקטה אחת כמה שניות אחרי הפתיחה, ואז פעם ביום. בלי רעש: כשל = שותקים. (מצב בדיקה: בלי רשת, אלא אם ביקשו.)"""
    if SKIP_UPDATE or (os.environ.get("MAKE_SHORT_NO_EXPORT") and not os.environ.get("MAKE_SHORT_REL_WATCH")):
        return
    time.sleep(25)
    while True:
        try:
            if REL.update_mode() == "receiver" and REL.source()[0] and not RELS["applying"] and not RELS["checking"]:
                if time.time() - RELS["last_at"] > 20 * 3600:
                    rel_run_check(True)
        except Exception:
            pass
        time.sleep(1800)


def publisher():
    if PUBLISHER["p"] is None:
        PUBLISHER["p"] = PUB.Publisher()
    return PUBLISHER["p"]


def rel_post(path, d):
    """נתיבי POST של 4.3. מחזיר dict, או None אם הנתיב אינו שלנו."""
    try:
        if path == "/api/release/check":
            rel_check_start(False)
            return {"ok": True}
        if path == "/api/release/apply":
            if not d.get("confirm"):
                raise ValueError("חסר אישור")
            if not (RELS["check"] or {}).get("available"):
                raise ValueError("אין עדכון ידוע — קודם בודקים")
            rel_guard("עדכן")
            threading.Thread(target=rel_apply_run, daemon=True).start()
            return {"ok": True}
        if path == "/api/release/rollback":
            if not d.get("confirm"):
                raise ValueError("חסר אישור")
            if not REL.has_previous():
                raise ValueError("אין גרסה קודמת שמורה")
            rel_guard("לחזור לגרסה הקודמת")
            threading.Thread(target=rel_rollback_run, daemon=True).start()
            return {"ok": True}
        if path == "/api/release/cancel":           # 4.3.1: רק בהורדה ובאימות; בהחלפה עצמה — לא
            p = RELS["prog"] or {}
            if not RELS["applying"] or not p.get("cancellable"):
                raise ValueError("אי אפשר לבטל עכשיו — ההחלפה כבר התחילה (היא קצרה, ואם משהו ישתבש נחזור לגרסה התקינה)")
            RELS["cancel"] = True
            return {"ok": True}
        if path == "/api/release/seen":
            st = REL.load_state()
            st.pop("just_updated", None)
            st.pop("recovered", None)
            st.pop("recover_failed", None)
            st.pop("skip_note", None)
            REL.save_state(st)
            return {"ok": True}
        if path == "/api/publish/keygen":
            return {"pub": PUB.keygen(str(d.get("passphrase") or ""))}
        if path == "/api/publish/start":
            if not PUB.have_key():
                raise ValueError("עוד אין מפתח חתימה")
            publisher().start(str(d.get("passphrase") or ""), [str(x) for x in d.get("notes") or []], bool(d.get("must_not_skip")),
                              str(d.get("baseline") or "").strip() or None)
            return {"ok": True}
        if path == "/api/publish/answer":
            publisher().answer(bool(d.get("yes")))
            return {"ok": True}
        if path == "/api/publish/cancel":
            return {"ok": publisher().cancel()}
        if path == "/api/publish/cleanup":
            mk = PUB.cleanup_pending()
            if not mk:
                raise ValueError("אין מה לנקות")
            PUB.undo_upload(mk)
            return {"ok": True}
    except REL.UpdateError as e:
        raise ValueError(str(e))
    return None


# ─────────────── 4.5: "🧩 שינויים אישיים שלי" — שינויים שהמשתמש עשה לעצמו שורדים עדכונים רשמיים ───────────────
PCS = {"busy": False, "label": "", "msg": "", "prog": None}


def pc_active():
    return REL.update_mode() == "receiver"


def pc_after_update(p):
    """תקציר לחלון "עודכנו": מה קרה לכל שינוי אישי, במילים פשוטות."""
    if not p:
        return None
    res = p.get("results") or []
    return {"lines": PERS.summary_he(res), "error": p.get("error", ""), "attention": len([r for r in res if r["state"] in PERS.NEEDS_USER]),
            "n": len(res)}


def pc_brief():
    """קטן וזול — נכנס ל-/api/release/status (נשאל כל כמה שניות)."""
    if not pc_active():
        return {"active": False, "n": 0, "attention": 0, "waiting": 0, "busy": False}
    ch = PERS.load()["changes"]
    return {"active": True, "n": len([c for c in ch if c["state"] != "archived"]), "total": len(ch),
            "attention": len([c for c in ch if c["state"] in PERS.NEEDS_USER]),
            "waiting": len([c for c in ch if c["state"] == "waiting"]), "busy": PCS["busy"]}


def pc_status():
    d = PERS.status(REL.REPO) if pc_active() else {"active": False, "changes": [], "attention": 0, "waiting": 0, "last_reapply": None,
                                                     "has_official_base": False}
    lr = d.get("last_reapply") or {}
    d["lines"] = PERS.summary_he(lr.get("results"))
    d.update(busy=PCS["busy"], label=PCS["label"], msg=PCS["msg"], prog=PCS["prog"], version=REL.installed_version())
    return d


def pc_begin(what, label):
    if not pc_active():
        raise ValueError("ההתקנה הזאת לא מתעדכנת מהאינטרנט — אין בה שינויים אישיים מנוהלים")
    if external_pipeline_running():                 # 4.5.62 (#7): כמו בעדכון הרשמי — בנייה מחדש של הקוד לא רצה מתחת לעבודה מחוץ לחלון
        raise ValueError("רצה עכשיו עבודה של התוכנה מחוץ לחלון הזה (חלון שחור או צ'אט) — אפשר ל%s כשהיא תסתיים" % what)
    with QLOCK:
        if PCS["busy"] or RELS["applying"]:
            raise ValueError("עוד פעולה רצה — לחכות שתסתיים")
        if not server_idle():
            raise ValueError("יש עבודה שרצה או בתור — אפשר ל%s כשהיא תסתיים" % what)
        PCS.update(busy=True, label=label, msg="", prog=None)


def pc_prog(pct, label):
    PCS["prog"] = {"pct": pct, "label": label}


def pc_run(fn):
    try:
        PCS["msg"] = fn() or ""
    except PERS.PCError as e:
        PCS["msg"] = str(e)
    except Exception as e:
        PCS["msg"] = "הפעולה לא הצליחה (%s) — שום דבר לא נפגע." % type(e).__name__
        app_log("=== personal change op failed: %r" % e)
    finally:
        PCS["busy"] = False
        PCS["prog"] = None


PC_RESTART_NOTE = "התוכנה תיפתח מחדש בעצמה ברגע שאין עבודה, ורק אז זה ייכנס לתוקף."


def _pc_outcome(r, ok_text):
    if not r:
        return ok_text
    return {"applied": ok_text, "absorbed": "✓ כבר נכלל בגרסה הרשמית — אין צורך בו.",
            "conflict": "⚠ לא התמזג עם הגרסה הנוכחית — הוא נשאר כבוי ושמור.",
            "incompatible": "⛔ הבדיקה נכשלה כשהוחל — הוא הוסר שוב, והכול עובד. השינוי נשמר."}.get(r["state"], ok_text)


def pc_post(path, d):
    """נתיבי POST של 4.5. מחזיר dict, או None אם הנתיב אינו שלנו."""
    cid = str(d.get("id") or "")
    try:
        if path == "/api/personal/enable":
            on = bool(d.get("on"))
            pc_begin("להפעיל או לכבות שינוי", "מפעיל…" if on else "מכבה…")
            threading.Thread(target=pc_run, args=(lambda: _pc_outcome(PERS.set_enabled(REL.REPO, cid, on, prog=pc_prog), "✅ הופעל בקוד. " + PC_RESTART_NOTE) if on
                                                  else (PERS.set_enabled(REL.REPO, cid, False, prog=pc_prog), "⏸ כובה — יצא מהקוד. " + PC_RESTART_NOTE + " אפשר להפעיל שוב בכל רגע.")[1],), daemon=True).start()
            return {"ok": True}
        if path == "/api/personal/giveup":
            pc_begin("לוותר על שינוי", "מוותר…")
            threading.Thread(target=pc_run, args=(lambda: PERS.give_up(REL.REPO, cid, prog=pc_prog) or "🗄 הועבר לארכיון — אפשר לשחזר.",), daemon=True).start()
            return {"ok": True}
        if path == "/api/personal/restore":
            pc_begin("לשחזר שינוי", "משחזר…")
            threading.Thread(target=pc_run, args=(lambda: _pc_outcome(PERS.restore(REL.REPO, cid, prog=pc_prog), "✅ שוחזר בקוד. " + PC_RESTART_NOTE),), daemon=True).start()
            return {"ok": True}
        if path == "/api/personal/retry":
            pc_begin("לנסות שוב", "מנסה שוב…")

            def _retry():
                r = PERS.retry_waiting(REL.REPO, prog=pc_prog)
                return "\n".join(PERS.summary_he((r or {}).get("results"))) or ((r or {}).get("error") or "אין מה להחיל.")
            threading.Thread(target=pc_run, args=(_retry,), daemon=True).start()
            return {"ok": True}
        if path == "/api/personal/rename":
            PERS.rename(cid, str(d.get("desc") or ""))
            return pc_status()
        if path == "/api/personal/block":
            return PERS.merge_block(REL.REPO, cid, SET.load()["chat_code_chars"])
        if path == "/api/personal/patch":
            return {"text": PERS.patch_text(cid)}
        if path == "/api/personal/dismiss":              # "הבנתי" — מנקה את הודעת הפעולה האחרונה
            PCS["msg"] = ""
            return {"ok": True}
    except PERS.PCError as e:
        raise ValueError(str(e))
    return None


def pc_watch():
    """בהפעלה: שינויים שממתינים (נקטעו / עריכה ידנית שנשמרה בעדכון שנכשל) — מנסים להחיל שוב, רק כשאין שום עבודה."""
    if SKIP_UPDATE or (os.environ.get("MAKE_SHORT_NO_EXPORT") and not os.environ.get("MAKE_SHORT_REL_WATCH")):
        return
    time.sleep(30)
    for _ in range(40):
        try:
            if not pc_active():
                return
            if _ == 0:
                PERS.startup_consistency(REL.REPO)      # 4.5.x (C7): אחרי התקנה מחדש / חזרה — "פעיל" שלא בקוד → ממתין
            PERS.migrate_legacy(REL.REPO)
            if not any(c["state"] == "waiting" for c in PERS.load()["changes"]):
                return
            try:
                pc_begin("להחיל שינויים אישיים", "מחיל שינויים אישיים…")
            except ValueError:
                time.sleep(60)
                continue
            pc_run(lambda: "\n".join(PERS.summary_he((PERS.retry_waiting(REL.REPO, prog=pc_prog) or {}).get("results"))))
            return
        except Exception as e:
            app_log("=== pc_watch: %r" % e)
            return


# ─────────────── 4.4: הצעות למנהל (ntfy) ───────────────
PROPS ={"selftest": None, "st_running": False, "patch": (0.0, "", ""), "checking": set()}


def prop_local_patch():
    """patch מקומי (מטמון 30 שניות — git diff בכל סקר מיותר)."""
    at, text, why = PROPS["patch"]
    if time.time() - at > 30:
        try:
            text, why = PROP.local_patch(REL.REPO)
        except Exception as e:
            text, why = "", "לא הצלחתי לבדוק שינויים מקומיים (%s)" % str(e)[:80]
        PROPS["patch"] = (time.time(), text, why)
    return text, why


def prop_diag():
    """פרטי מערכת למנהל: גוף הדוח של "העתק פרטים לעוזר" בלי הראש (הראש מיועד לעוזר חיצוני: קישורים, נתיבים, הוראות)."""
    t = report_text("", False)
    i = t.find("דוח תקלה — יצירת שורטס")
    return "גרסה %s\n%s" % (tool_version(), t[i:] if i >= 0 else "")


def prop_status():
    text, why = prop_local_patch()
    v = PROP.validate_patch(text) if text else None
    d = {"sender": PROP.sender_status(), "outbox": PROP.outbox_view(), "selftest": PROPS["selftest"], "st_running": PROPS["st_running"],
         "patch": {"has": bool(text), "ok": bool(v and v["ok"]), "files": (v or {}).get("files", []), "why": why or
                   ("; ".join((v or {}).get("problems", [])[:2]) if v and not v["ok"] else ""), "chars": len(text)},
         "owner": None}
    if PROP.owner_visible():
        d["owner"] = PROP.owner_status()
    return d


def prop_selftest_run():
    """"🧪 בדיקה מהירה" לפני שליחת תיקון: make_short_selftest.py quick --json (עד ~דקה); התקציר נשמר ונשלח עם התיקון."""
    PROPS["st_running"] = True
    try:
        r = subprocess.run([sys.executable, str(HERE / "make_short_selftest.py"), "quick", "--json"], capture_output=True, text=True,
                           errors="replace", timeout=900)
        res = json.loads(next((l for l in reversed(r.stdout.splitlines()) if l.startswith("{")), "{}"))
        good = bool(res.get("ok"))
        txt = "%s בדיקה מהירה (quick) %s · גרסה %s · %s" % ("✓" if good else "✗", "עברה" if good else "נכשלה", tool_version(),
                                                          time.strftime("%d/%m/%Y %H:%M"))
        if not good:
            txt += " — " + "; ".join((res.get("errors") or [])[:3])[:300]
    except Exception as e:
        txt = "✗ הבדיקה המהירה לא הסתיימה: %s" % str(e)[:150]
    PROPS["selftest"] = txt
    PROPS["st_running"] = False


class OwnerOnly(ValueError):
    """בקשה למסך של הבעלים ממי שאינו הבעלים → HTTP 403."""


def prop_owner_guard():
    if not PROP.owner_visible():
        raise OwnerOnly("המסך הזה זמין רק אצל המנהל")


# ───────── 4.6: 🔐 כספת ושחזור למחשב חדש (הבעלים בלבד) ─────────
import make_short_vault as VAULT  # noqa: E402
VAULTS = {"vis": None, "vis_at": 0.0, "kit": "", "kit_running": False, "kit_msg": ""}


def vault_visible():
    """הבעלים = עץ הפיתוח (מחובר לריפו), או שיש מפתח חתימה, או שכבר יש כספת במחשב (מחשב שהבעלים שחזר אליו)."""
    if VAULTS["vis"] is None or time.time() - VAULTS["vis_at"] > 60:
        try:
            v = REL.update_mode(REL.REPO) == "owner" or PROP.owner_visible() or VAULT.VAULT_FILE.is_file()
        except Exception:
            v = False
        VAULTS.update(vis=bool(v), vis_at=time.time())
    return VAULTS["vis"]


def vault_guard():
    if not vault_visible():
        raise OwnerOnly("המסך הזה זמין רק אצל המנהל")


def vault_status():
    s = VAULT.status()
    s.update(owner_screens=PUB.owner_screens_on() or PROP.owner_visible(), kit_running=VAULTS["kit_running"], kit_msg=VAULTS["kit_msg"], drive=drive_on_setting(), remote_name=VAULT.KIT_REMOTE_NAME)
    return s


def drive_on_setting():
    try:
        return bool(SET.load().get("drive_on", True))
    except Exception:
        return True


def vault_kit_run():
    """בונה את תיקיית "שחזור למחשב חדש" ומעלה אותה (backup_extras.sh kit). ברקע; בלי ערכים ביומן."""
    VAULTS.update(kit_running=True, kit_msg="מעלה את תיקיית השחזור ל-Drive…")
    try:
        if not drive_on_setting():
            VAULT.build_kit(say=lambda *_: None)
            VAULTS["kit_msg"] = "התיקייה נבנתה במחשב, אבל הגיבוי ל-Drive כבוי — היא תעלה כשתדליקו אותו."
            return
        p = subprocess.run(["bash", str(MS.SH / "backup_extras.sh"), "kit"], capture_output=True, text=True, timeout=3600,
                           cwd=str(MS.SH), start_new_session=True)
        if p.returncode == 75:
            VAULTS["kit_msg"] = "גיבוי אחר רץ עכשיו — התיקייה תעלה בגיבוי היומי."
        elif p.returncode == 0:
            VAULTS["kit_msg"] = "✓ תיקיית השחזור עודכנה ב-Drive (\"גיבוי תוכנה\" ← \"%s\")." % VAULT.KIT_REMOTE_NAME
        else:
            VAULTS["kit_msg"] = "⚠ ההעלאה ל-Drive לא הצליחה: %s" % HEALTH.scrub((p.stderr or p.stdout or "").strip()[-200:])
    except Exception as e:
        VAULTS["kit_msg"] = "⚠ %s" % VAULT._safe_msg(e)
    finally:
        VAULTS["kit_running"] = False
        app_log("=== %s vault kit: %s" % (time.strftime("%H:%M:%S"), VAULTS["kit_msg"][:120]))


def vault_kit_start():
    if not VAULTS["kit_running"]:
        threading.Thread(target=vault_kit_run, daemon=True).start()


def vault_source():
    """מאיפה משחזרים בחלון: העותק שב-Drive (אם מחובר) — אחרת העותק המקומי."""
    if drive_on_setting():
        tmp = MS.DATA_DIR / "vault_download.enc"
        try:
            rc = subprocess.run([HEALTH.RCLONE, "copyto", "%s/%s/vault.enc" % (os.environ.get("EXTRAS_REMOTE", "gdrive:גיבוי תוכנה"),
                                                                             VAULT.KIT_REMOTE_NAME), str(tmp)],
                                capture_output=True, timeout=120).returncode
            if rc == 0 and tmp.is_file():
                os.chmod(tmp, 0o600)
                return tmp
        except Exception:
            pass
    if VAULT.VAULT_FILE.is_file():
        return VAULT.VAULT_FILE
    raise ValueError("לא נמצאה כספת — לא ב-Drive (\"גיבוי תוכנה\" ← \"%s\") ולא במחשב." % VAULT.KIT_REMOTE_NAME)


def vault_health():
    """🩺 (הבעלים בלבד): אין כספת כשיש מפתח חתימה = אזהרה (המפתח היחיד נמצא רק במחשב הזה); אחרת שורה שקטה."""
    if not vault_visible():
        return None
    s = VAULT.status()
    steps = ["בהגדרות (בתצוגה 🛠️ מתקדם) ← \"🔐 כספת ושחזור למחשב חדש\" ← סיסמה פעמיים ← \"🔐 גבה לכספת\"",
             "את הסיסמה לשמור ב-Google Keep וגם לכתוב על נייר — בלעדיה אי אפשר לפתוח את הכספת"]
    if not s["exists"]:
        signing = any(a["id"] == "signing" and a["present"] for a in s["available"])
        if signing:
            return HEALTH.res("vault", "warn", "🔐 מפתח החתימה של העדכונים נמצא רק במחשב הזה",
                              "אם המחשב יאבד — אי אפשר יהיה לשלוח עדכונים למי שקיבל את התוכנה, וכולם יצטרכו להתקין מחדש. "
                              "הכספת שומרת אותו (ואת Gemini, Modal, Drive) מוצפן ב-Drive, ומחשב חדש חוזר בלחיצה כפולה.", steps)
        return HEALTH.res("vault", "ok", "🔐 עדיין אין כספת (מומלץ: מחשב חדש יחזור עם כל המפתחות) — בהגדרות ← 🔐 כספת ושחזור")
    if s["stale"] or s["new"]:
        return HEALTH.res("vault", "ok", "🔐 כספת קיימת, אבל משהו השתנה מאז — כדאי לגבות שוב (הגדרות ← 🔐 כספת ושחזור)")
    return HEALTH.res("vault", "ok", "🔐 כספת עדכנית · תיקיית \"שחזור למחשב חדש\" ב-Drive")


HEALTH.EXTRA["vault"] = vault_health


def vault_api(op, d):
    vault_guard()
    if op == "status":
        return vault_status()
    if op == "create":
        items = d.get("items")
        VAULT.create(str(d.get("passphrase") or ""), str(d.get("passphrase2") or ""),
                     [str(i) for i in items] if isinstance(items, list) and items else None)
        VAULTS["vis"] = None
        vault_kit_start()
        return vault_status()
    if op == "restore":
        src = vault_source()
        try:
            rep = VAULT.restore(str(d.get("passphrase") or ""), src, overwrite=bool(d.get("overwrite")))
        finally:
            if src.name == "vault_download.enc":
                src.unlink(missing_ok=True)
        return dict(vault_status(), report=rep)
    if op == "kit":
        vault_kit_start()
        return vault_status()
    if op == "owner_screens":                      # 4.6.5: להציג את "פרסם עדכון" ו"הצעות ממשתמשים" (מקומי, בלי רשת)
        PUB.set_owner_screens(bool(d.get("on", True)))
        return vault_status()
    raise ValueError("פעולה לא מוכרת")


def prop_check_run(pid):
    PROPS["checking"].add(pid)
    try:
        PROP.check_patch(pid, repo=REL.REPO)
    except Exception as e:
        try:
            m, _p = PROP.get_item(pid)
            PROP._save_check(m, {"at": time.time(), "applied": False, "selftest": None, "text": "הבדיקה לא רצה: %s" % str(e)[:200], "risks": []})
        except Exception:
            pass
    finally:
        PROPS["checking"].discard(pid)


def prop_post(path, d):
    try:
        if path == "/api/proposals/prepare":
            kind = str(d.get("kind") or "")
            patch, st, pc_ver = "", "", None
            pcid = str(d.get("personal_id") or "")
            if kind == "patch" and pcid:                  # 4.5: הצעת שינוי אישי אחד (מהמסך "שינויים אישיים שלי")
                _t, patch, why = PERS.proposal_payload(pcid)
                if not patch:
                    raise ValueError(why or "אין קוד להציע בשינוי הזה")
                st = ""                                   # 4.5.62: הבדיקה המהירה האחרונה היא על כל הקוד, לא על השינוי הזה — לא מצרפים
                pc_ver = PERS.proposal_base_version(pcid) or None
            elif kind == "patch":
                patch, why = PROP.local_patch(REL.REPO)
                if not patch:
                    raise ValueError(why or "אין שינויים מקומיים להציע")
                st = PROPS["selftest"] or ""
            diag = prop_diag() if d.get("with_diag") else ""
            r = PROP.prepare(kind, str(d.get("text") or ""), str(d.get("contact") or ""), diag, patch, st, bool(d.get("with_diag")),
                             kind == "patch", app_version=pc_ver)
            if pcid:
                PROPS.setdefault("personal", {})[r["draft"]] = pcid
            return {k: r[k] for k in ("draft", "digest", "preview", "bytes", "parts")}
        if path == "/api/proposals/confirm":
            PROP.confirm(str(d.get("draft") or ""), str(d.get("digest") or ""))
            _pid = PROPS.get("personal", {}).pop(str(d.get("draft") or ""), "")
            if _pid:
                PERS.note_event(_pid, "נשלח למנהל כהצעה")
            return prop_status()
        if path == "/api/proposals/contact":
            PROP.set_contact(str(d.get("contact") or ""), d.get("server"))
            return prop_status()
        if path == "/api/proposals/selftest":
            if PROPS["st_running"]:
                raise ValueError("הבדיקה כבר רצה")
            threading.Thread(target=prop_selftest_run, daemon=True).start()
            return {"ok": True}
        if path == "/api/proposals/sync":
            r = PROP.sync_sender()
            if PROP.owner_visible() and PROP.owner_status().get("has_channel"):
                r["owner"] = PROP.fetch_inbox()
            return {"sync": r, "status": prop_status()}
        if path == "/api/proposals/resend":
            PROP.resend_now(str(d.get("pid") or ""))
            return prop_status()
        if path == "/api/proposals/forget":
            PROP.forget(str(d.get("pid") or ""))
            return prop_status()
        if path.startswith("/api/proposals/owner/"):
            prop_owner_guard()
            op = path.rsplit("/", 1)[1]
            if op == "setup":
                PROP.setup_channel(str(d.get("server") or PROP.DEFAULT_SERVER))
            elif op == "rotate":
                PROP.rotate()
            elif op == "notify":
                PROP.notify_test()
            elif op == "backup":                       # 4.5.62 (#8): גיבוי מוצפן של מפתח ההצעות (עולה ל-Drive בגיבוי היומי)
                PROP.backup_encrypt(str(d.get("passphrase") or ""))
            elif op == "fetch":
                return {"fetch": PROP.fetch_inbox(), "status": prop_status()}
            elif op == "list":
                return {"items": PROP.inbox_list(), "status": prop_status()}
            elif op == "item":
                m, p = PROP.get_item(str(d.get("pid") or ""))
                if m["status"] == "new":
                    m = PROP.mark_read(m["pid"])
                patch = p.get("patch", "")
                return {"meta": m, "payload": {k: p.get(k, "") for k in ("kind", "name", "text", "diag", "selftest", "app_version", "sender_id")},
                        "patch": patch, "checking": m["pid"] in PROPS["checking"]}
            elif op == "check":
                pid = str(d.get("pid") or "")
                PROP.get_item(pid)
                if pid not in PROPS["checking"]:
                    threading.Thread(target=prop_check_run, args=(pid,), daemon=True).start()
                return {"ok": True}
            elif op == "act":
                PROP.act(str(d.get("pid") or ""), str(d.get("action") or ""), str(d.get("text") or ""))
            else:
                raise ValueError("פעולה לא מוכרת")
            return prop_status()
    except PROP.ProposalError as e:
        raise ValueError(str(e))
    return None


def prop_watch():
    """סנכרון שקט ברקע: שולח מה שממתין / שליחה חוזרת / תשובות; אצל הבעלים — שליפת התיבה. כשל רשת = שותקים. (מצב בדיקה: כבוי.)"""
    if SKIP_UPDATE or (os.environ.get("MAKE_SHORT_NO_EXPORT") and not os.environ.get("MAKE_SHORT_PROP_WATCH")):
        return
    time.sleep(40)
    while True:
        try:
            if PROP.load_channel():
                if any(r["status"] not in PROP.FINAL for r in PROP.outbox_view()):
                    PROP.sync_sender()
                if PROP.owner_visible() and PROP.owner_status().get("has_channel"):
                    PROP.fetch_inbox()
        except Exception:
            pass
        time.sleep(300)

FOCUS = {"at": 0.0}          # 4.1.3: הפעם האחרונה שדף פתוח *ובפוקוס* דיווח — לא מפעילים מחדש מתחת לאצבעות שלו


def code_tree_ready():
    """4.1.3: האם מותר לבדוק/להחיל עדכון קוד עכשיו: בעץ git של הבעלים — רק מצב שנשמר (commit) ומסומן בתגית (vX.Y.Z).
    בזמן עריכה (עץ מלוכלך, או commit בלי תגית) לא מתחילים בדיקה ולא מפעילים מחדש. התקנה בלי git (מקבל) — כמו קודם.
    MAKE_SHORT_UPDATE_GATE=off — לבדיקות. מחזיר (מותר, סיבה)."""
    if os.environ.get("MAKE_SHORT_UPDATE_GATE") == "off":
        return True, ""
    repo = HERE.parent.parent
    if not (repo / ".git").exists():
        return True, ""
    try:
        st = subprocess.run(["git", "-C", str(repo), "status", "--porcelain"], capture_output=True, text=True, timeout=20)
        if st.returncode != 0:
            return True, ""
        if st.stdout.strip():
            return False, "בעץ יש שינויים שלא נשמרו (commit)"
        if REL.update_mode(repo) == "receiver" and (repo / ".from_package").exists():
            # 4.5.62 (#6): אצל מקבל ה-HEAD הוא "רשמי + שינויים אישיים" ואין לו תגית גרסה — לא מחכים לתגית (לא תבוא לעולם);
            # רק לא באמצע החלה/כיבוי של שינוי אישי או עדכון (העץ משתנה אז)
            if PCS["busy"] or RELS["applying"]:
                return False, "באמצע החלה של שינוי אישי או עדכון"
            return True, ""
        tg =subprocess.run(["git", "-C", str(repo), "describe", "--tags", "--exact-match", "HEAD"],
                            capture_output=True, text=True, timeout=20)
        if tg.returncode != 0:
            return False, "ה-commit עוד בלי תגית גרסה"
    except Exception:
        return True, ""
    return True, ""


def code_check_now():
    """קבצי הקוד בדיסק נרגעו. אם הם שונים ממה שהשרת טען — בדיקה עצמית; עברה → "עדכון ממתין"."""
    h = SNAP.content_hash()
    if h == CODE["boot"]:                           # חזרו למה שהשרת טען (למשל ביטול עדכון) — אין מה לעדכן
        CODE["pending"] = CODE["failed"] = None
        CODE["checked"] = h
        CODE["held"] = False
        return
    ready, why = code_tree_ready()
    if not ready:                                   # 4.1.3: באמצע עריכה — מחכים; code_watch יבדוק שוב כשיישמר ויסומן
        if not CODE.get("held"):
            app_log("=== %s code changed on disk but not committed+tagged (%s) — waiting" % (time.strftime("%H:%M:%S"), why))
        CODE["held"] = True
        CODE["checked"] = ""
        CODE["pending"] = None
        return
    CODE["held"] = False
    if h == CODE["checked"]:
        return
    CODE["checked"] = h
    app_log("=== %s code changed on disk (%s -> %s) — self-check" % (time.strftime("%H:%M:%S"), CODE["boot"], h))
    ok, log = code_selfcheck()
    if SNAP.content_hash() != h:                    # השתנה שוב בזמן הבדיקה — הסיבוב הבא יבדוק מחדש
        CODE["checked"] = ""
        return
    if ok:
        CODE["pending"] = {"hash": h, "at": time.strftime("%H:%M"), "files": SNAP.changed_files(SNAP_BOOT) if SNAP_BOOT else []}
        CODE["failed"] = None
        app_log("=== code update ready (waits for an idle moment)")
    else:
        CODE["pending"] = None
        CODE["failed"] = {"hash": h, "at": time.strftime("%H:%M"), "log": log}
        app_log("=== code update FAILED self-check: %s" % log[-300:])


def code_restart_if_idle():
    """יש עדכון שעבר בדיקה: ברגע שאין שום עבודה — "מתעדכן" (הדף שומר טקסט שהוקלד), אחרי RESTART_GRACE שניות —
    הפעלה מחדש על הקוד החדש. עבודה שמתחילה בחלון הזה — נדחית ההפעלה מחדש (העבודה גוברת)."""
    if not CODE["pending"]:
        RESTARTING["on"] = False
        return
    now = time.time()
    if not server_idle() or now - FOCUS["at"] < 30:       # 4.1.3: גם לא כשהוא באמצע עבודה בדף (פוקוס)
        RESTARTING["on"] = False
        return
    if not RESTARTING["on"]:
        RESTARTING.update(on=True, at=now)
        return
    if now - RESTARTING["at"] < RESTART_GRACE:
        return
    with QLOCK:
        if not server_idle() or time.time() - FOCUS["at"] < 30 or not code_tree_ready()[0]:
            RESTARTING["on"] = False
            return
        app_log("=== %s restart onto new code %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), CODE["pending"]["hash"]))
        sys.stdout.flush()
        os.execv(sys.executable, [sys.executable] + sys.argv)


def code_watch():
    last_sig, last_change, last_clean, last_held = CODE["sig"], 0.0, time.time(), 0.0
    while True:
        time.sleep(3)
        try:
            sig, now = SNAP.stat_sig(), time.time()
            if CODE.get("held") and now - last_held > 15 and sig == last_sig and not last_change:
                last_held = now                      # 4.1.3: ממתין לשמירה+תגית — בודקים כל 15 שניות אם כבר
                code_check_now()
            if sig != last_sig:
                last_sig, last_change = sig, now
            elif last_change and now - last_change >= CODE_SETTLE and \
                    not any(j["running"] and j["kind"] in ("upd_apply", "upd_undo") for j in JOBS.values()) and not RELS["applying"]:
                last_change = 0.0                    # (בזמן עדכון מהחלון — העדכון בודק את עצמו; אחריו נבדוק מה שנשאר)
                code_check_now()
            code_restart_if_idle()
            if now - last_clean > 300:
                last_clean = now
                SNAP.clean(keep={CODE["boot"]})
        except Exception as e:                       # המעקב לעולם לא מת בגלל תקלה אחת
            app_log("=== code watch: %s" % e)


def code_info():
    return {"hash": CODE["boot"], "pending": CODE["pending"], "failed": CODE["failed"], "restarting": RESTARTING["on"],
            "busy": not server_idle()}


MAX_BODY = 64 * 2**20                   # 4.1.0: תקרה לגוף בקשה (הקובץ הגדול ביותר שמותר: מנגינה 25MB ב-base64)
UPLOAD_LIMITS = {"music": 26 * 2**20, "logo": 5 * 2**20, "cookies": 2 * 2**20}


def b64_limited(s, kind):
    """4.1.0: קובץ שמגיע כ-base64 מהדף — לא מפענחים לפני שבודקים שהוא לא ענק."""
    limit = UPLOAD_LIMITS[kind]
    if not isinstance(s, str) or not s:
        raise ValueError("לא התקבל קובץ")
    if len(s) * 3 // 4 > limit:
        raise ValueError("הקובץ גדול מדי (עד %d MB)" % (limit // 2**20))
    return base64.b64decode(s)


def err_text(e):
    """4.1.0: הודעת שגיאה לדף — בלי נתיבי הבית של המחשב (שם משתמש) ובלי סודות."""
    s = HEALTH.scrub(str(e))
    home = os.path.expanduser("~")
    if home and home != "/":
        s = s.replace(home, "~")
    s = re.sub(r"/home/[^/\s'\"]+", "~", s)
    return re.sub(r"/mnt/c/Users/[^/\s'\"]+", "C:/Users/…", s)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        if not isinstance(body, (bytes, bytearray)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = -1
        if n < 0 or n > MAX_BODY:                  # 4.1.0: שלילי / ענק — לא קוראים, והחיבור נסגר
            self.close_connection = True
            raise ValueError("הבקשה לא תקינה או גדולה מדי")
        raw = self.rfile.read(n)
        if len(raw) != n:
            self.close_connection = True
            raise ValueError("הבקשה נקטעה")
        return json.loads(raw.decode("utf-8") or "{}")

    def same_origin_only(self):
        """4.1.0: GET שמשנה משהו (בדיקה מחדש / רענון) — רק מהדף של התוכנה: Sec-Fetch-Site=same-origin (דפדפן), או — בלי
        כותרת כזאת (סקריפט מקומי) — Origin תקין. בקשה בלי אף אחד משניהם נדחית."""
        site = (self.headers.get("Sec-Fetch-Site") or "").lower()
        if site:
            return site in ("same-origin", "none")
        origin = self.headers.get("Origin")
        return origin is not None and origin.lower() in {"http://%s:%d" % (h, PORT) for h in ("127.0.0.1", "localhost", "[::1]")}

    def refused(self, post):
        """29/10 (סקירה חיצונית): אתר זר בדפדפן שלו לא יכול לדבר עם השרת.
        Host — רק 127.0.0.1/localhost בפורט שלנו (חוסם DNS rebinding, גם ב-GET);
        POST — רק JSON, ו-Origin (כשיש) מהדף שלנו; Sec-Fetch-Site=cross-site נדחה
        (מלבד מעבר רגיל לדף הראשי, למשל קישור). urllib / PowerShell לא שולחים Origin — עוברים."""
        hosts = {"%s:%d" % (h, PORT) for h in ("127.0.0.1", "localhost", "[::1]")}
        if (self.headers.get("Host") or "").lower() not in hosts:
            return "host"
        site = (self.headers.get("Sec-Fetch-Site") or "").lower()
        if not post:
            if site == "cross-site" and not (self.headers.get("Sec-Fetch-Mode") == "navigate"
                                             and urlparse(self.path).path == "/"):
                return "cross-site"
            return None
        if site not in ("", "same-origin", "none"):
            return "cross-site"
        origin = self.headers.get("Origin")
        if origin is not None and origin.lower() not in {"http://" + h for h in hosts}:
            return "origin"
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            return "content-type"
        return None

    def do_GET(self):
        if self.refused(False):
            return self.send(403, {"error": "הבקשה לא הגיעה מחלון התוכנה"})
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/":
                return self.send(200, (HERE / "make_short_page.html").read_bytes(), "text/html; charset=utf-8")
            if u.path == "/api/alive":
                return self.alive()
            if u.path == "/sw.js":
                # כרטיס 12: כדי שאפשר יהיה "להתקין" את הדף כאפליקציה (ואז נקודה על הסמל בשורת המשימות —
                # navigator.setAppBadge). כל בקשה הולכת לשרת כמו תמיד. 28/10: רק כשהשרת לא עונה לפתיחת חלון
                # (הסמל של האפליקציה המותקנת לא מפעיל אותו) — דף "התוכנה מתחילה…" מהמטמון, שמפעיל ומחכה
                return self.send(200, b"const C='ys-offline-1';"
                                      b"self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(['/offline.html','/icon-192.png'])));self.skipWaiting()});"
                                      b"self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));"
                                      b"self.addEventListener('fetch',e=>{if(e.request.mode!=='navigate')return;"
                                      b"e.respondWith(fetch(e.request).catch(()=>caches.match('/offline.html')))});",
                                 "text/javascript; charset=utf-8")
            if u.path == "/offline.html":
                return self.send(200, (APP_DIR / "offline.html").read_bytes(), "text/html; charset=utf-8")
            if u.path in ICONS:
                f, ctype = ICONS[u.path]
                return self.send(200, (APP_DIR / f).read_bytes(), ctype)
            if u.path == "/font/heebo900":
                return self.stream(HEEBO, "font/ttf")
            if u.path in ("/font/ysmarker", "/font/ysfloat"):         # 30/10: גופני "מרקר" ו"ריחוף" לתצוגה המקדימה
                return self.stream(HEEBO.parent / ("YSMarkerBold.ttf" if u.path.endswith("marker") else "YSFloatHeebo.ttf"), "font/ttf")
            if u.path == "/api/sub_lines":
                p, _ = load_state(q["p"])
                return self.send(200, MS.sub_lines(p, re.sub(r"[^\w]", "", q["n"]), q.get("emph")))
            if u.path == "/api/emph":                    # 🔠 הגדלת מילים של קליף (כרטיס 15)
                p, _ = load_state(q["p"])
                return self.send(200, MS.emph_view(p, re.sub(r"[^\w]", "", q["n"])))
            if u.path == "/api/hook":                    # 🎬 הוק של קליף (6/11)
                p, _ = load_state(q["p"])
                return self.send(200, MS.hook_view(p, re.sub(r"[^\w]", "", q["n"])))
            if u.path == "/api/layout":                  # "📐 פריסת שורות" של קליף מוכן
                p, _ = load_state(q["p"])
                wj = p / ("work/subtitles/%s_words.json" % re.sub(r"[^\w]", "", q["n"]))
                if not wj.exists():
                    raise ValueError("לקליף הזה עוד אין כתוביות — קודם ליצור אותו")
                return self.send(200, LAYOUT.view(p, q["n"], json.load(open(wj, encoding="utf-8"))["words"]))
            if u.path == "/api/preview":
                return self.send(200, preview_view(q["id"]))
            if u.path == "/preview_file":
                pv = PREVIEWS[q["id"]]
                if not pv["ok"]:
                    raise ValueError("התצוגה עוד לא מוכנה")
                pv["seen"] = time.time()
                return self.stream(Path(pv["file"]), "video/mp4")
            if u.path == "/api/lessons":
                kick_queue()
                running = [j for j in JOBS.values() if j["running"]]
                return self.send(200, {"lessons": lessons(), "health_running": HEALTH_STATE["running"],
                                       "health": health_view(),
                                       "code": code_info(),
                                       "net": NET["ok"], "drive": drive_view(), "modal_meter": modal_meter_view(),
                                       "share_stale": share_stale_view(),
                                       "busy": len(running),        # כולל עבודות שמחכות בתור
                                       "queue": queue_view(),
                                       "offline_ready": len(offline_ready_projects()),
                                       # שיעור שבתור ממשיך לבד — לא צריך כפתור "המשך"
                                       "interrupted": [{"project": str(d), "title": file_state(d)[1]}
                                                       for d in (TOOL.glob("*") if TOOL.exists() else [])
                                                       if d.is_dir() and not busy(d) and PR.job_state(d) == "interrupted"
                                                       and str(d) not in queued_projects()]})
            if u.path == "/api/queue":
                return self.send(200, queue_view())
            if u.path == "/api/past":
                return self.send(200, {"lessons": past_lessons()})
            if u.path == "/api/context":
                p, _ = load_state(q["p"])
                if not NET["ok"]:
                    try:                                 # בלי אינטרנט — רק מה שכבר במטמון / בתמלול השיעור
                        return self.send(200, MS.context_words(p, q["n"]))
                    except Exception:
                        raise ValueError("אין אינטרנט — אי אפשר לתמלל את מה שסביב הקליף עכשיו")
                return self.send(200, MS.context_words(p, q["n"]))
            if u.path == "/api/scene":                   # 28/10: "📜 הקטע והסביבה שלו" בשלב הסופי
                p, _ = load_state(q["p"])
                return self.send(200, MS.scene_words(p, re.sub(r"[^\w]", "", q["n"])))
            if u.path == "/source_audio":
                p, _ = load_state(q["p"])
                return self.send(200, source_audio(p, q["a"], q["b"]), "audio/wav")
            if u.path == "/api/pick":
                P, _ = load_pick(q["p"])
                return self.send(200, pick_view(P))
            if u.path == "/api/pick/prompt":
                P, st = load_pick(q["p"])
                return self.send(200, {"text": PICK.chunk_prompt(st, q["c"])})
            if u.path == "/api/gemini":
                return self.send(200, PICK.gemini_status())
            if u.path == "/api/modal_meter":            # 🔄 ליד מד Modal (כרטיס 14)
                if q.get("refresh"):
                    if not self.same_origin_only():
                        return self.send(403, {"error": "הבקשה לא הגיעה מחלון התוכנה"})
                    modal_meter_refresh()
                return self.send(200, modal_meter_view())
            if u.path == "/api/job":
                if q["id"] not in JOBS:                  # השרת התחדש מאז — העבודה כבר לא בזיכרון: נגמרה (הדף בודק את הקבצים)
                    return self.send(200, {"id": q["id"], "running": False, "ok": None, "gone": True, "log": []})
                return self.send(200, JOBS[q["id"]])
            if u.path == "/api/home":
                return self.send(200, {"folders": folders(), "settings": SET.state(), "rules": SET.rules_text(),
                                       "test_mode": MS.TEST_MODE, "version": tool_version()})
            if u.path == "/api/settings":
                return self.send(200, SET.state())
            if u.path == "/api/rabbis":
                return self.send(200, RABBIS.view())
            if u.path == "/api/tools":
                return self.send(200, TOOLS.scan())
            if u.path == "/api/health":
                if q.get("refresh") and not self.same_origin_only():
                    return self.send(403, {"error": "הבקשה לא הגיעה מחלון התוכנה"})
                if q.get("refresh") or (HEALTH_STATE["data"] is None and not HEALTH_STATE["running"]):
                    refresh_health()
                return self.send(200, health_view())
            if u.path == "/api/report":
                return self.send(200, {"text": report_text(q.get("job", ""), q.get("full") == "1")})
            if u.path == "/api/music":
                return self.send(200, music_payload())
            if u.path == "/api/project":
                p, st = load_state(q["p"])
                for c in st["clips"]:
                    c.update(MS.read_edit_raw(p / c["edit"]))
                    d = final_dir(p, c["name"])
                    c["final"] = bool(d)
                    c["sub_rgb"] = MS.clip_rgb(c["name"], p)
                    c["emph_on"] = EMPH.is_on(p, c["name"])      # 🔠 (כרטיס 15)
                    c["wps"] = MS.clip_rate(p, c["name"])        # 30/10: מילים בשנייה — אזהרת "ריחוף מילים" (דיבור איטי בלבד)
                    c["hook_eff"] = MS.hook_active(c, SET.load())  # 🎬 6/11: הוק דולק בקליף (הבחירה שלו, אחרת ההגדרה הכללית)
                    c["hook_text"] = (c.get("hook") or {}).get("text", "") if c.get("hook_built") else ""
                    c["exits"] = clip_exits(p, c)                # 🎥 הרב יוצא מהמסגרת (כרטיס 22)
                    if d and "track" not in c:          # קליפים מלפני 21/10 — המנגינה רק ב-meta
                        try:
                            c["track"] = json.load(open(d / "meta.json", encoding="utf-8")).get("music")
                        except (OSError, ValueError):
                            pass
                st["last_job"] = next((j["id"] for j in reversed(list(JOBS.values())) if j["project"] == str(p)), "")
                # שיעור שיוצא לפני 21/10 (בלי "saved") — נחשב שמור כמו שהוא
                if st.get("export_target") and st.get("finished") and not st.get("saved"):
                    st["saved"] = {"at": st["finished"], "snap": MS.snapshot(p, st),
                                   "clips": [c["name"] for c in st["clips"] if not c.get("dropped")], "legacy": True}
                    MS_save_state(p, st)
                st["unsaved"] = MS.unsaved(p, st)
                st["unsaved_clips"] = MS.unsaved_clips(p, st)         # 28/10: "💾 שמור את הקליף הזה"
                for c in st["clips"]:
                    c["auto_pick"] = c["name"] in (st.get("auto_picked") or [])    # "⚠ נבחר אוטומטית"
                    try:                                # באג "D9": צבע זהב בכתובית עם אותיות לועזיות — אפשר לצרוב מחדש
                        a = (p / ("work/subtitles/%s.ass" % c["name"])).read_text(encoding="utf-8-sig")
                        c["color_glitch"] = bool(re.search(r"^Dialogue:.*\\c&H", a, re.M))
                    except OSError:
                        c["color_glitch"] = False
                try:
                    st["auto_note"] = PICK.load(p).get("auto_note", "") if (p / PICK.PICK).exists() else ""
                except (OSError, ValueError):
                    st["auto_note"] = ""
                st["clip_jobs"] = clip_jobs(p)
                # כרטיס 25: מה הפרופיל של הרב עושה בשיעור הזה + הצעות "להוסיף לפרופיל?" (אחרי 2 תיקונים זהים)
                _pf = RABBIS.get(st.get("rabbi") or "")
                st["profile"] = ({"name": _pf["name"], "sub_gap": _pf["sub_gap"], "dedupe": _pf["dedupe_repeats"],
                                  "camera": _pf["camera"], "words": len(_pf["words"]),
                                  "offers": RABBIS.offers(_pf["name"])} if _pf else None)
                st["editor"] = editor_view(p)           # 28/10: העורך החכם — ממתין / נשלח / הסתיים / צ'אט
                for c in st["clips"]:                   # גרסת קובץ העריכה — מיזוג תיקונים שנעשו בזמן בנייה מחדש
                    c["ver"] = MS.edit_ver(p / c["edit"])
                st["state"] = lesson_state(p)
                st["cleaning"] = str(p.resolve()) in CLEANING         # כרטיס 17: "🧹 מתנקה…" — הכפתורים נעולים
                st["progress"] = PR.load(p)
                st["net"] = NET["ok"]
                live = [c for c in st["clips"] if not c.get("dropped")]
                st["warnings"] = SET.rule_warnings([c["seconds"] for c in live])
                st["export_win"] = MS.win_path(st["export_target"]) if st.get("export_target") else ""
                st["folders"] = folders()               # רשימת הרבנים/הסדרות טרייה (רב חדש שנשמר עכשיו — כרטיס 16)
                return self.send(200, st)
            if u.path == "/video":
                p, st = load_state(q["p"])
                c = next(c for c in st["clips"] if c["name"] == q["n"])
                f = p / c["clean"]
                if q.get("final"):
                    d = final_dir(p, c["name"])
                    f = sorted(d.glob("*.mp4"))[0] if d else f
                return self.stream(f, "video/mp4")
            if u.path == "/api/fix/state":               # 🛠️ תיקון בצ'אט (כרטיס 27): הסטטוס של התיקון האחרון בקליף
                p, st = load_state(q["p"])
                return self.send(200, fix_state(p, re.sub(r"[^\w]", "", q["n"])))
            if u.path in ("/fix_video", "/fix_frame"):    # לפני/אחרי של תיקון בצ'אט
                p, st = load_state(q["p"])
                f, ctype = fix_media(p, re.sub(r"[^\w]", "", q["n"]), re.sub(r"[^\w]", "", q.get("id", "")), q.get("which", "new"),
                                     u.path == "/fix_frame")
                return self.stream(f, ctype)
            if u.path == "/audio":
                return self.stream(MUSIC.audio_path(q["u"]), "audio/mpeg")
            if u.path == "/logo_preview":
                return self.send(200, logo_preview(), "image/png")
            if u.path == "/logo_img":
                return self.send(200, logo_image(q.get("f", "")), "image/png")
            if u.path == "/api/logos":
                return self.send(200, {"logos": logo_files()})
            if u.path == "/api/share/info":
                return self.send(200, share_info())
            if u.path == "/api/share/profiles":          # 3.5
                return self.send(200, {"profiles": SHARE.profiles_view()})
            if u.path == "/share_profile_logo":          # 3.5: תמונה קטנה של הלוגו בפרופיל
                f = SHARE._pdir(q.get("id", "")) / "logo.png"
                return self.send(200, f.read_bytes() if f.is_file() else b"", "image/png")
            if u.path == "/api/proposals/status":          # 4.4
                return self.send(200, prop_status())
            if u.path == "/api/release/status":           # 4.3
                return self.send(200, rel_status())
            if u.path == "/api/personal/status":          # 4.5
                return self.send(200, pc_status())
            if u.path == "/api/update/rules":
                return self.send(200, {"text": update_rules()})
            if u.path == "/api/update/status":
                return self.send(200, UPD.status())
        except Exception as e:
            return self.send(400, {"error": err_text(e)})
        self.send(404, {"error": "לא נמצא"})

    def alive(self):
        """חיבור שנשאר פתוח כל עוד הדף פתוח. כל 10 שניות שורה ריקה — כך נדע שהחלון נסגר."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with LOCK:
            ALIVE["open"] += 1
        import select
        try:
            while True:
                self.wfile.write(b": ok\n\n")
                self.wfile.flush()
                # הדף לא שולח כלום בחיבור הזה — אם הוא "נקרא", זה סימן שהחלון נסגר (EOF) — מיד, בלי לחכות לכתיבה
                if select.select([self.connection], [], [], 10)[0] and not self.connection.recv(1):
                    break
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            with LOCK:
                ALIVE["open"] -= 1
                ALIVE["last"] = time.time()

    def stream(self, f, ctype):
        size = f.stat().st_size
        a, b = 0, size - 1
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range") or "")
        if m:
            a = int(m.group(1) or 0)
            b = min(int(m.group(2)) if m.group(2) else size - 1, size - 1)
        self.send_response(206 if m else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(b - a + 1))
        self.send_header("Cache-Control", "no-store")
        if m:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
        self.end_headers()
        with open(f, "rb") as fh:
            fh.seek(a)
            left = b - a + 1
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                left -= len(chunk)

    def do_POST(self):
        if self.refused(True):
            return self.send(403, {"error": "הבקשה לא הגיעה מחלון התוכנה"})
        u = urlparse(self.path)
        try:
            d = self.body()
            r = self.post(u.path, d)
            if r is not None:
                return self.send(200, r)
        except OwnerOnly as e:                      # 4.5.x (A10): מסכי הבעלים — 403 אמיתי למי שאינו הבעלים
            return self.send(403, {"error": str(e)})
        except Exception as e:
            return self.send(400, {"error": err_text(e)})
        self.send(404, {"error": "לא נמצא"})

    def post(self, path, d):
        if path == "/api/prepare":
            clips = [c for c in d.get("clips", []) if (c.get("pieces") or "").strip()]
            if not clips:
                MS.auto_pick(d)                         # השלב הבא; עכשיו — הודעה ברורה
            for c in clips:
                MS.parse_pieces(c["pieces"])           # שגיאה בזמנים — מיד, לפני הורדה
            url = MS.check_url(d.get("url"))          # 4.1.0: רק קישור יוטיוב — ערך אחר היה מגיע ל-yt-dlp כאופציה
            if any(j["running"] and j.get("url") == url for j in JOBS.values()):
                raise ValueError("השיעור הזה כבר בהכנה")
            need_net("הורדת השיעור")
            SPECS.mkdir(parents=True, exist_ok=True)
            spec = SPECS / ("spec_%s_%d.json" % (time.strftime("%Y%m%d_%H%M%S"), os.getpid()))
            P = MS.project_for(url) or TOOL / ("%s_auto" % time.strftime("%Y-%m-%d_%H%M%S"))
            if (P / MS.STATE).exists() or str(P) in queued_projects():   # כבר הוכן פעם — תיקייה חדשה, לא דורסים
                P = P.with_name(P.name + "_" + time.strftime("%H%M%S"))
            spec.write_text(json.dumps(dict(d, clips=clips, project=str(P)), ensure_ascii=False), encoding="utf-8")
            return {"job": enqueue("prepare", ["prepare", spec], P, url, url=url)}
        # בחירה אוטומטית
        if path == "/api/pick/start":
            need_net("סריקת השיעור")
            return {"job": pick_start(d)}
        if path == "/api/pick/paste":
            P, _ = load_pick(d["project"])
            if busy(P):
                raise ValueError("הסריקה עוד רצה — לחכות שתסתיים")
            with LOCK:
                st = PICK.load(P)
                cid = d.get("chunk", "")
                n, warns = (PICK.add_rank_answer if cid.startswith("r") else PICK.add_answer)(st, d.get("text", ""), cid)
                (P / "pick").mkdir(exist_ok=True)
                (P / "pick" / ("pasted_%s_%s.txt" % (d.get("chunk", ""), time.strftime("%H%M%S")))).write_text(
                    d.get("text", ""), encoding="utf-8")
                PICK.save(P, st)
            if st.get("auto_pause") and not cid.startswith("r"):   # 28/10: האוטומטי עצר לצ'אט — ממשיכים לבד
                try:
                    auto_burn_after_pick({"project": str(P)}, srcs=("gemini", "chat"))
                except Exception as e:
                    app_log("=== auto burn after paste: %s" % e)
            return {"added": n, "warnings": warns, "state": pick_view(P)}
        if path == "/api/pick/request":
            # כרטיס 25: שינוי "מה לחפש" ו"🔍 חפש שוב" — Gemini רק אם ההגדרה של הצעד היא "מפתח" ויש מפתח שעובד; אחרת
            # ההנחיות המעודכנות מחכות ב"העתק לצ'אט" (אותו נוסח, כולל הבקשה)
            P, st = load_pick(d["project"])
            if busy(P):
                raise ValueError("הסריקה עוד רצה — לחכות שתסתיים")
            with LOCK:
                st, changed = PICK.set_request(P, d.get("request", ""), force=bool(d.get("again")))
            g = PICK.gemini_status()
            direct = bool(st.get("use_gemini", True) and g.get("has_key") and not g.get("key_blocked") and PICK.step_direct("pick"))
            if d.get("ask") and direct and (changed or d.get("again")):
                need_net("Gemini")
                return {"job": start_job("pick", pick_cmd("gemini", P), P, st.get("title", "")), "changed": changed,
                        "state": pick_view(P)}
            return {"changed": changed, "state": pick_view(P), "chat": bool(d.get("ask") and not direct)}
        if path == "/api/pick/gemini":
            need_net("Gemini")
            P, st = load_pick(d["project"])
            return {"job": start_job("pick", pick_cmd("gemini", P), P, st.get("title", ""))}
        if path == "/api/pick/transcribe":
            need_net("התמלול")
            P, st = load_pick(d["project"])
            mode = d.get("mode") if d.get("mode") in ("all", "missing") else "missing"
            args = ["transcribe", P, mode] + (["--yes"] if d.get("yes") else [])
            return {"job": start_job("pick", pick_cmd(*args), P, st.get("title", ""))}
        if path == "/api/pick/stageb":
            # שלב ב' של פלייליסט גדול: רק השיעורים שסומנו מתומללים ב-Modal ומקבלים הצעות
            need_net("תמלול השיעורים שנבחרו")
            P, st = load_pick(d["project"])
            nums = sorted({int(n) for n in d.get("lessons", [])})
            if not nums:
                raise ValueError("לא סומן אף שיעור")
            args = ["stageb", P, ",".join(map(str, nums))] + (["--yes"] if d.get("yes") else [])
            return {"job": start_job("pick", pick_cmd(*args), P, st.get("title", ""))}
        if path == "/api/pick/mode":
            P, st = load_pick(d["project"])
            if busy(P):
                raise ValueError("הסריקה עוד רצה — לחכות שתסתיים")
            with LOCK:
                PICK.switch_mode(P, d.get("mode", ""))
            return pick_view(P)
        if path == "/api/pick/more":
            P, st = load_pick(d["project"])
            if busy(P):
                raise ValueError("הסריקה עוד רצה — לחכות שתסתיים")
            with LOCK:
                PICK.request_more(P, d["lesson"])
            return pick_view(P)
        if path == "/api/pick/estimate":
            return PICK.estimate_playlist(MS.check_url(d.get("url")))
        if path == "/api/pick/update":
            return pick_update(d)
        if path == "/api/pick/build":
            return pick_build(d)
        if path == "/api/queue/edit":
            return queue_edit(d)
        if path == "/api/queue/netonly":             # "⏸ הכן לעבודה בלי אינטרנט" — מצב שנשמר עם התור
            with QLOCK:
                QSTATE["net_only"] = bool(d.get("on"))
                queue_save()
            kick_queue()
            return queue_view()
        if path == "/api/offline/continue":          # "▶ המשך בלי אינטרנט" — שיעור אחד או כל המוכנים
            return {"queued": offline_continue(d.get("project") or None)}
        if path == "/api/gemini/key":
            PICK.save_key(d.get("key", ""))
            ok, msg = PICK.check_key()
            recheck(["gemini"], wait=True)                      # ההתראה למעלה מתעדכנת מיד (מקומי)
            return {"ok": ok, "msg": msg, "status": PICK.gemini_status()}
        if path == "/api/gemini/check":
            ok, msg = PICK.check_key(d.get("key") or None)      # מה שבתיבה, ואם ריקה — השמור
            recheck(["gemini"], wait=True)
            return {"ok": ok, "msg": msg, "status": PICK.gemini_status()}
        if path == "/api/rules_check":
            return {"warnings": SET.rule_warnings([float(x) for x in d.get("seconds", [])])}
        if path == "/api/save":
            return save_edits(d)
        if path == "/api/finish":
            p, st = load_state(d["project"])
            names = [c["name"] for c in st["clips"] if not c.get("dropped")]
            one = [x for x in (d.get("clips") or []) if x in names]
            if (st.get("editor") or {}).get("status") in ("pending", "sending"):
                editor_skip(p, "manual")             # סיים לפני העורך — הטקסט שלו כמו שהוא; העורך לא ידרוס אחר כך
                p, st = load_state(d["project"])
            return finish_clips(p, st, one or names)
        # 28/10 — העורך החכם
        if path == "/api/pick/send_now":             # בחירה: "שאל עכשיו" — בלי לחכות לשיעורים אחרים
            P, _ = load_pick(d["project"])
            need_net("Gemini")
            PICKHOLD["force"].add(str(P))
            pick_tick()
            return {"ok": True}
        if path == "/api/editor/send":               # "שלח עכשיו" — בלי לחכות לשיעורים האחרים
            p, _ = load_state(d["project"])
            need_net("העורך החכם")
            EDITOR["force"].add(str(p))
            EDITOR["manual"].add(str(p))
            editor_tick()
            return {"ok": True, "editor": editor_view(p)}
        if path == "/api/focus":                     # 4.1.3: הדף פתוח ובפוקוס — לא מפעילים מחדש את התוכנה מתחתיו
            if d.get("on"):
                FOCUS["at"] = time.time()
            return {"ok": True}
        if path == "/api/editor/stop":               # 4.1.1 "⛔ עצור את העורך" — בלי העורך, הטקסט נשאר
            p, _ = load_state(d["project"])
            editor_stop(p)
            return {"ok": True, "editor": editor_view(p)}
        if path == "/api/editor/skip":               # "דלג על העורך" / "צרוב בלי העורך"
            p, _ = load_state(d["project"])
            editor_skip(p)
            return {"ok": True, "editor": editor_view(p)}
        if path == "/api/editor/again":              # שוב (למשל אחרי שהמכסה התאפסה) — בבקשה משותפת כרגיל
            p, _ = load_state(d["project"])
            if busy(p):
                raise ValueError("השיעור בעבודה עכשיו — לחכות שתסתיים")
            EDITOR["manual"].add(str(p))                 # 4.1.1: ידני — עוקף את "Gemini עמוס לאחרונה" (תמיד מנסים)
            _ed_write(p, lambda e: e.update(status="pending", since=time.time(), msg="", auto_stop=None, skipped=False))
            EDITOR["force"].add(str(p))                  # ידני = מיד, בלי חלון ההמתנה
            return {"ok": True, "editor": editor_view(p)}
        if path == "/api/editor/chat":               # הבלוק להעתקה לצ'אט (טקסטים + כללים, בלי שמע)
            p, _ = load_state(d["project"])
            text, n = ED.chat_block([p])
            return {"text": text, "clips": n}
        if path == "/api/editor/paste":
            p, _ = load_state(d["project"])
            if busy(p):
                raise ValueError("השיעור בעבודה עכשיו — לחכות שתסתיים")
            with ED_LOCK:
                res = ED.paste([p], d.get("text") or "")
            editor_continue(p, "skip")
            return {"result": res.get(str(p)) or [], "editor": editor_view(p)}
        if path == "/api/editor/alts":               # "🔍 חפש הצעות אחרות" — בקשה אחת לכל הספקות של הקליף
            p, _ = load_state(d["project"])
            clip = re.sub(r"[^\w]", "", d["clip"])
            # 28/10: אף פעם לא מבוי סתום — בחר "העתק לצ'אט" לשלב הזה, או ש-Gemini לא זמין → הבלוק לצ'אט במקום שגיאה
            if not PICK.step_direct("alts") or not NET["ok"]:
                return {"chat_needed": PICK.CHAT_MODE_MSG if NET["ok"] else "אין אינטרנט — אפשר דרך צ'אט",
                        "chat": ED.alts_chat(p, clip, d.get("text") or "")}
            try:
                res = ED.alts(p, clip, d.get("text") or "")
            except PICK.GeminiStop as e:
                return {"chat_needed": str(e), "chat": ED.alts_chat(p, clip, d.get("text") or ""),
                        "gemini": PICK.gemini_status()}
            return {"alts": res, "gemini": PICK.gemini_status()}
        if path == "/api/editor/alts_paste":         # התשובה מהצ'אט ל"חפש הצעות אחרות" — אותו פענוח ושמירה
            p, _ = load_state(d["project"])
            return {"alts": ED.alts(p, re.sub(r"[^\w]", "", d["clip"]), d.get("text") or "", answer=d.get("answer") or "")}
        if path == "/api/rabbis":                # כרטיס 25: פרופיל לכל רב — הגדרות, אפס / בטל, והצעות "להוסיף לפרופיל?"
            a = d.get("action")
            if a == "save":
                RABBIS.save(d.get("name", ""), d.get("fields") or {})
            elif a == "reset":
                RABBIS.reset(d.get("name", ""))
            elif a == "undo":
                RABBIS.undo(d.get("name", ""))
            elif a == "offer":
                RABBIS.answer_offer(d.get("name", ""), d.get("wrong") or None, d.get("right", ""), bool(d.get("accept")))
            elif a:
                raise ValueError("פעולה לא מוכרת")
            return RABBIS.view()
        if path == "/api/repeat_undo":           # כרטיס 25: "בטל" לחזרה שהוסרה — החור נסגר והקליף נבנה מחדש (בתור, כמו הזזת גבול)
            p, st = load_state(d["project"])
            need_net("בנייה בגבולות חדשים (תמלול)")
            return {"job": enqueue("retime", ["undo_repeat", p, d["clip"], int(d["i"])], p, st.get("video_title", ""),
                                   clip=d["clip"])}
        if path == "/api/glossary":
            if d.get("action"):
                ED.glossary_edit(d["action"], d.get("right", ""), d.get("wrong", ""))
            return dict(ED.glossary_view(), quality=ED.quality_summary())
        if path == "/api/save_lesson":           # "💾 שמור לתיקייה" — ייצוא + דרייב (או תור, בלי אינטרנט)
            p, st = load_state(d["project"])
            return save_start(p, st, d.get("clips"))
        if path == "/api/resume":
            return {"job": resume(d["project"], d.get("allow"))}
        if path == "/api/drop":
            p, st = load_state(d["project"])
            c = next(c for c in st["clips"] if c["name"] == d["clip"])
            # כרטיס 14 (בקרת סתירות): ויתור על קליף שיש לו עבודה בתור — עבודה שרצה עכשיו: מחכים לה (אחרת היא
            # כותבת טיוטה לקליף שכבר הוצא); עבודות שרק ממתינות לו — יוצאות מהתור לבד, ונאמר לו
            removed = drop_clip_jobs(p, c["name"])
            saved_copy = bool(st.get("saved") and d["clip"] in (st["saved"].get("clips") or []) and st.get("export_target"))
            if saved_copy:
                return {"job": start_job("drop_saved", ms_cmd("drop_saved", p, c["name"]), p, st.get("video_title", "")),
                        "removed": removed}
            r = subprocess.run(ms_cmd("drop", p, c["name"]), capture_output=True, text=True, errors="replace")
            if r.returncode:
                raise ValueError((r.stdout + r.stderr).strip().splitlines()[-1])
            return {"ok": True, "removed": removed}
        if path == "/api/uploaded":                  # "✓ הועלה" / "בטל סימון" (כרטיס 17) — רק סימון
            return mark_uploaded(d)
        if path == "/api/clean/plan":                # "🧹 נקה" — הסיכום לפני אישור (לא נוגע בכלום)
            return clean_plan(d)
        if path == "/api/clean/run":                 # אחרי אישור — עבודה עם התקדמות; הכול לסל המיחזור
            return clean_start(d)
        if path == "/api/clean/dismiss":             # כרטיס 23: ✕ על ניקוי שנגמר/נכשל בחלונית התור
            j = JOBS.get(str(d.get("job") or ""))
            if not j or j["kind"] != "clean" or j["running"]:
                raise ValueError("אין ניקוי שנגמר בשם הזה")
            j["dismissed"] = True
            return {"ok": True}
        if path == "/api/restore":
            p, st = load_state(d["project"])
            r = subprocess.run(ms_cmd("restore", p, d["clip"]), capture_output=True, text=True, errors="replace")
            if r.returncode:
                raise ValueError((r.stdout + r.stderr).strip().splitlines()[-1])
            return {"ok": True}
        if path == "/api/retime":
            p, st = load_state(d["project"])
            pieces = [[round(float(a), 2), round(float(b), 2)] for a, b in d["pieces"]]
            if any(b - a < 1.0 for a, b in pieces):
                raise ValueError("חלק קצר מדי")
            need_net("בנייה בגבולות חדשים (תמלול)")
            return {"job": enqueue("retime", ["retime", p, d["clip"], json.dumps(pieces)], p, st.get("video_title", ""),
                                   clip=d["clip"])}
        if path == "/api/open_export":            # "📂 פתח את התיקייה" במסך "השיעור הושלם"
            p, st = load_state(d["project"])
            t = Path(st.get("export_target") or "")
            root = MS.export_root()
            if not (t.is_dir() and root and root.resolve() in t.resolve().parents):
                raise ValueError("התיקייה לא נמצאה")
            w = subprocess.run(["wslpath", "-w", str(t)], capture_output=True, text=True, timeout=10).stdout.strip()
            subprocess.Popen(["/mnt/c/Windows/explorer.exe", w], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, cwd="/mnt/c")
            return {"ok": True}
        if path == "/api/tab/close":
            set_hidden(Path(d["project"]).resolve(), True)
            return {"ok": True}
        if path == "/api/tab/open":
            pr = Path(d["project"]).resolve()
            set_hidden(pr, False)
            par = playlist_links().get(str(pr))
            if par:                                   # שיעור מפלייליסט נפתח — גם לשונית הפלייליסט חוזרת
                set_hidden(Path(par[0]), False)
            return {"ok": True}
        if path == "/api/rebuild":
            p, st = load_state(d["project"])
            cam = d.get("camera") or "smooth"           # 28/10 (כרטיס 22): גם "zippy"
            if cam not in MS.CAMERAS or cam == "default":
                raise ValueError("מצלמה לא מוכרת")
            return {"job": enqueue("rebuild", ["rebuild", p, d["clip"]] + ([cam] if cam != "smooth" else []), p,
                                   st.get("video_title", ""), clip=d["clip"])}
        if path == "/api/swap":
            p, st = load_state(d["project"])
            mode = d.get("mode") or "swap"
            if mode not in MS.SWAP_MODES:
                raise ValueError("פעולה לא מוכרת")
            args = ["swap", p, d["clip"]] + ([d["uuid"]] if d.get("uuid") else []) + \
                   (["--reject-old"] if d.get("reject_old") else []) + ["--mode=" + mode]
            return {"job": enqueue("swap", args, p, st.get("video_title", ""), clip=d["clip"])}
        if path == "/api/restyle":
            # "החל" בהגדרות המהירות: צבע / מצלמה / מוזיקה של קליף מוכן — עבודה רגילה בתור
            p, st = load_state(d["project"])
            args = ["restyle", p, d["clip"]]
            if d.get("color"):
                if not SET.valid_choice(d["color"]):       # RRGGBB · PLAIN (ללא צבע) · MARKER:RRGGBB · FLOAT[:RRGGBB]
                    raise ValueError("צבע לא תקין")
                args.append("--color=" + d["color"])
            if d.get("camera"):
                if d["camera"] not in MS.CAMERAS:
                    raise ValueError("מצלמה לא מוכרת")
                args.append("--camera=" + d["camera"])
            if d.get("music"):
                if d["music"] not in MS.SWAP_MODES:
                    raise ValueError("פעולה לא מוכרת")
                args.append("--music=" + d["music"])
                if d.get("uuid"):
                    args.append("--uuid=" + re.sub(r"[^\w-]", "", d["uuid"]))
            if d.get("subs"):                          # "📐 פריסת שורות" נשמרה — צריבה מחדש של הכתוביות
                args.append("--subs")
            if d.get("emph") in ("on", "off"):          # 🔠 הגדלת מילים מהשורה המהירה (כרטיס 15)
                args.append("--emph=" + d["emph"])
            if d.get("hook") in ("on", "off", "redo"):  # 🎬 הוק (6/11): נוסף / הוסר / נבנה מחדש אחרי עריכת הרגע
                args.append("--hook=" + d["hook"])
            if d.get("db") not in (None, ""):          # 22/10: עוצמת המוזיקה בקליף הזה
                args.append("--db=%d" % max(SET.CLIP_DB[0], min(SET.CLIP_DB[1], int(d["db"]))))
            if len(args) == 3:
                raise ValueError("לא נבחר שום שינוי")
            if not d.get("color") and not d.get("camera") and not d.get("subs") and not d.get("emph") and not d.get("hook"):
                # מוזיקה בלבד — כ-10 שניות: פריט "קל" בתור (עם שם בחלונית), מתחיל מיד גם כשעבודה כבדה רצה
                return {"job": enqueue("swap", args, p, st.get("video_title", ""), clip=d["clip"])}
            return {"job": enqueue("restyle", args, p, st.get("video_title", ""), clip=d["clip"])}
        if path == "/api/preview":
            return start_preview(d)
        if path == "/api/drive/now":                 # המחוון ☁: "לנסות שוב" / "גבה עכשיו"
            return drive_now()
        if path == "/api/drive/own_key":             # 16/11: מפתח גוגל אישי לגיבוי (מתוך ההתראה)
            return drive_own_key(str(d.get("client_id") or ""), str(d.get("client_secret") or ""))
        if path == "/api/layout":                    # שמירת "📐 פריסת שורות" (chunks=null = חזרה לאוטומטית)
            p, st = load_state(d["project"])
            name = re.sub(r"[^\w]", "", d["clip"])
            wj = p / ("work/subtitles/%s_words.json" % name)
            words = json.load(open(wj, encoding="utf-8"))["words"]
            LAYOUT.save(p, name, words, d.get("chunks"))
            return LAYOUT.view(p, name, words)
        if path == "/api/emph":                      # 🔠 המתג / המילים שערך / חזרה להצעה — בלי צריבה
            p, st = load_state(d["project"])
            name = re.sub(r"[^\w]", "", d["clip"])
            return MS.emph_set(p, name, d.get("on"), d["picks"] if "picks" in d else False, bool(d.get("revert")))
        if path == "/api/hook":                      # 🎬 הרגע שבחר / מתג הקליף / חזרה להצעה — בלי צריבה ("✓ החל" צורב)
            p, st = load_state(d["project"])
            name = re.sub(r"[^\w]", "", d["clip"])
            return MS.hook_set(p, name, d.get("i0"), d.get("i1"), d.get("on"), bool(d.get("auto")))
        if path == "/api/sub_preview":               # "▶ תצוגה מקדימה לכתוביות" — הטקסט שבתיבה, לפני צריבה
            p, st = load_state(d["project"])
            return MS.sub_preview(p, re.sub(r"[^\w]", "", d["clip"]), d.get("text", ""), d.get("emph"))
        # הגדרות
        if path == "/api/settings":
            return SET.update(d)
        if path == "/api/tools/set":
            r = TOOLS.set_pref(str(d.get("tool", "")), str(d.get("mode", "")), str(d.get("path", "")))
            if not r["ok"]:
                raise ValueError(r["msg"])
            TOOLS.reload_env()
            HEALTH.FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
            recheck(["ffmpeg", "ytdlp"])            # ffmpeg / yt-dlp אולי השתנו
            return {"msg": r["msg"], "tools": TOOLS.scan()}
        if path == "/api/settings/reset":
            return SET.reset(d.get("keys"))
        if path == "/api/settings/undo":
            return SET.undo()
        if path == "/api/settings/undo_dismiss":          # 4.6.3: ✕ הסתר — בלי להחזיר כלום
            return SET.dismiss_undo()
        # מוזיקה
        # 22/10 (כרטיס 13): ❤ / נשמע / השבתה / איפוס הלייקים — on=false מבטל
        if path in ("/api/music/like", "/api/music/heard", "/api/music/disable"):
            fn = {"like": MUSIC.set_like, "heard": MUSIC.set_heard, "disable": MUSIC.set_disabled}[path.rsplit("/", 1)[1]]
            fn(d["uuid"], bool(d.get("on", True)))
            return music_payload()
        if path == "/api/music/reset_likes":
            MUSIC.reset_likes()
            return music_payload()
        if path == "/api/music/undo_reset":
            MUSIC.undo_reset()
            return music_payload()
        if path == "/api/music/remove":
            MUSIC.remove(d["uuid"])
            return music_payload()
        if path == "/api/music/restore":
            MUSIC.restore(d["uuid"])
            return music_payload()
        if path == "/api/music/approve":
            MUSIC.approve(d["uuid"], d.get("on", True))
            return music_payload()
        if path == "/api/music/add":
            MUSIC.add(d["name"], b64_limited(d.get("data"), "music"), d.get("credit", ""), d.get("title", ""))
            return music_payload()
        # קבצים שהוא מעלה
        if path == "/api/upload_logo":
            data = b64_limited(d.get("data"), "logo")
            if not data.startswith(b"\x89PNG"):
                raise ValueError("צריך קובץ PNG (עם רקע שקוף)")
            BRAND.mkdir(parents=True, exist_ok=True)
            f = BRAND / ("logo_custom_%s.png" % time.strftime("%Y%m%d_%H%M%S"))
            f.write_bytes(data)
            return SET.update({"logo2_path" if d.get("slot") == "right" else "logo_path": str(f)})
        if path == "/api/upload_cookies":
            data = b64_limited(d.get("data"), "cookies").decode("utf-8", errors="replace")
            if "youtube.com" not in data or "\t" not in data:
                raise ValueError("זה לא נראה כמו קובץ עוגיות של יוטיוב (cookies.txt). " + HEALTH.COOKIE_REJECT_NOTE)
            ck = HEALTH.COOKIES
            if ck.exists():                               # העותק הקודם נשמר, לא נמחק
                os.replace(ck, ck.with_suffix(".txt.bak"))
                os.chmod(ck.with_suffix(".txt.bak"), 0o600)
            fd = os.open(ck, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(data)
            os.chmod(ck, 0o600)
            recheck(["cookies"], wait=True)               # מקומי, מיידי — התשובה כבר אומרת אם הקובץ בתוקף
            r = next((x for x in HEALTH_STATE["data"]["results"] if x.get("id") == "cookies"), {})
            if r.get("level") == "ok":
                job_alert_clear("cookies")
            action_set("upload_cookies", "ok" if r.get("level") == "ok" else "fail",
                       "קובץ העוגיות נשמר ✓ — בתוקף" if r.get("level") == "ok" else "נשמר, אבל: " + r.get("title", ""))
            return {"ok": True, "check": r, "health": health_view()}
        # שיתוף ועדכון התוכנה
        if path == "/api/share/build":
            if any(j["running"] and j["kind"] == "share" for j in JOBS.values()):
                raise ValueError("כבר נבנית חבילה — לחכות שתסתיים")
            pid = str(d.get("profile") or "")
            prof = SHARE.profile_get(pid) if pid else None
            if pid and not prof:
                raise ValueError("הפרופיל לא נמצא (אולי נמחק) — לבחור שוב")
            cmd = [sys.executable, "-u", str(HERE / "make_short_share.py"), "build"] + (["--drive"] if d.get("drive") else []) \
                + (["--prune"] if d.get("rebuild") else []) \
                + (["--profile", pid] if prof else [])              # 3.5: חבילה לפרופיל (ברירת מחדל: בלי)
            SHARE_STALE["ts"] = 0
            return {"job": start_job("share", cmd, title="חבילת שיתוף" + (" ל" + prof["name"] if prof else ""))}
        if path == "/api/share/profile/save":           # 3.5: פרופיל למקבל — חדש / עריכה
            logo = b64_limited(d.get("logo"), "logo") if d.get("logo") else None
            p = SHARE.profile_save({k: d.get(k) for k in ("id", "name", "footer_lines", "org_name", "subscribe_text",
                                                          "auto_rebuild")}, logo)
            SHARE_STALE["ts"] = 0
            return {"ok": True, "profile": p, "profiles": SHARE.profiles_view()}
        if path == "/api/share/profile/auto":           # רק התיבה "🔄 לבנות מחדש לבד" של פרופיל אחד
            p = SHARE.profile_get(str(d.get("id") or ""))
            if not p:
                raise ValueError("הפרופיל לא נמצא")
            SHARE.profile_save(dict(p, auto_rebuild=bool(d.get("on"))))
            SHARE_STALE["ts"] = 0
            return {"ok": True, "profiles": SHARE.profiles_view()}
        if path == "/api/share/profile/delete":
            if any(j["running"] and j["kind"] == "share" for j in JOBS.values()):
                raise ValueError("נבנית עכשיו חבילה — למחוק כשהיא תסתיים")
            where = SHARE.profile_delete(str(d.get("id") or ""))
            SHARE_STALE["ts"] = 0
            return {"ok": True, "where": where, "profiles": SHARE.profiles_view()}
        if path == "/api/share/open":
            open_in_explorer(d.get("file") or str(SHARE.default_out()))
            return {"ok": True}
        if path == "/api/update/check":
            return UPD.check(d.get("text", ""))
        if path in ("/api/chat/plan", "/api/chat/block"):
            # 27/10: "עבודה עם צ'אט (Claude)" — בלוק אחד להדבקה בצ'אט: באג / שינוי, עם הקוד הרלוונטי בתוך תקציב
            mode = "bug" if d.get("mode") == "bug" else "change"
            fn = CHAT.plan if path.endswith("plan") else CHAT.block
            return fn(mode, str(d.get("text") or "")[:4000], chat_ctx(mode, str(d.get("job") or "")),
                      list(d.get("ticks") or []), list(d.get("unticks") or []), SET.load()["chat_code_chars"])
        if path.startswith("/api/fix/"):
            return fix_api(path[len("/api/fix/"):], d)
        if path == "/api/chat/files":
            return CHAT.followup([str(x) for x in d.get("items") or []][:30], SET.load()["chat_code_chars"])
        if path == "/api/chat/retry":
            j = JOBS.get(str(d.get("job") or ""))
            if j:
                scrub = chat_ctx("change")["scrub"]
                return CHAT.retry(log=[scrub(l) for l in j["log"]])
            return CHAT.retry(check_result=UPD.check(d.get("text", "")))
        if path in ("/api/update/apply", "/api/update/undo"):
            # 21/10: אפשר לעדכן גם באמצע עבודה — כל עבודה רצה מצילום קוד קבוע, והעדכון ייכנס לתוקף כשהעבודה תסתיים
            if any(j["running"] and j["kind"] in ("upd_apply", "upd_undo") for j in JOBS.values()):
                raise ValueError("עדכון אחר כבר רץ — לחכות שיסתיים")
            if PCS["busy"]:
                raise ValueError("מתבצעת עכשיו פעולה על השינויים האישיים שלכם — לחכות שתסתיים (כמה דקות)")
            if path.endswith("undo"):
                return {"job": start_job("upd_undo", [sys.executable, "-u", str(HERE / "make_short_update.py"), "undo"],
                                         title="ביטול עדכון")}
            if not UPD.check(d.get("text", ""))["ok"]:
                raise ValueError("העדכון לא עבר בדיקה — ללחוץ \"בדוק עדכון\" ולראות למה")
            SPECS.mkdir(parents=True, exist_ok=True)
            f = SPECS / ("update_%s.txt" % time.strftime("%Y%m%d_%H%M%S"))
            f.write_text(d["text"], encoding="utf-8")
            return {"job": start_job("upd_apply", [sys.executable, "-u", str(HERE / "make_short_update.py"), "apply", f],
                                     title="עדכון תוכנה")}
        if path == "/api/test/probe" and MS.TEST_MODE:
            # בדיקות בלבד (מצב בדיקה): עבודה שמדפיסה איזו גרסת קוד רצה, ממתינה, וקוראת לסקריפט אחר
            return {"job": start_job("probe", [sys.executable, "-u", str(HERE / "make_short_snap.py"), "probe",
                                               str(float(d.get("secs", 8)))], title="בדיקת צילום קוד")}
        if path.startswith("/api/personal/"):                               # 4.5
            r = pc_post(path, d)
            if r is not None:
                return r
        if path.startswith("/api/proposals/"):                              # 4.4
            r = prop_post(path, d)
            if r is not None:
                return r
        if path.startswith("/api/vault/"):                                  # 4.6: status|create|restore|kit — הבעלים בלבד (403)
            return vault_api(path.rsplit("/", 1)[1], d)
        if path.startswith(("/api/release/", "/api/publish/")):          # 4.3
            r = rel_post(path, d)
            if r is not None:
                return r
        if path == "/api/restart":
            if any(j["running"] for j in JOBS.values()) or queue_pending():
                raise ValueError("יש עבודה שרצה — אפשר להפעיל מחדש כשתסתיים")
            restart_soon()
            return {"ok": True}
        if path == "/api/action":
            if d["id"] == "update_ytdlp":
                return {"job": ytdlp_update_start(), "health": health_view()}
            if d["id"] == "engine_upgrade":
                return {"job": engine_upgrade_start(), "health": health_view()}
            if d["id"] == "engine_dismiss":            # ההודעה השקטה — חוזרת רק בעוד חודש
                ENG.dismiss()
                recheck(["engine"], wait=True)
                return {"ok": True, "health": health_view()}
            if d["id"] == "drive_reconnect":
                drive_reconnect()
                return {"ok": True, "health": health_view()}
            if d["id"] == "modal_connect":             # 4.0: "🧭 צעדים ראשונים" — חיבור Modal מתוך החלון
                modal_connect()
                return {"ok": True, "health": health_view()}
            if d["id"] == "health":
                refresh_health()
                return {"ok": True}
        return None


if __name__ == "__main__":
    TOOL.mkdir(parents=True, exist_ok=True)
    _recs = []                                        # 4.3: עדכון מהאינטרנט שנקטע באמצע (כיבוי) — חוזרים לגרסה התקינה האחרונה, לפני כל דבר אחר
    try:
        _rec = REL.recover()
        if _rec:
            _recs.append((_rec, _rec.startswith("⚠")))
    except Exception as e:                            # 4.5.x (B2): כשל אמיתי — מוצג בדף (לא רק ביומן)
        _recs.append((str(e) if isinstance(e, REL.UpdateError) else "החזרת עדכון שנקטע נכשלה (%s)." % type(e).__name__, True))
    try:
        _recs += REL.startup_notes(skip_update=SKIP_UPDATE)
    except Exception as e:
        app_log("=== startup notes: %r" % e)
    if _recs:
        app_log("=== %s update recovery: %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), " | ".join(t for t, _ in _recs)))
        try:
            _st = REL.load_state()
            _st["recovered"] = " ".join(t for t, _ in _recs)
            _st["recover_failed"] = any(f for _, f in _recs)
            REL.save_state(_st)
        except Exception as e:
            app_log("=== update recovery state: %r" % e)

    def _trial_watch():                               # 4.5.x (B7): 30 שניות של ריצה תקינה = הגרסה החדשה עברה את ההפעלה הראשונה
        time.sleep(30)
        REL.trial_ok()
    threading.Thread(target=_trial_watch, daemon=True).start()
    try:                                              # 4.0: קובץ הגדרות מלפני 4.0 → "מתקדם" + בלי מסך פתיחה, בכתב
        if SET.ensure_view():
            app_log("=== %s settings: pre-4.0 file → view_mode=advanced, first_steps_seen" % time.strftime("%Y-%m-%d %H:%M:%S"))
    except Exception as e:
        app_log("=== ensure_view: %s" % e)
    if not os.environ.get("MAKE_SHORT_NO_EXPORT"):     # 4.0.5: ניסיון "מפתח אישי" שנקטע — לא במצב בדיקה (שם אין דרייב)
        try:
            own_key_startup()
        except Exception as e:
            app_log("=== own_key_startup: %s" % e)
    refresh_health()                                  # בדיקת מערכת ברקע, כבר בפתיחה
    ThreadingHTTPServer.daemon_threads = True         # חיבורי /api/alive לא מעכבים את היציאה
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    except OSError:
        # לחיצה שנייה על הקיצור כשהתוכנה כבר פתוחה: החלון נפתח מול השרת הקיים, וכאן אין מה לעשות
        import urllib.request
        try:
            body = urllib.request.urlopen("http://127.0.0.1:%d/api/home" % PORT, timeout=5).read()
            if b'"folders"' not in body:   # 21/10: his collab tool sat on our old port and answered 200
                raise ValueError("another program")
            print("  התוכנה כבר פתוחה — נפתח חלון נוסף שלה.", flush=True)
            sys.exit(0)
        except Exception:
            raise SystemExit("  הפורט %d תפוס על ידי תוכנה אחרת — לסגור אותה ולנסות שוב." % PORT)
    print("\n  יצירת שורטס — החלון נפתח בדפדפן: http://localhost:%d\n"
          "  החלון השחור הזה נסגר לבד כדקה אחרי שסוגרים את התוכנה (לא באמצע עבודה).\n" % PORT, flush=True)
    try:
        migrate_playlist_links()                      # פלייליסטים ישנים: השיעורים שהוכנו מהם הופכים לתת-לשוניות
    except Exception as e:
        app_log("=== migrate links: %s" % e)
    queue_load()                                      # התור מהפעם הקודמת — ממשיך לבד
    if IDLE_EXIT > 0:
        threading.Thread(target=idle_watch, args=(srv,), daemon=True).start()
    threading.Thread(target=net_watch, daemon=True).start()
    threading.Thread(target=drive_watch, daemon=True).start()
    threading.Thread(target=extras_watch, daemon=True).start()     # 3.4: "גיבוי תוכנה" + זיכרון Claude, פעם ביום
    threading.Thread(target=queue_watch, daemon=True).start()
    threading.Thread(target=editor_watch, daemon=True).start()     # 28/10: העורך החכם — שליחה משותפת
    pause_recover()                                                # 4.2.0: עבודה שנשארה קפואה מריצה שנפלה — ממשיכה
    threading.Thread(target=pause_watch, daemon=True).start()
    try:                                              # צילום הקוד הנוכחי (להשוואה: "מה עודכן") + ניקוי צילומים ישנים שאין בהם שימוש
        SNAP_BOOT = str(SNAP.ensure()[0])
        SNAP.clean(keep={CODE["boot"]})
    except Exception as e:
        app_log("=== boot snapshot: %s" % e)
    threading.Thread(target=code_watch, daemon=True).start()
    threading.Thread(target=rel_watch, daemon=True).start()         # 4.3: בדיקת עדכון שקטה פעם ביום
    threading.Thread(target=prop_watch, daemon=True).start()        # 4.4: הצעות למנהל — סנכרון שקט
    threading.Thread(target=pc_watch, daemon=True).start()          # 4.5: שינויים אישיים שממתינים — מוחלים שוב כשאין עבודה
    threading.Thread(target=share_watch, daemon=True).start()       # כרטיס 14: חבילת השיתוף בגרסה הנוכחית
    threading.Thread(target=health_watch, daemon=True).start()      # 22/10: בדיקת מערכת כל ~30 דקות
    modal_meter_refresh()                                            # מד Modal — בלי לחכות לבדיקת המערכת
    srv.serve_forever()
    srv.server_close()
