# -*- coding: utf-8 -*-
"""
make_short.py — שורט מקטע שהמשתמש בחר בעצמו, **בלי מודל שפה** (שלב 1 של "התוכנה").

למה זה קיים (19/10/2026): המשתמש רוצה להמשיך להפיק שורטס גם אם המנוי ל-Claude
ייגמר. כל העבודה הטכנית כבר הייתה סקריפטים; מה שחסר הוא מי שמחבר אותם ומי שמכריע.
כאן החיבור אוטומטי, וההכרעות (איזה קטע, איזו מילה נאמרה, כותרת ותיאור) — אצלו.

שני שלבים, ובאמצע בן אדם:
  prepare <spec.json>  מוריד, מצמיד כל גבול לשקט שנמדד, בונה וידאו נקי (מעקב פנים,
                       מצלמה לא נעולה), מתמלל בשתי אוזניים, וכותב לכל קליף קובץ עריכה
                       ב-<project>/לעריכה/: כותרת, תיאור, וטקסט הכתוביות עם [א / ב]
                       בכל מקום ששתי האוזניים חלוקות, ולצדו כתוביות יוטיוב לעיון.
  finish <project>     קורא את קובצי העריכה ועושה את כל השאר: יישור, כתוביות טורקיז,
                       שער כיסוי, צריבה + לוגו, נרמול קול, מוזיקה, מטא-דאטה (טיוטה).

🚨 למה עצירה באמצע ולא הכרעה אוטומטית: תמלול אחד לעולם לא נצרב (שער 5א בסקיל).
כשאין מודל שפה שיכריע בין האוזניים — מכריע המשתמש, שמכיר את הפסוקים ועונה על
ספקות מהר (28/9). ספק שנשאר בסוגריים — נלקחת האוזן הראשונה, ומדווח.

spec.json:
{"url": "https://www.youtube.com/watch?v=...",
 "rabbi": "", "series": "",            ← ריק = מנחשים מכותרת הסרטון
 "clips": [{"pieces": "12:30-13:15, 14:02-14:20",
            "title": "", "description": "", "tags": "",
            "opening": "", "closing": "", "refine": false}]}   ← מהבחירה האוטומטית (make_short_pick.py):
                                     refine = הזמנים מכתוביות יוטיוב → מדייקים מול תמלול מדויק לפי הציטוטים

שימוש: shorts.sh py make_short.py prepare spec.json
       shorts.sh py make_short.py finish <project>
       shorts.sh py make_short.py rebuild <project> <clipN> [smooth|zippy]   ← בנייה מחדש במצלמה חלקה/זריזה
       shorts.sh py make_short.py swap <project> <clipN> [uuid] [--reject-old]   ← החלפת מוזיקה
       shorts.sh py make_short.py restyle <project> <clipN> [--color=RRGGBB] [--camera=default|smooth|zippy]
                                          [--music=swap|back|off|on] [--uuid=..]   ← "הגדרות מהירות"
       shorts.sh py make_short.py preview <project> <clipN> music <uuid|off> | camera <default|smooth|zippy> [--at=SEC]
       shorts.sh py make_short.py save <project>                  ← הטיוטה → תיקיית השורטס (הדרייב — ברקע, 22/10)
       shorts.sh py make_short.py drop|restore|drop_saved <project> <clipN>   ← "ויתרתי" / שחזור
       shorts.sh py make_short.py retime <project> <clipN> '[[a,b],...]'     ← גבולות חדשים, הטקסט נשמר
       shorts.sh py make_short.py context <project> <clipN>       ← מילים סביב הקליף (לגרירת הגבולות)
כל עבודה רושמת את השלבים ב-<project>/progress.json; אותה פקודה שוב = ממשיכה מאיפה שנעצרה.
finish יוצר טיוטה בתיקיית העבודה בלבד; ייצוא — רק ב-save, והוא רק מסמן "ממתין לגיבוי": את הדרייב
מעדכן עובד הרקע של החלון (make_short_app.drive_watch) לכל תיקיית השורטס בבת אחת.

ההגדרות (מוזיקה, לוגו, צבע, גיבוי, כללי אורך) — make_short_settings.py, נערכות מהחלון.
תיקיות העבודה של התוכנה: projects/תוכנה/ (ליד תיקיות העבודה של Claude, לא מעורבבות בהן).
"""
import contextlib
import difflib
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

import make_short_settings as SET
import make_short_modal_day as MD
import make_short_rabbis as RB
import make_short_repeats as RP
import shorts_layout as SL

HERE =Path(__file__).resolve().parent
SH = HERE.parent.parent
SHORTS = str(SH / "shorts.sh")
PY = sys.executable
FFMPEG = os.environ.get("FFMPEG", "ffmpeg")
FFPROBE = os.environ.get("FFPROBE", "ffprobe")
LIB = os.environ.get("SHORTS_LIB", str(SH / "assets"))
LARGE = "ivrit-ai/whisper-large-v3-ct2"
TURBO = "ivrit-ai/whisper-large-v3-turbo-ct2"
SR = 16000
FILLERS = {"כן", "אז", "נו", "טוב", "אוקיי", "ובכן", "אממ", "אה"}
STATE = "make_short.json"
EDIT_DIR = "לעריכה"
SEP_TEXT = "==== טקסט הכתוביות ===="
SEP_REF = "==== לעיון בלבד"
# רמות המוזיקה — SET.music_levels(): ‎-13/-9/-3 כמו מאז 24/9, ועליהן ההזזה שהוא בחר בהגדרות
TOOL_DIR = Path(os.environ.get("SHORTS_PROJECTS") or os.path.expanduser("~/.local/share/yeshiva-shorts/projects")) / "תוכנה"
HEAVY_LOCK = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts")) / "heavy_build.lock"
TEST_MODE = os.environ.get("MAKE_SHORT_NO_EXPORT") == "1"
# 16/11 (3.4): הקישורים של הישיבה, שם הישיבה ומשפט ההרשמה עברו להגדרות (📝 תיאור ותגיות) — ראו footer_for / desc_settings


def say(msg):
    print(msg, flush=True)


def mmss_(t):
    t = int(round(float(t)))
    return "%d:%02d" % (t // 60, t % 60)


def run(cmd, cwd=None, check=True):
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, errors="replace")
    if check and r.returncode:
        tail = "\n".join((r.stderr or r.stdout or "").strip().splitlines()[-10:])
        raise RuntimeError("%s נכשל:\n%s" % (" ".join(Path(str(c)).name for c in cmd[:2]), tail))
    return r.stdout


@contextlib.contextmanager
def heavy(label):
    """בנייה כבדה (וידאו) — אחת בכל פעם, גם כשכמה שיעורים בעבודה במקביל.
    🚨 24/9: רינדורים במקביל רצו פי 8–15 לאט יותר מאחד אחרי השני. התמלול (Modal, בענן)
    וההורדות כן רצים במקביל — רק הקטע הזה ממתין בתור. הנעילה היא קובץ (flock), כך שהיא
    עובדת בין תהליכים נפרדים ונשחררת לבד אם תהליך נפל. שורות STAGE= הן בשביל החלון."""
    import fcntl
    HEAVY_LOCK.parent.mkdir(parents=True, exist_ok=True)
    fh = open(HEAVY_LOCK, "w")
    try:
        try:
            fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            say("STAGE=queued")
            say("   ⏳ %s ממתין בתור — שיעור אחר נבנה עכשיו, זה יתחיל לבד כשהוא יסיים" % label)
            fcntl.flock(fh, fcntl.LOCK_EX)
        say("STAGE=building")
        yield
    finally:
        fcntl.flock(fh, fcntl.LOCK_UN)
        fh.close()
        say("STAGE=working")


def load_st():
    return json.load(open(STATE, encoding="utf-8"))


def use_rabbi(rabbi, cam=True):
    """כרטיס 25 (1/11/2026): פרופיל הרב לעבודה הזאת — המצלמה (CAM_RABBI בסביבה, כל תהליך-בן יורש) ועצירת הכתוביות
    (build_ass.GAP_THRESHOLD). נקרא בתחילת כל עבודה/תצוגה שבונה מצלמה או מחלקת כתוביות; בלי פרופיל — כמו תמיד.
    cam=False בתוך השרת (תצוגות): שם משתנה הסביבה היה עובר בירושה לעבודות של רבנים אחרים."""
    rabbi = (rabbi or "").strip()
    if cam:
        if rabbi:
            os.environ["CAM_RABBI"] = rabbi
        else:
            os.environ.pop("CAM_RABBI", None)
    sys.path.insert(0, str(HERE))
    RB.apply_gap(rabbi)
    return rabbi


def use_project_rabbi(P, cam=True):
    """אותו דבר לפי הרב שרשום בפרויקט (make_short.json). פרויקט בלי מצב עדיין — בלי פרופיל."""
    try:
        return use_rabbi(json.load(open(Path(P) / STATE, encoding="utf-8")).get("rabbi"), cam)
    except (OSError, ValueError):
        return use_rabbi("", cam)


def save_st(st):
    tmp = Path(STATE + ".tmp")
    json.dump(st, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    tmp.replace(STATE)


def check_framing(video, camera="default"):
    """שער המיסגור (check_framing.py) על הקליף שנבנה. מחזיר {"ok", "text", "exits"}.
    המצלמה המאושרת לא משתנה מעצמה (לעולם לא נעולה) — רק אזהרה, והוא מחליט על בנייה חלקה/זריזה."""
    r = subprocess.run([PY, str(HERE / "check_framing.py"), str(video)], capture_output=True, text=True,
                       errors="replace")
    lines = [l.strip() for l in (r.stdout or r.stderr or "").strip().splitlines() if l.strip()]
    # קוד 2 = "בתוך הפריים אבל בצד" — עובר, עם אזהרה רכה בכרטיס
    out = {"ok": r.returncode in (0, 2), "warn": r.returncode == 2,
           "text": " · ".join(l for l in lines if l.startswith(("❌", "✅", "⚠️", "מיסגור")))[:400]}
    m = re.match(r"work/clips/(\w+)_clean\.mp4$", str(video))
    if m:
        out["exits"] = frame_exits(m.group(1), camera)
    return out


def frame_exits(name, camera="default"):
    """כרטיס 22 (28/10/2026): בכמה שניות הרב יוצא מהקרופ שלנו (camera_path.py, על ה-raw — בקליף הבנוי
    רב שיצא פשוט לא נראה, ו-check_framing לא סופר את השניות האלה). שומר ליד הקליף, מחזיר סיכום או None."""
    r = subprocess.run([PY, str(HERE / "camera_path.py"), "status", name, camera or "default"],
                       capture_output=True, text=True, errors="replace")
    try:
        return json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return None


def duration(p):
    return float(run([FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).strip())


def win_path(p):
    # WSL_DISTRO_NAME: the distro this runs in (Ubuntu, Ubuntu-24.04, Debian...)
    return "\\\\wsl.localhost\\" + os.environ.get("WSL_DISTRO_NAME", "Ubuntu") + str(p).replace("/", "\\")


def norm(t):
    return re.sub(r"[^א-תA-Za-z0-9]", "", t)


# ─────────────────────────── קלט ───────────────────────────

def secs(t):
    v = 0.0
    for p in t.strip().split(":"):
        v = v * 60 + float(p)
    return v


def parse_pieces(s):
    """"12:30-13:15, 14:02-14:20" → [(750, 795), (842, 860)]"""
    out = []
    for part in re.split(r"[,;\n]+", s or ""):
        part = part.strip()
        if not part:
            continue
        m = re.fullmatch(r"([\d:.]+)\s*[-–—]\s*([\d:.]+)", part)
        if not m:
            raise ValueError("לא הבנתי את הזמנים: '%s' (צריך למשל 12:30-13:15)" % part)
        a, b = secs(m.group(1)), secs(m.group(2))
        if b <= a:
            raise ValueError("קטע שנגמר לפני שהוא מתחיל: '%s'" % part)
        out.append((a, b))
    if not out:
        raise ValueError("לא צוינו זמנים לקליף")
    return out


def guess_names(title):
    """שם הרב והסדרה **רק מכותרת הסרטון** (כלל 4 של הפרויקט).
    "מידת החסידות | שיעורים במסילת ישרים | הרה"ג זלמן ברוך מלמד" → ("הרב זלמן ברוך מלמד", "שיעורים במסילת ישרים")"""
    parts = [p.strip() for p in re.split(r"[|｜]", title) if p.strip()]
    rabbi, rest = "", []
    for p in parts[1:] or parts:
        m = re.search(r"(?:הרה[\"״']?ג|הרב)\s+(.+)", p)
        if m and not rabbi:
            rabbi = "הרב " + m.group(1).strip()
        else:
            rest.append(p)
    # 20/10 (סריקת פלייליסט): "הרב יהודה מלמד שליט"א" ו"שמונה פרקים לרמב"ם - שיעור 6" — התואר שאחרי השם
    # ומספר השיעור היו פותחים תיקיית רב/סדרה חדשה לכל שיעור
    # 22/10 (כרטיס 16): שליט"א/זצ"ל, "הרה"ג", מירכאות ורווחים כפולים — הכול ב-shorts_layout.clean_rabbi
    rabbi = SL.clean_rabbi(rabbi)
    series = re.sub(r"\s*[-–—,]?\s*(שיעור|חלק)\s*[\dא-ת]{1,3}\s*$", "", rest[0]).strip() if rest else ""
    return rabbi, series


def existing_folder(rabbi, series):
    """שם רב/סדרה נקי, וכפי שכבר קיים בתיקיית הייצוא אם יש תיקייה "כמעט זהה".
    נולד בבדיקה הראשונה (19/10): הכותרת אמרה 'בש"ס' והתיקייה הקיימת 'בשס' — בלי ההתאמה
    הייתה נפתחת תיקייה כפולה לאותה סדרה. 22/10 (כרטיס 16): גם שליט"א, הרה"ג מול הרב, רווחים כפולים."""
    root = export_root() or Path(os.environ.get("SHORTS_EXPORT_DIR") or os.path.expanduser("~/Videos/Shorts"))
    return SL.resolve_names(root, rabbi, series)


# ──────────────── גבולות על שקט שנמדד ────────────────

def load_audio(path):
    raw = subprocess.run([FFMPEG, "-v", "error", "-i", str(path), "-f", "f32le", "-ac", "1",
                          "-ar", str(SR), "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.float32)


def quietest(audio, t0, t1):
    """הנקודה השקטה ביותר בין t0 ל-t1, בחלונות של 10ms (זמנים יחסיים לאודיו).
    🚨 חותכים לפי שקט שנמדד, לא לפי חותמות whisper (16/9: השקט האמיתי היה 0.17ש' אחרי הגבול שלו)."""
    n = int(0.01 * SR)
    seg = audio[max(0, int(t0 * SR)):max(0, int(t1 * SR))]
    m = len(seg) // n
    if m < 1:
        return (t0 + t1) / 2
    r = np.sqrt((seg[:m * n].reshape(m, n) ** 2).mean(1))
    return t0 + (int(np.argmin(r)) + 0.5) * 0.01


def snap_piece(words, audio, lo, a, b, opening=True):
    """מצמיד את (a, b) שהמשתמש נתן (בערך, מהאוזן) לגבולות מילה אמיתיים, ובתוכם לנקודה
    השקטה ביותר. מעדיף גבול שיש לפניו/אחריו הפסקה — שם מתחיל ונגמר משפט."""
    if not words:
        return a, b, "", ""

    # גבול משפט = הפסקה בדיבור *או* פיסוק בתמלול. בבדיקה השנייה (19/10) רק ההפסקה נספרה:
    # "כן, זה מעניין" — אין הפסקה אחרי "כן," והגבול קפץ ל"שברוך", באמצע המשפט.
    punct = lambda k: words[k]["word"].strip()[-1:] in ",.?!:;"

    def gap_before(i, depth=0):
        if not i or punct(i - 1):
            return 1.0
        # "הזה. כן זה מעניין" — מילת מילוי שעומדת בתחילת משפט מעבירה את הגבול למילה שאחריה
        if opening and not depth and norm(words[i - 1]["word"]) in FILLERS and gap_before(i - 1, 1) >= 0.12:
            return 1.0
        return words[i]["start"] - words[i - 1]["end"]

    def gap_after(j):
        if j + 1 >= len(words) or punct(j):
            return 1.0
        return words[j + 1]["start"] - words[j]["end"]

    cs = [i for i, w in enumerate(words) if abs(w["start"] - a) <= 3]
    ce = [j for j, w in enumerate(words) if abs(w["end"] - b) <= 3]
    # קליף שנפתח ב"כן,"/"אז"/"על כל פנים" — פתיחה חלשה (שער ההוק 7א). בבדיקה הראשונה הגבול נצמד
    # ל"כן," שחצי שנייה לפני "זה מעניין" שהקליף הידני פתח בו.
    # רק בפתיחת השורט; בחלק שני "אז לכן" הוא חיבור טבעי בין החלקים (הקליף הידני פתח שם ב"אז")
    i = min(cs, key=lambda k: abs(words[k]["start"] - a) + (0.8 if gap_before(k) < 0.12 else 0)
            + (0.7 if opening and norm(words[k]["word"]) in FILLERS else 0)) if cs else None
    j = min(ce, key=lambda k: abs(words[k]["end"] - b) + (0.8 if gap_after(k) < 0.12 else 0)) if ce else None
    if i is not None and j is not None and j < i:
        j = None
    s, e = a, b
    if i is not None:
        ws = words[i]["start"]
        prev = words[i - 1]["end"] if i else ws - 0.6
        s = lo + quietest(audio, max(prev, ws - 0.6) - lo, ws - 0.03 - lo)
    if j is not None:
        we = words[j]["end"]
        nxt = words[j + 1]["start"] if j + 1 < len(words) else we + 0.8
        # הקצה של מילה מודגשת נמשך אחרי מה ש-whisper סימן (28/9, "הכל טוב!") — לפחות 0.2ש' לתוך השקט
        t0, t1 = we + 0.2, min(nxt - 0.02, we + 0.8)
        e = lo + quietest(audio, t0 - lo, t1 - lo) if t1 - t0 > 0.03 else min(we + 0.25, nxt)
    first = words[i]["word"].strip() if i is not None else ""
    last = words[j]["word"].strip() if j is not None else ""
    return round(s, 3), round(e, 3), first, last


# ──────────────── תמלול ────────────────

def asr(media, out_dir, model, prompt=""):
    """אוזן 1 = large-v3 העברי, אוזן 2 = turbo. ב-Modal — תמיד עם --model מפורש, ובודקים מה רץ בפועל.

    🚨 נולד בבדיקה הראשונה (19/10): asr.py בלי --model טוען את large-v3, ואם הטעינה נכשלת
    הוא נופל *בשקט* ל-turbo. שתי "האוזניים" יצאו אותו מודל, טקסט זהה מילה במילה, אפס ספקות —
    ו"בברכיו"/"ניס"/"ברור שעשה" היו נצרבים. large-v3 מפורש, באותה דקה, שמע נכון."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    def done(m):            # כבר תומלל (ריצה חוזרת אחרי הפסקה) — קובץ שלם ומאותו מודל
        try:
            d = json.load(open(out_dir / (Path(m).stem + "_words.json"), encoding="utf-8"))
            return isinstance(d.get("words"), list) and d.get("model", model) == model
        except (OSError, ValueError):
            return False
    todo = [m for m in media if not done(m)]
    if not todo:
        media_all, media = media, []
    else:
        media_all, media = media, todo
    # Modal קודם, גם כש-SHORTS_ASR=local (כך מוגדר אצלו): large-v3 על המעבד שלו נתקע 17 דקות על
    # קליף של 39 שניות (19/10), וב-Modal זה 30 שניות ואגורות. המחשב — רק כגיבוי:
    #  · בהגדרה "מנוע תמלול: המחשב" (asr_engine=cpu — מי שאין לו Modal / נגמר הקרדיט / מי ששיתפו איתו)
    #  · או כש-Modal נפל באמצע — ורק אחרי שאישר ("💻 תמלל במחשב" → MAKE_SHORT_ASR_ALLOW_CPU=1). 22/10: לפני זה
    #    המעבר למחשב היה בשקט (שורה ביומן), והכתוביות יצאו פחות מדויקות בלי שידע.
    engine = SET.load().get("asr_engine", "modal")
    if media and engine == "modal" and os.environ.get("MAKE_SHORT_ASR", "modal") == "modal":
        def dur(m):
            try:
                return duration(m)
            except (RuntimeError, ValueError):
                return 60.0
        MD.gate(MD.clip_estimate([dur(m) for m in media]), "תמלול %d קבצים (%s)" % (len(media), model.split("/")[-1]))
    try:
        if not media:
            pass
        elif engine == "cpu":
            raise RuntimeError("בהגדרות נבחר תמלול במחשב")
        elif os.environ.get("MAKE_SHORT_ASR", "modal") != "modal":
            raise RuntimeError("Modal כבוי ב-MAKE_SHORT_ASR")
        else:
            run([PY, HERE / "modal_asr.py", "run", "--media", *media, "--out-dir", out_dir, "--model", model]
                + (["--prompt", prompt] if prompt else []))
    except RuntimeError as ex:
        why = str(ex).splitlines()[-1][:120] if str(ex).strip() else "שגיאה"
        if os.environ.get("MAKE_SHORT_ASR_NO_CPU") == "1":
            # "הכן לעבודה בלי אינטרנט" (כרטיס 12): תמלול במחשב = מודל חלש יותר = כתוביות פחות טובות. לא בלי לשאול.
            raise RuntimeError("Modal לא זמין (%s) — לא מתמלל במחשב בלי לשאול (האיכות נמוכה יותר). "
                               "ימשיך לבד כשיחזור החיבור" % why)
        if engine != "cpu" and os.environ.get("MAKE_SHORT_ASR_ALLOW_CPU") != "1":
            raise RuntimeError("Modal לא זמין (%s) — לא עבר לתמלול במחשב בלי לשאול: במחשב זה איטי (רבע שעה ויותר "
                               "לקליף) ופחות מדויק. אפשר: \"🔁 נסה שוב\" (Modal), או \"💻 תמלול במחשב\"" % why)
        say("   ⚠️ %s — מתמלל במחשב (איטי ופחות מדויק), זה יכול לקחת הרבה זמן" %
            ("תמלול במחשב לפי ההגדרות" if engine == "cpu" else "Modal לא זמין (%s), ואישרתם תמלול במחשב" % why))
        env = dict(os.environ, SHORTS_MODEL=model)
        r = subprocess.run([PY, str(HERE / "asr.py"), "run", "--media", *map(str, media), "--out-dir", str(out_dir)],
                           env=env, capture_output=True, text=True, errors="replace")
        if r.returncode:
            raise RuntimeError("התמלול נכשל:\n" + (r.stderr or r.stdout)[-800:])
    res = {}
    for m in media_all:
        p = out_dir / (Path(m).stem + "_words.json")
        if not p.exists():
            raise RuntimeError("התמלול לא יצר %s" % p.name)
        data = json.load(open(p, encoding="utf-8"))
        if data.get("model") and data["model"] != model:
            raise RuntimeError("התמלול רץ על %s במקום %s — אוזן שנייה כזאת לא שווה כלום" % (data["model"], model))
        res[str(m)] = data["words"]
    return res


def two_ears(w1, w2):
    """טקסט אחד לעריכה: מה ששתי האוזניים שמעו זהה — כמו שהוא; מה שחלוק — [א / ב]."""
    t1 = [w["word"].strip() for w in w1 if w["word"].strip()]
    t2 = [w["word"].strip() for w in w2 if w["word"].strip()]
    sm = difflib.SequenceMatcher(None, [norm(x) for x in t1], [norm(x) for x in t2], autojunk=False)
    w1 = [w for w in w1 if w["word"].strip()]
    out, doubts = [], []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            # אותה מילה — עם הפיסוק של מי שיש לו. whisper לא עקבי בפיסוק בין ריצות (19/10: אותו
            # קליף יצא פעם עם פסיקים ונקודות ופעם בלי אף אחד), והפיסוק קובע איפה שורת כתובית נגמרת.
            out += [b if b[-1:] in ",.?!:;" and a[-1:] not in ",.?!:;" else a
                    for a, b in zip(t1[i1:i2], t2[j1:j2])]
        else:
            d = "[%s / %s]" % (" ".join(t1[i1:i2]) or "—", " ".join(t2[j1:j2]) or "—")
            out.append(d)
            # זמן הספק בקליף — כדי שהחלון יקפוץ בנגן בדיוק לשם
            at = w1[min(i1, len(w1) - 1)]["start"] if w1 else 0.0
            doubts.append([round(at, 2), d])
    return " ".join(out), doubts


# ──────────────── כתוביות יוטיוב — אוזן שלישית, לעיון ────────────────

def fetch_captions(url, d, offline=False):
    d.mkdir(parents=True, exist_ok=True)
    # offline = "המשך בלי אינטרנט": הכתוביות ירדו (או שאין לסרטון) כבר בשלב הרשת — לא מנסים שוב בלי חיבור
    if not list(d.glob("yt*.srt")) and not offline:
        run([SHORTS, "yt-dlp", "--skip-download", "--write-auto-subs", "--write-subs", "--sub-langs", "iw.*,he.*",
             "--convert-subs", "srt", "-o", d / "yt", "--", url], check=False)
    cues = []
    for f in sorted(d.glob("yt*.srt")):
        for blk in re.split(r"\n\s*\n", f.read_text(encoding="utf-8", errors="replace")):
            m = re.search(r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)\s*\n(.*)", blk, re.S)
            if m:
                g = [int(x) for x in m.groups()[:8]]
                cues.append((g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000,
                             g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000,
                             " ".join(m.group(9).split())))
        if cues:
            break
    return cues


def captions_for(cues, cuts):
    """רצף המילים של כתוביות יוטיוב לכל חלק. הכתוביות האוטומטיות "מתגלגלות" — כל שורה חוזרת
    בשתיים-שלוש כתוביות — ולכן מוסיפים מכל אחת רק את מה שעוד לא נכתב."""
    pieces = []
    for a, b in cuts:
        seq = []
        for s, e, t in cues:
            if e > a and s < b:
                w = t.split()
                k = next((k for k in range(min(len(w), len(seq)), 0, -1) if seq[-k:] == w[:k]), 0)
                seq += w[k:]
        pieces.append(seq)
    return pieces


def borrow_punct(text, cap_words):
    """פיסוק מכתוביות יוטיוב למילים שאין להן. שתי האוזניים של whisper לפעמים כמעט בלי פיסוק
    (19/10), והפיסוק הוא מה שקובע איפה שורת כתובית נגמרת. מילים בתוך [ספק] לא נוגעים."""
    toks = re.split(r"(\[[^\]]*\]|\s+)", text)
    plain = [k for k, t in enumerate(toks) if t and not t.isspace() and not t.startswith("[")]
    sm = difflib.SequenceMatcher(None, [norm(toks[k]) for k in plain], [norm(w) for w in cap_words], autojunk=False)
    for blk in sm.get_matching_blocks():
        for n in range(blk.size):
            k, cw = plain[blk.a + n], cap_words[blk.b + n]
            if toks[k][-1:] not in ",.?!:;" and cw[-1:] in ",.?!:;":
                toks[k] += cw[-1]
    return "".join(toks)


# ──────────────────────────── prepare ────────────────────────────

def auto_pick(spec):
    """בלי זמנים — הבחירה האוטומטית היא שלב נפרד (make_short_pick.py, כפתור "בחר לבד" בחלון),
    כי באמצע הוא בודק ומסמן את ההצעות. prepare עצמו תמיד מקבל זמנים."""
    raise ValueError("אין זמנים — כדי שהתוכנה תציע קטעים לבד, ללחוץ \"בחר קטעים לבד\"")


def video_height(p):
    try:
        return int(run([FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=height",
                        "-of", "csv=p=0", p]).strip().splitlines()[0])
    except Exception:
        return 0


def better_quality(src, url):
    """שיעור מתוזמן/פרטי יורד לפעמים רק ב-360p. עם העוגיות ו-player_client=web_safari יוטיוב נותן
    לרוב 720p — מנסים פעם אחת, ומחליפים רק אם יצא טוב יותר."""
    h = video_height(src)
    ck = SET.CONFIG / "youtube_cookies.txt"
    if not h or h >= 720 or not ck.exists():
        return
    say("   ⚠️ ירד רק ב-%dp — מנסה שוב דרך web_safari עם העוגיות, בשביל 720p" % h)
    alt = Path("source/full_video_safari.mp4")
    try:
        run([SHORTS, "yt-dlp", "--cookies", ck, "--extractor-args", "youtube:player_client=web_safari",
             "-f", "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b", "--merge-output-format", "mp4", "-o", alt, "--", url])
        h2 = video_height(alt)
        if h2 > h:
            os.replace(alt, src)
            say("   ✓ עכשיו %dp" % h2)
        else:
            say("   (גם כך רק %dp — ממשיך במה שיש)" % h2)
    except RuntimeError as ex:
        say("   (הניסיון נכשל — ממשיך ב-%dp: %s)" % (h, str(ex).splitlines()[-1][:120]))


def _quotes_of(c):
    """[(opening, closing)] לכל חלק של הקליף, או None אם אי אפשר לדייק (חלקים וציטוטים לא מתאימים)."""
    pq = c.get("piece_quotes")
    if pq and len(pq) == len(c["cuts"]):
        return [(q.get("opening"), q.get("closing")) for q in pq]
    if len(c["cuts"]) == 1 and (c.get("opening") or c.get("closing")):
        return [(c.get("opening"), c.get("closing"))]
    return None


def refine_by_quotes(clips, src, full):
    """קטע שנבחר מכתוביות יוטיוב (סריקת פלייליסט): הזמנים שם גסים. מתמללים לכל חלק חלון של ±45 שניות ב-large-v3
    ומחפשים בו את משפט הפתיחה והסיום שהמודל ציטט — ורק אז ההצמדה הרגילה לשקט."""
    import make_short_pick as MP
    todo = [(n, c, q) for n, c in enumerate(clips, 1) if c.get("refine") for q in [_quotes_of(c)] if q]
    if not todo:
        return
    say("③א מדייק את הזמנים מול תמלול מדויק (הם נבחרו מכתוביות יוטיוב)")
    wins = []
    for n, c, qs in todo:
        for k, (a, b) in enumerate(c["cuts"]):
            lo, hi = max(0.0, a - 45), min(full, b + 45)
            w = Path("work/snap/refine%d_%d_%d_%d.wav" % (n, k, lo * 10, hi * 10))
            if not w.exists():
                run([FFMPEG, "-y", "-v", "error", "-ss", "%.3f" % lo, "-t", "%.3f" % (hi - lo), "-i", src,
                     "-vn", "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", w])
            wins.append((c, k, qs[k], lo, w))
    words = asr([str(w) for *_, w in wins], "work/snap/refine_asr", LARGE)
    for c, k, (op, cl), lo, w in wins:
        ws = [dict(x, start=x["start"] + lo, end=x["end"] + lo) for x in words[str(w)] if x["word"].strip()]
        a, b = c["cuts"][k]
        o = MP.find_quote(ws, op, a, 40) if op else None
        e = MP.find_quote(ws, cl, b, 40, at_end=True) if cl else None
        na = o["t"] if o and o["score"] >= 0.6 else a
        nb = e["t"] if e and e["score"] >= 0.6 else b
        if nb > na + (3 if len(c["cuts"]) == 1 else 1.5):
            c["cuts"][k] = (na, nb)
        say("   %s%s → %s–%s  (פתיחה %s · סיום %s)" % (
            c.get("title") or "קליף", " חלק %d" % (k + 1) if len(c["cuts"]) > 1 else "", MP.mmss(na), MP.mmss(nb),
            "%.0f%%" % (o["score"] * 100) if o else "—", "%.0f%%" % (e["score"] * 100) if e else "—"))
        if (o and o["score"] < 0.6) or (e and e["score"] < 0.6):
            say("   ⚠️ ציטוט לא נמצא בתמלול המדויק — נשארו הזמנים מהכתוביות; לבדוק בעריכה")

YT_URL = re.compile(r"https?://(?:www\.|m\.|music\.)?(?:youtube\.com|youtu\.be)/[^\s\x00-\x1f]*")


def check_url(url):
    """4.1.0: קישור יוטיוב תקין בלבד. ערך אחר (למשל --exec=… או קישור לאתר זר) לא מגיע לעולם ל-yt-dlp — שם הוא
    היה נקרא כאופציה של התוכנה (הרצת פקודה). בנוסף, בכל קריאה ל-yt-dlp מהקוד יש "--" לפני הקישור."""
    u = str(url or "").strip()
    if not YT_URL.fullmatch(u):
        raise ValueError("צריך קישור של יוטיוב")
    return u


def project_for(url):
    """תיקיית העבודה של שיעור לפי הקישור — נקבעת לפני ההורדה, כדי שריצה חוזרת (המשך אחרי הפסקה,
    גם למחרת) תגיע לאותה תיקייה ולא תפתח תיקייה חדשה עם תאריך אחר."""
    m = re.search(r"(?:v=|youtu\.be/|shorts/|live/)([\w-]{11})", url or "")
    if not m:
        return None
    return TOOL_DIR / ("%s_auto-%s" % (time.strftime("%Y-%m-%d"), m.group(1)))


def wav_cut(src, lo, hi, out):
    """קטע שמע ל-wav — לקובץ זמני ואז שינוי שם: wav שנקטע באמצע לא יישאר בשם הסופי
    (ריצה חוזרת מדלגת על wav שקיים)."""
    out = Path(out)
    if out.exists():
        return
    tmp = out.with_name(out.stem + ".part.wav")
    args = ["-ss", "%.3f" % lo, "-t", "%.3f" % (hi - lo)] if lo is not None else []
    run([FFMPEG, "-y", "-v", "error", *args, "-i", src, "-vn", "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", tmp])
    os.replace(tmp, out)


XFADE = 0.18      # כמו build_clean_video.XFADE_DUR — מעבר בין חלקים של קליף


def source_clip_wav(src, cuts, out):
    """השמע של הקליף הנקי — ישר מהשיעור, בלי לבנות את הווידאו (כרטיס 12, "הכן לעבודה בלי אינטרנט").
    אותם חיבורים בדיוק כמו multi_piece_clip + build_clean: כל חלק (a, b) מהשיעור, ובין חלקים acrossfade של 0.18ש'.
    כך התמלול (שצריך אינטרנט) נעשה עכשיו, והזמנים שלו נופלים בדיוק על הקליף שייבנה אחר כך בלי רשת."""
    out = Path(out)
    if out.exists():
        return
    ins, fc = [], []
    for i, (a, b) in enumerate(cuts):
        ins += ["-ss", "%.3f" % a, "-t", "%.3f" % (b - a), "-i", src]
        fc.append("[%d:a]aresample=48000,aformat=channel_layouts=mono[a%d]" % (i, i))
    cur = "a0"
    for i in range(1, len(cuts)):
        fc.append("[%s][a%d]acrossfade=d=%s[x%d]" % (cur, i, XFADE, i))
        cur = "x%d" % i
    tmp = out.with_name(out.stem + ".part.wav")
    run([FFMPEG, "-y", "-v", "error", *ins, "-filter_complex", ";".join(fc), "-map", "[%s]" % cur,
         "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", tmp])
    os.replace(tmp, out)


def _cuts_key(clips):
    return hashlib.md5(json.dumps([[c.get("pieces"), bool(c.get("refine")), c.get("piece_quotes") or []]
                                   for c in clips], ensure_ascii=False).encode()).hexdigest()[:10]


def need_net_data(what):
    raise ValueError("%s עוד לא נעשה — לזה צריך אינטרנט. \"⏸ הכן לעבודה בלי אינטרנט\" כשיש חיבור, ואז אפשר להמשיך בלי." % what)


def dedupe_clips(clips, wins, words):
    """כרטיס 25: מילה שחוזרת מיד על עצמה ("הוא הוא") נחתכת גם מהקול, בתוך שקט שנמדד — או נשארת ונרשמת.
    נקרא רק לרב שהפרופיל שלו מדליק את זה (make_short_rabbis.dedupe_on). הקלט — מה שכבר קיים בשלב "הצמדת הגבולות":
    wins = [(clip, k, lo, wav)] (חלון סביב כל חתיכה), words = {str(wav): מילים בזמני החלון} — שום תמלול נוסף.
    מעדכן את c["cuts"] (חתיכה נחתכת לשתיים) ומחזיר {clip: [רשומות]} (make_short_repeats.plan_piece)."""
    out = {}
    by = {(c["name"], k): (lo, w) for c, k, lo, w in wins}
    for c in clips:
        new, recs = [], []
        for k, (s, e) in enumerate(c["cuts"]):
            lo, w = by[(c["name"], k)]
            ws = [dict(x, start=x["start"] + lo, end=x["end"] + lo) for x in words[str(w)]]
            pcs, rc = RP.plan_piece(ws, load_audio(w), lo, s, e, RB.KEEP_REPEATS, opening=(k == 0 and not new))
            new += pcs
            recs += [dict(r_, piece=k) for r_ in rc]
        if recs:
            out[c["name"]] = recs
            c["cuts"] = new
            for r_ in recs:
                say("   %s %s «%s» ב-%s%s" % (c["name"], "✂️ הוסרה חזרה" if r_["action"] == "removed" else
                                            "⚠️ נשארה חזרה", r_["word"], mmss_(r_["t"]),
                                            "" if r_["action"] == "removed" else " — " + r_["why"]))
    return out


def prepare(spec_path, mode=None):
    """mode (כרטיס 12, 21/10/2026 — "להכין כשיש אינטרנט ולסיים בלי"):
      "net"   = רק השלבים שצריכים רשת: פרטי הסרטון, הורדה, דיוק והצמדת הגבולות (תמלול), שתי האוזניים על השמע
                של הקליפים (חתוך ישר מהשיעור — source_clip_wav), כתוביות יוטיוב. בלי חיתוך וידאו ובלי טקסט לעריכה.
      "local" = ההמשך בלי רשת: חיתוך ומעקב פנים, ואז הטקסט לעריכה מהתמלול שכבר נעשה. שלב רשת שחסר — נעצר עם
                הסבר, ולעולם לא נופל לתמלול במחשב (מודל חלש יותר)."""
    import make_short_progress as PR
    if mode in ("net", "local"):
        os.environ["MAKE_SHORT_ASR_NO_CPU"] = "1"
    spec = json.load(open(spec_path, encoding="utf-8-sig"))
    url = spec["url"].strip()
    if not [c for c in spec.get("clips", []) if (c.get("pieces") or "").strip()]:
        auto_pick(spec)
    clips = [dict(c, cuts=parse_pieces(c.get("pieces", ""))) for c in spec["clips"]
             if (c.get("pieces") or "").strip()]
    for w in SET.rule_warnings([sum(b - a for a, b in c["cuts"]) for c in clips]):
        say("⚠️ %s (לפי הזמנים שנכתבו; ממשיך כי זו בחירה שלך)" % w)

    # תיקיות העבודה של התוכנה — projects/תוכנה/, לא ליד תיקיות העבודה של Claude (בקשתו 20/10).
    # 21/10: נקבעת לפני הכול ונרשמת במפרט, כדי ש"המשך" יגיע בדיוק לכאן
    P = Path(spec.get("project") or project_for(url) or TOOL_DIR / ("%s_auto" % time.strftime("%Y-%m-%d_%H%M")))
    P.mkdir(parents=True, exist_ok=True)
    own_spec = P / "make_short_spec.json"
    if Path(spec_path).resolve() != own_spec.resolve():
        spec["project"] = str(P)
        own_spec.write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding="utf-8")
    say("PROJECT=%s" % P)
    os.chdir(P)
    PR.job_begin(P, "prepare", ["prepare", own_spec] + (["--%s" % {"net": "net-only", "local": "local"}[mode]] if mode else []))
    for d in ("source", "shorts", "work/clips", "work/snap", "work/subtitles", EDIT_DIR):
        Path(d).mkdir(parents=True, exist_ok=True)
    key = _cuts_key(clips)
    D = PR.data(P)
    if D.get("cuts_key") != key:          # מפרט אחר (זמנים חדשים) — שום שלב חיתוך קודם לא תקף
        for k in ("refined", "snapped", "built", "framing", "dedupe"):
            D.pop(k, None)
        D["cuts_key"] = key
        PR.put(P, "cuts_key", key)
        for k in ("refined", "snapped", "built", "framing", "dedupe"):
            PR.put(P, k, None)
    names = ["clip%d" % n for n in range(1, len(clips) + 1)]
    est_b = [int(30 + 2.5 * sum(b - a for a, b in c["cuts"])) for c in clips]
    net_steps = [["info", "פרטי הסרטון", 5], ["download", "הורדת השיעור", 120]] + \
        ([["refine", "דיוק הזמנים מול תמלול מדויק", 45]] if any(c.get("refine") for c in clips) else []) + \
        [["snap", "הצמדת הגבולות לשקט", 35]]
    if mode == "net":
        PR.plan(P, net_steps + [["ears", "תמלול בשתי אוזניים (מהשמע של השיעור)", 60], ["captions", "כתוביות יוטיוב", 8]])
    else:
        PR.plan(P, net_steps +
                [["build:%s" % n, "חיתוך ומעקב פנים — קליף %d/%d" % (i + 1, len(names)), est_b[i]] for i, n in enumerate(names)] +
                [["ears", "תמלול בשתי אוזניים", 60], ["edit", "הכנת הטקסט לתיקון", 8]])

    PR.step(P, "info", "run")
    say("① פרטי הסרטון")
    info = D.get("info")
    if not info and mode == "local":
        need_net_data("פרטי הסרטון")
    if not info:
        info = run([SHORTS, "yt-dlp", "--skip-download", "--no-warnings", "--print",
                    "%(id)s\t%(title)s\t%(channel_url)s", "--", url]).strip().splitlines()[-1].split("\t")
        PR.put(P, "info", info)
    vid, vtitle, chan = info[0], info[1], info[2] if len(info) > 2 else ""
    g_rabbi, g_series = guess_names(vtitle)
    rabbi = (spec.get("rabbi") or g_rabbi).strip()
    series = series_title = (spec.get("series") or g_series).strip()   # בתיאור — כמו בכותרת, עם הגרשיים
    rabbi, series = existing_folder(rabbi, series)
    say("   %s\n   רב: %s · סדרה: %s" % (vtitle, rabbi or "?", series or "?"))
    say("TITLE=%s" % vtitle)
    prof = RB.get(rabbi)
    if prof:                       # כרטיס 25: מה שסוכם על הרב הזה — מצלמה, עצירת כתוביות, חזרות
        use_rabbi(rabbi)
        say("   📇 פרופיל הרב: %s" % " · ".join(x for x in (
            "כתוביות: עצירה %.1f ש'" % prof["sub_gap"] if prof.get("sub_gap") else "",
            "מצלמה %s/%s" % (prof["camera"]["trigger_sec"], prof["camera"]["max_pan"])
            if (prof.get("camera") or {}).get("trigger_sec") else "",
            "מסיר מילים שחוזרות" if prof.get("dedupe_repeats") else "",
            "%d מילים" % len(prof["words"]) if prof.get("words") else "") if x))
    PR.step(P, "info", "done", vtitle)

    src = Path("source/full_video.mp4")
    PR.step(P, "download", "run")
    if PR.media_ok(src):
        PR.step(P, "download", "skip", "כבר הורד")
    elif mode == "local":
        need_net_data("הורדת השיעור")
    else:
        say("② מוריד את השיעור (כמה דקות)")
        # yt-dlp ממשיך לבד הורדה שנקטעה (קובץ .part); הקובץ הסופי נכתב רק בסוף, אחרי המיזוג
        run([SHORTS, "yt-dlp", "-f", "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b",
             "--merge-output-format", "mp4", "-o", src, "--", url])
        better_quality(src, url)
        PR.step(P, "download", "done")
    full = duration(src)
    for c in clips:
        for a, b in c["cuts"]:
            if b > full + 1:
                raise ValueError("הזמן %d:%02d אחרי סוף השיעור (%d:%02d)" % (b // 60, b % 60, full // 60, full % 60))
    if any(c.get("refine") for c in clips):
        PR.step(P, "refine", "run")
        if D.get("refined"):
            for c, cuts in zip(clips, D["refined"]):
                c["cuts"] = [tuple(x) for x in cuts]
            PR.step(P, "refine", "skip", "כבר נעשה")
        elif mode == "local":
            need_net_data("דיוק הזמנים (תמלול)")
        else:
            refine_by_quotes(clips, src, full)
            PR.put(P, "refined", [c["cuts"] for c in clips])
            PR.step(P, "refine", "done")

    for n, c in enumerate(clips, 1):
        c["name"] = "clip%d" % n
    PR.step(P, "snap", "run")
    if D.get("snapped"):
        for c, cuts in zip(clips, D["snapped"]):
            c["cuts"] = [tuple(x) for x in cuts]
        PR.step(P, "snap", "skip", "כבר נעשה")
    elif mode == "local":
        need_net_data("הצמדת הגבולות (תמלול)")
    else:
        say("③ מתמלל חלון סביב כל קטע ומצמיד את הגבולות לשקט אמיתי")
        wins = []
        for c in clips:
            for k, (a, b) in enumerate(c["cuts"]):
                lo, hi = max(0.0, a - 4), min(full, b + 4)
                # 🚨 הזמנים בשם הקובץ: asr מדלג על קובץ שכבר תומלל (מוקש 19), וריצה חוזרת עם זמנים אחרים
                # הייתה מקבלת את התמלול הישן בלי שום שגיאה
                w = Path("work/snap/%s_p%d_%d_%d.wav" % (c["name"], k, lo * 10, hi * 10))
                wav_cut(src, lo, hi, w)
                wins.append((c, k, lo, w))
        words = asr([str(w) for *_, w in wins], "work/snap/asr", TURBO)   # לגבולות מספיק המהיר
        for c, k, lo, w in wins:
            ws = [dict(x, start=x["start"] + lo, end=x["end"] + lo) for x in words[str(w)]]
            a, b = c["cuts"][k]
            s, e, first, last = snap_piece(ws, load_audio(w), lo, a, b, opening=(k == 0))
            c["cuts"][k] = (s, e)
            say("   %s חלק %d: %.1f–%.1f  «%s … %s»" % (c["name"], k + 1, s, e, first, last))
        dedup = dedupe_clips(clips, wins, words) if RB.dedupe_on(rabbi) else {}
        PR.put(P, "snapped", [c["cuts"] for c in clips])
        PR.put(P, "dedupe", dedup)
        PR.step(P, "snap", "done")

    # תיקייה לפי הגבולות של *כל* הקליפים: שמות הקבצים (clip1, clip2) חוזרים בכל ריצה, ו-asr
    # מדלג על מה שכבר תומלל — תיקייה ישנה הייתה מחזירה תמלול של חיתוך קודם (מוקש 12)
    run_tag = hashlib.md5(json.dumps([c["cuts"] for c in clips]).encode()).hexdigest()[:8]
    if mode == "net":
        # שתי האוזניים על השמע של הקליפים, חתוך ישר מהשיעור (אותם חיבורים כמו הבנייה) — בלי לבנות וידאו
        say("⑤ מתמלל את הקליפים בשתי אוזניים (מהשמע של השיעור — הווידאו ייבנה אחר כך, גם בלי אינטרנט)")
        PR.step(P, "ears", "run")
        d = Path("work/ear_%s" % run_tag)
        d.mkdir(parents=True, exist_ok=True)
        wavs = []
        for c in clips:
            w = str(d / ("%s.wav" % c["name"]))
            source_clip_wav(str(src), c["cuts"], w)
            wavs.append(w)
        asr(wavs, "work/ear_large_" + run_tag, LARGE)
        asr(wavs, "work/ear_turbo_" + run_tag, TURBO)
        PR.step(P, "ears", "done")
        PR.step(P, "captions", "run")
        fetch_captions(url, Path("work/captions"))
        PR.step(P, "captions", "done")
        PR.put(P, "net_ready", {"at": time.strftime("%Y-%m-%d %H:%M"), "tag": run_tag, "title": vtitle})
        say("STAGE=net_ready")
        say("\n✅ מוכן לעבודה בלי אינטרנט: ההורדה והתמלול נעשו. החיתוך, מעקב הפנים והטקסט לתיקון — "
            "\"▶ המשך בלי אינטרנט\" (על המחשב, בלי רשת).")
        return

    built = PR.data(P).get("built") or {}
    framing = PR.data(P).get("framing") or {}
    import camera_path as CP
    cam0 = SET.load().get("camera_default") or "default"     # 28/10 (כרטיס 22): מצלמה לקליפים חדשים
    for i, c in enumerate(clips):
        n = c["name"]
        c["clean"] = "work/clips/%s_clean.mp4" % n
        bkey = hashlib.md5(json.dumps(c["cuts"] + ([cam0] if cam0 != "default" else [])).encode()).hexdigest()[:10]
        PR.step(P, "build:" + n, "run")
        expect = sum(b - a for a, b in c["cuts"])
        if built.get(n) == bkey and PR.media_ok(c["clean"], expect, tol=max(2.0, 0.15 * expect)):
            say("④ %s: כבר נבנה ✓" % n)
            PR.step(P, "build:" + n, "skip", "כבר נבנה")
        else:
            say("④ %s: בונה וידאו אנכי עם מעקב פנים (כמה דקות)" % n)
            with heavy(n):
                if cam0 == "default":
                    run([PY, HERE / "multi_piece_clip.py", n, *["%.3f,%.3f" % ab for ab in c["cuts"]]], cwd=P)
                else:
                    r = subprocess.run([PY, str(HERE / "multi_piece_clip.py"), n, *["%.3f,%.3f" % ab for ab in c["cuts"]]],
                                       cwd=P, env=CP.cam_env(os.environ, cam0), capture_output=True, text=True,
                                       errors="replace")
                    if r.returncode:
                        raise RuntimeError("הבנייה נכשלה:\n" + "\n".join((r.stderr or r.stdout).strip().splitlines()[-8:]))
            built[n] = bkey
            PR.put(P, "built", built)
            framing.pop(n, None)
            ca = dict(PR.data(P).get("camera_auto") or {})
            if ca.pop(n, None):
                PR.put(P, "camera_auto", ca)
            PR.step(P, "build:" + n, "done")
        c["seconds"] = round(duration(c["clean"]), 1)
        c["camera"] = cam0
        c["framing"] = framing.get(n)
        if c["framing"] is None and SET.load()["camera_check"]:
            c["framing"] = framing[n] = check_framing(c["clean"], cam0)
            PR.put(P, "framing", framing)
            if not c["framing"]["ok"]:
                say("   ⚠️ %s: הרב לא תמיד במרכז — %s" % (n, c["framing"]["text"]))
            ex = c["framing"].get("exits") or {}
            if ex.get("sec"):
                say("   ⚠️ %s: הרב יוצא מהמסגרת ב-%.0f שניות (%s)%s" % (
                    n, ex["sec"], ex["times"], "" if ex.get("zippy_sec") is None else
                    " — במצלמה זריזה: %.0f שניות" % ex["zippy_sec"]))
                # exit_fix=auto: בונים מיד במצלמה זריזה, רק כשהמדידה מראה שהיא באמת טובה יותר.
                # ברירת המחדל "offer" — הכרטיס מציע, והוא מחליט אחרי שראה לפני/אחרי.
                if SET.load().get("exit_fix") == "auto" and cam0 != "zippy" and ex.get("zippy_sec", ex["sec"]) < ex["sec"]:
                    say("   ⑤ %s: בונה שוב במצלמה זריזה (ההגדרה \"לתקן לבד\")" % n)
                    build_camera(P, c, "zippy")
                    framing[n] = c["framing"]
                    PR.put(P, "framing", framing)
                    PR.put(P, "camera_auto", dict(PR.data(P).get("camera_auto") or {}, **{n: "zippy"}))
        if (PR.data(P).get("camera_auto") or {}).get(n) and built.get(n) == bkey:
            c["camera"] = PR.data(P)["camera_auto"][n]      # המשך אחרי הפסקה: הבנייה הזריזה כבר נעשתה

    say("⑤ מתמלל את הקליפים בשתי אוזניים")
    PR.step(P, "ears", "run")
    # אחרי "הכן לעבודה בלי אינטרנט": ה-wav (מהשמע של השיעור) והתמלולים כבר כאן — asr מדלג עליהם, בלי רשת
    for c in clips:
        d = Path("work/ear_%s" % run_tag)
        d.mkdir(parents=True, exist_ok=True)
        c["wav"] = str(d / ("%s.wav" % c["name"]))
        wav_cut(c["clean"], None, None, c["wav"])
    import make_short_editor as ED
    # 28/10: המילון האישי כרמז ל-whisper — רק לאוזן 1, ואוזן 2 (בלי רמז) שומרת שהרמז לא בלע התחלה או משפט
    hint = ED.asr_hint(rabbi=rabbi) if mode != "local" else ""      # כרטיס 25: גם מילים מפרופיל הרב
    ear1 = asr([c["wav"] for c in clips], "work/ear_large_" + run_tag, LARGE, prompt=hint)
    try:
        ear2 = asr([c["wav"] for c in clips], "work/ear_turbo_" + run_tag, TURBO)
    except MD.OverCap:                   # תקרת היום — עוצרים ושואלים, לא ממשיכים בשקט עם אוזן אחת
        raise
    except Exception as ex:
        say("   ⚠️ האוזן השנייה (Modal) נכשלה — הכתוביות של יוטיוב יהיו ההשוואה היחידה:\n   %s" % ex)
        ear2 = {}
    bad = [c["wav"] for c in clips if hint and c["wav"] in ear2 and ED.hint_suspect(ear1[c["wav"]], ear2[c["wav"]])]
    if bad:
        say("   ↻ התמלול עם רמז המילון נראה חסר ב-%d קליפים — מתמלל אותם שוב בלי רמז" % len(bad))
        ear1.update(asr(bad, "work/ear_large_plain_" + run_tag, LARGE))
    PR.step(P, "ears", "done")

    PR.step(P, "edit", "run")
    cues = fetch_captions(url, Path("work/captions"), offline=(mode == "local"))
    for c in clips:
        w1 = ear1[c["wav"]]
        c["ear1"] = "work/subtitles/%s_ear1.json" % c["name"]
        json.dump({"words": w1}, open(c["ear1"], "w", encoding="utf-8"), ensure_ascii=False)
        text, doubts = two_ears(w1, ear2[c["wav"]]) if c["wav"] in ear2 else \
            (" ".join(w["word"].strip() for w in w1), None)
        cap = captions_for(cues, c["cuts"])
        text = borrow_punct(text, [w for p in cap for w in p])
        c["doubts"] = doubts
        yt = "\n…\n".join(" ".join(p) for p in cap if p) or "(אין כתוביות יוטיוב לסרטון הזה)"
        edit = Path(EDIT_DIR) / ("%s.txt" % c["name"])
        edit.write_text(EDIT_TEMPLATE.format(
            title=c.get("title", ""), desc=c.get("description", ""), tags=c.get("tags", ""),
            video=win_path(P / c["clean"]), sec=c["seconds"], text=text, yt=yt), encoding="utf-8")
        # 28/10 (העורך החכם): הבסיס למיזוג אם יתקן לפני שהעורך יחזור, ומה ש"נמסר" (למד האיכות)
        c["editor_base"] = keep_version(P, edit)
        c["edit"] = str(edit)
        f2 = Path("work/ear_turbo_%s/%s_words.json" % (run_tag, c["name"]))
        c["ear2"] = str(f2) if c["wav"] in ear2 and f2.exists() else ""
        ED.write_delivered(P, c["name"], text, "ears")
        # 🔠 הגדלת מילים (כרטיס 15): ההצעה של המודל נשמרת תמיד; נחשפת ונצרבת רק כשהמתג דולק.
        # ריצה חוזרת (המשך אחרי הפסקה) לא דורסת מה שכבר ערך
        import make_short_emph as EM
        if EM.load(P, c["name"]) is None:
            prop = EM.clean_picks(c.get("emphasis"))
            EM.save(P, c["name"], {"on": bool(SET.load().get("emph_default")), "picks": None,
                                   "proposed": prop or None,
                                   "src": (c.get("emph_src") or "gemini") if prop else None})

    warns = SET.rule_warnings([c["seconds"] for c in clips])
    for w in warns:
        say("   ⚠️ %s" % w)
    state = {"url": url, "video_id": vid, "video_title": vtitle, "channel_url": chan,
             "rabbi": rabbi, "series": series, "series_title": series_title, "project": str(P),
             "warnings": warns,
             "clips": [{k: c[k] for k in ("name", "cuts", "clean", "seconds", "ear1", "edit", "doubts",
                                          "camera", "framing", "ear2", "editor_base")}
                       for c in clips]}
    if SET.load().get("smart_editor", True):
        # העורך לא רץ כאן: החלון שולח אותו — אם יש עוד שיעורים בדרך, כולם בבקשה אחת (make_short_editor.py)
        state["editor"] = {"status": "pending", "since": time.time()}
    for c in state["clips"]:                     # התיאור מההצעה (Gemini) — נערך עכשיו בשלב העריכה
        c["proposed_desc"] = next((x.get("description", "") for x in clips if x["name"] == c["name"]), "")
        c["hook_quote"] = next((x.get("hook_quote", "") for x in clips if x["name"] == c["name"]), "")    # 🎬 הצעת המודל להוק (6/11)
        c["repeats"] = (PR.data(P).get("dedupe") or {}).get(c["name"], [])      # כרטיס 25: חזרות שהוסרו / נשארו
    save_st(state)
    PR.step(P, "edit", "done")
    say("STAGE=ready_edit")
    say("\n✅ ההכנה הסתיימה. עכשיו לתקן את קובצי העריכה:")
    for c in clips:
        say("   %s (%.0f שניות, %s ספקות): %s" % (c["name"], c["seconds"],
                                                  "?" if c["doubts"] is None else len(c["doubts"]),
                                                  win_path(P / c["edit"])))
    say("PROJECT=%s" % P)


EDIT_TEMPLATE = """כותרת: {title}
תיאור: {desc}
תגיות: {tags}

# כותרת — קצרה ומסקרנת. שם הרב יתווסף לבד.
# תיאור — שורה או כמה שורות, עוצר בסקרנות בלי לגלות את הפואנטה. הקישורים, ההרשמה והמוזיקה מתווספים לבד.
# תגיות — מופרדות בפסיקים (לא חובה). שם הרב, הסדרה והתגיות הקבועות מההגדרות מתווספים לבד.
# לצפייה בקטע ({sec} שניות): {video}

{sep}
# תקנו מילים והוסיפו פיסוק: פסיק איפה שהרב עוצר, נקודה בסוף משפט — הפיסוק קובע איפה שורת כתובית נגמרת.
# [א / ב] = שתי מערכות התמלול שמעו אחרת. השאירו רק את הנכון ומחקו את הסוגריים. "—" = לא נאמר כלום.
# ציטוט מפסוק או מחז"ל — לנוסח המקורי. לחכמים — התואר המלא (רבן שמעון בן גמליאל).
# מילה שלא ברורה גם אחרי שמיעה — אפשר למחוק אותה. אסור למחוק משפטים שלמים.
# שורות שמתחילות ב-# לא נכנסות לסרטון.

{text}

{ref} — כתוביות יוטיוב האוטומטיות לאותו קטע (אוזן שלישית; לא נכנס לסרטון) ====
{yt}
""".replace("{sep}", SEP_TEXT).replace("{ref}", SEP_REF)


# ──────────────────────────── finish ────────────────────────────

def parse_edit(path):
    txt = Path(path).read_text(encoding="utf-8-sig")
    head, _, rest = txt.partition(SEP_TEXT)
    body = rest.split(SEP_REF)[0]
    fields, cur = {"כותרת": "", "תיאור": "", "תגיות": ""}, None
    for line in head.splitlines():
        m = re.match(r"\s*(כותרת|תיאור|תגיות)\s*:\s*(.*)", line)
        if m:
            cur = m.group(1)
            fields[cur] = m.group(2).strip()
        elif line.lstrip().startswith("#"):
            cur = None
        elif cur == "תיאור" and line.strip():      # תיאור של כמה שורות
            fields[cur] = (fields[cur] + "\n" + line.strip()).strip()
    text = " ".join(l for l in body.splitlines() if not l.lstrip().startswith("#"))
    left = re.findall(r"\[[^\]]*\]", text)

    def first_ear(m):
        a = m.group(1).split("/")[0].strip()
        return "" if a in ("—", "-") else a
    text = " ".join(re.sub(r"\[([^\]]*)\]", first_ear, text).split())
    return fields, text, left


def read_edit_raw(path):
    """לחלון: השדות, הטקסט עם הסוגריים כמו שהם, וכתוביות יוטיוב."""
    txt = Path(path).read_text(encoding="utf-8-sig")
    fields, _, _ = parse_edit(path)
    rest = txt.partition(SEP_TEXT)[2]
    body, _, ref = rest.partition(SEP_REF)
    text = "\n".join(l for l in body.splitlines() if not l.lstrip().startswith("#")).strip()
    yt = ref.split("\n", 1)[1].strip() if "\n" in ref else ""
    return {"title": fields["כותרת"], "desc": fields["תיאור"], "tags": fields["תגיות"], "text": text, "yt": yt}


def write_edit(path, clip, project, title, desc, tags, text, yt):
    # קובץ זמני ואז שינוי שם: עבודה שקוראת את הקובץ באותו רגע (בנייה מחדש) לא תקרא חצי קובץ
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(EDIT_TEMPLATE.format(
        title=title.strip(), desc=desc.strip(), tags=tags.strip(), video=win_path(Path(project) / clip["clean"]),
        sec=clip["seconds"], text=text.strip(), yt=yt.strip()), encoding="utf-8")
    os.replace(tmp, path)
    keep_version(project, path)


# ─────────────── גרסאות של קובץ העריכה + מיזוג (21/10/2026, כרטיס 12) ───────────────
# הבעיה: הוא הזיז את הגבולות של קליף 1 והמשיך לתקן מילים בזמן הבנייה; הבנייה כותבת בסוף טקסט חדש (עם מה
# שנוסף), והשמירה האוטומטית של הדף הייתה דורסת אותו — או להפך. עכשיו כל גרסה שנכתבת נשמרת בצד לפי טביעה,
# הדף שולח עם כל שמירה את הטביעה שממנה הוא התחיל, ואם הקובץ השתנה בינתיים — התיקונים שלו נמזגים לגרסה החדשה.

def edit_ver(path):
    try:
        return hashlib.md5(Path(path).read_bytes()).hexdigest()[:12]
    except OSError:
        return ""


def keep_version(project, path):
    """עותק של קובץ העריכה כמו שהוא עכשיו, לפי הטביעה (בסיס למיזוג). קטן — טקסט בלבד."""
    try:
        v = edit_ver(path)
        d = Path(project) / "work" / "edit_versions"
        d.mkdir(parents=True, exist_ok=True)
        f = d / ("%s_%s.txt" % (Path(path).stem, v))
        if not f.exists():
            shutil.copyfile(path, f)
        return v
    except OSError:
        return ""


def version_text(project, path, ver):
    f = Path(project) / "work" / "edit_versions" / ("%s_%s.txt" % (Path(path).stem, ver))
    if not ver or not f.exists():
        return None
    return read_edit_raw(f)


def _toks(t):
    return re.findall(r"\[[^\]]*\]|\S+", t or "")


def merge3(base, mine, theirs):
    """מיזוג שלושה כיווני ברמת מילים: התיקונים שעשה (base→mine) מוחלים על הגרסה החדשה (theirs).
    תיקון שהמקום שלו לא קיים יותר בגרסה החדשה (המילים ירדו בהזזת הגבולות) — לא מנחשים: חוזר ברשימת conflicts.
    מחזיר (טקסט, כמה תיקונים הוחלו, [תיקונים שלא הוחלו])."""
    b, m, t = _toks(base), _toks(mine), _toks(theirs)
    nb, nt = [norm(x) or x for x in b], [norm(x) or x for x in t]
    to_t = {}                                     # אינדקס ב-base → אינדקס ב-theirs, למילים שלא השתנו
    for blk in difflib.SequenceMatcher(None, nb, nt, autojunk=False).get_matching_blocks():
        for k in range(blk.size):
            to_t[blk.a + k] = blk.b + k
    edits, conflicts = [], []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, b, m, autojunk=False).get_opcodes():
        if op == "equal":
            continue
        new = m[j1:j2]
        if i2 > i1:                               # החלפה / מחיקה: כל המילים המקוריות צריכות להיות שם, ברצף
            idx = [to_t.get(i) for i in range(i1, i2)]
            if None in idx or idx != list(range(idx[0], idx[0] + len(idx))):
                conflicts.append(" ".join(b[i1:i2]) + " → " + (" ".join(new) or "(נמחק)"))
                continue
            edits.append((idx[0], idx[-1] + 1, new))
        else:                                     # הוספה: עוגן — המילה שלפני (או שאחרי, בתחילת הטקסט)
            if i1 > 0 and (i1 - 1) in to_t:
                pos = to_t[i1 - 1] + 1
            elif i1 in to_t:
                pos = to_t[i1]
            else:
                conflicts.append("נוסף: " + " ".join(new))
                continue
            edits.append((pos, pos, new))
    out = list(t)
    for a, z, new in sorted(edits, key=lambda e: (e[0], e[1]), reverse=True):
        out[a:z] = new
    return " ".join(out), len(edits), conflicts


def words_changed(old, new):
    """מה נוסף ומה ירד בין שני טקסטים — "נוסף בהתחלה: …", "ירד מהסוף: …" (להסבר בכרטיס)."""
    a, b = _toks(old), _toks(new)
    out = []
    ops = [o for o in difflib.SequenceMatcher(None, [norm(x) for x in a], [norm(x) for x in b], autojunk=False).get_opcodes()
           if o[0] != "equal"]
    for op, i1, i2, j1, j2 in ops:
        where = "בהתחלה" if i1 == 0 else ("בסוף" if i2 == len(a) else "באמצע")
        if j2 > j1:
            out.append("נוסף %s: %s" % (where, " ".join(b[j1:j2][:12]) + (" …" if j2 - j1 > 12 else "")))
        if i2 > i1:
            out.append("ירד %s: %s" % (where.replace("ב", "מה", 1) if where != "באמצע" else "מהאמצע",
                                       " ".join(a[i1:i2][:12]) + (" …" if i2 - i1 > 12 else "")))
    return out


def loudnorm(src, dst):
    """הקול ל-‎-14 LUFS לפני המוזיקה — היעדים של המוזיקה יחסיים לקול (24/9: קליפים יצאו ‎-11 עד ‎-38).
    שני מעברים: מעבר אחד נחת נמוך מדי (‎-15…-16)."""
    r = subprocess.run([FFMPEG, "-hide_banner", "-nostdin", "-i", src, "-af",
                        "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True, errors="replace")
    d = json.loads(re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr)[-1])
    af = ("loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=%s:measured_TP=%s:measured_LRA=%s:"
          "measured_thresh=%s:offset=%s:linear=true" % (d["input_i"], d["input_tp"], d["input_lra"],
                                                        d["input_thresh"], d["target_offset"]))
    run([FFMPEG, "-y", "-v", "error", "-i", src, "-c:v", "copy", "-af", af, "-ar", "48000",
         "-c:a", "aac", "-b:a", "192k", dst])


def pick_track(seconds, avoid):
    """טראק לקליף: הכי פחות משומש, בלי מה שנפסל ובלי מה שכבר שימש בשיעור הזה.
    🚨 טראקים של Scott Buckley שאף פעם לא שימשו הם המשפחה האפלה שהמשתמש העיף ארבעה ממנה
    ביום אחד (14/10, "אין לי עניין במנגינות אימה") — לא נותנים אותם אוטומטית."""
    pool, smart, fb = pick_pool(seconds, avoid)
    if not pool:
        return None
    if smart:
        # 22/10 (כרטיס 13): הוא כבר שמע את כל המנגינות שבסבב — עכשיו הלייקים קובעים: ❤ פי 3, השאר
        # פחות אבל אף פעם לא אפס (הגרלה משוקללת, לא "תמיד האהובה")
        return track_info(random.choices(pool, weights=[pick_weight(fb, t) for t in pool])[0])
    import music_library as ML
    uses = lambda t: len(fb.get("tracks", {}).get(t["uuid"], {}).get("uses", []))
    random.shuffle(pool)
    pool.sort(key=lambda t: (uses(t), -ML.track_score(fb, t["uuid"])))
    return track_info(pool[0])


LIKED_WEIGHT, PLAIN_WEIGHT = 3.0, 1.0


def pick_weight(fb, t):
    import make_short_music as MUS
    return LIKED_WEIGHT if MUS.liked(fb, t["uuid"]) else PLAIN_WEIGHT


def pick_pool(seconds, avoid):
    """(המועמדים, האם בחירה חכמה, המשוב). אותם כללים תמיד: בלי נפסלות/מושבתות, בלי Buckley שלא שימש,
    בלי מה שכבר שימש בשיעור הזה. בחירה חכמה = ההגדרה דולקת וכל המנגינות שבסבב (status active) נשמעו."""
    import music_library as ML
    import make_short_music as MUS
    idx, fb = ML.load_index(), ML.load_feedback()
    uses = lambda t: len(fb.get("tracks", {}).get(t["uuid"], {}).get("uses", []))
    ok = lambda t: t.get("approved") or MUS.liked(fb, t["uuid"])     # ❤ = אישור
    pool = [t for t in ML.downloaded_tracks(idx)
            if ML.track_score(fb, t["uuid"]) > -2 and t["uuid"] not in avoid
            and "_rejected" not in t["path"] and not MUS.disabled(fb, t["uuid"])
            and not ("buckley" in json.dumps(t).lower() and uses(t) == 0 and not ok(t))
            and not (t.get("user_added") and not ok(t))]   # מנגינה שהעלה — רק אחרי "אשר"
    # 🚨 רק טראקים שכבר יצאו אצלו בשורטס ולא נפסלו. "הכי פחות משומש" לבד בחר בבדיקה (19/10) את
    # Canon in D — מאלה שעוד לא שימשו ושנרשם עליהם "לבדוק קודם" (שם בשורת הקרדיט, 70% בס).
    # טראק חדש נכנס לסבב רק אחרי שמישהו שמע אותו בשורט אמיתי — או שהוא אישר אותו בחלון.
    pool = [t for t in pool if uses(t) > 0 or ok(t)] or pool
    pool = [t for t in pool if t.get("seconds", 0) >= seconds] or pool
    smart = False
    if pool and SET.load().get("smart_music", True):
        smart = MUS.smart_ready(MUS.listing())
    return pool, smart, fb


def track_info(t):
    import music_library as ML
    lic = ML.load_json(t["path"] + ".license.json", {})
    return {"path": t["path"], "uuid": t["uuid"], "title": t.get("title", ""), "credit": lic.get("credit_line", "")}


def track_by_uuid(uuid):
    import music_library as ML
    for t in ML.downloaded_tracks(ML.load_index()):
        if t["uuid"] == uuid:
            return track_info(t)
    raise ValueError("המנגינה לא נמצאה בספרייה")


def add_music(plain, out, track, clip_db=0):
    """מערבב מוזיקה ל-plain → out ומוודא שהיא נשמעת. clip_db = עוצמת המוזיקה בקליף הזה (c["music_db"])."""
    run([PY, HERE / "mix_music.py", plain, track["path"], out, *SET.music_levels(clip_db=clip_db)])
    lvl = music_audible(plain, out)
    if lvl < -40:
        raise RuntimeError("המוזיקה לא נשמעת (%.1f dB) — לא מייצא" % lvl)


def credit_into(desc, credit):
    """שורת הקרדיט בתיאור: מחליפה קיימת או מוסיפה. 🚨 CC BY — קרדיט חובה."""
    desc = re.sub(r"\n*מוזיקה: [^\n]*", "", desc or "").rstrip()
    return desc + ("\n\nמוזיקה: " + credit if credit else "")


DATA_DIR = Path(os.environ.get("SHORTS_DATA_DIR") or os.path.expanduser("~/.local/share/yeshiva-shorts"))


def net_ok(timeout=2.5):
    """יש אינטרנט? חיבור קצר ליוטיוב (זול — בלי הורדה). MAKE_SHORT_OFFLINE=1 = מדמים ניתוק (לבדיקות)."""
    if os.environ.get("MAKE_SHORT_OFFLINE") == "1":
        return False
    if os.environ.get("MAKE_SHORT_OFFLINE_FILE") and os.path.exists(os.environ["MAKE_SHORT_OFFLINE_FILE"]):
        return False                               # בדיקות: ניתוק וחזרה בלי להפעיל מחדש (קובץ קיים = אין רשת)
    import socket
    for host in ("www.youtube.com", "www.google.com"):
        try:
            socket.create_connection((host, 443), timeout).close()
            return True
        except OSError:
            continue
    return False


# 22/10/2026 (כרטיס 13, בקשתו): הגיבוי לדרייב כבר לא חלק משמירה או ויתור — שיעור לא מחכה לו.
# שמירה/ויתור רק רושמים "יש שינוי" בקובץ הזה; עובד רקע בחלון (make_short_app.drive_watch) מגבה את
# כל תיקיית השורטס דקה-שתיים אחרי השינוי האחרון, בפתיחה אם נשאר משהו, וכשהאינטרנט חוזר.
# במצב בדיקה — קובץ נפרד, ו"דרייב" = תיקייה מקומית (MAKE_SHORT_TEST_DRIVE_DST); בלעדיה אין גיבוי בכלל.
DRIVE_PENDING = DATA_DIR / ("drive_pending_test.json" if TEST_MODE else "drive_pending.json")
DRIVE_STATUS = DATA_DIR / ("drive_status_test.json" if TEST_MODE else "drive_status.json")


def drive_pending():
    try:
        return json.load(open(DRIVE_PENDING, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_json_atomic(path, d):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    os.replace(tmp, path)


def mark_drive_pending(why, allow_delete=0):
    """עוד שינוי בתיקיית השורטס שעוד לא בדרייב. rev עולה בכל שינוי — גיבוי שרץ בזמן שנשמר עוד
    שיעור לא מוחק את הסימון של השיעור החדש (run_drive_backup משווה).
    allow_delete (כרטיס 17, "🧹 נקה"): מספר הקבצים המדויק שהוצאנו בכוונה — הגיבוי מקבל --allow-delete
    בדיוק בגודל הזה (מעל ברירת המחדל 10), כך שניקוי גדול לא נתקע, ומחיקה לא צפויה עדיין עוצרת."""
    if not SET.load()["drive_on"]:
        return
    d = drive_pending()
    d["n"] = int(d.get("n", 0)) + 1
    d["rev"] = int(d.get("rev", 0)) + 1
    if allow_delete:
        d["allow_delete"] = int(d.get("allow_delete", 0)) + int(allow_delete)
    d.setdefault("since", time.strftime("%Y-%m-%d %H:%M"))
    d["last_change"] = time.time()
    d["why"] = why
    _write_json_atomic(DRIVE_PENDING, d)


def drive_status():
    try:
        return json.load(open(DRIVE_STATUS, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def drive_cmd():
    """הפקודה של הגיבוי. במצב בדיקה: אותו drive_backup.sh מול תיקיית בדיקה מקומית (לא הדרייב שלו)."""
    env = dict(os.environ)
    if TEST_MODE:
        dst = os.environ.get("MAKE_SHORT_TEST_DRIVE_DST")
        src = os.environ.get("MAKE_SHORT_TEST_EXPORT")
        if not dst or not src:
            return None, env
        env.update(DRIVE_SRC=src, DRIVE_DST=dst)
    return ["bash", str(SH / "drive_backup.sh")], env


def drive_limit(env=None):
    """מגבלת הזמן של drive_backup.sh לסנכרון (אותה נוסחה שם — לשנות יחד): שעה + גודל התיקייה ב-0.3MB/s.
    נמדד 29/10: התיקייה 2.7GB, הגיבוי האיטי ביותר ביומן ~1.8 שעות (161 קבצים)."""
    e = env or os.environ        # 3.4: כמו drive_backup.sh — DRIVE_SRC → SHORTS_EXPORT_DIR → ~/Videos/Shorts
    src = Path(os.path.expanduser(e.get("DRIVE_SRC") or e.get("SHORTS_EXPORT_DIR") or "~/Videos/Shorts"))
    size = 0
    for root, _, files in os.walk(src):
        for f in files:
            try:
                size += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return 3600 + size // 300000


def _kill_group(p):
    """הורג את כל קבוצת התהליכים (bash + timeout + rclone), לא רק את bash — אחרת rclone ממשיך להחזיק את הנעילה."""
    import signal
    for sig, wait in ((signal.SIGTERM, 10), (signal.SIGKILL, 5)):
        try:
            os.killpg(p.pid, sig)
        except OSError:
            return
        try:
            p.wait(wait)
            return
        except subprocess.TimeoutExpired:
            pass


def run_drive_backup():
    """מראה של כל תיקיית השורטס לדרייב. (True, "") = הצליח; (None, why) = גיבוי אחר כבר רץ (לא כישלון);
    (False, why) = נכשל — הסימון נשאר, ינסה שוב."""
    cmd, env = drive_cmd()
    if not cmd:
        return False, "מצב בדיקה בלי תיקיית דרייב לבדיקה"
    before = drive_pending()
    allow = int(before.get("allow_delete", 0))
    if allow > 10:                                 # ניקוי מכוון (כרטיס 17) — בדיוק מה שהוצא, לא יותר
        cmd = cmd + ["--allow-delete", str(allow)]
    # 29/10 (סקירה חיצונית): בלי מגבלת זמן, rclone תקוע החזיק את הנעילה לנצח וכל גיבוי אחריו יצא 5.
    # drive_backup.sh מגביל כל קריאה ל-rclone בעצמו; כאן רק גיבוי אחרון — קבוצת תהליכים משלו,
    # והורגים את כולה (bash, timeout, rclone) אם גם זה נתקע. נחשב כישלון → הניסיון החוזר של 5 דקות.
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, errors="replace", env=env,
                         start_new_session=True)
    try:
        out, err = p.communicate(timeout=drive_limit(env) + 2 * 1800 + 600)    # סנכרון + רשימה + בדיקה + מרווח
    except subprocess.TimeoutExpired:
        _kill_group(p)
        out, err = "", "הגיבוי לדרייב נתקע ונעצר — ינסה שוב"
        p.returncode = 124
    r = subprocess.CompletedProcess(cmd, p.returncode, out, err)
    st = drive_status()
    if r.returncode == 5:                          # drive_backup.sh: גיבוי אחר באמצע (flock)
        return None, "גיבוי אחר כבר רץ"
    if r.returncode == 124 and "TIMEOUT" in (r.stderr or ""):
        r.stderr = "הגיבוי לדרייב לקח יותר מדי זמן ונעצר — ינסה שוב (%s)" % r.stderr.strip().splitlines()[-1][:120]
    if r.returncode == 0:
        now = drive_pending()
        if int(now.get("rev", 0)) == int(before.get("rev", 0)):
            try:
                DRIVE_PENDING.unlink()
            except OSError:
                pass
        else:                                       # נשמר עוד משהו בזמן הגיבוי — נשאר בתור לסיבוב הבא
            now["n"] = max(1, int(now.get("n", 0)) - int(before.get("n", 0)))
            left = int(now.get("allow_delete", 0)) - allow     # המחיקות שהגיבוי הזה כבר עשה — לא נספרות שוב
            if left > 0:
                now["allow_delete"] = left
            else:
                now.pop("allow_delete", None)
            _write_json_atomic(DRIVE_PENDING, now)
        st.update(last_ok=time.strftime("%Y-%m-%d %H:%M"), last_ok_ts=time.time(), error="", fail_since="")
        _write_json_atomic(DRIVE_STATUS, st)
        return True, ""
    why = ((r.stderr or r.stdout).strip().splitlines() or [""])[-1][:200] or "נכשל (קוד %d)" % r.returncode
    st.update(error=why, error_at=time.strftime("%Y-%m-%d %H:%M"))
    if not st.get("fail_since"):
        st["fail_since"] = time.strftime("%Y-%m-%d %H:%M")
        st["fail_since_ts"] = time.time()
    _write_json_atomic(DRIVE_STATUS, st)
    return False, why


def music_audible(plain, mixed):
    """🚨 במשך חודש "הגרסה עם המוזיקה" הייתה זהה למקור עד 0.1dB. מודדים את ההפרש."""
    r = subprocess.run([FFMPEG, "-hide_banner", "-nostdin", "-i", plain, "-i", mixed, "-filter_complex",
                        "[0:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a];"
                        "[1:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,volume=-1[b];"
                        "[a][b]amix=inputs=2:normalize=0,volumedetect", "-f", "null", "-"],
                       capture_output=True, text=True, errors="replace")
    m = re.search(r"mean_volume:\s*(-?[\d.]+)", r.stderr)
    return float(m.group(1)) if m else -99.0


DESC_KEYS = ("footer_lines", "org_name", "subscribe_text", "fixed_tags")


def desc_settings(cfg=None):
    """16/11 (3.4): ארבע ההגדרות של 📝 תיאור ותגיות (ברירת מחדל: ריק / כללי — כל ישיבה ממלאת את שלה)."""
    cfg = cfg or SET.load()
    return {k: cfg.get(k, SET.DEFAULTS[k]) for k in DESC_KEYS}


def desc_sig(ds):
    return hashlib.md5(json.dumps([ds[k] for k in DESC_KEYS], ensure_ascii=False).encode()).hexdigest()[:10]


def footer_for(series, ds=None):
    """שורת הסדרה (+ שם הישיבה) ואחריה השורות הקבועות. כל חלק ריק — פשוט לא נכתב."""
    ds = ds or desc_settings()
    org = (ds["org_name"] or "").strip()
    if series:
        # הנוסח של כל השיעורים עד היום: "מתוך סדרת השיעורים בנושא תפילה", "...השיעורים יסודות ועיונים בש"ס"
        line = ("מתוך סדרת ה" + series) if series.startswith("שיעורים") else ("מתוך סדרת השיעורים " + series)
        line = "%s | %s" % (line, org) if org else line
    else:
        line = org
    return "\n".join(p for p in (line, (ds["footer_lines"] or "").strip("\n")) if p)


def clip_dirs(name):
    """תיקיות הטיוטה של קליף ב-shorts/ (clip1, או clip1_<כותרת> אחרי שמירה)."""
    return [d for d in sorted(Path("shorts").glob(name + "*")) if d.is_dir() and re.match(re.escape(name) + r"(_|$)", d.name)]


def park_dirs(dirs, why="old_shorts"):
    """מזיז הצידה לתיקיית העבודה — לא מוחק (ריצה חוזרת, ויתור, החלפה)."""
    if not dirs:
        return None
    park = Path("work/%s_%s" % (why, time.strftime("%Y%m%d_%H%M%S")))
    park.mkdir(parents=True, exist_ok=True)
    for d in dirs:
        shutil.move(str(d), str(park / Path(d).name))
    return park


def finish_key(c, cfg, logos):
    """מה שקובע איך הטיוטה של קליף נראית. אותו מפתח + סרטון שלם = לא בונים שוב (המשך אחרי הפסקה,
    או "צור שוב" אחרי שתוקן רק קליף אחד)."""
    import make_short_progress as PR
    h = hashlib.md5()
    h.update(Path(c["edit"]).read_bytes())
    lay = Path("work/subtitles/%s_layout.json" % c["name"])      # פריסת שורות שקבע — שינוי בה = צריבה מחדש
    if lay.exists():
        h.update(lay.read_bytes())
    emph = Path("work/subtitles/%s_emph.json" % c["name"])     # 🔠 רק כשדולק — כבוי = המפתח של לפני כרטיס 15
    try:
        ed = json.loads(emph.read_text(encoding="utf-8"))
        if ed.get("on"):
            h.update(json.dumps(ed, ensure_ascii=False, sort_keys=True).encode())
    except (OSError, ValueError):
        pass
    h.update(json.dumps([c.get("sub_rgb_user"), cfg.get("sub_color"), cfg.get("custom_colors"), logos,
                         cfg.get("music_on"), cfg.get("music_level"), PR.sig(c["clean"]),
                         *([c["music_db"]] if c.get("music_db") else []),     # ריק = המפתח של לפני 22/10 נשאר
                         # כרטיס 25: עצירת כתוביות מפרופיל הרב משנה את חלוקת השורות — רק אצל מי שיש לו (use_rabbi קבע CAM_RABBI)
                         *(["gap", RB.gap_for(os.environ.get("CAM_RABBI"))] if RB.gap_for(os.environ.get("CAM_RABBI")) else []),
                         # 30/10: שקיפות המרקר משנה את הצריבה רק אצל מי שבמרקר — לכל השאר המפתח נשאר כמו שהיה
                         *([cfg.get("marker_opacity"), cfg.get("marker_text")] if "MARKER" in str(c.get("sub_rgb_user") or c.get("sub_rgb") or cfg.get("sub_color")).upper() else []),
                         # 31/10 (כרטיס 24): צל הריחוף וצבע/שקיפות הקופסה משנים את הצריבה רק אצל מי שבסגנון הזה — לכל השאר המפתח נשאר
                         *(_style_sig(cfg, str(c.get("sub_rgb_user") or c.get("sub_rgb") or cfg.get("sub_color")))),
                         *hook_sig(c, cfg),          # 6/11: הוק — רק כשדולק, אחרת המפתח כמו לפני
                         (c.get("track") or {}).get("uuid") if c.get("track_user") else ""],
                        ensure_ascii=False, default=str).encode())
    return h.hexdigest()[:12]


def _style_sig(cfg, choice):
    """ערכי הגדרות שמשנים את הציור של הסגנון: צל הריחוף (רק כשהוא לא ברירת המחדל), צבע+שקיפות הקופסה."""
    st = SET.parse_choice(choice)[0]
    if st == "float" and SET.float_shadow(cfg) is not None:
        return [list(SET.float_shadow(cfg))]
    if st == "box":
        return [cfg.get("box_color"), cfg.get("box_opacity")]
    return []


def write_meta(st, c, clip_dir, rabbi, series, f, text, track):
    """meta.json + «תיאור להעתקה» של הטיוטה. "names" = הרב והסדרה שנכתבו בו — השמירה כותבת שוב כשהשתנו
    (28/10: טיוטה שנבנתה לבד לפני שמילא שם סדרה)."""
    ds = desc_settings()
    tags = [t.strip() for t in f["תגיות"].split(",") if t.strip()]
    fixed = [t.strip() for t in (ds["fixed_tags"] or "").split(",") if t.strip()]
    for t in (rabbi, (ds["org_name"] or "").strip(), series, *fixed):     # הסדר של תמיד: רב, ישיבה, סדרה, "שיעור תורה"
        if t and t not in tags:
            tags.append(t)
    hook = re.split(r"(?<=[.?!])\s", text, maxsplit=1)[0]
    run([PY, HERE / "write_clip_meta.py", clip_dir, "--title", "%s | %s" % (f["כותרת"], rabbi) if rabbi else f["כותרת"],
         "--hook", hook, "--description", f["תיאור"], "--tags", ",".join(tags),
         "--source-url", st["url"], "--channel-url", st.get("channel_url", ""),
         "--subscribe", ds["subscribe_text"] or "",
         "--footer", footer_for(st.get("series_title") if norm(st.get("series_title", "")) == norm(series)
                                else series, ds)])
    meta_p = Path(clip_dir) / "meta.json"
    meta = json.load(open(meta_p, encoding="utf-8"))
    if track:
        meta["description"] = credit_into(meta["description"], track["credit"])
        meta["music"] = {k: track[k] for k in ("uuid", "title", "credit")}
    meta["names"] = [rabbi, series]
    meta["desc_sig"] = desc_sig(ds)          # 3.4: שמירה מחדש אחרי שינוי ב-📝 כותבת את התיאור שוב
    json.dump(meta, open(meta_p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)


def refresh_meta(st, rabbi, series):
    """בשמירה: קליף שהתיאור שלו נכתב בלי שם הרב/הסדרה (או בשם אחר) — כותבים אותו שוב, עם אותה מנגינה."""
    for c in st["clips"]:
        if c.get("dropped") or not clip_dirs(c["name"]):
            continue
        d = clip_dirs(c["name"])[0]
        try:
            meta = json.load(open(d / "meta.json", encoding="utf-8"))
        except (OSError, ValueError):
            continue
        # 3.4: גם כשההגדרות של 📝 תיאור ותגיות השתנו מאז שהטיוטה נכתבה (בלי desc_sig = טיוטה מלפני 3.4 — נשארת)
        sig_now = desc_sig(desc_settings())
        same_desc = meta.get("desc_sig", sig_now) == sig_now
        if meta.get("names", [rabbi, series]) == [rabbi, series] and same_desc:
            continue                                   # בלי "names" = טיוטה מלפני 28/10, שנבנתה עם השמות
        f, text, _ = parse_edit(c["edit"])
        say("⑨ %s: התיאור נכתב שוב %s" % (c["name"], ("עם %s / %s" % (rabbi, series)) if same_desc else "לפי 📝 תיאור ותגיות"))
        write_meta(st, c, d, rabbi, series, f, text, c.get("track"))


def hook_active(c, cfg):
    """🎬 הוק (6/11): בקליף שהוא בחר במפורש — הבחירה שלו; אחרת ההגדרה הכללית (ברירת מחדל: דולק)."""
    v = c.get("hook_on")
    return bool(cfg.get("hook_on", True)) if v is None else bool(v)


def hook_sig(c, cfg):
    """חלק ממפתח הטיוטה: משתנה רק כשההוק דולק — ובכבוי המפתח נשאר כמו לפני ההוק."""
    if not hook_active(c, cfg):
        return []
    return ["hook", (c.get("hook") or {}).get("text", ""), bool(cfg.get("hook_sfx", True))]


def hook_prep(P, c, cfg, aligned, lay, eidx, report, force=None):
    """🎬 ההוק לצריבה: מחזיר None (בלי הוק) או {"clean","words_json","total","lay","eidx","plan"} — הסרטון הנקי עם ההוק
    וההבזק בהתחלה, והמילים/פריסה/הגדלה על הציר המשולב. הבחירה: מה שנקבע לקליף (c["hook"]) → הצעת המודל (hook_quote) →
    הצעה יוריסטית (אפשר לערוך בחלון). hook_clip.py הוא המנוע המשותף עם הסקיל."""
    on = hook_active(c, cfg) if force is None else force
    if not on:
        c["hook_built"] = False
        return None
    sys.path.insert(0, str(HERE))
    import hook_clip as HC
    hk = c.get("hook") if (c.get("hook") or {}).get("text") else None
    if hk and not HC.resolve(hk, aligned):
        report.append("%s: 🎬 ההוק שנבחר כבר לא נמצא בטקסט (הטקסט תוקן?) — בוחר מחדש" % c["name"])
        hk = None
    if not hk:
        sp = HC.find_span(aligned, c["hook_quote"]) if c.get("hook_quote") else None
        if sp:
            hk = {"i0": sp[0], "i1": sp[1], "src": "gemini",
                  "text": " ".join(w["word"].strip() for w in aligned[sp[0]:sp[1] + 1])}
        else:
            hk = HC.suggest(aligned)
    if not hk:
        report.append("%s: 🎬 לא נמצא הוק מתאים — השורט בלי הוק (אפשר לבחור ידנית בחלון)" % c["name"])
        c["hook_built"] = False
        return None
    r = HC.prepare(c["clean"], aligned, hk, "work/hook", tag=c["name"], sfx=bool(cfg.get("hook_sfx", True)))
    if not r:
        report.append("%s: 🎬 ההוק לא נבנה — השורט בלי הוק" % c["name"])
        c["hook_built"] = False
        return None
    pl = r["plan"]
    c["hook"] = dict(hk, i0=pl["i0"], i1=pl["i1"], text=pl["text"])
    c["hook_built"] = True
    c["hook_extra"] = round(pl["Tc"], 2)
    report.append("%s: 🎬 הוק %.1f שניות: «%s»" % (c["name"], pl["Th"], pl["text"]))
    return {"clean": r["clean"], "words_json": r["words_json"], "total": r["total"], "plan": pl,
            "lay": HC.shift_layout(lay, r["K"], r["comb"]), "eidx": HC.shift_idx(eidx, r["K"])}


def finish(project, only=None):
    """הטיוטה: כתוביות, צריבה, קול, מוזיקה ותיאור — בתיקיית העבודה בלבד (21/10/2026: הוא רוצה לראות
    ולשנות לפני שמשהו נכנס לתיקיית השורטס; "💾 שמור לתיקייה" = save). קליף שהטיוטה שלו כבר מעודכנת
    ושלמה — מדלגים עליו (המשך אחרי הפסקה, או תיקון של קליף אחד בלבד).
    only = רק הקליפים האלה ("✓ סיים את הקליף הזה", כרטיס 12: הכפתור בתת-לשונית של קליף 1 התחיל את כל
    השלושה לפני שבדק את 2 ו-3). השאר לא נוגעים; השיעור "גמור" רק כשלכל הקליפים יש טיוטה."""
    import make_short_progress as PR
    P = Path(project)
    os.chdir(P)
    st = load_st()
    use_rabbi(st.get("rabbi"))                       # כרטיס 25: עצירת כתוביות לפי פרופיל הרב
    rabbi, series = existing_folder(st["rabbi"], st["series"])
    # 28/10: טיוטה נבנית גם בלי שם רב/סדרה (כותרת "נושא | הרב X" — אין בה סדרה). התיאור נכתב שוב בשמירה,
    # אחרי שימלא אותם (save_lesson → refresh_meta); השמירה עצמה בלעדיהם — נעצרת עם הסבר.
    if not rabbi or not series:
        say("⚠️ חסר שם %s — הטיוטה נבנית; לפני השמירה לתיקייה צריך למלא אותו" % ("רב" if not rabbi else "סדרה"))
    PR.job_begin(P, "finish", ["finish", P] + (["--clips=" + ",".join(only)] if only else []))
    sys.path.insert(0, str(HERE))
    import align_clean_text as ACT
    import build_clean_video as BCV
    import check_subs as CS
    import karaoke_ass as KA
    import make_short_layout as LAY
    cfg = SET.load()
    Path("shorts").mkdir(exist_ok=True)
    for d in ("work/burn", "work/plain"):
        Path(d).mkdir(parents=True, exist_ok=True)
    logos = SET.logos(cfg)          # שמאל ו/או ימין, כל אחד עם ההילה שלו (21/10)
    gcolor, grgb = SET.sub_color(cfg)
    every = [c for c in st["clips"] if not c.get("dropped")]
    live = [c for c in every if not only or c["name"] in only]
    if not live:
        raise ValueError("אין קליף כזה לסיים")
    PR.plan(P, [["fin:%s" % c["name"], "%s: כתוביות, צריבה, קול ומוזיקה (%d/%d)" % (
        c["name"].replace("clip", "קליף "), i + 1, len(live)), int(25 + 1.6 * c.get("seconds", 30))]
                for i, c in enumerate(live)])
    fin = PR.data(P).get("finish") or {}
    # מנגינות שכבר שייכות לקליפים אחרים בשיעור — גם כשמסיימים רק קליף אחד, לא אותה מנגינה פעמיים
    done, used_tracks, report = [], {(c.get("track") or {}).get("uuid") for c in every} - {None}, []
    for c in live:
        n = c["name"]
        key = finish_key(c, cfg, logos)
        PR.step(P, "fin:" + n, "run")
        vids = [v for d in clip_dirs(n) for v in d.glob("*.mp4")]
        if fin.get(n) == key and vids and PR.media_ok(vids[0], (c.get("seconds") or 0) + (c.get("hook_extra") or 0 if c.get("hook_built") else 0) or None, tol=3):
            say("⑥ %s: הטיוטה כבר מעודכנת ✓" % n)
            PR.step(P, "fin:" + n, "skip", "כבר מוכן")
            done.append(n)
            continue
        try:
            f, text, left = parse_edit(c["edit"])
            if not f["כותרת"] or not f["תיאור"]:
                raise ValueError("חסרים כותרת או תיאור בקובץ העריכה")
            if left:
                report.append("%s: %d ספקות נשארו בסוגריים — נלקחה האוזן הראשונה: %s"
                              % (n, len(left), " · ".join(left[:5])))
            say("⑥ %s: מיישר כתוביות" % n)
            asr_words = json.load(open(c["ear1"], encoding="utf-8"))["words"]
            aligned = ACT.align(asr_words, text)
            ratio, worst, _ = CS.analyze(asr_words, aligned)
            # 🚨 שער הכיסוי (5ה): טקסט מקוצר "נמתח" על כל הקליף בלי שגיאה — וכתוביות נעלמות
            if ratio < 0.90 or worst > 3.0:
                raise ValueError("הטקסט לא מכסה את כל מה שנאמר (כיסוי %.0f%%, רווח של %.1f שניות בלי כתובית). "
                                 "כנראה נמחק משפט — להחזיר אותו לקובץ העריכה" % (ratio * 100, worst))
            words_json = "work/subtitles/%s_words.json" % n
            json.dump({"words": aligned}, open(words_json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            Path("work/subtitles/%s_final.txt" % n).write_text(text, encoding="utf-8")
            ass = "work/subtitles/%s.ass" % n
            # הצבע: מה שבחר לקליף הזה (הגדרות מהירות), אחרת ההגדרה הכללית. "אקראי" — אותו צבע
            # שהקליף כבר קיבל, כדי שתיקון טקסט לא יחליף לו צבע
            urgb = c.get("sub_rgb_user") or (c.get("sub_rgb") if cfg.get("sub_color") == "random" else None)
            # "📐 פריסת שורות" שקבע לקליף — ממופה למילים של עכשיו (נשמרת איפה שהמילים לא השתנו)
            lay, has_lay, lost = LAY.chunks_for(P, n, aligned)
            if lost:
                report.append("%s: %d כתוביות מהפריסה שקבעת השתנו בטקסט — שם חזרה החלוקה האוטומטית" % (n, lost))
            choice = urgb or clip_choice(cfg, ass, report, n)
            eidx = emph_for_burn(P, c, aligned, report, choice)        # 🔠 None = מתג כבוי → צריבה כמו תמיד
            with heavy(n):
                hk = hook_prep(P, c, cfg, aligned, lay, eidx, report) if hook_active(c, cfg) else None
            if hk:
                say("⑥ %s: 🎬 הוק: «%s»" % (n, hk["plan"]["text"]))
            build_subs(hk["words_json"] if hk else words_json, ass, hk["total"] if hk else duration(c["clean"]), choice,
                       hk["lay"] if hk else lay, hk["eidx"] if hk else eidx)
            if hk:
                import hook_clip as HC
                HC.trim_ass(ass, hk["plan"]["Tc"])
            c["sub_rgb"] = clip_rgb(n)

            say("⑦ %s: צורב כתוביות%s, מנרמל קול" % (n, " ולוגו" if logos else ""))
            burn = "work/burn/%s.mp4" % n
            with heavy(n):
                BCV.burn_subtitles(hk["clean"] if hk else c["clean"], ass, burn, os.path.join(LIB, "fonts"), logos=logos)
            plain = "work/plain/%s.mp4" % n          # הבסיס בלי מוזיקה — נשאר כאן להחלפת טראק
            loudnorm(burn, "work/plain/%s.part.mp4" % n)
            os.replace("work/plain/%s.part.mp4" % n, plain)

            park_dirs(clip_dirs(n))                   # הטיוטה הקודמת של הקליף הזה — הצידה, לא נמחקת
            clip_dir = Path("shorts") / n
            clip_dir.mkdir(parents=True, exist_ok=True)
            out = str(clip_dir / "video.mp4")
            tmp_out = str(clip_dir / "video.part.mp4")
            track = None
            if cfg["music_on"]:
                say("⑧ %s: מוזיקת רקע" % n)
                # מנגינה שכבר נבחרה לקליף (בסיבוב קודם או בהגדרות המהירות) נשארת
                old = (c.get("track") or {}).get("uuid")
                try:
                    track = track_by_uuid(old) if old else None
                except ValueError:
                    track = None
                if not track:
                    track = pick_track(c["seconds"], used_tracks)
                if not track and used_tracks:            # כל הפעילות כבר בשיעור הזה — עדיף חזרה מבלי מוזיקה
                    track = pick_track(c["seconds"], set())
                if track:
                    add_music(plain, tmp_out, track, c.get("music_db", 0))
                    used_tracks.add(track["uuid"])
                    if not TEST_MODE and track["uuid"] != old:   # בדיקה לא נספרת כשימוש — אחרת הטראק "מאושר"
                        run([PY, HERE / "music_library.py", "used", track["uuid"], "--clip", str(clip_dir),
                             "--project", str(P)], check=False)
                else:
                    # 22/10 (כרטיס 14, בקרת סתירות): כל המנגינות מושבתות / הספרייה ריקה — היה "נכשל" בלי מוצא.
                    # עכשיו הקליף נבנה בלי מוזיקה, ואומרים בבירור (הכלל שלו: תמיד עם מוזיקה — הוא יחליט)
                    shutil.copyfile(plain, tmp_out)
                    report.append("⚠️ %s: אין אף מנגינה פעילה בספרייה (כולן מושבתות?) — נבנה בלי מוזיקה. "
                                  "מפעילים מנגינה בהגדרות ← מוזיקה, ואז 🔀 בקליף" % n)
            else:
                shutil.copyfile(plain, tmp_out)
            c["track"] = {k: track[k] for k in ("uuid", "title", "credit")} if track else None

            say("⑨ %s: תיאור ותגיות" % n)
            write_meta(st, c, clip_dir, rabbi, series, f, text, track)
            os.replace(tmp_out, out)                   # הסרטון אחרון — קיים = הקליף שלם
            fin[n] = finish_key(c, cfg, logos)
            PR.put(P, "finish", fin)
            # הקליף נשמר במצב (מנגינה, צבע) מיד — הפסקה באמצע הקליף הבא לא מאבדת אותו
            save_st(dict(load_st(), clips=[c if x["name"] == n else x for x in load_st()["clips"]]))
            PR.step(P, "fin:" + n, "done")
            done.append(n)
            report.append("%s: «%s» · %.0f שניות · מוזיקה: %s"
                          % (n, f["כותרת"], c["seconds"], track["title"] if track else ("בלי (כבויה בהגדרות)" if not cfg["music_on"] else "בלי — אין מנגינה פעילה")))
        except Exception as ex:
            PR.step(P, "fin:" + n, "fail", str(ex)[:300])
            report.append("❌ %s לא הופק: %s" % (n, ex))

    st = load_st()
    whole = all(any(d.glob("*.mp4") for d in clip_dirs(c["name"])) for c in st["clips"] if not c.get("dropped"))
    if not only or whole:                       # קליף אחד מוכן והשאר עוד בתיקון — השיעור עוד לא "גמור"
        st["finished"] = time.strftime("%Y-%m-%d %H:%M")
        st["draft_at"] = st["finished"]
    save_st(st)
    say("\n" + "\n".join(report))
    say("DONE=%d/%d" % (len(done), len(live)))
    if done:
        say("   הטיוטה מוכנה — רואים, משנים אם צריך, ואז \"💾 שמור לתיקייה\".")
        say("STAGE=done")
    if len(done) < len(live):
        bad = [r for r in report if r.startswith("❌")]
        raise RuntimeError(bad[0][2:] if bad else "לא כל הקליפים הופקו")
    return 0


# ─────────────── שמירה לתיקיית השורטס (21/10/2026) ───────────────

def export_root():
    if TEST_MODE:            # בדיקה: רק לתיקיית בדיקה מפורשת, אף פעם לא לתיקיית השורטס האמיתית
        return Path(os.environ["MAKE_SHORT_TEST_EXPORT"]) if os.environ.get("MAKE_SHORT_TEST_EXPORT") else None
    return Path(os.environ.get("SHORTS_EXPORT_DIR") or os.path.expanduser("~/Videos/Shorts"))


def snapshot(P, st):
    """מה שנשמר: לכל קליף חי — חתימת הסרטון של הטיוטה + התיאור. שונה מהשמירה האחרונה = "יש שינויים שלא נשמרו"."""
    import make_short_progress as PR
    out = {}
    for c in st.get("clips", []):
        if c.get("dropped"):
            continue
        ds = [d for d in sorted((Path(P) / "shorts").glob(c["name"] + "*"))
              if d.is_dir() and re.match(re.escape(c["name"]) + r"(_|$)", d.name)]
        vids = sorted(ds[0].glob("*.mp4")) if ds else []
        try:
            desc = json.load(open(ds[0] / "meta.json", encoding="utf-8")).get("description", "") if ds else ""
        except (OSError, ValueError):
            desc = ""
        out[c["name"]] = [PR.sig(vids[0]) if vids else "", hashlib.md5(desc.encode()).hexdigest()[:10]]
    return out


def unsaved(P, st):
    """None = עוד לא נשמר אף פעם; False = הכול שמור; True = השתנה משהו מאז השמירה."""
    if not st.get("saved"):
        return None
    return snapshot(P, st) != st["saved"].get("snap")


def unsaved_clips(P, st):
    """28/10: הקליפים שהטיוטה שלהם שונה ממה שנשמר (או שעוד לא נשמרו) — ל"💾 שמור את הקליף הזה"."""
    snap, old = snapshot(P, st), (st.get("saved") or {}).get("snap") or {}
    return [n for n, v in snap.items() if v[0] and old.get(n) != v]


def save_lesson(project, only=None):
    """"💾 שמור לתיקייה": הטיוטה → תיקיית השורטס (רק סרטונים ו«תיאור להעתקה.txt»). הגיבוי לדרייב — לא כאן:
    רק מסמנים "ממתין", והעובד ברקע מגבה את כל התיקייה (22/10, בקשתו: שמירה נגמרת מיד).
    🚨 שיעור אחד = תיקייה אחת: שמירה חוזרת מחליפה את הקבצים באותה תיקייה, לא פותחת "_1714" חדשה.
    קבצים ישנים שם (כותרת שהשתנתה, קליף שוויתרו עליו) עוברים לתיקיית העבודה, לא נמחקים."""
    import make_short_progress as PR
    P = Path(project)
    os.chdir(P)
    st = load_st()
    PR.job_begin(P, "save", ["save", P] + (["--clips=" + ",".join(only)] if only else []))
    PR.plan(P, [["export", "העתקה לתיקיית השורטס", 10]])
    rabbi, series = existing_folder(st["rabbi"], st["series"])
    if not rabbi or not series:
        raise ValueError("חסר שם %s — כתבו אותו בשדה \"%s\" ואז שמרו שוב"
                         % (("הרב", "שם הרב") if not rabbi else ("הסדרה", "סדרה")))
    refresh_meta(st, rabbi, series)
    every = [c["name"] for c in st["clips"] if not c.get("dropped")]
    # 28/10: only = "💾 שמור את הקליף הזה" (או "שמור את כולם" בזמן שקליף אחר עוד מתעדכן — בלעדיו)
    live = [n for n in every if not only or n in only]
    missing = [n for n in live if not clip_dirs(n) or not list(clip_dirs(n)[0].glob("*.mp4"))]
    if missing:
        raise ValueError("ל-%s עוד אין טיוטה — קודם \"צור את השורטס\"" % ", ".join(missing))
    root = export_root()
    report = []
    PR.step(P, "export", "run")
    if root is None:
        report.append("(מצב בדיקה בלי MAKE_SHORT_TEST_EXPORT: לא נשמר לשום תיקייה)")
        PR.step(P, "export", "skip", "מצב בדיקה")
    else:
        target = Path(st.get("export_target") or "")
        inside = target.is_dir() and root.resolve() in target.resolve().parents
        if inside and not st.get("export_dirs") and (target / "shorts").is_dir():
            # שיעור שנשמר במבנה הישן (תיקייה לשיעור) ועוד לא סודר — נשאר שם עד reorganize_exports --apply
            # (באישורו בלבד, כרטיס 16). אחרת שמירה חוזרת הייתה משאירה עותק ישן ועותק חדש.
            say("⑩ שומר ל-%s (מבנה ישן — השיעור עוד לא סודר)" % target)
            out = run([PY, HERE / "export_clips.py", "--project", P, "--into", target])
            m = re.search(r"✓ יוצא ואומת: (.+)", out)
            st = load_st()
            st["export_target"] = m.group(1).strip() if m else str(target)
        else:
            # כרטיס 16 (22/10): <הרב>/<הסדרה>/<כותרת השורט>/ — תיקייה לכל שורט, בשם הכותרת
            series_dir = root / rabbi / series
            known = Path("work/export_known.json")
            known.parent.mkdir(parents=True, exist_ok=True)
            known.write_text(json.dumps(st.get("export_dirs") or {}, ensure_ascii=False), encoding="utf-8")
            say("⑩ שומר ל-%s" % series_dir)
            out = run([PY, HERE / "export_clips.py", "--project", P, "--to", series_dir, "--known", known]
                      + (["--only", ",".join(live)] if only else []))
            m = re.search(r"^EXPORT_DIRS=(.+)$", out, re.M)
            if not m:
                raise RuntimeError("הייצוא לא החזיר את התיקיות")
            dirs = json.loads(m.group(1))
            st = load_st()
            old = dict(st.get("export_dirs") or {})
            old.update(dirs)
            st["export_dirs"] = old
            st["export_target"] = str(series_dir)
            st["export_layout"] = "short"
            for d in {str(Path(x).parent) for x in old.values()} - {str(series_dir)}:
                SL.prune_empty(d, root)               # שינה רב/סדרה — הישנות שהתרוקנו יורדות
        for line in out.splitlines():
            if line.strip().startswith("↪"):
                report.append(line.strip())
        PR.step(P, "export", "done", win_path(st["export_target"]))
    snap = snapshot(P, st)
    if only:                                       # רק הקליפים שנשמרו עכשיו מתעדכנים; השאר — כמו בשמירה הקודמת
        old = dict((st.get("saved") or {}).get("snap") or {})
        old.update({n: snap[n] for n in live if n in snap})
        snap = {n: old[n] for n in every if n in old}
        clips = [n for n in every if n in set((st.get("saved") or {}).get("clips") or []) | set(live)]
    else:
        clips = live
    st["saved"] = {"at": time.strftime("%Y-%m-%d %H:%M"), "snap": snap, "clips": clips}
    try:                                           # 28/10: מד האיכות + המילון האישי לומד ממה שתיקן
        import make_short_editor as ED
        q = ED.on_saved(P, st, live)
        for c in st["clips"]:
            if c["name"] in q:
                c["quality"] = q[c["name"]]
    except Exception as e:
        say("(מד האיכות לא נרשם: %s)" % e)
    save_st(st)
    if root is not None:
        mark_drive_pending("נשמר: %s" % st.get("video_title", P.name))   # הגיבוי — ברקע, לא כאן (כרטיס 13)
    try:                                           # המנגינות של שורט ששמר — "נשמעו" (לבחירה החכמה, כרטיס 13)
        import make_short_music as MUS
        MUS.mark_heard_many([(c.get("track") or {}).get("uuid") for c in st["clips"] if not c.get("dropped")])
    except Exception as e:
        say("(לא נרשם \"נשמע\" למנגינות: %s)" % e)
    say("\n" + "\n".join(report + ["✅ נשמר: %d שורטס%s" % (len(live), (" ב-" + win_path(st["export_target"]))
                                                           if st.get("export_target") else "")]))
    say("SAVED=%s" % st.get("export_target", ""))
    say("STAGE=done")
    return 0


# ─────────────── אחרי הסיום: בנייה חלקה, החלפת מוזיקה ───────────────

def clip_of(st, name):
    for c in st["clips"]:
        if c["name"] == name:
            return c
    raise ValueError("אין קליף בשם %s" % name)


def rebuild(project, name, camera="smooth"):
    """בנייה מחדש של קליף אחד (לפני הצריבה) במצלמה "חלקה" (CAM_SMOOTH=7) — לרב שמתנדנד מצד לצד —
    או "זריזה" (CAM_ZIPPY=1, כרטיס 22) — לרב שיוצא מהקרופ.
    אותם גבולות בדיוק, ולכן הקול והתמלול לא משתנים: קובץ העריכה נשאר כמו שהוא."""
    if camera not in CAMERAS:
        raise ValueError("מצלמה לא מוכרת: %s" % camera)
    P = Path(project)
    os.chdir(P)
    st = load_st()
    use_rabbi(st.get("rabbi"))                       # כרטיס 25: המצלמה של הרב הזה (אם יש לו פרופיל)
    c = clip_of(st, name)
    say("④ %s: בונה מחדש במצלמה %s" % (name, CAMERAS[camera]))
    import camera_path as CP
    env = CP.cam_env(os.environ, camera)
    with heavy(name):
        r = subprocess.run([PY, str(HERE / "multi_piece_clip.py"), name, *["%.3f,%.3f" % tuple(ab) for ab in c["cuts"]]],
                           cwd=P, env=env, capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("הבנייה נכשלה:\n" + "\n".join((r.stderr or r.stdout).strip().splitlines()[-8:]))
    c["camera"] = camera
    c["framing"] = check_framing(c["clean"], camera)
    st = dict(load_st(), clips=[c if x["name"] == name else x for x in load_st()["clips"]])
    save_st(st)
    say("   %s" % c["framing"]["text"])
    if st.get("finished"):
        say("   ⚠️ השורטס כבר נוצרו מהבנייה הקודמת — כדי שייכנס, ללחוץ שוב על \"צור את השורטס\"")
    say("STAGE=ready_edit")
    say("✅ נבנה מחדש")
    return 0


def final_video(name):
    dirs = [d for d in sorted(Path("shorts").glob(name + "*")) if d.is_dir() and re.match(name + r"(_|$)", d.name)]
    if not dirs:
        raise ValueError("ל-%s עוד אין שורט מוכן — קודם \"צור את השורטס\"" % name)
    vids = sorted(dirs[0].glob("*.mp4"))
    if not vids:
        raise ValueError("לא נמצא הסרטון של %s" % name)
    return dirs[0], vids[0]


SWAP_MODES = ("swap", "back", "off", "on")
CAMERAS = {"default": "רגילה", "smooth": "חלקה", "zippy": "זריזה"}     # זריזה: כרטיס 22, 28/10
PREVIEW_MUSIC_SEC = 15
PREVIEW_CAM_SEC = 10


def resolve_music(c, mode, want=""):
    """(track או None, cur, old) לפי הפעולה — אותו חישוב לתצוגה המקדימה ולהחלה, כדי שמה שנשמע
    בתצוגה הוא מה שייכנס (swap בלי uuid = "הבאה בסבב", שהיא אקראית — מכריעים פעם אחת)."""
    if mode not in SWAP_MODES:
        raise ValueError("פעולה לא מוכרת: %s" % mode)
    cur = c.get("track")
    old = (cur or {}).get("uuid", "")
    hist = c.get("music_history") or []
    if mode == "off" and not cur:
        raise ValueError("המוזיקה כבר כבויה בקליף הזה")
    if mode == "back" and not hist:
        raise ValueError("אין מנגינה קודמת לחזור אליה")
    if mode in ("back", "on") and hist and not want:
        want = hist[-1]["uuid"]
    if mode == "off":
        return None, cur, old
    track = track_by_uuid(want) if want else pick_track(c["seconds"], {old} if old else set())
    if not track:
        raise RuntimeError("אין מנגינה אחרת מתאימה בספרייה")
    return track, cur, old


def style_of(choice):
    """28/10: הבחירה (RRGGBB או אסימון כמו PLAIN) → שם הסגנון ב-karaoke_ass.SUB_STYLES."""
    st = SET.parse_choice(choice)[0]               # karaoke / plain / marker / float
    return st if st in ("plain", "marker", "float", "box") else "karaoke"


def em_rgb_for(ass_path):
    """"ללא צבע": הצבע של המילים המסומנות — אחד מצבעי האקראי, קבוע לקליף (לפי נתיב ה-ass, כמו "אקראי")."""
    pool = SET.em_pool()
    return pool[int(hashlib.md5(os.path.abspath(str(ass_path)).encode("utf-8")).hexdigest(), 16) % len(pool)]


def clip_choice(cfg, ass, report=None, n=""):
    """הבחירה לקליף חדש לפי ההגדרה: צבע קבוע / צבע משלו / ללא צבע — או "אקראי": אחד מהמותרים (גם "ללא צבע"),
    קבוע לפי נתיב ה-ass (צריבה חוזרת של אותו קליף → אותה בחירה)."""
    gcolor, grgb = SET.sub_color(cfg)
    if gcolor != "random":
        return (grgb or SET.DEFAULT_COLORS.get(gcolor) or "1AC8A8").upper()
    rpool, rfb = SET.random_pool(cfg)
    if rfb and report is not None:
        report.append("%s: כל הצבעים/הסגנונות הושבתו מ\"אקראי\" — נלקח טורקיז" % n)
    if rfb:
        return rpool[0]
    h = int(hashlib.md5(os.path.abspath(str(ass)).encode("utf-8")).hexdigest(), 16)
    groups = SET.random_groups(cfg)
    pick = SET.random_pick(h, groups)
    # 30/10: ריחוף רק לדיבור איטי — קליף מהיר מדי לא מקבל אותו באקראי (ביד אפשר, עם אזהרה)
    if SET.parse_choice(pick)[0] == "float" and len(groups) > 1:
        wj = Path(str(ass)[:-4] + "_words.json")
        if clip_rate(wj.parent.parent.parent, wj.name[:-11]) > __import__("karaoke_styles").FLOAT_MAX_WPS:
            groups.pop("float")
            pick = SET.random_pick(h, groups)
    return pick


def build_subs(words_json, ass, dur, choice, lay, eidx):
    """הכתוביות של קליף בבחירה אחת: צבע (RRGGBB) בקריוקי, או סגנון אחר (PLAIN = ללא צבע). המקום היחיד שמחליט —
    הסיום, השינוי המהיר והבדיקה העצמית עוברים כאן, כך שאין דרך שקליף ייצא בשני צבעים."""
    sys.path.insert(0, str(HERE))
    import karaoke_ass as KA
    mode = style_of(choice)
    if mode in ("marker", "float", "box"):         # 30/10: karaoke_styles.py — הצבע (אם יש) בתוך הבחירה, השקיפות מההגדרות
        cfg = SET.load()
        rgb = SET.parse_choice(choice)[1]
        KA.build(words_json, ass, dur, "teal", rows_layout=lay, emph_idx=eidx, mode=mode, rgb=rgb,
                 opacity=cfg.get("box_opacity") if mode == "box" else cfg.get("marker_opacity"),
                 text=(cfg.get("marker_text") or {}).get(rgb), shadow=SET.float_shadow(cfg) if mode == "float" else None,
                 box_rgb=cfg.get("box_color") if mode == "box" else None)
        return
    rgb = em_rgb_for(ass) if mode != "karaoke" else choice.upper()
    KA.HIGHLIGHT_RGB["custom"] = rgb
    KA.build(words_json, ass, dur, "teal", color="custom", rows_layout=lay, emph_idx=eidx, mode=mode)


def clip_rgb(name, base="."):
    """הצבע שבו הקליף נצרב — מתוך קובץ ה-ass שלו (סגנון Hi), כי "אקראי" נבחר לפי הנתיב
    וההגדרה יכולה להשתנות אחרי היצירה. None אם אין. 28/10: קליף בסגנון אחר → האסימון שלו (PLAIN)."""
    try:
        txt = (Path(base) / ("work/subtitles/%s.ass" % name)).read_text(encoding="utf-8-sig")
        m = re.search(r"^; ys-style: (\w+)", txt, re.M)
        if m and m.group(1) in ("marker", "float", "box"):        # 30/10: הצבע נשמר בשורת ; ys-rgb (ריחוף בלי הדגשה = "-")
            r = re.search(r"^; ys-rgb: ([0-9A-Fa-f]{6})", txt, re.M)
            return m.group(1).upper() + (":" + r.group(1).upper() if r else "")
        if m and m.group(1) != "karaoke":
            return SET.STYLE_TOKENS.get(m.group(1), m.group(1).upper())
        m = re.search(r"^Style: Hi,[^,]*,\d+,&H00([0-9A-Fa-f]{6})", txt, re.M)
        if m:
            b = m.group(1).upper()
            return b[4:6] + b[2:4] + b[0:2]
    except OSError:
        pass
    return None


def clip_rate(P, name):
    """מילים בשנייה בקליף (מהמילים המיושרות שלו); 0 = עוד לא נבנה. מזהיר את מי שבחר "ריחוף מילים" (לדיבור איטי)."""
    import karaoke_styles as KS
    try:
        w = json.load(open(Path(P) / ("work/subtitles/%s_words.json" % name), encoding="utf-8"))
        return KS.speech_rate(w["words"] if isinstance(w, dict) else w)
    except (OSError, ValueError, KeyError):
        return 0.0


def clip_em(P, name):
    """"ללא צבע": הצבע של המילים המסומנות בקליף — מה שנצרב (סגנון Hi), ואם עוד לא נצרב כך — מה שייצרב."""
    ass = Path(P) / ("work/subtitles/%s.ass" % name)
    try:
        txt = ass.read_text(encoding="utf-8-sig")
        m = re.search(r"^; ys-style: float\s*\n; ys-rgb: ([0-9A-Fa-f]{6})", txt, re.M)
        if m:                                                  # ריחוף עם הדגשה: המילים המסומנות בצבע שבחר
            return m.group(1).upper()
        if re.search(r"^; ys-style: plain", txt, re.M):
            m = re.search(r"^Style: Hi,[^,]*,\d+,&H00([0-9A-Fa-f]{6})", txt, re.M)
            if m:
                b = m.group(1).upper()
                return b[4:6] + b[2:4] + b[0:2]
    except OSError:
        pass
    return em_rgb_for(os.path.abspath(str(ass)))


def _lines(P, name, words, dur, idx=None):
    """הכתוביות כמו שהצריבה תצייר אותן (חלוקה, שורות, "📐 פריסת שורות", זמן כל מילה, והמילים המוגדלות
    כש-idx לא None) — לציור בדף. words = המילים המיושרות, בלי SUB_DELAY (כמו words.json)."""
    sys.path.insert(0, str(HERE))
    import build_ass as B
    from subtitle_terms import fix_words
    import karaoke_ass as KA
    import make_short_layout as LAY
    use_project_rabbi(P, cam=False)                      # כרטיס 25: אותה עצירת כתוביות כמו בצריבה (פרופיל הרב)
    lay, _, _ = LAY.chunks_for(P, name, words)          # "📐 פריסת שורות" — אותה פריסה כמו בצריבה
    words = [dict(w, start=w["start"] + KA.SUB_DELAY, end=w["end"] + KA.SUB_DELAY) for w in words]
    items, rows_by_first = KA.make_items(words, dur, lay, with_index=idx is not None)
    plan, over = KA.plan_from_idx(items, idx) if idx is not None else ({}, [])
    out = []
    for ci, (start, end, chunk) in enumerate(items):
        tokens = fix_words([w["word"].strip() for w in chunk], color=False).split()
        ws = [w for w in chunk if w["word"].strip()]
        n = len(tokens)
        t = [min(max(ws[min(k, len(ws) - 1)]["start"], start), end) for k in range(n)] if ws else [start] * n
        if t:
            t[0] = start
        rows = (KA.layout_rows(tokens, chunk, words, rows_by_first) if lay else None) or B.split_rows(tokens)
        ln = {"s": round(start, 3), "e": round(end, 3), "rows": [len(r) for r in rows],
              "w": tokens, "t": [round(x, 3) for x in t]}
        big = plan.get(ci) or []
        if big and len(ws) == n:                         # כמו בצריבה: רק כשהמילים תואמות אחת-לאחת
            ln["big"] = big
        if ci in over:
            ln["over"] = True
        out.append(ln)
    return out


def sub_lines(project, name, emph=None):
    """הכתוביות של הקליף לתצוגה המקדימה בחלון (צבע / "▶ כתוביות" — מיידי, בלי צריבה): אותה חלוקה לכתוביות
    ולשורות כמו karaoke_ass.build, עם זמן תחילת כל מילה. הציור עצמו — בדף.
    emph = "on"/"off" — לראות את הקליף עם/בלי הגדלת מילים לפני "החל" (ברירת מחדל: מה שהמתג אומר)."""
    sys.path.insert(0, str(HERE))
    import make_short_emph as EM
    P = Path(project)
    wj = P / ("work/subtitles/%s_words.json" % name)
    words = json.load(open(wj, encoding="utf-8"))["words"]
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    dur = duration(P / c["clean"])
    on = EM.is_on(P, name) if emph not in ("on", "off") else emph == "on"
    idx = None
    if on:
        ensure_proposal(P, c, words, dur)
        idx, _ = EM.idx_for_words(P, name, words) if EM.is_on(P, name) else _idx_forced(P, name, words)
    import karaoke_styles as KS
    return {"lines": _lines(P, name, words, dur, idx), "rgb": clip_rgb(name, P), "emph": on, "em_rgb": clip_em(P, name),
            "rate": KS.speech_rate(words), "opacity": SET.load().get("marker_opacity")}


def _idx_forced(P, name, words):
    """המילים להגדלה כאילו המתג דולק (תצוגה לפני "החל")."""
    import make_short_emph as EM
    d = EM.load(P, name) or {}
    live = [k for k, w in enumerate(words) if w["word"].strip()]
    got, lost = EM.resolve(EM.picks_of(d), [EM.norm(words[k]["word"]) for k in live])
    return {live[i] for i in got if i is not None}, lost


# ─────────────── 🔠 הגדלת מילים + תצוגה מקדימה של הכתוביות לפני צריבה (כרטיס 15, 22/10/2026) ───────────────

def plain_text(raw):
    """הטקסט מתיבת העריכה כמו שהצריבה תקרא אותו: בלי שורות #, ובכל ספק [א / ב] — האפשרות הראשונה."""
    text = " ".join(l for l in (raw or "").splitlines() if not l.lstrip().startswith("#"))

    def first_ear(m):
        a = m.group(1).split("/")[0].strip()
        return "" if a in ("—", "-") else a
    return " ".join(re.sub(r"\[([^\]]*)\]", first_ear, text).split())


def align_text(P, c, raw):
    """הטקסט (גם לא שמור) מיושר למילים של האוזן הראשונה — מה ש-finish יעשה. (words, כיסוי, הרווח הכי גדול)."""
    sys.path.insert(0, str(HERE))
    import align_clean_text as ACT
    import check_subs as CS
    asr_words = json.load(open(Path(P) / c["ear1"], encoding="utf-8"))["words"]
    words = ACT.align(asr_words, plain_text(raw))
    try:
        ratio, worst, _ = CS.analyze(asr_words, words)
    except Exception:
        ratio, worst = 1.0, 0.0
    return words, ratio, worst


def ensure_proposal(P, c, words, dur):
    """אין הצעה של מודל לקליף (זמנים ידניים / שיעור מלפני כרטיס 15) — ההצעה האוטומטית, פעם אחת, נשמרת."""
    import make_short_emph as EM
    d = EM.load(P, c["name"]) or {"on": False, "picks": None, "proposed": None, "src": None}
    if d.get("proposed") is None and d.get("picks") is None:
        d["proposed"] = EM.auto_proposal(words, dur)
        d["src"] = "auto"
        EM.save(P, c["name"], d)
    return d


def emph_for_burn(P, c, aligned, report, choice=None):
    """לצריבה: None כשהמתג כבוי (בדיוק כמו תמיד); אחרת קבוצת המילים להגדלה, ומה שלא נמצא — לדוח.
    30/10: choice = הסגנון של הקליף. מרקר / ריחוף בלי הדגשה — מילים מסומנות לא משנות כלום (None). ריחוף עם הדגשה: בחירת
    הצבע היא ההדלקה — בפעם הראשונה שהמתג של הקליף נדלק לבד (אחר כך הוא יכול לכבות), והמילים צבועות, לא מוגדלות."""
    import make_short_emph as EM
    st, rgb = SET.parse_choice(choice)
    if st in ("marker", "box") or (st == "float" and not rgb):
        return None
    if st == "float" and not EM.is_on(P, c["name"]) and not c.get("emph_forced"):
        ed = EM.load(P, c["name"]) or {"on": False, "picks": None, "proposed": None, "src": None}
        ed["on"] = True
        EM.save(P, c["name"], ed)
        c["emph_forced"] = True
    if not EM.is_on(P, c["name"]):
        return None
    ensure_proposal(P, c, aligned, duration(Path(P) / c["clean"]))
    idx, lost = EM.idx_for_words(P, c["name"], aligned)
    report.append("%s: 🔠 הגדלת מילים — %d מילים" % (c["name"], len(idx or ())))
    if lost:
        report.append("%s: %d מילים להגדלה לא נמצאו בטקסט (ירדו): %s"
                      % (c["name"], len(lost), " · ".join(p["w"] for p in lost[:6])))
    return idx


def emph_view(project, name, raw=None):
    """לדף: מצב המתג, ההצעה (מחושבת עכשיו אם עוד אין — "הצעה אוטומטית"), ומה שערך."""
    import make_short_emph as EM
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    d = EM.load(P, name) or {"on": False, "picks": None, "proposed": None, "src": None}
    if d.get("proposed") is None:
        if raw is None:
            raw = read_edit_raw(P / c["edit"])["text"]
        words, _, _ = align_text(P, c, raw)
        d = ensure_proposal(P, c, words, duration(P / c["clean"]))
    return {"on": bool(d.get("on")), "picks": EM.picks_of(d), "proposed": d.get("proposed") or [],
            "edited": d.get("picks") is not None, "src": d.get("src") or "auto",
            "label": EM.SRC_LABEL.get(d.get("src") or "auto", "הצעה אוטומטית")}


def emph_set(project, name, on=None, picks=False, revert=False):
    """מהדף: on = המתג; picks = רשימה (מה שערך); revert = חזרה להצעה. לא צורב — "✓ החל" צורב."""
    import make_short_emph as EM
    P = Path(project)
    d = EM.load(P, name) or {"on": False, "picks": None, "proposed": None, "src": None}
    if on is not None:
        d["on"] = bool(on)
    if revert:
        d["picks"] = None
    elif picks is not False:
        d["picks"] = EM.clean_picks(picks, limit=200)
    EM.save(P, name, d)
    return emph_view(project, name)


def hook_view(project, name):
    """🎬 לדף (6/11): מצב ההוק של קליף — דולק/כבוי (בפועל), מה נבחר, הצעת המודל וההצעה האוטומטית, והמילים לבחירה.
    ready=False = עוד אין כתוביות מיושרות (לפני הסיום) — אין מה לבחור."""
    sys.path.insert(0, str(HERE))
    import hook_clip as HC
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    cfg = SET.load()
    out = {"on": hook_active(c, cfg), "explicit": c.get("hook_on"), "built": bool(c.get("hook_built")),
           "global": bool(cfg.get("hook_on", True)), "ready": False, "hook": c.get("hook"), "words": [],
           "proposed": None, "suggest": None, "min": HC.MIN_S, "max": HC.MAX_S}
    try:
        words = json.load(open(P / ("work/subtitles/%s_words.json" % name), encoding="utf-8"))["words"]
    except (OSError, ValueError, KeyError):
        return out
    out["ready"] = True
    out["words"] = [{"w": w["word"].strip(), "s": round(w["start"], 2), "e": round(w["end"], 2)} for w in words]
    sp = HC.find_span(words, c["hook_quote"]) if c.get("hook_quote") else None
    out["proposed"] = {"i0": sp[0], "i1": sp[1]} if sp else None
    sg = HC.suggest(words)
    out["suggest"] = {"i0": sg["i0"], "i1": sg["i1"]} if sg else None
    h = c.get("hook") or {}
    sp = HC.resolve(h, words) if h.get("text") else None
    out["current"] = {"i0": sp[0], "i1": sp[1], "sec": round(HC.span_seconds(words, sp[0], sp[1]), 1)} if sp else None
    return out


def hook_set(project, name, i0=None, i1=None, on=None, auto=False):
    """מהדף: i0/i1 = הרגע שבחר (מילים); auto = חזרה להצעה (מודל → יוריסטית); on = מתג הקליף (True/False/None = כמו ההגדרה
    הכללית). לא צורב — "✓ החל" צורב (restyle --hook=redo)."""
    sys.path.insert(0, str(HERE))
    import hook_clip as HC
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    words = json.load(open(P / ("work/subtitles/%s_words.json" % name), encoding="utf-8"))["words"]
    if auto:
        sp = HC.find_span(words, c["hook_quote"]) if c.get("hook_quote") else None
        src = "gemini"
        if not sp:
            sg = HC.suggest(words)
            sp, src = ((sg["i0"], sg["i1"]), "auto") if sg else (None, None)
        c["hook"] = ({"i0": sp[0], "i1": sp[1], "src": src,
                      "text": " ".join(w["word"].strip() for w in words[sp[0]:sp[1] + 1])} if sp else None)
    elif i0 is not None and i1 is not None:
        i0, i1 = int(i0), int(i1)
        if not (0 <= i0 <= i1 < len(words)):
            raise ValueError("רגע לא תקין")
        sec = HC.span_seconds(words, i0, i1)
        if sec > 6.0:
            raise ValueError("ההוק ארוך מדי (%.1f שניות) — עד כ-3.5 שניות" % sec)
        c["hook"] = {"i0": i0, "i1": i1, "src": "user", "text": " ".join(w["word"].strip() for w in words[i0:i1 + 1])}
    if on in (True, False):
        c["hook_on"] = on
    elif on == "default":
        c["hook_on"] = None
    json.dump(st, open(P / (STATE + ".tmp"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    (P / (STATE + ".tmp")).replace(P / STATE)
    return hook_view(project, name)


def preview_rgb(P, c):
    """הצבע שהקליף ייצרב בו (לתצוגה לפני הצריבה הראשונה) — אותה בחירה כמו ב-finish."""
    rgb = c.get("sub_rgb_user") or clip_rgb(c["name"], P)
    if rgb:
        return rgb
    cfg = SET.load()
    gcolor, grgb = SET.sub_color(cfg)
    return clip_choice(cfg, os.path.abspath(str(Path(P) / ("work/subtitles/%s.ass" % c["name"]))))


def sub_preview(project, name, raw, emph=None):
    """"▶ תצוגה מקדימה לכתוביות" בשלב התיקון: הטקסט כמו שהוא בתיבה עכשיו (גם לא שמור) מיושר לקול, ומה
    שהצריבה תצייר — שורות, זמנים, פריסה שקבע, ומילים מוגדלות כשהמתג דולק. emph = {"on", "picks"} מהדף
    (מה שמסומן ברגע זה), או None = מה ששמור. כמה שניות, בלי צריבה."""
    import make_short_emph as EM
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    dur = duration(P / c["clean"])
    words, ratio, worst = align_text(P, c, raw)
    d = EM.load(P, name) or {}
    on = bool(emph.get("on")) if isinstance(emph, dict) else bool(d.get("on"))
    idx, lost = None, []
    if on:
        if isinstance(emph, dict) and emph.get("picks") is not None:
            picks = EM.clean_picks(emph["picks"], limit=200)
        else:
            picks = EM.picks_of(ensure_proposal(P, c, words, dur))
        live = [k for k, w in enumerate(words) if w["word"].strip()]
        got, lost = EM.resolve(picks, [EM.norm(words[k]["word"]) for k in live])
        idx = {live[i] for i in got if i is not None}
    lines = _lines(P, name, words, dur, idx)
    import karaoke_styles as KS
    return {"lines": lines, "rgb": preview_rgb(P, c), "em_rgb": clip_em(P, name), "emph": on, "lost": [p["w"] for p in lost],
            "rate": KS.speech_rate(words), "opacity": SET.load().get("marker_opacity"),
            "over": sum(1 for l in lines if l.get("over")), "cover": round(ratio, 3), "gap": round(worst, 1)}


PREVIEW_SUBS_SEC = 20


def preview(project, name, kind, arg="", clip_db=0, at=0, emph=None):
    """תצוגה מקדימה מהירה ל"הגדרות מהירות" (21/10/2026 — הוא רוצה לראות את החלופה בשניות,
    לא אחרי דקות של צריבה):
      music <uuid|off> [--db=N] — 15 השניות הראשונות של הבסיס בלי מוזיקה, מעורבבות עם המנגינה
                                  (בעוצמה N של הקליף, 22/10)
      camera <default|smooth|zippy> [--at=SEC] — 10 שניות במצלמה הזאת, 540x960, קידוד מהיר.
                                  --at (28/10, כרטיס 22): מהשנייה הזאת בקליף, ולצד הקליף הנוכחי
                                  באותו רגע — "לפני | אחרי" בקובץ אחד, מסונכרן
    מדפיס FILE=<נתיב>. לא נוגע בקליף עצמו."""
    P = Path(project)
    os.chdir(P)
    st = load_st()
    use_rabbi(st.get("rabbi"))
    c = clip_of(st, name)
    d = Path("work/preview")
    d.mkdir(parents=True, exist_ok=True)
    if kind == "music":
        plain = Path("work/plain/%s.mp4" % name)
        if not plain.exists():
            raise ValueError("אין בסיס בלי מוזיקה ל-%s" % name)
        cut = d / ("%s_plain15.mp4" % name)
        if not cut.exists() or cut.stat().st_mtime < plain.stat().st_mtime:
            run([FFMPEG, "-y", "-v", "error", "-i", plain, "-t", str(PREVIEW_MUSIC_SEC), "-c", "copy", cut])
        if arg in ("", "off"):
            say("FILE=%s" % (P / cut))
            return 0
        track = track_by_uuid(arg)
        lv = SET.music_levels(clip_db=clip_db)       # 22/10: עוצמה לקליף — הרמות בשם הקובץ, כל עוצמה תצוגה משלה
        out = d / ("%s_music_%s_%s.mp4" % (name, re.sub(r"[^\w-]", "", arg)[:40], "_".join(lv[1::2])))
        if not out.exists() or out.stat().st_mtime < cut.stat().st_mtime:
            run([PY, HERE / "mix_music.py", cut, track["path"], out, *lv])
        say("FILE=%s" % (P / out))
        return 0
    if kind == "subs":
        # 30/10: "מרקר"/"ריחוף" — תצוגה אמיתית: אותו .ass כמו בצריבה, ב-libass, על הקטע הנקי (20 שניות, 540x960, בלי קול).
        # ציור מקורב בדף לא מראה את התיבה הרצה/הריחוף ולא את הגופן הנכון (הוא ראה "מילים שקופצות" — בצריבה זה לא כך)
        if not SET.valid_choice(arg):
            raise ValueError("סגנון לא תקין: %s" % arg)
        import karaoke_ass as KA
        import make_short_emph as EM
        import make_short_layout as LAY
        words_json = "work/subtitles/%s_words.json" % name
        aligned = json.load(open(words_json, encoding="utf-8"))["words"]
        lay, _, _ = LAY.chunks_for(P, name, aligned)
        eidx = None
        if emph == "on":
            eidx = _idx_forced(P, name, aligned)[0]
        elif emph is None and EM.is_on(P, name):
            eidx = EM.idx_for_words(P, name, aligned)[0]
        ass = d / ("%s_subs_%s.ass" % (name, hashlib.md5(("%s|%s" % (arg, emph)).encode()).hexdigest()[:6]))
        build_subs(words_json, str(ass), duration(c["clean"]), arg, lay, eidx)
        out = d / ("%s_subs_%s.mp4" % (name, hashlib.md5(ass.read_bytes() + str(Path(c["clean"]).stat().st_mtime).encode()).hexdigest()[:10]))
        if not out.exists():
            run([FFMPEG, "-y", "-v", "error", "-t", str(PREVIEW_SUBS_SEC), "-i", c["clean"], "-vf",
                 "scale=540:960,ass=%s:fontsdir=%s" % (ass.as_posix(), os.path.join(LIB, "fonts")), "-an",
                 "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-pix_fmt", "yuv420p", out])
        say("FILE=%s" % (P / out))
        return 0
    if kind == "camera":
        if arg not in CAMERAS:
            raise ValueError("מצלמה לא מוכרת: %s" % arg)
        import camera_path as CP
        at = max(0.0, float(at or 0))
        if at:          # מתחילים שתי שניות לפני היציאה, כדי לראות את הרב יוצא (או לא)
            at = max(0.0, min(at - 2.0, duration(c["clean"]) - PREVIEW_CAM_SEC))
        tag = "_at%d" % int(at * 10) if at else ""
        out = d / ("%s_cam_%s%s.mp4" % (name, arg, tag))
        env = CP.cam_env(dict(os.environ, MPC_PREVIEW=str(out), MPC_PREVIEW_SEC=str(PREVIEW_CAM_SEC),
                              MPC_PREVIEW_AT="%.2f" % at), arg)
        r = subprocess.run([PY, str(HERE / "multi_piece_clip.py"), name, *["%.3f,%.3f" % tuple(ab) for ab in c["cuts"]]],
                           cwd=P, env=env, capture_output=True, text=True, errors="replace")
        if r.returncode or not out.exists():
            raise RuntimeError("התצוגה המקדימה נכשלה:\n" + "\n".join((r.stderr or r.stdout).strip().splitlines()[-6:]))
        if tag:
            # לפני | אחרי: הקליף כמו שהוא עכשיו (משמאל) והמצלמה החדשה (מימין), אותן שניות בדיוק
            sbs = d / ("%s_cam_%s%s_sbs.mp4" % (name, arg, tag))
            run([FFMPEG, "-y", "-v", "error", "-ss", "%.2f" % at, "-t", str(PREVIEW_CAM_SEC), "-i", c["clean"],
                 "-i", out, "-filter_complex",
                 "[0:v]scale=540:960,setsar=1[a];[1:v]scale=540:960,setsar=1[b];[a][b]hstack=inputs=2[v]",
                 "-map", "[v]", "-map", "0:a?", "-shortest", "-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
                 "-c:a", "aac", "-b:a", "128k", sbs])
            out = sbs
        say("FILE=%s" % (P / out))
        return 0
    raise ValueError("סוג תצוגה לא מוכר: %s" % kind)


def build_camera(P, c, camera):
    """הווידאו הנקי מחדש במצלמה רגילה, חלקה (CAM_SMOOTH=7) או זריזה (CAM_ZIPPY=1). אותם גבולות
    בדיוק — הקול, התמלול והכתוביות לא משתנים."""
    import camera_path as CP
    env = CP.cam_env(os.environ, camera)
    with heavy(c["name"]):
        r = subprocess.run([PY, str(HERE / "multi_piece_clip.py"), c["name"],
                            *["%.3f,%.3f" % tuple(ab) for ab in c["cuts"]]],
                           cwd=P, env=env, capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("הבנייה נכשלה:\n" + "\n".join((r.stderr or r.stdout).strip().splitlines()[-8:]))
    c["camera"] = camera
    c["framing"] = check_framing(c["clean"], camera)


def restyle(project, name, color=None, camera=None, music=None, want="", reject_old=False, subs=False, vol=None,
            emph=None, hook=None):
    """שינוי מהיר של קליף מוכן — מ"הגדרות מהירות" בכרטיס הקליף (21/10/2026):
      color  — RRGGBB: צבע הכתוביות בקליף הזה  → צריבה מחדש (דקה-שתיים)
      camera — default/smooth                   → בנייה מחדש + צריבה (כמה דקות)
      music  — swap/back/off/on (+want=uuid)    → ערבוב מחדש מהבסיס בלבד (שניות)
        swap = מנגינה אחרת (want ריק = הבאה בסבב); back = הקודמת (c["music_history"]);
        off = בלי מוזיקה וקרדיט יורד; on = המנגינה שלפני הכיבוי (או הבאה בסבב)
      vol    — עוצמת המוזיקה בקליף הזה, dB יחסית לרמה הכללית (‎-8…+6, 0 = כמו תמיד) → ערבוב מחדש (22/10)
      emph   — on/off: המתג "🔠 הגדלת מילים" של הקליף (כרטיס 15)       → צריבה מחדש
    בסוף: הקובץ מוחלף במקומו בתיקיית השורטס, meta.json + «תיאור להעתקה.txt» (רק שורת הקרדיט
    משתנה, אם המוזיקה השתנתה). הסמלים — לפי ההגדרות של עכשיו. רק בטיוטה — לתיקייה ולדרייב ב"💾 שמור"."""
    P = Path(project)
    os.chdir(P)
    st = load_st()
    use_rabbi(st.get("rabbi"))
    c = clip_of(st, name)
    plain = Path("work/plain/%s.mp4" % name)
    if not plain.exists():
        raise ValueError("אין בסיס בלי מוזיקה ל-%s — צריך ליצור את השורט מחדש" % name)
    d, mp4 = final_video(name)
    meta_p = d / "meta.json"
    meta = json.load(open(meta_p, encoding="utf-8"))
    if "track" not in c:
        c["track"] = meta.get("music")
    if color is not None and not SET.valid_choice(color):
        raise ValueError("צבע לא תקין: %s" % color)
    if camera is not None and camera not in CAMERAS:
        raise ValueError("מצלמה לא מוכרת: %s" % camera)
    report = []

    if camera and camera != (c.get("camera") or "default"):
        say("④ %s: בונה מחדש במצלמה %s (כמה דקות)" % (name, CAMERAS[camera]))
        build_camera(P, c, camera)
        say("   %s" % (c["framing"] or {}).get("text", ""))
        report.append("%s: מצלמה %s" % (name, CAMERAS[camera]))
    elif camera:
        camera = None
    if emph in ("on", "off"):
        c["emph_forced"] = True                    # בחירה מפורשת של המתג — ריחוף עם הדגשה לא ידליק אותו מעצמו
        import make_short_emph as EM
        ed = EM.load(P, name) or {"on": False, "picks": None, "proposed": None, "src": None}
        if bool(ed.get("on")) != (emph == "on"):
            ed["on"] = emph == "on"
            EM.save(P, name, ed)
            subs = True
            report.append("%s: הגדלת מילים %s" % (name, "דולקת" if emph == "on" else "כבויה"))
    if hook in ("on", "off", "redo"):              # 🎬 הוק (6/11): דולק/כבוי לקליף הזה, או בנייה מחדש אחרי שערך את הרגע
        if hook != "redo":
            c["hook_on"] = hook == "on"
        elif c.get("hook_on") is None:
            c["hook_on"] = True
        subs = True
        report.append("%s: הוק %s" % (name, {"on": "נוסף", "off": "הוסר", "redo": "נבנה מחדש"}[hook]))
    rgb = (color or clip_rgb(name) or "1AC8A8").upper()
    if camera or subs or (color and color.upper() != (clip_rgb(name) or "")):
        sys.path.insert(0, str(HERE))
        import build_clean_video as BCV
        import karaoke_ass as KA
        import make_short_layout as LAY
        words_json = "work/subtitles/%s_words.json" % name
        if not Path(words_json).exists():
            raise ValueError("אין קובץ כתוביות ל-%s — צריך ליצור את השורט מחדש" % name)
        say("⑥ %s: כתוביות %s%s" % (name, SET.choice_name(rgb), " בפריסת השורות שקבעת" if LAY.load(P, name) else ""))
        ass = "work/subtitles/%s.ass" % name
        aligned = json.load(open(words_json, encoding="utf-8"))["words"]
        lay, _, _ = LAY.chunks_for(P, name, aligned)
        eidx = emph_for_burn(P, c, aligned, report, rgb)
        # הוק: מה שנבנה כבר בקליף (או מה שביקש עכשיו) נשמר גם בשינוי צבע/פריסה; קליף ישן בלי הוק לא מקבל הוק בלי שביקש
        want_hook = bool(c["hook_on"]) if c.get("hook_on") is not None else bool(c.get("hook_built"))
        with heavy(name):
            hk = hook_prep(P, c, SET.load(), aligned, lay, eidx, report, force=want_hook)
        build_subs(hk["words_json"] if hk else words_json, ass, hk["total"] if hk else duration(c["clean"]), rgb,
                   hk["lay"] if hk else lay, hk["eidx"] if hk else eidx)
        if hk:
            import hook_clip as HC
            HC.trim_ass(ass, hk["plan"]["Tc"])
        logos = SET.logos(SET.load())
        say("⑦ %s: צורב מחדש%s, מנרמל קול (דקה-שתיים)" % (name, " עם הסמלים" if logos else ""))
        burn = "work/burn/%s.mp4" % name
        Path("work/burn").mkdir(parents=True, exist_ok=True)
        with heavy(name):
            BCV.burn_subtitles(hk["clean"] if hk else c["clean"], ass, burn, os.path.join(LIB, "fonts"), logos=logos)
        tmp_plain = Path("work/plain/%s.new.mp4" % name)
        loudnorm(burn, str(tmp_plain))
        os.replace(tmp_plain, plain)
        c["sub_rgb"] = rgb
        if color:
            report.append("%s: כתוביות %s" % (name, SET.choice_name(rgb)))
        if subs:
            report.append("%s: הכתוביות נצרבו מחדש %s" % (name, "בפריסת השורות שקבעת" if lay else "בחלוקה האוטומטית"))
        visual = True
    else:
        visual = False

    old = (c.get("track") or {}).get("uuid", "")
    if music:
        track, cur, old = resolve_music(c, music, want)
    else:
        track, cur = c.get("track") and track_by_uuid_safe(c["track"]), c.get("track")
    if vol is not None:
        vol = max(SET.CLIP_DB[0], min(SET.CLIP_DB[1], int(vol)))
        if vol == int(c.get("music_db") or 0):
            vol = None
    if not visual and not music and vol is None:
        say("אין מה לשנות — הכול כבר כך")
        say("STAGE=done")
        return 0
    if vol is not None:
        c["music_db"] = vol
        report.append("%s: עוצמת המוזיקה %s" % (name, "כמו תמיד" if vol == 0 else "%+d dB" % vol))
    clip_db = int(c.get("music_db") or 0)

    tmp_dir = Path("work/swap")
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp = tmp_dir / ("%s.mp4" % name)
    if track:
        say("⑧ %s: מערבב את «%s»%s" % (name, track["title"], " (%+d dB)" % clip_db if clip_db else ""))
        add_music(str(plain), str(tmp), track, clip_db)
    else:
        say("⑧ %s: בלי מוזיקה" % name)
        shutil.copyfile(str(plain), str(tmp))
    # 4.1.3: בזמן הבנייה (דקה-שתיים) השמירה יכלה להזיז את התיקייה clip1 → clip1_<כותרת>. מאתרים אותה שוב עכשיו,
    # ולא סומכים על הנתיב מההתחלה (הוא גרם ל-[Errno 2] ‏shorts/clip1/video.mp4). meta נקרא מחדש מהתיקייה הנוכחית.
    d, mp4 = final_video(name)
    meta_p = d / "meta.json"
    meta = json.load(open(meta_p, encoding="utf-8"))
    shutil.move(str(tmp), str(mp4))
    if music:
        # ההיסטוריה: "חזרה" מורידה את האחרונה; שינוי אחר שומר את הנוכחית כדי שאפשר לחזור אליה
        hist = c.setdefault("music_history", [])
        if music in ("back", "on") and hist and hist[-1]["uuid"] == (track or {}).get("uuid"):
            hist.pop()
        elif cur and (not track or track["uuid"] != old):
            hist.append({k: cur.get(k, "") for k in ("uuid", "title", "credit")})
        del hist[:-20]
        c["track"] = {k: track[k] for k in ("uuid", "title", "credit")} if track else None
        meta["description"] = credit_into(meta.get("description", ""), track["credit"] if track else "")
        if track:
            meta["music"] = c["track"]
        else:
            meta.pop("music", None)
        json.dump(meta, open(meta_p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        report.append("%s: %s" % (name, "המוזיקה עכשיו «%s»" % track["title"] if track
                                  else "בלי מוזיקה (והקרדיט ירד מהתיאור)"))
    if color:
        c["sub_rgb_user"] = rgb                    # הצבע שבחר לקליף הזה — נשאר גם ב"צור שוב"
    save_st(dict(load_st(), clips=[c if x["name"] == name else x for x in load_st()["clips"]]))
    # הטיוטה עכשיו תואמת את ההגדרות של הקליף — "צור שוב" לא יבנה אותה שוב בלי סיבה
    import make_short_progress as PR
    fin = PR.data(P).get("finish") or {}
    try:
        fin[name] = finish_key(c, SET.load(), SET.logos(SET.load()))
        PR.put(P, "finish", fin)
    except OSError:
        pass
    if not TEST_MODE:
        if music and track:
            run([PY, HERE / "music_library.py", "used", track["uuid"], "--clip", str(d), "--project", str(P)],
                check=False)
        if music and reject_old and old and track:
            run([PY, HERE / "music_library.py", "rate", old, "--bad", "--note", "הוחלפה בחלון", "--clip", str(d)],
                check=False)
            report.append("המנגינה הקודמת לא תיבחר שוב")
    # 21/10/2026: שינוי מהיר משנה רק את הטיוטה. לתיקיית השורטס זה נכנס רק ב"💾 שמור" — הוא מחליט מתי.
    st = load_st()
    if unsaved(P, st):
        report.append("השינוי בטיוטה — כדי שייכנס לתיקיית השורטס: \"💾 שמור שוב\"")
    say("\n" + "\n".join(report))
    say("STAGE=done")
    return 0


def track_by_uuid_safe(t):
    """המנגינה הנוכחית לערבוב מחדש אחרי צריבה. נמחקה מהספרייה → אותו קובץ אי אפשר; עוצרים."""
    try:
        return track_by_uuid(t["uuid"])
    except ValueError:
        raise RuntimeError("המנגינה של הקליף («%s») כבר לא בספרייה — לבחור מנגינה אחרת יחד עם השינוי"
                           % t.get("title", ""))


def swap(project, name, want="", reject_old=False, mode="swap"):
    """מוזיקה בלבד (הכפתורים מ-21/10) — restyle בלי שינוי בתמונה."""
    return restyle(project, name, music=mode, want=want, reject_old=reject_old)


# ─────────────── "🗑️ ויתרתי" ושחזור (21/10/2026) ───────────────

def drop_clip(project, name):
    """קליף שוויתר עליו: יוצא מהשמירה ומהספירה של "עד 2 לשיעור", והטיוטה שלו עוברת ל-work/dropped/
    (לא נמחקת) — "שחזר" מחזיר אותה. קליף שכבר נשמר לתיקיית השורטס: את העותק שם מעבירים לסל המיחזור
    של ווינדוס דרך החלון (win_recycle.py), אחרי אישור — כאן רק מצב הטיוטה."""
    P = Path(project)
    os.chdir(P)
    st = load_st()
    c = clip_of(st, name)
    park = park_dirs(clip_dirs(name), "dropped_%s" % name)
    c["dropped"] = True
    c["dropped_at"] = time.strftime("%Y-%m-%d %H:%M")
    if park:
        c["dropped_park"] = str(park)
    save_st(st)
    say("🗑️ %s — ויתרת עליו (אפשר לשחזר)" % name)
    return 0


def drop_saved(project, name):
    """ויתור על שורט שכבר נשמר: הטיוטה הצידה (drop_clip), והעותק בתיקיית השורטס → סל המיחזור של ווינדוס
    (win_recycle: העתקה, אימות, סל, ורק אז הסרה) → מסמן לגיבוי ברקע (מראה — יורד גם בדרייב, לפח שלו)."""
    import make_short_progress as PR
    import win_recycle as WR
    P = Path(project)
    os.chdir(P)
    st = load_st()
    PR.job_begin(P, "drop_saved", ["drop_saved", P, name])
    PR.plan(P, [["bin", "העברה לסל המיחזור", 15]])
    target, root = Path(st.get("export_target") or ""), export_root()
    PR.step(P, "bin", "run")
    gone = []
    # רק בתוך תיקיית השורטס של המצב הנוכחי — שיעור שהועתק לבדיקה עדיין מצביע על התיקייה האמיתית (22/10)
    mine = Path((st.get("export_dirs") or {}).get(name) or "")
    if root and str(mine) not in ("", ".") and mine.is_dir() and root.resolve() in mine.resolve().parents:
        # המבנה החדש (כרטיס 16): התיקייה של השורט עצמו
        say("🗑️ %s → סל המיחזור" % mine.name)
        gone.append(WR.recycle(mine, root, "%s_%s" % (P.name.split("_")[-1], name)))
        SL.prune_empty(mine.parent, root)           # סדרה/רב שהתרוקנו — לא נשארות תיקיות ריקות (22/10)
    elif root and target.is_dir() and root.resolve() in target.resolve().parents and (target / "shorts").is_dir():
        for d in sorted((target / "shorts").glob(name + "*")):
            if d.is_dir() and re.match(re.escape(name) + r"(_|$)", d.name):
                say("🗑️ %s → סל המיחזור" % d.name)
                gone.append(WR.recycle(d, root, "%s_%s" % (P.name.split("_")[-1], name)))
    PR.step(P, "bin", "done", " · ".join(gone) or "לא היה עותק בתיקיית השורטס")
    drop_clip(P, name)
    st = load_st()
    (st.get("export_dirs") or {}).pop(name, None)     # גם אם התיקייה כבר לא הייתה שם (הזיז/מחק בעצמו)
    if st.get("saved"):
        st["saved"]["snap"].pop(name, None)
        st["saved"]["clips"] = [x for x in st["saved"].get("clips", []) if x != name]
    save_st(st)
    report = []
    if gone:
        mark_drive_pending("ויתור: %s" % name)        # מראה — יירד גם מהדרייב בגיבוי הבא ברקע
    say("\n".join(report + ["✅ %s הוסר מתיקיית השורטס (נמצא בסל המיחזור, אפשר לשחזר משם)" % name]))
    return 0


def restore_clip(project, name):
    P = Path(project)
    os.chdir(P)
    st = load_st()
    c = clip_of(st, name)
    if c.get("cleaned"):                           # כרטיס 17: נוקה — הקבצים בסל המיחזור של ווינדוס, לא כאן
        raise ValueError("%s נוקה ב-%s — אפשר לשחזר רק מסל המיחזור של ווינדוס" % (name, c["cleaned"]))
    park = Path(c.get("dropped_park") or "")
    if park.is_dir() and not clip_dirs(name):
        for d in park.iterdir():
            shutil.move(str(d), str(Path("shorts") / d.name))
        park.rmdir()
    for k in ("dropped", "dropped_at", "dropped_park"):
        c.pop(k, None)
    save_st(st)
    say("↩ %s שוחזר" % name)
    return 0


# ─────────────── הזזת התחלה/סוף של קליף (21/10/2026) ───────────────

def _clip_to_source(cuts, t):
    """זמן בקליף הנקי → זמן בשיעור (החלקים מחוברים ברצף; החפיפה של 0.18ש' זניחה כאן)."""
    acc = 0.0
    for a, b in cuts:
        if t <= acc + (b - a) + 1e-6:
            return a + (t - acc)
        acc += b - a
    return cuts[-1][1]


def context_words(project, name, pad=30.0):
    """מילים עם זמנים בשיעור סביב הקליף (pad שניות לפני ואחרי) — לגרירה של התחלה/סוף ול"משפט קודם/הבא".
    קודם מה שכבר יש (תמלול השיעור כולו מהבחירה האוטומטית), ורק אם אין — תמלול קצר של החלונות (Modal)."""
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    a0, b1 = c["cuts"][0][0], c["cuts"][-1][1]
    lo, hi = max(0.0, a0 - pad), b1 + pad
    cache = P / "work" / "retime" / ("%s_ctx_%d_%d.json" % (name, lo * 10, hi * 10))
    if cache.exists():
        return json.load(open(cache, encoding="utf-8"))
    words = []
    try:                                       # תמלול השיעור כולו (turbo) מהבחירה האוטומטית
        import make_short_pick as MP
        pk = MP.load(P)
        les = (pk.get("lessons") or [None])[0]
        if les and les.get("words"):
            words = [w for w in MP.lesson_words(P, les) if lo <= w["start"] <= hi]
    except Exception:
        words = []
    if not words:
        os.chdir(P)
        src = "source/full_video.mp4"
        wins = []
        for k, (x, y) in enumerate([(lo, min(a0 + 8, b1)), (max(b1 - 8, a0), hi)]):
            w = Path("work/retime/%s_w%d_%d_%d.wav" % (name, k, x * 10, y * 10))
            w.parent.mkdir(parents=True, exist_ok=True)
            wav_cut(src, x, y, w)
            wins.append((x, w))
        got = asr([str(w) for _, w in wins], "work/retime/asr", TURBO)
        for x, w in wins:
            words += [dict(v, start=v["start"] + x, end=v["end"] + x) for v in got[str(w)] if v["word"].strip()]
        words.sort(key=lambda v: v["start"])
        ded = []
        for v in words:                        # שני החלונות נחפפים בקליף קצר
            if not ded or v["start"] > ded[-1]["start"] + 0.05:
                ded.append(v)
        words = ded
    out = {"lo": lo, "hi": hi, "cuts": c["cuts"],
           "words": [{"w": v["word"].strip(), "s": round(v["start"], 2), "e": round(v["end"], 2)} for v in words]}
    cache.parent.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(cache, "w", encoding="utf-8"), ensure_ascii=False)
    return out


SCENE_PAD = 60.0


def scene_words(project, name):
    """📜 "הקטע והסביבה שלו" (28/10, שינוי הבחירה גם אחרי הצריבה): הטקסט המלא כמו בשלב ההצעות — מה שבשורט,
    הדילוגים (עם הסיבה, אם המודל נתן), ודקה לפני ואחרי. המילים: תמלול השיעור כולו כשיש; אחרת החלונות שבקצוות
    (context_words) + מה שבתוך הקליף מהאוזן הראשונה, מתורגם לזמן בשיעור. orig = ההצעה המקורית של המודל."""
    P = Path(project)
    st = json.load(open(P / STATE, encoding="utf-8"))
    c = clip_of(st, name)
    cuts = [list(x) for x in c["cuts"]]
    cx = context_words(project, name, SCENE_PAD)
    words = list(cx["words"])
    a0, b1 = cuts[0][0], cuts[-1][1]
    if not any(a0 + 8 < w["s"] < b1 - 8 for w in words) and b1 - a0 > 16:
        try:                                       # רק קצוות — האמצע מהאוזן הראשונה של הקליף
            ear = json.load(open(P / c["ear1"], encoding="utf-8"))["words"]
            mid = [{"w": v["word"].strip(), "s": round(_clip_to_source(cuts, v["start"]), 2),
                    "e": round(_clip_to_source(cuts, v["end"]), 2)} for v in ear if v["word"].strip()]
            words = [w for w in words if not (a0 + 8 < w["s"] < b1 - 8)] + [w for w in mid if a0 + 8 < w["s"] < b1 - 8]
            words.sort(key=lambda w: w["s"])
        except (OSError, ValueError, KeyError):
            pass
    # ההצעה המקורית והדילוגים: מהמפרט (סדר הקליפים) ← ההצעה ב-pick.json עם אותה כותרת/זמנים
    orig, skips = None, []
    try:
        sp = json.load(open(P / "make_short_spec.json", encoding="utf-8"))
        k = int(re.sub(r"\D", "", name) or 0) - 1
        sc = sp["clips"][k] if 0 <= k < len(sp.get("clips", [])) else None
        if sc:
            orig = [list(x) for x in parse_pieces(sc["pieces"])]
            import make_short_pick as MP
            pk = MP.load(P) if (P / MP.PICK).exists() else {}
            p = next((p for p in pk.get("picks", []) if p.get("pieces") == sc["pieces"] or
                      (p.get("title") and p.get("title") == sc.get("title"))), None)
            if p:
                skips = [{"from": s["from"], "to": s["to"], "reason": s.get("reason") or s.get("why") or ""}
                         for s in p.get("skips") or [] if "from" in s and "to" in s]
                o = (p.get("orig") or {}).get("pieces")
                if o:
                    orig = [list(x) for x in parse_pieces(o)]
    except (OSError, ValueError, KeyError, IndexError):
        pass
    return {"lo": cx["lo"], "hi": cx["hi"], "cuts": cuts, "words": words, "skips": skips, "orig": orig}


def merge_text(old_text, old_ear1, old_cuts, new_text, new_ear1, new_cuts):
    """הטקסט שהוא כבר תיקן נשמר; רק מה שנוסף בהתחלה/בסוף בא מהתמלול החדש, ומה שירד — יורד.
    כל מילה בטקסט שלו מקבלת זמן בשיעור דרך היישור לאוזן הראשונה הישנה; מילים חדשות — מהאוזן החדשה."""
    def toks(t):
        return [x for x in re.findall(r"\[[^\]]*\]|\S+", t)]

    def timed(text, ear, cuts):
        tk = toks(text)
        plain = [norm(re.sub(r"^\[([^/\]]*).*$", r"\1", x)) for x in tk]
        ew = [w for w in ear if w["word"].strip()]
        sm = difflib.SequenceMatcher(None, plain, [norm(w["word"]) for w in ew], autojunk=False)
        tt = [None] * len(tk)
        for blk in sm.get_matching_blocks():
            for i in range(blk.size):
                tt[blk.a + i] = _clip_to_source(cuts, ew[blk.b + i]["start"])
        known = [i for i, x in enumerate(tt) if x is not None]
        for i in range(len(tt)):               # מילה שתוקנה (לא מתיישרת) — זמן מהשכנות
            if tt[i] is None and known:
                prv = max([k for k in known if k < i], default=None)
                nxt = min([k for k in known if k > i], default=None)
                tt[i] = tt[prv] if prv is not None else tt[nxt]
        return list(zip(tt, tk))

    inside = lambda t, cuts: any(a - 0.15 <= t <= b + 0.15 for a, b in cuts)
    old = [(t, x) for t, x in timed(old_text, old_ear1, old_cuts) if t is not None and inside(t, new_cuts)]
    new = [(t, x) for t, x in timed(new_text, new_ear1, new_cuts) if t is not None and not inside(t, old_cuts)]
    allw = sorted(old + new, key=lambda p: p[0])
    return " ".join(x for _, x in allw)


def retime(project, name, pieces):
    """גבולות חדשים שהוא גרר (בשיעור, בצעדים של 0.1ש') → הצמדה לגבול מילה ולשקט שנמדד → בנייה מחדש של
    הקליף → שתי אוזניים על הקליף החדש → הטקסט שתיקן נשמר (merge_text) עם מה שנוסף."""
    import make_short_progress as PR
    P = Path(project)
    os.chdir(P)
    st = load_st()
    use_rabbi(st.get("rabbi"))
    c = clip_of(st, name)
    want = [tuple(map(float, ab)) for ab in pieces]
    PR.job_begin(P, "retime", ["retime", P, name, json.dumps(pieces)])
    PR.plan(P, [["snap", "הצמדה לגבול מילה ולשקט", 20], ["build:" + name, "בנייה מחדש של הקליף", 90],
                ["ears", "תמלול בשתי אוזניים", 50], ["edit", "מיזוג הטקסט שתיקנת", 3]])
    src = "source/full_video.mp4"
    full = duration(src)
    PR.step(P, "snap", "run")
    wins = []
    for k, (a, b) in enumerate(want):
        lo, hi = max(0.0, a - 4), min(full, b + 4)
        w = Path("work/snap/%s_rt%d_%d_%d.wav" % (name, k, lo * 10, hi * 10))
        wav_cut(src, lo, hi, w)
        wins.append((k, lo, w))
    words = asr([str(w) for *_, w in wins], "work/snap/asr", TURBO)
    cuts = []
    for k, lo, w in wins:
        ws = [dict(x, start=x["start"] + lo, end=x["end"] + lo) for x in words[str(w)]]
        a, b = want[k]
        s, e, first, last = snap_piece(ws, load_audio(w), lo, a, b, opening=(k == 0))
        cuts.append((s, e))
        say("   חלק %d: %.1f–%.1f  «%s … %s»" % (k + 1, s, e, first, last))
    PR.step(P, "snap", "done")
    old_cuts = [tuple(x) for x in c["cuts"]]
    f, _, _ = parse_edit(c["edit"])
    old_raw = read_edit_raw(c["edit"])
    old_ear1 = json.load(open(c["ear1"], encoding="utf-8"))["words"]

    PR.step(P, "build:" + name, "run")
    say("④ %s: בונה מחדש בגבולות החדשים" % name)
    import camera_path as CP
    env = CP.cam_env(os.environ, c.get("camera"))
    with heavy(name):
        r = subprocess.run([PY, str(HERE / "multi_piece_clip.py"), name, *["%.3f,%.3f" % ab for ab in cuts]],
                           cwd=P, env=env, capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("הבנייה נכשלה:\n" + "\n".join((r.stderr or r.stdout).strip().splitlines()[-8:]))
    PR.step(P, "build:" + name, "done")
    PR.step(P, "ears", "run")
    tag = hashlib.md5(json.dumps(cuts).encode()).hexdigest()[:8]
    d = Path("work/ear_rt_%s" % tag)
    d.mkdir(parents=True, exist_ok=True)
    wav = str(d / ("%s.wav" % name))
    wav_cut(c["clean"], None, None, wav)
    e1 = asr([wav], "work/ear_large_rt_" + tag, LARGE)[wav]
    try:
        e2 = asr([wav], "work/ear_turbo_rt_" + tag, TURBO)[wav]
        new_text, doubts = two_ears(e1, e2)
    except MD.OverCap:
        raise
    except Exception as ex:
        say("   ⚠️ האוזן השנייה נכשלה: %s" % ex)
        new_text, doubts = " ".join(w["word"].strip() for w in e1), None
    PR.step(P, "ears", "done")
    PR.step(P, "edit", "run")
    # 21/10/2026 (כרטיס 12): הוא ממשיך לתקן את הקליף בזמן הבנייה, והדף שומר לבד — המיזוג נעשה על מה שבקובץ
    # עכשיו, לא על מה שהיה בהתחלה (אחרת התיקונים מהדקות האלה היו נעלמים)
    old_raw = read_edit_raw(c["edit"])
    f, _, _ = parse_edit(c["edit"])
    text = merge_text(old_raw["text"], old_ear1, old_cuts, new_text, e1, cuts)
    c["retime_note"] = {"at": time.time(), "changes": words_changed(old_raw["text"], text)}
    import make_short_editor as ED
    dl = ED.read_delivered(P, name)
    if dl:              # מד האיכות: "מה שנמסר" בגבולות החדשים = מה שנמסר קודם + המילים החדשות מהתמלול
        ED.write_delivered(P, name, merge_text(dl["text"], old_ear1, old_cuts, new_text, e1, cuts), dl.get("src") or "ears")
    c["cuts"] = [list(x) for x in cuts]
    c["seconds"] = round(duration(c["clean"]), 1)
    c["ear1"] = "work/subtitles/%s_ear1.json" % name
    json.dump({"words": e1}, open(c["ear1"], "w", encoding="utf-8"), ensure_ascii=False)
    # ספקות: רק אלה שעדיין בטקסט (המיזוג שמר את מה שהכריע); הזמנים מהקליף החדש
    left = set(re.findall(r"\[[^\]]*\]", text))
    shift = old_cuts[0][0] - cuts[0][0]
    new_d = [x for x in (doubts or []) if x[1] in left]
    seen = {x[1] for x in new_d}
    c["doubts"] = sorted(new_d + [[max(0.0, round(t + shift, 2)), s] for t, s in (c.get("doubts") or [])
                                  if s in left and s not in seen], key=lambda x: x[0])
    c["framing"] = check_framing(c["clean"], c.get("camera")) if SET.load()["camera_check"] else None
    write_edit(c["edit"], c, P, f["כותרת"], f["תיאור"], f["תגיות"], text, old_raw["yt"])
    st = dict(load_st(), clips=[c if x["name"] == name else x for x in load_st()["clips"]])
    save_st(st)
    PR.step(P, "edit", "done")
    say("✅ %s: %.1f שניות. הטקסט שתיקנת נשמר; מה שנוסף — מהתמלול החדש." % (name, c["seconds"]))
    say("STAGE=ready_edit")
    return 0


def undo_repeat(project, name, idx):
    """כרטיס 25: "בטל" לחזרה שהוסרה (פרופיל הרב): החור נסגר בחזרה בגבולות הקליף, והקליף נבנה מחדש כמו בהזזת גבול
    (retime) — הטקסט שתיקן נשמר. הרשומה מסומנת "undone", כך שהסרה לא תחזור לבד."""
    P = Path(project)
    os.chdir(P)
    st = load_st()
    c = clip_of(st, name)
    recs = c.get("repeats") or []
    idx = int(idx)
    if not 0 <= idx < len(recs) or recs[idx].get("action") != "removed":
        raise ValueError("אין חזרה מוסרת כזאת בקליף")
    new = RP.rejoin(c["cuts"], recs[idx]["removed"])
    if new is None:
        raise ValueError("גבולות הקליף כבר זזו ביד — אפשר להחזיר את המילה בהזזת הגבולות (⏱)")
    recs[idx]["action"] = "undone"
    save_st(st)
    say("↩ %s: מחזיר את «%s» (%s)" % (name, recs[idx]["word"], mmss_(recs[idx]["t"])))
    return retime(project, name, new)


def _main(a):
    import make_short_progress as PR
    if len(a) == 4 and a[0] == "undo_repeat":
        return undo_repeat(a[1], a[2], a[3])
    if len(a) in (2, 3) and a[0] == "prepare":
        mode = {"--net-only": "net", "--local": "local"}.get(a[2]) if len(a) == 3 else None
        return prepare(a[1], mode) or 0
    if len(a) in (2, 3) and a[0] == "finish":
        only = next((x[8:].split(",") for x in a[2:] if x.startswith("--clips=")), None)
        return finish(a[1], only)
    if len(a) in (2, 3) and a[0] == "save":
        only = next((x[8:].split(",") for x in a[2:] if x.startswith("--clips=")), None)
        return save_lesson(a[1], only)
    if len(a) == 3 and a[0] == "drop_saved":
        return drop_saved(a[1], a[2])
    if len(a) == 3 and a[0] in ("drop", "restore"):
        return (drop_clip if a[0] == "drop" else restore_clip)(a[1], a[2])
    if len(a) == 4 and a[0] == "retime":
        return retime(a[1], a[2], json.loads(a[3]))
    if len(a) == 3 and a[0] == "context":
        print(json.dumps(context_words(a[1], a[2]), ensure_ascii=False))
        return 0
    if len(a) in (3, 4) and a[0] == "rebuild":
        PR.job_begin(a[1], "rebuild", a)
        return rebuild(a[1], a[2], *a[3:])
    if a and a[0] == "swap" and len(a) >= 3:
        PR.job_begin(a[1], "swap", a)
        mode = next((x[7:] for x in a[3:] if x.startswith("--mode=")), "swap")
        rest = [x for x in a[3:] if x != "--reject-old" and not x.startswith("--mode=")]
        return swap(a[1], a[2], rest[0] if rest else "", "--reject-old" in a, mode)
    if a and a[0] == "restyle" and len(a) >= 3:
        PR.job_begin(a[1], "restyle", a)
        o = dict(x[2:].split("=", 1) for x in a[3:] if x.startswith("--") and "=" in x)
        return restyle(a[1], a[2], o.get("color") or None, o.get("camera") or None, o.get("music") or None,
                       o.get("uuid", ""), "--reject-old" in a, subs="--subs" in a,
                       vol=int(o["db"]) if o.get("db") not in (None, "") else None, emph=o.get("emph") or None, hook=o.get("hook") or None)
    if len(a) == 3 and a[0] == "emph_auto":            # בדיקה ידנית: מה ההצעה האוטומטית לקליף
        print(json.dumps(emph_view(a[1], a[2]), ensure_ascii=False, indent=1))
        return 0
    if a and a[0] == "preview" and len(a) >= 4:
        db = next((int(x[5:]) for x in a[4:] if x.startswith("--db=")), 0)
        at = next((float(x[5:]) for x in a[4:] if x.startswith("--at=")), 0)
        em = next((x[7:] for x in a[4:] if x.startswith("--emph=")), None)
        rest = [x for x in a[4:] if not x.startswith(("--db=", "--at=", "--emph="))]
        return preview(a[1], a[2], a[3], rest[0] if rest else "", db, at, em)
    print(__doc__)
    return 2


if __name__ == "__main__":
    import make_short_progress as PR
    try:
        rc = _main(sys.argv[1:])
        PR.job_end(None, rc == 0, "" if rc == 0 else "הסתיים בשגיאה")
        sys.exit(rc)
    except Exception as e:
        msg = str(e).strip()
        if not net_ok() and not isinstance(e, ValueError):
            msg = "אין חיבור לאינטרנט — " + msg     # סיבה ברורה: הורדה/תמלול נכשלו כי אין רשת
        say("❌ %s" % msg)
        PR.job_end(None, False, msg)
        sys.exit(1)
