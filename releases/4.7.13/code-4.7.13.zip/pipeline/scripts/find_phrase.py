# -*- coding: utf-8 -*-
"""
מאתר משפט (בדרך כלל "משפט פתיחה/סיום לאימות" שג'מיני נתן) בתוך תמלול
word-level, בעזרת התאמה מטושטשת (fuzzy) - כי לג'מיני לפעמים יש ניסוח
מעט שונה מהמילים המדויקות שה-ASR שמע (במיוחד שמות פרטיים).

מחזיר את חלון הזמן הכי דומה + ציון התאמה (0-1). ציון מתחת ל-0.75 =
לא אמין, כדאי לחפש שוב עם קטע קצר יותר מתוך המשפט (למשל 3-4 מילים
הכי ייחודיות), או לבדוק את התמלול ידנית.

שימוש:
  python find_phrase.py <words_json> "<המשפט לחיפוש>"
"""
import json
import re
import sys
from difflib import SequenceMatcher


def normalize(t):
    return re.sub(r"[^א-ת]", "", t)


def load_words(words_json_path):
    with open(words_json_path, encoding="utf-8") as f:
        data = json.load(f)
    words = data.get("words", [])
    out = []
    for w in words:
        norm = normalize(w.get("word", ""))
        if norm:
            out.append({"norm": norm, "start": w["start"], "end": w["end"], "raw": w["word"]})
    return out


def best_match_window(words, phrase: str):
    target_words = [normalize(w) for w in phrase.split()]
    target_words = [w for w in target_words if w]
    n = len(target_words)
    if n == 0 or len(words) < n:
        return None

    target_joined = "".join(target_words)
    best = None

    for i in range(len(words)):
        for span in range(max(1, int(n * 0.7)), int(n * 1.3) + 2):
            j = i + span
            if j > len(words):
                break
            window_joined = "".join(w["norm"] for w in words[i:j])
            score = SequenceMatcher(None, target_joined, window_joined).ratio()
            if best is None or score > best[0]:
                best = (score, i, j)

    if best is None:
        return None
    score, i, j = best
    return {
        "score": round(score, 3),
        "start_time": words[i]["start"],
        "end_time": words[j - 1]["end"],
        "matched_text": "".join(w["raw"] for w in words[i:j]).strip(),
    }


if __name__ == "__main__":
    words_json, phrase = sys.argv[1], sys.argv[2]
    words = load_words(words_json)
    result = best_match_window(words, phrase)
    print(json.dumps(result, ensure_ascii=False, indent=2))
