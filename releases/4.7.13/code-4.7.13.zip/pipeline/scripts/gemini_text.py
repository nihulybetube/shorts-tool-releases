# -*- coding: utf-8 -*-
"""קריאת טקסט-בלבד ל-Gemini. משלים את `ask_gemini_upload` (וידאו) ואת
`gemini_verify_audio` (אודיו), שהם היחידים שהיו עד עכשיו.

נדרש לשלב ההגהה האוטומטית ב-`auto_pipeline.py`: מיזוג שני תמלולים לטקסט
אחד הוא משימת טקסט, בלי מדיה, ולכן שער "0 טוקני וידאו/אודיו" לא רלוונטי
כאן — במקומו יש שער אורך אצל הקורא.
"""
import json
import urllib.parse
import time
import urllib.error
import urllib.request

from ask_gemini_upload import load_api_key

MODEL = "gemini-flash-latest"
RETRY = {429, 500, 502, 503, 504}


def ask_text(prompt, model=MODEL, thinking_budget=4096, timeout=180):
    api_key = load_api_key()
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"thinkingConfig": {"thinkingBudget": thinking_budget}},
    }
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model}:generateContent?key={urllib.parse.quote(api_key, safe='')}")
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    last, result = None, None
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            break
        except TimeoutError:
            last = "timeout"
        except urllib.error.HTTPError as e:
            if e.code not in RETRY:
                raise
            last = e
        if attempt < 3:
            time.sleep(4 * (2 ** attempt))
    if result is None:
        raise RuntimeError(f"Gemini לא זמין אחרי 4 ניסיונות: {last}")
    if "error" in result:
        raise RuntimeError(f"Gemini API error: {result['error']}")
    cand = (result.get("candidates") or [{}])[0]
    return "".join(p.get("text", "") for p in cand.get("content", {}).get("parts", []))
