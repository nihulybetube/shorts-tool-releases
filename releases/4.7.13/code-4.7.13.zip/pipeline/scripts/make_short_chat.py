# -*- coding: utf-8 -*-
"""
make_short_chat.py — "עבודה עם צ'אט (Claude)" בתיבת "עדכון תוכנה" (27/10/2026).

למה: הוא סומך על Claude יותר מכול לקוד, ורוצה לבקש שינויים מצ'אט רגיל (claude.ai) במקום מ-Claude Code —
כדי לחסוך את המכסה של Claude Code: הצ'אט רק כותב קוד, והתוכנה בודקת ומחילה בעצמה (make_short_update.py).
עד היום "העתק הוראות לעוזר" העתיק רק את הפורמט ורשימת קבצים — בלי קוד, אז צ'אט יכול היה רק לנחש.
כאן נבנה בלוק טקסט אחד שמדביקים בצ'אט, עם כל מה שהוא צריך:
  "🐞 מצאתי באג"   — מה קרה (במילים שלו) + הפורמט + תקציר המבנה (מ-HANDOFF) + העבודה האחרונה שנכשלה (יומן
                     ושגיאה, מנוקים) + בדיקת המערכת + בדיקת האיכות האחרונה + גרסאות + הקוד של הקבצים שכנראה מעורבים
                     (מה-traceback, מסוג העבודה, ומהמילים בתיאור שלו)
  "➕ אני רוצה שינוי" — מה לשנות + הפורמט + תקציר המבנה + מפתח כל הקבצים + הקוד של הקבצים הרלוונטיים
הקוד כולו ~1.35MB — לא נכנס להודעה אחת. לכן בוחרים לפי רלוונטיות (מילים ← קבצים ופונקציות, ומה שהוא סימן
ברשימה), ושומרים על תקציב תווים (הגדרה chat_code_chars, ברירת מחדל 150 אלף). קובץ גדול מדי → רק הקטעים
הרלוונטיים עם מספרי שורות + מפת הקובץ, ונאמר את זה בבלוק. הצ'אט יכול לענות רק "צריך קבצים: a, b:120-300, c#func"
— התיבה מזהה את זה ובונה בלוק המשך עם בדיוק מה שביקש (followup).
🔒 שום סוד: יומנים עוברים HEALTH.scrub; כל הבלוק עובר guard() — דפוסי מפתחות + הערכים האמיתיים שלו — ואם משהו
נשאר, הבלוק לא נבנה. קבצי הגדרות/מפתחות (UPD.FORBIDDEN) וקבצים מחוץ ל-git לא נכנסים אף פעם.

שימוש (בדיקות):  make_short_chat.py block bug|change "<טקסט>" [--tick path]... [--budget N] [--json]
                 make_short_chat.py files "<path>, <path>:10-40, <path>#name" [--json]
"""
import json
import math
import os
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
sys.path.insert(0, str(HERE))
import make_short_update as UPD  # noqa: E402

DEFAULT_BUDGET = 150000
TEXT_EXT = (".py", ".html", ".sh", ".md", ".txt", ".json", ".webmanifest", ".ps1", ".bat", ".gitignore")

# תיאור של שורה לקבצים העיקריים (לשאר — השורה הראשונה של ההסבר בראש הקובץ)
PURPOSE = {
    "pipeline/scripts/make_short_app.py": "השרת של החלון (HTTP על 127.0.0.1:8790): עבודות, תור, API לדף, עדכון עצמי",
    "pipeline/scripts/make_short_page.html": "הדף עצמו (HTML + CSS + JavaScript) — כל מה שהוא רואה ולוחץ",
    "pipeline/scripts/make_short.py": "המנוע: prepare / finish / save / swap / restyle / retime — בניית השורט",
    "pipeline/scripts/make_short_pick.py": "בחירת קטעים אוטומטית (Gemini או העתקה לצ'אט), פלייליסטים",
    "pipeline/scripts/make_short_settings.py": "ההגדרות המתקדמות: DEFAULTS, בדיקת ערכים, איפוס וביטול",
    "pipeline/scripts/make_short_update.py": "תיבת \"עדכון תוכנה\": פורמט העדכון, בדיקה, החלה, בדיקה עצמית, החזרה",
    "pipeline/scripts/make_short_chat.py": "הבלוק לצ'אט (הקובץ הזה): בחירת קבצים לפי רלוונטיות ותקציב",
    "pipeline/scripts/make_short_fix.py": "\"🛠️ תקן שורט זה בצ'אט\": בלוק הקשר לקליף אחד, פירוק תשובת צ'אט (החלפה ב-ASS / סקריפט בבידוד), גרסה חדשה, לפני/אחרי, חזרה",
    "pipeline/scripts/make_short_health.py": "בדיקת מערכת (ffmpeg, yt-dlp, עוגיות, דרייב, Modal, דיסק) + scrub לסודות",
    "pipeline/scripts/make_short_engine.py": "מנוע התמלול: גרסאות מוצמדות (requirements-pinned.txt), הודעה על חדשה, \"נסה מנוע חדש יותר\" עם חזרה אוטומטית",
    "pipeline/scripts/make_short_selftest.py": "בקרת איכות: מטריצת הגדרות, בדיקות השרת, חבילת השיתוף (quick/matrix/all)",
    "pipeline/scripts/make_short_rabbis.py": "פרופיל לכל רב: עצירת כתוביות, מצלמה, הסרת חזרות, מילים של הרב; הצעות \"להוסיף לפרופיל?\"",
    "pipeline/scripts/make_short_repeats.py": "הסרת מילה שחוזרת מיד (\"הוא הוא\") מהקול, בשקט שנמדד — רק לרב שהפרופיל שלו מדליק",
    "pipeline/scripts/karaoke_ass.py": "כתוביות קריוקי (שורה שלמה, המילה המדוברת בצבע)",
    "pipeline/scripts/mix_music.py": "ערבוב המוזיקה מתחת לקול",
    "pipeline/scripts/multi_piece_clip.py": "בניית שורט מכמה חלקים של השיעור",
    "pipeline/scripts/build_clean_video.py": "חיתוך על שקט + מצלמה וירטואלית שעוקבת אחרי הפנים + לוגו",
    "docs/HANDOFF.md": "המדריך המלא לעוזר: מבנה, כללים, תקלות ידועות",
    "SKILL.md": "הדרך הישנה (Claude Code צעד-צעד) — המקור למה ש\"צריך\" לקרות",
    "shorts.sh": "השער: PATH, venv, ffmpeg, deno, טעינת config.env — כל הרצה עוברת דרכו",
}

# מילים בבקשה שלו ← קבצים (שמות בסיס) + מונחים שמכוונים לקטעים בתוך קבצים גדולים
TOPICS = [
    (r"כתובי|כתובית|מילה מוגדל|הגדל|פריסת שורות|שורות הכתוב|קריוקי|subtitle|karaoke",
     ["karaoke_ass.py", "make_short_emph.py", "make_short_layout.py", "align_clean_text.py"], ["sub", "karaoke", "emph", "ass"]),
    (r"מוזיק|מנגינ|שיר|עוצמ|לייק|❤|music", ["make_short_music.py", "mix_music.py"], ["music", "track", "מוזיקה"]),
    (r"מצלמ|ממורכז|מרכז|פנים|מסגר|framing|camera", ["camera_sim.py", "multi_piece_clip.py", "build_clean_video.py",
                                                     "check_framing.py", "face_track.py"], ["camera", "framing", "cam"]),
    (r"סמל|לוגו|logo", ["make_short_settings.py"], ["logo"]),
    (r"דרייב|גיבוי|drive|☁", ["drive_backup.sh", "make_short_health.py"], ["drive"]),
    (r"תור|queue", ["make_short_app.py"], ["queue", "BUILD_Q", "תור"]),
    (r"בחיר|בוחר|קטעים|gemini|ג'מיני|גמיני|פלייליסט|playlist|דירוג|מה לחפש", ["make_short_pick.py"], ["pick", "gemini", "playlist", "request"]),
    (r"פרופיל|חזרה|חוזר|גמגום|הוא הוא|רב מסוים", ["make_short_rabbis.py", "make_short_repeats.py"], ["profile", "repeat", "rabbi"]),
    (r"סל המיחזור|נקה|🧹|מחיק|ניקוי|הועלה", ["make_short_clean.py", "win_recycle.py"], ["clean", "recycle", "uploaded"]),
    (r"שיתוף|חבילה|zip|התקנה|מחשב אחר", ["make_short_share.py", "install_windows.ps1"], ["share", "package"]),
    (r"תקן שורט|תיקון בצ'אט|תקן בצ'אט|פגם|גרסה מתוקנת|חזור לגרסה", ["make_short_fix.py", "make_short_page.html"], ["fix", "chat_fix", "fixbox"]),
    (r"עדכון תוכנה|תיבת העדכון|צ'אט|claude|עוזר", ["make_short_update.py", "make_short_chat.py"], ["upd", "update", "chat"]),
    (r"modal|מודאל|תמלול|אוזן|אוזניים|asr|whisper", ["modal_asr.py", "asr.py", "make_short_modal_day.py", "make_short.py"],
     ["modal", "asr", "ear"]),
    (r"שמיר|שומר|ייצוא|תיקיי|תיקייה|💾|export", ["shorts_layout.py", "export_clips.py", "make_short.py"],
     ["save", "export", "folder"]),
    (r"הגדרו|ברירת מחדל|settings", ["make_short_settings.py", "make_short_page.html"], ["settings", "SET", "data-k"]),
    (r"כפתור|מסך|חלון|דף|לשוני|כרטיס|תפריט|עיצוב|כהה|בהיר|גלילה|לחיצה|לוחץ|נפתח|מופיע|רואה|שורה בדף",
     ["make_short_page.html", "make_short_app.py"], []),
    (r"התרא|צליל|🔔|הודעה קופצת", ["make_short_page.html"], ["notif", "sound", "toast"]),
    (r"yt-dlp|הורד|עוגי|cookies|יוטיוב|youtube", ["make_short.py", "make_short_health.py"], ["yt-dlp", "ytdlp", "cookies", "download"]),
    (r"בדיקת מערכת|באנר|health|אזהר", ["make_short_health.py"], ["health", "banner", "alert"]),
    (r"מנוע|גרס|faster|pip|ספרי", ["make_short_engine.py", "install.sh"], ["engine", "pins", "upgrade"]),
    (r"תיאור|כותרת|תגי|meta", ["write_clip_meta.py", "make_short.py"], ["meta", "title", "desc"]),
    (r"חיתוך|שקט|גבולות|זמנים|retime|קצר מדי|ארוך מדי", ["make_short.py"], ["retime", "snap", "silence"]),
    (r"עריכה|ספק|תיקון טקסט|טקסט", ["make_short.py", "make_short_page.html"], ["edit", "doubt", "text"]),
    (r"הפעלה|קיצור|bat|לא נפתח|שחור", ["launcher.bat.txt", "make_short_app.py"], ["launcher", "restart", "idle"]),
]

# סוג העבודה שנכשלה ← הקבצים שמריצים אותה
KIND_FILES = {
    "prepare": ["make_short.py", "multi_piece_clip.py", "build_clean_video.py", "modal_asr.py"],
    "finish": ["make_short.py", "karaoke_ass.py", "mix_music.py"],
    "retime": ["make_short.py"], "restyle": ["make_short.py", "karaoke_ass.py"], "rebuild": ["make_short.py", "multi_piece_clip.py"],
    "swap": ["make_short.py", "make_short_music.py", "mix_music.py"],
    "save": ["make_short.py", "shorts_layout.py", "export_clips.py"], "drop_saved": ["make_short.py", "win_recycle.py"],
    "pick": ["make_short_pick.py"], "clean": ["make_short_clean.py", "win_recycle.py"], "share": ["make_short_share.py"],
    "upd_apply": ["make_short_update.py"], "upd_undo": ["make_short_update.py"], "update": ["make_short_health.py"],
    "engine": ["make_short_engine.py"], "fixapply": ["make_short_fix.py"],
}

STOP = set("""של את עם אני אנחנו רוצה רוצים שיהיה שיהיו כאשר כשאני לא כן זה זאת הוא היא הם אבל גם רק כל יותר מאוד אחרי לפני
צריך אפשר שהוא שזה הזה הזאת כמו במקום אותו אותה יש אין היה היתה קרה עשה עושה עושים שלי שלו לי לו לה על אל מה מי איך למה
כדי ככה פשוט בבקשה תודה כבר עוד עדיין תמיד אף פעם פעם שוב גם the and for with that this from when not are""".split())

SECRET_ENV = ("GEMINI_API_KEY", "MODAL_TOKEN_ID", "MODAL_TOKEN_SECRET")


# ─────────────── הקבצים ───────────────

def tracked():
    """קבצי הטקסט שב-git (בלי קבצי הגדרות/מפתחות), עם הגודל."""
    r = subprocess.run(["git", "-C", str(REPO), "-c", "core.quotepath=false", "ls-files", "-z"], capture_output=True, text=True)
    out = []
    for f in r.stdout.split("\0"):
        if not f or not (f.endswith(TEXT_EXT) or Path(f).name in (".gitignore",)):
            continue
        base = Path(f).name.lower()
        if any(__import__("fnmatch").fnmatch(base, pat) for pat in UPD.FORBIDDEN):
            continue
        p = REPO / f
        if p.is_file() and not p.is_symlink():
            out.append(f)
    return out


def read(path):
    try:
        return (REPO / path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def purpose(path, text=None):
    if path in PURPOSE:
        return PURPOSE[path]
    text = read(path) if text is None else text
    if path.endswith(".py"):
        m = re.search(r'"""\s*(.*?)"""', text, re.S)
        if m:
            for l in m.group(1).splitlines():
                l = l.strip()
                if l:
                    return re.sub(r"^\S+\.py\s*[—–-]\s*", "", l)[:110]
    if path.endswith(".md"):
        m = re.search(r"^#+\s*(.+)$", text, re.M)
        if m:
            return m.group(1).strip()[:110]
    for l in text.splitlines()[:6]:
        l = l.strip().lstrip("#:;/*-! ").strip()
        if l and not l.startswith(("!/", "-*-", "bash", "usr/bin")) and len(l) > 8:
            return l[:110]
    return ""


def resolve(name, files):
    """נתיב שהצ'אט כתב (מלא, חלקי או רק שם הקובץ) → נתיב בריפו."""
    name = name.strip().strip("`'\"").lstrip("./")
    if name.startswith(("a/", "b/")) and name[2:] in files:
        name = name[2:]
    if name in files:
        return name
    hits = [f for f in files if f.endswith("/" + name)] or [f for f in files if Path(f).name == Path(name).name]
    return hits[0] if len(hits) == 1 else None


# ─────────────── קטעים בתוך קובץ ───────────────

BOUNDARY = {
    ".py": re.compile(r"^(?:def |class |async def |@\w|# ─|if __name__)"),
    ".html": re.compile(r"^(?:async function |function |const [A-Za-z_$][\w$]*\s*=|let [A-Za-z_$]|/\*|<div class=\"card|<!--|"
                        r"<script|<style|document\.|window\.|<div class=\"set\"><h3)"),
    ".sh": re.compile(r"^(?:[\w-]+\s*\(\)\s*\{|# ─|#\s*=+)"),
    ".md": re.compile(r"^#{1,3} "),
    ".ps1": re.compile(r"^(?:function |# ─|#\s*=+|# ---)"),
}


def sections(path, text):
    """→ [(start, end, name)] 1-based כולל. גבולות: def/class/function/כותרות; קטע קטן מתמזג לקודם, גדול מתפצל."""
    lines = text.split("\n")
    rx = BOUNDARY.get(Path(path).suffix)
    starts = [0] + [i for i, l in enumerate(lines) if i and rx and rx.match(l)]
    raw = []
    for k, s in enumerate(starts):
        e = (starts[k + 1] if k + 1 < len(starts) else len(lines)) - 1
        raw.append([s, e])
    merged = []
    for s, e in raw:
        if merged and (e - s + 1) < 6 and (merged[-1][1] - merged[-1][0]) < 120:
            merged[-1][1] = e
        else:
            merged.append([s, e])
    out = []
    for s, e in merged:
        while e - s + 1 > 220:
            out.append((s + 1, s + 200, _name(lines[s])))
            s += 200
        out.append((s + 1, e + 1, _name(lines[s])))
    return out


def _name(line):
    m = re.match(r"\s*(?:async\s+)?(?:def|class|function)\s+([\w$]+)", line) or re.match(r"\s*(?:const|let)\s+([\w$]+)", line)
    if m:
        return m.group(1)
    return line.strip()[:60]


def tokens(text):
    """מילים מהבקשה שלו (עברית בלי תחיליות, מזהים באנגלית) — לחיפוש בקוד."""
    out = []
    for w in re.findall(r"[\w֐-׿'\"/.-]+", text or ""):
        w = w.strip("'\".-/")
        if len(w) < 3 or w.lower() in STOP:
            continue
        out.append(w)
        if re.match(r"^[֐-׿]", w) and w[0] in "והבלמשכ" and len(w) >= 4:
            out.append(w[1:])
        if w.startswith(("וה", "שה", "בה", "לה", "מה", "כש")) and len(w) >= 5:
            out.append(w[2:])
    return list(dict.fromkeys(out))[:40]


def topic_hit(rx, what, toks):
    """נושא מתאים? חלופה עם רווח — חיפוש בכל הטקסט; מילה בודדת — רק בתחילת מילה (אחרי תחילית),
    כדי ש"תור" לא יימצא בתוך "כפתור"."""
    low = (what or "").lower()
    for alt in rx.split("|"):
        if " " in alt or not re.match(r"[\w֐-׿]", alt):
            if alt in low:
                return alt
        elif any(re.match(alt, t.lower()) for t in toks):
            return alt
    return None


def weights(toks, files):
    """משקל לכל מילה לפי כמה קבצים היא מופיעה בהם: מילה נדירה מכוונת, מילה שבכל מקום ("שורט") כמעט לא שווה."""
    code = [f for f in files if not f.startswith(("docs/", "pipeline/tests/")) and not f.endswith((".md", ".txt", ".json"))]
    texts = [read(f).lower() for f in code]
    n = max(1, len(texts))
    w = {}
    for t in toks:
        df = sum(1 for x in texts if t.lower() in x)
        w[t] = 0.0 if not df else math.log2(1 + n / df) - 1.0
    return w


def score_chunk(lines_text, name, toks, focus, hot):
    """ניקוד של קטע: מילים מהבקשה (משוקללות), מונחים מכוונים, ושורות "חמות" (מה-traceback)."""
    low = lines_text.lower()
    s = 0.0
    for t, w in (toks.items() if isinstance(toks, dict) else ((t, 1.0) for t in toks)):
        n = low.count(t.lower())
        if n and w > 0:
            s += w * min(3, n)
    for f in focus:
        n = low.count(f.lower())
        if n:
            s += min(12, 3 * n)
        if f.lower() in name.lower():
            s += 20
    s += 100 * hot
    return s


# ─────────────── ניקוי סודות ───────────────

def _known():
    vals = []
    try:
        import make_short_share as SH
        vals += [v.decode("utf-8", "replace") if isinstance(v, bytes) else v for v in SH.known_secrets()]
        pats = [re.compile(p.pattern.decode() if isinstance(p.pattern, bytes) else p.pattern) for p in SH.SECRET_PATTERNS]
    except Exception:
        pats = [re.compile(p) for p in (r"AIza[0-9A-Za-z_\-]{30,}", r"\b(?:ak|as)-[0-9A-Za-z]{16,}", r"ya29\.[0-9A-Za-z_\-]{20,}",
                                        r"1//0[0-9A-Za-z_\-]{30,}")]
    for name in SECRET_ENV:
        v = (os.environ.get(name) or "").strip().strip("'\"")
        if len(v) >= 8:
            vals.append(v)
    return [v for v in vals if v and len(v) >= 8], pats


def guard(text):
    """הבלוק כולו: ערכים אמיתיים של מפתחות ודפוסי מפתחות → [הוסתר]. נשאר משהו → שגיאה (לא מעתיקים)."""
    vals, pats = _known()
    n = 0
    for v in vals:
        if v in text:
            n += text.count(v)
            text = text.replace(v, "[הוסתר]")
    for p in pats:
        text, k = p.subn("[הוסתר]", text)
        n += k
    if any(v in text for v in vals) or any(p.search(text) for p in pats):
        raise ValueError("בבלוק נשאר משהו שנראה כמו מפתח — לא מעתיקים. לפנות לעוזר בלי הבלוק.")
    return text, n


# ─────────────── תקציר המבנה ───────────────

def architecture():
    """§1 ו-§2 (העץ) מתוך docs/HANDOFF.md — תמיד בגרסה העדכנית; ועוד כללים קצרים לשינוי קוד."""
    h = read("docs/HANDOFF.md")
    a = h.find("## 1. What this is")
    b = h.find("### The tool's flow")
    body = h[a:b].strip() if a >= 0 and b > a else "(docs/HANDOFF.md לא נמצא — אפשר לבקש: צריך קבצים: docs/HANDOFF.md)"
    rules = """
Rules for code changes (from HANDOFF §2–§5):
- The server is make_short_app.py (Python stdlib http.server, 127.0.0.1:8790 — always 127.0.0.1, never localhost);
  the page is ONE file, make_short_page.html (inline CSS + JS, RTL Hebrew UI, helper $(id), api(path, body), esc(), flash()).
- Heavy work runs as "jobs" (start_job / enqueue) from an immutable code snapshot; the page polls /api/job.
- Settings: make_short_settings.py DEFAULTS (+ clean() limits); the page binds inputs with data-k="<key>".
- Test mode: MAKE_SHORT_NO_EXPORT=1 + MAKE_SHORT_SETTINGS=<temp file> + another port (8766).
- Every user-visible text is Hebrew and plain (the owner is not a programmer). .bat files stay ASCII-only.
- Never touch config.env, cookies, tokens, rclone.conf; never print secrets.
- Python changes take effect after the server restarts by itself (self-update when idle); page changes after F5.
"""
    return body + "\n" + rules.strip()


def file_index(files):
    rows = []
    for f in files:
        t = read(f)
        rows.append("  %s — %s · %d שורות, %s תווים" % (f, purpose(f, t) or "—", t.count("\n") + 1, _k(len(t))))
    return "\n".join(rows)


def _k(n):
    return "%.1f אלף" % (n / 1000) if n >= 1000 else str(n)


# ─────────────── בחירת קבצים ───────────────

def traceback_hits(log, files):
    """File ".../x.py", line N, in func → {path: {"lines": [N], "funcs": [func]}} (עבודות רצות מצילום — לפי סוף הנתיב)."""
    hits = {}
    for path, line, func in re.findall(r'File "([^"]+)", line (\d+), in ([\w<>]+)', log or ""):
        rel = None
        for f in files:
            if path.endswith("/" + f) or path.endswith(f):
                rel = f
                break
        if not rel:
            rel = resolve(Path(path).name, files)
        if rel:
            h = hits.setdefault(rel, {"lines": [], "funcs": []})
            h["lines"].append(int(line))
            if not func.startswith("<"):
                h["funcs"].append(func)
    return hits


def choose(mode, what, ctx, files, ticks=(), unticks=()):
    """→ [{"path", "score", "reason", "focus", "hot_lines"}] לפי סדר חשיבות."""
    by_base = {}
    for f in files:
        by_base.setdefault(Path(f).name, f)
    cand = {}

    def add(path, pts, why, focus=(), hot=()):
        if not path or path not in files:
            return
        c = cand.setdefault(path, {"path": path, "score": 0.0, "reasons": [], "focus": [], "hot_lines": []})
        c["score"] += pts
        if why and why not in c["reasons"]:
            c["reasons"].append(why)
        c["focus"] += [x for x in focus if x not in c["focus"]]
        c["hot_lines"] += list(hot)

    toks = tokens(what)
    for rx, bases, focus in TOPICS:
        hit = topic_hit(rx, what, toks)
        if hit:
            for b in bases:
                add(by_base.get(b), 25, "מתאים למילה «%s»" % hit, focus)
    if mode == "bug" and ctx.get("job"):
        j = ctx["job"]
        for path, h in traceback_hits("\n".join(j.get("log") or []) + "\n" + (j.get("error") or ""), files).items():
            add(path, 70, "מופיע בשגיאה (traceback)", h["funcs"], h["lines"])
        for b in KIND_FILES.get(j.get("kind"), ["make_short_app.py"]):
            add(by_base.get(b), 30, "מריץ את העבודה שנכשלה (%s)" % j.get("kind"))
    # מילים מהתיאור שלו שמופיעות בקוד (טקסט בעברית בדף, שמות פונקציות) — משוקללות לפי נדירות
    W = weights(toks, files)
    generic = []
    for f in files:
        if f.startswith(("docs/", "pipeline/tests/")) or f.endswith((".md", ".txt", ".json")):
            continue
        t = read(f).lower()
        pts = sum(W[w] * min(3, 1 + math.log2(t.count(w.lower()))) for w in toks if W.get(w, 0) > 0 and w.lower() in t)
        if f in cand:
            add(f, min(pts, 30), "מילים מהתיאור מופיעות בקוד")
        elif pts >= 12:
            generic.append((pts, f))
    for pts, f in sorted(generic, reverse=True)[:2]:          # קובץ שרק המילים הכלליות מביאות — לכל היותר שניים
        add(f, min(pts, 30), "מילים מהתיאור מופיעות בקוד")
    for f in ticks:
        add(f, 1000, "סימנתם ברשימה")
    out = sorted((c for c in cand.values() if c["path"] not in unticks), key=lambda c: -c["score"])
    picked = [c for c in out if c["score"] >= 1000] + [c for c in out if 12 <= c["score"] < 1000][:6]
    if not picked and mode == "change":           # בלי שום רמז — רוב השינויים הם בדף ובשרת
        for b in ("make_short_page.html", "make_short_app.py"):
            if by_base.get(b) and by_base[b] not in unticks:
                picked.append({"path": by_base[b], "score": 5, "reasons": ["ברירת מחדל: הדף והשרת"], "focus": [], "hot_lines": []})
    for c in picked:
        c["reason"] = "; ".join(c["reasons"][:3])
    return picked, W


# ─────────────── הצגת קוד ───────────────

def render_whole(path, text):
    n = text.count("\n") + (0 if text.endswith("\n") else 1)
    return "=== קוד מהמחשב: %s · מלא · %d שורות ===\n%s%s=== סוף קוד: %s ===\n" % (
        path, n, text, "" if text.endswith("\n") else "\n", path)


def outline(path, text, secs, limit=5000):
    rows, used = [], 0
    for s, e, name in secs:
        r = "  %d–%d  %s" % (s, e, name)
        if used + len(r) > limit:
            rows.append("  … (המפה קוצרה — אפשר לבקש טווח שורות)")
            break
        rows.append(r)
        used += len(r) + 1
    return "\n".join(rows)


def render_excerpt(path, text, allot, toks, focus, hot_lines, ranges=None, names=None):
    """רק הקטעים הרלוונטיים (או שביקשו: ranges/names), לפי סדר השורות, עם מפת הקובץ. → (טקסט, [(s, e)])"""
    lines = text.split("\n")
    secs = sections(path, text)
    total = len(lines)
    pick = []
    if ranges or names:
        for a, b in ranges or []:
            pick.append((max(1, a), min(total, b)))
        for nm in names or []:
            pick += [(s, e) for s, e, n in secs if n == nm or re.search(r"(?:def|function|class|const|let)\s+%s\b" % re.escape(nm),
                                                                          lines[s - 1])]
    else:
        scored = []
        for s, e, name in secs:
            hot = sum(1 for L in hot_lines if s <= L <= e)
            sc = score_chunk("\n".join(lines[s - 1:e]), name, toks, focus, hot)
            if sc >= 3:                                       # רק קטע שבאמת קשור — לא כל מקום שמופיעה בו מילה כללית
                scored.append((sc, s, e))
        scored.sort(key=lambda x: -x[0])
        if secs and secs[0][1] - secs[0][0] < 80:            # הראש (הסבר, ייבוא, קבועים) — עוזר להבין את השאר
            pick.append((secs[0][0], secs[0][1]))
        for L in hot_lines:                                   # סביב שורת השגיאה עצמה, גם אם הקטע ארוך
            pick.append((max(1, L - 40), min(total, L + 25)))
        used = sum(len("\n".join(lines[a - 1:b])) for a, b in pick)
        for sc, s, e in scored:
            size = len("\n".join(lines[s - 1:e])) + 30
            if used + size > allot:
                continue
            pick.append((s, e))
            used += size
    pick = merge_ranges(pick)
    out, used, shown = [], 0, []
    head_note = "קטעים בלבד (הקובץ: %d שורות, %s תווים — לא נכנס כולו)" % (total, _k(len(text)))
    for a, b in pick:
        chunk = "\n".join(lines[a - 1:b])
        if used + len(chunk) > allot and shown:
            break
        if len(chunk) > allot:                                # טווח אחד ענק — חותכים אותו
            keep, acc = [], 0
            for k, l in enumerate(lines[a - 1:b]):
                if acc + len(l) + 1 > allot:
                    break
                keep.append(l)
                acc += len(l) + 1
            b = a + len(keep) - 1
            chunk = "\n".join(keep)
        out.append("[שורות %d–%d]\n%s" % (a, b, chunk))
        shown.append((a, b))
        used += len(chunk)
    body = "\n".join(out) if out else "(לא נמצא קטע מתאים — לבקש לפי מפת הקובץ)"
    txt = ("=== קוד מהמחשב: %s · %s ===\n%s\n"
           "מפת הקובץ (לבקש קטע: \"צריך קבצים: %s:<משורה>-<עד שורה>\" או \"%s#<שם>\"):\n%s\n=== סוף קוד: %s ===\n") % (
        path, head_note, body, path, path, outline(path, text, secs), path)
    return txt, shown


def merge_ranges(rs):
    out = []
    for a, b in sorted(rs):
        if out and a <= out[-1][1] + 3:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def pack(chosen, budget_left, toks, files_text):
    """מחלק את התקציב: קבצים קטנים — מלאים; קבצים גדולים — קטעים, לפי ניקוד. → (טקסט, [מידע לכל קובץ])"""
    infos, parts = [], {}
    smalls = [c for c in chosen if len(files_text[c["path"]]) + 120 <= min(25000, budget_left)]
    left = budget_left
    for c in smalls:
        t = files_text[c["path"]]
        if len(t) + 120 <= left * (0.7 if len(chosen) > 1 else 1.0):
            parts[c["path"]] = render_whole(c["path"], t)
            left -= len(parts[c["path"]])
    bigs = [c for c in chosen if c["path"] not in parts]
    for k, c in enumerate(bigs):
        t = files_text[c["path"]]
        if len(t) + 120 <= left * (0.6 if k + 1 < len(bigs) else 1.0):
            parts[c["path"]] = render_whole(c["path"], t)
        else:
            weight = c["score"] / max(1.0, sum(x["score"] for x in bigs[k:]))
            allot = max(4000, int((left - 6000 * (len(bigs) - k)) * max(weight, 0.35)))
            allot = min(allot, max(2000, left - 7000))
            if allot < 2000:
                continue
            parts[c["path"]], shown = render_excerpt(c["path"], t, allot, toks, c["focus"], c["hot_lines"])
            c["ranges"] = shown
        left -= len(parts[c["path"]])
        if left < 3000:
            break
    out = []
    for c in chosen:
        if c["path"] not in parts:
            infos.append({"path": c["path"], "how": "לא נכנס (התקציב נגמר)", "chars": 0, "reason": c.get("reason", "")})
            continue
        out.append(parts[c["path"]])
        whole = "· מלא ·" in parts[c["path"]].split("\n", 1)[0]
        infos.append({"path": c["path"], "how": "מלא" if whole else "קטעים: " + ", ".join("%d–%d" % r for r in c.get("ranges", [])[:8]),
                      "chars": len(parts[c["path"]]), "reason": c.get("reason", ""), "whole": whole})
    return "\n".join(out), infos


# ─────────────── הבלוקים ───────────────

ASK = """=== מה אני מבקש ממך (Claude) ===
1. קרא את הבקשה ואת הקוד שלמטה. חסר לך קוד כדי לכתוב שינוי נכון? אל תנחש — ענה רק בשורה אחת, בלי שום טקסט נוסף:
   צריך קבצים: <נתיב>, <נתיב>:<משורה>-<עד שורה>, <נתיב>#<שם פונקציה>
   (התוכנה מזהה את השורה הזאת ומעתיקה לך בדיוק את מה שביקשת.)
2. אחרת — התשובה בסדר הזה:
   א. שורה ראשונה:  תיאור: <משפט אחד בעברית פשוטה>
   ב. פסקה אחת בעברית פשוטה (המשתמש לא מתכנת): מה השתנה ומה הוא יראה אחרי העדכון.
   ג. העדכון עצמו, בפורמט שמתואר למטה — עדיף «=== החלפה: … ===» (חפש והחלף) לכל שינוי בקובץ קיים.
3. שינוי מינימלי: רק מה שהבקשה צריכה. בלי לשכתב קוד שעובד, בלי שינויי שמות/עיצוב/סדר שלא התבקשו, בלי "שיפורים" נוספים.
4. הטקסט «לפני» — העתקה מדויקת מהקוד שלמטה (כולל הרווחים בתחילת השורה), בלי הכותרות [שורות …] ובלי מספרי שורות,
   ומספיק שורות כדי שיופיע בקובץ פעם אחת בלבד.
5. הכול בתוך ההודעה עצמה — לא artifact ולא קובץ מצורף (המשתמש מעתיק את ההודעה בכפתור ההעתקה שמתחתיה).
   לא לקצר ב-"..." או "שאר הקוד ללא שינוי".
6. טקסט שהמשתמש רואה — בעברית פשוטה. אל תבקש מפתחות, סיסמאות או config.env.
7. אחרי שהוא מדביק את התשובה, התוכנה מציגה לו מה ישתנה, שומרת מצב, מחילה, בודקת את עצמה (קומפילציה, שרת בדיקה,
   בדיקת איכות) — ואם משהו נשבר הכול חוזר לבד, והוא ידביק לך את היומן.
"""

END = """=== סוף הבקשה ===
עכשיו: או שורה אחת "צריך קבצים: …", או תיאור + פסקה בעברית + העדכון בפורמט (=== החלפה: … ===). הכול בתוך ההודעה."""


def block(mode, what, ctx=None, ticks=(), unticks=(), budget=DEFAULT_BUDGET):
    """הבלוק המלא לצ'אט. mode = bug | change. → {"text", "chars", "budget", "files": [...], "redacted"}"""
    ctx = ctx or {}
    files = tracked()
    ticks = [resolve(t, files) for t in ticks]
    ticks = [t for t in ticks if t]
    unticks = {u for u in (resolve(t, files) for t in unticks) if u}
    when = time.strftime("%Y-%m-%d %H:%M")
    head = ["=== בקשה ל-Claude: %s בתוכנה \"יצירת שורטס\" (נבנה בתוכנה, %s) ===" % (
        "תיקון באג" if mode == "bug" else "שינוי", when),
        "המשתמש לא מתכנת ועונים לו בעברית פשוטה. הבלוק הזה נבנה אוטומטית ומכיל את מה שצריך — כולל קוד.", "",
        "%s (במילים שלו):" % ("מה קרה" if mode == "bug" else "מה לשנות"), (what or "").strip() or "(לא כתב)", "",
        ASK, UPD.FORMAT_RULES, "=== המבנה של התוכנה (מתוך docs/HANDOFF.md) ===", architecture(), ""]
    if ctx.get("header"):
        head += ["=== גרסאות ==="] + list(ctx["header"]) + [""]
    if mode == "bug":
        j = ctx.get("job")
        if j:
            head += ["=== העבודה האחרונה שנכשלה ===",
                     "סוג: %s · %s · התחילה %s · %s" % (j.get("kind"), j.get("title"), j.get("started"), j.get("state", "נכשלה")),
                     "השגיאה: %s" % (j.get("error") or "—"), "היומן (שורות אחרונות):"] + list(j.get("log") or [])[-80:] + [""]
        else:
            head += ["=== העבודה האחרונה שנכשלה ===", "(אין עבודה שנכשלה מאז שהתוכנה נפתחה — הבאג כנראה בדף או בהתנהגות)", ""]
        if ctx.get("health"):
            head += ["=== בדיקת מערכת אחרונה ==="] + list(ctx["health"]) + [""]
        if ctx.get("selftest"):
            head += ["=== בדיקת האיכות האחרונה (make_short_selftest.py) ===", ctx["selftest"], ""]
        if ctx.get("app_log"):
            head += ["=== יומן החלון (שורות אחרונות) ==="] + list(ctx["app_log"])[-30:] + [""]
    if ctx.get("updates"):
        head += ["=== עדכונים אחרונים מהתיבה ==="] + list(ctx["updates"]) + [""]
    head += ["=== מפתח הקבצים (כל הקוד שבמחשב; אפשר לבקש כל אחד: \"צריך קבצים: …\") ===", file_index(files), ""]
    fixed = "\n".join(head)
    chosen, toks = choose(mode, what, ctx, files, ticks, unticks)
    files_text = {c["path"]: read(c["path"]) for c in chosen}
    left = budget - len(fixed) - len(END) - 400
    code, infos = pack(chosen, max(0, left), toks, files_text)
    summary = ["=== הקוד שנשלח (%d קבצים; השאר — במפתח למעלה) ===" % sum(1 for i in infos if i["chars"])]
    summary += ["  %s — %s (%s)" % (i["path"], i["how"], i["reason"]) for i in infos]
    text = fixed + "\n".join(summary) + "\n\n" + code + "\n" + END + "\n"
    text, red = guard(text)
    return {"text": text, "chars": len(text), "budget": budget, "files": infos, "redacted": red,
            "over": len(text) > budget, "tokens": toks}


def plan(mode, what, ctx=None, ticks=(), unticks=(), budget=DEFAULT_BUDGET):
    """לרשימה שבדף: מה ייכנס (בלי הטקסט עצמו) + כל הקבצים לסימון."""
    b = block(mode, what, ctx, ticks, unticks, budget)
    files = tracked()
    allf = [{"path": f, "chars": len(read(f)), "purpose": purpose(f)} for f in files]
    return {"chars": b["chars"], "budget": budget, "files": b["files"], "all": allf, "over": b["over"]}


def parse_items(items):
    """["path", "path:10-40", "path#name"] → {path: {"ranges": [...], "names": [...], "whole": bool}}, unknown"""
    files = tracked()
    want, unknown = {}, []
    for it in items:
        it = it.strip().strip("`'\"*")
        if not it:
            continue
        m = re.match(r"^(.+?)(?::(\d+)\s*[-–]\s*(\d+)|#([\w$]+))?$", it)
        path = resolve(m.group(1), files) if m else None
        if not path:
            unknown.append(it)
            continue
        w = want.setdefault(path, {"ranges": [], "names": [], "whole": False})
        if m.group(2):
            a, b = int(m.group(2)), int(m.group(3))
            w["ranges"].append((min(a, b), max(a, b)))
        elif m.group(4):
            w["names"].append(m.group(4))
        else:
            w["whole"] = True
    return want, unknown


def followup(items, budget=DEFAULT_BUDGET):
    """הצ'אט ענה "צריך קבצים: …" — בלוק המשך עם בדיוק מה שביקש."""
    want, unknown = parse_items(items)
    out = ["=== הקבצים שביקשת (נבנה בתוכנה, %s) ===" % time.strftime("%Y-%m-%d %H:%M")]
    if unknown:
        out.append("לא מצאתי בקוד: %s (אפשר לבחור מהמפתח שבהודעה הראשונה)" % ", ".join(unknown))
    left = budget - 2000
    infos = []
    for path, w in want.items():
        t = read(path)
        if w["whole"] and len(t) + 200 <= left:
            part = render_whole(path, t)
            how = "מלא"
        elif w["whole"] and not (w["ranges"] or w["names"]):
            secs = sections(path, t)
            allot = max(2000, min(left - 1000, 40000))
            part, shown = render_excerpt(path, t, allot, [], [], [], ranges=[(1, secs[0][1] if secs else 80)])
            part = part.replace("=== סוף קוד:", "(הקובץ גדול מדי לשלוח כולו — לבקש טווחי שורות או שמות פונקציות מהמפה)\n=== סוף קוד:", 1)
            how = "גדול מדי — ראש הקובץ + מפה"
        else:
            part, shown = render_excerpt(path, t, max(2000, left - 1000), [], [], [], ranges=w["ranges"], names=w["names"])
            how = "קטעים: " + ", ".join("%d–%d" % r for r in shown[:8])
        if len(part) > left:
            infos.append({"path": path, "how": "לא נכנס (התקציב נגמר)", "chars": 0})
            continue
        out.append(part)
        left -= len(part)
        infos.append({"path": path, "how": how, "chars": len(part)})
    out.append("=== עכשיו כתוב את העדכון לפי ההוראות שבהודעה הראשונה (או שוב \"צריך קבצים: …\" אם עדיין חסר) ===")
    text, red = guard("\n".join(out) + "\n")
    return {"text": text, "chars": len(text), "budget": budget, "files": infos, "unknown": unknown, "redacted": red}


def retry(check_result=None, log=None):
    """העדכון של הצ'אט לא עבר: שגיאות הבדיקה (+ האזור האמיתי בקובץ ליד כל «לפני» שלא נמצא), או יומן ההחלה שנכשלה."""
    out = ["=== העדכון שכתבת לא הוחל (נבנה בתוכנה, %s) ===" % time.strftime("%Y-%m-%d %H:%M")]
    if check_result is not None:
        out.append("התוכנה בדקה את העדכון לפני ההחלה ולא החילה כלום. הבעיות:")
        out += ["  - " + e for e in check_result.get("errors") or []]
        for m in check_result.get("misses") or []:
            t = read(m["path"])
            if m.get("line") and t:
                L = m["line"]
                lines = t.split("\n")
                a, b = max(1, L - 12), min(len(lines), L + 12)
                out.append("\nהקוד האמיתי ב-%s סביב שורה %d (העתק ממנו בדיוק):\n[שורות %d–%d]\n%s" % (
                    m["path"], L, a, b, "\n".join(lines[a - 1:b])))
        out.append("\nכתוב את העדכון כולו שוב (כל הבלוקים — שום דבר ממנו לא הוחל), בפורמט שבהודעה הראשונה.")
    else:
        out.append("העדכון הוחל, הבדיקה העצמית נכשלה, והתוכנה חזרה לבד בדיוק למצב שלפניו — כלומר כל העדכון בוטל.")
        out.append("היומן:")
        out += list(log or [])[-80:]
        out.append("\nתקן ושלח את העדכון כולו מחדש (לא רק את התיקון), בפורמט שבהודעה הראשונה. "
                   "צריך עוד קוד? ענה רק \"צריך קבצים: …\".")
    text, red = guard("\n".join(out) + "\n")
    return {"text": text, "chars": len(text), "redacted": red}


if __name__ == "__main__":
    a = sys.argv[1:]
    js = "--json" in a
    a = [x for x in a if x != "--json"]
    budget = DEFAULT_BUDGET
    if "--budget" in a:
        k = a.index("--budget")
        budget = int(a[k + 1])
        del a[k:k + 2]
    tk = []
    while "--tick" in a:
        k = a.index("--tick")
        tk.append(a[k + 1])
        del a[k:k + 2]
    if a[:1] == ["block"] and len(a) >= 3:
        r = block(a[1], a[2], {}, tk, (), budget)
    elif a[:1] == ["files"] and len(a) >= 2:
        r = followup(re.split(r"[,\s]+", a[1]), budget)
    else:
        sys.exit(__doc__)
    if js:
        print(json.dumps({k: v for k, v in r.items() if k != "text"}, ensure_ascii=False, indent=1))
    else:
        print(r["text"])
