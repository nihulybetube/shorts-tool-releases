# -*- coding: utf-8 -*-
"""
tool_finder.py — מציאה ובדיקה של הכלים החיצוניים שהפייפליין נשען עליהם (21/10/2026).

למה: מי שמקבל את הכלי כבר יכול להיות עם ffmpeg / yt-dlp / Deno מותקנים. הכלי לא צריך להוריד
עותק שני, אבל גם לא לסמוך עליו בעיוורון: ffmpeg של apt ב-Debian 5.1 **נכשל** על שרשרת הסינון
של הכלי (חסר vidstab / libass), וזה מתגלה באמצע רינדור. לכן לכל מועמד נעשית בדיקת תקינות אמיתית.

מודול בלי תלויות (stdlib בלבד) — נקרא גם מ-shorts.sh, מ-doctor.py וממסך ההגדרות.

העדפות המשתמש: ~/.config/yeshiva-shorts/tools.json
    {"ffmpeg": {"mode": "auto|builtin|custom", "path": "/..."}, "ffprobe": ..., "ytdlp": ..., "deno": ...}
    mode "auto"    = כמו תמיד (אין שינוי בהתנהגות הקיימת): המובנה קודם, ואם אין — מה שנמצא במחשב
    mode "builtin" = רק מה שהכלי התקין בעצמו
    mode "system"  = הראשון התקין שנמצא ב-PATH / במיקומים מוכרים
    mode "custom"  = נתיב שהמשתמש בחר
`apply()` כותב את ההעדפות ל-tools.env, ו-shorts.sh טוען אותו. אין tools.json → אין tools.env →
shorts.sh מתנהג בדיוק כמו קודם.
"""
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

CONFIG = Path(os.environ.get("SHORTS_CONFIG_DIR") or
              Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "yeshiva-shorts")
DATA = Path(os.environ.get("SHORTS_DATA_DIR") or
            Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "yeshiva-shorts")
PRIVBIN = DATA / "bin"
PREFS = CONFIG / "tools.json"
TOOLS_ENV = CONFIG / "tools.env"

MODES = ("auto", "builtin", "system", "custom")
KNOWN_DIRS = ["/usr/bin", "/usr/local/bin", "/opt/homebrew/bin", "/opt/local/bin", "/snap/bin",
              str(Path.home() / ".local" / "bin"), str(Path.home() / "bin"), "/home/linuxbrew/.linuxbrew/bin"]
NEED_FILTERS = ("vidstabdetect", "vidstabtransform", "xfade", "ass", "overlay")


def _run(cmd, timeout=20):
    try:
        r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, errors="replace",
                           timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, ValueError):
        return 127, ""
    except subprocess.TimeoutExpired:
        return 124, ""


def _exe(p):
    return bool(p) and os.path.isfile(p) and os.access(p, os.X_OK)


# ───────────────────────────── מערכת הרצה ─────────────────────────────
def runtime():
    """איפה הכלי רץ ומה אפשרי שם. הכלי כולו הוא סקריפטי bash + פייתון עם fcntl, ולכן:
    WSL / לינוקס / מק = נתמך; Windows ללא bash = לא נתמך (ראה HANDOFF §11)."""
    sysname = platform.system()
    wsl = False
    if sysname == "Linux":
        try:
            wsl = "microsoft" in Path("/proc/version").read_text().lower()
        except OSError:
            pass
    bash = shutil.which("bash")
    try:
        import fcntl  # noqa: F401
        has_fcntl = True
    except ImportError:
        has_fcntl = False
    if wsl:
        kind, ok = "WSL", True
        msg = "WSL (לינוקס בתוך Windows) — הדרך המלאה והמנוסה."
    elif sysname == "Linux":
        kind, ok = "Linux", True
        msg = "לינוקס רגיל — אמור לעבוד כמו ב-WSL. רק פתיחת החלון מ-Windows (מקש .bat) לא רלוונטית."
    elif sysname == "Darwin":
        kind, ok = "macOS", True
        msg = "מק — אמור לעבוד. ffmpeg דרך brew חייב לכלול vidstab ו-libass (ראה ההערה ב-install.sh)."
    elif sysname == "Windows":
        kind, ok = "Windows", False
        msg = ("Windows בלי WSL — לא נתמך: הכלי רץ דרך סקריפטי bash, נעילת fcntl ונתיבי venv של לינוקס. "
               "הפתרון: להתקין WSL (windows\\התקנה.bat עושה את זה).")
    else:
        kind, ok = sysname, False
        msg = "מערכת לא מוכרת — לא נבדק."
    return {"kind": kind, "ok": ok and bool(bash) and has_fcntl, "bash": bool(bash), "fcntl": has_fcntl,
            "python": platform.python_version(), "detail": msg}


# ───────────────────────────── ffmpeg / ffprobe ─────────────────────────────
def probe_ffmpeg(path):
    """בדיקת תקינות: רצה, ויש בה libass + libx264, ולבדיקה מלאה גם vidstab ופילטרים.
    מחזיר {ok, level (ok|warn|bad), version, issues[]}."""
    rc, out = _run([path, "-hide_banner", "-version"], 15)
    if rc:
        return {"ok": False, "level": "bad", "version": "", "issues": ["לא רץ"]}
    ver = (out.splitlines() or [""])[0]
    m = re.search(r"version\s+(\S+)", ver)
    version = m.group(1) if m else ver[:40]
    _, flt = _run([path, "-hide_banner", "-filters"], 15)
    names = set()
    for line in flt.splitlines():
        parts = line.split()
        if len(parts) >= 2 and re.match(r"^[A-Z.]{2,3}$", parts[0]):
            names.add(parts[1])
    issues, level = [], "ok"
    if "ass" not in names:
        issues.append("חסר libass — אין כתוביות בכלל")
        level = "bad"
    if "--enable-libx264" not in out:
        issues.append("חסר libx264 — אין קידוד וידאו")
        level = "bad"
    lost = [x for x in ("vidstabdetect", "vidstabtransform", "xfade", "overlay") if x not in names]
    if lost and level != "bad":
        issues.append("חסר: %s — הייצוב / המעברים יידלגו או ייכשלו" % ", ".join(lost))
        level = "warn"
    return {"ok": level != "bad", "level": level, "version": version, "issues": issues}


def probe_ffprobe(path):
    rc, out = _run([path, "-hide_banner", "-version"], 15)
    if rc:
        return {"ok": False, "level": "bad", "version": "", "issues": ["לא רץ"]}
    m = re.search(r"version\s+(\S+)", out)
    return {"ok": True, "level": "ok", "version": m.group(1) if m else "", "issues": []}


# ───────────────────────────── yt-dlp ─────────────────────────────
def probe_ytdlp(path):
    rc, out = _run(path if isinstance(path, list) else [path, "--version"], 30)
    ver = out.strip().splitlines()[-1] if rc == 0 and out.strip() else ""
    if not ver:
        return {"ok": False, "level": "bad", "version": "", "issues": ["לא רץ"]}
    issues, level = [], "ok"
    try:
        import time as _t
        age = (_t.time() - _t.mktime(_t.strptime(ver[:10], "%Y.%m.%d"))) / 86400
        if age > 90:
            issues.append("גרסה בת %d ימים — יוטיוב משנה דברים, כנראה צריך עדכון" % age)
            level = "warn"
    except ValueError:
        pass
    return {"ok": True, "level": level, "version": ver, "issues": issues}


# ───────────────────────────── Deno / Node ─────────────────────────────
def probe_deno(path):
    rc, out = _run([path, "--version"], 15)
    if rc:
        return {"ok": False, "level": "bad", "version": "", "issues": ["לא רץ"]}
    first = out.strip().splitlines()[0] if out.strip() else ""
    if os.path.basename(path).startswith("node"):
        return {"ok": True, "level": "warn", "version": first,
                "issues": ["זה Node ולא Deno — yt-dlp משתמש כברירת מחדל רק ב-Deno"]}
    return {"ok": True, "level": "ok", "version": first.replace("deno ", ""), "issues": []}


# ───────────────────────────── חיפוש מועמדים ─────────────────────────────
def _which_all(name):
    """כל ההתאמות ב-PATH (לא רק הראשונה) + מיקומים מוכרים, בלי כפילויות."""
    seen, out = set(), []
    dirs = [d for d in os.environ.get("PATH", "").split(os.pathsep) if d] + KNOWN_DIRS
    for d in dirs:
        p = os.path.join(d, name)
        try:
            rp = os.path.realpath(p)
        except OSError:
            continue
        if _exe(p) and rp not in seen:
            seen.add(rp)
            out.append(p)
    return out


def _source_of(path, builtin_paths):
    rp = os.path.realpath(path)
    if any(rp == os.path.realpath(b) for b in builtin_paths):
        return "builtin"
    return "system"


def _find(tool, name, builtin_paths, env_var, probe):
    seen, cands = set(), []

    def add(path, source):
        rp = os.path.realpath(path)
        if rp in seen or not _exe(path):
            return
        seen.add(rp)
        c = {"path": path, "source": source}
        c.update(probe(path))
        cands.append(c)

    for b in builtin_paths:
        add(b, "builtin")
    ev = os.environ.get(env_var, "")
    if ev:
        add(shutil.which(ev) or ev, "env")
    for p in _which_all(name):
        add(p, _source_of(p, builtin_paths))
    return cands


def find_ffmpeg():
    return _find("ffmpeg", "ffmpeg", [str(PRIVBIN / "ffmpeg")], "FFMPEG", probe_ffmpeg)


def find_ffprobe():
    return _find("ffprobe", "ffprobe", [str(PRIVBIN / "ffprobe")], "FFPROBE", probe_ffprobe)


def find_ytdlp():
    """builtin = ה-venv של הכלי. system = yt-dlp בנתיב (pipx / brew / apt / הורדה ידנית)."""
    cands, seen = [], set()
    venv_py = DATA / "venv" / "bin" / "python"
    if _exe(str(venv_py)):
        r = probe_ytdlp([str(venv_py), "-m", "yt_dlp", "--version"])
        cands.append(dict({"path": str(venv_py) + " -m yt_dlp", "source": "builtin"}, **r))
        seen.add(os.path.realpath(str(venv_py)))
    for p in _which_all("yt-dlp"):
        rp = os.path.realpath(p)
        if rp in seen or str(DATA / "venv") in p:
            continue
        seen.add(rp)
        cands.append(dict({"path": p, "source": "system"}, **probe_ytdlp(p)))
    return cands


def find_deno():
    cands, seen = [], set()
    builtin = [str(DATA / "deno" / "bin" / "deno"), str(Path.home() / ".deno" / "bin" / "deno")]
    for p in builtin:
        if _exe(p):
            seen.add(os.path.realpath(p))
            cands.append(dict({"path": p, "source": "builtin"}, **probe_deno(p)))
    for name in ("deno", "node"):
        for p in _which_all(name):
            rp = os.path.realpath(p)
            if rp in seen:
                continue
            seen.add(rp)
            cands.append(dict({"path": p, "source": "system"}, **probe_deno(p)))
    return cands


# ───────────────────────────── תמלול ─────────────────────────────
def find_asr():
    """מנועי תמלול: Modal (ענן) ו-faster-whisper (מקומי). הבחירה נשמרת ב-SHORTS_ASR ב-config.env."""
    venv_py = str(DATA / "venv" / "bin" / "python")
    py = venv_py if _exe(venv_py) else sys.executable
    out = []
    rc, txt = _run([py, "-c", "import modal,sys;print(getattr(modal,'__version__',''))"], 25)
    toml = Path(os.environ.get("MODAL_CONFIG_PATH") or Path.home() / ".modal.toml")
    cfg_env = _read_env_file(CONFIG / "config.env")
    toml2 = Path(cfg_env.get("MODAL_CONFIG_PATH", "")) if cfg_env.get("MODAL_CONFIG_PATH") else toml
    token = toml2.exists() or toml.exists() or bool(os.environ.get("MODAL_TOKEN_ID"))
    issues = []
    if rc:
        issues.append("הספרייה modal לא מותקנת")
    if not token:
        issues.append("אין טוקן Modal (modal token new)")
    out.append({"id": "modal", "name": "Modal (ענן, מהיר)", "version": txt.strip() if not rc else "",
                "ok": not issues, "level": "ok" if not issues else "warn", "issues": issues,
                "path": "ענן"})
    rc, txt = _run([py, "-c", "import faster_whisper as f;print(f.__version__)"], 40)
    gpu = bool(shutil.which("nvidia-smi")) and _run(["nvidia-smi", "-L"], 10)[0] == 0
    out.append({"id": "local", "name": "faster-whisper (על המחשב)" + (" · כרטיס מסך" if gpu else " · בלי כרטיס מסך (איטי)"),
                "version": txt.strip() if not rc else "", "ok": rc == 0,
                "level": "ok" if rc == 0 else "warn",
                "issues": [] if rc == 0 else ["faster-whisper לא מותקן"], "path": "מקומי"})
    return out


def _read_env_file(p):
    d = {}
    try:
        for line in Path(p).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                d[k.strip()] = v.strip().strip("'\"")
    except OSError:
        pass
    return d


# ───────────────────────────── העדפות ─────────────────────────────
FINDERS = {"ffmpeg": find_ffmpeg, "ffprobe": find_ffprobe, "ytdlp": find_ytdlp, "deno": find_deno}
PROBES = {"ffmpeg": probe_ffmpeg, "ffprobe": probe_ffprobe, "ytdlp": probe_ytdlp, "deno": probe_deno}
LABELS = {"ffmpeg": "ffmpeg (חיתוך, כתוביות, קידוד)", "ffprobe": "ffprobe (קריאת פרטי וידאו)",
          "ytdlp": "yt-dlp (הורדה מיוטיוב)", "deno": "Deno (פותר אתגר של יוטיוב)"}


def load_prefs():
    try:
        d = json.loads(PREFS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    return d if isinstance(d, dict) else {}


def effective(tool, cands, pref):
    """איזה מועמד בפועל ייבחר — חייב להתאים להיגיון של shorts.sh. mode=auto = ההתנהגות הקיימת:
    המובנה (אם קיים ורץ), אחרת הראשון התקין שנמצא."""
    mode = (pref or {}).get("mode", "auto")
    if mode == "custom":
        p = (pref or {}).get("path", "")
        if tool == "ytdlp":
            return {"path": p, "source": "custom", **probe_ytdlp(p)} if _exe(p) else None
        return {"path": p, "source": "custom", **PROBES[tool](p)} if _exe(p) else None
    order = {"builtin": ["builtin"], "system": ["system", "env"]}.get(mode, ["builtin", "env", "system"])
    for src in order:
        for c in cands:
            if c["source"] == src and c["ok"]:
                return c
    return None


def scan():
    """תמונת מצב מלאה למסך ההגדרות / doctor. לא כותבת כלום."""
    prefs = load_prefs()
    tools = []
    for t, fn in FINDERS.items():
        cands = fn()
        pref = prefs.get(t) or {"mode": "auto"}
        cur = effective(t, cands, pref)
        tools.append({"id": t, "label": LABELS[t], "mode": pref.get("mode", "auto"), "custom_path": pref.get("path", ""),
                      "candidates": cands, "current": cur,
                      "found_system": any(c["source"] == "system" and c["ok"] for c in cands),
                      "has_builtin": any(c["source"] == "builtin" for c in cands)})
    asr = find_asr()
    mode = _read_env_file(CONFIG / "config.env").get("SHORTS_ASR", "")
    return {"runtime": runtime(), "tools": tools, "asr": {"engines": asr, "selected": mode},
            "priority_note": "ברירת מחדל: כמו תמיד — מה שהכלי התקין, ואם אין — מה שנמצא במחשב"}


def set_pref(tool, mode, path=""):
    """שומר בחירה אחרי בדיקה. מחזיר {ok, msg}. לא מוחק ולא מחליף שום כלי."""
    if tool == "asr":
        if mode not in ("modal", "local"):
            return {"ok": False, "msg": "מנוע תמלול לא מוכר"}
        _write_env_key(CONFIG / "config.env", "SHORTS_ASR", mode)
        return {"ok": True, "msg": "מנוע התמלול עודכן"}
    if tool not in FINDERS or mode not in MODES:
        return {"ok": False, "msg": "בחירה לא מוכרת"}
    msg = ""
    if mode == "custom":
        path = os.path.expanduser((path or "").strip())
        if tool == "ytdlp" and path and not os.path.isabs(path):
            path = shutil.which(path) or path
        if not _exe(path):
            return {"ok": False, "msg": "הנתיב לא קיים או שאי אפשר להריץ אותו: %s" % path}
        pr = PROBES[tool](path)
        if not pr["ok"]:
            return {"ok": False, "msg": "הכלי הזה לא תקין לשימוש: " + "; ".join(pr["issues"])}
        if pr["issues"]:
            msg = "נשמר, עם הערה: " + "; ".join(pr["issues"])
    elif mode in ("builtin", "system"):
        cands = FINDERS[tool]()
        want = [c for c in cands if c["source"] in (("builtin",) if mode == "builtin" else ("system", "env")) and c["ok"]]
        if not want:
            return {"ok": False, "msg": ("הכלי לא התקין את הגרסה המובנית — אפשר להריץ install.sh" if mode == "builtin"
                                         else "לא נמצאה במחשב גרסה תקינה של הכלי הזה")}
    prefs = load_prefs()
    if mode == "auto":
        prefs.pop(tool, None)
    else:
        prefs[tool] = {"mode": mode, **({"path": path} if mode == "custom" else {})}
    CONFIG.mkdir(parents=True, exist_ok=True)
    PREFS.write_text(json.dumps(prefs, ensure_ascii=False, indent=1), encoding="utf-8")
    apply_prefs(prefs)
    return {"ok": True, "msg": msg or "נשמר"}


def _write_env_key(path, key, value):
    path = Path(path)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    done, out = False, []
    for ln in lines:
        if re.match(r"^\s*%s\s*=" % re.escape(key), ln):
            out.append("%s=%s" % (key, value))
            done = True
        else:
            out.append(ln)
    if not done:
        out.append("%s=%s" % (key, value))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def apply_prefs(prefs=None):
    """כותב tools.env לפי ההעדפות. אין העדפות → מוחק אותו (חזרה להתנהגות המקורית של shorts.sh)."""
    prefs = load_prefs() if prefs is None else prefs
    lines = ["# נוצר אוטומטית ע\"י tool_finder.py — לא לערוך ידנית (העדפות ב-tools.json)"]
    for tool, var in (("ffmpeg", "FFMPEG"), ("ffprobe", "FFPROBE")):
        p = prefs.get(tool)
        if p:
            path = _resolve(tool, p)
            if path:
                lines.append("export %s=%s" % (var, shlex.quote(path)))
    p = prefs.get("ytdlp")
    if p:
        path = _resolve("ytdlp", p)
        if path and path != "BUILTIN":
            lines.append("export SHORTS_YTDLP=%s" % shlex.quote(path))
        elif path == "BUILTIN":
            lines.append("export SHORTS_YTDLP=")
    p = prefs.get("deno")
    if p:
        path = _resolve("deno", p)
        if path:
            lines.append("export SHORTS_DENO=%s" % shlex.quote(path))
    if len(lines) == 1:
        try:
            TOOLS_ENV.unlink()
        except OSError:
            pass
        return
    CONFIG.mkdir(parents=True, exist_ok=True)
    TOOLS_ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")


def reload_env():
    """לשרת שכבר רץ: הילדים שלו יורשים FFMPEG/FFPROBE מהסביבה שלו, שנקבעה בהפעלה.
    אחרי שינוי בחירה מעדכנים אותה כאן (yt-dlp ו-Deno נקראים מחדש דרך shorts.sh בכל קריאה)."""
    prefs = load_prefs()
    for tool, var in (("ffmpeg", "FFMPEG"), ("ffprobe", "FFPROBE")):
        c = effective(tool, FINDERS[tool](), prefs.get(tool) or {"mode": "auto"})
        if c:
            os.environ[var] = c["path"]


def _resolve(tool, pref):
    mode = pref.get("mode", "auto")
    if mode == "custom":
        return pref.get("path")
    cands = FINDERS[tool]()
    c = effective(tool, cands, pref)
    if not c:
        return None
    if tool == "ytdlp":
        return "BUILTIN" if c["source"] == "builtin" else c["path"]
    return c["path"]


def summary_lines(s=None):
    """שורות טקסט פשוטות ל-doctor."""
    s = s or scan()
    out = []
    for t in s["tools"]:
        cur = t["current"]
        if not cur:
            out.append((t["id"], "bad", "%s: לא נמצא כלי תקין" % t["label"]))
            continue
        src = {"builtin": "מובנה", "system": "מהמחשב", "env": "ממשתנה סביבה", "custom": "נתיב שבחרת"}[cur["source"]]
        note = (" — " + "; ".join(cur["issues"])) if cur.get("issues") else ""
        out.append((t["id"], cur["level"], "%s: %s · %s · %s%s" % (t["label"], cur["version"] or "?", src, cur["path"], note)))
    return out


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["apply"]:
        apply_prefs()
        print("tools.env עודכן")
    elif a[:1] == ["set"] and len(a) >= 3:
        print(json.dumps(set_pref(a[1], a[2], a[3] if len(a) > 3 else ""), ensure_ascii=False))
    else:
        print(json.dumps(scan(), ensure_ascii=False, indent=1))
