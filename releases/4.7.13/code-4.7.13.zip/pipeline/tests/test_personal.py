# -*- coding: utf-8 -*-
"""בדיקות 4.5 — שינויים אישיים שורדים עדכונים רשמיים. הכול בתיקיות זמניות, בלי רשת, בלי לגעת בהגדרות האמיתיות.

הרצה:  python3 test_personal.py"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
T = Path(tempfile.mkdtemp(prefix="ys_pc_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg"), "SHORTS_DATA_DIR": str(T / "data"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_UPDATES": str(T / "data" / "updates.json"),
                   "MAKE_SHORT_UPDATE_NO_SELFTEST": "1"})
os.environ.pop("MAKE_SHORT_UPDATE_MODE", None)
sys.path.insert(0, str(SCRIPTS))
import make_short_release as R  # noqa: E402
import make_short_personal as PC  # noqa: E402
import make_short_update as UPD  # noqa: E402

FAIL = []


def chk(c, w, d=""):
    print(("✓ " if c else "✗ ") + w + ("" if c else "  — " + str(d)[:300]), flush=True)
    if not c:
        FAIL.append(w)


def sh(cwd, *a):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def gc(repo, msg):
    sh(repo, "git", "add", "-A")
    sh(repo, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", msg)


A_LINES = ["# a.py", ""] + ["def f%d():\n    return %d\n" % (i, i) for i in range(1, 31)] + ["", "TAIL = 'end'", ""]
A0 = "\n".join(A_LINES)
B0 = "B = 1\nX1 = 1\nX2 = 2\nX3 = 3\nX4 = 4\nC = 2\nY1 = 1\nY2 = 2\nY3 = 3\nY4 = 4\nZ = 9\n"


def a_with(**repl):
    t = A0
    for k, v in repl.items():
        t = t.replace(k, v)
    return t


def make_install(path):
    path.mkdir(parents=True)
    sh(path, "git", "init", "-q", "-b", "main")
    (path / "pipeline" / "scripts").mkdir(parents=True)
    (path / "VERSION").write_text("1.0.0\n")
    (path / "pipeline/scripts/a.py").write_text(A0, encoding="utf-8")
    (path / "pipeline/scripts/b.py").write_text(B0, encoding="utf-8")
    (path / ".from_package").write_text("1.0.0")
    with open(path / ".git" / "info" / "exclude", "a") as f:
        f.write(".from_package\n")
    gc(path, "1.0.0")
    sh(path, "git", "tag", "rel-1.0.0")
    return path


def release_tree(base, version, files):
    """עץ שחרור מזויף + מניפסט. files = כל קבצי הגרסה (path → text)."""
    tree = base / ("tree-" + version)
    shutil.rmtree(tree, ignore_errors=True)
    m = {"version": version, "files": {}}
    for p, txt in files.items():
        f = tree / p
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(txt, encoding="utf-8")
        m["files"][p] = {"sha256": hashlib.sha256(txt.encode("utf-8")).hexdigest(), "mode": 0o644}
    return tree, m


def official(repo, version, files, check=None):
    tree, m = release_tree(T, version, dict(files, VERSION=version + "\n"))
    return R.apply_release(tree, m, repo, T / "sd", check_fn=check, log=lambda s: None)


def box(repo, desc, edits):
    """שינוי מהתיבה בפורמט האמיתי (חפש והחלף). edits = [(path, old, new)]."""
    txt = "תיאור: %s\n" % desc
    for p, o, n in edits:
        txt += "=== החלפה: %s ===\n<<<<<<< לפני\n%s\n=======\n%s\n>>>>>>> אחרי\n=== סוף החלפה ===\n" % (p, o, n)
    UPD.REPO = repo
    UPD.selfcheck = lambda: True
    UPD.selftest_quick = lambda: True
    import io
    from contextlib import redirect_stdout
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = UPD.apply(txt)
    return rc, buf.getvalue()


def check_ok(repo):
    def fn():
        t = (repo / "pipeline/scripts/b.py").read_text(encoding="utf-8")
        return ("BREAK" not in t), "BREAK נמצא — נכשל"
    return fn


def reg_state(cid=None):
    reg = PC.load()
    if cid:
        return next(c["state"] for c in reg["changes"] if c["id"] == cid)
    return {c["id"]: c["state"] for c in reg["changes"]}


def fhash(repo, p):
    return hashlib.sha256((repo / p).read_bytes()).hexdigest()


# ═════════ 1. רישום משינוי מהתיבה ═════════
repo = make_install(T / "inst")
chk(PC.active(repo), "התקנה מחבילה (יש סימון) — המנגנון פעיל")
rc, out = box(repo, "הפונקציה f3 מחזירה 33", [("pipeline/scripts/a.py", "def f3():\n    return 3", "def f3():\n    return 33")])
chk(rc == 0, "שינוי מהתיבה הוחל", out)
reg = PC.load()
c1 = reg["changes"][0] if reg["changes"] else {}
chk(len(reg["changes"]) == 1 and c1.get("desc") == "הפונקציה f3 מחזירה 33" and c1.get("state") == "applied" and c1.get("base_version") == "1.0.0"
    and c1.get("files") == ["pipeline/scripts/a.py"], "נרשם שינוי אישי: שם מ«תיאור:», בסיס 1.0.0, קבצים, מצב פעיל", c1)
chk((T / "data/local_changes/personal/pc-0001/change.patch").read_bytes().count(b"+    return 33") == 1, "ה-patch נשמר מחוץ לעץ הקוד")
chk(sh(repo, "git", "rev-parse", "refs/personal/pc-0001") == c1.get("commit"), "commit-מצביע ב-refs/personal")
chk(not (repo / "registry.json").exists() and sh(repo, "git", "status", "--porcelain") == "", "הרישום לא בתוך עץ הקוד; העץ נקי")

rc, out = box(repo, "ערך B הופך ל-10", [("pipeline/scripts/b.py", "B = 1", "B = 10")])
chk(rc == 0 and list(reg_state()) == ["pc-0001", "pc-0002"], "שינוי שני נרשם אחרי הראשון (סדר)", out)

# ═════════ 2. עדכון רשמי + החלה מחדש נקייה ═════════
chk(UPD.hist_load()[-1]["status"] == "applied", "היסטוריית התיבה: מוחל")
off_a = a_with(**{"TAIL = 'end'": "TAIL = 'end'\nNEW_OFFICIAL = True"})
official(repo, "1.1.0", {"pipeline/scripts/a.py": off_a, "pipeline/scripts/b.py": B0})
chk("return 33" not in (repo / "pipeline/scripts/a.py").read_text(), "אחרי העדכון הרשמי לבדו הקוד רשמי נקי (השינוי האישי נדרס)")
res = PC.reapply(repo, check_ok(repo), log=lambda s: None)
chk(res and not res["error"] and [r["state"] for r in res["results"]] == ["applied", "applied"], "החלה מחדש נקייה על 1.1.0: שני השינויים ✅", res)
a_now = (repo / "pipeline/scripts/a.py").read_text()
chk("return 33" in a_now and "NEW_OFFICIAL" in a_now and "B = 10" in (repo / "pipeline/scripts/b.py").read_text(), "הקוד כולל גם את הרשמי החדש וגם את השינויים שלי")
chk(sh(repo, "git", "diff", "--name-only", "rel-1.1.0").splitlines() == ["pipeline/scripts/a.py", "pipeline/scripts/b.py"]
    and sh(repo, "git", "rev-parse", "rel-1.1.0^{commit}") != sh(repo, "git", "rev-parse", "HEAD"), "התגית הרשמית שלמה; השינויים מעליה ב-commit-ים")
chk(PC.load()["changes"][0]["base_version"] == "1.1.0" and PC.load()["changes"][0]["applied_version"] == "1.1.0", "גרסת בסיס/הוחל עודכנה ל-1.1.0")
chk(UPD.hist_load()[-1]["status"] == "folded", "«בטל עדכון אחרון» של התיבה לא יגע בשינויים ישנים אחרי עדכון רשמי")
chk(not (T / "data/local_changes/reapply_pending.json").exists(), "היומן נוקה")

# ═════════ 3. קונפליקט: הרשמי נשאר, השינוי נשמר שלם, הודעה ═════════
rc, out = box(repo, "f10 מחזירה 1010", [("pipeline/scripts/a.py", "def f10():\n    return 10", "def f10():\n    return 1010")])
chk(rc == 0, "שינוי שלישי (f10) הוחל", out)
c3 = PC.load()["changes"][2]["id"]
patch3 = (T / ("data/local_changes/personal/%s/change.patch" % c3)).read_bytes()
off2 = off_a.replace("def f10():\n    return 10", "def f10():\n    return 100  # official")
tree2, m2 = release_tree(T, "1.2.0", {"pipeline/scripts/a.py": off2, "pipeline/scripts/b.py": B0, "VERSION": "1.2.0\n"})
R.apply_release(tree2, m2, repo, T / "sd", check_fn=None, log=lambda s: None)
res = PC.reapply(repo, check_ok(repo), log=lambda s: None)
st = {r["id"]: r["state"] for r in res["results"]}
chk(st == {"pc-0001": "applied", "pc-0002": "applied", c3: "conflict"}, "קונפליקט רק בשינוי f10; האחרים נשארו ✅", st)
chk("return 100  # official" in (repo / "pipeline/scripts/a.py").read_text() and R.installed_version(repo) == "1.2.0",
    "הקוד הרשמי של 1.2.0 נשאר והעדכון לא נחסם")
chk((T / ("data/local_changes/personal/%s/change.patch" % c3)).read_bytes() == patch3 and sh(repo, "git", "rev-parse", "-q", "--verify", "refs/personal/" + c3),
    "ה-patch והמצביע של השינוי שלא התמזג נשארו שלמים")
msgs = PC.summary_he(res["results"])
chk(any("לא נכנס" in m and "f10" in m for m in msgs), "הודעה פשוטה בעברית על מה שלא נכנס", msgs)
chk(PC.status(repo)["attention"] == 1, "סטטוס: שינוי אחד צריך את המשתמש")

# ═════════ 4. הוחל אבל הבדיקה נכשלה → הוסר אוטומטית; שני שינויים, אחד נכשל ═════════
rc, out = box(repo, "שינוי שבור", [("pipeline/scripts/b.py", "C = 2", "C = 2  # BREAK")])
chk(rc == 0, "שינוי שבור הוחל בתיבה (הבדיקה הוזרמה כמדומה)", out)
cb = PC.load()["changes"][-1]["id"]
rc, out = box(repo, "שינוי תקין אחרי השבור", [("pipeline/scripts/a.py", "def f25():\n    return 25", "def f25():\n    return 250")])
cl = PC.load()["changes"][-1]["id"]
tree3, m3 = release_tree(T, "1.3.0", {"pipeline/scripts/a.py": off2, "pipeline/scripts/b.py": B0 + "D = 4\n", "VERSION": "1.3.0\n"})
R.apply_release(tree3, m3, repo, T / "sd", check_fn=None, log=lambda s: None)
res = PC.reapply(repo, check_ok(repo), log=lambda s: None)
st = {r["id"]: r["state"] for r in res["results"]}
chk(st.get(cb) == "incompatible" and st.get("pc-0001") == "applied" and st.get(cl) == "applied" and st.get(c3) == "conflict",
    "השבור → ⛔ לא תואם; השאר (גם זה שאחריו) ✅; הקונפליקט נשאר ⚠", st)
chk("BREAK" not in (repo / "pipeline/scripts/b.py").read_text() and "return 250" in (repo / "pipeline/scripts/a.py").read_text(),
    "השבור הוצא מהקוד (חזרה לתוצאה נקייה), התקין נשאר")
chk(PC.load()["changes"][-2]["reason"].startswith("BREAK"), "סיבת הכישלון נרשמה", PC.load()["changes"][-2])
chk((T / ("data/local_changes/personal/%s/change.patch" % cb)).read_bytes().count(b"BREAK") == 1, "השינוי השבור נשמר שלם ברישום")

# ═════════ 5. הפעלה / כיבוי ═════════
r = PC.set_enabled(repo, "pc-0002", False, check_ok(repo))
chk(r is None and reg_state("pc-0002") == "disabled" and "B = 10" not in (repo / "pipeline/scripts/b.py").read_text()
    and "return 33" in (repo / "pipeline/scripts/a.py").read_text(), "כיבוי שינוי אחד: יוצא מהקוד, האחרים נשארים")
r = PC.set_enabled(repo, "pc-0002", True, check_ok(repo))
chk(r and r["state"] == "applied" and "B = 10" in (repo / "pipeline/scripts/b.py").read_text(), "הפעלה חזרה: חוזר לקוד")
r = PC.set_enabled(repo, cb, True, check_ok(repo))
chk(r and r["state"] == "incompatible" and "BREAK" not in (repo / "pipeline/scripts/b.py").read_text(), "הפעלה של שבור: הבדיקה נכשלת והוא נשאר בחוץ")
(repo / "pipeline/scripts/a.py").write_text((repo / "pipeline/scripts/a.py").read_text() + "# מגע ידני\n")
PC.set_enabled(repo, "pc-0002", False, check_ok(repo))          # 4.5.x (C1): עריכה ידנית לא חוסמת ולא נמחקת — נרשמת
mc = [c for c in PC.load()["changes"] if c["kind"] == "manual"]
chk(mc and mc[-1]["state"] == "applied" and "# מגע ידני" in (repo / "pipeline/scripts/a.py").read_text() and reg_state("pc-0002") == "disabled",
    "עץ עם עריכה ידנית: העריכה נרשמת כשינוי אישי ונשארת, והכיבוי מתבצע")
PC.give_up(repo, mc[-1]["id"], check_ok(repo))
PC.set_enabled(repo, "pc-0002", True, check_ok(repo))
chk("# מגע ידני" not in (repo / "pipeline/scripts/a.py").read_text() and reg_state("pc-0002") == "applied"
    and sh(repo, "git", "status", "--porcelain") == "", "אפשר לוותר על העריכה הידנית כמו על כל שינוי")
before = PC.load()
try:
    PC.set_enabled(repo, "pc-9999", True, check_ok(repo))
    chk(False, "שינוי שלא קיים — נדחה")
except PC.PCError:
    pass
chk(PC.load()["changes"] == before["changes"], "כשל בהפעלה/כיבוי לא שינה את הרישום")

# ═════════ 6. ויתור ושחזור ═════════
PC.give_up(repo, "pc-0002", check_ok(repo))
chk(reg_state("pc-0002") == "archived" and "B = 10" not in (repo / "pipeline/scripts/b.py").read_text(), "ויתור: בארכיון ויוצא מהקוד")
chk((T / "data/local_changes/personal/pc-0002/change.patch").is_file(), "ה-patch של מה שוויתרתי עליו נשמר")
r = PC.restore(repo, "pc-0002", check_ok(repo))
chk(r and r["state"] == "applied", "שחזור מהארכיון")

# ═════════ 7. חזרה לגרסה הקודמת: הרישום שלם, המצב עקבי ═════════
ids_before = [c["id"] for c in PC.load()["changes"]]
rb = R.rollback_previous(repo, T / "sd", check_fn=None, personal_check=check_ok(repo))
chk(R.installed_version(repo) == "1.2.0", "חזרנו ל-1.2.0")
chk([c["id"] for c in PC.load()["changes"]] == ids_before, "אף רשומה לא אבדה בחזרה לגרסה קודמת")
chk(rb["personal"] and not rb["personal"]["error"], "השינויים הפעילים הוחלו מחדש על הגרסה הקודמת", rb.get("personal"))
chk("return 33" in (repo / "pipeline/scripts/a.py").read_text() and reg_state("pc-0001") == "applied" and reg_state(c3) == "conflict",
    "המצב עקבי: אותם שינויים פעילים, אותו קונפליקט")
chk(sh(repo, "git", "status", "--porcelain") == "", "העץ נקי אחרי החזרה")

# ═════════ 8. הפסקת חשמל באמצע ההחלה מחדש ═════════
repo2 = make_install(T / "inst2")
os.environ["SHORTS_DATA_DIR"] = str(T / "data2")
PC.DATA = Path(T / "data2")
for mod in (R, PC):
    mod.DATA = Path(T / "data2")
R.LOCAL_CHANGES = PC.ROOT = Path(T / "data2/local_changes")
PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
os.environ["MAKE_SHORT_UPDATES"] = str(T / "data2" / "updates.json")
box(repo2, "f5 מחזירה 55", [("pipeline/scripts/a.py", "def f5():\n    return 5", "def f5():\n    return 55")])
box(repo2, "C הופך ל-30", [("pipeline/scripts/b.py", "C = 2", "C = 30")])
official(repo2, "1.1.0", {"pipeline/scripts/a.py": off_a, "pipeline/scripts/b.py": B0})
official_head = sh(repo2, "git", "rev-parse", "HEAD")
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "pc_after_stack"
crashed = False
try:
    PC.reapply(repo2, check_ok(repo2), log=lambda s: None)
except R.SimulatedCrash:
    crashed = True
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
chk(crashed and PC.JOURNAL.exists() and sh(repo2, "git", "rev-parse", "HEAD") != official_head, "הפסקה אחרי הבנייה: היומן נשאר והעץ באמצע")
msg = PC.recover(repo2)
chk("נקטעה" in msg and sh(repo2, "git", "rev-parse", "HEAD") == official_head and not PC.JOURNAL.exists(), "התאוששות: חזרה למצב הרשמי השלם", msg)
chk(set(reg_state().values()) == {"waiting"}, "השינויים סומנו ממתינים (לא אבדו)", reg_state())
res = PC.retry_waiting(repo2, check_ok(repo2))
chk(set(reg_state().values()) == {"applied"} and "return 55" in (repo2 / "pipeline/scripts/a.py").read_text() and "C = 30" in (repo2 / "pipeline/scripts/b.py").read_text(),
    "ניסיון חוזר השלים את ההחלה", res)
# הפסקה לפני שהרישום נשמר — גם כן מתאוששת; ואחרי שהרישום נשמר אבל לפני ניקוי היומן — לא הופכים שוב
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "pc_before_clear"
try:
    PC.retry_waiting(repo2, check_ok(repo2))
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
top = sh(repo2, "git", "rev-parse", "HEAD")
PC.recover(repo2)
chk(sh(repo2, "git", "rev-parse", "HEAD") == top and not PC.JOURNAL.exists() and set(reg_state().values()) == {"applied"},
    "הפסקה אחרי שהרישום נשמר: ההתאוששות לא הופכת מצב שכבר שלם")

# ═════════ 9. הגירה של patch-ים ש-4.3 שמר ═════════
repo3 = make_install(T / "inst3")
os.environ["SHORTS_DATA_DIR"] = str(T / "data3")
for mod in (R, PC):
    mod.DATA = Path(T / "data3")
R.LOCAL_CHANGES = PC.ROOT = Path(T / "data3/local_changes")
PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
os.environ["MAKE_SHORT_UPDATES"] = str(T / "data3" / "updates.json")
(repo3 / "pipeline/scripts/a.py").write_text(A0.replace("return 7\n", "return 777\n"), encoding="utf-8")
(repo3 / "pipeline/scripts/extra.py").write_text("EXTRA = 1\n")                # קובץ חדש שלא ב-git
legacy_patch = subprocess.run(["git", "-C", str(repo3), "diff", "--binary", "rel-1.0.0", "--"], capture_output=True).stdout
sh(repo3, "git", "checkout", "--", "."); (repo3 / "pipeline/scripts/extra.py").unlink()
R.LOCAL_CHANGES.mkdir(parents=True)
(R.LOCAL_CHANGES / "20261101-120000_1.0.0_לפני_1.1.0.patch").write_bytes(legacy_patch)
(R.LOCAL_CHANGES / "20261101-120000_untracked/pipeline/scripts").mkdir(parents=True)
(R.LOCAL_CHANGES / "20261101-120000_untracked/pipeline/scripts/extra.py").write_text("EXTRA = 1\n")
(R.LOCAL_CHANGES / "20261101-130000_1.0.0_לפני_1.0.5.patch").write_bytes(b"")           # גיבוי ריק — לא נרשם
official(repo3, "1.1.0", {"pipeline/scripts/a.py": off_a, "pipeline/scripts/b.py": B0})
n = PC.migrate_legacy(repo3)
chk(n == 1 and len(PC.load()["changes"]) == 1 and PC.load()["changes"][0]["kind"] == "legacy" and PC.load()["changes"][0]["state"] == "waiting",
    "הגירה: patch ישן אחד נרשם כשינוי ממתין (הריק — לא)", PC.load())
chk(PC.migrate_legacy(repo3) == 0 and len(PC.load()["changes"]) == 1, "הגירה פעם אחת לכל קובץ")
res = PC.reapply(repo3, check_ok(repo3), log=lambda s: None)
chk(res["results"] and res["results"][0]["state"] == "applied" and "return 777" in (repo3 / "pipeline/scripts/a.py").read_text()
    and (repo3 / "pipeline/scripts/extra.py").read_text() == "EXTRA = 1\n", "patch של 4.3 (כולל קובץ חדש) הוחל מחדש על 1.1.0", res)

# עריכה ידנית שלא ב-commit נרשמת כשינוי אישי ושורדת עדכון
(repo3 / "pipeline/scripts/b.py").write_text(B0.replace("B = 1", "B = 111"), encoding="utf-8")
official(repo3, "1.2.0", {"pipeline/scripts/a.py": off_a, "pipeline/scripts/b.py": B0})
man = [c for c in PC.load()["changes"] if c["kind"] == "manual"]
chk(len(man) == 1 and man[0]["state"] == "waiting", "עריכה ידנית נרשמה לפני שהעדכון דרס אותה", PC.load()["changes"])
res = PC.reapply(repo3, check_ok(repo3), log=lambda s: None)
chk("B = 111" in (repo3 / "pipeline/scripts/b.py").read_text() and "return 777" in (repo3 / "pipeline/scripts/a.py").read_text(),
    "העריכה הידנית והשינוי הישן שניהם חזרו אחרי העדכון", res)

# ═════════ 10. כבר נכלל ברשמי ═════════
repo4 = make_install(T / "inst4")
os.environ["SHORTS_DATA_DIR"] = str(T / "data4")
for mod in (R, PC):
    mod.DATA = Path(T / "data4")
R.LOCAL_CHANGES = PC.ROOT = Path(T / "data4/local_changes")
PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
os.environ["MAKE_SHORT_UPDATES"] = str(T / "data4" / "updates.json")
box(repo4, "f4 מחזירה 44", [("pipeline/scripts/a.py", "def f4():\n    return 4", "def f4():\n    return 44")])
official(repo4, "1.1.0", {"pipeline/scripts/a.py": A0.replace("def f4():\n    return 4", "def f4():\n    return 44"), "pipeline/scripts/b.py": B0})
res = PC.reapply(repo4, check_ok(repo4), log=lambda s: None)
chk(res["results"] and res["results"][0]["state"] == "absorbed" and any("כבר כלול" in m for m in PC.summary_he(res["results"])),
    "המנהל אימץ את אותו שינוי: «כבר נכלל בגרסה הרשמית», בלי כפילות", res)
chk(sh(repo4, "git", "rev-parse", "HEAD") == sh(repo4, "git", "rev-parse", "rel-1.1.0"), "אין commit מיותר")

# ═════════ 11. עדכון מלא דרך run_updates עם שינוי שנכשל: העדכון לא נחסם ═════════
repo5 = make_install(T / "inst5")
os.environ["SHORTS_DATA_DIR"] = str(T / "data5")
for mod in (R, PC):
    mod.DATA = Path(T / "data5")
R.LOCAL_CHANGES = PC.ROOT = Path(T / "data5/local_changes")
R.STATE_DIR = Path(T / "data5/release_updates")
PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
os.environ["MAKE_SHORT_UPDATES"] = str(T / "data5" / "updates.json")
box(repo5, "f10 תשע", [("pipeline/scripts/a.py", "def f10():\n    return 10", "def f10():\n    return 9")])
box(repo5, "שבור", [("pipeline/scripts/b.py", "C = 2", "C = 2  # BREAK")])
box(repo5, "תקין", [("pipeline/scripts/a.py", "def f20():\n    return 20", "def f20():\n    return 21")])
trees = {}
for v, fl in (("1.1.0", {"pipeline/scripts/a.py": A0.replace("def f10():\n    return 10", "def f10():\n    return 0"), "pipeline/scripts/b.py": B0}),
              ("1.2.0", {"pipeline/scripts/a.py": A0.replace("def f10():\n    return 10", "def f10():\n    return 0"), "pipeline/scripts/b.py": B0 + "E = 5\n"})):
    trees[v] = release_tree(T, v, dict(fl, VERSION=v + "\n"))
R.source = lambda: ("http://x.invalid", [])
R.fetch_index = lambda base: [{"version": "1.1.0"}, {"version": "1.2.0"}]
R.fetch_release = lambda base, e, keys: (trees[e["version"]][1], b"")
R.download_release = lambda base, e, m, stage_root, progress=None: trees[e["version"]][0]
R.check_chain = lambda m, inst: None
prog = []
rr = R.run_updates(repo5, check_fn=None, log=lambda s: None, stage_root=T / "stage5", progress=prog.append, personal_check=check_ok(repo5))
chk(not rr["error"] and R.installed_version(repo5) == "1.2.0" and [a["version"] for a in rr["applied"]] == ["1.1.0", "1.2.0"],
    "עדכון רשמי בשני צעדים הושלם למרות שינויים אישיים בעייתיים", rr["error"])
pst = {r["desc"]: r["state"] for r in (rr["personal"] or {}).get("results", [])}
chk(pst == {"f10 תשע": "conflict", "שבור": "incompatible", "תקין": "applied"}, "תוצאה לכל שינוי: ⚠ / ⛔ / ✅", pst)
chk(any(p.get("stage") == "personal" and "2 מתוך 3" in p["label"] for p in prog), "בהתקדמות יש שלב «מחיל מחדש את השינויים האישיים שלך (2 מתוך 3)»")
chk([p["stage"] for p in prog if p["stage"] in ("applying", "personal")][-1] == "personal", "השלב האישי בא אחרי ההתקנה הרשמית")
chk("E = 5" in (repo5 / "pipeline/scripts/b.py").read_text() and "return 21" in (repo5 / "pipeline/scripts/a.py").read_text(), "הרשמי החדש + התקין שלי")

# ═════════ 12. עץ הבעלים — מחוץ למנגנון ═════════
os.environ["MAKE_SHORT_UPDATE_MODE"] = "owner"
before = json.dumps(PC.load(), sort_keys=True)
chk(PC.reapply(repo5, check_ok(repo5)) is None and PC.after_box(repo5, "x", "a", "b") is None and PC.capture_manual(repo5, "1", "2") is None
    and json.dumps(PC.load(), sort_keys=True) == before, "במצב בעלים: אין החלה, אין רישום, הרישום לא נגע")
os.environ.pop("MAKE_SHORT_UPDATE_MODE")

# ═════════ 13. בלוק למיזוג בצ'אט + התשובה מחליפה את הישן ═════════
cf = [c for c in PC.load()["changes"] if c["state"] == "conflict"][0]
blk = PC.merge_block(repo5, cf["id"])
tx = blk["text"]
chk("[מיזוג %s]" % cf["id"] in tx and "return 9" in tx and "return 0" in tx and "```diff" in tx and "=== החלפה:" in tx,
    "בלוק הצ'אט: מזהה למיזוג, השינוי שלי, הקוד הרשמי החדש, והוראות הפורמט")
(repo5 / "pipeline/scripts/config.env").write_text("GEMINI_API_KEY=SEKRET-VALUE-123\n")   # קובץ סוד לא במעקב בתוך העץ
blk2 = PC.merge_block(repo5, cf["id"])["text"]
chk("SEKRET-VALUE-123" not in blk2, "בלוק הצ'אט לא כולל את תוכן קובץ סוד שנמצא בעץ")
(repo5 / "pipeline/scripts/config.env").unlink()
rc, out = box(repo5, "f10 תשע [מיזוג %s]" % cf["id"], [("pipeline/scripts/a.py", "def f10():\n    return 0", "def f10():\n    return 9")])
newc = PC.load()["changes"][-1]
chk(rc == 0 and newc.get("replaces") == cf["id"] and reg_state(cf["id"]) == "archived" and "[מיזוג" not in newc["desc"] and newc["state"] == "applied",
    "התשובה בתיבה נרשמה כשינוי חדש על הגרסה החדשה והחליפה את הישן (בארכיון)", newc)

# ═════════ 14. ביטול בתיבה, הצעה למנהל, שינוי שם ═════════
rc, out = box(repo5, "עוד אחד", [("pipeline/scripts/a.py", "def f25():\n    return 25", "def f25():\n    return 26")])
lastc = PC.load()["changes"][-1]
UPD.undo.__globals__["selfcheck"] = lambda: True
import io
from contextlib import redirect_stdout
with redirect_stdout(io.StringIO()):
    UPD.undo()
chk(reg_state(lastc["id"]) == "disabled", "«בטל עדכון אחרון» בתיבה: השינוי נשאר ברשימה ככבוי")
d, pt, why = PC.proposal_payload(lastc["id"])
chk(d == "עוד אחד" and "return 26" in pt, "שינוי אישי אחד כחומר להצעה למנהל (4.4)")
PC.rename(lastc["id"], "שם חדש")
chk(PC.status(repo5)["changes"][-1]["desc"] == "שם חדש", "שינוי שם")

# ═════════ 16. 4.5.x — תיקוני הסקירה (C1–C9) ═════════
OK = lambda: (True, "")          # noqa: E731
R.source = lambda: ("", [])
B_ = lambda r: (r / "pipeline/scripts/b.py").read_text(encoding="utf-8")   # noqa: E731


def fresh(name):
    """רישום נפרד לכל התקנה מזויפת (כמו במחשב אמיתי — התקנה אחת, רישום אחד)."""
    R.LOCAL_CHANGES = PC.ROOT = Path(T / ("data_" + name) / "local_changes")
    PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
    return make_install(T / name)



# C1: עריכה ידנית + קובץ חדש לפני תיבת העדכון → שינוי אישי משלהם; בנייה מחדש לא מוחקת אותם; קובץ סוד לא נבלע ל-git
rc1 = fresh("c1")
(rc1 / "pipeline/scripts/b.py").write_text(B0.replace("Z = 9", "Z = 10"), encoding="utf-8")
(rc1 / "pipeline/scripts/mine.py").write_text("MINE = 1\n")
(rc1 / "pipeline/scripts/config.env").write_text("K=SEKRET\n")
rc, out = box(rc1, "שינוי בתיבה", [("pipeline/scripts/a.py", "def f3():\n    return 3", "def f3():\n    return 33")])
man = [c for c in PC.load()["changes"] if c["kind"] == "manual" and "pipeline/scripts/mine.py" in c["files"]]
chk(rc == 0 and man and man[0]["state"] == "applied" and "pipeline/scripts/b.py" in man[0]["files"],
    "C1: עריכה ידנית + קובץ חדש נרשמו כשינוי אישי לפני ה'צילום' של התיבה", out[-300:])
chk("pipeline/scripts/config.env" not in sh(rc1, "git", "ls-files"), "C1: קובץ סוד שלא במעקב לא נבלע ל-commit")
boxc = PC.load()["changes"][-1]
PC.set_enabled(rc1, boxc["id"], False, OK)
chk("Z = 10" in B_(rc1) and (rc1 / "pipeline/scripts/mine.py").exists() and "return 33" not in (rc1 / "pipeline/scripts/a.py").read_text(),
    "C1: כיבוי שינוי אחר (בנייה מחדש מהגרסה הרשמית) — העריכה הידנית והקובץ החדש נשארו")
# commit שנעשה ישירות (כמו ה'צילום' של 4.5.0) — נרשם בבנייה מחדש ולא נמחק
(rc1 / "pipeline/scripts/b.py").write_text(B_(rc1).replace("C = 2", "C = 3"), encoding="utf-8")
gc(rc1, "לפני עדכון: משהו (צילום ישן)")
PC.set_enabled(rc1, boxc["id"], True, OK)
chk("C = 3" in B_(rc1) and "return 33" in (rc1 / "pipeline/scripts/a.py").read_text()
    and any("לא היה רשום" in c["desc"] for c in PC.load()["changes"]), "C1: commit לא רשום נרשם ושרד בנייה מחדש")
# ועוד אחד — ואז עדכון רשמי: נרשם לפני שהעדכון דורס ומוחל מחדש אחריו
(rc1 / "pipeline/scripts/b.py").write_text(B_(rc1).replace("Y1 = 1", "Y1 = 7"), encoding="utf-8")
gc(rc1, "commit ישיר")
official(rc1, "1.1.0", {"pipeline/scripts/a.py": A0, "pipeline/scripts/b.py": "NEW = 1\n" + B0})
rr = PC.reapply(rc1, OK)
chk(not rr["error"] and "Y1 = 7" in B_(rc1) and "C = 3" in B_(rc1) and "Z = 10" in B_(rc1) and "NEW = 1" in B_(rc1),
    "C1: commits לא רשומים + עריכות ידניות שרדו עדכון רשמי (נרשמו לפני ההחלה)", rr)

# C2: החלה-מחדש שנכשלה אחרי עדכון — כל השינויים "ממתין" (לא "פעיל" כשהקוד רשמי)
_stack0 = PC._stack
PC._stack = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("נכשל באמצע"))
rr = PC.reapply(rc1, OK, kind="update")
PC._stack = _stack0
en = [c for c in PC.load()["changes"] if PC._enabled(c)]
chk(rr["error"] and en and all(c["state"] == "waiting" for c in en), "C2: כשל אחרי עדכון — אין שינוי שמסומן 'פעיל' בלי להיות בקוד",
    {c["id"]: c["state"] for c in en})
PC.retry_waiting(rc1, OK)

# C9: _stack — שינוי שהופך לריק בבדיקה אחד-אחד (אחרי שהקודם הוצא) → "נכלל", לא commit None
r9 = fresh("c9")
box(r9, "שבור עם X1", [("pipeline/scripts/b.py", "B = 1\nX1 = 1", "B = 1 # BREAK\nX1 = 1"), ("pipeline/scripts/b.py", "Y4 = 4", "Y4 = 44")])
box(r9, "מחזיר X1", [("pipeline/scripts/b.py", "Y4 = 44", "Y4 = 4")])
rr = PC.reapply(r9, check_ok(r9), kind="retry")
st9 = {r["desc"]: r["state"] for r in rr["results"]}
chk(not rr["error"] and st9 == {"שבור עם X1": "incompatible", "מחזיר X1": "absorbed"}, "C9: שינוי שנהיה ריק בבדיקה בנפרד — 'נכלל', בלי קריסה", rr)

# C6: הבדיקה נכשלת גם על הגרסה הרשמית לבד (בעיה בסביבה) → "ממתין", לא "לא תואם"
r6 = fresh("c6")
box(r6, "תקין 6", [("pipeline/scripts/b.py", "Y2 = 2", "Y2 = 22")])
rr = PC.reapply(r6, lambda: (False, "אין מקום בדיסק"), kind="retry")
chk(not rr["error"] and [r["state"] for r in rr["results"]] == ["waiting"] and "בסביבה" in rr["results"][0]["reason"],
    "C6: כשל של הבדיקה גם בלי השינויים — השינוי 'ממתין' ולא מסומן 'לא תואם'", rr)
# C6/C9: יומן של תהליך חי (גם אם ישן מ-20 דקות) לא נדרס; מספר תהליך שחזר אחרי אתחול — כן
PC._jwrite({"head_before": PC._head(r6), "base": PC.official_commit(r6), "ids": [], "kind": "toggle", "stamp": "s1"})
jd = json.loads(PC.JOURNAL.read_text())
jd["pid"], jd["ident"] = os.getppid(), R.proc_ident(os.getppid())
PC.JOURNAL.write_text(json.dumps(jd))
os.utime(PC.JOURNAL, (1, 1))
chk(PC.recover(r6) == "" and PC.JOURNAL.exists(), "C6: בדיקה ארוכה (יומן ישן) של תהליך חי — ההתאוששות לא נוגעת")
jd["ident"] = "other-boot:1"
PC.JOURNAL.write_text(json.dumps(jd))
chk(PC.recover(r6) and not PC.JOURNAL.exists(), "C9: אותו מספר תהליך מאתחול אחר — מתאוששים")

# C3: "כבר נכלל" חוזר אחרי חזרה לגרסה שאין בה את השינוי
r3 = fresh("c3")
box(r3, "X3 שלי", [("pipeline/scripts/b.py", "X3 = 3", "X3 = 33")])
official(r3, "1.1.0", {"pipeline/scripts/a.py": A0, "pipeline/scripts/b.py": B0.replace("X3 = 3", "X3 = 33")})
rr = PC.reapply(r3, OK)
chk([r["state"] for r in rr["results"]] == ["absorbed"], "C3: אחרי עדכון שכולל את השינוי — 'נכלל'", rr)
rb = R.rollback_previous(r3, sd=T / "sd3", personal_check=OK)
chk(R.installed_version(r3) == "1.0.0" and "X3 = 33" in B_(r3) and [r["state"] for r in rb["personal"]["results"]] == ["applied"],
    "C3: אחרי חזרה לגרסה שאין בה את השינוי — הוא הוחל שוב", rb.get("personal"))

# C4: index.lock שנשאר מ-git שמת לא חוסם בנייה מחדש; וכשההחזרה נכשלת — היומן נשאר (לא 'נשכח')
(r3 / ".git" / "index.lock").write_text("")
cid3 = PC.load()["changes"][-1]["id"]
PC.set_enabled(r3, cid3, False, OK)
chk(reg_state(cid3) == "disabled" and "X3 = 3\n" in B_(r3) and not (r3 / ".git/index.lock").exists(), "C4: index.lock ישן הוסר והבנייה מחדש הצליחה")
_hr0 = R.hard_reset
PC._stack = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("קריסה"))
R.hard_reset = lambda repo, rev: (_ for _ in ()).throw(R.UpdateError("git נכשל"))
try:
    PC.set_enabled(r3, cid3, True, OK)
    chk(False, "C4: כשל כפול מחזיר שגיאה")
except PC.PCError as e:
    chk("גם החזרת הקוד נכשלה" in str(e) and PC.JOURNAL.exists(), "C4: החזרה שנכשלה — שגיאה ברורה והיומן נשאר להפעלה הבאה", str(e))
finally:
    PC._stack, R.hard_reset = _stack0, _hr0
jd = json.loads(PC.JOURNAL.read_text())
jd["pid"] = 999999
PC.JOURNAL.write_text(json.dumps(jd))
chk(PC.recover(r3) and not PC.JOURNAL.exists() and reg_state(cid3) == "disabled", "C4: בהפעלה הבאה ההתאוששות משלימה")

# C8: אחרי כל בנייה מחדש — היסטוריית התיבה "מקופלת" (בטל עדכון אחרון לא יחזיר commit שכבר לא קיים)
hp = Path(os.environ["MAKE_SHORT_UPDATES"])
hp.write_text(json.dumps([{"desc": "x", "commit": "0" * 40, "status": "applied"}]))
PC.set_enabled(r3, cid3, True, OK)
chk(json.loads(hp.read_text())[0]["status"] == "folded", "C8: אחרי הפעלה/כיבוי — היסטוריית התיבה מקופלת")

# C7: התקנה מחדש מחבילה מעל התקנה קיימת → שינוי 'פעיל' שלא בקוד → ממתין, ותגית rel לגרסה
r7 = fresh("c7")
box(r7, "שלי 7", [("pipeline/scripts/b.py", "Y3 = 3", "Y3 = 33")])
for f in ("pipeline/scripts/a.py", "pipeline/scripts/b.py"):          # ההתקנה מחדש: הקוד מוחלף בקוד הרשמי, commit חדש
    (r7 / f).write_text({"pipeline/scripts/a.py": A0, "pipeline/scripts/b.py": B0}[f], encoding="utf-8")
gc(r7, "התקנה מחבילת שיתוף")
sh(r7, "git", "tag", "-d", "rel-1.0.0")
n7 = PC.startup_consistency(r7)
c7 = PC.load()["changes"][-1]
chk(n7 == 1 and c7["state"] == "waiting" and PC.official_commit(r7) == PC._head(r7), "C7: אחרי התקנה מחדש — תגית rel לגרסה והשינוי 'ממתין'")
PC.retry_waiting(r7, OK)
chk("Y3 = 33" in B_(r7) and reg_state(c7["id"]) == "applied", "C7: והוא מוחל שוב על הקוד שהותקן")
ins = (HERE.parent.parent / "windows/install_windows.ps1").read_text(encoding="utf-8")
chk('tag -f "rel-$V"' in ins and "register-manual" in ins, "C7: המתקין מסמן rel-X ורושם עריכות ידניות לפני ההחלפה")

# C9: קישורים סימבוליים — לא מעתיקים דרכם (סוד מחוץ לריפו)
outside = T / "outside_secret.txt"
outside.write_text("TOP-SECRET-OUTSIDE\n")
r9b = fresh("c9b")
os.symlink(outside, r9b / "pipeline/scripts/link.py")
os.symlink(T, r9b / "pipeline/linkdir")
c9 = PC.register_manual(r9b, "בדיקה")
blob = b"".join(p.read_bytes() for p in PC.PDIR.rglob("*") if p.is_file() and not p.is_symlink())
chk(c9 is None and b"TOP-SECRET-OUTSIDE" not in blob and not PC._no_symlink(r9b, "pipeline/linkdir/x.py"),
    "C9: קישור סימבולי (קובץ או תיקייה) לא נרשם ולא מועתק")
tr9 = T / "stage9"
(tr9 / "pipeline/scripts").mkdir(parents=True)
(tr9 / "pipeline/scripts/link.py").write_text("x")
c9m = PC.capture_manual(r9b, "1.0.0", "1.1.0", tr9)
chk(c9m is None and b"TOP-SECRET-OUTSIDE" not in b"".join(p.read_bytes() for p in PC.PDIR.rglob("*") if p.is_file() and not p.is_symlink()),
    "C9: גם capture_manual לפני עדכון לא עוקב אחרי קישור")

# C9: default_check — שינוי שנוגע במנגנון הבדיקה לא מאשר את עצמו (הבדיקה רצה מהעותק הרשמי של קבצי הבדיקה)
rD = fresh("cd")
STUB = ("import sys, pathlib\nb = (pathlib.Path(__file__).resolve().parent / 'b.py').read_text()\n"
        "sys.exit(1 if 'BAD' in b else 0)\n")
(rD / "pipeline/scripts/make_short_update.py").write_text(STUB)
gc(rD, "בדיקה")
sh(rD, "git", "tag", "-f", "rel-1.0.0")
(rD / "pipeline/scripts/b.py").write_text(B0 + "BAD = 1\n")
gc(rD, "שינוי שובר")
chk(PC.default_check(rD)[0] is False, "C9: default_check מזהה שינוי שובר (בסיס הבדיקה)")
(rD / "pipeline/scripts/make_short_update.py").write_text("import sys\nsys.exit(0)\n")       # "מאשר את עצמו"
gc(rD, "שינוי שמשתיק את הבדיקה")
chk(PC.touches_checks(["pipeline/scripts/make_short_update.py", "x.py"]) == ["pipeline/scripts/make_short_update.py"]
    and PC.default_check(rD)[0] is False, "C9: שינוי שמשתיק את הבדיקה עצמה — עדיין נכשל (בדיקה מהעותק הרשמי)")
(rD / "pipeline/scripts/b.py").write_text(B0)
gc(rD, "תיקון")
chk(PC.default_check(rD)[0] is True, "C9: שינוי תקין עובר את הבדיקה")

# C5: קובץ רשימה פגום — לא "ריק": גיבוי, סירוב לשמור, ומספור לא דורס pc-* קיים
R.LOCAL_CHANGES = PC.ROOT = Path(T / "data_c3" / "local_changes")          # הרישום של ההתקנה c3 (יש בו שינויים)
PC.REG, PC.PDIR, PC.JOURNAL = PC.ROOT / "registry.json", PC.ROOT / "personal", PC.ROOT / "reapply_pending.json"
good_raw = PC.REG.read_bytes()
PC.REG.write_bytes(b"{not json")
lr = PC.load()
chk(lr.get("_corrupt") and Path(lr["_corrupt"]).read_bytes() == b"{not json", "C5: רשימה פגומה מגובה ומסומנת")
try:
    PC.set_enabled(r3, cid3, False, OK)
    chk(False, "C5: פעולה על רשימה פגומה נדחית")
except PC.PCError as e:
    chk("פגום" in str(e) and PC.REG.read_bytes() == b"{not json", "C5: פעולה על רשימה פגומה נדחית והקובץ לא נדרס", str(e))
rr = PC.reapply(r3, OK)
chk(rr["error"] and "פגום" in rr["error"] and PC.REG.read_bytes() == b"{not json", "C5: גם החלה-מחדש אחרי עדכון לא דורסת")
PC.REG.write_text(json.dumps({"v": 1, "seq": 0, "changes": [], "seen": []}))
maxd = max(int(d.name[3:]) for d in PC.PDIR.iterdir() if d.name.startswith("pc-"))
rS = make_install(T / "cseq")
(rS / "pipeline/scripts/b.py").write_text(B0.replace("Y4 = 4", "Y4 = 44"))
cS = PC.register_manual(rS, "בדיקה")
chk(cS and int(cS["id"][3:]) == maxd + 1, "C5: המספר הבא גבוה מכל pc-* קיים (לא דורס patch של שינוי ישן)", cS and cS["id"])
PC.REG.write_bytes(good_raw)

# ═════════ 15. סריקות זהות וסודות על המודול החדש ═════════
src = (SCRIPTS / "make_short_personal.py").read_text(encoding="utf-8")
own = ["nihuly" + "betube", "ita" + "i4", "gmail"]
chk(not any(o in src.lower() or o in (HERE / "test_personal.py").read_text(encoding="utf-8").lower().replace("\"gmail\"", "") for o in own[:2]),
    "אין זהות של הבעלים בקוד/בבדיקות")
import re
chk(not re.search(r"(?i)\b(token|secret|password)\s*=", src) and "BEGIN PRIVATE" not in src, "אין מילות סוד בקוד החדש")

print("\n%s: %d נכשלו" % ("נכשל" if FAIL else "הכול עבר", len(FAIL)))
shutil.rmtree(T, ignore_errors=True)
sys.exit(1 if FAIL else 0)
