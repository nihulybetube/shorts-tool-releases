# -*- coding: utf-8 -*-
"""בדיקה: כרטיס 23 (31/10/2026) — צבעים פעיל/מושבת, "✓ הועלה" מ"שיעורים קודמים" ומחלון הניקוי, וניקוי ברקע.
שרת אמיתי על פורט פנוי, בתיקייה זמנית; "סל המיחזור" = תיקייה מקומית (MAKE_SHORT_FAKE_BIN). בלי רשת ובלי וידאו.
  1. הגדרה ישנה (random_off + marker_off) → colors_off; מושבת לא באקראי; שלוש הרשימות נפרדות.
  2. /api/past — לכל שיעור השורטס שלו (נשמר / הועלה).
  3. "סמן שכל השיעור הועלה" (only_saved) — מסמן את מה שנשמר, מחזיר את מה שלא; בטל סימון; קליף לא קיים — נדחה.
  4. תוכנית הניקוי מחזירה mark_items (רק שמורים שלא סומנו); סימון items → אין "לא סומן".
  5. ניקוי: מופיע ב-queue.cleans בזמן הריצה ואחריה (ok), ✕ מסיר; סימון בזמן ניקוי — נדחה.
הרצה: python3 pipeline/tests/test_card23.py"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
fails = []


def check(cond, msg, extra=""):
    print(("  ✓ " if cond else "  ✗ ") + msg + (("  ← " + str(extra)) if (extra and not cond) else ""), flush=True)
    if not cond:
        fails.append(msg)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def call(port, path, body=None):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path),
                                 data=None if body is None else json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "Origin": "http://127.0.0.1:%d" % port})
    try:
        return json.loads(urllib.request.urlopen(req, timeout=15).read().decode())
    except urllib.error.HTTPError as e:
        return json.loads(e.read().decode() or "{}")


def w(p, size=1000):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b"x" * size)


def lesson(T, name, clips, saved):
    P = T / "projects" / "תוכנה" / name
    w(P / "source" / "full_video.mp4", 50000)
    st = {"video_title": "שיעור " + name, "rabbi": "הרב בדיקה", "series": "סדרה", "finished": "x", "clips": [],
          "saved": {"at": "x", "snap": {}, "clips": list(saved)}, "export_dirs": {}, "export_layout": "short",
          "export_target": str(T / "Shorts" / "הרב בדיקה" / "סדרה")}
    for n in clips:
        st["clips"].append({"name": n, "title": "כותרת " + n, "edit": "לעריכה/%s.txt" % n, "seconds": 30})
        w(P / "לעריכה" / ("%s.txt" % n), 100)
        w(P / "work" / "clips" / ("%s_clean.mp4" % n), 2000)
        w(P / "shorts" / ("%s_כותרת" % n) / "v.mp4", 3000)
        if n in saved:
            d = T / "Shorts" / "הרב בדיקה" / "סדרה" / ("כותרת %s %s" % (name, n))
            w(d / "כותרת.mp4", 5000)
            st["export_dirs"][n] = str(d)
    json.dump(st, open(P / "make_short.json", "w", encoding="utf-8"), ensure_ascii=False)
    return P


def main():
    T = Path(tempfile.mkdtemp(prefix="ys23_t_"))
    (T / "settings.json").write_text(json.dumps({"values": {
        "random_off": ["1AC8A8", "FLOAT"], "marker_off": ["10206E"]}}), encoding="utf-8")
    A = lesson(T, "2026-10-30_auto-TESTa", ["clip1", "clip2"], ["clip1"])      # clip2 לא נשמר
    B = lesson(T, "2026-10-30_auto-TESTb", ["clip1"], ["clip1"])
    port = free_port()
    env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_SETTINGS=str(T / "settings.json"),
               MAKE_SHORT_IDLE_EXIT="0", SHORTS_PROJECTS=str(T / "projects"), MAKE_SHORT_QUEUE=str(T / "queue.json"),
               MAKE_SHORT_TEST_EXPORT=str(T / "Shorts"), MAKE_SHORT_FAKE_BIN=str(T / "bin"),
               SHORTS_EXPORT_LEDGER=str(T / "exports.jsonl"), SHORTS_DATA_DIR=str(T / "data"), GEMINI_API_KEY="",
               MAKE_SHORT_NO_SHARE_CHECK="1", MAKE_SHORT_NO_MODAL_METER="1", PYTHONUNBUFFERED="1")
    srv = subprocess.Popen([sys.executable, "-u", str(SCRIPTS / "make_short_app.py")], env=env, cwd=str(T),
                           stdout=open(T / "server.log", "w"), stderr=subprocess.STDOUT)
    try:
        for _ in range(80):
            try:
                call(port, "/api/home")
                break
            except OSError:
                time.sleep(0.3)

        print("1. צבעים: ישן → מושבת, רשימות נפרדות")
        s = call(port, "/api/settings")
        v = s.get("values") or {}
        check(set(v.get("colors_off") or []) == {"1AC8A8", "FLOAT", "MARKER:10206E"}, "random_off + marker_off → colors_off",
              v.get("colors_off"))
        check("random_off" not in v and "marker_off" not in v, "המפתחות הישנים לא מוצגים יותר")
        sl = s.get("style_lists") or {}
        check(sorted(sl) == ["float", "karaoke", "marker"] and "PLAIN" in sl["karaoke"] and "FLOAT" in sl["float"]
              and all(x.startswith("MARKER:") for x in sl["marker"]), "שלוש רשימות נפרדות לדף")
        s2 = call(port, "/api/settings", {"colors_off": ["marker:74202c", "FF7A00", "bad"], "custom_colors": ["FF7A00"]})
        check((s2.get("values") or {}).get("colors_off") == ["MARKER:74202C", "FF7A00"], "שמירת מושבתים נקייה",
              (s2.get("values") or {}).get("colors_off"))
        sys.path.insert(0, str(SCRIPTS))
        os.environ["MAKE_SHORT_SETTINGS"] = str(T / "settings.json")
        import make_short_settings as SET
        g = SET.random_groups(SET.load())
        check("MARKER:74202C" not in g["marker"] and "FF7A00" not in g["karaoke"] and "1AC8A8" in g["karaoke"],
              "מושבת לא באקראי, ומה שהוחזר — כן")

        print("2. /api/past מחזיר את השורטס")
        past = {x["project"]: x for x in call(port, "/api/past")["lessons"]}
        ca = (past.get(str(A)) or {}).get("clips") or []
        check([(c["name"], c["saved"], bool(c["uploaded"])) for c in ca] == [("clip1", True, False), ("clip2", False, False)],
              "שיעור A: clip1 נשמר, clip2 לא", ca)

        print("3. סימון \"הועלה\" לכל השיעור")
        r = call(port, "/api/uploaded", {"project": str(A), "on": True, "only_saved": True})
        check(bool(r.get("ok")) and len(r.get("skipped") or []) == 1 and "clip2" in r["skipped"][0],
              "clip1 סומן, clip2 חזר כ\"לא נשמר\"", r)
        ca = {c["name"]: c for c in {x["project"]: x for x in call(port, "/api/past")["lessons"]}[str(A)]["clips"]}
        check(bool(ca["clip1"]["uploaded"]) and not ca["clip2"]["uploaded"], "המצב נשמר")
        r = call(port, "/api/uploaded", {"project": str(A), "on": False, "only_saved": True})
        ca = {c["name"]: c for c in {x["project"]: x for x in call(port, "/api/past")["lessons"]}[str(A)]["clips"]}
        check(r.get("ok") and not ca["clip1"]["uploaded"], "בטל סימון לכל השיעור")
        r = call(port, "/api/uploaded", {"project": str(A), "clip": "clip9", "on": True})
        check(not r.get("ok"), "קליף שלא קיים — נדחה", r)
        r = call(port, "/api/uploaded", {"project": str(B), "clip": "clip1", "on": True})
        past = {x["project"]: x for x in call(port, "/api/past")["lessons"]}
        # (הצבע הסגול דורש טיוטה אמיתית ש"נשמרה" — בבדיקה הזאת אין וידאו; כאן רק שהסימון נרשם)
        check(r.get("ok") and bool(past[str(B)]["clips"][0]["uploaded"]), "שורט יחיד מסומן מ\"שיעורים קודמים\"", r)
        call(port, "/api/uploaded", {"project": str(B), "clip": "clip1", "on": False})

        print("4. חלון הניקוי: mark_items")
        pl = call(port, "/api/clean/plan", {"items": [{"project": str(B)}]})
        check(pl.get("mark_items") == [{"project": str(B), "clip": "clip1"}] and len(pl.get("not_uploaded") or []) == 1,
              "שורט שמור שלא סומן — מוצע לסימון", pl.get("mark_items"))
        r = call(port, "/api/uploaded", {"items": pl["mark_items"], "on": True})
        pl2 = call(port, "/api/clean/plan", {"items": [{"project": str(B)}]})
        check(r.get("ok") and not pl2.get("not_uploaded") and not pl2.get("mark_items"), "אחרי \"סמן\" — אין מה לאשר")

        print("5. ניקוי ברקע ברשימת התור")
        r = call(port, "/api/clean/run", {"items": [{"project": str(B)}]})
        jid = r.get("job")
        check(bool(jid), "הניקוי התחיל", r)
        seen_run, done = False, None
        rr = call(port, "/api/uploaded", {"project": str(B), "clip": "clip1", "on": False})
        lock_refused = not rr.get("ok")
        t0 = time.time()
        while time.time() - t0 < 30:
            cs = [c for c in call(port, "/api/lessons")["queue"].get("cleans", []) if c["job"] == jid]
            if cs and cs[0]["running"]:
                seen_run = True
            if cs and not cs[0]["running"]:
                done = cs[0]
                break
            time.sleep(0.2)
        check(seen_run or lock_refused, "נראה \"רץ\" בחלונית התור (או ננעל לסימון מיד)")
        check(bool(done) and done["ok"] is True and done["total"] >= 1 and done["done"] == done["total"],
              "נגמר בהצלחה — עם שלבים", done)
        check(not B.exists() and any((T / "bin").rglob("*")), "השיעור עבר ל\"סל\" (המדומה)")
        call(port, "/api/clean/dismiss", {"job": jid})
        cs = [c for c in call(port, "/api/lessons")["queue"].get("cleans", []) if c["job"] == jid]
        check(not cs, "✕ מסיר מהרשימה")
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except subprocess.TimeoutExpired:
            srv.kill()
    if fails:
        print("\nתיקיית הבדיקה (נשארה לבדיקה): %s" % T)
        print("❌ %d נכשלו" % len(fails))
        sys.exit(1)
    if T.name.startswith("ys23_t_") and T.parent == Path(tempfile.gettempdir()):
        shutil.rmtree(T)                       # רק התיקייה הזמנית שהבדיקה עצמה יצרה
    print("✅ הכול עבר")


if __name__ == "__main__":
    main()
