# -*- coding: utf-8 -*-
"""בדיקות 4.4 — הצעות למנהל דרך ntfy: בנייה וניקוי, תצוגה מקדימה = מה שנשלח, אישור, תור ושליחה חוזרת, תשובות חתומות,
קלט עוין, מכסות, ארגז חול ל-patch, סיבוב נושאים, חשיפת בעלים. בלי רשת אמיתית (שרת ntfy מזויף מקומי, 127.0.0.1).

הרצה:  python3 test_proposals.py   — תיקיות זמניות בלבד; לא נוגע בהגדרות האמיתיות."""
import base64
import getpass
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
T = Path(tempfile.mkdtemp(prefix="ys_prop_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg0"), "SHORTS_DATA_DIR": str(T / "data0"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_UPDATE_NO_SELFTEST": "1"})
os.environ.pop("MAKE_SHORT_PUBLISH_SCREEN", None)
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(HERE))
import make_short_proposals as P  # noqa: E402
from fake_ntfy import Fake  # noqa: E402

OUT = []


def chk(c, w, d=""):
    OUT.append((bool(c), w, d))
    print(("✓ " if c else "✗ ") + w + ("" if c else "  — " + str(d)[:300]), flush=True)


def raises(fn, *a, **k):
    try:
        fn(*a, **k)
    except P.ProposalError as e:
        return str(e) or "x"
    return ""


def sh(cwd, *a):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def as_(who):
    P._set_dirs(T / ("cfg_" + who), T / ("data_" + who), T / ("repo_" + who))
    if who == "owner":
        os.environ["MAKE_SHORT_PUBLISH_SCREEN"] = "1"
    else:
        os.environ.pop("MAKE_SHORT_PUBLISH_SCREEN", None)


def make_repo(path, probe=False):
    path.mkdir(parents=True)
    sh(path, "git", "init", "-q", "-b", "main")
    (path / "pipeline" / "scripts").mkdir(parents=True)
    (path / "assets").mkdir()
    (path / "VERSION").write_text("1.0.0\n")
    (path / "assets" / "release_source.json").write_text('{"base":"","pubkey":""}\n')
    (path / "pipeline" / "scripts" / "x.py").write_text("def f():\n    return 1\n")
    # "בדיקה עצמית" מזויפת: מריצה probe.py אם קיים (דרכו בודקים שהארגז באמת סוגר)
    (path / "pipeline" / "scripts" / "make_short_selftest.py").write_text(
        "import os, sys\nsys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))\n"
        "if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'probe.py')):\n    import probe\n"
        "import x\nsys.exit(0 if x.f() == 1 else 1)\n")
    sh(path, "git", "add", "-A")
    sh(path, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "base")
    sh(path, "git", "tag", "v1.0.0")
    sh(path, "git", "tag", "rel-1.0.0")


fake = Fake()
USER = getpass.getuser()

# ───────── חיבור הערוץ ─────────
as_("sender")
make_repo(T / "repo_sender")
make_repo(T / "repo_owner")
chk(P.load_channel() is None and not P.sender_status()["active"], "בלי קובץ ערוץ: התכונה כבויה")
chk("עוד לא פעילה" in raises(P.prepare, "idea", "שלום"), "בלי ערוץ אי אפשר להכין הצעה")
chk(not P._valid_server("https://ntfy.sh"), "במצב בדיקה אסור שרת אמיתי (https://ntfy.sh נדחה)")
chk(not P._valid_server("http://example.com"), "http לא-מקומי נדחה")
chk(P._valid_server(fake.url), "שרת מקומי מזויף מותר")

as_("owner")
chk(P.owner_visible(), "הבעלים רואה (יש מפתח/מצב בדיקה)")
ch = P.setup_channel(fake.url)
chk(len(ch["inbox"]) >= 32 and ch["inbox"] != ch["alert"] and P._valid_topic(ch["inbox"]), "נושאים אקראיים ארוכים ותקינים", ch)
chk(len(set(P.new_topic() for _ in range(50))) == 50 and len(P.new_topic()) - 4 >= 32, "192 ביט אקראיות (32 תווים base64)")
chk(raises(P.setup_channel, fake.url), "אי אפשר ליצור ערוץ שני בלי סיבוב")
cb = P.channel_file_bytes()
chk(cb and json.loads(cb)["inbox"] == ch["inbox"], "קובץ הערוץ לגרסה נבנה מהערוץ")
chk(oct(os.stat(P.OWNER_FILE).st_mode & 0o777) == "0o600", "קובץ הבעלים 600")
(T / "repo_sender" / "assets" / "proposals_channel.json").write_bytes(cb)
as_("sender")
chk(P.load_channel() and P.load_channel()["inbox"] == ch["inbox"], "השולח טוען את הערוץ מהקובץ שבקוד")
chk(not P.owner_visible() and not P.owner_status()["visible"], "שולח רגיל: מסך הבעלים לא נראה")

# ───────── ניקוי והכנת טיוטה ─────────
fakekey = "AIza" + "SyD" + "x" * 33
txt = ("הכפתור לא עובד <script>alert(1)</script>\u202eevil\x07 %s token=abc123secretvalue\n"
       "קובץ ב-/home/%s/shorts/x.py ו-C:\\Users\\%s\\Desktop") % (fakekey, USER, USER)
d = P.prepare("bug", txt, contact="דנה", diag="שורה 1\nGEMINI_API_KEY=" + "q" * 40 + "\n/home/%s/log" % USER, with_diag=True)
pv, pl = d["preview"], d["draft"] and P._read_json(P.DRAFTS / (d["draft"] + ".json"))["payload"]
chk(fakekey not in pv and "token=abc123" not in pv and "AIza" not in pv, "מפתח וטוקן לא בתצוגה", pv[:400])
chk("\u202e" not in pv and "\x07" not in pv, "תווי בקרה ותווי כיוון נסתרים הוסרו")
# 4.7.4: not a bare `USER not in pv` - on a PC whose Linux user is "shorts" (the installer's default user) the neutral folder
# name "/shorts/x.py" in the sample itself contains the user name, so the check failed on every clean restore.
chk(("/home/" + USER) not in pv and ("Users\\" + USER) not in pv and ("/home/" + USER + "/") not in pl["diag"] and "<user>" in pv,
    "שם המשתמש לא בנתיבים")
chk("<script>alert(1)</script>" in pl["text"], "HTML נשמר כטקסט (לא מורצים; התצוגה עושה escape)")
chk("q" * 40 not in pv, "מפתח בפרטי המערכת הוסתר")
chk(pl["text"] in pv and pl["name"] in pv and pl["diag"] in pv and pl["sender_id"] in pv and P.alert_text(pl) in pv,
    "התצוגה המקדימה מכילה כל שדה שיישלח (טקסט, שם, פרטי מערכת, מזהה, התראה)")
chk("בתים" in pv and d["bytes"] > 0, "התצוגה מציגה גודל")
msgs = P.encode(pl)
chk(all(len(m.encode()) <= 4096 for m in msgs), "כל הודעה ≤ 4096 בתים (מגבלת ntfy)")
parts = [P.parse_part(m) for m in msgs]
wire = "".join(x[4] for x in parts)
blob = base64.urlsafe_b64decode(wire)
try:
    plain_ok = zlib.decompress(blob) is not None
except zlib.error:
    plain_ok = False
chk(not plain_ok and pl["reply"]["topic"].encode() not in blob and b"sender_id" not in blob,
    "A1: בקו אין טקסט גלוי — לא zlib רגיל, לא נושא התשובה, לא שמות שדות (מוצפן לבעלים)")
chk("מפתח ההצעות" in raises(P.decode, wire), "A1: השולח (או כל מי שקורא את הנושא) לא יכול לפענח")
as_("owner")
chk(all(parts) and P.decode(wire) == P.validate_payload(pl), "פענוח הקו אצל הבעלים == הטיוטה (מה שמוצג = מה שנשלח)")
chk(oct(os.stat(P.OWNER_KEY).st_mode & 0o777) == "0o600" and "x25519" in P.OWNER_KEY.read_text(), "A1: המפתחות הפרטיים של הבעלים בקובץ 600")
tamper = bytearray(blob)
tamper[-5] ^= 1
chk("לא מוצפנת" in raises(P.decode, base64.urlsafe_b64encode(bytes(tamper)).decode()), "A1: שינוי של בית אחד בדרך — נדחה")
as_("sender")
chk(not (P.OUTBOX.exists() and list(P.OUTBOX.glob("*.json"))), "הכנת טיוטה לא הכניסה לתור")
chk(not fake.msgs, "שום דבר לא יצא לרשת לפני אישור")
chk("השתנתה" in raises(P.confirm, d["draft"], "0" * 64), "digest שגוי — לא שולחים")
dp = P.DRAFTS / (d["draft"] + ".json")
dd = json.loads(dp.read_text())
dd["payload"]["text"] += " (שונה)"
dp.write_text(json.dumps(dd))
chk("השתנתה" in raises(P.confirm, d["draft"], d["digest"]), "טיוטה ששונתה בדיסק אחרי התצוגה — לא נשלחת")
chk(not fake.msgs, "עדיין שום דבר ברשת")

# ───────── שליחה, התראה, קבלה ─────────
d = P.prepare("bug", "כפתור ההעתקה לא עובד", contact="")
rec = P.confirm(d["draft"], d["digest"])
inbox_msgs, alert_msgs = fake.on(ch["inbox"]), fake.on(ch["alert"])
chk(rec["status"] == "sent" and len(inbox_msgs) >= 1, "אחרי אישור: נשלח ל-inbox", rec["status"])
chk(len(alert_msgs) == 1 and ch["alert"] != ch["inbox"] and "תקלה" in alert_msgs[0]["message"], "התראה אחת לנושא ה-alert", alert_msgs)
chk(not any(m["topic"] not in (ch["inbox"], ch["alert"]) for m in fake.msgs), "לא נשלח לשום נושא אחר")
chk(all(P.parse_part(m["message"]) for m in inbox_msgs), "כל הודעות ה-inbox בפורמט הקו")
pid1 = rec["pid"]
# שולח שני יום-אפס: אנונימי
chk(rec["payload"]["name"] == "", "אפשר אנונימי")

as_("owner")
r = P.fetch_inbox()
chk(r["stored"] == 1 and r["dropped"] == 0, "הבעלים שלף והצעה נשמרה", r)
items = P.inbox_list()
chk(len(items) == 1 and items[0]["status"] == "new" and items[0]["pid"] == pid1, "ההצעה בתיבה כ'חדשה'")
chk(any(m["topic"] == rec["payload"]["reply"]["topic"] for m in fake.msgs), "הבעלים פרסם אישור קבלה בערוץ התשובה")
n_before = len(fake.msgs)
r = P.fetch_inbox()
chk(r["stored"] == 0 and len(P.inbox_list()) == 1, "שליפה שנייה לא יוצרת כפילות")
as_("sender")
s = P.sync_sender()
chk(s["updated"] == 1 and P._read_json(P.OUTBOX / (pid1 + ".json"))["status"] == "received", "אצל השולח: 'התקבלה אצל המנהל'", s)

# ───────── פעולות הבעלים והסטטוסים ─────────
as_("owner")
P.mark_read(pid1)
chk(P.inbox_list()[0]["status"] == "read", "סימון נקרא")
time.sleep(1.1)
P.act(pid1, "reply", "תבדוק שוב אחרי העדכון")
as_("sender")
P.sync_sender()
o = P._read_json(P.OUTBOX / (pid1 + ".json"))
chk(o["status"] == "replied" and "תבדוק" in o["reply_text"], "תשובה חופשית מגיעה לשולח")
as_("owner")
time.sleep(1.1)
P.act(pid1, "accept", "תודה, נכנס לגרסה הבאה")
chk(P.release_notes_list()[0]["pid"] == pid1 and P.owner_status()["release_list"], "'✅ לצרף' מוסיף לרשימת הגרסה הבאה")
as_("sender")
P.sync_sender()
o = P._read_json(P.OUTBOX / (pid1 + ".json"))
chk(o["status"] == "accepted" and "תודה" in o["reply_text"], "'התקבלה לגרסה הבאה' + טקסט הבעלים אצל השולח")
as_("owner")
time.sleep(1.1)
P.act(pid1, "reply", "הערה אחרונה")
as_("sender")
P.sync_sender()
chk(P._read_json(P.OUTBOX / (pid1 + ".json"))["status"] == "accepted", "תשובה חופשית לא מורידה סטטוס סופי")
# זיוף: חתימה במפתח אחר; שידור חוזר ישן; פורמט שבור; חתימה אמיתית של הצעה אחרת; מהעתיד
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey as _EK  # noqa: E402
rep_topic = o["payload"]["reply"]["topic"]
fbody = P._b64u(json.dumps({"pid": pid1, "topic": rep_topic, "status": "rejected", "text": "זיוף", "ts": time.time()}).encode())
forged = "YSR2 %s %s %s" % (pid1, P._b64u(_EK.generate().sign(("YSR2|%s|%s" % (pid1, fbody)).encode())), fbody)
chk(not P.apply_reply(o, forged), "A1: תשובה חתומה במפתח שאינו של הבעלים — נדחית (מי שקרא את ההצעה לא יכול לזייף)")
chk(not P.apply_reply(o, "YSR2 %s %s %s" % (pid1, "A" * 86, fbody)), "A1: תשובה בלי חתימה תקפה — נדחית")
as_("owner")
old = P.make_reply(o["payload"], "received", "")
other = P.make_reply(dict(o["payload"], pid="1" * 16), "rejected", "של הצעה אחרת")
fut = P.make_reply(o["payload"], "rejected", "x", ts=time.time() + 10 ** 7)
as_("sender")
chk(not P.apply_reply(o, old), "תשובה ישנה/נסוגה (שידור חוזר) נדחית")
chk(not P.apply_reply(o, "YSR2 %s zz zz" % pid1) and not P.apply_reply(o, "garbage") and not P.apply_reply(o, "YSR1 %s a b" % pid1),
    "פורמט שבור / ישן (YSR1) נדחה")
oth = other.split(" ")
chk(not P.apply_reply(o, " ".join([oth[0], pid1] + oth[2:])), "A1: חתימה אמיתית של הצעה אחרת לא תקפה להצעה הזאת")
chk(not P.apply_reply(o, fut), "חותמת זמן מהעתיד רחוק נדחית (גם כשהחתימה אמיתית)")

# דחייה
as_("sender")
d = P.prepare("idea", "רעיון: כפתור חדש")
r2 = P.confirm(d["draft"], d["digest"])
as_("owner")
P.fetch_inbox()
P.act(r2["pid"], "reject", "לא מתאים לכיוון של התוכנה")
as_("sender")
P.sync_sender()
o2 = P._read_json(P.OUTBOX / (r2["pid"] + ".json"))
chk(o2["status"] == "rejected" and "לא מתאים" in o2["reply_text"], "'נדחתה' + נימוק")
chk(P.outbox_view()[0]["status_he"] and all("status_he" in v for v in P.outbox_view()), "סטטוסים בעברית בתצוגה")

# ───────── אין חיבור: תור + שליחה אחר כך ─────────
fake.down = True
d = P.prepare("idea", "הצעה בלי אינטרנט")
r3 = P.confirm(d["draft"], d["digest"])
chk(r3["status"] == "queued" and r3.get("last_error"), "בלי חיבור: נשארת בתור עם הסבר", r3.get("last_error"))
s = P.sync_sender()
chk(P._read_json(P.OUTBOX / (r3["pid"] + ".json"))["status"] == "queued", "סנכרון בלי חיבור לא קורס ולא מאבד")
fake.down = False
s = P.sync_sender()
chk(s["sent"] == 1 and P._read_json(P.OUTBOX / (r3["pid"] + ".json"))["status"] == "sent", "כשחוזר חיבור — נשלחת", s)
al = len(fake.on(ch["alert"]))
chk(al == 3, "ההתראה נשלחה פעם אחת לכל הצעה", al)

# ───────── פער זמן: שרת שוכח, שליחה חוזרת, הבעלים עונה על כפילות ─────────
fake.cache_secs = 0.2            # השרת "שוכח" אחרי רגע
time.sleep(0.5)
as_("owner")
r = P.fetch_inbox()
chk(r["stored"] == 0, "הצעה שפג תוקפה בשרת לפני שהבעלים שלף — אבדה בצד הבעלים (לכן יש שליחה חוזרת)")
fake.cache_secs = 12 * 3600
as_("sender")
rec3 = P._read_json(P.OUTBOX / (r3["pid"] + ".json"))
rec3["last_attempt"] -= 13 * 3600
P._save_rec(rec3)
s = P.sync_sender()
chk(s["resent"] == 1, "אחרי 12 שעות בלי אישור — נשלחת שוב", s)
chk(len(fake.on(ch["alert"])) == al, "שליחה חוזרת לא שולחת התראה נוספת")
as_("owner")
r = P.fetch_inbox()
chk(r["stored"] >= 1, "הבעלים קיבל בהשלמה (catch-up)", r)
as_("sender")
P.sync_sender()
chk(P._read_json(P.OUTBOX / (r3["pid"] + ".json"))["status"] == "received", "והשולח מקבל אישור")
# תשובה שנעלמה מהשרת + שליחה חוזרת => הבעלים מפרסם שוב את הסטטוס הנוכחי
as_("owner")
P.act(r3["pid"], "accept", "בפנים")
fake.msgs[:] = [m for m in fake.msgs if m["topic"] != rec3["payload"]["reply"]["topic"]]       # נמחקו מהשרת
as_("sender")
rr = P._read_json(P.OUTBOX / (r3["pid"] + ".json"))
rr["status"], rr["reply_at"] = "sent", 0                      # השולח לא ראה כלום
rr["last_attempt"] -= 13 * 3600
P._save_rec(rr)
P.sync_sender()
as_("owner")
mo = P._read_json(P._inbox_dir(r3["pid"]) / "meta.json")      # גם אצל הבעלים "עברו 13 שעות" (פרסום חוזר — פעם ב-6 שעות לכל היותר)
mo["republished_at"] -= 13 * 3600
P._write_json(P._inbox_dir(r3["pid"]) / "meta.json", mo)
P.fetch_inbox()
as_("sender")
P.sync_sender()
chk(P._read_json(P.OUTBOX / (r3["pid"] + ".json"))["status"] == "accepted", "כפילות → הבעלים מפרסם שוב את הסטטוס → השולח מתעדכן")

# ───────── קלט עוין אצל הבעלים ─────────
as_("owner")
pre = len(P.inbox_list())
bomb = base64.urlsafe_b64encode(zlib.compress(b"0" * 50_000_000, 9)).decode()
chk(len(bomb) < P.CAPS["chunk"] * 25, "פצצת דחיסה נכנסת בגודל קטן ב-base64")
chk(raises(P.decode, bomb), "פצצת דחיסה נדחית")
hostile = ["", "YSP1", "YSP1 zz 1 1 abc def", "YSP1 %s 99 99 %s aaa" % ("a" * 16, "b" * 16), "YSP1 %s 0 1 %s aaa" % ("a" * 16, "b" * 16),
           "YSP1 %s 1 1 %s %s" % ("a" * 16, "b" * 16, "A" * 5000), "x" * 5000, "<script>alert(1)</script>", "YSP1 %s 1 1 %s ***" % ("a" * 16, "b" * 16),
           None, 5, "YSP1 %s 1 1 %s %s" % ("c" * 16, "d" * 16, base64.urlsafe_b64encode(b"notzlib").decode())]
chk(all(P.ingest(m)[0] == "drop" for m in hostile), "הודעות פגומות/עוינות נזרקות, בלי קריסה")
chk(len(P.inbox_list()) == pre, "ושום דבר לא נכנס לתיבה")


def framed(b64, pid=None):
    import hashlib
    pid = pid or os.urandom(8).hex()
    return "YSP2 %s 1 1 %s %s" % (pid, hashlib.sha256(b64.encode()).hexdigest()[:16], b64)


plain_v1 = base64.urlsafe_b64encode(zlib.compress(json.dumps({"v": 1, "pid": "a" * 16, "kind": "idea", "sender_id": "f" * 16,
                                                              "text": "גלוי", "reply": {"topic": P.new_topic()}}).encode())).decode()
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey as _XK  # noqa: E402
from cryptography.hazmat.primitives import serialization as _SER  # noqa: E402
other_pub = _XK.generate().public_key().public_bytes(_SER.Encoding.Raw, _SER.PublicFormat.Raw)
to_other = P.encode({"v": 1, "pid": "b" * 16, "kind": "idea", "sender_id": "f" * 16, "ts": 1, "app_version": "1", "name": "",
                     "text": "למפתח אחר", "diag": "", "patch": "", "selftest": "", "reply": {"topic": P.new_topic()}, "epoch": 1},
                    P._b64u(other_pub))
chk(P.ingest(framed(plain_v1, "a" * 16))[0] == "drop" and [P.ingest(m)[0] for m in to_other][-1] == "drop"
    and len(P.inbox_list()) == pre, "A1: הצעה לא מוצפנת, או מוצפנת למפתח אחר — נזרקת")
chk(P.owner_status()["drops"]["invalid"] >= 2, "A3: מונה 'נדחו' בתיבה (פגומות/לא מוצפנות אליך)", P.owner_status()["drops"])


def mk_payload(**kw):
    p = {"v": 1, "pid": os.urandom(8).hex(), "kind": "idea", "sender_id": "f" * 16, "ts": int(time.time()), "app_version": "1.0.0",
         "name": "", "text": "טקסט", "diag": "", "patch": "", "selftest": "", "reply": {"topic": P.new_topic(), "key": os.urandom(32).hex()}, "epoch": 1}
    p.update(kw)
    return p


def inject(p):
    ms = P.encode(p)
    return [P.ingest(m) for m in ms][-1]


k, _ = inject(mk_payload(text="<img src=x onerror=alert(1)> \x00\x1b[31m\u202e", name="\x07שם" * 100))
it = P.get_item(P.inbox_list()[0]["pid"])
chk(k == "stored", "הצעה עם HTML ותווי בקרה נשמרת (כטקסט)")
stored = [P._read_json(f) for f in P.INBOX.glob("*/payload.json")]
chk(all("\x00" not in s["text"] and "\x1b" not in s["text"] and "\u202e" not in s["text"] and "\x07" not in s["name"] and len(s["name"]) <= 80
        for s in stored), "תווי בקרה הוסרו, שם נחתך ל-80")
for bad_p in (mk_payload(kind="evil"), mk_payload(pid="../../etc"), mk_payload(reply={"topic": "../x", "key": "a" * 64}),
              mk_payload(sender_id="zz"), mk_payload(text="", patch=""), mk_payload(kind="patch", text="x", patch=""), mk_payload(v=2)):
    try:
        k = inject(bad_p)[0]
    except Exception as e:
        k = "EXC " + str(e)
    chk(k == "drop", "payload לא תקין נזרק: %s" % str({a: str(b)[:12] for a, b in list(bad_p.items())[:3]}), k)

# patch עוין: נשמר כהצעה אבל מסומן ולא נבדק
evil_patches = {
    "traversal": "diff --git a/../../etc/passwd b/../../etc/passwd\n--- a/../../etc/passwd\n+++ b/../../etc/passwd\n@@ -1 +1 @@\n-a\n+b\n",
    "absolute": "diff --git a//etc/x b//etc/x\n--- a//etc/x\n+++ b//etc/x\n@@ -1 +1 @@\n-a\n+b\n",
    "gitdir": "diff --git a/.git/hooks/pre-commit b/.git/hooks/pre-commit\n--- a/.git/hooks/pre-commit\n+++ b/.git/hooks/pre-commit\n@@ -1 +1 @@\n-a\n+b\n",
    "symlink": "diff --git a/pipeline/l b/pipeline/l\nnew file mode 120000\nindex 0000000..1111111\n--- /dev/null\n+++ b/pipeline/l\n@@ -0,0 +1 @@\n+/etc/passwd\n",
    "binary": "diff --git a/assets/a.png b/assets/a.png\nBinary files a/assets/a.png and b/assets/a.png differ\n",
    "config": "diff --git a/config.env b/config.env\n--- a/config.env\n+++ b/config.env\n@@ -1 +1 @@\n-a\n+b\n",
    "protected": "diff --git a/assets/release_source.json b/assets/release_source.json\n--- a/assets/release_source.json\n+++ b/assets/release_source.json\n@@ -1 +1 @@\n-a\n+b\n",
    "version": "diff --git a/VERSION b/VERSION\n--- a/VERSION\n+++ b/VERSION\n@@ -1 +1 @@\n-1.0.0\n+9.9.9\n",
    "backslash": "diff --git a/a\\b b/a\\b\n--- a/a\\b\n+++ b/a\\b\n@@ -1 +1 @@\n-a\n+b\n",
    "empty": "   \n",
    "nodiff": "just text, not a patch",
}
for nm, pt in evil_patches.items():
    v = P.validate_patch(pt)
    chk(not v["ok"], "patch עוין נדחה: " + nm, v)
giant = "diff --git a/pipeline/scripts/x.py b/pipeline/scripts/x.py\n--- a/pipeline/scripts/x.py\n+++ b/pipeline/scripts/x.py\n@@ -1 +1 @@\n" + "+x\n" * 80000
chk(not P.validate_patch(giant)["ok"], "patch ענק נדחה")
as_("sender")
chk("אי אפשר לשלוח" in raises(P.prepare, "patch", "תיקנתי", patch=evil_patches["traversal"]), "השולח לא יכול לשלוח patch עוין")
chk("אי אפשר" in raises(P.prepare, "patch", "תיקנתי", patch=giant), "השולח לא יכול לשלוח patch ענק")
as_("owner")
hp = mk_payload(kind="patch", text="תיקון", patch=evil_patches["gitdir"], app_version="1.0.0")
k, pid_h = inject(hp)
chk(k == "stored", "הצעת patch עוין מגיעה לתיבה (אבל מסומנת)")
mh = P.get_item(hp["pid"])[0]
chk(mh["has_patch"] and not mh["patch_ok"] and mh["patch_problems"], "מסומן patch לא תקין עם סיבה", mh["patch_problems"])
cr = P.check_patch(hp["pid"], repo=T / "repo_owner")
chk(not cr["applied"] and cr["selftest"] is None and "נדחה" in cr["text"], "בדיקה בארגז חול מסרבת ל-patch עוין (בלי להחיל)", cr["text"])

# ───────── מכסות ספאם ─────────
as_("sender")
c = P.sender_cfg()
for f in list(P.OUTBOX.glob("*.json")):
    f.unlink()
P.SENT_LOG.unlink(missing_ok=True)                    # "עבר יום"
cnt = 0
for i in range(P.SENDER_DAY - 1):
    d = P.prepare("idea", "הצעה %d" % i)
    P.confirm(d["draft"], d["digest"])
    cnt += 1
for r_ in P.outbox_view():                            # A8: "הסר מהרשימה" לא מאפס את המכסה
    P.forget(r_["pid"])
d = P.prepare("idea", "האחרונה המותרת")
P.confirm(d["draft"], d["digest"])
chk("כבר נשלחו" in raises(P.prepare, "idea", "עוד אחת"), "מכסת שולח: %d ביום — גם אחרי 'הסר מהרשימה' (A8)" % P.SENDER_DAY)
as_("owner")
for f in list(P.INBOX.glob("*/meta.json")):
    shutil.rmtree(f.parent)
# A3: אין מכסה "לשולח" — תוקף שמשתמש במזהה של משתמש אחר לא חוסם אותו; רק המכסה הכללית אמיתית
victim = "e" * 16
res = [inject(mk_payload(sender_id=victim, text="מתחזה %d" % i))[0] for i in range(15)]
chk(res.count("stored") == 15, "A3: 15 הצעות עם אותו מזהה שולח — לא נחסמות לפי מזהה (שהתוקף בוחר)", res)
res = [inject(mk_payload(sender_id=os.urandom(8).hex(), text="ס%d" % i))[0] for i in range(P.OWNER_TOTAL_DAY)]
chk(res.count("stored") == P.OWNER_TOTAL_DAY - 15 and res.count("drop") == 15, "מכסה כללית %d ביום" % P.OWNER_TOTAL_DAY, (res.count("stored"), res.count("drop")))
chk(P.owner_status()["drops"]["quota"] == 15, "A3: בתיבה מוצג 'נדחו בגלל מכסה: 15'", P.owner_status()["drops"])
# A3: "YSP2 <מזהה מוכר>" חוזר — הבעלים מפרסם שוב סטטוס לכל היותר פעם אחת בחלון
known = P.inbox_list()[0]["pid"]
before_pub = len([x for x in fake.log if x[0] == "POST"])
for _ in range(30):
    P.ingest("YSP2 %s 1 1 %s AAAA" % (known, "0" * 16))
chk(len([x for x in fake.log if x[0] == "POST"]) - before_pub == 0, "A3: כפילויות מזויפות של הצעה מוכרת — בלי פרסום חוזר בתוך 6 שעות")
mk_ = P._read_json(P._inbox_dir(known) / "meta.json")
mk_["republished_at"] -= 7 * 3600
P._write_json(P._inbox_dir(known) / "meta.json", mk_)
for _ in range(30):
    P.ingest("YSP2 %s 1 1 %s AAAA" % (known, "0" * 16))
chk(len([x for x in fake.log if x[0] == "POST"]) - before_pub == 1, "A3: אחרי 6 שעות — פרסום חוזר אחד בלבד (לא 30)")

# ───────── חלקים בכמה שליפות + גודל ─────────
as_("owner")
for f in list(P.INBOX.glob("*")):
    shutil.rmtree(f)
import random
rnd = random.Random(5)
noise = lambda n: "".join(chr(1488 + rnd.randrange(27)) + chr(65 + rnd.randrange(26)) for _ in range(n // 2))
big = mk_payload(text=noise(3900), diag=noise(11000))
ms = P.encode(big)
chk(len(ms) >= 2, "הצעה גדולה מתפצלת לכמה הודעות", len(ms))
a = P.ingest(ms[0])
chk(a[0] == "part" and not P.inbox_list(), "חלק ראשון בלבד — מחכים")
a = [P.ingest(m)[0] for m in ms[1:]]
chk(a[-1] == "stored", "החלק האחרון משלים")
ms2 = P.encode(mk_payload(text="x"))
pid2 = P.parse_part(ms2[0])[0]
r1 = P.ingest(ms2[0].replace(" 1 1 ", " 1 2 ", 1))                     # טוען שיש 2 חלקים
r2 = P.ingest(ms2[0].replace(" 1 1 ", " 2 3 ", 1))                     # חלק שני עם מספר חלקים אחר
chk(r1[0] == "part" and r2 == ("drop", "חלקים לא תואמים") and not (P._inbox_dir(pid2) / "meta.json").exists(),
    "מספר חלקים לא תואם: ממתין, ואז נזרק — בלי קריסה ובלי להיכנס לתיבה", (r1, r2))
huge = mk_payload(text="א" * 4000, diag="".join(chr(1488 + (i * 7919) % 27) for i in range(12000)), patch="")
huge["patch"] = base64.b64encode(os.urandom(88000)).decode()   # רעש שאינו מתכווץ
chk("גדולה מדי" in raises(P.encode, huge), "מעל תקרת הקו (64 אלף) — נדחה")

# ───────── ארגז חול: patch תקין ו-patch זדוני ─────────
as_("owner")
for f in list(P.INBOX.glob("*")):
    shutil.rmtree(f)
good = "diff --git a/pipeline/scripts/x.py b/pipeline/scripts/x.py\n--- a/pipeline/scripts/x.py\n+++ b/pipeline/scripts/x.py\n@@ -1,2 +1,2 @@\n def f():\n-    return 1\n+    return 1  # שיפור\n"
gp = mk_payload(kind="patch", text="שיפור קטן", patch=good)
inject(gp)
mg = P.get_item(gp["pid"])[0]
chk(mg["patch_ok"] and mg["patch_files"] == ["pipeline/scripts/x.py"], "patch תקין מזוהה", mg)
import make_short_fix as FIX  # noqa: E402
have_sb = FIX.sandbox_available()[0]
if not have_sb:
    # A10: דילוג גלוי — ובמצב CI (או כשדורשים ארגז) זה כישלון, לא "✓"
    print("⏭ דולג: אין bubblewrap כאן — בדיקות ארגז החול לא רצו (%s)" % FIX.sandbox_available()[1], flush=True)
    if os.environ.get("CI") or os.environ.get("MAKE_SHORT_REQUIRE_SANDBOX") == "1":
        chk(False, "בדיקות ארגז החול חייבות לרוץ במצב CI — אין bubblewrap")
else:
    cr = P.check_patch(gp["pid"], repo=T / "repo_owner")
    chk(cr["applied"] and cr["selftest"] is True, "patch תקין: הוחל בעותק זמני והבדיקה עברה", cr)
    chk(P.get_item(gp["pid"])[0]["check"]["selftest"] is True, "התוצאה נשמרת בהצעה")
    live = (T / "repo_owner" / "pipeline" / "scripts" / "x.py").read_text()
    chk("שיפור" not in live and sh(T / "repo_owner", "git", "status", "--porcelain") == "", "העץ החי לא נגע")
    chk(not list(P.PDIR.glob("ysp_check_*")), "העותק הזמני נמחק")
    # זדוני: מנסה לקרוא קובץ הגדרות, לפתוח רשת, וכתיבה מחוץ לעץ
    canary = T / "real_config_canary.txt"
    canary.write_text("SECRET")
    outside = T / "written_outside.txt"
    port = int(fake.url.rsplit(":", 1)[1])
    probe = ("import os, socket, sys\nleak = []\n"
             "try:\n    open(%r).read(); leak.append('read-config')\nexcept Exception:\n    pass\n"
             "try:\n    s = socket.create_connection(('127.0.0.1', %d), 2); leak.append('network'); s.close()\nexcept Exception:\n    pass\n"
             "try:\n    open(%r, 'w').write('x'); pass\nexcept Exception:\n    pass\n"
             "print(\"LEAK:\", leak) if leak else None\nsys.exit(1 if leak else 0)\n") % (str(canary), port, str(outside))
    lines = ["diff --git a/pipeline/scripts/probe.py b/pipeline/scripts/probe.py", "new file mode 100644", "--- /dev/null",
             "+++ b/pipeline/scripts/probe.py", "@@ -0,0 +1,%d @@" % len(probe.splitlines())] + ["+" + l for l in probe.splitlines()]
    mp = mk_payload(kind="patch", text="נראה תמים", patch="\n".join(lines) + "\n")
    inject(mp)
    getlen = len([x for x in fake.log if x[0] == "GET"])
    cr = P.check_patch(mp["pid"], repo=T / "repo_owner")
    chk(cr["applied"], "patch זדוני הוחל בעותק זמני", cr["text"])
    chk(cr["selftest"] is True, "בתוך הארגז: אין גישה לקובץ הגדרות, לא לרשת ולא לכתיבה החוצה (probe יצא נקי)", cr["text"])
    chk(canary.read_text() == "SECRET" and not outside.exists(), "קובץ הגדרות לא נקרא/שונה ושום כתיבה לא יצאה מהעץ")
    chk(len([x for x in fake.log if x[0] == "GET"]) == getlen, "הארגז לא פנה לרשת")
    chk(any("socket" in r or "config" in r for r in P.get_item(mp["pid"])[0]["patch_risks"]), "סימני סיכון מסומנים לבעלים", P.get_item(mp["pid"])[0]["patch_risks"])
    mm = mk_payload(kind="patch", text="לא מתאים", patch=good.replace("return 1\n+", "return 7\n+", 1).replace("-    return 1", "-    return 7"), app_version="1.0.0")
    inject(mm)
    cr = P.check_patch(mm["pid"], repo=T / "repo_owner")
    chk(not cr["applied"] and "לא מתאים" in cr["text"], "patch שלא מתאים לגרסה — דווח", cr["text"])
    mv = mk_payload(kind="patch", text="גרסה לא קיימת", patch=good, app_version="9.9.9")
    inject(mv)
    chk("לא נמצאה" in P.check_patch(mv["pid"], repo=T / "repo_owner")["text"], "גרסה שלא קיימת אצל הבעלים — דווח")
    # A4: patch ששובר את הקוד וגם "משתיק" את הבדיקה — הבדיקה רצה מהעותק הרשמי ונכשלת; והתוצאה מסומנת "לא מחייבת"
    selftest_path = "pipeline/scripts/make_short_selftest.py"
    st_old = (T / "repo_owner" / selftest_path).read_text().splitlines()
    sl = ["diff --git a/%s b/%s" % (selftest_path, selftest_path), "--- a/" + selftest_path, "+++ b/" + selftest_path,
          "@@ -1,%d +1,1 @@" % len(st_old)] + ["-" + l for l in st_old] + ["+import sys; sys.exit(0)"]
    brk = good.replace("+    return 1  # שיפור", "+    return 2")
    ma = mk_payload(kind="patch", text="מאשר את עצמו", patch=brk + "\n".join(sl) + "\n")
    inject(ma)
    chk(P.get_item(ma["pid"])[0]["patch_ok"], "A4: (ה-patch עצמו תקין מבחינת מבנה)", P.get_item(ma["pid"])[0]["patch_problems"])
    cr = P.check_patch(ma["pid"], repo=T / "repo_owner")
    chk(cr["applied"] and cr["selftest"] is False and selftest_path in cr.get("check_files_restored", []) and cr.get("untrusted"),
        "A4: patch שמשתיק את הבדיקה עצמה — הבדיקה הרשמית רצה ונכשלת; התוצאה מסומנת 'לא מחייבת'", cr)
    cr_good = P.get_item(gp["pid"])[0]["check"]
    chk(cr_good.get("untrusted") and "לא מחייבת" in cr_good["text"], "A4: גם תוצאה ירוקה מוצגת 'לא מחייבת'", cr_good)
    # A5: מגבלות משאבים בארגז — קובץ ענק / זיכרון ענק לא עוברים, והבדיקה מסתיימת
    hog = ("import sys\nok = []\n"
           "try:\n    open('/work/big.bin', 'wb').write(b'0' * (400 << 20)); ok.append('fsize')\nexcept Exception:\n    pass\n"
           "try:\n    x = bytearray(6 << 30); ok.append('mem')\nexcept MemoryError:\n    pass\n"
           "print('HOG:', ok)\nsys.exit(1 if ok else 0)\n")
    hl = ["diff --git a/pipeline/scripts/probe.py b/pipeline/scripts/probe.py", "new file mode 100644", "--- /dev/null",
          "+++ b/pipeline/scripts/probe.py", "@@ -0,0 +1,%d @@" % len(hog.splitlines())] + ["+" + l for l in hog.splitlines()]
    mh2 = mk_payload(kind="patch", text="זולל", patch="\n".join(hl) + "\n")
    inject(mh2)
    t0 = time.time()
    cr = P.check_patch(mh2["pid"], repo=T / "repo_owner")
    chk(cr["applied"] and cr["selftest"] is True and time.time() - t0 < 120,
        "A5: בתוך הארגז — אי אפשר לכתוב קובץ של 400MB או להקצות 6GB (מגבלות), והבדיקה הסתיימה", cr["text"])

# ───────── patch מקומי אצל השולח (שולח "תיקנתי לעצמי") ─────────
as_("sender")
chk(P.local_patch(T / "repo_sender")[0] == "" and "אין שינויים" in P.local_patch(T / "repo_sender")[1], "בלי שינויים מקומיים — אין מה להציע")
(T / "repo_sender" / "pipeline" / "scripts" / "x.py").write_text("def f():\n    return 1  # שלי\n")
(T / "repo_sender" / "assets" / "release_source.json").write_text('{"base":"x","pubkey":"y"}\n')
pt, why = P.local_patch(T / "repo_sender")
chk("x.py" in pt and "VERSION" not in pt and "proposals_channel" not in pt, "patch מקומי: בלי קבצים מוגנים", why)
for f in list(P.OUTBOX.glob("*.json")):
    f.unlink()
P.SENT_LOG.unlink(missing_ok=True)                    # "עבר יום" (המכסה נבדקה למעלה)
d = P.prepare("patch", "הוספתי הערה", patch=pt, selftest="עברה: 12 בדיקות", with_patch=True)
chk("# שלי" in d["preview"] and "עברה: 12" in d["preview"] and "תיקון" in d["preview"], "תצוגה מקדימה כוללת את ה-patch ואת תוצאת הבדיקה")
secret_patch = pt.replace("# שלי", "# key " + "AIza" + "SyD" + "y" * 33)
chk("מפתח" in raises(P.prepare, "patch", "x", patch=secret_patch), "patch עם מפתח — לא נשלח")
(T / "repo_sender" / "pipeline" / "scripts" / "bin.dat").write_bytes(b"\x00\x01\x02")
sh(T / "repo_sender", "git", "add", "-N", "pipeline/scripts/bin.dat")
chk("בינארי" in P.local_patch(T / "repo_sender")[1], "שינוי בינארי — לא נשלח")

# ───────── סיבוב נושאים ─────────
as_("owner")
old_in = P.load_channel()["inbox"]
ch2 = P.rotate()
chk(ch2["epoch"] == 2 and ch2["inbox"] != old_in and ch2["alert"] != ch["alert"], "סיבוב: נושאים חדשים, epoch+1")
chk(json.loads(P.channel_file_bytes())["inbox"] == ch2["inbox"], "הגרסה הבאה תישא את הנושאים החדשים")
_srv, tps = P._topics()
chk(tps[0] == ch2["inbox"] and old_in in tps, "הנושא הישן עדיין נשלף (מי שלא התעדכן)")
as_("sender")
d = P.prepare("idea", "הצעה לנושא ישן")        # השולח עדיין עם הערוץ הישן (קובץ הקוד שלו)
P.confirm(d["draft"], d["digest"])
as_("owner")
r = P.fetch_inbox()
chk(r["stored"] >= 1, "הצעה לנושא הישן אחרי סיבוב עדיין מתקבלת", r)
(T / "repo_sender" / "assets" / "proposals_channel.json").write_bytes(P.channel_file_bytes())
as_("sender")
chk(P.load_channel()["inbox"] == ch2["inbox"], "אחרי עדכון השולח עובר לנושא החדש")

# ───────── 4.5.x: הצפה, הפניה, פרטיות, התראות ─────────
as_("owner")
_srv2, tps2 = P._topics()


def junk(n, size=3000):
    with fake.lock:
        for _ in range(n):
            fake.n += 1
            fake.msgs.append({"id": "m%06d" % fake.n, "time": int(time.time()), "event": "message", "topic": tps2[0],
                              "message": "YSP2 " + "z" * size, "title": None, "priority": 1, "tags": []})


P.fetch_inbox()                                          # ריקון מה שכבר שם
junk(60)
as_("sender")
d = P.prepare("idea", "הצעה אמיתית אחרי הצפה")
rf = P.confirm(d["draft"], d["digest"])
as_("owner")
cap0, pages0 = P.CAPS["resp"], P.CAPS["pages"]
P.CAPS["resp"] = 20000
r = P.fetch_inbox()
chk(not r["error"] and r["stored"] == 1 and (P._inbox_dir(rf["pid"]) / "meta.json").exists(),
    "A2: הצפה של 180 אלף תווים (מעל התקרה) — נקראת בעמודים, וההצעה האמיתית שאחריה נכנסת", r)
r = P.fetch_inbox()
chk(r["stored"] == 0 and r["dropped"] == 0 and not r.get("more"), "A2: המצביע התקדם — שליפה שנייה לא קוראת שוב את ההצפה", r)
junk(60)
as_("sender")
d = P.prepare("idea", "עוד אחת אחרי הצפה")
rf2 = P.confirm(d["draft"], d["digest"])
as_("owner")
P.CAPS["pages"] = 2
got = 0
for _ in range(10):
    r = P.fetch_inbox()
    got += r["stored"]
    if not r.get("more"):
        break
chk(got == 1 and (P._inbox_dir(rf2["pid"]) / "meta.json").exists(), "A2: גם כשעמודים מוגבלים — כל שליפה ממשיכה מאיפה שעצרה", got)
P.CAPS["resp"], P.CAPS["pages"] = cap0, pages0
# A7: לא הולכים אחרי הפניה
fake.redirect_to = "http://127.0.0.1:1/internal"
err = raises(P.poll_page, fake.url, tps2)
fake.redirect_to = None
chk("להפנות" in err and not any(x[0] == "GET" and "internal" in x[1] for x in fake.log), "A7: הפניה (302) נחסמת — לא פונים לכתובת אחרת", err)
# A6: שם המשתמש בווינדוס (שונה מזה של לינוקס) לא יוצא, גם לא ב-patch ובתוצאת הבדיקה
os.environ["MAKE_SHORT_WIN_USERS"] = "winperson7"
s_ = P.privacy("C:\\Users\\winperson7\\Desktop · /mnt/c/Users/winperson7/x · \\\\wsl.localhost\\Ubuntu\\home\\%s\\y" % USER)
chk("winperson7" not in s_ and USER not in s_.replace("<user>", ""), "A6: privacy מסתיר את שם המשתמש בווינדוס ובלינוקס", s_)
as_("sender")
P.SENT_LOG.unlink(missing_ok=True)
for f in list(P.OUTBOX.glob("*.json")):
    f.unlink()
pt_w = pt.replace("# שלי", "# שלי C:/Users/winperson7/notes")
d = P.prepare("patch", "תיקון עם נתיב", patch=pt_w, selftest="רץ מ-/mnt/c/Users/winperson7/x: עבר", with_patch=True)
dp_ = P._read_json(P.DRAFTS / (d["draft"] + ".json"))["payload"]
chk("winperson7" not in d["preview"] and "winperson7" not in dp_["patch"] and "winperson7" not in dp_["selftest"]
    and dp_["patch"] in d["preview"] and dp_["selftest"] in d["preview"], "A6: גם ב-patch ובתוצאת הבדיקה — והתצוגה == מה שנשלח")
os.environ.pop("MAKE_SHORT_WIN_USERS")
# A9: ההתראה לטלפון בלי קישורים
al = P.alert_text({"kind": "idea", "app_version": "1", "text": "תלחץ כאן https://evil.example/x או www.evil.co", "patch": ""})
chk("http" not in al and "www." not in al and "[קישור]" in al, "A9: קישורים בטקסט לא נכנסים להתראה לטלפון", al)
as_("owner")
chk("לא ללחוץ על קישורים" in P.owner_status()["push_warning"], "A9: אזהרה לבעלים: לא ללחוץ על קישורים/כפתורים בהתראות")

# ───────── חשיפה, זהות ─────────
as_("sender")
chk(not P.owner_status()["visible"] and not P.owner_visible(), "שולח: אין חשיפת בעלים")
src = (SCRIPTS / "make_short_proposals.py").read_text(encoding="utf-8")
for needle in ("nihuly" + "betube", "<user>", "gmail"):
    # 4.5.62: בהתקנה של מקבל (.from_package) קובץ הבדיקה עצמו עבר ניטרול — המחרוזת הופכת ל-<user> ונמצאת בקוד; שם אין מה לבדוק
    if (SCRIPTS.parent.parent / ".from_package").exists():
        break
    chk(needle not in src, "אין מחרוזת זהות בקוד: " + needle)
import make_short_share as SH  # noqa: E402
as_("owner")
cbytes = P.channel_file_bytes().lower()
chk(cbytes and not any(n in cbytes for n in SH.identity_needles(False)), "קובץ הערוץ שנשלח למקבלים נקי מפרטים מזהים (סריקת הזהות)")
okey = json.loads(P.OWNER_KEY.read_text())
cj = json.loads(P.channel_file_bytes())
chk(okey["x25519"].lower() not in cbytes.decode() and okey["ed25519"].lower() not in cbytes.decode()
    and set(cj) == {"v", "server", "inbox", "alert", "epoch", "enc_pub", "sign_pub"},
    "A1: קובץ הערוץ (שנשלח לכולם) נושא רק מפתחות ציבוריים — לא את הפרטיים")
import make_short_chat as CHAT  # noqa: E402
chk(CHAT.guard(P.channel_file_bytes().decode())[1] == 0, "קובץ הערוץ לא נראה כמו סוד (סריקת הסודות של הצ'אט)")

# ───────── הערוץ נכנס לגרסה החתומה (ורק אליה) ─────────
import make_short_publish as PUB  # noqa: E402
import make_short_release as REL  # noqa: E402
import zipfile  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
os.environ["SHORTS_CONFIG_DIR"] = str(T / "cfg_owner")
key = Ed25519PrivateKey.generate()
rd = PUB.build_release(T / "repo_owner", "1.0.0", None, ["x"], False, None, T / "relout", key, say=lambda *a: None)
man = json.loads((rd / "manifest.json").read_text())
zz = zipfile.ZipFile(rd / man["archive"]["name"])
chk(P.CHANNEL_ASSET in man["files"] and json.loads(zz.read(P.CHANNEL_ASSET))["inbox"] == ch2["inbox"], "הגרסה החתומה נושאת את הנושאים הנוכחיים של הבעלים")
as_("sender")
as_("nobody")
rd2 = PUB.build_release(T / "repo_owner", "1.0.0", None, ["x"], False, None, T / "relout2", key, say=lambda *a: None)
chk(P.CHANNEL_ASSET not in json.loads((rd2 / "manifest.json").read_text())["files"], "בלי ערוץ אצל הבעלים — הגרסה נבנית בלי קובץ ערוץ (התכונה כבויה אצל המקבלים)")

fake.stop()
bad = [o for o in OUT if not o[0]]
print("\n%d בדיקות, %d נכשלו" % (len(OUT), len(bad)))
shutil.rmtree(T, ignore_errors=True)
sys.exit(1 if bad else 0)
