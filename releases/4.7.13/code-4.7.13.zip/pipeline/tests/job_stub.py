# -*- coding: utf-8 -*-
"""עבודה מדומה במקום make_short.py — לבדיקות התור והדף (MAKE_SHORT_JOB_STUB=<הקובץ הזה>).
מדברת באותו פרוטוקול: PLAN= / STEP= / STAGE=, ישנה STUB_SECS שניות (ברירת מחדל 2), ויוצאת 0
(או 1 כש-STUB_FAIL=1). STUB_MARK=<תיקייה> — כותבת שם <kind>_<clip>.end עם זמן הסיום המדויק,
כדי שהבדיקה תמדוד כמה זמן אחרי הסוף השרת והדף יודעים שהעבודה נגמרה."""
import json
import os
import sys
import time

a = sys.argv[1:]
kind = a[0] if a else "?"
clip = a[2] if len(a) > 2 and not a[2].startswith("--") else next((x[8:] for x in a if x.startswith("--clips=")), "")
secs = float(os.environ.get("STUB_SECS_" + kind.upper(), os.environ.get("STUB_SECS", "2")))
print("PLAN=" + json.dumps([["s1", "שלב מדומה 1", secs / 2], ["s2", "שלב מדומה 2", secs / 2]], ensure_ascii=False), flush=True)
print("STEP=s1\trun\t", flush=True)
time.sleep(secs / 2)
print("STEP=s1\tdone\t", flush=True)
print("STEP=s2\trun\t", flush=True)
time.sleep(secs / 2)
print("STEP=s2\tdone\t", flush=True)
mark = os.environ.get("STUB_MARK")
if mark:
    with open(os.path.join(mark, "%s_%s.end" % (kind, clip or "all")), "w") as fh:
        fh.write(repr(time.time()))
if os.environ.get("STUB_FAIL") == "1":
    print("❌ כישלון מדומה", flush=True)
    sys.exit(1)
# 22/10 (כרטיס 18): כישלון עם שורת יומן אמיתית (למשל "Sign in to confirm") — בודק שההתראה המתאימה עולה למעלה
if os.environ.get("STUB_FAIL_MSG"):
    print(os.environ["STUB_FAIL_MSG"], flush=True)
    print("❌ ההורדה נכשלה (מדומה)", flush=True)
    sys.exit(1)
# 22/10 (כרטיס 18): נכשלת עם הודעת "לשאול" (Modal נפל / תקרת היום) עד שהניסיון החוזר מגיע עם האישור
ask = os.environ.get("STUB_ASK")            # cpu | cap
if ask == "cpu" and os.environ.get("MAKE_SHORT_ASR_ALLOW_CPU") != "1":
    print("❌ Modal לא זמין (מדומה) — לא עבר לתמלול במחשב בלי לשאול. אפשר: \"🔁 נסה שוב\" (Modal), או \"💻 תמלול במחשב\"", flush=True)
    sys.exit(1)
if ask == "cap" and os.environ.get("MAKE_SHORT_MODAL_OK") != "1":
    print("❌ עובר את תקרת Modal היומית — היום כבר: $0.90 · הפעולה: ~$0.20 · התקרה: $1.00. לא נשלח כלום ל-Modal.", flush=True)
    sys.exit(1)
if ask:
    print("STUB_ALLOWED cpu=%s modal_ok=%s" % (os.environ.get("MAKE_SHORT_ASR_ALLOW_CPU"), os.environ.get("MAKE_SHORT_MODAL_OK")), flush=True)
print("STAGE=done", flush=True)
