# -*- coding: utf-8 -*-
"""בדיקה מקצה לקצה (ידנית, כ-2 דקות): האפליקציה האמיתית כמקבל, מול שרת עדכונים מזויף מקומי.

מעתיקה את הקוד הנוכחי (commit אחרון של הריפו שממנו רצה הבדיקה) → "בעלים" בגרסה 4.3.0 → מפרסמת 4.3.1 לשרת מזויף →
מתקינה "מקבל" ב-4.3.0 (ריפו עם .from_package) → מפעילה את השרת שלו → /api/release/check → /api/release/apply →
מחכה להפעלה מחדש → בודקת: הגרסה 4.3.1, "מה השתנה", הדף נפתח. גם: סירוב כשיש עבודה רצה (מדומה) ובעץ של בעלים.

הרצה:  python3 e2e_update_app.py     (לא נוגעת בשום דבר אמיתי; הכול בתיקייה זמנית; פורט פנוי)"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
T = Path(tempfile.mkdtemp(prefix="ys_e2e_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg"), "SHORTS_DATA_DIR": str(T / "data"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_PUBLISH_SELFTEST": "[]"})
sys.path.insert(0, str(REPO / "pipeline" / "scripts"))
import make_short_publish as P  # noqa: E402
import make_short_release as R  # noqa: E402

FAILS = []


def chk(c, w, d=""):
    print(("✓ " if c else "✗ ") + w + ("" if c else " — " + str(d)[:300]), flush=True)
    if not c:
        FAILS.append(w)


def sh(cwd, *a):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def git_commit(repo, msg, tag=None):
    sh(repo, "git", "add", "-A")
    sh(repo, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "--allow-empty", "-m", msg)
    if tag:
        sh(repo, "git", "tag", "-f", tag)


def get(port, path):
    return json.loads(urllib.request.urlopen("http://127.0.0.1:%d%s" % (port, path), timeout=10).read())


def post(port, path, body):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), json.dumps(body).encode(),
                                 {"Content-Type": "application/json", "Origin": "http://127.0.0.1:%d" % port})
    try:
        return 200, json.loads(urllib.request.urlopen(req, timeout=20).read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


try:
    # בעלים: עותק של הקוד הנוכחי (כולל מה שלא נשמר — לבדיקה) בגרסה 4.3.0
    owner = T / "owner"
    shutil.copytree(REPO, owner, ignore=shutil.ignore_patterns(".git", "__pycache__", "projects", "work"), symlinks=True)
    sh(owner, "git", "init", "-q", "-b", "main")
    (owner / "VERSION").write_text("4.3.0\n")
    git_commit(owner, "4.3.0", "v4.3.0")
    # מקבל: שיבוט, בלי origin, עם סימון חבילה
    inst = T / "install"
    sh(T, "git", "clone", "-q", str(owner), str(inst))
    sh(inst, "git", "remote", "remove", "origin")
    (inst / ".from_package").write_text("4.3.0")
    with open(inst / ".git" / "info" / "exclude", "a") as f:
        f.write(".from_package\n")
    # גרסה 4.3.1 אצל הבעלים
    (owner / "VERSION").write_text("4.3.1\n")
    (owner / "docs").mkdir(exist_ok=True)
    (owner / "docs" / "e2e_note.md").write_text("added in 4.3.1\n")
    git_commit(owner, "4.3.1", "v4.3.1")
    # מפתח + שרת מזויף
    pub = P.keygen("e2e passphrase long")
    remote = T / "remote"
    remote.mkdir()
    sh(remote, "git", "init", "-q", "-b", "main")
    sh(remote, "git", "config", "receive.denyCurrentBranch", "updateInstead")
    (remote / "README").write_text("x\n")
    git_commit(remote, "init")
    os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)
    os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = pub
    P.save_cfg({"remote": str(remote)})
    pb = P.Publisher(repo=owner)
    pb.start("e2e passphrase long", ["נוספה הערה בדיקה", "תיקון קטן"], False, "4.3.0")
    t0 = time.time()
    while time.time() - t0 < 300:
        s = pb.state()
        if s["waiting"]:
            pb.answer(True)
        if not s["running"]:
            break
        time.sleep(0.1)
    s = pb.state()
    chk(s["done"] and not s["error"], "פרסום 4.3.1 של הקוד האמיתי לשרת מזויף (כולל סריקת זהות וסודות)", s["error"] + str(s["log"][-3:]))
    # השרת של המקבל
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_IDLE_EXIT="0", GEMINI_API_KEY="",
               MAKE_SHORT_SETTINGS=str(T / "settings.json"), SHORTS_PROJECTS=str(T / "projects"), MAKE_SHORT_QUEUE=str(T / "queue.json"),
               MAKE_SHORT_NO_MODAL_METER="1", PYTHONUNBUFFERED="1", MAKE_SHORT_RESTART_GRACE="1")
    log = open(T / "server.log", "w")
    srv = subprocess.Popen([sys.executable, "-u", str(inst / "pipeline" / "scripts" / "make_short_app.py")], env=env, cwd=str(T),
                           stdout=log, stderr=subprocess.STDOUT)
    for _ in range(100):
        try:
            get(port, "/api/home")
            break
        except Exception:
            time.sleep(0.3)
    st = get(port, "/api/release/status")
    chk(st["mode"] == "receiver" and st["installed"] == "4.3.0" and st["configured"], "המקבל מזוהה כמקבל, גרסה 4.3.0", st)
    chk(st["publish"]["visible"] is not None and not st["has_prev"], "אין עדיין גרסה קודמת לחזור אליה")
    code, r = post(port, "/api/release/apply", {"confirm": True})
    chk(code == 400, "אי אפשר להתקין לפני שבדקו", r)
    code, r = post(port, "/api/release/check", {})
    for _ in range(40):
        time.sleep(0.5)
        st = get(port, "/api/release/status")
        if not st["checking"]:
            break
    chk(st["available"] and st["version"] == "4.3.1" and st["notes"] == ["נוספה הערה בדיקה", "תיקון קטן"], "הבדיקה מצאה 4.3.1 עם מה חדש", st)
    code, r = post(port, "/api/release/apply", {})
    chk(code == 400, "בלי אישור — לא מתקינים", r)
    code, r = post(port, "/api/release/apply", {"confirm": True})
    chk(code == 200, "העדכון התחיל", r)
    done = False
    for _ in range(300):
        time.sleep(1)
        try:
            st = get(port, "/api/release/status")
        except Exception:
            continue
        if st["installed"] == "4.3.1" and not st["applying"] and st.get("just_updated"):
            done = True
            break
        if st.get("last_error"):
            break
    chk(done, "העדכון הסתיים, השרת חזר לעבוד ומציג 'מה השתנה'", st.get("last_error") or st)
    chk(R.installed_version(inst) == "4.3.1" and (inst / "docs" / "e2e_note.md").exists(), "הקבצים של 4.3.1 על הדיסק")
    chk(R.rel_tags(inst) == ["rel-4.3.1"] or "rel-4.3.1" in R.rel_tags(inst), "תגית גרסה נשמרה", R.rel_tags(inst))
    time.sleep(2)
    st = get(port, "/api/release/status")
    chk(st["has_prev"] and st["just_updated"]["notes"] == ["נוספה הערה בדיקה", "תיקון קטן"], "אפשר לחזור לגרסה הקודמת; ההודעה נשמרה", st.get("just_updated"))
    chk(not st["available"], "אחרי העדכון אין עוד עדכון")
    # חזרה
    code, r = post(port, "/api/release/rollback", {"confirm": True})
    chk(code == 200, "חזרה לגרסה הקודמת התחילה", r)
    ok = False
    for _ in range(200):
        time.sleep(1)
        try:
            st = get(port, "/api/release/status")
            if st["installed"] == "4.3.0" and not st["applying"]:
                ok = True
                break
        except Exception:
            pass
    chk(ok and not (inst / "docs" / "e2e_note.md").exists(), "אחרי חזרה: 4.3.0 והקובץ החדש נעלם")
    srv.terminate()
finally:
    try:
        srv.terminate()
    except Exception:
        pass
    if "--keep" not in sys.argv:
        shutil.rmtree(T, ignore_errors=True)
    else:
        print("(נשאר: %s)" % T)
print("RESULT=" + json.dumps({"failed": FAILS}, ensure_ascii=False))
sys.exit(1 if FAILS else 0)
