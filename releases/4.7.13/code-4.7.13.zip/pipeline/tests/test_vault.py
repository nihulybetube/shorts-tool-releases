# -*- coding: utf-8 -*-
"""4.6 — בדיקות הכספת וערכת השחזור. רק סודות מזויפים, רק תיקיות זמניות, Drive מזויף = תיקייה מקומית, בלי רשת.

  python3 pipeline/tests/test_vault.py            (גם מתוך make_short_selftest.py)

מה נבדק: הלוך-חזור; סיסמה שגויה; שינוי בקובץ (תוכן / כותרת / רשימת הפריטים / תאריך); כתיבה שנקטעה (חצי קובץ, לפני
ההחלפה); שום ערך סודי בקובץ המוצפן, בפלט, ביומנים, בערכה שב-Drive, בחבילת שיתוף או ב-git; שחזור לא דורס בלי אישור;
הרשאות 0600; חיווט מחדש של נתיב Modal; ערכה לא חתומה וחתומה (וזיופים שלהן); העתק Ed25519 זהה; ושחזור מלא
"למחשב חדש" מתוך Drive מזויף: ערכה → בדיקה → חילוץ → התקנת הקוד (הקטע האמיתי מהמתקין) → כספת → גיבוי רגיל.
"""
import base64
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
SCRIPTS = REPO / "pipeline" / "scripts"
T = Path(tempfile.mkdtemp(prefix="ys_vault_test_"))
H1 = T / "oldpc"
C1, D1 = H1 / ".config" / "yeshiva-shorts", H1 / ".local" / "share" / "yeshiva-shorts"
for d in (C1, D1):
    d.mkdir(parents=True)
RC1 = H1 / ".config" / "rclone" / "rclone.conf"
WINMODAL = T / "winhome" / ".modal.toml"          # המחשב הישן: קובץ Modal "בווינדוס", MODAL_CONFIG_PATH מצביע אליו
os.environ.update({"HOME": str(H1), "SHORTS_CONFIG_DIR": str(C1), "SHORTS_DATA_DIR": str(D1), "MAKE_SHORT_TEST_GUARD": "1",
                   "MAKE_SHORT_VAULT_FAST_KDF": "1", "RCLONE_CONFIG": str(RC1), "MAKE_SHORT_RELEASES_BASE": "",
                   "MAKE_SHORT_RELEASE_PUBKEY": ""})
os.environ.pop("GEMINI_API_KEY", None)
os.environ.pop("MODAL_CONFIG_PATH", None)
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(REPO / "windows" / "restore"))
import make_short_vault as V  # noqa: E402
import make_short_release as R  # noqa: E402
import make_short_publish as P  # noqa: E402
import restore_kit as RK  # noqa: E402

FAILS = []


def chk(cond, name, detail=""):
    print(("  ✓ " if cond else "  ✗ ") + name + ("" if cond or not detail else "  — " + str(detail)[:300]), flush=True)
    if not cond:
        FAILS.append(name)


def raises(fn, needle=""):
    try:
        fn()
    except V.VaultError as e:
        return needle in str(e)
    except Exception as e:                       # noqa: BLE001
        return needle and needle in str(e)
    return False


def mode(p):
    return stat.S_IMODE(os.stat(p).st_mode)


# ─────────── סודות מזויפים (נבנים בחיבור — הקוד עצמו לא מכיל דפוס של סוד) ───────────
GEM = "AI" + "za" + "SyFAKE" + "g" * 30
CID = "1234-fake.apps.googleusercontent.com"
CSEC = "GOC" + "SPX-" + "fakeclientsec" + "z" * 12
TOK = "ya" + "29." + "faketok" + "q" * 24
MID, MSEC = "ak-" + "fakeid" + "1" * 14, "as-" + "fakesec" + "2" * 14
INBOX, ALERT = "in-fake" + "7" * 16, "al-fake" + "8" * 16
PRIVK = base64.b64encode(b"fake-proposals-private-key-material!!").decode()
SIGN_PW, VAULT_PW = "signing-" + "pass-" + str(41 * 3), "vault pass " + "phrase " + str(6 * 7)
SECRETS = [GEM, CSEC, TOK, MID, MSEC, INBOX, ALERT, PRIVK, VAULT_PW, SIGN_PW]


def put(p, text, m=0o600):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    os.chmod(p, m)


def no_secret_in(path_or_text, what):
    if isinstance(path_or_text, Path):
        blobs = []
        for f in ([path_or_text] if path_or_text.is_file() else [x for x in path_or_text.rglob("*") if x.is_file()]):
            blobs.append((f, f.read_bytes()))
    else:
        blobs = [("text", str(path_or_text).encode("utf-8"))]
    hits = [(str(f), s[:6]) for f, b in blobs for s in SECRETS if s.encode("utf-8") in b]
    chk(not hits, "שום ערך סודי לא נמצא ב: " + what, hits[:3])


print("▶ כספת: לפני שיש משהו")
chk(all(not a["present"] for a in V.available()), "מחשב ריק: שום פריט לא 'קיים'")
chk(raises(lambda: V.create(VAULT_PW, VAULT_PW), "אין במחשב"), "כספת ריקה לא נוצרת")

# ─────────── המחשב הישן: סודות מזויפים במקומות האמיתיים שלהם ───────────
P.keygen(SIGN_PW)                                                  # release_key.enc אמיתי (מוצפן בסיסמת החתימה)
put(C1 / "proposals_owner.key", json.dumps({"x25519": PRIVK, "ed25519": PRIVK[::-1]}))
put(C1 / "proposals_owner.json", json.dumps({"channel": {"server": "https://ntfy.invalid", "inbox": INBOX, "alert": ALERT, "epoch": 1}}))
put(WINMODAL, "[fakeprof]\ntoken_id = \"%s\"\ntoken_%s = \"%s\"\nactive = true\n" % (MID, "secret", MSEC))
sys.path.insert(0, str(REPO / "setup"))
import state  # noqa: E402
state.write_env({"GEMINI_API_KEY": GEM, "MODAL_CONFIG_PATH": str(WINMODAL), "SHORTS_ASR": "modal"})
put(RC1, "[gdrive]\ntype = drive\nclient_id = %s\nclient_%s = %s\nscope = drive\ntoken = {\"access_%s\":\"%s\"}\n" % (CID, "secret", CSEC, "token", TOK))
av = {a["id"]: a["present"] for a in V.available()}
chk(all(av.values()) and len(av) == 5, "כל חמשת הפריטים מזוהים במחשב", av)

print("▶ יצירה")
chk(raises(lambda: V.create(VAULT_PW, VAULT_PW + "x"), "לא זהות"), "שתי סיסמאות שונות → שגיאה")
chk(raises(lambda: V.create("short", "short"), "קצרה"), "סיסמה קצרה → שגיאה")
chk(raises(lambda: V.create(VAULT_PW, VAULT_PW, ["nope"]), "לא מוכר"), "פריט לא מוכר → שגיאה")
st = V.create(VAULT_PW, VAULT_PW)
chk(st["exists"] and sorted(i["id"] for i in st["items"]) == sorted(av), "נוצרה כספת עם כל הפריטים", st["items"])
chk(mode(V.VAULT_FILE) == 0o600, "vault.enc בהרשאה 0600", oct(mode(V.VAULT_FILE)))
no_secret_in(V.VAULT_FILE, "vault.enc (מוצפן)")
no_secret_in(V.STATE_FILE, "קובץ המצב המקומי")
h = json.loads(V.VAULT_FILE.read_text(encoding="utf-8"))
chk(set(h) == {"v", "kind", "kdf", "n", "r", "p", "salt", "nonce", "made", "items", "ct"}, "בכותרת רק שדות מוכרים (בלי ערכים)", sorted(h))
chk(not st["stale"] and not st["new"], "מיד אחרי יצירה — אין 'השתנה מאז'")
state.write_env({"GEMINI_API_KEY": GEM[:-1] + "h"})
chk(V.status()["stale"] == ["gemini"], "מפתח Gemini שהשתנה → 'לגבות שוב' (רק הוא)", V.status()["stale"])
state.write_env({"GEMINI_API_KEY": GEM})
chk(not V.status()["stale"], "חזר לערך המקורי → עדכני")

print("▶ סיסמה שגויה / שינויים בקובץ")
chk(raises(lambda: V.decrypt("wrong password!!"), "שגויה"), "סיסמה שגויה → שגיאה ברורה")
good = V.VAULT_FILE.read_bytes()
for label, mut in (("ct", lambda d: d.update(ct=d["ct"][:10] + ("A" if d["ct"][10] != "A" else "B") + d["ct"][11:])),
                   ("items", lambda d: d.update(items=d["items"][:-1])),
                   ("made", lambda d: d.update(made=d["made"] + 1)),
                   ("n", lambda d: d.update(n=2 ** 30))):
    d = json.loads(good)
    mut(d)
    bad = T / ("tampered_%s.enc" % label)
    bad.write_text(json.dumps(d), encoding="utf-8")
    chk(raises(lambda: V.decrypt(VAULT_PW, bad)), "שינוי ב-%s מתגלה (לא נפתח)" % label)
trunc = T / "trunc.enc"
trunc.write_bytes(good[: len(good) // 2])
chk(raises(lambda: V.decrypt(VAULT_PW, trunc), "פגום"), "קובץ שלא הורד עד הסוף → 'פגום'")
chk(V.decrypt(VAULT_PW)["items"]["gemini"]["GEMINI_API_KEY"] == GEM, "הסיסמה הנכונה פותחת")

print("▶ כתיבה שנקטעה (אטומיות)")
for cp in ("half_written", "before_replace"):
    os.environ["MAKE_SHORT_VAULT_CRASH_AT"] = cp
    try:
        V.create("another password 99", "another password 99")
        crashed = False
    except V.SimulatedCrash:
        crashed = True
    os.environ.pop("MAKE_SHORT_VAULT_CRASH_AT")
    chk(crashed and V.VAULT_FILE.read_bytes() == good, "קריסה (%s): הכספת הקודמת שלמה ובלי שינוי" % cp)
    chk(V.decrypt(VAULT_PW)["items"]["signing"], "קריסה (%s): עדיין נפתחת בסיסמה הקודמת" % cp)
leftover = list(C1.glob("vault.enc.tmp*"))
V.create(VAULT_PW, VAULT_PW)
chk(leftover and not list(C1.glob("vault.enc.tmp*")), "קובץ זמני שנשאר מקריסה — נמחק ביצירה הבאה")

print("▶ ערוץ מ-4.4 (בלי מפתח פרטי)")
import make_short_proposals as PRP0  # noqa: E402
PRP0.OWNER_KEY.rename(T / "keep_owner.key")
chk({a["id"]: a["present"] for a in V.available()}["proposals"], "4.6.8: ערוץ בלי קובץ מפתח עדיין נחשב 'קיים' (היה אפור)")
st = V.create(VAULT_PW, VAULT_PW, ["proposals"])
chk((C1 / "proposals_owner.key").is_file() and oct(mode(C1 / "proposals_owner.key")) == "0o600", "הגיבוי יצר את המפתח הפרטי החסר (מקומי)")
chk("proposals_owner.key" in V.decrypt(VAULT_PW)["items"]["proposals"], "והוא נכנס לכספת")
V.create(VAULT_PW, VAULT_PW)                      # חזרה לכספת המלאה (עם המפתח החדש) לשאר הבדיקות
print("▶ שחזור (אותו מחשב): לא דורס, ובלי ערכים בדוח")
rep = V.restore(VAULT_PW)
chk(all(r["result"] == "same" for r in rep), "הכול כבר במקום → 'זהה' לכל פריט", [(r["id"], r["result"]) for r in rep])
no_secret_in(json.dumps(rep, ensure_ascii=False), "דוח השחזור")

print("▶ שחזור למחשב חדש (תיקיות חדשות)")
H2 = T / "newpc"
C2, D2 = H2 / ".config" / "yeshiva-shorts", H2 / ".local" / "share" / "yeshiva-shorts"
RC2 = H2 / ".config" / "rclone" / "rclone.conf"
saved = shutil.copy2(V.VAULT_FILE, T / "vault_download.enc")
os.environ.update({"HOME": str(H2), "SHORTS_CONFIG_DIR": str(C2), "SHORTS_DATA_DIR": str(D2), "RCLONE_CONFIG": str(RC2)})
V.CONFIG, V.DATA, V.VAULT_FILE, V.STATE_FILE, V.KIT_DIR = C2, D2, C2 / "vault.enc", D2 / "vault_state.json", D2 / "restore_kit"
chk(raises(lambda: V.restore("wrong password!!", saved), "שגויה") and not C2.exists(), "סיסמה שגויה: שום דבר לא נכתב במחשב החדש")
rep = {r["id"]: r for r in V.restore(VAULT_PW, saved)}
chk(all(r["result"] == "restored" for r in rep.values()) and len(rep) == 5, "כל חמשת הפריטים שוחזרו",
    {k: (r["result"], r["note"]) for k, r in rep.items()})
chk((C2 / "release_key.enc").read_bytes() == (C1 / "release_key.enc").read_bytes(), "מפתח החתימה זהה בבתים")
chk((C2 / "proposals_owner.key").read_bytes() == (C1 / "proposals_owner.key").read_bytes() and
    (C2 / "proposals_owner.json").read_bytes() == (C1 / "proposals_owner.json").read_bytes(), "מפתח ההצעות + הערוץ זהים")
env2 = state.read_env()
chk(env2.get("GEMINI_API_KEY") == GEM, "מפתח Gemini ב-config.env החדש")
chk(env2.get("MODAL_CONFIG_PATH") == str(H2 / ".modal.toml") and (H2 / ".modal.toml").read_text() == WINMODAL.read_text(),
    "Modal: הקובץ הועבר לבית החדש והנתיב חווט מחדש (לא הנתיב הישן מווינדוס)", env2.get("MODAL_CONFIG_PATH"))
chk(env2.get("SHORTS_ASR") == "modal", "התמלול מוגדר ל-Modal")
g2 = V._gdrive_section(RC2)
chk(g2 and g2.get("client_id") == CID and g2.get("client_secret") == CSEC and "token" not in g2, "Drive: רק המפתח האישי, בלי הכניסה (אין טוקן)")
chk(V.drive_state(RC2) == "needs-login" and "בדפדפן" in rep["drive_client"]["check"], "Drive: מצב 'צריך כניסה בדפדפן'")
for f in (C2 / "release_key.enc", C2 / "proposals_owner.key", C2 / "proposals_owner.json", C2 / "config.env", H2 / ".modal.toml", RC2):
    chk(mode(f) == 0o600, "0600: %s" % f.name, oct(mode(f)))
chk(V.VAULT_FILE.is_file() and V.VAULT_FILE.read_bytes() == saved.read_bytes(), "עותק מקומי של הכספת נשמר (המחשב החדש מזוהה כשל הבעלים)")
chk(all(r["check"].startswith("✓") or "בדפדפן" in r["check"] for r in rep.values()), "בדיקה מקומית עברה לכל פריט",
    {k: r["check"] for k, r in rep.items()})
no_secret_in(json.dumps(list(rep.values()), ensure_ascii=False), "דוח השחזור במחשב החדש")
state.write_env({"GEMINI_API_KEY": GEM[:-2] + "xy"})
r = {x["id"]: x for x in V.restore(VAULT_PW, saved)}
chk(r["gemini"]["result"] == "kept" and state.read_env()["GEMINI_API_KEY"] == GEM[:-2] + "xy", "ערך אחר שכבר קיים — לא נדרס בלי אישור")
r = {x["id"]: x for x in V.restore(VAULT_PW, saved, overwrite=True)}
chk(r["gemini"]["result"] == "restored" and state.read_env()["GEMINI_API_KEY"] == GEM, "עם 'להחליף גם מה שקיים' — הוחלף")
(H2 / ".modal.toml").write_text("[x]\ntoken_id = \"other\"\n")
r = {x["id"]: x for x in V.restore(VAULT_PW, saved, overwrite=True)}
chk(r["modal"]["result"] == "restored" and list(H2.glob(".modal.toml.before-vault-*")), "דריסה שומרת עותק של הקודם (.before-vault-…)")

print("▶ CLI: סיסמה רק מהמקלדת, שום ערך בפלט")
cli = [sys.executable, str(SCRIPTS / "make_short_vault.py"), "restore", "--file", str(saved)]
p = subprocess.run(cli, input="wrong one!!!\n" + VAULT_PW + "\n", capture_output=True, text=True, timeout=300,
                   start_new_session=True, env=dict(os.environ))
chk(p.returncode == 0 and "שגויה" in p.stdout and "שוחזר" in p.stdout + p.stdout.replace("כבר היה", "שוחזר"),
    "CLI: סיסמה שגויה ואז נכונה → מצליח", (p.stdout + p.stderr)[-300:])
no_secret_in(p.stdout + p.stderr, "פלט ה-CLI")
p = subprocess.run(cli, input="\n", capture_output=True, text=True, timeout=60, start_new_session=True, env=dict(os.environ))
chk(p.returncode == 3 and "דילגנו" in p.stdout, "CLI: Enter ריק = דילוג (קוד 3)")
src = (SCRIPTS / "make_short_vault.py").read_text(encoding="utf-8")
chk("getpass" in src and not re.search(r"--pass|argv\[\d\]\s*#\s*pw|environ\.get\(\"[A-Z_]*PASS", src), "אין סיסמה בשורת הפקודה או במשתני סביבה")

print("▶ שמות קבצים: הכספת לא נכנסת לחבילה / לשינוי אישי / ל-git")
chk(not R._safe_path("vault.enc") and not R._safe_path("config/vault.enc"), "ארכיון עדכון/חבילה: vault.enc חסום")
import make_short_personal as PER  # noqa: E402
import fnmatch  # noqa: E402
chk(any(fnmatch.fnmatch("vault.enc", pat) for pat in PER.FORBIDDEN), "שינוי אישי: vault.enc חסום")
gi = (REPO / ".gitignore").read_text(encoding="utf-8")
chk(re.search(r"^\*\.enc$", gi, re.M) is not None, ".gitignore: *.enc")
chk(not [l for l in subprocess.run(["git", "-C", str(REPO), "ls-files"], capture_output=True, text=True).stdout.splitlines() if l.endswith(".enc")],
    "אין קובץ .enc בריפו")

print("▶ העתק Ed25519 בבודק הערכה = המקור")
blk = lambda t: re.search(r"(_P = 2 \*\* 255 - 19.*?return False\n)", t, re.S).group(1)  # noqa: E731
chk(blk((SCRIPTS / "make_short_release.py").read_text(encoding="utf-8")) ==
    blk((REPO / "windows" / "restore" / "restore_kit.py").read_text(encoding="utf-8")), "restore_kit.py: אימות החתימה זהה לזה של העדכונים")

print("▶ ערכת שחזור: לא חתומה")
ver = R.installed_version(REPO)
K = T / "kit_unsigned"
ks = V.build_kit(REPO, K, say=lambda *_: None)
chk(ks["exists"] and ks["version"] == ver and not ks["signed"] and ks["has_vault"], "נבנתה (גרסה %s, לא חתומה, עם הכספת)" % ver, ks)
names = sorted(str(p.relative_to(K)) for p in K.rglob("*") if p.is_file())
chk(names == sorted(["kit/code-%s.zip" % ver, "kit/kit.json", "kit/manifest.json", "restore_kit.py", "restore.ps1",
                     "שחזור למחשב חדש.bat", "קרא אותי - שחזור.txt", "vault.enc"]), "בדיוק הקבצים הצפויים", names)
v = RK.verify(K)
chk(v["ok"] and not v["signed"] and "לא חתומה" in v["msg"], "הבדיקה של המחשב החדש: תקינה, ואומרת שלא חתומה", v["msg"])
ps = (K / "restore.ps1").read_bytes()
chk(ps.startswith(b"\xef\xbb\xbf") and b"#<<SHARED-WSL" not in ps and "function Wsl-Run".encode() in ps
    and "Distro-Installed".encode() in ps and "wsl.exe --install".encode() in ps, "restore.ps1: BOM + קטעי ה-WSL של המתקין בפנים")
chk(b"\r\n" in ps and b"\n" not in ps.replace(b"\r\n", b""), "restore.ps1: שורות CRLF")
bat = (K / "שחזור למחשב חדש.bat").read_bytes()
chk(all(b < 128 for b in bat) and b"restore.ps1" in bat and b"kit\\kit.json" in bat, "ה-bat: ASCII בלבד, בודק שחולץ")
chk((K / "vault.enc").read_bytes() == V.VAULT_FILE.read_bytes() and mode(K / "vault.enc") == 0o600, "הכספת בערכה = העותק העדכני, 0600")
no_secret_in(K, "תיקיית הערכה (כולל ה-zip)")
import zipfile  # noqa: E402
with zipfile.ZipFile(K / "kit" / ("code-%s.zip" % ver)) as z:
    zn = z.namelist()
chk("shorts.sh" in zn and "windows/install_windows.ps1" in zn and "pipeline/scripts/make_short_app.py" in zn, "בארכיון הקוד יש את התוכנה", len(zn))
chk(not any(n.endswith(".enc") or "config.env" in n for n in zn), "בארכיון אין קבצים מוצפנים / הגדרות אישיות")
again = V.build_kit(REPO, K, say=lambda *_: None)
chk(again["made"] == ks["made"], "בנייה שנייה בלי שינוי — לא נבנית מחדש (מטמון)")


def tamper(name, fn):
    D = T / ("kit_t_" + name)
    shutil.copytree(K, D)
    fn(D)
    r = RK.verify(D)
    chk(not r["ok"], "זיוף נתפס: " + name, r["msg"])


def flip_zip(D):
    zp = D / "kit" / ("code-%s.zip" % ver)
    b = bytearray(zp.read_bytes())
    b[len(b) // 2] ^= 1
    zp.write_bytes(bytes(b))


tamper("בית אחד בארכיון", flip_zip)
tamper("מניפסט ששונה (שדה רגיל)", lambda D: (D / "kit" / "manifest.json").write_text(
    (D / "kit" / "manifest.json").read_text(encoding="utf-8").replace('"previous"', '"previouz"'), encoding="utf-8"))


def swap_hash(D):
    m = json.loads((D / "kit" / "manifest.json").read_text(encoding="utf-8"))
    m["files"]["shorts.sh"]["sha256"] = "0" * 64
    (D / "kit" / "manifest.json").write_text(json.dumps(m), encoding="utf-8")


tamper("גיבוב של קובץ במניפסט", swap_hash)
tamper("חתימה שנוספה לערכה לא חתומה", lambda D: (D / "kit" / "manifest.sig").write_text("QUJD", encoding="ascii"))
tamper("ארכיון חסר", lambda D: (D / "kit" / ("code-%s.zip" % ver)).unlink())

print("▶ ערכת שחזור: חתומה (מפתח בדיקה)")
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
from cryptography.hazmat.primitives import serialization as S  # noqa: E402
tk = Ed25519PrivateKey.generate()
tpub = base64.b64encode(tk.public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)).decode()
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = tpub
# 4.7.13: ב-HEAD כבר יש מפתח ציבורי אמיתי ב-release_source.json — הערכה החתומה במפתח בדיקה נבדקת מול שכפול שבו הקובץ מכיר את מפתח הבדיקה
RS = T / "repo_signed"
subprocess.run(["git", "clone", "-q", str(REPO), str(RS)], check=True, capture_output=True)
(RS / "assets" / "release_source.json").write_text(json.dumps({"base": "", "pubkey": tpub}) + "\n", encoding="utf-8")
subprocess.run(["git", "-C", str(RS), "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-qam", "test key"], check=True, capture_output=True)
P.build_release(RS, ver, ver, ["בדיקה"], False, None, V.DATA / "release_work", tk, say=lambda *_: None, include_channel=False)
KS = T / "kit_signed"
ks2 = V.build_kit(RS, KS, say=lambda *_: None)
v2 = RK.verify(KS)
chk(ks2["signed"] and v2["ok"] and v2["signed"] and v2["key_id"] == R.key_id(tpub), "גרסה מפורסמת חתומה → הערכה חתומה ונבדקת", v2["msg"])
D = T / "kit_badsig"
shutil.copytree(KS, D)
other = Ed25519PrivateKey.generate()
(D / "kit" / "manifest.sig").write_text(base64.b64encode(other.sign((D / "kit" / "manifest.json").read_bytes())).decode(), encoding="ascii")
chk(not RK.verify(D)["ok"], "חתימה במפתח אחר → לא מתקינים")
D = T / "kit_signflag"
shutil.copytree(KS, D)
(D / "kit" / "manifest.sig").unlink()
chk(not RK.verify(D)["ok"], "ערכה שמסומנת חתומה בלי קובץ חתימה → לא מתקינים")
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = ""
shutil.rmtree(V.DATA / "release_work", ignore_errors=True)

print("▶ חילוץ + השוואת גרסאות")
ST = T / "stage"
r = RK.stage(K, ST)
chk(r["ok"] and (ST / "code" / "shorts.sh").is_file() and (ST / "extras").is_dir(), "חילוץ לתבנית חבילה (code/ + extras/)")
pj = json.loads((ST / "package.json").read_text(encoding="utf-8"))
chk(pj.get("commit") == ver and pj.get("restore") is True, "package.json: גרסה + סימן שחזור", pj)
chk(os.access(ST / "code" / "shorts.sh", os.X_OK), "הרשאת הרצה נשמרה (shorts.sh)")
chk(RK.compare(K, T / "nohome") == "none", "compare: אין התקנה → none")


# ─────────── שחזור מלא מ-Drive מזויף ───────────
print("▶ מקצה לקצה: גיבוי מהמחשב הישן ל-Drive מזויף → שחזור במחשב חדש")
rclone = shutil.which("rclone") or str(Path("~").expanduser() / ".local/bin/rclone")
real_home_bin = Path(os.path.expanduser("~" + os.environ.get("USER", ""))) / ".local" / "bin"
if not Path(rclone).is_file():
    for cand in (real_home_bin / "rclone", Path("/usr/bin/rclone")):
        if cand.is_file():
            rclone = str(cand)
if not Path(rclone).is_file():
    msg = "אין rclone במחשב — דילוג גלוי על בדיקת מקצה לקצה"
    print("  ⚠ " + msg)
    if os.environ.get("CI"):
        chk(False, msg)
else:
    FAKE = T / "fakedrive" / "גיבוי תוכנה"
    FAKE.mkdir(parents=True)
    # המחשב הישן: גם הגדרות / לוגו / מוזיקה (בלי סודות) — מה שהגיבוי הרגיל מעביר
    put(C1 / "make_short_settings.json", json.dumps({"values": {"view_mode": "advanced", "org_name": "בדיקה"}}, ensure_ascii=False), 0o644)
    put(C1 / "guidelines.txt", "הנחיות בדיקה", 0o644)
    (C1 / "brand").mkdir(exist_ok=True)
    (C1 / "brand" / "logo.png").write_bytes(b"\x89PNG\r\n\x1a\nfake")
    (D1 / "music" / "tracks").mkdir(parents=True, exist_ok=True)
    (D1 / "music" / "tracks" / "a.mp3").write_bytes(b"ID3fake")
    env1 = dict(os.environ, HOME=str(H1), SHORTS_CONFIG_DIR=str(C1), SHORTS_DATA_DIR=str(D1), RCLONE_CONFIG=str(RC1),
                EXTRAS_REMOTE=str(FAKE), CLAUDE_WIN_HOME=str(T / "nowin"), PATH=str(Path(rclone).parent) + ":" + os.environ["PATH"])
    b = subprocess.run(["bash", str(REPO / "backup_extras.sh"), "backup"], env=env1, capture_output=True, text=True, timeout=900)
    chk(b.returncode == 0, "backup_extras.sh backup (עם ערכת השחזור) עבר", (b.stdout + b.stderr)[-500:])
    KD = FAKE / V.KIT_REMOTE_NAME
    chk((KD / "vault.enc").is_file() and (KD / "kit" / "kit.json").is_file() and (KD / "שחזור למחשב חדש.bat").is_file(),
        "ב-Drive המזויף: התיקייה 'שחזור למחשב חדש' עם הכספת והערכה")
    chk((FAKE / "config" / "make_short_settings.json").is_file() and (FAKE / "music" / "tracks" / "a.mp3").is_file(), "הגיבוי הרגיל עלה (בלי סיסמה)")
    no_secret_in(T / "fakedrive", "כל ה-Drive המזויף")
    no_secret_in(D1 / "logs", "היומנים במחשב הישן")
    # ...ושוב, בלי שינוי: לא נבנה מחדש ולא מתווסף כלום
    b2 = subprocess.run(["bash", str(REPO / "backup_extras.sh"), "kit"], env=env1, capture_output=True, text=True, timeout=600)
    chk(b2.returncode == 0 and len(list(KD.rglob("code-*.zip"))) == 1, "backup_extras.sh kit: ערכה אחת בלבד (מראה)", (b2.stdout + b2.stderr)[-300:])
    # כספת שלא נראית מוצפנת (שדה גלוי) לעולם לא עולה — הגיבוי נעצר וה-Drive נשאר עם הטובה
    real_v = (KD / "vault.enc").read_bytes()
    C3 = T / "c3"
    C3.mkdir()
    (C3 / "vault.enc").write_text(json.dumps({"v": 1, "kind": "yeshiva-shorts-vault", "kdf": "scrypt", "ct": "x", "plain": "x" * 40}))
    b3 = subprocess.run(["bash", str(REPO / "backup_extras.sh"), "kit"], env=dict(env1, SHORTS_CONFIG_DIR=str(C3)), capture_output=True, text=True, timeout=600)
    chk(b3.returncode == 2 and "לא נראה מוצפן" in b3.stderr and (KD / "vault.enc").read_bytes() == real_v,
        "כספת שלא נראית מוצפנת — לא עולה (וה-Drive נשאר עם הטובה)", (b3.stdout + b3.stderr)[-300:])
    shutil.rmtree(D1 / "restore_kit", ignore_errors=True)

    # "המחשב החדש": הורדה מהדפדפן = העתקה לתיקיית ההורדות
    DL = T / "Downloads" / "שחזור למחשב חדש"
    shutil.copytree(KD, DL)
    p = subprocess.run([sys.executable, "-I", str(DL / "restore_kit.py"), "verify", str(DL)], capture_output=True, text=True, timeout=300)
    chk(p.returncode == 0 and "✓" in p.stdout, "במחשב החדש: הערכה נבדקה לפני התקנה", p.stdout + p.stderr)
    STG = T / "newstage"
    p = subprocess.run([sys.executable, "-I", str(DL / "restore_kit.py"), "stage", str(DL), str(STG)], capture_output=True, text=True, timeout=300)
    chk(p.returncode == 0, "חילוץ", p.stdout + p.stderr)
    # התקנת הקוד: הקטע האמיתי של מצב חבילה מתוך המתקין שבערכה
    inst = (STG / "code" / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig")
    blocks = re.findall(r"Wsl-Run @'\r?\n(.*?)\r?\n'@", inst, re.S)
    code_blk = next(x for x in blocks if ".from_package" in x and "cp -a" in x)
    H3 = T / "newpc3"
    C4, D4 = H3 / ".config" / "yeshiva-shorts", H3 / ".local" / "share" / "yeshiva-shorts"
    p = subprocess.run(["bash", "-c", code_blk, "x", str(STG / "code"), str(H3), ver], capture_output=True, text=True, timeout=300,
                       env=dict(os.environ, HOME=str(H3)))
    D3 = H3 / "yeshiva-shorts-skill"
    chk(p.returncode == 0 and (D3 / "shorts.sh").is_file() and (D3 / ".from_package").is_file(), "הקוד הותקן (קטע ההתקנה האמיתי)",
        (p.stdout + p.stderr)[-300:])
    chk("<SHARED-WSL-A-BEGIN>" in inst and "-Restore" in inst and "$Restore" in inst, "המתקין שבערכה מכיר את ‎-Restore")
    env3 = dict(os.environ, HOME=str(H3), SHORTS_CONFIG_DIR=str(C4), SHORTS_DATA_DIR=str(D4), RCLONE_CONFIG=str(H3 / ".config/rclone/rclone.conf"),
                EXTRAS_REMOTE=str(FAKE), CLAUDE_WIN_HOME=str(T / "nowin"), PATH=env1["PATH"])
    p = subprocess.run([sys.executable, str(D3 / "pipeline" / "scripts" / "make_short_vault.py"), "restore", "--file", str(DL / "vault.enc")],
                       input=VAULT_PW + "\n", capture_output=True, text=True, timeout=300, env=env3, start_new_session=True)
    chk(p.returncode == 0 and p.stdout.count("שוחזר") >= 5, "הכספת שוחזרה בקוד המותקן", (p.stdout + p.stderr)[-400:])
    no_secret_in(p.stdout + p.stderr, "פלט השחזור במחשב החדש")
    p = subprocess.run([sys.executable, str(D3 / "pipeline" / "scripts" / "make_short_vault.py"), "drive-state"], capture_output=True, text=True, env=env3)
    chk(p.stdout.strip() == "needs-login", "Drive: מחכה לכניסה אחת בדפדפן", p.stdout)
    p = subprocess.run(["bash", str(D3 / "backup_extras.sh"), "restore"], env=env3, capture_output=True, text=True, timeout=600)
    chk(p.returncode == 0 and (D4 / "music" / "tracks" / "a.mp3").is_file() and (C4 / "brand" / "logo.png").is_file()
        and json.loads((C4 / "make_short_settings.json").read_text(encoding="utf-8"))["values"]["view_mode"] == "advanced",
        "הגיבוי הרגיל חזר בלי סיסמה (מוזיקה, לוגו, הגדרות — כולל התצוגה המתקדמת)", (p.stdout + p.stderr)[-300:])
    p = subprocess.run([sys.executable, "-c", "import sys; sys.path.insert(0, %r); import make_short_proposals as X; print(X.owner_visible())"
                        % str(D3 / "pipeline" / "scripts")], capture_output=True, text=True, env=env3)
    chk(p.stdout.strip() == "True", "המחשב החדש מזוהה כמחשב הבעלים (מסך הפרסום וההצעות)", p.stdout + p.stderr)
    p = subprocess.run([sys.executable, "-I", str(DL / "restore_kit.py"), "compare", str(DL), str(H3)], capture_output=True, text=True)
    chk(p.stdout.strip() == "same", "הפעלה שנייה של השחזור: הקוד כבר מותקן → לא מתקין שוב", p.stdout)
    chk((D4 / "logs").is_dir(), "יש יומנים במחשב החדש (נבדקים בשורה הבאה)")
    no_secret_in(D4, "תיקיית הנתונים במחשב החדש (יומנים, מוזיקה, מצב)")
    no_secret_in(D3, "קוד התוכנה המותקן")

print("▶ החלון: נקודות הקצה והדף")
HA = T / "apppc"
CA, DA = HA / ".config" / "yeshiva-shorts", HA / ".local" / "share" / "yeshiva-shorts"
put(CA / "make_short_settings.json", json.dumps({"values": {"drive_on": False}}), 0o644)
put(CA / "config.env", "GEMINI_API_KEY=%s\n" % GEM)
put(CA / "proposals_owner.key", json.dumps({"x25519": PRIVK}))
probe = r'''
import os, sys, json, time
sys.path.insert(0, sys.argv[1])
import make_short_app as APP
out = {}
APP.drive_on_setting = lambda: False          # בלי Drive (גם כשהבדיקה העצמית מפנה את קובץ ההגדרות למקום אחר)
APP.REL.update_mode = lambda r=None: "receiver"
APP.PROP.owner_visible = lambda: False
APP.VAULTS["vis"] = None
try:
    APP.vault_api("status", {}); out["nonowner"] = "allowed"
except APP.OwnerOnly:
    out["nonowner"] = "403"
out["health_nonowner"] = APP.vault_health()
out["health_run_all"] = [r["id"] for r in APP.HEALTH.run_all(drive_enabled=False, online=False)["results"]]
APP.REL.update_mode = lambda r=None: "owner"
APP.VAULTS["vis"] = None
h = APP.vault_health()
out["health_owner"] = [h["level"], h["title"]]
APP.PROP.owner_visible = lambda: True
APP.VAULT.available = lambda real=APP.VAULT.available: [dict(a, present=True) if a["id"] == "signing" else a for a in real()]
h = APP.vault_health()
out["health_signing"] = [h["level"], h["title"], h["steps"]]
APP.VAULT.available = APP.VAULT.available.__defaults__[0]
APP.PROP.owner_visible = lambda: False
s = APP.vault_api("status", {})
out["avail"] = sorted(a["id"] for a in s["available"] if a["present"])
try:
    APP.vault_api("create", {"passphrase": "x" * 12, "passphrase2": "y" * 12})
except ValueError as e:
    out["mismatch"] = str(e)
s = APP.vault_api("create", {"passphrase": sys.argv[2], "passphrase2": sys.argv[2], "items": ["gemini", "proposals"]})
out["items"] = sorted(i["id"] for i in s["items"])
for _ in range(600):
    if not APP.VAULTS["kit_running"]:
        break
    time.sleep(0.5)
out["kit_msg"] = APP.VAULTS["kit_msg"]
out["kit"] = APP.vault_api("status", {})["kit"]
r = APP.vault_api("restore", {"passphrase": sys.argv[2]})
out["restore"] = sorted((x["id"], x["result"]) for x in r["report"])
try:
    APP.vault_api("restore", {"passphrase": "wrong password!"})
except ValueError as e:
    out["wrong"] = str(e)
APP.PROP.owner_visible = lambda: False
APP.REL.update_mode = lambda r=None: "receiver"
APP.VAULTS["vis"] = None
out["vis_with_vault"] = APP.vault_visible()
print("PROBE" + json.dumps(out, ensure_ascii=False))
'''
envA = dict(os.environ, HOME=str(HA), SHORTS_CONFIG_DIR=str(CA), SHORTS_DATA_DIR=str(DA), RCLONE_CONFIG=str(HA / "rclone.conf"),
            MAKE_SHORT_NO_EXPORT="1")
p = subprocess.run([sys.executable, "-c", probe, str(SCRIPTS), VAULT_PW], capture_output=True, text=True, timeout=900, env=envA, cwd=str(T))
line = next((l for l in p.stdout.splitlines() if l.startswith("PROBE")), "")
o = json.loads(line[5:]) if line else {}
chk(o.get("nonowner") == "403", "לא-בעלים: /api/vault/* → 403 (OwnerOnly)", (p.stdout + p.stderr)[-400:])
chk("health_nonowner" in o and o["health_nonowner"] is None and "vault" not in o.get("health_run_all", ["vault"]),
    "🩺 אצל מי שאינו הבעלים: אין שורת כספת בכלל", o.get("health_run_all"))
chk((o.get("health_owner") or [""])[0] == "ok" and "עדיין אין כספת" in (o.get("health_owner") or ["", ""])[1],
    "🩺 בעלים בלי מפתח חתימה: שורה שקטה עם המלצה", o.get("health_owner"))
hs = o.get("health_signing") or ["", "", []]
chk(hs[0] == "warn" and "רק במחשב הזה" in hs[1] and any("גבה לכספת" in s for s in hs[2]) and any("נייר" in s for s in hs[2]),
    "🩺 בעלים עם מפתח חתימה ובלי כספת: אזהרה עם צעדים בעברית", hs[:2])
chk(o.get("avail") == ["gemini", "proposals"], "החלון מראה רק מה שקיים במחשב", o.get("avail"))
chk("לא זהות" in o.get("mismatch", ""), "החלון: שתי סיסמאות שונות → הודעה ברורה")
chk(o.get("items") == ["gemini", "proposals"], "נוצרה כספת רק עם הפריטים שסומנו")
chk((o.get("kit") or {}).get("exists") and "כבוי" in o.get("kit_msg", ""), "תיקיית השחזור נבנתה; Drive כבוי → נאמר במפורש", o.get("kit_msg"))
chk(o.get("restore") == [["gemini", "same"], ["proposals", "same"]], "שחזור מהחלון: הכול כבר במקום", o.get("restore"))
chk("שגויה" in o.get("wrong", ""), "שחזור מהחלון בסיסמה שגויה → הודעה ברורה")
chk(o.get("vis_with_vault") is True, "מחשב שיש בו כספת (שוחזר) — המסך גלוי גם בלי ריפו")
no_secret_in(DA, "תיקיית הנתונים של החלון (יומנים, ערכה)")
no_secret_in(p.stdout + p.stderr, "פלט החלון")
page = (SCRIPTS / "make_short_page.html").read_text(encoding="utf-8")
chk('class="set adv" id="vaultSet" hidden' in page and "REL.vault_visible" in page, "הכרטיס מוסתר כברירת מחדל ובתצוגה הפשוטה")
chk(all(('id="%s"' % i) in page and re.search(r'type="password" id="%s"' % i, page) for i in ("vaultPw1", "vaultPw2", "vaultPwR")),
    "שדות הסיסמה מוסתרים (type=password)")
chk('$("vaultPw1").value="";$("vaultPw2").value=""' in page and '$("vaultPwR").value=""' in page, "הסיסמה נמחקת מהשדה אחרי הפעולה")
for must in ("Google Keep", "על נייר", "משתלט על חשבון הגוגל", "מפתח החתימה אבד", "פעם אחת מחדש", "הנזק נופל על מי שקיבל", "שחזור למחשב חדש"):
    chk(must in page, "ההסבר בכרטיס כולל: " + must)
chk('data-fs="vault"' in page and "if(REL&&REL.vault_visible){" in page and "function fsVault()" in page,
    "🧭 צעדים ראשונים: כרטיס כספת — רק אצל הבעלים")
guide = (REPO / "docs" / "מדריך-העברה-למחשב-אחר.md").read_text(encoding="utf-8")
chk("שחזור למחשב חדש" in guide and "חלץ הכול" in guide and "Extract All" in guide and "סיסמת הכספת" in guide,
    "מדריך ההעברה: הדרך החדשה (תיקייה מה-Drive + לחיצה כפולה + סיסמה)")
app_src = (SCRIPTS / "make_short_app.py").read_text(encoding="utf-8")
chk('path.startswith("/api/vault/")' in app_src and "vault_guard()" in app_src, "השרת חוסם את /api/vault/* בלי הדף")

shutil.rmtree(T, ignore_errors=True)
print("\n%s — %d נכשלו" % ("✓ הכול עבר" if not FAILS else "✗ יש כישלונות", len(FAILS)))
sys.exit(1 if FAILS else 0)
