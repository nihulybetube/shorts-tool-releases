# -*- coding: utf-8 -*-
"""בדיקה: "✓ הועלה" ו-"🧹 נקה" (כרטיס 17, 22/10/2026). בלי רשת, בלי וידאו אמיתי ובלי סל המיחזור של ווינדוס:
הכול בתיקייה זמנית, "הסל" = תיקייה מקומית (MAKE_SHORT_FAKE_BIN), היומן והגיבוי — קבצי בדיקה.
  1. שורט אחד מתוך שלושה: התיקייה שלו בתיקיית השורטס + רק הקבצים שלו; clip1 ו-clip21 (שם דומה) והקבצים
     המשותפים (הסרטון המלא, תמלול השיעור) נשארים; הסדרה לא ריקה — נשארת.
  2. השורט האחרון → כל השיעור (גם קבצי ההכנה ב-app_specs), והסדרה/הרב שהתרוקנו יורדים.
  3. מבנה ישן (תיקייה לשיעור עם shorts/) — תיקיית השיעור כולה.
  4. דרייב: מספר הקבצים המדויק נרשם ב-allow_delete; שורה ביומן; נתיב מחוץ לתחום — נדחה.
הרצה: python3 pipeline/tests/test_clean.py"""
import json
import os
import sys
import tempfile
from pathlib import Path

fails = []


def check(cond, msg, extra=""):
    print(("  ✓ " if cond else "  ✗ ") + msg + (("  ← " + str(extra)) if (extra and not cond) else ""))
    if not cond:
        fails.append(msg)


td = tempfile.mkdtemp(prefix="ys17_")
T = Path(td)
os.environ.update(SHORTS_PROJECTS=str(T / "projects"), MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_TEST_EXPORT=str(T / "Shorts"),
                  MAKE_SHORT_FAKE_BIN=str(T / "bin"), SHORTS_EXPORT_LEDGER=str(T / "exports.jsonl"),
                  SHORTS_DATA_DIR=str(T / "data"), MAKE_SHORT_SETTINGS=str(T / "settings.json"))
(T / "settings.json").write_text(json.dumps({"drive_on": True}), encoding="utf-8")
HERE = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import make_short_clean as CLEAN  # noqa: E402

ROOT = T / "Shorts"


def w(p, size=1000):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b"x" * size)


def lesson(name, clips, layout="short"):
    P = MS.TOOL_DIR / name
    w(P / "source" / "full_video.mp4", 50000)
    w(P / "work" / "captions" / "yt.iw.srt", 300)
    w(P / "work" / "snap" / "refine1_0_100_200.wav", 400)
    st = {"video_title": "שיעור " + name, "rabbi": "הרב בדיקה", "series": "סדרה", "finished": "x", "clips": [],
          "saved": {"at": "x", "snap": {}, "clips": list(clips)}}
    exp = {}
    for n in clips:
        st["clips"].append({"name": n, "title": "כותרת " + n, "edit": "לעריכה/%s.txt" % n, "seconds": 30})
        w(P / "לעריכה" / ("%s.txt" % n), 100)
        for f in ("work/clips/%s_clean.mp4", "work/clips/%s_raw.mp4", "work/plain/%s.mp4", "work/burn/%s.mp4",
                  "work/subtitles/%s_words.json", "work/ear_large_ab/%s_words.json", "work/preview/%s_plain15.mp4",
                  "work/snap/%s_p0_1_2.wav"):
            w(P / (f % n), 2000)
        w(P / "shorts" / ("%s_כותרת" % n) / "v.mp4", 3000)
        if layout == "short":
            d = ROOT / "הרב בדיקה" / "סדרה" / ("כותרת " + n)
            w(d / "כותרת.mp4", 5000)
            w(d / "תיאור להעתקה.txt", 50)
            exp[n] = str(d)
    if layout == "short":
        st["export_dirs"], st["export_target"], st["export_layout"] = exp, str(ROOT / "הרב בדיקה" / "סדרה"), "short"
    else:
        t = ROOT / "הרב ישן" / "סדרה ישנה" / ("שיעור " + name)
        for n in clips:
            w(t / "shorts" / ("%s_כותרת" % n) / "v.mp4", 5000)
            w(t / "shorts" / ("%s_כותרת" % n) / "תיאור להעתקה.txt", 50)
        st["export_target"] = str(t)
    (P / MS.STATE).write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
    return P


print("1. שורט אחד מתוך שלושה")
P = lesson("2026-10-22_auto-AAAAAAAAAAA", ["clip1", "clip2", "clip21"])
w(ROOT / "הרב בדיקה" / "סדרה" / "שורט של שיעור אחר" / "a.mp4", 10)     # לא שלנו — לא ייגע
spec = T / "app_specs"
os.makedirs(spec, exist_ok=True)
(spec / "spec_20261022_000000_1.json").write_text(json.dumps({"project": str(P)}), encoding="utf-8")
pl = CLEAN.plan([{"project": str(P), "clip": "clip2"}])
r = pl["lessons"][0]
check(not r["whole"], "שורט אחד מתוך שלושה — לא כל השיעור")
check(len(r["exports"]) == 1 and r["exports"][0]["files"] == 2, "בתיקיית השורטס: רק התיקייה שלו (וידאו + תיאור)", r["exports"])
check(r["work_files"] == 9, "9 קבצי עבודה של clip2 (כולל shorts/clip2_…, בלי clip21)", r["work_files"])
check(pl["not_uploaded"] and "clip2" in pl["not_uploaded"][0] or "כותרת clip2" in pl["not_uploaded"][0],
      "מזהיר שלא סומן \"הועלה\"", pl["not_uploaded"])
CLEAN.SPECS = spec
CLEAN.run([{"project": str(P), "clip": "clip2"}])
check(not (ROOT / "הרב בדיקה" / "סדרה" / "כותרת clip2").exists(), "התיקייה של clip2 יצאה מתיקיית השורטס")
check((ROOT / "הרב בדיקה" / "סדרה" / "כותרת clip1").is_dir() and (ROOT / "הרב בדיקה" / "סדרה" / "כותרת clip21").is_dir(),
      "clip1 ו-clip21 נשארו")
check(not list(P.rglob("*clip2_*")) and not (P / "work/plain/clip2.mp4").exists(), "אין יותר קבצי עבודה של clip2")
check((P / "work/plain/clip21.mp4").exists() and (P / "work/clips/clip1_clean.mp4").exists(), "קבצים של קליפים אחרים — נשארו")
check((P / "source/full_video.mp4").exists() and (P / "work/captions/yt.iw.srt").exists()
      and (P / "work/snap/refine1_0_100_200.wav").exists(), "קבצים משותפים לשיעור — נשארו")
check((P / "לעריכה/clip2.txt").exists(), "קובץ העריכה (הכותרת לרשימה) נשאר")
st = json.load(open(P / MS.STATE, encoding="utf-8"))
c2 = next(c for c in st["clips"] if c["name"] == "clip2")
check(c2.get("cleaned") and c2.get("dropped") and "clip2" not in st["export_dirs"] and "clip2" not in st["saved"]["clips"],
      "המצב: clip2 נוקה (לא בשמירה, לא בתיקיות)")
check(len(list((T / "bin").iterdir())) == 2, "שני פריטים ב\"סל\" (התיקייה בשורטס + קבצי העבודה)")
check(not list(P.glob(CLEAN.STAGE_PREFIX + "*")), "לא נשארה תיקיית ביניים בשיעור")
pend = json.load(open(MS.DRIVE_PENDING, encoding="utf-8"))
check(pend.get("allow_delete") == 2, "דרייב: allow_delete = 2 קבצים בדיוק", pend)
try:
    MS.restore_clip(P, "clip2")
    check(False, "שחזור של שורט שנוקה — נחסם")
except ValueError:
    check(True, "שחזור של שורט שנוקה — נחסם (רק מסל המיחזור)")

print("2. השורטס האחרונים → כל השיעור")
pl = CLEAN.plan([{"project": str(P), "clip": "clip1"}, {"project": str(P), "clip": "clip21"}])
check(pl["lessons"][0]["whole"], "האחרונים שנשארו → כל השיעור")
CLEAN.run([{"project": str(P), "clip": "clip1"}, {"project": str(P), "clip": "clip21"}])
check(not P.exists(), "תיקיית העבודה של השיעור יצאה")
check(not (spec / "spec_20261022_000000_1.json").exists(), "קובץ ההכנה שלו הלך איתו")
check((ROOT / "הרב בדיקה" / "סדרה" / "שורט של שיעור אחר" / "a.mp4").exists(), "שורט של שיעור אחר — לא נגעו")
check(json.load(open(MS.DRIVE_PENDING, encoding="utf-8")).get("allow_delete") == 6, "דרייב: 2+4 קבצים מצטברים")
led = [json.loads(x) for x in (T / "exports.jsonl").read_text(encoding="utf-8").splitlines()]
check(len(led) == 2 and led[-1]["event"] == "clean" and led[-1]["whole"], "שורה ביומן לכל ניקוי", led)
(ROOT / "הרב בדיקה" / "סדרה" / "שורט של שיעור אחר" / "a.mp4").unlink()
import shorts_layout as SL  # noqa: E402
SL.prune_empty(ROOT / "הרב בדיקה" / "סדרה" / "שורט של שיעור אחר", ROOT)
P3 = lesson("2026-10-22_auto-CCCCCCCCCCC", ["clip1"])
CLEAN.run([{"project": str(P3)}])
check(not (ROOT / "הרב בדיקה").exists() and ROOT.exists(), "סדרה ורב שהתרוקנו — ירדו; השורש נשאר")

print("3. מבנה ישן")
P2 = lesson("2026-10-22_auto-BBBBBBBBBBB", ["clip1", "clip2"], layout="old")
pl = CLEAN.plan([{"project": str(P2)}])
check([Path(x["path"]).name for x in pl["lessons"][0]["exports"]] == ["שיעור 2026-10-22_auto-BBBBBBBBBBB"],
      "כל השיעור במבנה הישן = תיקיית השיעור", pl["lessons"][0]["exports"])
pl1 = CLEAN.plan([{"project": str(P2), "clip": "clip2"}])
check(len(pl1["lessons"][0]["exports"]) == 1 and pl1["lessons"][0]["exports"][0]["path"].endswith("clip2_כותרת"),
      "שורט אחד במבנה הישן = shorts/clip2_…")
CLEAN.run([{"project": str(P2)}])
check(not P2.exists() and not (ROOT / "הרב ישן").exists(), "השיעור הישן יצא, בלי תיקיות ריקות")

print("4. שמירה על הגבולות")
try:
    CLEAN.plan([{"project": str(T / "projects" / "claude_lesson")}])
    check(False, "שיעור מחוץ ל-projects/תוכנה — נדחה")
except ValueError:
    check(True, "שיעור מחוץ ל-projects/תוכנה (של Claude) — נדחה")
try:
    CLEAN.recycle(ROOT, ROOT, "x")
    check(False, "השורש עצמו — נדחה")
except RuntimeError:
    check(True, "השורש עצמו — נדחה")
os.environ["MAKE_SHORT_CLEAN_MAX_GB"] = "0.000001"
import importlib  # noqa: E402
importlib.reload(CLEAN)
P4 = lesson("2026-10-22_auto-DDDDDDDDDDD", ["clip1"])
check(CLEAN.plan([{"project": str(P4)}])["too_big"], "מעל התקרה של סל המיחזור — מסומן too_big")
try:
    CLEAN.run([{"project": str(P4)}])
    check(False, "too_big — הניקוי לא רץ")
except ValueError:
    check(P4.exists(), "too_big — הניקוי לא רץ, כלום לא נמחק")

print("5. דרייב: ניקוי של יותר מ-10 קבצים (תיקייה מקומית במקום הדרייב)")
import shutil  # noqa: E402
if shutil.which("rclone") or (Path.home() / ".local/bin/rclone").exists():
    src, dst = T / "drv_src", T / "drv_dst"
    for i in range(7):
        w(src / ("שורט %d" % i) / "v.mp4", 100)
        w(src / ("שורט %d" % i) / "תיאור להעתקה.txt", 10)
    w(src / "נשאר" / "v.mp4", 100)
    os.environ["MAKE_SHORT_TEST_DRIVE_DST"] = str(dst)
    os.environ["MAKE_SHORT_TEST_EXPORT"] = str(src)
    if MS.DRIVE_PENDING.exists():
        MS.DRIVE_PENDING.unlink()
    MS.mark_drive_pending("בדיקה")
    check(MS.run_drive_backup()[0] is True, "גיבוי ראשון (העלאה)")
    for i in range(6):
        shutil.rmtree(src / ("שורט %d" % i))              # 12 קבצים יצאו מ"תיקיית השורטס"
    MS.mark_drive_pending("בלי היתר")
    ok, why = MS.run_drive_backup()
    check(ok is False and (dst / "שורט 0" / "v.mp4").exists(), "בלי היתר: 12 מחיקות > 10 — הגיבוי עוצר, כלום לא נמחק", why)
    MS.mark_drive_pending("ניקוי", allow_delete=12)
    ok, why = MS.run_drive_backup()
    check(ok is True and not (dst / "שורט 0").exists() and (dst / "שורט 6" / "v.mp4").exists(),
          "עם allow_delete=12: בדיוק 12 נמחקו, השאר נשאר", why)
    check(not MS.DRIVE_PENDING.exists(), "הסימון (כולל ההיתר) נוקה אחרי הצלחה")
else:
    print("  (אין rclone — דילגתי)")

shutil.rmtree(td)          # תיקייה זמנית של הבדיקה עצמה (קבצים מזויפים בלבד)
print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d: %s" % (len(fails), fails)))
sys.exit(1 if fails else 0)
