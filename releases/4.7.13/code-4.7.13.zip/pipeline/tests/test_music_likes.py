# -*- coding: utf-8 -*-
"""כרטיס 13 (22/10/2026): ❤ / נשמע / השבתה / בחירה חכמה / איפוס+ביטול — על עותק של המשוב שלו.
לא נוגע בקובץ האמיתי (SHORTS_MUSIC_FEEDBACK + MAKE_SHORT_SETTINGS זמניים); קורא את ספריית המוזיקה בלבד.
הרצה: shorts.sh py ../tests/test_music_likes.py"""
import collections
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="ys13_likes_"))
REAL_FB = Path(os.path.expanduser("~/.config/yeshiva-shorts/music-feedback.json"))
shutil.copy(REAL_FB, TMP / "fb.json")
os.environ["SHORTS_MUSIC_FEEDBACK"] = str(TMP / "fb.json")
os.environ["MAKE_SHORT_SETTINGS"] = str(TMP / "settings.json")
os.environ["MAKE_SHORT_NO_EXPORT"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import make_short as MS          # noqa: E402
import make_short_music as MUS   # noqa: E402
import make_short_settings as SET  # noqa: E402
import music_library as ML       # noqa: E402

assert ML.feedback_path() == TMP / "fb.json"
real_before = REAL_FB.read_bytes()
fails = []


def check(cond, what):
    print(("  ✓ " if cond else "  ✗ ") + what)
    if not cond:
        fails.append(what)


rows = MUS.listing()
act = [r for r in rows if r["status"] == "active"]
print("tracks: %d, active: %d" % (len(rows), len(act)))
check(len(act) >= 5, "יש מספיק מנגינות בסבב לבדיקה")
sm = MUS.summary(rows)
check(sm["total"] == len(act) and sm["liked"] == 0, "סיכום: %d/%d, ❤ %d" % (sm["heard"], sm["total"], sm["liked"]))

# 1. בלי לייק — הבחירה של תמיד (הכי פחות משומשת)
pool, smart, fb = MS.pick_pool(30, set())
check(not smart, "בלי ❤ — אין בחירה חכמה")
uses = lambda u: len(fb.get("tracks", {}).get(u, {}).get("uses", []))
picks = [MS.pick_track(30, set())["uuid"] for _ in range(30)]
check(len({uses(u) for u in picks}) == 1 and uses(picks[0]) == min(uses(t["uuid"]) for t in pool),
      "בלי ❤ — תמיד הכי פחות משומשת")

# 2. כולן נשמעו + 3 לייקים → בחירה חכמה, ❤ פי 3, השאר לא אפס
for r in act:
    MUS.set_heard(r["uuid"], True)
liked = [r["uuid"] for r in act[:3]]
for u in liked:
    MUS.set_like(u, True)
rows = MUS.listing()
check(all(r["liked"] for r in rows if r["uuid"] in liked), "❤ נשמר")
pool, smart, fb = MS.pick_pool(30, set())
check(smart, "כולן נשמעו + ❤ — בחירה חכמה פועלת")
N = 200
cnt = collections.Counter(MS.pick_track(30, set())["uuid"] for _ in range(N))
liked_in = sum(cnt[u] for u in liked if any(t["uuid"] == u for t in pool))
nl = sum(1 for t in pool if t["uuid"] in liked)
exp = N * 3 * nl / (3 * nl + (len(pool) - nl))
per_liked = liked_in / max(1, nl)
per_plain = (N - liked_in) / max(1, len(pool) - nl)
print("  200 בחירות: ❤ %d (צפוי ≈%.0f) · ממוצע לאהובה %.1f · לרגילה %.1f · יחס %.1f · מנגינות שונות %d/%d"
      % (liked_in, exp, per_liked, per_plain, per_liked / max(0.01, per_plain), len(cnt), len(pool)))
check(1.8 < per_liked / max(0.01, per_plain) < 5, "❤ נבחרת בערך פי 3")
check(len(cnt) > len(pool) * 0.6, "גם מנגינות בלי ❤ נבחרות (לא אפס)")
avoid = {liked[0]}
check(all(MS.pick_track(30, avoid)["uuid"] != liked[0] for _ in range(60)), "מה שכבר בשיעור — לא נבחר שוב")

# 3. השבתה — לעולם לא נבחרת, לא נספרת ב-"מתוך"
MUS.set_disabled(liked[1], True)
rows = MUS.listing()
check(next(r for r in rows if r["uuid"] == liked[1])["status"] == "disabled", "מושבתת מסומנת")
check(MUS.summary(rows)["total"] == len(act) - 1, "מושבתת לא נספרת ב-\"מתוך\"")
check(all(MS.pick_track(30, set())["uuid"] != liked[1] for _ in range(200)), "מושבתת לא נבחרת ב-200 בחירות")
path = next(t["path"] for t in ML.downloaded_tracks(ML.load_json(ML.index_path(), {})) if t["uuid"] == liked[1])
check(Path(path).exists() and "_rejected" not in path, "הקובץ של המושבתת נשאר במקומו")
MUS.set_disabled(liked[1], False)
check(next(r for r in MUS.listing() if r["uuid"] == liked[1])["status"] == "active", "▶ הפעל מחזיר לסבב")

# 4. מנגינה אחת "לא נשמעה" → אין בחירה חכמה
MUS.set_heard(act[-1]["uuid"], False)
check(not MS.pick_pool(30, set())[1], "אחת לא נשמעה — חוזרים לבחירה של תמיד")
MUS.set_heard(act[-1]["uuid"], True)

# 5. ההגדרה כבויה
SET.update({"smart_music": False})
check(not MS.pick_pool(30, set())[1], "\"בחירה חכמה\" כבויה — הבחירה של תמיד")
SET.update({"smart_music": True})

# 6. איפוס + ביטול
before = json.loads((TMP / "fb.json").read_text(encoding="utf-8"))
MUS.reset_likes()
rows = MUS.listing()
check(not any(r["liked"] for r in rows) and not any(r["heard"] for r in rows), "איפוס: אין ❤ ואין \"נשמע\"")
check(MUS.summary(rows)["can_undo_reset"], "אפשר לבטל את האיפוס")
MUS.undo_reset()
after = json.loads((TMP / "fb.json").read_text(encoding="utf-8"))
check(after == before, "בטל — המשוב חזר בדיוק כמו לפני האיפוס")
check(not MUS.summary(MUS.listing())["can_undo_reset"], "אחרי ביטול — אין מה לבטל")

check(REAL_FB.read_bytes() == real_before, "הקובץ האמיתי שלו לא השתנה")
shutil.rmtree(TMP)
print("FAIL: %s" % fails if fails else "ALL OK")
sys.exit(1 if fails else 0)
