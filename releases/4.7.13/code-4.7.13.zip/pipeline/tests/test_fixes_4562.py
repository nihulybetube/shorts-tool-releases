# -*- coding: utf-8 -*-
"""בדיקות 4.5.62 — תיקוני "בדיקת מכלול" (אינטגרציה) של 4.5.61. הכול בתיקיות זמניות, בלי רשת, בלי לגעת בהגדרות האמיתיות.

הרצה:  python3 test_fixes_4562.py"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
REPO = HERE.parent.parent
T = Path(tempfile.mkdtemp(prefix="ys_fix4562_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg"), "SHORTS_DATA_DIR": str(T / "data"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_UPDATES": str(T / "data" / "updates.json"),
                   "MAKE_SHORT_UPDATE_NO_SELFTEST": "1"})
os.environ.pop("MAKE_SHORT_UPDATE_MODE", None)
(T / "home").mkdir()
sys.path.insert(0, str(SCRIPTS))
import make_short_release as R  # noqa: E402
import make_short_personal as PC  # noqa: E402
import make_short_update as UPD  # noqa: E402
import make_short_proposals as PROP  # noqa: E402

FAIL = []


def chk(c, w, d=""):
    print(("✓ " if c else "✗ ") + w + ("" if c else "  — " + str(d)[:400]), flush=True)
    if not c:
        FAIL.append(w)


def sh(cwd, *a, check=True):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if check and r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def gc(repo, msg):
    sh(repo, "git", "add", "-A")
    sh(repo, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", msg)


# ═════════ 1. shorts.sh: סימן trial (#2, #3) ושחזור מעדכון שנקטע (#10) ═════════
def trial_repo(name, final_version=None):
    d = T / name
    d.mkdir()
    sh(d, "git", "init", "-q", "-b", "main")
    shutil.copy(REPO / "shorts.sh", d / "shorts.sh")
    (d / "pipeline" / "scripts").mkdir(parents=True)
    (d / "VERSION").write_text("1.0.0\n")
    gc(d, "1.0.0")
    c1 = sh(d, "git", "rev-parse", "HEAD")
    sh(d, "git", "tag", "rel-1.0.0")
    (d / "pipeline/scripts/x.py").write_text("PERSONAL = 1\n")
    gc(d, "שינוי אישי: x [pc-0001]")
    p1 = sh(d, "git", "rev-parse", "HEAD")
    for v in ("1.1.0", "1.2.0", "1.3.0"):
        (d / "VERSION").write_text(v + "\n")
        gc(d, "עדכון לגרסה " + v)
        sh(d, "git", "tag", "rel-" + v)
    sh(d, "git", "tag", "-d", "rel-1.0.0")                       # עדכון של 3 גרסאות מוחק את התגית של הבסיס (KEEP_TAGS=3)
    if final_version:
        (d / "VERSION").write_text(final_version + "\n")
        gc(d, "התקנה מחבילה " + final_version)
    return d, c1, p1


def run_sh(d, data, *args):
    env = dict(os.environ, HOME=str(T / "home"), SHORTS_DATA_DIR=str(data), SHORTS_CONFIG_DIR=str(T / "cfg_sh"))
    return subprocess.run(["bash", str(d / "shorts.sh"), *args], capture_output=True, text=True, timeout=60, env=env)


data_a = T / "data_a"
ru = data_a / "release_updates"
ru.mkdir(parents=True)
d, c1, p1 = trial_repo("recv_a")
(ru / "trial").write_text("1.1.0 1.2.0 1.3.0\n%s\n%s\n0\n%s\n" % (p1, d, c1))
r1 = run_sh(d, data_a, "py", "make_short_app.py")           # ההפעלה הראשונה → --skip-update (אין venv → יוצא 3 אחרי הבלוק)
lines = (ru / "trial").read_text().split("\n") if (ru / "trial").exists() else []
chk(len(lines) >= 5 and lines[3] == "1" and lines[4] == c1, "trial: אחרי ההפעלה הראשונה המונה 1 והבסיס הרשמי נשמר בשורה 5", str(lines) + r1.stderr[-150:])
r2 = run_sh(d, data_a, "py", "make_short_app.py")           # השנייה → חזרה לבד
tags = sh(d, "git", "tag").split()
chk(sh(d, "git", "rev-parse", "HEAD") == p1, "trial #2: אחרי שתי הפעלות כושלות חוזרים ל-commit שלפני העדכון", r2.stderr[-200:])
chk(tags == ["rel-1.0.0"] and sh(d, "git", "rev-parse", "rel-1.0.0^{commit}") == c1,
    "trial #2: תגיות rel-1.1.0..1.3.0 נמחקו, ו-rel-1.0.0 הוחזרה על ה-commit הרשמי (לא על HEAD עם השינוי האישי)", str(tags))
chk((ru / "trial_failed").exists() and not (ru / "trial").exists(), "trial: trial_failed נכתב והסימן נמחק")
chk((d / "pipeline/scripts/x.py").exists() and (d / "VERSION").read_text().strip() == "1.0.0", "trial #2: השינוי האישי נשאר בקוד, הגרסה חזרה ל-1.0.0")

# #3: התקנה מחבילה מעל גרסה שלא עלתה — הסימן הישן לא מבטל את ההתקנה החדשה
data_b = T / "data_b"
rub = data_b / "release_updates"
rub.mkdir(parents=True)
d2, c1b, p1b = trial_repo("recv_b", final_version="9.9.9")
head_b = sh(d2, "git", "rev-parse", "HEAD")
(rub / "trial").write_text("1.1.0 1.2.0 1.3.0\n%s\n%s\n1\n%s\n" % (p1b, d2, c1b))        # כבר ניסיון אחד כושל
run_sh(d2, data_b, "py", "make_short_app.py")
chk(sh(d2, "git", "rev-parse", "HEAD") == head_b and (d2 / "VERSION").read_text().strip() == "9.9.9",
    "trial #3: סימן ישן + גרסה מותקנת אחרת (חבילה חדשה) — הקוד החדש לא מוחזר לאחור")
chk(not (rub / "trial").exists() and not (rub / "trial_failed").exists(), "trial #3: הסימן הישן נמחק ולא מדווח כשל")

# #10: שחזור מעדכון שנקטע ב-shorts.sh לבד משאיר עץ נקי (בלי .ysnew ובלי תגית היעד)
data_c = T / "data_c"
ruc = data_c / "release_updates"
ruc.mkdir(parents=True)
d3, c1c, p1c = trial_repo("recv_c")
sh(d3, "git", "reset", "-q", "--hard", p1c)
sh(d3, "git", "tag", "rel-2.0.0")
(d3 / "pipeline/scripts/.make_short_layout.py.ysnew").write_text("half")
(d3 / ".VERSION.ysnew").write_text("half")
(ruc / "pending.json").write_text(json.dumps({"base": p1c, "target": "2.0.0", "added": [], "removed": [], "from": "1.0.0"}))
(ruc / "pending.sha").write_text("%s\n%s\n999999999\nx\n" % (p1c, d3))
run_sh(d3, data_c, "py", "make_short_app.py")
chk(not (d3 / ".VERSION.ysnew").exists() and not (d3 / "pipeline/scripts/.make_short_layout.py.ysnew").exists(),
    "שחזור ב-bash: קבצי .ysnew נמחקו")
chk("rel-2.0.0" not in sh(d3, "git", "tag").split() and not (ruc / "pending.sha").exists(), "שחזור ב-bash: תגית היעד נמחקה והיומן נוקה")
chk(sh(d3, "git", "status", "--porcelain") == "", "שחזור ב-bash: העץ נקי")

# מתקין החבילה מנקה סימני עדכון ישנים
ins = (REPO / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig")
chk('release_updates' in ins and '/trial"' in ins and "pending.sha" in ins, "המתקין: מוחק trial / pending של הקוד שמוחלף")

# ═════════ 2. trial_begin + official_commit ═════════
sd = T / "sd_trial"
rr = T / "inst_t"
rr.mkdir()
sh(rr, "git", "init", "-q", "-b", "main")
(rr / "VERSION").write_text("1.0.0\n")
gc(rr, "v1")
sh(rr, "git", "tag", "rel-1.0.0")
off = R.official_commit(rr)
(rr / "x").write_text("p")
gc(rr, "שינוי אישי: x")
R.trial_begin(["1.1.0"], sh(rr, "git", "rev-parse", "HEAD"), repo=rr, sd=sd, official=off)
tl = (sd / "trial").read_text().split("\n")
chk(off and R.official_commit(rr) == off != sh(rr, "git", "rev-parse", "HEAD") and tl[4] == off and tl[3] == "0",
    "official_commit = התגית (לא HEAD עם שינוי אישי), ו-trial_begin שומר אותו בשורה 5", str(tl))
src = (SCRIPTS / "make_short_release.py").read_text(encoding="utf-8")
i_on, i_pc = src.index("on_installed(done)"), src.index("PC = _pc(repo) if done else None")
chk(i_on < i_pc, "run_updates: סימן ה-trial ו'מה השתנה' נכתבים לפני ההחלה מחדש של השינויים האישיים")

# ═════════ 3. שינויים אישיים: סיבה בעברית, "כבר נכלל", תלות, עקביות אחרי חזרה ═════════
A0 = "\n".join(["# a.py", ""] + ["def f%d():\n    return %d\n" % (i, i) for i in range(1, 31)] + ["", "TAIL = 'end'", ""])


def make_install(path):
    path.mkdir(parents=True)
    sh(path, "git", "init", "-q", "-b", "main")
    (path / "pipeline" / "scripts").mkdir(parents=True)
    (path / "VERSION").write_text("1.0.0\n")
    (path / "pipeline/scripts/a.py").write_text(A0, encoding="utf-8")
    (path / ".from_package").write_text("1.0.0")
    with open(path / ".git" / "info" / "exclude", "a") as f:
        f.write(".from_package\n")
    gc(path, "1.0.0")
    sh(path, "git", "tag", "rel-1.0.0")
    return path


def official(repo, version, a_text):
    tree = T / ("tree-" + version)
    shutil.rmtree(tree, ignore_errors=True)
    files = {"VERSION": version + "\n", "pipeline/scripts/a.py": a_text}
    m = {"version": version, "files": {}}
    for p, txt in files.items():
        f = tree / p
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(txt, encoding="utf-8")
        m["files"][p] = {"sha256": hashlib.sha256(txt.encode("utf-8")).hexdigest(), "mode": 0o644}
    return R.apply_release(tree, m, repo, T / "sd", check_fn=None, log=lambda s: None)


def box(repo, desc, old, new):
    txt = "תיאור: %s\n=== החלפה: pipeline/scripts/a.py ===\n<<<<<<< לפני\n%s\n=======\n%s\n>>>>>>> אחרי\n=== סוף החלפה ===\n" % (desc, old, new)
    UPD.REPO = repo
    UPD.selfcheck = lambda: True
    UPD.selftest_quick = lambda: True
    import io
    from contextlib import redirect_stdout
    with redirect_stdout(io.StringIO()):
        return UPD.apply(txt)


shutil.rmtree(PC.ROOT, ignore_errors=True)          # רישום נקי לכל תרחיש (הרישום אחד לכל המחשב)
repo = make_install(T / "inst")
rc = box(repo, "A: f3 מחזיר 33", "def f3():\n    return 3", "def f3():\n    return 33")
rc2 = box(repo, "C: f4 מחזיר 44", "def f4():\n    return 4", "def f4():\n    return 44  # שינוי אישי ארוך מספיק לזיהוי")
chk(rc == 0 and rc2 == 0, "שני שינויים סמוכים בתיבה הוחלו")
off_a = A0.replace("def f3():\n    return 3", "def f3():\n    return 3000").replace("def f4():\n    return 4", "def f4():\n    return 44  # שינוי אישי ארוך מספיק לזיהוי")
official(repo, "1.1.0", off_a)
res = PC.reapply(repo, lambda: (True, ""), log=lambda s: None)
st = {r["id"]: r for r in res["results"]}
a, c = st.get("pc-0001", {}), st.get("pc-0002", {})
chk(a.get("state") == "conflict" and "hint" not in a.get("reason", "").lower() and "disable this message" not in a.get("reason", "").lower()
    and any("֐" <= ch <= "׿" for ch in a.get("reason", "")), "#5: סיבת הקונפליקט בעברית, בלי שורת hint של git", a.get("reason"))
chk(c.get("state") == "absorbed", "#4: שינוי שהרשמי כבר כולל — 'כבר נכלל' גם כשקדם לו שינוי שנכשל באותו אזור", c)

# #4: כיבוי שינוי קודם לא מפיל סתם את הבא — ואם כן, הסיבה אומרת למה
shutil.rmtree(PC.ROOT, ignore_errors=True)
repo2 = make_install(T / "inst2")
box(repo2, "A: f3 מחזיר 33", "def f3():\n    return 3", "def f3():\n    return 33")
box(repo2, "C: f4 מחזיר 44", "def f4():\n    return 44".replace("44", "4"), "def f4():\n    return 44")
r_off = PC.set_enabled(repo2, "pc-0001", False, check_fn=lambda: (True, ""))
cs = next(x for x in PC.load()["changes"] if x["id"] == "pc-0002")
chk(cs["state"] == "applied" or "בנוי על גבי" in cs.get("reason", ""),
    "#4: כיבוי שינוי קודם — הבא נשאר פעיל, או שהסיבה מסבירה שהוא בנוי על גביו", cs)
chk("hint:" not in cs.get("reason", ""), "#5: גם בכיבוי אין שורת hint בסיבה", cs.get("reason"))

# #2: אחרי חזרה אוטומטית (אין תגית) — הבסיס הרשמי נמצא מתחת לשינויים, והרישום מתיישר עם הקוד
shutil.rmtree(PC.ROOT, ignore_errors=True)
repo3 = make_install(T / "inst3")
box(repo3, "A: f3 מחזיר 33", "def f3():\n    return 3", "def f3():\n    return 33")
c1_sha = sh(repo3, "git", "rev-parse", "rel-1.0.0^{commit}")
sh(repo3, "git", "tag", "-d", "rel-1.0.0")
reg = PC.load()
reg["changes"][0]["state"] = "conflict"
reg["changes"][0]["reason"] = "לא התמזג — הקוד הרשמי פועל"
PC.save(reg)
PC.startup_consistency(repo3)
tag_now = sh(repo3, "git", "rev-parse", "-q", "--verify", "rel-1.0.0^{commit}", check=False)
chk(tag_now == c1_sha and tag_now != sh(repo3, "git", "rev-parse", "HEAD"), "#2: התגית חזרה על ה-commit הרשמי, לא על HEAD שכולל שינוי אישי", tag_now)
chk(PC.load()["changes"][0]["state"] == "applied", "#2: שינוי שה-commit שלו בקוד מסומן שוב 'פעיל' (הרישום והקוד מסכימים)")

# ═════════ 4. גיבוי מוצפן של מפתח ההצעות (#8) ═════════
PROP._owner_keys(create=True)
before = PROP.OWNER_KEY.read_bytes()
chk(not PROP.backup_status()["has_backup"], "#8: לפני גיבוי — אין גיבוי")
try:
    PROP.backup_encrypt("short")
    chk(False, "#8: סיסמה קצרה נדחית")
except PROP.ProposalError:
    chk(True, "#8: סיסמה קצרה נדחית")
st_b = PROP.backup_encrypt("correct horse battery")
enc = PROP._backup_file().read_text(encoding="utf-8")
ej = json.loads(enc)
secret_x = json.loads(before)["x25519"]
chk(st_b["has_backup"] and not st_b["stale"] and secret_x not in enc and ej["kdf"] == "scrypt" and ej["ct"]
    and not any(k in ej for k in ("x25519", "ed25519", "key")), "#8: הקובץ המוצפן נוצר ואין בו את המפתח הפרטי בגלוי")
chk(oct(PROP._backup_file().stat().st_mode & 0o777) == "0o600", "#8: הרשאות 0600")
PROP.OWNER_KEY.write_text(json.dumps({"v": 1, "x25519": "changed", "ed25519": "changed"}))
chk(PROP.backup_status()["stale"], "#8: מפתח שהשתנה מאז הגיבוי → 'לגבות שוב'")
PROP.OWNER_KEY.write_bytes(before)
chk(not PROP.backup_status()["stale"], "#8: אחרי חזרה למפתח המקורי — עדכני")
saved_enc = PROP._backup_file().read_bytes()
PROP.OWNER_KEY.unlink()
try:
    PROP.backup_restore("wrong password!!")
    chk(False, "#8: סיסמה שגויה לא מפענחת")
except PROP.ProposalError as e:
    chk("שגויה" in str(e) and not PROP.OWNER_KEY.exists(), "#8: סיסמה שגויה לא מפענחת ולא כותבת כלום")
PROP.backup_restore("correct horse battery")
chk(PROP.OWNER_KEY.read_bytes() == before, "#8: שחזור במחשב חדש מחזיר בדיוק את המפתח")
try:
    PROP.backup_restore("correct horse battery")
    chk(False, "#8: שחזור לא דורס מפתח קיים")
except PROP.ProposalError:
    chk(PROP.OWNER_KEY.read_bytes() == before, "#8: שחזור לא דורס מפתח קיים")
chk("backup" in PROP.owner_status() and PROP.owner_status()["backup"]["has_backup"], "#8: מסך הבעלים מקבל את מצב הגיבוי")
bx = (REPO / "backup_extras.sh").read_text(encoding="utf-8")
chk("proposals_owner.enc" in bx and "proposals_owner.key" not in bx.replace("proposals_owner.key עצמו", ""),
    "#8: backup_extras מעלה רק את הקובץ המוצפן (לא את .key)")

# ═════════ 5. האפליקציה: שער הקוד אצל מקבל, pc_begin, הדף ═════════
probe = r'''
import os, sys, json
sys.path.insert(0, sys.argv[1])
import make_short_app as APP
out = {}
# מקבל עם HEAD בלי תגית: code_tree_ready מתיר (4.5.62 #6); בעץ בעלים — עדיין דורש תגית
import subprocess
repo = sys.argv[2]
APP.HERE = __import__("pathlib").Path(repo) / "pipeline" / "scripts"
APP.REL.update_mode = lambda r=None: "receiver"
out["receiver_ready"] = APP.code_tree_ready()[0]
APP.PCS["busy"] = True
out["receiver_busy"] = APP.code_tree_ready()[0]
APP.PCS["busy"] = False
APP.REL.update_mode = lambda r=None: "owner"
out["owner_untagged"] = APP.code_tree_ready()[0]
# pc_begin מסרב כשרצה עבודה מחוץ לחלון (#7)
APP.REL.update_mode = lambda r=None: "receiver"
APP.external_pipeline_running = lambda: True
try:
    APP.pc_begin("להפעיל", "x"); out["pc_begin_ext"] = "allowed"
except ValueError as e:
    out["pc_begin_ext"] = str(e)
APP.external_pipeline_running = lambda: False
try:
    APP.pc_begin("להפעיל", "x"); out["pc_begin_ok"] = "allowed"
except ValueError as e:
    out["pc_begin_ok"] = str(e)
print(json.dumps(out, ensure_ascii=False))
'''
rp = T / "recv_code"
make_install(rp)
(rp / "pipeline" / "scripts").mkdir(parents=True, exist_ok=True)
sh(rp, "git", "init", "-q", "-b", "main", check=False)
(rp / "extra.txt").write_text("personal\n")
gc(rp, "שינוי אישי: x")                                     # HEAD בלי תגית גרסה
penv = dict(os.environ, MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_IDLE_EXIT="0", PYTHONUNBUFFERED="1")
pr = subprocess.run([sys.executable, "-c", probe, str(SCRIPTS), str(rp)], capture_output=True, text=True, errors="replace", timeout=120, env=penv, cwd=str(T))
try:
    po = json.loads(pr.stdout.strip().splitlines()[-1])
except (ValueError, IndexError):
    po = {}
chk(po.get("receiver_ready") is True, "#6: מקבל עם HEAD של שינוי אישי (בלי תגית) — code_watch לא מחכה לתגית", pr.stdout[-200:] + pr.stderr[-300:])
chk(po.get("receiver_busy") is False, "#6: אבל לא באמצע החלה/כיבוי של שינוי אישי")
chk(po.get("owner_untagged") is False, "#6: בעץ הבעלים השער של 4.1.3 (commit בלי תגית) נשאר")
chk("מחוץ לחלון" in str(po.get("pc_begin_ext", "")), "#7: pc_begin מסרב כשרצה עבודה מחוץ לחלון", po.get("pc_begin_ext"))
chk(po.get("pc_begin_ok") == "allowed", "#7: ובלי עבודה חיצונית — מותר", po.get("pc_begin_ok"))

page = (SCRIPTS / "make_short_page.html").read_text(encoding="utf-8")
chk("relJust(REL.just_updated,recHtml)" in page and "function relJust(j,pre)" in page,
    "#9: הודעת 'חזרנו' לא מוחקת את 'מה השתנה' — שתיהן נפתחות יחד")
chk("relRollback()" in page[page.index("function relJust"):page.index("/* ───── 4.5: 🧩")], "#10: כפתור 'חזור לגרסה הקודמת' בחלון 'מה השתנה' (גם בתצוגה הפשוטה)")
chk('id="propBackup"' in page and "propOwnBackup" in page and "/api/proposals/owner/backup" in page, "#8: כרטיס גיבוי המפתח במסך הבעלים")
app_src = (SCRIPTS / "make_short_app.py").read_text(encoding="utf-8")
chk('op == "backup"' in app_src and "PC_RESTART_NOTE" in app_src and "ופועל." not in app_src[app_src.index('"/api/personal/enable"'):app_src.index('"/api/personal/giveup"')],
    "#6: הודעות הפעלה/כיבוי אומרות שצריך הפעלה מחדש (לא 'ופועל' כשלא)")
chk("app_version=pc_ver" in app_src and "def proposal_base_version" in (SCRIPTS / "make_short_personal.py").read_text(encoding="utf-8"),
    "#10: הצעה משינוי אישי נושאת את גרסת הבסיס שלו ובלי תוצאת בדיקה כללית")
chk(PC.proposal_base_version("pc-9999") == "", "#10: proposal_base_version של שינוי לא קיים — ריק")
sh_src = (REPO / "shorts.sh").read_text(encoding="utf-8")
chk("2>/dev/null < \"$c\"" in sh_src, "#10: אין רעש /proc/…/cmdline בחלון השחור")


# ═════════ 6. הדרכות למשתמש שאינו מתכנת (בדיקת הדרכות 4.5.61) ═════════
import make_short_health as HE  # noqa: E402
cs = "\n".join(HE.COOKIE_STEPS)
chk("chromewebstore.google.com/detail/cclelndahbckbenkjhflpdbgdldlbecc" in cs and "Ctrl+Shift+N" in cs and "Allow in Incognito" in cs
    and "chrome://extensions" in cs and "🧩" in cs and "Netscape" in cs and "LOCALLY" in cs and "מתחזה" in cs and "לא שולחים לאף אחד" in cs,
    "עוגיות: קישור ישיר לתוסף, אזהרת מתחזים, אישור גלישה בסתר, Ctrl+Shift+N, סמל הפאזל, פורמט, 'לא לשלוח'")
chk("לא נראה כמו קובץ עוגיות" in cs and "JSON" in cs and "JSON" in HE.COOKIE_REJECT_NOTE and "Netscape" in HE.COOKIE_REJECT_NOTE,
    "עוגיות: מה לעשות כשהקובץ נדחה (שלב בהוראות + הסבר בהודעה)")
HE._run = lambda cmd, timeout=30: (0, "{}" if "dump" in cmd else "")
HE.RCLONE = "/bin/true"
HE.own_key_trusted = lambda *a, **k: False
HE.rclone_conf = lambda *a, **k: ""
dres = HE.check_drive(True)
ds = "\n".join(dres.get("steps", []))
chk("sites.google.com" in ds and "Test users" in ds and "Contact Information" in ds and "Publish (פרסום)" in ds and "(הפעלה)" in ds
    and "github.io" not in ds and "GitHub Pages" not in ds and "Ctrl+Shift+C" not in ds and "לא נבדקו מול חשבון אמיתי" in ds,
    "Drive: דף בית בלי GitHub (Google Sites), תוכנית ב' (Test users), סדר מסכי Get started, בלי Ctrl+Shift+C, וסימון 'לא אומת'", ds[:300])
chk("Configure this as a Shared Drive? ← n" in ds, "Drive: תשובות חלון שחור לפי הסדר (y/y/n/y) — לא 'בכל שאלה Enter'")
page = (SCRIPTS / "make_short_page.html").read_text(encoding="utf-8")
chk("בכל שאלה בו Enter" not in page and "מפתח משותף" in page and "מפתח גוגל אישי" in page, "צעדים ראשונים: כרטיס הדרייב לא אומר 'בכל שאלה Enter' ומפנה למפתח אישי")
chk("Workspace budget" in page and "Usage &amp; Billing" in page and "באנגלית בלבד" in page, "Modal: שמות המסכים המדויקים (Usage & Billing / Workspace budget), האתר באנגלית")
chk("Create API key in new project" in page and "Copy (העתקה)" in page and "403" in page and "18+" in page, "Gemini: בחירת פרויקט, Copy, 403, גיל 18+")
chk("Topic name" in page and "Subscribe" in page and "אופטימיזציית סוללה" in page and "Philipp Heckel" in page, "ntfy: התקנת האפליקציה, Topic name, Subscribe, אם ההתראה לא מגיעה")
ins2 = (REPO / "windows" / "install_windows.ps1").read_text(encoding="utf-8-sig")
pkgdrive = ins2[ins2.index("if ($Pkg -and -not $SkipDrive) {"):ins2.index("if ($SkipDrive) { if (-not $Pkg)")]
chk("צעדים ראשונים" in pkgdrive and "Read-Host" not in pkgdrive and "$SkipDrive = $true" in pkgdrive,
    "המתקין (חבילה): לא מחבר דרייב דרך המפתח המשותף — מפנה ל'צעדים ראשונים'")
chk("ראו במדריך" not in ins2 and "Ctrl+C, ואפשר" not in ins2 and "modal.com" in ins2 and "לדלג" in ins2, "המתקין: Modal — אין 'ראו במדריך' ו-Ctrl+C; יש דילוג מפורש והסבר הרשמה")
chk("הגדרות מתקדמות ← מפתח Gemini" not in ins2 and "צעדים ראשונים" in ins2.split("מה נשאר")[1], "המתקין: הסיכום מפנה ל'צעדים ראשונים' (לא להגדרות מתקדמות שמוסתרות בפשוט)")
import make_short_share as SHR  # noqa: E402
rd = SHR.readme({"made": "x", "commit": "y", "music_tracks": 3, "profile": None, "drive_offer": True})
chk("ההתקנה מסבירה" not in rd and "צעדים ראשונים" in rd and "modal.com" in rd and "כרטיס אשראי" in rd, "'קרא אותי': מפנה ל'צעדים ראשונים', אומר להירשם ל-Modal לפני")
chk("בלי כרטיס אשראי" not in (REPO / "setup" / "setup.py").read_text(encoding="utf-8") and "בלי כרטיס אשראי" not in (REPO / "README.md").read_text(encoding="utf-8"),
    "Modal: 'בלי כרטיס אשראי' (שגוי) הוסר מהתוכנה ומה-README")
hsrc = (SCRIPTS / "make_short_health.py").read_text(encoding="utf-8")
chk("דוח התקלה" not in hsrc and "(או לClaude)" not in hsrc and "מתוך Claude" not in hsrc and "🧹 נקה" in hsrc and "התקנה.bat" in hsrc,
    "הודעות תקלה: שם הכפתור 'העתק פרטים לעוזר', 'התקנה.bat', ו-'🧹 נקה' (בלי Claude)")
chk("זה בדיוק מה שתקרת ההוצאה נועדה" in hsrc, "Modal: הגעתם לתקרה — 'זה בסדר, זה מה שהיא נועדה לעשות'")
probe2 = r'''
import sys, json
sys.path.insert(0, sys.argv[1])
import make_short_app as APP
bot = APP.job_alert("cookies", {"title": "t", "log": ["ERROR: [youtube] x: Sign in to confirm you're not a bot. Use --cookies"], "error": ""})
priv = APP.job_alert("cookies", {"title": "t", "log": ["ERROR: Private video. Sign in if you've been granted access"], "error": ""})
print(json.dumps({"bot_title": bot["title"], "bot_steps": bot["steps"], "priv_title": priv["title"], "priv_steps": len(priv["steps"])}, ensure_ascii=False))
'''
pr2 = subprocess.run([sys.executable, "-c", probe2, str(SCRIPTS)], capture_output=True, text=True, errors="replace", timeout=120, env=penv, cwd=str(T))
try:
    p2 = json.loads(pr2.stdout.strip().splitlines()[-1])
except (ValueError, IndexError):
    p2 = {}
chk("רובוט" in p2.get("bot_title", "") and "פגו" not in p2.get("bot_title", "") and "פגו" in p2.get("priv_title", ""),
    "'לא רובוט' מוצג כ'לא רובוט' (לא 'העוגיות פגו'); התחברות/פרטי — עדיין עוגיות", pr2.stdout[-300:] + pr2.stderr[-300:])
chk("שיעור ציבורי" in " ".join(p2.get("bot_steps", [])) and "🍪" in " ".join(p2.get("bot_steps", [])), "'לא רובוט': הנחיה אחת כמו ב'צעדים ראשונים' (ציבורי — לחכות/רשת אחרת; מתוזמן — עוגיות)")

shutil.rmtree(T, ignore_errors=True)
print("\n%s" % ("✅ הכול עבר" if not FAIL else "❌ נכשלו: " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
