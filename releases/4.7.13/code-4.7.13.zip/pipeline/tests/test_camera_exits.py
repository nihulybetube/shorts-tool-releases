# -*- coding: utf-8 -*-
"""בדיקה: "הרב יוצא מהמסגרת" + מצלמה זריזה (כרטיס 22, 28/10/2026). בלי וידאו ובלי רשת — מסלולי פנים סינתטיים.
  1. רב שיושב בנוחות בפנים: זריזה = רגילה בדיוק (מערך זהה) — היא לא מצלמה קופצנית, רק מאיצה ליד הקצה.
  2. רב שקופץ חצי קרופ הצידה: הרגילה משאירה אותו בחוץ שניות; הזריזה תופסת אותו, בלי לעבור את תקרת המהירות.
  3. measure: רצף של שנייה ומעלה נספר, דגימה בודדת לא; הזמנים ממופים לזמן הקליף (אחרי ה-crossfade בין חתיכות).
  4. cam_env מוחק מצלמה קודמת; load_status פג כשה-raw משתנה או כשהקליף נבנה במצלמה אחרת.
  5. ההגדרות: exit_fix / camera_default מקבלות רק ערכים מוכרים.
הרצה: shorts.sh py pipeline/tests/test_camera_exits.py"""
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import camera_path as CP  # noqa: E402
import face_track as F  # noqa: E402
import make_short_settings as SET  # noqa: E402

fails = []
FPS = F.SAMPLE_FPS
W = 0.3164


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg)
    if not cond:
        fails.append(msg)


def cam(target, zippy):
    F.ZIPPY = zippy
    try:
        return F.virtual_camera(np.asarray(target, dtype=float), FPS)[0]
    finally:
        F.ZIPPY = False


def out_sec(face, c):
    return float((np.abs(np.asarray(face) - c) / W > 0.5).sum()) / FPS


print("1. רב רגוע — זריזה זהה לרגילה")
rng = np.random.default_rng(7)
calm = 0.5 + 0.02 * np.sin(np.arange(120) / 6.0) + rng.normal(0, 0.004, 120)
check(np.array_equal(cam(calm, False), cam(calm, True)), "בתוך אזור המת: אותו מסלול בדיוק")
lean = np.r_[np.full(30, 0.5), np.full(10, 0.55), np.full(40, 0.5)]           # רכינה קצרה לספר וחזרה
check(np.array_equal(cam(lean, False), cam(lean, True)), "רכינה קצרה (0.05, 5 שניות): אותו מסלול")

print("2. רב שקופץ חצי קרופ הצידה")
jump = np.r_[np.full(20, 0.5), np.linspace(0.5, 0.68, 4), np.full(40, 0.68), np.linspace(0.68, 0.45, 4), np.full(30, 0.45)]
d, z = cam(jump, False), cam(jump, True)
check(out_sec(jump, d) >= 2.0, "רגילה: בחוץ %.1f שניות (המצב שהוא ראה)" % out_sec(jump, d))
check(out_sec(jump, z) <= 0.5, "זריזה: בחוץ %.1f שניות" % out_sec(jump, z))
peak = float(np.abs(np.diff(z)).max()) * FPS
check(peak <= F.Z_PAN_RATE + 1e-9, "זריזה: מהירות שיא %.3f ≤ התקרה %.3f" % (peak, F.Z_PAN_RATE))
check(float((np.abs(np.diff(z[-20:])) < 1e-4).mean()) > 0.8, "זריזה: אחרי שהרב נרגע — המצלמה עומדת")

print("3. measure")
t = np.arange(40) / FPS
face = np.full(40, 0.5)
face[10:14] = 0.72            # שתי שניות בחוץ
face[25] = 0.72               # דגימה בודדת — לא נספרת כרצף
sim = {"t": t, "face": face, "h": np.full(40, 60.0), "cam": np.full(40, 0.5), "moves": 0, "W": W, "aw": 640,
       "segs": [[0.5, 10.5], [11.0, 20.0]]}
m = CP.measure(sim)
check(len(m["runs"]) == 1 and m["warn_sec"] == 2.0, "רצף אחד של 2 שניות (%s)" % m["runs"])
check(abs(m["runs"][0][0] - 4.5) < 0.01, "שנייה 5.0 ב-raw = 4.5 בקליף (חצי שנייה ריפוד בהתחלה) — %s" % m["runs"][0][0])
sim2 = dict(sim, face=np.where(t > 12, 0.72, 0.5))
m2 = CP.measure(sim2)
check(abs(m2["runs"][0][0] - (10.0 + 1.5 - 0.18)) < 0.6, "אחרי מעבר בין חתיכות: הזמן ממופה עם ה-crossfade (%s)" % m2["runs"][0][0])
check(CP.fmt_runs([[9.5, 13], [21.5, 23.5]]) == "0:09 · 0:21", "fmt_runs")
check(m["moves"] == 0 and m["travel"] == 0.0 and m["still_pct"] == 100, "מצלמה עומדת = 0 תנועה")

print("4. cam_env / load_status")
env = CP.cam_env({"CAM_SMOOTH": "7", "X": "1"}, "zippy")
check(env.get("CAM_ZIPPY") == "1" and "CAM_SMOOTH" not in env and env["X"] == "1", "זריזה מוחקת את החלקה")
check("CAM_ZIPPY" not in CP.cam_env({"CAM_ZIPPY": "1"}, "default") and "CAM_SMOOTH" not in CP.cam_env({}, None),
      "רגילה = בלי משתני מצלמה (אותה בנייה כמו תמיד)")
with tempfile.TemporaryDirectory() as td:
    os.makedirs(os.path.join(td, "work/clips"))
    raw = os.path.join(td, "work/clips/clip1_raw.mp4")
    open(raw, "wb").write(b"x" * 100)
    st = {"key": CP._raw_key(td, "clip1"), "camera": "default",
          "cur": {"warn_sec": 3.0, "runs": [[9.5, 12.5]]}, "zippy": {"warn_sec": 0.0}}
    json.dump(st, open(os.path.join(td, "work/clips/clip1_exits.json"), "w"))
    d = CP.load_status("clip1", "default", td)
    s = CP.summary(d)
    check(s and s["sec"] == 3.0 and s["zippy_sec"] == 0.0 and s["times"] == "0:09", "סיכום לכרטיס: %s" % s)
    check(CP.load_status("clip1", "zippy", td) is None, "נבנה מאז במצלמה אחרת → פג")
    time.sleep(1.1)
    open(raw, "wb").write(b"y" * 120)
    check(CP.load_status("clip1", "default", td) is None, "ה-raw נבנה מחדש → פג")

print("5. הגדרות")
check(SET.DEFAULTS.get("exit_fix") == "offer" and SET.DEFAULTS.get("camera_default") == "default",
      "ברירות מחדל: להציע, מצלמה רגילה")
for k, good, bad in (("exit_fix", "auto", "always"), ("camera_default", "zippy", "fast")):
    check(SET.clean(k, good) == good, "%s=%s מתקבל" % (k, good))
    try:
        SET.clean(k, bad)
        check(False, "%s=%s נדחה" % (k, bad))
    except ValueError:
        check(True, "%s=%s נדחה" % (k, bad))

print("\n%s" % ("✅ הכול עבר" if not fails else "❌ %d נכשלו" % len(fails)))
sys.exit(1 if fails else 0)
