# -*- coding: utf-8 -*-
"""בדיקות לתקרת Modal ליום (22/10/2026) ולהעברת modal_confirm_usd הישן.
מריצים: shorts.sh py ../tests/test_modal_day.py — הכול בתיקייה זמנית, בלי לגעת בהגדרות שלו."""
import json
import os
import sys
import tempfile
from pathlib import Path

T = Path(tempfile.mkdtemp(prefix="ys_md_"))
os.environ["MAKE_SHORT_SETTINGS"] = str(T / "settings.json")
os.environ["MAKE_SHORT_MODAL_DAY"] = str(T / "modal_day.json")
os.environ.pop("MAKE_SHORT_SETTINGS_SNAP", None)
os.environ.pop("MAKE_SHORT_MODAL_OK", None)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import make_short_settings as SET  # noqa: E402
import make_short_modal_day as MD  # noqa: E402

fails = 0


def ok(cond, what):
    global fails
    print(("✓ " if cond else "✗ ") + what)
    fails += 0 if cond else 1


# 1. ההגדרה הישנה עוברת כמו שהיא
(T / "settings.json").write_text(json.dumps({"values": {"modal_confirm_usd": 2, "music_on": False}}), encoding="utf-8")
ok(SET.load()["modal_day_cap"] == 2.0, "modal_confirm_usd=2 → modal_day_cap=2")
ok("modal_confirm_usd" not in SET.load(), "המפתח הישן לא נשאר בערכים")
SET.update({"music_on": True})
raw = json.loads((T / "settings.json").read_text(encoding="utf-8"))["values"]
ok(raw.get("modal_day_cap") == 2.0 and "modal_confirm_usd" not in raw, "בכתיבה הבאה הקובץ נשמר עם המפתח החדש")
SET.reset(["modal_day_cap"])
ok(SET.load()["modal_day_cap"] == 1.0, "איפוס → $1")
SET.undo()
ok(SET.load()["modal_day_cap"] == 2.0, "ביטול האיפוס → $2")
ok(SET.clean("modal_day_cap", "1.234") == 1.23 and SET.clean("modal_day_cap", 99) == 30.0, "ניקוי: סנטים ותקרה 30")
ok(SET.clean("asr_engine", "cpu") == "cpu", "מנוע: cpu מתקבל")
try:
    SET.clean("asr_engine", "gpu")
    ok(False, "מנוע לא מוכר נדחה")
except ValueError:
    ok(True, "מנוע לא מוכר נדחה")

# 2. התקרה ליום
SET.update({"modal_day_cap": 1.0})
ok(MD.check(0.5)[0], "היום $0 + $0.5 ≤ $1 → בלי לשאול")
MD.record(0.7, "עבודה א")
okc, info = MD.check(0.25)
ok(okc and abs(info["spent"] - 0.7) < 1e-9, "היום $0.7 + $0.25 ≤ $1 → בלי לשאול")
okc, info = MD.check(0.4)
ok(not okc, "היום $0.7 + $0.4 > $1 → שואל")
ok(info["text"] == "היום כבר: $0.70 · הפעולה: ~$0.40 · התקרה: $1.00", "שלושת המספרים: " + info["text"])
MD.set_billing(0.9)
ok(abs(MD.view()["spent"] - 0.9) < 1e-9, "דוח Modal גבוה מההערכות → הוא קובע")
MD.set_billing(0.1)
ok(abs(MD.view()["spent"] - 0.7) < 1e-9, "דוח Modal נמוך (באיחור) → ההערכות קובעות")
SET.update({"modal_day_cap": 0})
ok(not MD.check(0.001)[0], "תקרה 0 → תמיד לשאול")
SET.update({"modal_day_cap": 1.0})

# 3. gate: נעצר בלי לרשום; עם אישור — נרשם וממשיך
before = MD.view()["est_sum"]
try:
    MD.gate(0.5, "גדולה")
    ok(False, "gate מעל התקרה עוצר")
except MD.OverCap as e:
    ok("תקרת Modal היומית" in str(e) and MD.view()["est_sum"] == before, "gate מעל התקרה עוצר ולא רושם")
os.environ["MAKE_SHORT_MODAL_OK"] = "1"
MD.gate(0.5, "אושרה")
ok(abs(MD.view()["est_sum"] - (before + 0.5)) < 1e-9, "עם אישור — נרשם")
os.environ.pop("MAKE_SHORT_MODAL_OK")

# 4. יום חדש מתאפס
d = json.loads((T / "modal_day.json").read_text(encoding="utf-8"))
d["day"] = "2000-01-01"
(T / "modal_day.json").write_text(json.dumps(d), encoding="utf-8")
ok(MD.view()["spent"] == 0, "יום חדש → מתחיל מאפס")

# 5. עבודה מצילום הגדרות קוראת את התקרה החיה
snap = T / "snap.json"
snap.write_text(json.dumps({"values": dict(SET.load(), modal_day_cap=0.1), "snapshot_of": str(T / "settings.json")}), encoding="utf-8")
os.environ["MAKE_SHORT_SETTINGS_SNAP"] = str(snap)
SET.update({"modal_day_cap": 1.5})
ok(MD.cap() == 1.5, "בצילום הגדרות — התקרה בתוקף היא זו שבהגדרות עכשיו")
os.environ.pop("MAKE_SHORT_SETTINGS_SNAP")

print("\n%s" % ("הכול עבר ✓" if not fails else "%d נכשלו" % fails))
import shutil  # noqa: E402
shutil.rmtree(T, ignore_errors=True)
sys.exit(1 if fails else 0)
