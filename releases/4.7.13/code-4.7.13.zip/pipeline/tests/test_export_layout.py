# -*- coding: utf-8 -*-
"""בדיקה: מבנה תיקיית השורטסים (כרטיס 16, 22/10/2026). בלי רשת ובלי וידאו אמיתי — קבצי mp4 מזויפים
בתיקייה זמנית; היומן (exports.jsonl) — זמני גם הוא. אף פעם לא נוגע ב-~/Videos/Shorts.
  1. שמות: רב/סדרה נקיים מהכותרת, שם כמעט זהה לתיקייה קיימת נכנס אליה (מירכאות, שליט"א, הרה"ג, רווחים).
  2. רב חדש / סדרה חדשה — נפתחות תיקיות בשם נקי, במקום הנכון.
  3. ייצוא: <הרב>/<הסדרה>/<כותרת>/ ובה רק הסרטון ו«תיאור להעתקה.txt»; שמירה חוזרת — אותה תיקייה;
     כותרת שהשתנתה — שינוי שם, בלי עותק שני; שתי כותרות זהות — " (2)"; תווים אסורים / נתיב ארוך.
הרצה: python3 pipeline/tests/test_export_layout.py"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(HERE))
import make_short as MS  # noqa: E402
import shorts_layout as SL  # noqa: E402

fails = []


def check(cond, msg, extra=""):
    print(("  ✓ " if cond else "  ✗ ") + msg + (("  ← " + str(extra)) if (extra and not cond) else ""))
    if not cond:
        fails.append(msg)


print("1. שמות מהכותרת")
check(MS.guess_names("מידת החסידות | שיעורים במסילת ישרים | הרה\"ג זלמן ברוך מלמד שליט\"א")
      == ("הרב זלמן ברוך מלמד", "שיעורים במסילת ישרים"), "הרה\"ג … שליט\"א → הרב …")
check(SL.clean_rabbi("'הרב   יהודה  מלמד'") == "הרב יהודה מלמד", "מירכאות ורווחים כפולים")
check(SL.clean_rabbi("יהודה מלמד") == "הרב יהודה מלמד", "שם בלי תואר → \"הרב …\"")
check(SL.clean_rabbi("הגאון הרב חיים כץ זצ\"ל") == "הרב חיים כץ", "הגאון הרב … זצ\"ל")
check(SL.clean_series('יסודות ועיונים בש"ס') == "יסודות ועיונים בשס", "גרשיים אסורים בחלונות — יורדים")
check(SL.clean_series("שאלה: למה?") == "שאלה למה", "נקודתיים וסימן שאלה — יורדים")

with tempfile.TemporaryDirectory(prefix="ys16_") as td:
    T = Path(td)
    root = T / "Shorts"
    (root / "הרב זלמן ברוך מלמד" / "יסודות ועיונים בשס").mkdir(parents=True)
    (root / "הרב חיים כץ" / "פרשת השבוע").mkdir(parents=True)

    print("2. התאמה לתיקייה קיימת")
    for typed in ("הרב זלמן ברוך מלמד", "הרה\"ג זלמן ברוך מלמד שליט\"א", "הרב  זלמן  ברוך מלמד", "זלמן ברוך מלמד"):
        r, s = SL.resolve_names(root, typed, 'יסודות ועיונים בש"ס')
        check((r, s) == ("הרב זלמן ברוך מלמד", "יסודות ועיונים בשס"), "«%s» → התיקייה הקיימת" % typed, (r, s))
    r, s = SL.resolve_names(root, "הרב חיים כץ", "פרשת  השבוע ")
    check(s == "פרשת השבוע", "סדרה עם רווח כפול → הקיימת", s)

    print("3. רב חדש / סדרה חדשה")
    r, s = SL.resolve_names(root, "הרה\"ג משה  כהן שליט\"א", "\"הלכות שבת\"")
    check((r, s) == ("הרב משה כהן", "הלכות שבת"), "רב חדש — שם נקי", (r, s))
    r, s = SL.resolve_names(root, "הרב חיים כץ", "כלי יקר")
    check((r, s) == ("הרב חיים כץ", "כלי יקר"), "סדרה חדשה אצל רב קיים", (r, s))

    print("4. ייצוא במבנה החדש")
    ledger = T / "exports.jsonl"
    env = dict(os.environ, SHORTS_EXPORT_DIR=str(root), SHORTS_EXPORT_LEDGER=str(ledger))

    def project(name, clips):
        P = T / "projects" / name
        for cid, title, size in clips:
            d = P / "shorts" / cid
            d.mkdir(parents=True, exist_ok=True)
            for f in d.glob("*.mp4"):
                f.unlink()
            (d / "video_music.mp4").write_bytes(b"x" * size)
            (d / "meta.json").write_text(json.dumps({"title": title, "description": "תיאור של " + title,
                                                     "tags": ["הרב משה כהן", "שבת"]}, ensure_ascii=False),
                                         encoding="utf-8")
        return P

    def export(P, to, known=None):
        args = [sys.executable, str(HERE / "export_clips.py"), "--project", str(P), "--to", str(to)]
        if known is not None:
            kf = T / "known.json"
            kf.write_text(json.dumps(known, ensure_ascii=False), encoding="utf-8")
            args += ["--known", str(kf)]
        r = subprocess.run(args, capture_output=True, text=True, env=env)
        line = [ln for ln in r.stdout.splitlines() if ln.startswith("EXPORT_DIRS=")]
        return r.returncode, (json.loads(line[0][12:]) if line else {}), r.stdout + r.stderr

    P = project("2026-10-22_lesson-AAA", [("clip1", "למה שבת? | הרב משה כהן", 100),
                                         ("clip2", "למה שבת? | הרב משה כהן", 200),
                                         ("clip3", "שמירת שבת: הלכה למעשה. | הרב משה כהן", 300)])
    rc, dirs, out = export(P, "הרה\"ג משה כהן שליט\"א/הלכות שבת")      # יחסי + שם "מלוכלך"
    check(rc == 0, "ייצוא עבר", out[-400:])
    sdir = root / "הרב משה כהן" / "הלכות שבת"
    check(sdir.is_dir(), "נפתחה <הרב משה כהן>/<הלכות שבת> (שם נקי)", sorted(p.name for p in root.iterdir()))
    names = sorted(Path(d).name for d in dirs.values())
    check(names == ["למה שבת", "למה שבת (2)", "שמירת שבת הלכה למעשה"], "תיקייה לכל שורט; כותרת זהה → (2)", names)
    files = sorted(str(f.relative_to(root)) for f in root.rglob("*") if f.is_file())
    check(all(len(Path(f).parts) == 4 for f in files), "עומק 4: רב/סדרה/כותרת/קובץ", files)
    inside = sorted(f.name for f in Path(dirs["clip1"]).iterdir())
    check(inside == ["למה שבת   הרב משה כהן.mp4", "תיאור להעתקה.txt"], "בתיקייה רק הסרטון והתיאור", inside)

    # שמירה חוזרת (Claude, בלי מצב — לפי היומן) → אותן תיקיות
    rc, dirs2, out = export(P, sdir)
    check(dirs2 == dirs, "ייצוא חוזר — אותן תיקיות, בלי (3)", dirs2)
    # שמירה חוזרת מהתוכנה, הכותרת של clip2 השתנתה → שינוי שם, לא עותק שני
    for old in (P / "shorts").glob("clip2_*"):            # כמו finish: הטיוטה הקודמת הצידה
        old.rename(T / ("parked_" + old.name))
    project("2026-10-22_lesson-AAA", [("clip2", "שבת שלום | הרב משה כהן", 222)])
    rc, dirs3, out = export(P, sdir, known=dirs2)
    check(rc == 0 and Path(dirs3["clip2"]).name == "שבת שלום", "כותרת חדשה → שם תיקייה חדש", dirs3.get("clip2"))
    check(not Path(dirs2["clip2"]).exists(), "התיקייה בשם הישן לא נשארה (שינוי שם, לא עותק)")
    vids = sorted(f.name for f in sdir.rglob("*.mp4"))
    check(len(vids) == 3, "3 סרטונים בדיוק בסדרה", vids)
    parked = list((P / "work").glob("replaced_*/**/*.mp4"))
    check(len(parked) == 1, "הקובץ בשם הכותרת הישנה — בתיקיית העבודה, לא נמחק", parked)

    # פרויקט אחר עם אותה כותרת → (2), לא דורס
    P2 = project("2026-10-23_lesson-BBB", [("clip1", "שבת שלום | הרב משה כהן", 50)])
    rc, d2, out = export(P2, sdir)
    check(Path(d2.get("clip1", "")).name == "שבת שלום (2)", "שורט אחר בשם זהה → (2)", d2)
    check((Path(dirs3["clip2"]) / "שבת שלום   הרב משה כהן.mp4").stat().st_size == 222, "המקורי לא נדרס")

    # יעד בלי סדרה → שגיאה ברורה
    rc, _, out = export(P2, "הרב משה כהן")
    check(rc == 2 and "<הרב>/<הסדרה>" in out, "יעד בלי סדרה — מסורב עם הסבר")

    print("5. נתיב ארוך לחלונות")
    long_t = "א" * 140 + " | הרב משה כהן"
    d = SL.short_dir(sdir, long_t, MS_file := (SL.tidy("א" * 140) + "   הרב משה כהן.mp4"))
    check(SL.win_len(d / MS_file) <= SL.MAX_WIN_PATH or len(d.name) <= 20, "תיקייה מתקצרת עד שהנתיב נכנס",
          SL.win_len(d / MS_file))
    check(SL.folder_name("שאלה? \"תשובה\". | הרב") == "שאלה תשובה", "תווים אסורים ונקודה בסוף")

    # 31/10: כותרת של 250 תווים — גם שם הקובץ מתקצר (קודם התיקייה לבדה ירדה ל-20 והנתיב נשאר ארוך מדי → OSError)
    huge = "ב" * 250 + " | הרב משה כהן"
    deep = sdir.parent / ("סדרה " + "ס" * 70)
    import export_clips as EC
    fname = EC.sanitize_filename(huge) + ".mp4"
    tdir = SL.short_dir(deep, huge, fname)
    fitted = SL.fit_file_name(tdir, fname)
    check(SL.win_len(tdir / fitted) <= SL.MAX_WIN_PATH, "כותרת של 250 תווים: הנתיב המלא לקובץ נכנס", SL.win_len(tdir / fitted))
    check(fitted.endswith(".mp4") and fitted.startswith("ב" * 20), "שם הקובץ התקצר, הסיומת והתחלת הכותרת נשארו", fitted[:30])
    check(SL.fit_file_name(tdir, "קצר.mp4") == "קצר.mp4", "שם קצר לא משתנה")
    PL = project("2026-10-24_lesson-LONG", [("clip1", huge, 77)])
    rc, dl, out = export(PL, deep)
    saved = list(Path(dl.get("clip1", "/nonexistent")).glob("*.mp4"))
    check(rc == 0 and len(saved) == 1 and saved[0].stat().st_size == 77 and SL.win_len(saved[0]) <= SL.MAX_WIN_PATH,
          "ייצוא אמיתי עם כותרת של 250 תווים: הקובץ הועתק והנתיב בטווח", out[-300:])

    print("6. ניקוי תיקיות ריקות")
    e = root / "הרב ריק" / "סדרה ריקה"
    e.mkdir(parents=True)
    SL.prune_empty(e, root)
    check(not (root / "הרב ריק").exists() and root.is_dir(), "סדרה+רב ריקים ירדו, השורש נשאר")

print("7. reorganize_exports — תוכנית וביצוע על עץ מזויף")
with tempfile.TemporaryDirectory(prefix="ys16r_") as td:
    T = Path(td)
    root, projects = T / "Shorts", T / "projects"
    env = dict(os.environ, SHORTS_EXPORT_DIR=str(root), SHORTS_PROJECTS=str(projects),
               SHORTS_EXPORT_LEDGER=str(T / "exports.jsonl"), REORG_NO_DRIVE="1")

    def put(rel, data=b"v"):
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        return p
    L = "הרב א/סדרה/2026-10-01_lesson-X/shorts"
    put(L + "/clip1_כותרת אחת/כותרת אחת   הרב א.mp4", b"1" * 11)
    put(L + "/clip1_כותרת אחת/תיאור להעתקה.txt")
    put(L + "/clip2_כותרת שתיים/בוצע כבר.mp4", b"2" * 22)         # שם שהוא שינה (סימון)
    put(L + "/clip2_כותרת שתיים/video_music_music.wav")           # שארית — נשארת
    put("הרב א/סדרה/א. קבוצה שלו/וישלח/shorts/clip1_כותרת אחת/כותרת אחת   הרב א.mp4", b"3" * 33)
    put("הרב א/סדרה/2026-10-01_lesson-X/gemini/log.txt")
    pr = projects / "2026-10-01_lesson-X" / "shorts" / "clip2_כותרת שתיים"
    pr.mkdir(parents=True)
    (pr / "meta.json").write_text(json.dumps({"title": "כותרת שתיים | הרב א"}, ensure_ascii=False), encoding="utf-8")
    tool = projects / "תוכנה" / "2026-10-01_lesson-X"
    tool.mkdir(parents=True)
    (tool / "make_short.json").write_text(json.dumps({"export_target": str(root / "הרב א/סדרה/2026-10-01_lesson-X")},
                                                     ensure_ascii=False), encoding="utf-8")
    before = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
    plan_f = T / "plan.txt"
    r = subprocess.run([sys.executable, str(HERE / "reorganize_exports.py"), "--plan", "--out", str(plan_f)],
                       capture_output=True, text=True, env=env)
    after = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
    check(r.returncode == 0 and before == after, "--plan לא הזיז כלום", r.stdout + r.stderr)
    txt = plan_f.read_text(encoding="utf-8-sig") if plan_f.exists() else ""
    check("כותרת אחת (2)" in txt and "א. קבוצה שלו" in txt and "בוצע כבר.mp4" in txt,
          "בתוכנית: כפילות (2), התיקייה שלו, הקובץ ששינה")
    r = subprocess.run([sys.executable, str(HERE / "reorganize_exports.py"), "--apply"],
                       capture_output=True, text=True, env=env)
    check(r.returncode == 0, "--apply עבר", r.stdout + r.stderr)
    s = root / "הרב א" / "סדרה"
    got = sorted(str(p.relative_to(s)) for p in s.rglob("*") if p.is_file() and len(p.relative_to(s).parts) == 2)
    check(got == ["כותרת אחת (2)/כותרת אחת   הרב א.mp4", "כותרת אחת/כותרת אחת   הרב א.mp4",
                  "כותרת אחת/תיאור להעתקה.txt", "כותרת שתיים/בוצע כבר.mp4"], "המבנה החדש", got)
    check((s / "2026-10-01_lesson-X/shorts/clip2_כותרת שתיים/video_music_music.wav").exists()
          and (s / "2026-10-01_lesson-X/gemini/log.txt").exists(), "שאריות נשארו במקום")
    check(not (s / "א. קבוצה שלו").exists(), "תיקייה שהתרוקנה ירדה")
    nb = sum(p.stat().st_size for p in root.rglob("*.mp4"))
    check(nb == 11 + 22 + 33, "אותם בייטים בדיוק — שום דבר לא נמחק", nb)
    st = json.loads((tool / "make_short.json").read_text(encoding="utf-8"))
    check(st.get("export_layout") == "short" and Path(st["export_dirs"]["clip2"]).name == "כותרת שתיים",
          "מצב התוכנה עודכן לתיקיות החדשות", st)
    led = (T / "exports.jsonl").read_text(encoding="utf-8")
    check('"event": "reorganize"' in led, "שורת reorganize ביומן")

print("\n%s" % ("✓ הכול עבר" if not fails else "✗ %d נכשלו" % len(fails)))
sys.exit(1 if fails else 0)
