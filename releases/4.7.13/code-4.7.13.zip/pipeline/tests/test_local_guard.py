# -*- coding: utf-8 -*-
"""בדיקה: אתר זר בדפדפן לא יכול לדבר עם השרת המקומי (סקירה חיצונית, 29/10/2026).

  1. Host זר (DNS rebinding — "evil.com" שמצביע ל-127.0.0.1) → 403, גם ב-GET.
  2. POST מ-Origin זר / Sec-Fetch-Site=cross-site / בלי Content-Type של JSON (טופס text/plain) → 403.
  3. מה שהדף עצמו שולח עובר: הדף הראשי, GET של /api/home, POST עם JSON מ-Origin שלנו,
     ו-sendBeacon (Blob application/json, Sec-Fetch-Site=same-origin) — שמירה בסגירה חייבת להמשיך לעבוד.
  4. מעבר רגיל לדף הראשי מקישור באתר אחר — מותר (רק הדף, לא ה-API).
  5. כלים בלי Origin (urllib, PowerShell של קובץ ההפעלה) — עוברים.

הרצה:  ~/yeshiva-shorts-skill/shorts.sh py ../tests/test_local_guard.py   (או python3 ישירות)
פורט פנוי, מצב בדיקה, הגדרות בעותק זמני — לא נוגע בשרת שלו (8790)."""
import http.client
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def req(port, method, path, headers=None, body=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    h = {"Host": "127.0.0.1:%d" % port}
    h.update(headers or {})
    c.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
    for k, v in h.items():
        if v is not None:
            c.putheader(k, v)
    data = body.encode() if isinstance(body, str) else body
    if data is not None:
        c.putheader("Content-Length", str(len(data)))
    c.endheaders(data)
    r = c.getresponse()
    r.read()
    c.close()
    return r.status


def main():
    root = Path(tempfile.mkdtemp(prefix="ys_guardtest_"))
    port = free_port()
    env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_IDLE_EXIT="0",
               MAKE_SHORT_SETTINGS=str(root / "settings.json"), SHORTS_PROJECTS=str(root / "projects"),
               MAKE_SHORT_QUEUE=str(root / "queue.json"), GEMINI_API_KEY="", PYTHONUNBUFFERED="1", MAKE_SHORT_NO_MODAL_METER="1")
    srv = subprocess.Popen([sys.executable, "-u", str(SCRIPTS / "make_short_app.py")], env=env, cwd=str(root),
                           stdout=open(root / "server.log", "w"), stderr=subprocess.STDOUT)
    fails = []

    def check(cond, msg):
        print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
        if not cond:
            fails.append(msg)
    me = "http://127.0.0.1:%d" % port
    J = {"Content-Type": "application/json"}
    # נתיב שלא קיים: עבר את השומר → 404, נחסם → 403. כך אין שום פעולה אמיתית בבדיקה
    NOPE = "/api/__guard_probe"
    try:
        for _ in range(100):
            try:
                if req(port, "GET", "/api/home") == 200:
                    break
            except OSError:
                pass
            time.sleep(0.3)
        print("1. Host זר (DNS rebinding)")
        check(req(port, "GET", "/api/home", {"Host": "evil.example:%d" % port}) == 403, "GET עם Host זר נחסם")
        check(req(port, "GET", "/", {"Host": "127.0.0.1:1"}) == 403, "פורט אחר ב-Host — נחסם")
        check(req(port, "POST", NOPE, dict(J, Host="evil.example:%d" % port), "{}") == 403, "POST עם Host זר נחסם")
        print("2. POST מאתר זר")
        check(req(port, "POST", NOPE, dict(J, Origin="https://evil.example"), "{}") == 403, "Origin זר נחסם")
        check(req(port, "POST", NOPE, dict(J, Origin="http://127.0.0.1:1"), "{}") == 403, "Origin מפורט אחר במחשב נחסם")
        check(req(port, "POST", NOPE, dict(J, **{"Sec-Fetch-Site": "cross-site"}), "{}") == 403, "Sec-Fetch-Site=cross-site נחסם")
        check(req(port, "POST", NOPE, {"Content-Type": "text/plain", "Origin": me}, '{"a":1}') == 403,
              "טופס text/plain (שנקרא כ-JSON) נחסם")
        check(req(port, "POST", NOPE, {"Origin": me}, "{}") == 403, "POST בלי Content-Type נחסם")
        check(req(port, "GET", "/api/home", {"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "cors"}) == 403,
              "GET של API מאתר זר נחסם")
        print("3. מה שהדף שולח — עובר")
        check(req(port, "GET", "/", {"Sec-Fetch-Site": "none", "Sec-Fetch-Mode": "navigate"}) == 200, "הדף הראשי נפתח")
        check(req(port, "GET", "/api/home", {"Sec-Fetch-Site": "same-origin"}) == 200, "/api/home מהדף")
        check(req(port, "GET", "/api/home", {"Host": "localhost:%d" % port}) == 200, "Host=localhost מותר")
        check(req(port, "POST", NOPE, dict(J, Origin=me, **{"Sec-Fetch-Site": "same-origin"}), "{}") == 404,
              "POST עם JSON מהדף עובר את השומר")
        check(req(port, "POST", NOPE, {"Content-Type": "application/json; charset=UTF-8",
                                        "Origin": "http://localhost:%d" % port}, "{}") == 404, "charset ו-localhost — עובר")
        check(req(port, "POST", NOPE, {"Content-Type": "application/json", "Origin": me, "Sec-Fetch-Site": "same-origin",
                                        "Sec-Fetch-Mode": "no-cors", "Sec-Fetch-Dest": "empty"}, "{}") == 404,
              "sendBeacon בסגירה (Blob application/json) עובר")
        print("4. קישור לדף הראשי מאתר אחר")
        check(req(port, "GET", "/", {"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "navigate"}) == 200, "מעבר לדף — מותר")
        check(req(port, "GET", "/api/modal_meter?refresh=1", {"Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "navigate"}) == 403,
              "מעבר ל-API — נחסם")
        print("5. כלים בלי Origin")
        check(req(port, "POST", NOPE, J, "{}") == 404, "urllib/PowerShell עם JSON — עובר")
        print("6. (4.1.0) גודל בקשה, GET עם תופעת לוואי, קישור לא תקין, שגיאות בלי נתיבי הבית")
        S = {"Sec-Fetch-Site": "same-origin"}
        check(req(port, "POST", NOPE, dict(J, **{"Content-Length": "-5"}), None) == 400, "Content-Length שלילי — נדחה")
        check(req(port, "POST", NOPE, dict(J, **{"Content-Length": "99999999999"}), None) == 400, "Content-Length ענק — נדחה בלי לקרוא")
        check(req(port, "POST", NOPE, dict(J, **{"Content-Length": "abc"}), None) == 400, "Content-Length לא מספר — נדחה")
        check(req(port, "GET", "/api/modal_meter?refresh=1") == 403, "refresh בלי Sec-Fetch-Site ובלי Origin — נדחה")
        check(req(port, "GET", "/api/health?refresh=1") == 403, "בדיקת מערכת מחדש בלי הוכחה שזה מהדף — נדחה")
        check(req(port, "GET", "/api/modal_meter?refresh=1", S) == 200, "refresh מהדף (same-origin) עובר")
        check(req(port, "GET", "/api/modal_meter?refresh=1", {"Origin": me}) == 200, "refresh עם Origin תקין עובר")
        check(req(port, "GET", "/api/modal_meter?refresh=1", {"Origin": "http://evil.example"}) == 403, "refresh עם Origin זר — נדחה")
        import json as _j

        def post_json(path, obj):
            c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
            b = _j.dumps(obj).encode()
            c.request("POST", path, b, {"Content-Type": "application/json", "Content-Length": str(len(b))})
            r = c.getresponse()
            t = r.read().decode("utf-8", "replace")
            c.close()
            return r.status, t
        for bad in ("--exec=touch /tmp/ys_pwn", "-o /tmp/x", "https://evil.example/?https://www.youtube.com/", "file:///etc/passwd"):
            st, t = post_json("/api/prepare", {"url": bad, "clips": [{"pieces": "0:10-0:40"}]})
            check(st == 400 and "קישור של יוטיוב" in t, "prepare דוחה קישור לא-יוטיוב: " + bad[:30])
            st, t = post_json("/api/pick/estimate", {"url": bad})
            check(st == 400 and "קישור של יוטיוב" in t, "pick/estimate דוחה קישור לא-יוטיוב: " + bad[:30])
        check(not os.path.exists("/tmp/ys_pwn"), "שום פקודה לא הורצה מהקישור")
        big = "A" * (30 * 2**20)
        st, t = post_json("/api/upload_logo", {"data": big})
        check(st == 400 and "גדול מדי" in t, "לוגו ענק — נדחה לפני פענוח")
        st, t = post_json("/api/upload_cookies", {"data": "A" * (4 * 2**20)})
        check(st == 400 and "גדול מדי" in t, "קובץ עוגיות ענק — נדחה לפני פענוח")
        st, t = post_json("/api/music/add", {"name": "x.mp3", "data": "A" * (40 * 2**20)})
        check(st == 400 and "גדול מדי" in t, "מנגינה ענקית — נדחית לפני פענוח")
        home = os.path.expanduser("~")
        st, t = post_json("/api/pick/paste", {"project": home + "/no_such_dir_ys"})
        check(st == 400 and home not in t, "הודעת שגיאה מהשרת לא כוללת את נתיב הבית")
    finally:
        srv.terminate()
        try:
            srv.wait(5)
        except subprocess.TimeoutExpired:
            srv.kill()
        if not fails:
            shutil.rmtree(root, ignore_errors=True)
        else:
            print("  (נשאר לבדיקה: %s)" % root)
    print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d בדיקות" % len(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
