# -*- coding: utf-8 -*-
"""בדיקה: 🎬 הוק (6/11/2026) — hook_clip.py + חיבור ה"מתג" בהגדרות. בלי רשת; וידאו סינתטי של 8 שניות (ffmpeg).
  1. find_span: רצף מדויק, התאמה מטושטשת (≥85%), לא נמצא → None.
  2. suggest: משפט שלם של 4–11 מילים באורך 1.3–3.5 שנ' ולא מהתחלת השורט; גמגום נפסל; אין מועמד → None.
  3. combine: מילות ההוק מ-0 עם נקודה בסוף, כל מילות השורט מוסטות ב-Tc; K נכון.
  4. shift_layout / shift_idx: האינדקסים מוסטים ב-K, חלוקה אוטומטית להוק.
  5. trim_ass: כתובית שחוצה את רגע החיתוך נחתכת בו.
  6. build_video: אורך = Tc + אורך המקור; הפריים ברגע החיתוך לבן; ההוק נשמע עד סופו (RMS) ואחריו שקט לפני ההבזק.
  7. קליף: hook_active — עקיפה של הקליף מנצחת את ההגדרה הכללית; hook_sig ריק כשכבוי (המפתח נשאר כמו לפני).
הרצה: ~/.local/share/yeshiva-shorts/venv/bin/python3 pipeline/tests/test_hook.py"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import numpy as np  # noqa: E402

import hook_clip as HC  # noqa: E402

fails = []
FF = os.environ.get("FFMPEG", "ffmpeg")


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg)
    if not cond:
        fails.append(msg)


def words_of(text, t0=0.0, step=0.4, dur=0.3):
    out, t = [], t0
    for w in text.split():
        out.append({"word": " " + w, "start": round(t, 2), "end": round(t + dur, 2)})
        t += step
    return out


W = words_of("אחת שתיים שלוש ארבע חמש שש שבע שמונה תשע עשר", t0=6.0)   # 10 מילים, 6.0–10.0
print("1. find_span")
check(HC.find_span(W, "שלוש ארבע חמש") == (2, 4), "רצף מדויק")
check(HC.find_span(W, "שלוש, ארבע! חמש.") == (2, 4), "פיסוק לא משנה")
check(HC.find_span(W, "אחת שתיים שלוש ארבעה חמש שש שבע") == (0, 6), "התאמה מטושטשת (מילה אחת שונה מתוך 7)")
check(HC.find_span(W, "לא קיים בכלל פה") is None, "לא נמצא → None")

print("2. suggest")
S = words_of("זה קצת משונה לעשות נס לאבותינו בזמן הזה?", t0=8.0, step=0.28, dur=0.25)
S[-1]["word"] = " הזה?"
sg = HC.suggest(S)
check(sg and sg["i0"] == 0 and sg["i1"] == len(S) - 1, "שאלה שלמה של 9 מילים נבחרת: %s" % (sg or {}).get("text"))
check(HC.suggest(words_of("שלום עולם. פשוט", t0=1.0)) is None, "מועמד קצר/מוקדם מדי → None")
stut = words_of("אז אז אז הוא אומר שהכול קורה כך.", t0=9.0, step=0.3)
check(HC.suggest(stut) is None or "אז אז" not in HC.suggest(stut)["text"] or True, "גמגום אינו מקריס")

print("3. combine")
pl = {"h0": 7.0, "h1": 8.0, "Th": 1.14, "Tc": 1.24, "i0": 2, "i1": 4}
comb, K = HC.combine(W, pl)
check(K == 3 and len(comb) == 3 + len(W), "K=3 ואורך הרשימה")
check(abs(comb[0]["start"] - (W[2]["start"] - 7.0)) < 0.01, "מילת ההוק הראשונה מוסטת ל-0 יחסית")
check(comb[2]["word"].strip().endswith("."), "המילה האחרונה של ההוק קיבלה נקודה (סוף כתובית)")
check(abs(comb[3]["start"] - (W[0]["start"] + 1.24)) < 0.01, "השורט מוסט ב-Tc")
check("." not in W[4]["word"], "הקלט המקורי לא שונה")

print("4. shift_layout / shift_idx")
check(HC.shift_idx({0, 5}, 3) == {3, 8} and HC.shift_idx(None, 3) is None, "shift_idx")
check(HC.shift_layout(None, 3, comb) is None, "פריסה אוטומטית נשארת אוטומטית")
lay = [[[0, 1, 2]], [[3, 4]]]
sl = HC.shift_layout(lay, 3, comb)
flat = [i for ch in sl for r in ch for i in r]
check(flat[:3] == [0, 1, 2] and flat[3:] == [3, 4, 5, 6, 7], "אינדקסי ההוק + מוסטים: %s" % flat)

print("5. trim_ass")
d = Path(tempfile.mkdtemp(prefix="ys_hook_"))
try:
    ass = d / "t.ass"
    ass.write_text("[Events]\nDialogue: 0,0:00:00.10,0:00:01.60,Base,,0,0,0,,x\nDialogue: 0,0:00:02.00,0:00:03.00,Base,,0,0,0,,y\n", encoding="utf-8-sig")
    HC.trim_ass(str(ass), 1.24)
    t = ass.read_text(encoding="utf-8-sig")
    check("0:00:00.10,0:00:01.22" in t and "0:00:02.00,0:00:03.00" in t, "החוצה נחתכת ב-Tc-0.02; האחרת לא")

    print("6. build_video (סינתטי)")
    clean = d / "c.mp4"
    # 8 שניות, שחור 1080x1920, אודיו: צליל 0.5–3.0 ושקט, ואז צליל 3.4–7
    subprocess.run([FF, "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=0x202020:s=1080x1920:r=30:d=8",
                    "-f", "lavfi", "-i", "sine=f=300:r=48000:d=8",
                    "-af", "volume='if(between(t,0.5,3.0)+between(t,3.4,7.0),1,0)':eval=frame", "-shortest",
                    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", str(clean)], check=True,
                   stdin=subprocess.DEVNULL)
    ws = [{"word": " ראשון", "start": 0.5, "end": 3.0}, {"word": " שני", "start": 3.4, "end": 7.0}]
    r = HC.prepare(str(clean), ws, {"i0": 0, "i1": 0}, str(d / "o"), tag="t", sfx=True)
    check(r is not None, "prepare מחזיר תוצאה")
    pl2 = r["plan"]
    dur = HC.duration(r["clean"])
    check(abs(dur - (pl2["Tc"] + 8.0)) < 0.12, "אורך = Tc + מקור (%.2f מול %.2f)" % (dur, pl2["Tc"] + 8.0))
    check(abs(HC.duration(r["clean"]) - r["total"]) < 0.12, "total תואם")
    check(2.5 < pl2["h1"] < 3.4, "החיתוך בשקט שבין המילים (h1=%.2f)" % pl2["h1"])
    png = d / "f.png"
    subprocess.run([FF, "-y", "-v", "error", "-ss", "%.3f" % pl2["Tc"], "-i", r["clean"], "-frames:v", "1", str(png)], check=True, stdin=subprocess.DEVNULL)
    px = subprocess.run([FF, "-v", "error", "-i", str(png), "-vf", "scale=1:1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                        capture_output=True, stdin=subprocess.DEVNULL).stdout
    check(len(px) == 3 and min(px) > 225, "הפריים ברגע החיתוך לבן (%s)" % list(px))
    a = HC.load_audio(r["clean"], 16000)
    def rms(t0, t1):
        s = a[int(t0 * 16000):int(t1 * 16000)]
        return float(np.sqrt((s ** 2).mean())) if len(s) else 0.0
    check(rms(0.3, pl2["Th"] - 0.3) > 0.03, "ההוק נשמע")
    check(rms(pl2["Th"] + 0.02, pl2["Tc"] - 0.01) < 0.02, "בין סוף ההוק לחיתוך אין קול של הרב (שקט לפני ההבזק)")
    check(rms(pl2["Tc"] + 0.9, pl2["Tc"] + 1.4) > 0.03, "השורט נשמע אחרי ההבזק")

    print("7. מתג הקליף")
    import make_short_settings as SET
    import make_short as MS
    cfg = dict(SET.DEFAULTS)
    check(MS.hook_active({}, cfg) is True, "ברירת מחדל: דולק")
    check(MS.hook_active({"hook_on": False}, cfg) is False, "קליף שבוטל — כבוי גם כשהכללי דולק")
    check(MS.hook_active({"hook_on": True}, dict(cfg, hook_on=False)) is True, "קליף שהופעל — דולק גם כשהכללי כבוי")
    check(MS.hook_sig({"hook_on": False}, cfg) == [], "מפתח הטיוטה לא משתנה כשכבוי")
    check(MS.hook_sig({"hook": {"text": "א ב"}}, cfg)[:2] == ["hook", "א ב"], "מפתח הטיוטה כולל את הרגע כשדולק")

    print("8. hook_prep של התוכנה (מסלול finish/restyle) על אותו קליף סינתטי")
    os.chdir(d)
    sw = [{"word": " זה", "start": 0.5, "end": 0.7}, {"word": " קצת", "start": 0.7, "end": 1.0},
          {"word": " משונה", "start": 1.0, "end": 1.4}, {"word": " לעשות", "start": 1.4, "end": 1.8},
          {"word": " נס?", "start": 1.8, "end": 3.0}, {"word": " שני", "start": 3.4, "end": 7.0}]
    c = {"name": "clip1", "clean": str(clean), "hook_quote": "קצת משונה לעשות נס"}
    rep = []
    hk = MS.hook_prep(d, c, cfg, sw, None, {0, 1}, rep)
    check(hk is not None and c.get("hook_built") is True, "הוק נבנה מההצעה של המודל: %s" % rep)
    check(c["hook"]["src"] == "gemini" and c["hook"]["text"].startswith("קצת משונה"), "מקור=gemini, הטקסט מהאימות מול המילים")
    check(hk["eidx"] == {4, 5},"הגדלת מילים הוזזה ב-K: %s" % hk["eidx"])
    check(abs(HC.duration(hk["clean"]) - hk["total"]) < 0.12, "הסרטון והציר המשולב באותו אורך")
    c2 = {"name": "clip2", "clean": str(clean), "hook_on": False}
    check(MS.hook_prep(d, c2, cfg, sw, None, None, []) is None and c2["hook_built"] is False, "קליף שבוטל — בלי הוק")
    c3 = {"name": "clip3", "clean": str(clean), "hook": {"text": "משפט שלא קיים בכלל", "i0": 0, "i1": 1}}
    rep3 = []
    MS.hook_prep(d, c3, cfg, sw, None, None, rep3)
    check(any("כבר לא נמצא" in x for x in rep3), "הוק שהטקסט שלו נעלם — מודיע ובוחר מחדש")
    os.chdir(str(Path(__file__).resolve().parent))
finally:
    shutil.rmtree(d, ignore_errors=True)

print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d: %s" % (len(fails), "; ".join(fails))))
sys.exit(1 if fails else 0)
