# -*- coding: utf-8 -*-
"""בדיקת קצה-לקצה 4.5: האפליקציה האמיתית (שרת) על שיבוט זמני של הקוד שמסומן כהתקנה של מקבל. אין רשת, אין נגיעה בשרת האמיתי.

  שינוי מהתיבה → נרשם → המסך (API) מציג אותו → שם / בלוק לצ'אט / כיבוי והפעלה (עם בדיקה עצמית אמיתית) / ויתור ושחזור →
  עדכון רשמי (קובץ חדש בגרסה) → החלה מחדש → הודעות בעברית; ועץ בעלים (יש origin) → המסך כבוי.

הרצה:  python3 test_personal_app.py   (עדיף עם הפייתון של הסביבה: ~/.local/share/yeshiva-shorts/venv/bin/python)"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
FAIL = []


def chk(c, w, d=""):
    print(("  ✓ " if c else "  ✗ ") + w + ("" if c else "  — " + str(d)[:300]), flush=True)
    if not c:
        FAIL.append(w)


def sh(cwd, *a, check=True):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if check and r.returncode:
        raise RuntimeError("%s: %s" % (a, (r.stderr or r.stdout)[-300:]))
    return r.stdout.strip()


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def main():
    root = Path(tempfile.mkdtemp(prefix="ys_pcapp_"))
    app = root / "app"
    sh(root, "git", "clone", "-q", str(REPO), str(app))
    sh(app, "git", "remote", "remove", "origin")
    (app / ".from_package").write_text("4.4.0")
    with open(app / ".git" / "info" / "exclude", "a") as f:
        f.write(".from_package\n")
    ver = (app / "VERSION").read_text().strip()
    sh(app, "git", "tag", "-f", "rel-" + ver)       # 4.5.62: אצל מקבל התגית כבר קיימת בשיבוט
    port = free_port()
    cfg, data = root / "cfg", root / "data"
    env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_IDLE_EXIT="0", MAKE_SHORT_SETTINGS=str(root / "settings.json"),
               SHORTS_PROJECTS=str(root / "projects"), MAKE_SHORT_QUEUE=str(root / "queue.json"), GEMINI_API_KEY="", PYTHONUNBUFFERED="1",
               MAKE_SHORT_NO_MODAL_METER="1", SHORTS_CONFIG_DIR=str(cfg), SHORTS_DATA_DIR=str(data), HOME=str(root / "home"),
               MAKE_SHORT_UPDATE_NO_SELFTEST="1", MAKE_SHORT_TEST_GUARD="1", MAKE_SHORT_UPDATES=str(data / "updates.json"))
    env.pop("MAKE_SHORT_UPDATE_MODE", None)
    (root / "home").mkdir()
    me = "http://127.0.0.1:%d" % port
    srv = subprocess.Popen([sys.executable, "-u", str(app / "pipeline/scripts/make_short_app.py")], env=env, cwd=str(root),
                           stdout=open(root / "server.log", "w"), stderr=subprocess.STDOUT)

    def get(p):
        return json.loads(urllib.request.urlopen(me + p, timeout=20).read())

    def post(p, body=None):
        rq = urllib.request.Request(me + p, data=json.dumps(body or {}).encode(), headers={"Content-Type": "application/json"})
        try:
            return json.loads(urllib.request.urlopen(rq, timeout=60).read())
        except urllib.error.HTTPError as e:
            return {"_err": json.loads(e.read() or b"{}").get("error", str(e.code))}

    def wait_idle(n=240):
        for _ in range(n):
            s = get("/api/personal/status")
            if not s["busy"]:
                return s
            time.sleep(1)
        return s
    try:
        for _ in range(60):
            try:
                get("/api/home")
                break
            except OSError:
                time.sleep(0.5)
        else:
            raise RuntimeError("השרת לא עלה: " + (root / "server.log").read_text()[-400:])
        # 4.5.x (A10): מי שאינו הבעלים מקבל 403 על כל מסך בעלים של ההצעות
        codes = []
        for ep in ("list", "item", "fetch", "act", "check", "setup", "notify", "rotate"):
            rq = urllib.request.Request(me + "/api/proposals/owner/" + ep, data=b'{"pid":"0123456789abcdef"}',
                                        headers={"Content-Type": "application/json", "Origin": me})
            try:
                urllib.request.urlopen(rq, timeout=20)
                codes.append(200)
            except urllib.error.HTTPError as e:
                codes.append(e.code)
        chk(codes == [403] * 8, "A10: לא-בעלים מקבל 403 על /api/proposals/owner/* (8 נקודות)", codes)
        s = get("/api/personal/status")
        chk(s["active"] and s["changes"] == [] and s["has_official_base"], "מסך ריק אצל מקבל בלי שינויים; יש נקודת בסיס רשמית", s)
        rs = get("/api/release/status")
        chk(rs["personal"]["active"] and rs["personal"]["n"] == 0, "סטטוס העדכון כולל סיכום אישי")
        # שינוי מהתיבה — באמצעות התסריט האמיתי של התיבה, על השיבוט
        upd = root / "u.txt"
        upd.write_text("תיאור: הוספת הערה בראש קובץ ההגדרות\n=== החלפה: pipeline/scripts/make_short_guard.py ===\n<<<<<<< לפני\n"
                       + (app / "pipeline/scripts/make_short_guard.py").read_text().split("\n")[0]
                       + "\n=======\n"
                       + (app / "pipeline/scripts/make_short_guard.py").read_text().split("\n")[0] + "\n# הערה אישית שלי\n>>>>>>> אחרי\n=== סוף החלפה ===\n", encoding="utf-8")
        r = subprocess.run([sys.executable, str(app / "pipeline/scripts/make_short_update.py"), "apply", str(upd)], env=env, capture_output=True,
                           text=True, errors="replace", timeout=400, cwd=str(root))
        chk(r.returncode == 0 and "נרשם כשינוי אישי" in r.stdout, "התיבה החילה ורשמה", r.stdout[-400:])
        s = get("/api/personal/status")
        c = s["changes"][0] if s["changes"] else {}
        chk(len(s["changes"]) == 1 and c["state"] == "applied" and c["desc"].startswith("הוספת הערה"), "המסך מציג את השינוי כפעיל", s)
        rs = get("/api/release/status")
        chk(rs["personal"]["n"] == 1 and rs["personal"]["attention"] == 0, "הסיכום בסטטוס העדכון: שינוי אחד, אף אחד לא צריך אותי")
        # שם, בלוק, קוד
        s = post("/api/personal/rename", {"id": c["id"], "desc": "הערה אישית"})
        chk(s["changes"][0]["desc"] == "הערה אישית", "שינוי שם")
        blk = post("/api/personal/block", {"id": c["id"]})
        chk("[מיזוג %s]" % c["id"] in blk["text"] and "הערה אישית שלי" in blk["text"], "בלוק לצ'אט נבנה")
        chk("הערה אישית שלי" in post("/api/personal/patch", {"id": c["id"]})["text"], "הצגת הקוד של השינוי")
        # כיבוי והפעלה — דרך השרת, עם בדיקה עצמית אמיתית (selfcheck: קומפילציה + שרת בדיקה)
        r = post("/api/personal/enable", {"id": c["id"], "on": False})
        chk(r.get("ok"), "בקשת כיבוי התקבלה", r)
        s = wait_idle()
        chk(s["changes"][0]["state"] == "disabled" and "הערה אישית שלי" not in (app / "pipeline/scripts/make_short_guard.py").read_text()
            and "כובה" in s["msg"], "כובה: יצא מהקוד", s["msg"])
        r = post("/api/personal/enable", {"id": c["id"], "on": True})
        s = wait_idle()
        chk(s["changes"][0]["state"] == "applied" and "הערה אישית שלי" in (app / "pipeline/scripts/make_short_guard.py").read_text(),
            "הופעל חזרה אחרי בדיקה עצמית אמיתית", s["msg"])
        chk(sh(app, "git", "status", "--porcelain") == "", "העץ נקי")
        r = post("/api/personal/giveup", {"id": c["id"]})
        s = wait_idle()
        chk(s["changes"][0]["state"] == "archived", "ויתור → ארכיון")
        r = post("/api/personal/restore", {"id": c["id"]})
        s = wait_idle()
        chk(s["changes"][0]["state"] == "applied", "שחזור מהארכיון", s["msg"])
        chk("_err" in post("/api/personal/block", {"id": "pc-9999"}), "בלוק למזהה לא קיים — הודעת שגיאה")
        # עדכון רשמי: קובץ הקוד של השינוי השתנה בגרסה חדשה → החלה מחדש (נבדק בהפעלה חוזרת של השרת — כמו אחרי עדכון)
        page = (app / "pipeline/scripts/make_short_page.html").read_text(encoding="utf-8")
        chk('id="pcSet"' in page and "pcPoll()" in page, "הדף כולל את המסך ואת הסקר שלו")
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except subprocess.TimeoutExpired:
            srv.kill()
    log = (root / "server.log").read_text(errors="replace")
    chk("Traceback" not in log, "אין שגיאות בשרת", log[-300:])
    # עץ בעלים: יש origin → המסך כבוי
    app2 = root / "owner"
    sh(root, "git", "clone", "-q", str(REPO), str(app2))
    port2 = free_port()
    env2 = dict(env, MAKE_SHORT_PORT=str(port2))
    srv2 = subprocess.Popen([sys.executable, "-u", str(app2 / "pipeline/scripts/make_short_app.py")], env=env2, cwd=str(root),
                            stdout=open(root / "server2.log", "w"), stderr=subprocess.STDOUT)
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen("http://127.0.0.1:%d/api/home" % port2, timeout=5).read()
                break
            except OSError:
                time.sleep(0.5)
        s2 = json.loads(urllib.request.urlopen("http://127.0.0.1:%d/api/personal/status" % port2, timeout=20).read())
        chk(not s2["active"] and s2["changes"] == [], "עץ הבעלים: המנגנון כבוי")
    finally:
        srv2.terminate()
    shutil.rmtree(root, ignore_errors=True)
    print("\n%s: %d נכשלו" % ("נכשל" if FAIL else "הכול עבר", len(FAIL)))
    sys.exit(1 if FAIL else 0)


main()
