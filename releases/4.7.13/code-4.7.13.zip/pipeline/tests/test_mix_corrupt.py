# -*- coding: utf-8 -*-
"""בדיקה: מנגינה פגומה בספרייה (סקירה חיצונית, 29/10/2026).

לפני: ffmpeg נכשל בשקט, מערך ריק, ZeroDivisionError בלי שם. עכשיו: יציאה עם הודעה בעברית שמזכירה את שם
המנגינה ומה לעשות (החלף מוזיקה / ⏸ השבת), ו-make_short.run מעביר אותה לחלון. ומנגינה תקינה — עדיין מתערבבת."""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))


def main():
    import make_short as MS
    T = Path(tempfile.mkdtemp(prefix="ys_mixtest_"))
    fails = []

    def check(cond, msg):
        print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
        if not cond:
            fails.append(msg)
    try:
        vid, good, bad = T / "v.mp4", T / "good.mp3", T / "bad.mp3"
        subprocess.run([MS.FFMPEG, "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=64x64:d=4", "-f", "lavfi",
                        "-i", "sine=f=220:d=4", "-shortest", "-c:v", "libx264", "-c:a", "aac", str(vid)], check=True)
        subprocess.run([MS.FFMPEG, "-v", "error", "-f", "lavfi", "-i", "sine=f=440:d=3", str(good)], check=True)
        bad.write_bytes(b"\x00garbage" * 200)
        json.dump({"title": "Broken Tune"}, open(str(bad) + ".license.json", "w"))
        try:
            MS.run([sys.executable, SCRIPTS / "mix_music.py", vid, bad, T / "o1.mp4"])
            check(False, "מנגינה פגומה נכשלת")
        except RuntimeError as e:
            m = str(e)
            check("Broken Tune" in m and "השבת" in m and "ZeroDivision" not in m, "הודעה ברורה עם שם המנגינה: %s" % m[-160:])
        out = MS.run([sys.executable, SCRIPTS / "mix_music.py", vid, good, T / "o2.mp4"])
        check((T / "o2.mp4").exists() and '"dur"' in out, "מנגינה תקינה — מתערבבת")
    finally:
        shutil.rmtree(T, ignore_errors=True)
    print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d בדיקות" % len(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
