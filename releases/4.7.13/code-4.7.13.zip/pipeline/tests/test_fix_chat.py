# -*- coding: utf-8 -*-
"""בדיקה: 🛠️ תקן שורט זה בצ'אט (כרטיס 27, 12/11/2026) — make_short_fix.py + נקודות הקצה בשרת. בלי רשת, שיעור מלאכותי של 4 שניות.
  1. הבלוק לצ'אט: עובדות, סיכום צבעים, קטע ASS סביב הזמן, כללים; מפתח אמיתי שהוזרק לסביבה לא מגיע לבלוק (guard).
  2. פירוק תשובות: החלפה (גם עטופה בעיצוב של צ'אט), @all / @regex, סקריפט, חתוך באמצע, «זה באג בתוכנה», שאלה, «לפני» שלא נמצא.
  3. סריקת סקריפט: רשת / מחיקה / נתיב מחוץ לתיקייה / eval — נדחים; סקריפט תקין עובר.
  4. תיקון בכתוביות (באג בסגנון D9: צבע זהב על חלק מהכתוביות) → גרסה חדשה, לפני/אחרי, בדיקה עצמית, אישור; פיקסלים זהובים נראים בפריים.
     תיקון שני (הסרת הזהב) → הזהב נעלם; ↩ חזור ×2 מחזיר בדיוק את הקבצים (sha).
  5. סקריפט: פעם תקין (נזרק ב-discard — הטיוטה לא משתנה); פעם שכותב לקבצי הקליף → נדחה; פעם עם פלט במידה לא נכונה → נכשל בבדיקה העצמית.
  6. השרת (HTTP): files / block / check / apply (עבודה) / state / fix_video / fix_frame / accept / undo / reveal (בלי להפעיל סייר) / bug.
הרצה: ~/yeshiva-shorts-skill/shorts.sh py pipeline/tests/test_fix_chat.py [--keep]"""
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(HERE))
import make_short_selftest as T  # noqa: E402

fails = []


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
    if not cond:
        fails.append(msg)


FAKE_KEY = "AI" + "za" + "SyFAKEFAKEFAKEFAKEFAKEFAKEFAKE12345"  # built from parts so the package secret scan does not see a key
base = Path(tempfile.mkdtemp(prefix="ys_fixtest_"))
env = T.test_env(base)
env["GEMINI_API_KEY"] = FAKE_KEY
os.environ.update({k: v for k, v in env.items() if k.startswith(("MAKE_SHORT", "SHORTS_"))})
os.environ["GEMINI_API_KEY"] = FAKE_KEY
os.environ["MAKE_SHORT_FIX_NO_EXPLORER"] = "1"
env["MAKE_SHORT_FIX_NO_EXPLORER"] = "1"
import make_short_fix as FIX  # noqa: E402

PY = sys.executable
FFMPEG = FIX.FFMPEG


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def apply_cli(P, fid, name="clip1"):
    r = subprocess.run([PY, "-u", str(HERE / "make_short_fix.py"), "apply", str(P), name, fid], env=env, capture_output=True,
                       text=True, errors="replace", timeout=900)
    return r.returncode, r.stdout + r.stderr


def gold_pixels(video, t=1.6):
    """כמה פיקסלים זהובים (FFD737) באזור הכתוביות בפריים."""
    import numpy as np
    r = subprocess.run([FFMPEG, "-v", "error", "-nostdin", "-ss", str(t), "-i", str(video), "-frames:v", "1",
                        "-vf", "crop=1080:420:0:1330,format=rgb24", "-f", "rawvideo", "-"], capture_output=True)
    a = np.frombuffer(r.stdout, dtype="uint8").reshape(-1, 3).astype(int)
    d = abs(a[:, 0] - 0xFF) + abs(a[:, 1] - 0xD7) + abs(a[:, 2] - 0x37)
    return int((d < 60).sum())


def hi_rgb(P):
    import re
    a = (P / "work/subtitles/clip1.ass").read_text(encoding="utf-8-sig")
    b = re.search(r"^Style: Hi,[^,]*,\d+,&H00([0-9A-Fa-f]{6})", a, re.M).group(1)
    return (int(b[4:6], 16), int(b[2:4], 16), int(b[0:2], 16))


def hi_pixels(video, rgb, t=1.6):
    import numpy as np
    r = subprocess.run([FFMPEG, "-v", "error", "-nostdin", "-ss", str(t), "-i", str(video), "-frames:v", "1",
                        "-vf", "crop=1080:420:0:1330,format=rgb24", "-f", "rawvideo", "-"], capture_output=True)
    a = np.frombuffer(r.stdout, dtype="uint8").reshape(-1, 3).astype(int)
    d = abs(a[:, 0] - rgb[0]) + abs(a[:, 1] - rgb[1]) + abs(a[:, 2] - rgb[2])
    return int((d < 60).sum())


ANS_GOLD = """תיאור: מדמה את הבאג — מוסיף צבע זהב לכתובית אחת
הוספתי override של צבע לכתובית השנייה.

=== תיקון קליפ ===
=== החלפה: subtitles.ass ===
<<<<<<< לפני
{\\clip(291,1351,522,1474)}
=======
{\\clip(291,1351,522,1474)\\1c&H37D7FF&}
>>>>>>> אחרי
=== סוף החלפה ===
=== סוף תיקון ==="""

ANS_UNGOLD = """**תיאור:** מסיר את הצבע הזהב מהכתוביות

הצבע הזהב נשאר אחרי הצריבה בחלק מהכתוביות — מחזיר לצבע של שאר הקליף.

```
=== תיקון קליפ ===
=== החלפה: subtitles.ass ===
<<<<<<< לפני
@all
\\1c&H37D7FF&
=======
>>>>>>> אחרי
=== סוף החלפה ===
=== סוף תיקון ===
```"""

ANS_RX = """תיאור: צובע את כל ההדגשות בזהב
=== תיקון קליפ ===
=== החלפה: subtitles.ass ===
<<<<<<< לפני
@regex
(Dialogue: 2,[^\\n]*Hi,,0,0,0,,)
=======
\\g<1>{\\\\1c&H37D7FF&}
>>>>>>> אחרי
=== סוף החלפה ===
=== סוף תיקון ==="""

SCRIPT_OK = """=== תיקון קליפ ===
תיאור: מבהיר מעט את הווידאו
=== סקריפט: fix.py ===
import os, subprocess
IN, OUT = os.environ["IN_DIR"], os.environ["OUT_DIR"]
subprocess.run([os.environ["FFMPEG"], "-y", "-v", "error", "-i", IN + "/plain.mp4", "-vf", "eq=brightness=0.04", "-c:v", "libx264", "-preset", "ultrafast",
                "-pix_fmt", "yuv420p", "-c:a", "copy", OUT + "/plain.mp4"], check=True)
=== סוף סקריפט ===
=== סוף תיקון ==="""

SCRIPT_WRITES = """=== תיקון קליפ ===
תיאור: מנסה לכתוב לתיקיית הקליף
=== סקריפט: fix.py ===
import os, shutil
IN, OUT = os.environ["IN_DIR"], os.environ["OUT_DIR"]
P = os.path.abspath(os.path.join(IN, "..", "..", "..", ".."))
open(os.path.join(P, "shorts", "clip1", "junk.txt"), "w").write("x")
shutil.copy(IN + "/plain.mp4", OUT + "/plain.mp4")
=== סוף סקריפט ===
=== סוף תיקון ==="""

SCRIPT_WRONG = """=== תיקון קליפ ===
תיאור: פלט קטן מדי
=== סקריפט: fix.py ===
import os, subprocess
IN, OUT = os.environ["IN_DIR"], os.environ["OUT_DIR"]
subprocess.run([os.environ["FFMPEG"], "-y", "-v", "error", "-i", IN + "/plain.mp4", "-vf", "scale=320:568", "-c:v", "libx264", "-preset", "ultrafast",
                "-pix_fmt", "yuv420p", "-c:a", "copy", OUT + "/plain.mp4"], check=True)
=== סוף סקריפט ===
=== סוף תיקון ==="""

try:
    print("0. הכנת שיעור מלאכותי")
    def pin_karaoke(PP):   # הסגנון נבחר אקראית כשלא קובעים — הבדיקות כאן מניחות קריוקי (סגנון Hi)
        sp = PP / "make_short.json"
        s_ = json.load(open(sp, encoding="utf-8"))
        s_["clips"][0]["sub_rgb_user"] = "4EB1FF"
        json.dump(s_, open(sp, "w", encoding="utf-8"), ensure_ascii=False)
    P = T.make_fixture(base, "fix1")
    pin_karaoke(P)
    rc, out = T.run_ms(env, "finish", P)
    check(rc == 0, "finish יצר טיוטה עם מוזיקה")
    final0 = T.final_video(P)
    sha0, plain0 = sha(final0), sha(P / "work/plain/clip1.mp4")
    g0, HI = gold_pixels(final0), hi_rgb(P)
    check(hi_pixels(final0, HI) > 300, "לפני: צבע ההדגשה הרגיל נראה (%d פיקסלים; זהב ברקע: %d)" % (hi_pixels(final0, HI), g0))

    # מלבן ה-\clip תלוי בגופן/הסביבה — לוקחים את הראשון שבקובץ בפועל (קודם זה היה קבוע ונכשל בסביבות אחרות)
    import re as _re
    _m = _re.search(r"\{\\clip\((\d+),(\d+),(\d+),(\d+)\)\}", (P / "work/subtitles/clip1.ass").read_text(encoding="utf-8-sig"))
    if _m:
        ANS_GOLD = ANS_GOLD.replace("291,1351,522,1474", ",".join(_m.groups()))
        CLIP_PFX = ",".join(_m.groups()[:3])
    else:   # סגנון בלי \clip (נבחר אקראית): מצבעים את תחילת השורה שמוצגת בשנייה 1.6
        _pfx = "Dialogue: 1,0:00:01.08,0:00:02.42,Base,,0,0,0,,"
        for _l in (P / "work/subtitles/clip1.ass").read_text(encoding="utf-8-sig").splitlines():   # שורת ההדגשה (Hi) שמוצגת ב-1.6
            _d = _re.match(r"(Dialogue: \d+,0:00:01\.\d\d,0:00:0[12]\.\d\d,Hi,,0,0,0,,)", _l)
            if _d:
                _pfx = _d.group(1)
                break
        ANS_GOLD = ANS_GOLD.replace("{\\clip(291,1351,522,1474)}\n=======\n{\\clip(291,1351,522,1474)\\1c&H37D7FF&}",
                                    _pfx + "\n=======\n" + _pfx + "{\\1c&H37D7FF&}")
        CLIP_PFX = "0:00:01.08"

    print("1. הבלוק לצ'אט")
    r = FIX.build_block(P, "clip1", "בשיעור D9 חלק מהכתוביות בצבע אחר", 1.5)
    t = r["text"]
    check("בשיעור D9 חלק מהכתוביות בצבע אחר" in t, "הפגם במילים שלו בבלוק")
    check("שנייה 1.50" in t, "הזמן שסימן")
    check("=== תיקון קליפ ===" in t and "@regex" in t and "SHORTS_LIB" in t, "פורמט התשובה + כללי הגופנים")
    check("אורך:" in t and "LUFS" in t and "1080x1920" in t and "מוזיקה:" in t, "עובדות: אורך, עוצמה, רזולוציה, מוזיקה")
    check("סיכום צבעים" in t and "Hi=&H00" in t, "סיכום צבעים מה-ASS")
    check("0:00:01.38" in t, "שורות ה-ASS סביב הזמן")
    check("burn_subtitles" in t and "loudnorm" in t, "סדר הצינור")
    check(FAKE_KEY not in t, "מפתח שהוזרק לסביבה לא נכנס לבלוק")
    check(len(t) < FIX.BLOCK_CAP and not r["over"], "הבלוק בגודל סביר (%d תווים)" % len(t))
    r2 = FIX.build_block(P, "clip1", "", None, {"ass_full": True, "facts": False, "pipeline": False})
    check("כל הקובץ" in r2["text"] and "עובדות על הקליף" not in r2["text"] and "(לא כתב" in r2["text"], "בחירת מה ייכנס (ass מלא, בלי עובדות)")

    print("2. פירוק תשובות")
    p = FIX.parse(ANS_GOLD)
    check(p["kind"] == "ass" and len(p["edits"]) == 1 and p["desc"].startswith("מדמה"), "החלפה רגילה")
    p = FIX.parse(ANS_UNGOLD)
    check(p["kind"] == "ass" and p["edits"][0][0] == "all" and p["desc"].startswith("מסיר"), "@all בתוך ``` ועם **תיאור**")
    p = FIX.parse(ANS_GOLD.replace("=== סוף תיקון ===", ""))
    check(p["kind"] == "ass", "בלי שורת «סוף תיקון» זה עדיין תקין")
    p = FIX.parse(SCRIPT_OK)
    check(p["kind"] == "script" and "IN_DIR" in p["script"], "סקריפט")
    p = FIX.parse(SCRIPT_OK.replace("=== סוף סקריפט ===", ""))
    check(p["kind"] == "none" and any("נקטעה" in e for e in p["errors"]), "סקריפט שנחתך באמצע → שגיאה ברורה")
    check(FIX.parse("זה באג בתוכנה: הצבע תמיד זהב")["kind"] == "tool_bug", "«זה באג בתוכנה»")
    check(FIX.parse("באיזו שנייה זה קורה?")["kind"] == "question", "שאלה")
    check(FIX.parse("שלום, אין כאן תיקון")["kind"] == "none", "תשובה בלי תיקון")
    c = FIX.check(P, "clip1", ANS_GOLD)
    check(c["ok"] and any("1 מופעים" in n for n in c["notes"]), "check: מופע אחד יוחלף")
    c = FIX.check(P, "clip1", ANS_UNGOLD)
    check(not c["ok"] and any("לא נמצא" in e for e in c["errors"]), "@all על טקסט שלא קיים עדיין → שגיאה")
    c = FIX.check(P, "clip1", ANS_GOLD.replace(CLIP_PFX, "999,1,2"))
    check(not c["ok"] and c["errors"], "«לפני» שלא קיים בקובץ → שגיאה עם הסבר")
    c = FIX.check(P, "clip1", ANS_GOLD.replace("=== החלפה: subtitles.ass ===", "=== החלפה: make_short.py ==="))
    check(not c["ok"] and any("subtitles.ass" in e for e in c["errors"]), "החלפה בקובץ אחר נדחית")
    rx = ANS_RX
    c = FIX.check(P, "clip1", rx)
    check(c["ok"] and any("10 מופעים" in n for n in c["notes"]), "@regex על כל שורות ההדגשה: %s %s" % (c["notes"], c["errors"]))

    print("3. סריקת סקריפט")
    bad = {"רשת": "import socket\nsocket.socket()", "מחיקה": "import os\nos.remove('x')", "נתיב": "open('../x','w')", "eval": "eval('1')",
           "shell": "import os\nos.system('ls')", "מפתחות": "open('config.env')", "פקודה": "import subprocess\nsubprocess.run(['rm','-rf','x'])",
           "מוחלט": "open('/home/x','w')", "תחביר": "def ("}
    for k, src in bad.items():
        check(bool(FIX.scan_script(src)), "נדחה: " + k)
    check(not FIX.scan_script(SCRIPT_OK.split("fix.py ===\n")[1].split("=== סוף")[0]), "סקריפט תקין עובר סריקה")
    SB_OK, SB_WHY = FIX.sandbox_available()
    print("   (bwrap: %s)" % ("זמין" if SB_OK else "לא זמין — " + SB_WHY))
    check(SB_OK or FIX._sandbox_cmd("x.py") == (None, False), "בלי bwrap אין פקודת הרצה (לא רצים בלי בידוד)")

    print("4. תיקון כתוביות — דמיית באג D9 ותיקונו")
    fid1 = FIX.stage(P, "clip1", ANS_GOLD, "בדיקה", 1.6)
    rc, out = apply_cli(P, fid1)
    m1 = FIX.load_meta(P, fid1)
    check(rc == 0 and m1["state"] == "ready", "הגרסה הראשונה מוכנה (%s)" % (m1 or {}).get("error"))
    check(all(x["ok"] for x in m1["checks"]), "הבדיקה העצמית עברה: " + "; ".join(x["text"] for x in m1["checks"] if not x["ok"]))
    check((FIX.fix_dir(P, fid1) / "before.jpg").exists() and (FIX.fix_dir(P, fid1) / "after.jpg").exists(), "פריימי לפני/אחרי")
    check(sha(final0) == sha0, "הטיוטה לא השתנתה לפני האישור")
    check(gold_pixels(FIX.fix_dir(P, fid1) / "final_new.mp4") > g0 + 150, "בגרסה החדשה יש זהב")
    FIX.accept(P, "clip1", fid1)
    final1 = T.final_video(P)
    check(sha(final1) != sha0 and gold_pixels(final1) > g0 + 150, "אחרי אישור: הטיוטה זהובה")
    check((FIX._vdir(P, "clip1") / (fid1 + "_final_before.mp4")).exists(), "הגרסה הישנה נשמרה")
    st = json.load(open(P / "make_short.json", encoding="utf-8"))
    check(st["clips"][0].get("chat_fixes", [{}])[0].get("id") == fid1, "chat_fixes נרשם בקליף")
    check(FIX.state_view(P, "clip1")["can_undo"], "אפשר לחזור")
    sha1, plain1 = sha(final1), sha(P / "work/plain/clip1.mp4")
    time.sleep(1.1)
    fid2 = FIX.stage(P, "clip1", ANS_UNGOLD, "הזהב לא אמור להיות", 1.6)
    rc, out = apply_cli(P, fid2)
    m2 = FIX.load_meta(P, fid2)
    check(rc == 0 and m2["state"] == "ready", "התיקון השני מוכן: " + str(m2.get("error")))
    FIX.accept(P, "clip1", fid2)
    final2 = T.final_video(P)
    check(gold_pixels(final2) < g0 + 40 and hi_pixels(final2, HI) > 300, "אחרי התיקון השני: הזהב נעלם והצבע הרגיל חזר")
    FIX.undo(P, "clip1")
    check(sha(T.final_video(P)) == sha1 and sha(P / "work/plain/clip1.mp4") == plain1, "↩ חזרה: בדיוק הקבצים של אחרי התיקון הראשון")
    FIX.undo(P, "clip1")
    check(sha(T.final_video(P)) == sha0 and sha(P / "work/plain/clip1.mp4") == plain0, "↩ חזרה שנייה: בדיוק הקבצים המקוריים")
    st = json.load(open(P / "make_short.json", encoding="utf-8"))
    check("chat_fixes" not in st["clips"][0] and not FIX.state_view(P, "clip1")["can_undo"], "אחרי חזרה — אין סימון תיקון")
    try:
        FIX.undo(P, "clip1")
        check(False, "חזרה בלי מה לבטל נדחית")
    except ValueError:
        check(True, "חזרה בלי מה לבטל נדחית")

    print("5. סקריפט")
    time.sleep(1.1)
    fid3 = FIX.stage(P, "clip1", SCRIPT_OK, "קצת כהה", None)
    rc, out = apply_cli(P, fid3)
    m3 = FIX.load_meta(P, fid3)
    if SB_OK:
        check(rc == 0 and m3["state"] == "ready" and "בידוד מלא" in out, "סקריפט תקין רץ בבידוד bwrap מקצה לקצה: " + str(m3.get("error")))
    else:
        check(rc != 0 and m3["state"] == "failed" and "bubblewrap" in (m3.get("error") or ""),
              "אין bwrap → הסקריפט לא רץ וההודעה בעברית פשוטה: " + str(m3.get("error"))[:80])
    FIX.discard(P, "clip1", fid3)
    check(sha(T.final_video(P)) == sha0 and FIX.load_meta(P, fid3)["state"] == "discarded", "discard — הטיוטה לא השתנתה")
    time.sleep(1.1)
    fid4 = FIX.stage(P, "clip1", SCRIPT_WRITES, "", None)
    rc, out = apply_cli(P, fid4)
    m4 = FIX.load_meta(P, fid4)
    check(rc != 0 and m4["state"] == "failed" and not (P / "shorts/clip1/junk.txt").exists(), "סקריפט שניסה לכתוב לקבצי הקליף נכשל ושום דבר לא נכתב")
    try:
        (P / "shorts/clip1/junk.txt").unlink()
    except OSError:
        pass
    time.sleep(1.1)
    fid5 = FIX.stage(P, "clip1", SCRIPT_WRONG, "", None)
    rc, out = apply_cli(P, fid5)
    m5 = FIX.load_meta(P, fid5)
    check(rc != 0 and m5["state"] == "failed" and "הבדיקה העצמית" in m5["error"], "פלט ברזולוציה אחרת נכשל בבדיקה העצמית")
    check(sha(T.final_video(P)) == sha0, "אחרי כל הכישלונות הטיוטה לא השתנתה")
    try:
        FIX.accept(P, "clip1", fid5)
        check(False, "אי אפשר לאשר תיקון שנכשל")
    except ValueError:
        check(True, "אי אפשר לאשר תיקון שנכשל")
    rv = FIX.review_copy(P, "clip1")
    check(Path(rv["path"]).exists() and rv["size"] > 1000 and sha(T.final_video(P)) == sha0, "עותק קטן לסקירה נוצר, המקורי לא נגע")

    print("5א. בידוד bwrap — ניסיונות פריצה אמיתיים (בתיקיות מזויפות שנוצרו כאן)")
    if not SB_OK:
        print("   (דילוג: bwrap לא זמין כאן — %s)" % SB_WHY)
    else:
        sbd = Path(tempfile.mkdtemp(prefix="ys_sb_"))
        (sbd / "in").mkdir(); (sbd / "out").mkdir()
        (sbd / "in" / "a.txt").write_text("in")
        fake_cfg = Path.home() / ".config" / "ys_sbtest_fake"          # תיקייה מזויפת בבית האמיתי — נמחקת בסוף
        fake_cfg.mkdir(parents=True, exist_ok=True)
        (fake_cfg / "config.env").write_text("SECRET=1")
        victim = sbd / "victim.txt"
        victim.write_text("keep")
        home_probe = Path.home() / "ys_sbtest_home_probe.txt"
        outside = Path(tempfile.mkdtemp(prefix="ys_sbout_"))
        (outside / "f.txt").write_text("keep")

        def sb(src):
            sp = sbd / "s.py"
            sp.write_text(src, encoding="utf-8")
            cmd, iso = FIX._sandbox_cmd(str(sp), sbd / "in", sbd / "out", None)
            r = subprocess.run(cmd, cwd=str(sbd), env={"PATH": os.environ.get("PATH", "")}, capture_output=True, text=True, timeout=60)
            return iso, r.returncode, (r.stdout + r.stderr)
        iso, rc, o = sb("import os\nopen(os.path.join(os.path.expanduser('~'),'ys_sbtest_home_probe.txt'),'w').write('x')\nprint('WROTE')")
        check(iso and "WROTE" in o and not home_probe.exists(), "כתיבה ל-$HOME נעלמת בתוך הבידוד (tmpfs) — לא מגיעה לבית האמיתי")
        iso, rc, o = sb("import os\nprint('CFG', os.path.exists(os.path.expanduser('~/.config/ys_sbtest_fake/config.env')), os.path.exists(os.path.expanduser('~/.config')))")
        check("CFG False False" in o, "תיקיית ההגדרות (config.env מזויף) לא נראית בתוך הבידוד: " + o.strip()[-60:])
        iso, rc, o = sb("import os\nfor p in %r: \n  try:\n    os.remove(p); print('DELETED', p)\n  except OSError as e: print('FAIL', e.errno)\n"
                        % [str(victim), str(outside / "f.txt")])
        check("DELETED" not in o and victim.exists() and (outside / "f.txt").exists(), "מחיקה מחוץ ל-OUT נכשלת (קבצים מחוץ לבידוד לא נראים)")
        iso, rc, o = sb("import os\ntry:\n  open(os.environ['IN_DIR']+'/b.txt','w'); print('INWRITE')\nexcept OSError: print('INRO')")
        check("INRO" in o and not (sbd / "in" / "b.txt").exists(), "IN_DIR לקריאה בלבד")
        iso, rc, o = sb("import os\nopen(os.environ['OUT_DIR']+'/ok.txt','w').write('y')\nprint('OUTOK')")
        check("OUTOK" in o and (sbd / "out" / "ok.txt").read_text() == "y", "OUT_DIR ניתן לכתיבה")
        iso, rc, o = sb("import subprocess\nfor a in (['bash','-c','echo SHELL'],['/bin/sh','-c','echo SHELL']):\n  try: print(subprocess.run(a,capture_output=True,text=True).stdout)\n  except Exception as e: print('NOSH')\n"
                        "import importlib\nm=importlib.import_module('soc'+'ket')\ntry:\n  s=m.create_connection(('1.1.1.1',53),timeout=3); print('NET')\nexcept Exception as e: print('NONET')\n"
                        "import os\nprint('ENV', sorted(k for k in os.environ if 'KEY' in k or 'TOKEN' in k or 'GEMINI' in k))")
        check("NONET" in o and "NET\n" not in o.replace("NONET", ""), "רשת לא עובדת (ייבוא עקיף של socket עוקף את הסריקה אבל לא את הבידוד)")
        check("ENV []" in o, "אין מפתחות בסביבה (גם כשהם קיימים בתהליך האב)")
        iso, rc, o = sb("import os,sys\nprint('PROJ', os.path.exists(%r), os.path.exists('/mnt/c'))" % str(P))
        check("PROJ False False" in o, "תיקיית הפרויקט ו-/mnt/c לא נראים בתוך הבידוד")
        shutil.rmtree(fake_cfg, ignore_errors=True)
        shutil.rmtree(sbd, ignore_errors=True)
        shutil.rmtree(outside, ignore_errors=True)
        check(not home_probe.exists(), "הבית האמיתי נשאר נקי")

    print("5ב. קליף עם הוק 🎬 — הצריבה מחדש היא מהסרטון עם ההוק")
    hb = base / "fixture_clean.mp4"
    hb.unlink()
    subprocess.run([FFMPEG, "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30", "-f", "lavfi", "-i",
                    "sine=frequency=220:sample_rate=48000", "-t", "12", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-shortest", str(hb)], check=True)
    HW = "אחת שתיים שלוש ארבע חמש שש שבע שמונה תשע עשר אחד עשר שנים עשר מה הדין בדיוק בעניין הזה ואיך ממשיכים מכאן ולמה זה חשוב".split()
    PH = T.make_fixture(base, "hook1", words=HW, text="אחת שתיים שלוש ארבע חמש שש שבע שמונה תשע עשר אחד עשר שנים עשר. מה הדין בדיוק בעניין הזה? "
                                                      "ואיך ממשיכים מכאן ולמה זה חשוב.")
    rc, out = T.run_ms(env, "finish", PH)
    stH = json.load(open(PH / "make_short.json", encoding="utf-8"))["clips"][0]
    if not stH.get("hook_built"):
        check(False, "ההוק לא נבנה בשיעור הבדיקה (%s)" % out[-300:].replace("\n", " | "))
    else:
        fH = T.final_video(PH)
        shaH = sha(fH)
        tH = FIX.build_block(PH, "clip1", "כתובית בהוק בצבע אחר", 0.8)["text"]
        check("🎬 הוק: כן" in tH and "Tc" in tH and "כולל ההוק" in tH, "הבלוק מסביר את ההוק ואת ציר הזמן")
        check(FIX.burn_source(PH, stH) == PH / "work/hook/clip1_clean.mp4", "מקור הצריבה = הסרטון עם ההוק")
        aH = FIX.check(PH, "clip1", ANS_GOLD.replace(CLIP_PFX, "0,0,0")) if False else None
        # תיקון: כל ההדגשות לזהב (@regex) — כולל כתוביות ההוק
        fidH = FIX.stage(PH, "clip1", ANS_RX, "בדיקת הוק", 0.8)
        rc, out = apply_cli(PH, fidH)
        mH = FIX.load_meta(PH, fidH)
        check(rc == 0 and mH["state"] == "ready", "תיקון על קליף עם הוק מוכן: %s" % mH.get("error"))
        if mH["state"] == "ready":
            durs = (FIX.probe(fH)["dur"], FIX.probe(FIX.fix_dir(PH, fidH) / "final_new.mp4")["dur"])
            check(abs(durs[0] - durs[1]) < 0.3, "אורך כולל ההוק נשמר (%.2f → %.2f)" % durs)
            check(gold_pixels(FIX.fix_dir(PH, fidH) / "final_new.mp4", 0.8) > gold_pixels(fH, 0.8) + 100, "גם כתובית ההוק (שנייה 0.8) נצבעה")
            FIX.accept(PH, "clip1", fidH)
            FIX.undo(PH, "clip1")
            check(sha(T.final_video(PH)) == shaH, "↩ חזרה בקליף עם הוק")

    print("6. השרת (HTTP)")
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    senv = dict(env, MAKE_SHORT_PORT=str(port))
    srv = subprocess.Popen([PY, "-u", str(HERE / "make_short_app.py")], env=senv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, errors="replace")
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen("http://127.0.0.1:%d/api/home" % port, timeout=2).read()
                break
            except Exception:
                time.sleep(0.5)
        U = "http://127.0.0.1:%d" % port

        def api(path, body=None):
            req = urllib.request.Request(U + path, data=json.dumps(body).encode() if body is not None else None,
                                         headers={"Content-Type": "application/json", "Origin": U})
            try:
                return json.loads(urllib.request.urlopen(req, timeout=120).read())
            except urllib.error.HTTPError as e:
                return json.loads(e.read())

        q = {"project": str(P), "clip": "clip1"}
        r = api("/api/fix/files", q)
        keys = {f["key"]: f for f in r["files"]}
        check({"final", "plain", "clean", "ass"} <= set(keys) and keys["final"]["win"].startswith("\\\\"), "files: ארבעה קבצים + נתיב ווינדוס")
        r = api("/api/fix/block", dict(q, text="פגם", at="0:01.5", inc={"ass_full": True}))
        check("פגם" in r["text"] and "שנייה 1.50" in r["text"] and FAKE_KEY not in r["text"], "block דרך השרת (0:01.5 → 1.5 שניות)")
        r = api("/api/fix/reveal", dict(q, key="final"))
        check(r.get("ok") and r["win"].startswith("\\\\"), "reveal (בלי סייר בבדיקה)")
        r = api("/api/fix/reveal", dict(q, key="../../x"))
        check("error" in r, "reveal של מפתח לא מוכר נדחה")
        r = api("/api/fix/check", dict(q, text=ANS_GOLD))
        check(r["ok"] and r["kind"] == "ass", "check דרך השרת")
        r = api("/api/fix/apply", dict(q, answer=ANS_GOLD, defect="בדיקה", at="1.6"))
        check("job" in r and r["id"], "apply התחיל עבודה")
        for _ in range(240):
            time.sleep(1)
            sv = api("/api/fix/state?p=%s&n=clip1" % urllib.request.quote(str(P)))
            if sv["last"]["state"] in ("ready", "failed"):
                break
        check(sv["last"]["state"] == "ready", "state הגיע ל-ready: %s" % sv["last"].get("error"))
        check(any("אורך" in l or "מוזיקה" in l or "מנרמל" in l for l in sv["log"]) or sv["log"] == [], "יומן העבודה מוצג")
        for path in ("/fix_video?p=%s&n=clip1&id=%s&which=new" % (urllib.request.quote(str(P)), r["id"]),
                     "/fix_video?p=%s&n=clip1&id=%s&which=old" % (urllib.request.quote(str(P)), r["id"]),
                     "/fix_frame?p=%s&n=clip1&id=%s&which=new" % (urllib.request.quote(str(P)), r["id"])):
            check(len(urllib.request.urlopen(U + path, timeout=30).read(2000)) > 500, "מדיה: " + path.split("?")[0] + path[-9:])
        r2 = api("/api/fix/accept", dict(q, id=r["id"]))
        check(r2["last"]["state"] == "accepted" and r2["can_undo"], "accept דרך השרת")
        check(gold_pixels(T.final_video(P)) > g0 + 150, "הטיוטה זהובה אחרי accept")
        r3 = api("/api/fix/undo", q)
        check(not r3["can_undo"] and sha(T.final_video(P)) == sha0, "undo דרך השרת — הקובץ המקורי בדיוק")
        r = api("/api/fix/bug", dict(q, text="הצבע תמיד יוצא זהב"))
        check("הצבע תמיד יוצא זהב" in r["text"] and "clip1" in r["text"] and FAKE_KEY not in r["text"], "bug — הבלוק הכללי של כרטיס 19 עם הקליף והפגם")
        r = api("/api/fix/apply", dict(q, answer="סתם טקסט", defect=""))
        check("error" in r, "apply של תשובה בלי תיקון נדחה")
        r = api("/api/fix/files", {"project": str(P), "clip": "clip9"})
        check("error" in r, "קליף שלא קיים נדחה")
        # אי אפשר להתחיל תיקון כשהקליף בעבודה: עבודה מדומה על הקליף
        html = urllib.request.urlopen(U + "/", timeout=20).read().decode("utf-8", "replace")
        check("fixToggle" in html and "תקן שורט זה בצ'אט" in html and "/api/fix/apply" in html, "הדף כולל את הכפתור והפאנל")
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=10)
        except subprocess.TimeoutExpired:
            srv.kill()
finally:
    if "--keep" in sys.argv:
        print("(נשאר: %s)" % base)
    else:
        shutil.rmtree(base, ignore_errors=True)

print("\n%s" % ("✅ הכול עבר" if not fails else "❌ %d נכשלו:\n - %s" % (len(fails), "\n - ".join(fails))))
sys.exit(1 if fails else 0)
