# -*- coding: utf-8 -*-
"""dry_run_first_publish.py (4.7.8) - "ריצת ניסיון" של הפרסום הראשון, בלי לפרסם כלום באמת.
מריץ את כל מסלול הפרסום (preflight, בנייה ניטרלית + סריקות, חתימה במפתח *בדיקה*, העלאה, הורדה חזרה ואימות, רק אז latest.json,
ביטול וניקוי, ומקבל שמעדכן בסדר חתום) מול "ריפו ציבורי" מקומי מזויף ושרת ntfy מזויף - בבית זמני ובהגדרות זמניות.
כותב דוח בעברית פשוטה: בדיוק מה היה הופך לציבורי (קבצים, גדלים, תוצאות הסריקה).

שימוש (בסביבה של התוכנה - venv):  python dry_run_first_publish.py <קובץ-דוח.md> [תיקיית-קוד]
הקוד שנבדק = HEAD של התיקייה (ברירת מחדל: העץ הזה); עובדים על שכפול זמני שלו, כך שאין נגיעה בעץ האמיתי.
🚨 לא נוגע בשום דבר אמיתי: לא מפתח החתימה, לא ההגדרות, לא הערוץ, לא GitHub, לא ntfy.sh. (ידני - לא חלק מה-selftest.)"""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
SRC = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else HERE.parent.parent
OUT_MD = Path(sys.argv[1]) if len(sys.argv) > 1 else None
T = Path(tempfile.mkdtemp(prefix="ys_dry_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg"), "SHORTS_DATA_DIR": str(T / "data"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_PUBLISH_SELFTEST": "[]"})
(T / "home").mkdir()
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(HERE))
import make_short_release as R  # noqa: E402
import make_short_publish as P  # noqa: E402
import make_short_share as SH  # noqa: E402
import make_short_proposals as PRP  # noqa: E402
from fake_ntfy import Fake  # noqa: E402

PW = "dry run only passphrase"
FAILS, LOG = [], []


def say(s):
    LOG.append(s)
    print(s, flush=True)


def chk(c, what, d=""):
    say(("✓ " if c else "✗ ") + what + ("" if c else "  — " + str(d)[:300]))
    if not c:
        FAILS.append(what)
    return bool(c)


def sh(cwd, *a):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def commit(repo, msg, tag=None):
    sh(repo, "git", "add", "-A")
    sh(repo, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", msg)
    if tag:
        sh(repo, "git", "tag", "-f", tag)


def run_publish(pub, notes, baseline, cancel_at=None, timeout=300):
    """מריץ פרסום ועונה "כן" לכל אישור (או מבטל באישור הנתון). מחזיר (מצב, טקסטי האישורים)."""
    asks = {}
    pub.start(PW, notes, False, baseline)
    t0 = time.time()
    seen = set()
    while time.time() - t0 < timeout:
        st = pub.state()
        w = st["waiting"]
        if w and w["kind"] not in seen:
            seen.add(w["kind"])
            asks[w["kind"]] = w["text"]
            if cancel_at == w["kind"]:
                pub.cancel()
            else:
                pub.answer(True)
        if not st["running"]:
            return pub.state(), asks
        time.sleep(0.05)
    return pub.state(), asks


def kb(n):
    return "%.1f KB" % (n / 1024) if n < 1024 * 1024 else "%.2f MB" % (n / 1024 / 1024)


# ───────── הכנה: שכפול זמני של הקוד, "ריפו ציבורי" מקומי, מפתח בדיקה, ערוץ ntfy מזויף ─────────
ver = R.installed_version(SRC)
owner = T / "owner"
sh(T, "git", "clone", "-q", str(SRC), str(owner))
sh(owner, "git", "remote", "remove", "origin")
sh(owner, "git", "config", "user.name", "t")
sh(owner, "git", "config", "user.email", "t@t")
sh(owner, "git", "tag", "-f", "v" + ver)
real_src = json.loads((owner / "assets" / "release_source.json").read_text(encoding="utf-8"))
tags = [t for t in sh(owner, "git", "tag", "--list", "v[0-9]*").split() if re.match(r"^v\d+\.\d+\.\d+$", t)]
older = sorted([t for t in tags if R.ver_tuple(t[1:]) < R.ver_tuple(ver)], key=lambda t: R.ver_tuple(t[1:]))
baseline = older[-1][1:] if older else "0.0.1"
chk(P.suggested_baseline(owner) == baseline, "השדה 'מגרסה' מתמלא לבד בגרסה הקודמת (%s)" % baseline)

remote = T / "public_repo"
remote.mkdir()
sh(remote, "git", "init", "-q", "-b", "main")
sh(remote, "git", "config", "receive.denyCurrentBranch", "updateInstead")
(remote / "README.md").write_text("# shorts-tool-releases (dry run)\n")
commit(remote, "init")
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)
test_pub = P.keygen(PW)
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = test_pub
P.save_cfg({"remote": str(remote)})
fake = Fake()
ch = PRP.setup_channel(fake.url)
chk(PRP.channel_file_bytes() is not None, "ערוץ ההצעות (מזויף) נוצר, ייכנס לארכיון החתום")
pub =P.Publisher(repo=owner)

# ───────── 1. הפרסום הראשון (הגרסה האמיתית) ─────────
notes1 = ["הפרסום הראשון: מעכשיו אפשר לעדכן את התוכנה מהאינטרנט בכפתור אחד.", "העדכון נבדק וחתום לפני שהוא יוצא."]
st, asks = run_publish(pub, notes1, baseline)
chk(st["done"] and not st["error"], "פרסום ראשון (גרסה %s) עבר עד הסוף" % ver, st["error"] + " | " + " / ".join(st["log"][-3:]))
chk(set(asks) == {"plan", "final"}, "היו בדיוק שני אישורים בחלון: תוכנית ואישור סופי", list(asks))
idx = json.loads((remote / "latest.json").read_text())
chk(idx["latest"] == ver and [r["version"] for r in idx["releases"]] == [ver], "latest.json מצביע על הגרסה הראשונה בלבד")
rd = remote / "releases" / ver
zname = "code-%s.zip" % ver
chk({p.name for p in rd.iterdir()} == {"manifest.json", "manifest.sig", zname}, "בריפו רק ארכיון + מניפסט + חתימה")
man = json.loads((rd / "manifest.json").read_text())
chk(R.verify_manifest((rd / "manifest.json").read_bytes(), (rd / "manifest.sig").read_text(), [test_pub]), "החתימה (מפתח בדיקה) מאומתת")
chk(man["previous"] == baseline and man["archive"]["sha256"] == hashlib.sha256((rd / zname).read_bytes()).hexdigest(),
    "המניפסט: previous + sha256 של הארכיון נכונים")

# מה בדיוק ציבורי: כל קובץ בריפו הציבורי (חוץ מ-.git), וכל קובץ בארכיון
public_files = []
for p in sorted(remote.rglob("*")):
    if p.is_file() and ".git" not in p.relative_to(remote).parts:
        public_files.append((str(p.relative_to(remote)).replace("\\", "/"), p.stat().st_size))
with zipfile.ZipFile(rd / zname) as z:
    members = [(i.filename, i.file_size) for i in z.infolist()]
    datas = {i.filename: z.read(i) for i in z.infolist()}

# סריקות עצמאיות על הארכיון
secrets = SH.scan(rd / zname)
mine = SH.identity_scan(rd / zname, profile=False)
needles_p = [x for x in SH.identity_needles(True) if x not in SH.identity_needles(False)]
mention_files = {}                       # אזכורי שם בית המדרש (שוליים: הערות/תיעוד) - מידע לבעלים, לא חסימה
for n, d in datas.items():
    k = sum(sum(v.count(x) for x in needles_p) for v in [max(SH._variants(d), key=lambda v: sum(v.count(x) for x in needles_p))])
    if k:
        mention_files[n] = k
bad_names = [n for n, _ in members if n.lower().endswith((".mp3", ".wav", ".m4a", ".ogg", ".flac"))
             or "/brand/" in n.lower() or n.lower().endswith(("config.env", "cookies.txt", "release_key.enc", "vault.enc", "proposals_owner.json", ".key", ".enc"))]
media = [(n, s) for n, s in members if n.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp", ".ttf", ".otf", ".woff", ".woff2"))]
guid = datas.get("assets/guidelines/shorts_default.txt", b"")
guid_links = len(re.findall(rb"https?://", guid))
chk(not secrets, "סריקת סודות: נקי", secrets)
chk(not mine, "סריקת זהות הבעלים: נקי", mine)
chk(not bad_names, "אין בארכיון מוזיקה / קבצי הגדרות / מפתחות / כספת", bad_names)
chk(guid_links == 0, "ההנחיות שבארכיון הן ברירת המחדל הניטרלית (בלי קישורים)", guid_links)
chk("CHANGELOG.md" not in datas and "assets/release_source.json" in datas, "אין CHANGELOG; כתובת העדכונים והמפתח הציבורי כן")
in_zip_src = json.loads(datas["assets/release_source.json"])
chk(in_zip_src.get("pubkey") == real_src.get("pubkey") and in_zip_src.get("base") == real_src.get("base") and real_src.get("pubkey"),
    "בארכיון מופיעים המפתח הציבורי האמיתי וכתובת העדכונים האמיתית (לא של מפתח הבדיקה)")
chk(real_src.get("pubkey") != test_pub, "מפתח הבדיקה שונה מהמפתח האמיתי (הבדיקה לא נגעה במפתח האמיתי)")
parts = SH.release_base_parts(real_src.get("base", ""))
chk(parts is not None and parts[1] == "shorts-tool-releases", "שם הריפו בכתובת: shorts-tool-releases")
ho = datas.get("docs/HANDOFF.md", b"").decode("utf-8", "replace")
chk("## 10." not in ho, "מדריך המפתחים בארכיון בלי הפרק האישי (§10)")
chk(PRP.CHANNEL_ASSET in datas, "קובץ ערוץ ההצעות (נושאים אקראיים + מפתחות ציבוריים) נמצא בארכיון החתום")

# ───────── 2. גרסה שנייה (רק לניסוי) מתפרסמת במלואה — כדי לבדוק עדכון לפי הסדר ─────────
def bump(n):
    v = ver.split(".")
    return "%s.%s.%d" % (v[0], v[1], int(v[2]) + n)


ver2, ver3 = bump(1), bump(2)
(owner / "VERSION").write_text(ver2 + "\n")
(owner / "pipeline" / "dry_run_marker.txt").write_text("dry run second version\n")
commit(owner, "dry run %s" % ver2, "v" + ver2)
st2, _ = run_publish(pub, ["גרסת ניסוי שנייה (לא תפורסם באמת)"], baseline)
chk(st2["done"] and not st2["error"], "גרסת ניסוי %s פורסמה אחרי %s (שרשרת)" % (ver2, ver), st2["error"])
idx = json.loads((remote / "latest.json").read_text())
chk([r["version"] for r in idx["releases"]] == [ver, ver2], "latest.json: שתי הגרסאות לפי סדר")

# ───────── 3. ביטול וניקוי: גרסה שלישית מבוטלת באישור הסופי ─────────
before_idx = (remote / "latest.json").read_bytes()
(owner / "VERSION").write_text(ver3 + "\n")
commit(owner, "dry run %s" % ver3, "v" + ver3)
st3, asks3 = run_publish(pub, ["גרסה שתבוטל"], baseline, cancel_at="final")
chk(not st3["done"] and (remote / "latest.json").read_bytes() == before_idx, "ביטול באישור הסופי: latest.json לא השתנה", st3.get("error"))
chk(not (remote / "releases" / ver3 / "manifest.json").exists(), "ביטול: מה שהועלה הוצא מהריפו (revert)")
chk(P.cleanup_pending() is None, "ביטול: אין סימון 'ממתין לניקוי' שנשאר")

# ───────── 4. מקבל: עדכון חתום לפי הסדר מהגרסה הקודמת ─────────
inst = T / "receiver"
sh(T, "git", "clone", "-q", str(owner), str(inst))
sh(inst, "git", "checkout", "-q", "v" + baseline)
sh(inst, "git", "checkout", "-q", "-B", "main")
sh(inst, "git", "remote", "remove", "origin")
(inst / ".from_package").write_text(baseline)
with open(inst / ".git" / "info" / "exclude", "a") as f:
    f.write(".from_package\n")
chk(R.update_mode(inst) == "receiver", "מקבל מדומה (חבילה מגרסה %s) מזוהה כמקבל" % baseline)
c = R.check(installed=baseline)
chk(c["available"] and c["steps"] == [ver, ver2], "הבדיקה מציעה את שתי הגרסאות לפי הסדר", str(c)[:200])
res = R.run_updates(repo=inst, log=lambda s: None)
applied = [d["version"] for d in res["applied"]]
chk(applied == [ver, ver2] and not res["error"], "עדכון חתום לפי הסדר הושלם: %s" % " ← ".join(applied), res.get("error"))
chk(R.installed_version(inst) == ver2 and not (inst / "CHANGELOG.md").exists(), "אחרי העדכון הגרסה היא %s, ללא CHANGELOG" % ver2)
# חתימה מזויפת: אותו מניפסט בחתימה של מפתח אחר - נדחה
fm = (rd / "manifest.json").read_bytes()
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
fake_sig = base64.b64encode(Ed25519PrivateKey.generate().sign(fm)).decode()
try:
    R.verify_manifest(fm, fake_sig, [test_pub])
    chk(False, "חתימה של מפתח זר נדחית")
except R.UpdateError:
    chk(True, "חתימה של מפתח זר נדחית")

# ───────── 5. שער הפרסום האמיתי: בלי מפתח/בלי כתובת/בלי אישור — לא יוצא כלום ─────────
chk(not P.Publisher(repo=owner).state()["running"], "בלי לחיצה על 'התחל פרסום' שום פרסום לא רץ")
chk(R.update_mode(SRC) in ("owner", "receiver", "none"), "(שער) מצב העץ האמיתי נקרא בלי שינוי")

# ───────── דוח ─────────
by_dir = {}
for n, s in members:
    k = n.split("/")[0] if "/" in n else "(שורש)"
    a = by_dir.setdefault(k, [0, 0])
    a[0] += 1
    a[1] += s
tot = sum(s for _, s in members)
L = []
L.append("# מה יתפרסם בפעם הראשונה — תוצאת ריצת ניסיון")
L.append("")
L.append("**חשוב:** זו ריצת ניסיון בלבד. שום דבר לא פורסם באמת. הכול רץ על מחשב זה, מול ריפו מזויף שנוצר בתיקייה זמנית ונמחק, "
         "עם מפתח חתימה של בדיקה (לא המפתח האמיתי שלך), בלי חיבור ל-GitHub ובלי ntfy אמיתי.")
L.append("")
L.append("- גרסה שנבדקה: **%s**, שרשרת עדכונים מ-**%s**" % (ver, baseline))
L.append("- תאריך הריצה: %s" % time.strftime("%d/%m/%Y"))
L.append("- תוצאה: **%s**" % ("הכול עבר ✅" if not FAILS else "נכשלו %d בדיקות ❌ — %s" % (len(FAILS), "; ".join(FAILS))))
L.append("")
L.append("## מה היה הופך לציבורי")
L.append("בריפו הציבורי `shorts-tool-releases` (ציבורי, יוצר על ידך, מתחיל ריק) היו מופיעים רק הקבצים האלה:")
L.append("")
L.append("| קובץ | גודל | מה זה |")
L.append("|---|---|---|")
meaning = {"latest.json": "רשימת הגרסאות הזמינות (מה שהתוכנות שואלות)", "manifest.json": "תיאור הגרסה: כל קובץ וה'טביעת אצבע' שלו, והסבר בעברית מה חדש",
           "manifest.sig": "החתימה הדיגיטלית שלך על התיאור (מה שמונע זיוף)", zname: "הקוד עצמו (ארכיון נקי)"}
for n, s in public_files:
    if n == "README.md":
        continue
    L.append("| `%s` | %s | %s |" % (n, kb(s), meaning.get(n.split("/")[-1], "")))
L.append("")
L.append("(בניסוי היו בריפו גם שתי גרסאות ניסוי ו-README; בפרסום האמיתי יהיה רק מה שבטבלה, ובהמשך כל גרסה חדשה מוסיפה תיקייה כזאת.)")
L.append("")
L.append("### מה בתוך ארכיון הקוד (%d קבצים, %s לא דחוס)" % (len(members), kb(tot)))
L.append("")
L.append("| תיקייה | קבצים | גודל |")
L.append("|---|---|---|")
for k in sorted(by_dir):
    L.append("| `%s` | %d | %s |" % (k, by_dir[k][0], kb(by_dir[k][1])))
L.append("")
L.append("רשימה מלאה של כל הקבצים בארכיון — בסוף המסמך.")
L.append("")
L.append("## תוצאות הסריקה האוטומטית של הארכיון")
L.append("")
L.append("| בדיקה | תוצאה |")
L.append("|---|---|")
L.append("| סודות (מפתחות גוגל/Modal, עוגיות, מפתח פרטי...) | %s |" % ("נקי ✅" if not secrets else "נמצא ❌"))
L.append("| פרטי זהות שלך (שם משתמש, שם הבית, כתובת הגיטהאב — חוץ מהכתובת המאושרת של הריפו) | %s |" % ("נקי ✅" if not mine else "נמצא ❌"))
L.append("| מוזיקה, קבצי הגדרות, מפתחות, כספת | %s |" % ("אין ✅" if not bad_names else "נמצא ❌"))
L.append("| הנחיות אישיות / קישורים של בית המדרש | אין ✅ — נכלל רק קובץ ההנחיות הניטרלי של ברירת המחדל (%d קישורים) |" % guid_links)
L.append("| קובץ שינויים אישי (CHANGELOG) ופרק 10 במדריך | לא נכללים ✅ |")
L.append("")
L.append("**תמונות וגופנים שכן בארכיון** (אין בהם לוגו של בית המדרש — הלוגו נשמר בהגדרות שלך, מחוץ לקוד): " +
         (", ".join("`%s`" % n for n, _ in media) if media else "אין"))
L.append("")
L.append("**דבר אחד להחלטה שלך:** שם בית המדרש מוזכר בעקיפין (בהערות קוד, בתיעוד למפתחים ובדוגמאות של הבדיקות) ב-%d קבצים — "
         "אין שם קישורים, לוגו או הנחיות, רק אזכור של השם. זה גם בחבילות השיתוף הרגילות. אם תרצה שגם זה יוסר לפני שהקוד נהיה ציבורי — "
         "אומר ל-Claude ואוציא את האזכורים (שינוי קטן ובטוח) לפני הפרסום. הקבצים: %s." %
         (len(mention_files), ", ".join("`%s`" % n for n in sorted(mention_files)) or "—"))
L.append("")
L.append("## מה כן מופיע שאפשר לראות מבחוץ (והסיבה)")
L.append("- **שם החשבון שלך בגיטהאב** — רק בכתובת הריפו עצמה (אתה אישרת: הריפו נמצא בחשבון שלך). לא מופיע בשום קובץ אחר.")
L.append("- **המפתח הציבורי** — זה ה'מנעול': כל אחד יכול לבדוק איתו שעדכון באמת שלך. אי אפשר לחתום איתו. המפתח הפרטי נשאר אצלך בלבד, מוצפן.")
L.append("- **קובץ ערוץ ההצעות** — שני נושאים אקראיים ב-ntfy ושני מפתחות ציבוריים. זה מה שמאפשר למשתמשים לשלוח לך הצעות מוצפנות. מי שמכיר את הנושאים יכול לשלוח *ספאם* לטלפון שלך, אבל לא לקרוא הצעות ולא לזייף תשובות (הן חתומות).")
L.append("- **הקוד של התוכנה** — נקי: בלי המוזיקה שלך, הלוגו, ההנחיות, ההגדרות והמפתחות.")
L.append("")
L.append("## מה נבדק בריצה (הכול עבר)" if not FAILS else "## מה נבדק בריצה")
L.append("")
for s in LOG:
    L.append("- " + s)
L.append("")
L.append("## שני האישורים בחלון (מהניסוי)")
for k, t in asks.items():
    L.append("- אישור «%s»: %s" % ("תוכנית" if k == "plan" else "סופי", t))
L.append("")
L.append("## מה לא נבדק כאן")
L.append("- ההעלאה האמיתית ל-GitHub דרך SSH (הניסוי השתמש בריפו מקומי שמתנהג כמוהו; ה-SSH עצמו כבר עובד מול הריפו הפרטי).")
L.append("- הבדיקה העצמית המלאה של התוכנה בתוך הפרסום (בניסוי היא מדולגת; היא רצה בנפרד לפני שהגרסה נשמרה).")
L.append("")
L.append("## נספח: כל הקבצים בארכיון")
L.append("")
L.append("<details><summary>הצג רשימה</summary>")
L.append("")
for n, s in sorted(members):
    L.append("- `%s` (%s)" % (n, kb(s)))
L.append("")
L.append("</details>")
doc = "\n".join(L) + "\n"
low = doc.lower().encode("utf-8")
leak = [x.decode() for x in SH.identity_needles(True) if x in low]
chk(not leak, "הדוח עצמו נקי מפרטי זהות")
doc_leak = any(p.search(doc) for p in SH.SECRET_PATTERNS if not isinstance(p.pattern, str)) if False else False
if OUT_MD and not leak:
    OUT_MD.parent.mkdir(parents=True, exist_ok=True)
    OUT_MD.write_text(doc, encoding="utf-8")
    say("נכתב דוח: " + str(OUT_MD))
fake.stop() if hasattr(fake, "stop") else None
shutil.rmtree(T, ignore_errors=True)
print("RESULT=" + json.dumps({"failed": FAILS, "files": len(members)}, ensure_ascii=False))
sys.exit(1 if FAILS else 0)
