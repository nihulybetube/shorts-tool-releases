# -*- coding: utf-8 -*-
"""בדיקה: כרטיס 25 (1/11/2026) — פרופיל לכל רב + "מה לחפש" בבחירת הקטעים. בלי רשת, בלי וידאו, בלי Gemini.
  1. זיהוי רב לפי שם מלא (כ"ץ עם מירכאות, וייצן עם ראשי תיבות; מלמד ≠ מלמד; פרלמן — אין פרופיל).
  2. ברירות המחדל שסוכמו: sub_gap, המצלמה של בן שושן, הסרת חזרות רק לכץ.
  3. שמירה / אפס / בטל; המצלמה והעצירה מהפרופיל; הצעה "להוסיף לפרופיל?" רק אחרי 2 תיקונים ממקומות שונים.
  4. הסרת חזרות: שמע סינתטי — חיתוך בשקט, "נשארה" כשאין שקט, מילים מודגשות לא נוגעים, חתיכה קצרה מבטלת, rejoin.
  5. "מה לחפש": בקשה ריקה = אותן הנחיות בייט-בייט; בקשה נכנסת להנחיות; "לא מצאתי" נקרא ונשמר; החלפת בקשה.
הרצה: ~/.local/share/yeshiva-shorts/venv/bin/python3 pipeline/tests/test_rabbis.py"""
import json
import os
import sys
import tempfile
from pathlib import Path

T = Path(tempfile.mkdtemp(prefix="ys25_"))
os.environ["MAKE_SHORT_RABBIS"] = str(T / "rabbis")
os.environ["MAKE_SHORT_SETTINGS"] = str(T / "settings.json")
os.environ["SHORTS_CONFIG_DIR"] = str(T / "cfg")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import numpy as np  # noqa: E402

import make_short_rabbis as RB  # noqa: E402
import make_short_repeats as RP  # noqa: E402

fails = []


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg)
    if not cond:
        fails.append(msg)


print("1. זיהוי")
check(RB.get('הרב חיים כ"ץ') and RB.get("הרב חיים כץ")["name"] == "הרב חיים כץ", 'כ"ץ עם מירכאות = כץ')
check(RB.get("הרה\"ג חיים כץ שליט\"א") is not None, "תארים לא משנים")
check(RB.get("הרב ש. יוסף וייצן") and RB.get("הרב יוסף וייצן"), "וייצן עם ראשי תיבות (השם הישן)")
check(RB.get("הרב יהודה מלמד")["sub_gap"] == 1.5, "הרב יהודה מלמד — יש")
check(RB.get("הרב זלמן ברוך מלמד") is None, "הרב זלמן ברוך מלמד ≠ הרב יהודה מלמד — אין פרופיל")
check(RB.get("הרב יוחאי פרלמן") is None, "פרלמן — אין פרופיל (שיעור אחד שבו עמד)")
check(RB.get("") is None and RB.get(None) is None, "שם ריק")

print("2. ברירות המחדל")
gap = {p["name"] for p in RB.listing() if p["sub_gap"] == 1.5}
check(gap == {"הרב חיים בן שושן", "הרב משה גנץ", "הרב בן ציון אוריאל", "הרב יוסף וייצן", "הרב עידו יעקובי",
              "הרב יהודה מלמד", "הרב חיים כץ"}, "שבעת הרבנים עם SHORTS_SUB_GAP=1.5")
check([p["name"] for p in RB.listing() if p["dedupe_repeats"]] == ["הרב חיים כץ"], "הסרת חזרות — רק כץ")
check(RB.camera_env("הרב חיים בן שושן") == {"CAM_TRIGGER": "0.8", "CAM_PAN": "0.055"}, "מצלמה של בן שושן 0.8/0.055")
check(RB.camera_env("הרב חיים כץ") == {} and RB.camera_env("הרב אחר") == {}, "לאחרים — מצלמה רגילה")
check(not RB.dedupe_on("הרב משה גנץ") and RB.dedupe_on('הרב חיים כ"ץ'), "dedupe_on")

print("3. שמירה / אפס / בטל / מצלמה / עצירה")
import build_ass as B  # noqa: E402
import camera_path as CP  # noqa: E402
import face_track as F  # noqa: E402
base_gap = B.GAP_THRESHOLD
check(RB.apply_gap("הרב חיים כץ") == 1.5 and B.GAP_THRESHOLD == 1.5, "apply_gap קובע 1.5 לכץ")
RB.apply_gap("הרב יוחאי פרלמן")
check(B.GAP_THRESHOLD == base_gap, "ורב בלי פרופיל — חוזר לברירת המחדל")
d0 = (F.TRIGGER_SEC, F.MAX_PAN_RATE)
os.environ["CAM_RABBI"] = "הרב חיים בן שושן"
CP.apply_env({})
check((F.TRIGGER_SEC, F.MAX_PAN_RATE) == (0.8, 0.055), "camera_path.apply_env מציב 0.8/0.055")
CP._reset()
check((F.TRIGGER_SEC, F.MAX_PAN_RATE) == d0, "_reset מחזיר את הקבועים")
os.environ["CAM_RABBI"] = "הרב משה גנץ"
CP.apply_env({})
check((F.TRIGGER_SEC, F.MAX_PAN_RATE) == d0, "לגנץ המצלמה לא משתנה")
CP._reset()
os.environ.pop("CAM_RABBI")
check(CP.prof_sig("הרב חיים בן שושן") != CP.prof_sig("הרב משה גנץ"), "חתימת פרופיל שונה (מדידה ישנה נפסלת)")
RB.save("הרב משה גנץ", {"sub_gap": 2.0, "words": [{"right": "נצח ישראל", "wrong": "נצח ישראלי"}]})
check(RB.get("הרב משה גנץ")["sub_gap"] == 2.0 and RB.get("הרב משה גנץ")["custom"], "נשמר")
check("נצח ישראל" in RB.prompt_text(["הרב משה גנץ"]) and RB.hint_words("הרב משה גנץ") == ["נצח ישראל"], "המילים נכנסות להנחיות ולרמז")
check(RB.prompt_text(["הרב חיים כץ"]) == "", "לרב בלי מילים — שום בלוק")
RB.undo("הרב משה גנץ")
check(RB.get("הרב משה גנץ")["sub_gap"] == 1.5 and not RB.get("הרב משה גנץ")["custom"], "בטל — חזרה לברירת המחדל")
RB.save("הרב משה גנץ", {"sub_gap": 3.0})
RB.save("הרב משה גנץ", {"sub_gap": 4.0})
RB.undo("הרב משה גנץ")
check(RB.get("הרב משה גנץ")["sub_gap"] == 3.0, "בטל — צעד אחד אחורה")
RB.reset("הרב משה גנץ")
check(RB.get("הרב משה גנץ")["sub_gap"] == 1.5 and not RB.get("הרב משה גנץ")["custom"], "אפס")
try:
    RB.save("הרב משה גנץ", {"sub_gap": 99})
    check(False, "ערך מחוץ לטווח נדחה")
except ValueError:
    check(True, "ערך מחוץ לטווח נדחה")
RB.save("הרב חדש לגמרי", {})
check(RB.get("הרב חדש לגמרי") and not RB.get("הרב חדש לגמרי")["sub_gap"], "רב חדש נוצר, בלי כללים")
names = [p["name"] for p in RB.listing()]
check("הרב חדש לגמרי" in names and len(names) == 8, "הרשימה כוללת את החדש")
# הצעות
RB.note_corrections("הרב חיים כץ", [("תמצי", "תמצית")], where="L1/clip1")
RB.note_corrections("הרב חיים כץ", [("תמצי", "תמצית")], where="L1/clip1")
check(RB.offers("הרב חיים כץ") == [], "אותו קליף פעמיים = פעם אחת (אין הצעה)")
RB.note_corrections("הרב חיים כץ", [("תמצי", "תמצית")], where="L2/clip1")
o = RB.offers("הרב חיים כץ")
check(len(o) == 1 and o[0]["right"] == "תמצית" and o[0]["n"] == 2, "שני מקומות שונים → הצעה")
check(RB.offers("הרב משה גנץ") == [], "הצעה היא לכל רב לחוד")
RB.answer_offer("הרב חיים כץ", "תמצי", "תמצית", True)
check(RB.offers("הרב חיים כץ") == [] and RB.hint_words("הרב חיים כץ") == ["תמצית"], "אישור — נכנס לפרופיל ההצעה יורדת")
RB.note_corrections("הרב עידו יעקובי", [("א", "ב")], where="x1")
RB.note_corrections("הרב עידו יעקובי", [("א", "ב")], where="x2")
RB.answer_offer("הרב עידו יעקובי", "א", "ב", False)
check(RB.offers("הרב עידו יעקובי") == [] and RB.hint_words("הרב עידו יעקובי") == [], "דחייה — לא נכנס ולא מוצע שוב")

print("4. הסרת חזרות (שמע סינתטי)")
SR = RP.SR
rng = np.random.default_rng(1)


def synth(spans, total):
    """מערך שמע: רעש 'דיבור' בטווחים, שקט (רעש זעיר) בשאר. spans = [(start,end)] בשניות יחסיות ל-lo=0."""
    a = rng.normal(0, 0.0005, int(total * SR)).astype("float32")
    for s, e in spans:
        a[int(s * SR):int(e * SR)] += rng.normal(0, 0.1, int(e * SR) - int(s * SR)).astype("float32")
    return a


def words_for(seq):
    return [{"word": w, "start": s, "end": e} for w, s, e in seq]


# 20 שניות: ... "זה" 8.0-8.4, "הוא" 9.0-9.3, "הוא" 9.9-10.2, "מבין" 10.8-11.2 — שקט 0.6 משני צדי הראשון ובינו לשני
seq = [("זה", 8.0, 8.4), ("הוא", 9.0, 9.3), ("הוא", 9.9, 10.2), ("מבין", 10.8, 11.2)]
spans = [(1, 7.9), (8.0, 8.4), (9.0, 9.3), (9.9, 10.2), (10.8, 18.5)]
au = synth(spans, 20)
ws = words_for(seq)
pcs, recs = RP.plan_piece(ws, au, 0.0, 1.0, 18.5, RB.KEEP_REPEATS, opening=True)
check(len(recs) == 1 and recs[0]["action"] == "removed" and recs[0]["which"] == "first", "«הוא הוא» — הראשונה הוסרה")
check(len(pcs) == 2 and pcs[0][0] == 1.0 and pcs[1][1] == 18.5, "החתיכה נחתכה לשתיים בקצוות המקוריים")
c1, c2 = recs[0]["removed"]
check(8.4 < c1 < 9.0 and 9.3 < c2 < 9.9, "נקודות החיתוך בתוך השקט (%.2f, %.2f)" % (c1, c2))
check(RP.rejoin([list(x) for x in pcs], recs[0]["removed"]) == [[1.0, 18.5]], "rejoin מחזיר חתיכה אחת")
check(RP.rejoin([[1.0, 5.0], [6.0, 18.5]], recs[0]["removed"]) is None, "rejoin — גבולות שזזו הרבה → None")

# שקט קצר מדי (0.1s בין המילים ומאחוריהן): נשארת
seq2 = [("זה", 8.0, 8.4), ("הוא", 8.5, 8.8), ("הוא", 8.9, 9.2), ("מבין", 9.3, 9.7)]
au2 = synth([(1, 9.7 + 0.0), (10.0, 18.5)], 20)
p2, r2 = RP.plan_piece(words_for(seq2), au2, 0.0, 1.0, 18.5, RB.KEEP_REPEATS, opening=True)
check(p2 == [(1.0, 18.5)] and r2 and r2[0]["action"] == "kept" and "שקט" in r2[0]["why"], "אין שקט → נשארת, עם הסבר")

# מילה מודגשת — לא נוגעים
seq3 = [("זה", 8.0, 8.4), ("מאוד", 9.0, 9.3), ("מאוד", 9.9, 10.2), ("חשוב", 10.8, 11.2)]
p3, r3 = RP.plan_piece(words_for(seq3), au, 0.0, 1.0, 18.5, RB.KEEP_REPEATS, opening=True)
check(p3 == [(1.0, 18.5)] and r3 == [], "«מאוד מאוד» — הדגשה, לא נוגעים")

# חזרה ליד קצה החתיכה — לא נוגעים (EDGE)
seq4 = [("הוא", 1.2, 1.5), ("הוא", 1.9, 2.2)]
p4, r4 = RP.plan_piece(words_for(seq4), au, 0.0, 1.0, 18.5, (), opening=True)
check(p4 == [(1.0, 18.5)] and r4 == [], "חזרה בתוך 0.6 ש' מהקצה — לא נוגעים")

# החיתוך היה משאיר פתיחה קצרה מ-6 ש' → מבוטל
seq5 = [("זה", 4.0, 4.4), ("הוא", 5.0, 5.3), ("הוא", 5.9, 6.2), ("מבין", 6.8, 7.2)]
au5 = synth([(1, 3.9), (4.0, 4.4), (5.0, 5.3), (5.9, 6.2), (6.8, 18.5)], 20)
p5, r5 = RP.plan_piece(words_for(seq5), au5, 0.0, 1.0, 18.5, (), opening=True)
check(p5 == [(1.0, 18.5)] and r5[0]["action"] == "kept" and "קצרה" in r5[0]["why"], "פתיחה קצרה מדי → נשארת")
p5b, r5b = RP.plan_piece(words_for(seq5), au5, 0.0, 1.0, 18.5, (), opening=False)
check(r5b[0]["action"] == "removed" and len(p5b) == 2, "באמצע הקליף (לא פתיחה) החיתוך מותר ב-3 ש'+")

print("4b. dedupe_clips (החיבור ל-prepare) על קובץ wav אמיתי")
import wave  # noqa: E402

import make_short as MS  # noqa: E402
wp = T / "win.wav"
with wave.open(str(wp), "wb") as wf:
    wf.setnchannels(1)
    wf.setsampwidth(2)
    wf.setframerate(SR)
    wf.writeframes((np.clip(au, -1, 1) * 32767).astype("<i2").tobytes())
clips = [{"name": "clip1", "cuts": [(1.0, 18.5)]}, {"name": "clip2", "cuts": [(1.0, 18.5)]}]
wins = [(clips[0], 0, 0.0, wp), (clips[1], 0, 0.0, wp)]
out = MS.dedupe_clips(clips, wins, {str(wp): [dict(w) for w in ws]})
check(set(out) == {"clip1", "clip2"} and len(clips[0]["cuts"]) == 2 and len(clips[1]["cuts"]) == 2, "שני הקליפים נחתכו לשתי חתיכות")
check(out["clip1"][0]["piece"] == 0 and out["clip1"][0]["action"] == "removed", "הרשומה נשמרת עם מספר החתיכה")
clean = [{"name": "clip1", "cuts": [(1.0, 18.5)]}]
check(MS.dedupe_clips(clean, [(clean[0], 0, 0.0, wp)], {str(wp): [{"word": "x", "start": 2.0, "end": 2.4}]}) == {} and clean[0]["cuts"] == [(1.0, 18.5)],
      "בלי חזרות — שום שינוי")

print("5. מה לחפש")
import make_short_pick as PK  # noqa: E402
les = [{"n": 1, "title": "שיעור א", "rabbi": "הרב חיים כץ", "duration": 1800, "text": "[00:10] טקסט"}]
p_none = PK.build_prompt(les)
check(PK.build_prompt(les, request="") == p_none and PK.build_prompt(les, request="   ") == p_none, "בקשה ריקה = הנחיות זהות בייט-בייט")
p_req = PK.build_prompt(les, request="הקטע על הילדות שלו, ובנוסף עוד שני קטעים חזקים")
check("הילדות שלו" in p_req and "for_request" in p_req and "not_found" in p_req and "אל תמציא" in p_req, "הבקשה והכללים נכנסים")
check(p_req.index("בקשה מיוחדת") < p_req.index("התמלול:") and p_req.replace(p_req[p_req.index("🎯"):p_req.index("שאר הכללים") ], "") != "", "הבלוק לפני התמלול")
check("שיעור 1" in PK.build_prompt([dict(les[0], request="הילדות")], mixed=True), "בקשה לכל שיעור (שיעורים יחד)")
rbw = PK.build_prompt(les)
RB.save("הרב חיים כץ", {"words": [{"right": "אור החיים", "wrong": None}]})
check("אור החיים" in PK.build_prompt(les) and "אור החיים" not in rbw, "מילות הרב נכנסות להנחיית הבחירה")
notes = []
ans = json.dumps([{"not_found": True, "lesson": 1, "note": "הרב לא מדבר על ילדות; כן על הלכות"},
                  {"start": "0:10", "end": "0:40", "opening": "טקסט", "closing": "טקסט", "title": "כותרת", "for_request": True}])
got = PK.parse_answer(ans, notes)
check(len(got) == 1 and got[0].get("for_request") and notes[0]["lesson"] == 1 and "ילדות" in notes[0]["note"], "not_found ו-for_request נקראים")
check("for_request" not in PK.parse_answer(json.dumps([{"start": "0:10", "end": "0:40", "opening": "ב", "closing": "ג"}]))[0],
      "בלי for_request — שום שדה חדש בהצעה")
# add_answer עם "לא מצאתי" בלבד
P = T / "lesson"
(P / "pick").mkdir(parents=True)
(P / "pick" / "transcript.txt").write_text("[00:10] טקסט של השיעור", encoding="utf-8")
(P / "pick" / "words.json").write_text(json.dumps({"words": []}), encoding="utf-8")
st = {"kind": "lesson", "url": "u", "dir": str(P), "title": "t", "picks": [], "request": "הילדות",
      "lessons": [{"n": 1, "title": "t", "rabbi": "הרב חיים כץ", "words": "pick/words.json", "text_file": "pick/transcript.txt"}]}
PK.make_chunks(st)
n, warns = PK.add_answer(st, json.dumps([{"not_found": True, "lesson": 1, "note": "אין"}]), "g1", src="gemini")
check(n == 0 and st["request_notes"][0]["note"] == "אין" and st["chunks"]["gemini"][0]["status"] == "answered", "תשובה 'לא מצאתי' בלבד — נשמרת, לא שגיאה, החלק נחשב נענה")
check(not any("אין הצעה" in w for w in warns), "ואין אזהרת 'אין הצעה לשיעורים'")
st["picks"] = [{"id": "p1", "lesson": 1, "selected": True, "title": "אוטומטי"},
               {"id": "p2", "lesson": 1, "selected": True, "user_edited": True, "title": "ערך"},
               {"id": "p3", "lesson": 1, "dropped": True, "title": "ויתר"}]
PK.save(P, st)
st2, ch = PK.set_request(P, "הילדות")
check(not ch, "אותה בקשה — שום שינוי")
st2, ch = PK.set_request(P, "התלמיד שלו")
check(ch and st2["request"] == "התלמיד שלו" and "request_notes" not in st2 and st2["chunks"]["gemini"][0]["status"] == "pending", "בקשה חדשה: הערות 'לא מצאתי' נמחקות והחלק ממתין")
check([p["id"] for p in st2["picks"]] == ["p2", "p3"], "הצעה שסומנה אוטומטית יוצאת; מה שערך/ויתר עליו נשאר")
st2, ch = PK.set_request(P, "")
check(ch and "request" not in st2, "בקשה ריקה → חזרה להתנהגות הרגילה")
check("התלמיד" in PK.chunk_prompt(PK.set_request(P, "התלמיד שלו")[0], "g1"), "chunk_prompt כולל את הבקשה השמורה")

print()
if fails:
    print("נכשלו %d: %s" % (len(fails), "; ".join(fails)))
    sys.exit(1)
print("כל הבדיקות עברו")
