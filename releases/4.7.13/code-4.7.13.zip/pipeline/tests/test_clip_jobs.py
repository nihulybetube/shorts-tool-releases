# -*- coding: utf-8 -*-
"""בדיקה: עבודות של קליף אחד (כרטיס 12, 21/10/2026).

  1. החלפת מוזיקה (job 24 — הסתיימה בשרת והכרטיס נשאר "מתעדכן…") — נכנסת לתור עם שם, ו-/api/project
     מראה "done" לקליף תוך שניות מהרגע שהעבודה באמת נגמרה (זה מה שהדף קורא כדי להוריד את "מתעדכן…").
  2. החלפת מוזיקה בקליף 1 רצה מיד גם כשקליף 2 נבנה מחדש (קלה לא מחכה לכבדה).
  3. /api/job של עבודה שהשרת כבר לא מכיר → "gone" (לא שגיאה שעוצרת את הדף).
  4. שמירה עם גרסה ישנה של קובץ העריכה (בנייה מחדש כתבה בינתיים) → התיקונים נמזגים, לא דורסים.
  5. "סיים את הקליף הזה" → עבודת finish עם --clips=clip1 בלבד, בתוך הכרטיס (clip בעבודה).

הרצה:  ~/yeshiva-shorts-skill/shorts.sh py ../tests/test_clip_jobs.py   (או python3 ישירות)
רץ בתיקייה זמנית משלו, על פורט פנוי, עם עבודות מדומות (job_stub.py) — לא נוגע בשום שיעור אמיתי."""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def call(port, path, body=None):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path),
                                 data=None if body is None else json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        return json.loads(urllib.request.urlopen(req, timeout=10).read().decode())
    except urllib.error.HTTPError as e:
        return json.loads(e.read().decode())


def make_project(root):
    import make_short as MS
    P = root / "projects" / "תוכנה" / "2026-10-21_auto-TESTclipjob"
    (P / "לעריכה").mkdir(parents=True)
    (P / "work" / "clips").mkdir(parents=True)
    clips = []
    for n in ("clip1", "clip2"):
        c = {"name": n, "cuts": [[10.0, 30.0]], "clean": "work/clips/%s_clean.mp4" % n, "seconds": 20.0,
             "ear1": "work/subtitles/%s_ear1.json" % n, "edit": str(P / "לעריכה" / ("%s.txt" % n)), "doubts": [],
             "camera": "default", "framing": None}
        MS.write_edit(c["edit"], c, P, "כותרת " + n, "תיאור", "", "אחת שתיים שלוש ארבע חמש שש שבע", "")
        clips.append(c)
    json.dump({"url": "https://www.youtube.com/watch?v=TESTclipjob", "video_title": "בדיקה", "rabbi": "הרב בדיקה",
               "series": "סדרת בדיקה", "project": str(P), "clips": clips},
              open(P / "make_short.json", "w", encoding="utf-8"), ensure_ascii=False)
    return P


def main():
    root = Path(tempfile.mkdtemp(prefix="ys_cliptest_"))
    marks = root / "marks"
    marks.mkdir()
    P = make_project(root)
    port = free_port()
    env = dict(os.environ, MAKE_SHORT_PORT=str(port), MAKE_SHORT_JOB_STUB=str(HERE / "job_stub.py"),
               MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_SETTINGS=str(root / "settings.json"), MAKE_SHORT_IDLE_EXIT="0",
               SHORTS_PROJECTS=str(root / "projects"), MAKE_SHORT_QUEUE=str(root / "queue.json"),
               STUB_MARK=str(marks), STUB_SECS="2", STUB_SECS_REBUILD="6", GEMINI_API_KEY="", PYTHONUNBUFFERED="1")
    srv = subprocess.Popen([sys.executable, "-u", str(SCRIPTS / "make_short_app.py")], env=env, cwd=str(root),
                           stdout=open(root / "server.log", "w"), stderr=subprocess.STDOUT)
    fails = []

    def check(cond, msg):
        print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
        if not cond:
            fails.append(msg)
    try:
        for _ in range(60):
            try:
                call(port, "/api/home")
                break
            except OSError:
                time.sleep(0.3)
        p = str(P)

        print("1+2. בנייה מחדש של קליף 2 (6 ש') ובזמנה החלפת מוזיקה בקליף 1 (2 ש')")
        r1 = call(port, "/api/rebuild", {"project": p, "clip": "clip2"})
        check("job" in r1, "בנייה מחדש נכנסה לתור: %s" % r1)
        time.sleep(0.5)
        r2 = call(port, "/api/swap", {"project": p, "clip": "clip1", "mode": "swap"})
        check("job" in r2, "החלפת מוזיקה נכנסה לתור למרות שקליף 2 בעבודה: %s" % r2)
        qv = call(port, "/api/queue")["items"]
        sw = next((q for q in qv if q["kind"] == "swap"), None)
        check(bool(sw) and sw["what"] == "החלפת מוזיקה" and "קליף 1" in sw["clip"],
              "בחלונית התור יש פריט בשם: %s" % ((sw or {}).get("what"), (sw or {}).get("clip")).__str__())
        seen_run, seen_done = False, None
        t0 = time.time()
        while time.time() - t0 < 15:
            cj = call(port, "/api/project?p=" + urllib.request.quote(p)).get("clip_jobs", {})
            c1 = cj.get("clip1") or {}
            if c1.get("state") in ("working", "building"):
                if not seen_run:
                    c2 = cj.get("clip2") or {}
                    check(c2.get("state") in ("working", "building"), "באותו רגע קליף 2 עדיין נבנה (במקביל, לא בתור אחריו)")
                seen_run = True
            if c1.get("state") == "done":
                seen_done = time.time()
                break
            time.sleep(0.25)
        end = float((marks / "swap_clip1.end").read_text()) if (marks / "swap_clip1.end").exists() else None
        check(seen_run, "קליף 1 נראה 'בעבודה' בזמן ההחלפה")
        check(bool(seen_done and end), "קליף 1 עבר ל-done")
        if seen_done and end:
            lag = seen_done - end
            check(lag < 3.0, "השרת מדווח 'נגמר' %.2f ש' אחרי סוף העבודה (צריך פחות מ-3)" % lag)
        rb_end = marks / "rebuild_clip2.end"
        check(not rb_end.exists() or float(rb_end.read_text()) > (end or 0),
              "ההחלפה הסתיימה לפני הבנייה של קליף 2 (לא חיכתה לה)")

        print("3. /api/job של עבודה לא מוכרת")
        g = call(port, "/api/job?id=99999")
        check(g.get("gone") is True and g.get("running") is False, "מחזיר gone במקום שגיאה")

        print("4. שמירה עם גרסה ישנה → מיזוג")
        import make_short as MS
        st = call(port, "/api/project?p=" + urllib.request.quote(p))
        c1 = next(c for c in st["clips"] if c["name"] == "clip1")
        base_ver = c1["ver"]
        # "בנייה מחדש" כותבת גרסה חדשה: מילה נוספה בהתחלה ובסוף
        cc = json.load(open(P / "make_short.json", encoding="utf-8"))["clips"][0]
        MS.write_edit(cc["edit"], cc, P, "כותרת clip1", "תיאור", "", "אפס אחת שתיים שלוש ארבע חמש שש שבע שמונה", "")
        # בינתיים בדף: תיקן "שלוש" ל"שלושה" (על הגרסה הישנה)
        r = call(port, "/api/save", {"project": p, "rabbi": "הרב בדיקה", "series": "סדרת בדיקה", "reviewed": ["clip1"],
                                     "clips": [{"name": "clip1", "ver": base_ver, "title": "כותרת clip1", "desc": "תיאור",
                                                "tags": "", "text": "אחת שתיים שלושה ארבע חמש שש שבע", "yt": ""}]})
        m = (r.get("merged") or {}).get("clip1") or {}
        check(m.get("text") == "אפס אחת שתיים שלושה ארבע חמש שש שבע שמונה", "טקסט ממוזג: %s" % m.get("text"))
        check(m.get("applied") == 1 and not m.get("conflicts"), "תיקון אחד הוחל, בלי התנגשויות")
        saved = MS.read_edit_raw(cc["edit"])["text"]
        check(saved == m.get("text"), "הקובץ עצמו מכיל את הממוזג")
        st2 = json.load(open(P / "make_short.json", encoding="utf-8"))
        check(st2.get("reviewed") == ["clip1"], "'נבדק' נשמר בקובץ השיעור")
        t, n, conf = MS.merge3("א ב ג ד", "א ב גג ד", "ב ג ד ה")
        check(t == "ב גג ד ה" and n == 1, "merge3: תיקון באמצע נשמר כשההתחלה ירדה (%s)" % t)
        t, n, conf = MS.merge3("א ב ג ד", "אא ב ג ד", "ב ג ד ה")
        check(t == "ב ג ד ה" and conf, "merge3: תיקון במילה שירדה — לא מנחשים, מדווח (%s)" % conf)

        print("5. סיום של קליף אחד")
        time.sleep(7)                                    # שקליף 2 יסיים
        r = call(port, "/api/finish", {"project": p, "clips": ["clip1"]})
        check("job" in r, "finish לקליף אחד נכנס לתור")
        j = call(port, "/api/job?id=" + r["job"])
        check(j.get("clip") == "clip1" and j.get("cmd", [])[-1] == "--clips=clip1", "העבודה מסומנת לקליף 1 בלבד")
        time.sleep(0.5)
        r_other = call(port, "/api/swap", {"project": p, "clip": "clip2", "mode": "swap"})
        check("job" in r_other, "בזמן הסיום של קליף 1 — אפשר לשנות את קליף 2")
        r_same = call(port, "/api/swap", {"project": p, "clip": "clip1", "mode": "swap"})
        check("error" in r_same and "קליף 1" in r_same["error"], "ואת קליף 1 עצמו — לא (הודעה ברורה): %s" % r_same.get("error"))
    finally:
        srv.terminate()
        try:
            srv.wait(5)
        except subprocess.TimeoutExpired:
            srv.kill()
        if not fails:
            shutil.rmtree(root, ignore_errors=True)
        else:
            print("  (נשאר לבדיקה: %s)" % root)
    print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d בדיקות" % len(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
