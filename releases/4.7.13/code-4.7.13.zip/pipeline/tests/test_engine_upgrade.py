# -*- coding: utf-8 -*-
"""בדיקה: "נסה מנוע חדש יותר" (29/10/2026) — עם pip מזויף, בלי לגעת בסביבה האמיתית.

  1. newer() מזהה גרסה חדשה יותר (מטמון PyPI), ההודעה השקטה נסגרת לחודש.
  2. החדשה נכשלת בבדיקה העצמית → הגרסאות הקודמות חוזרות בדיוק, הקובץ המוצמד לא משתנה, יציאה 1.
  3. ההתקנה עצמה נכשלת → חוזרים לקודמות.
  4. החדשה עוברת → נשארת, ונרשמת בקובץ המוצמד (רק השורות שהשתנו; ההערות נשארות).
  5. בשרת: תמלול שנפל ב-ModuleNotFoundError + יש חדשה → התראה "engine" עם הכפתור;
     הכפתור לא רץ כשיש עבודה; בזמן ההחלפה עבודה חדשה לא מתחילה."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"

FAKE_PIP = r'''
import json, os, sys
st = os.environ["FAKE_PIP_STATE"]
v = json.load(open(st))
a = sys.argv[1:]
if a[0] == "freeze":
    for k, x in sorted(v["now"].items()):
        print("%s==%s" % (k, x))
    sys.exit(0)
if a[0] == "install":
    if os.environ.get("FAKE_PIP_FAIL") and "--upgrade" in a:
        print("ERROR: no matching distribution", file=sys.stderr); sys.exit(1)
    pk = [x for x in a[1:] if not x.startswith("-")]
    for p in pk:
        if "==" in p:
            n, x = p.split("=="); v["now"][n] = x
        elif "--upgrade" in a:
            v["now"].update({k: x for k, x in v["new"].items() if k == p or k in v.get("deps", [])})
    json.dump(v, open(st, "w"))
'''
CHECK = "import os,sys; print('  ✓ fake'); sys.exit(0 if os.environ.get('FAKE_CHECK_OK') else 1)"


def main():
    T = Path(tempfile.mkdtemp(prefix="ys_enginetest_"))
    fails = []

    def check(cond, msg):
        print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
        if not cond:
            fails.append(msg)
    try:
        (T / "pip.py").write_text(FAKE_PIP)
        (T / "check.py").write_text(CHECK)
        pins = T / "pins.txt"
        shutil.copy(SCRIPTS.parent.parent / "requirements-pinned.txt", pins)
        old = {"faster-whisper": "1.2.1", "modal": "1.5.5", "ctranslate2": "4.8.2", "numpy": "2.5.3"}
        new = {"faster-whisper": "1.3.0", "modal": "1.6.0", "ctranslate2": "4.9.0"}
        state = T / "pip.json"

        def reset():
            json.dump({"now": dict(old), "new": new, "deps": ["ctranslate2"]}, open(state, "w"))
        reset()
        env = dict(os.environ, FAKE_PIP_STATE=str(state), ENGINE_PIP="%s %s" % (sys.executable, T / "pip.py"),
                   ENGINE_SELFCHECK="%s %s" % (sys.executable, T / "check.py"), ENGINE_PINS=str(pins),
                   ENGINE_NO_GIT="1", MAKE_SHORT_ENGINE_STATE=str(T / "engine.json"), SHORTS_DATA_DIR=str(T / "data"))
        os.environ.update({k: v for k, v in env.items() if k.startswith(("FAKE_", "ENGINE_", "MAKE_SHORT_ENGINE", "SHORTS_DATA"))})
        json.dump({"latest": {"faster-whisper": "1.3.0", "modal": "1.6.0"}, "checked_ts": time.time()},
                  open(T / "engine.json", "w"))
        sys.path.insert(0, str(SCRIPTS))
        import make_short_engine as ENG
        pins0 = pins.read_text()

        print("1. גרסה חדשה + הודעה שקטה")
        nw = ENG.newer(net=False)
        check(nw == {"faster-whisper": ("1.2.1", "1.3.0"), "modal": ("1.5.5", "1.6.0")}, "מזהה גרסאות חדשות: %s" % nw)
        check(ENG.note_due(), "ההודעה מוצגת")
        ENG.dismiss()
        check(not ENG.note_due(), "אחרי סגור — לא מוצגת (חודש)")

        def up(**extra):
            return subprocess.run([sys.executable, str(SCRIPTS / "make_short_engine.py"), "upgrade"],
                                  env=dict(env, **extra), capture_output=True, text=True, timeout=120)
        print("2. החדשה נכשלת בבדיקה → חזרה")
        r = up()
        now = json.load(open(state))["now"]
        check(r.returncode == 1 and "↩" in r.stdout, "יציאה 1 עם 'הוחזר' (%d)" % r.returncode)
        check(now == old, "הגרסאות חזרו בדיוק: %s" % now)
        check(pins.read_text() == pins0, "הקובץ המוצמד לא השתנה")
        check(any((T / "data/engine_snapshots").iterdir()), "נשמר צילום של הגרסאות הקודמות")

        print("3. ההתקנה נכשלת → חזרה")
        reset()
        r = up(FAKE_PIP_FAIL="1")
        check(r.returncode != 0 and json.load(open(state))["now"] == old, "לא נשאר שום שינוי (%d)" % r.returncode)

        print("4. החדשה עוברת → נשארת ונרשמת")
        reset()
        r = up(FAKE_CHECK_OK="1")
        now = json.load(open(state))["now"]
        p = pins.read_text()
        check(r.returncode == 0 and now["faster-whisper"] == "1.3.0" and now["modal"] == "1.6.0", "הותקנו: %s" % now)
        check("faster-whisper==1.3.0" in p and "modal==1.6.0" in p and "ctranslate2==4.9.0" in p and "numpy==2.5.3" in p,
              "הקובץ המוצמד עודכן (כולל התלות), השאר נשאר")
        check(p.count("\n#") == pins0.count("\n#"), "ההערות בקובץ נשארו")

        print("5. בשרת")
        reset()
        json.dump({"latest": {"faster-whisper": "1.3.0", "modal": "1.6.0"}, "checked_ts": time.time()},
                  open(T / "engine.json", "w"))
        code = r'''
import json, os, sys, time
sys.path.insert(0, sys.argv[1])
os.execv = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("blocked"))
import make_short_app as A
A.kick_queue = lambda: None
out = []
job = {"id": "x1", "kind": "prepare", "title": "שיעור", "log": ["ModuleNotFoundError: No module named 'faster_whisper'"], "error": "asr.py נכשל"}
out.append([A.job_failed_alerts(job) == "engine" and A.JOB_ALERTS["engine"]["action"]["id"] == "engine_upgrade", "התראה עם הכפתור"])
job2 = {"id": "x2", "kind": "prepare", "title": "שיעור", "log": ["HTTP Error 403"], "error": ""}
A.JOB_ALERTS.clear()
out.append([A.job_failed_alerts(job2) != "engine", "שגיאה אחרת (403) — לא התראת מנוע"])
A.JOBS["r"] = {"id": "r", "kind": "finish", "running": True}
try:
    A.engine_upgrade_start(); out.append([False, "לא רץ כשיש עבודה"])
except ValueError:
    out.append([True, "לא רץ כשיש עבודה"])
A.JOBS["r"] = {"id": "r", "kind": "engine", "running": True}
try:
    A.start_job("prepare", ["true"], title="t"); out.append([False, "בזמן ההחלפה עבודה חדשה לא מתחילה"])
except ValueError:
    out.append([True, "בזמן ההחלפה עבודה חדשה לא מתחילה"])
r = A.engine_res(net=False)
out.append([r["level"] == "note" and r.get("dismiss") == "engine_dismiss", "ההודעה השקטה עם סגור"])
print("RESULT=" + json.dumps(out, ensure_ascii=False))
'''
        senv = dict(env, MAKE_SHORT_NO_EXPORT="1", MAKE_SHORT_SETTINGS=str(T / "settings.json"),
                    SHORTS_PROJECTS=str(T / "projects"), MAKE_SHORT_QUEUE=str(T / "queue.json"), GEMINI_API_KEY="",
                    MAKE_SHORT_PORT="1")
        r = subprocess.run([sys.executable, "-c", code, str(SCRIPTS)], env=senv, capture_output=True, text=True,
                           timeout=120, cwd=str(T))
        line = next((l for l in reversed(r.stdout.splitlines()) if l.startswith("RESULT=")), "")
        if not line:
            check(False, "בדיקת השרת רצה: " + (r.stdout + r.stderr)[-400:])
        for c, w in json.loads(line[7:]) if line else []:
            check(c, w)
    finally:
        shutil.rmtree(T, ignore_errors=True)
    print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d בדיקות" % len(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
