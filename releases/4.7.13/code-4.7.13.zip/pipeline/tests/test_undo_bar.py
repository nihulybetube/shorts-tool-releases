# -*- coding: utf-8 -*-
"""4.6.3 — פס "אופס…" בהגדרות: פג תוקף, אפשר להסתיר, ו"בטל" עדיין מחזיר. תיקיות זמניות בלבד."""
import json
import os
import re
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
T = Path(tempfile.mkdtemp(prefix="ys_undo_test_"))
os.environ.update({"HOME": str(T), "SHORTS_CONFIG_DIR": str(T / "c"), "SHORTS_DATA_DIR": str(T / "d"), "MAKE_SHORT_TEST_GUARD": "1"})
sys.path.insert(0, str(SCRIPTS))
import make_short_settings as S  # noqa: E402

FAILS = []


def chk(c, n):
    print(("  ✓ " if c else "  ✗ ") + n)
    if not c:
        FAILS.append(n)


key = next(k for k, v in S.DEFAULTS.items() if isinstance(v, bool) and k not in S.IDENTITY_KEYS + S.VIEW_KEYS)
S.update({key: not S.DEFAULTS[key]})
chk(S.load()[key] != S.DEFAULTS[key], "(הכנה) הערך שונה מברירת המחדל")
st = S.reset([key])
chk(st["undo"] and key in st["undo"]["values"], "אחרי איפוס יש רשומת בטל")
chk(S.state()["undo"] is not None, "טרי — הפס מוצג")
st = S.dismiss_undo()
chk(st["undo"] is None, "✕ הסתר: הפס נעלם")
chk(S.state()["values"][key] == S.DEFAULTS[key], "ההסתרה לא מחזירה ערך (ההגדרות נשארות כמו אחרי האיפוס)")
S.reset([key])
d = S._read()
d["undo"]["at"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(time.time() - 3 * 86400))
S._write(d)
chk(S.state()["undo"] is None and "undo" not in S._read(), "רשומה בת 3 ימים פגה ונמחקה מהקובץ (זה היה הפס הנצחי)")
d = S._read()
d["undo"] = {"values": {}, "all": True}
S._write(d)
chk(S.state()["undo"] is None, "רשומה בלי תאריך — לא נשארת לנצח")
S.reset([key])
S.undo()
chk(S.state()["undo"] is None, "בטל עדיין עובד ומנקה את הפס")
import make_short_publish as P  # noqa: E402
import make_short_proposals as PRP  # noqa: E402
chk(not P.screen_status()["visible"] and not PRP.owner_visible(), "בלי מפתח ובלי סימן: מסכי הבעלים מוסתרים")
P.set_owner_screens(True)
chk(P.screen_status()["visible"] and PRP.owner_visible(), "4.6.5: אחרי «הצג מסכי בעלים» שני המסכים גלויים (בלי מפתח חתימה)")
chk(oct(os.stat(P.OWNER_SCREENS).st_mode & 0o777) == "0o600", "הסימן בהרשאה 0600")
chk(not P.have_key(), "ההצגה לא יצרה מפתח")
P.set_owner_screens(False)
chk(not P.screen_status()["visible"], "אפשר גם להחזיר להסתרה")
app_s = (SCRIPTS / "make_short_app.py").read_text(encoding="utf-8")
chk('op == "owner_screens"' in app_s and "vaultScreens()" in (SCRIPTS / "make_short_page.html").read_text(encoding="utf-8"), "השרת והדף: כפתור 👑 הצג מסכי בעלים")
page = (SCRIPTS / "make_short_page.html").read_text(encoding="utf-8")
chk("undoDismiss()" in page and "✕ הסתר" in page and "/api/settings/undo_dismiss" in page, "הדף: כפתור ✕ הסתר")
chk("/api/settings/undo_dismiss" in (SCRIPTS / "make_short_app.py").read_text(encoding="utf-8"), "השרת: נקודת הקצה")
chk("it.dataset.drawn!==sig" in page and 'it.dataset.drawn="1"' not in page, "4.6.7: רשימת פריטי הכספת מצוירת מחדש כשמשהו נוצר אחרי הטעינה (היה אפור לנצח)")
print("\n%s — %d נכשלו" % ("✓ הכול עבר" if not FAILS else "✗ יש כישלונות", len(FAILS)))
sys.exit(1 if FAILS else 0)
