# -*- coding: utf-8 -*-
"""בדיקות להתראות החיות (22/10/2026, כרטיס 18):
- עבודה שנכשלה על עוגיות / yt-dlp / Modal מרימה מיד את ההתראה המתאימה, ופעולת התיקון מורידה אותה;
- 403 של Gemini שנרשם במונה המקומי (כמו ש-gemini_call רושם) מופיע מיד בסוף עבודת בחירה;
- 🚨 אף בדיקת מערכת / רענון לא שולח בקשה ל-generateContent (עולה מכסה) — נבדק בהחלפת urlopen.
הכול בתיקייה זמנית; מפתח מזויף בלבד; בלי רשת לגוגל. מריצים: shorts.sh py ../tests/test_live_alerts.py"""
import hashlib
import json
import os
import sys
import tempfile
import urllib.request
from pathlib import Path

T = Path(tempfile.mkdtemp(prefix="ys_alerts_"))
FAKE_KEY = "fake-test-key-not-real-0000000000"
os.environ.update(MAKE_SHORT_NO_EXPORT="1", SHORTS_PROJECTS=str(T / "projects"), SHORTS_CONFIG_DIR=str(T / "config"),
                  MAKE_SHORT_SETTINGS=str(T / "settings.json"), MAKE_SHORT_MODAL_DAY=str(T / "md.json"),
                  MAKE_SHORT_GEMINI_USAGE=str(T / "gemini_usage.json"), MAKE_SHORT_QUEUE=str(T / "q.json"),
                  GEMINI_API_KEY=FAKE_KEY)
(T / "projects").mkdir()
(T / "config").mkdir()

CALLS = []
_real = urllib.request.urlopen


def spy(req, *a, **k):
    url = req.full_url if hasattr(req, "full_url") else str(req)
    CALLS.append(url)
    if "generativelanguage" in url or "generateContent" in url:
        raise AssertionError("נשלחה בקשה ל-Gemini: " + url)
    return _real(req, *a, **k)


urllib.request.urlopen = spy
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import make_short_app as APP  # noqa: E402

fails = 0


def ok(cond, what):
    global fails
    print(("✓ " if cond else "✗ ") + what)
    fails += 0 if cond else 1


def view_ids():
    d = APP.health_view()["data"] or {}
    return {r["id"]: r for r in d.get("results", [])}


# בסיס: בדיקת מערכת מלאה (רשת אמיתית ל-pypi/rclone/Modal בסדר — רק לא Gemini)
APP.HEALTH_STATE["data"] = APP.HEALTH.run_all(drive_enabled=False, online=True)
ok("gemini" in view_ids(), "בדיקת Gemini נכללת בבדיקת המערכת")
ok(view_ids()["gemini"]["level"] == "ok", "מפתח בלי חסימה → Gemini תקין")

# 1. עבודה שנכשלה על עוגיות
j = {"id": "7", "kind": "prepare", "ok": False, "title": "שיעור בדיקה",
     "log": ["[youtube] abc: Downloading webpage", "ERROR: [youtube] abc: Sign in to confirm you're not a bot. Use --cookies"],
     "error": "ההורדה נכשלה"}
APP.job_end_alerts(j, wait=True)
r = view_ids().get("cookies", {})
ok(r.get("level") == "bad" and r.get("from_job") == "שיעור בדיקה", "Sign in to confirm → התראת עוגיות מהעבודה")
ok(r.get("action", {}).get("id") == "upload_cookies", "…עם כפתור העלה קובץ עוגיות")
APP.job_alert_clear("cookies")
ok(view_ids().get("cookies", {}).get("from_job") is None, "אחרי העלאת עוגיות תקינות — ההתראה מהעבודה יורדת")

# 2. yt-dlp ישן
APP.job_end_alerts({"id": "8", "kind": "prepare", "ok": False, "title": "x",
                    "log": ["ERROR: unable to download video data: HTTP Error 403: Forbidden"]}, wait=True)
r = view_ids().get("ytdlp", {})
ok(r.get("level") == "bad" and "משתנה לעיתים קרובות" in r.get("detail", ""), "HTTP 403 בהורדה → התראת yt-dlp עם ההסבר")
APP.job_end_alerts({"id": "9", "kind": "prepare", "ok": True, "title": "x", "log": []}, wait=True)
ok(view_ids().get("ytdlp", {}).get("from_job") is None, "הורדה שהצליחה אחר כך — התראת yt-dlp מהעבודה יורדת")

# 3. Modal
APP.job_end_alerts({"id": "10", "kind": "prepare", "ok": False, "title": "x",
                    "log": ["❌ Modal לא זמין (AuthError) — לא עבר לתמלול במחשב בלי לשאול"]}, wait=True)
ok(view_ids().get("modal", {}).get("from_job") == "x", "Modal נפל → התראת Modal")
APP.job_end_alerts({"id": "11", "kind": "prepare", "ok": False, "title": "x",
                    "log": ["❌ עובר את תקרת Modal היומית — היום כבר: $1.00 · הפעולה: ~$0.10 · התקרה: $1.00"]}, wait=True)
ok(APP.JOB_ALERTS.get("modal", {}).get("job") == "10", "תקרת היום אינה תקלה — לא מרימה התראה")

# 4. Gemini 403 באמצע בחירה: gemini_call רושם key_block לקובץ המונה — בסוף העבודה זה מופיע מיד
fp = hashlib.sha256(FAKE_KEY.encode()).hexdigest()[:12]
u = APP.PICK._usage_read()
u["key_block"] = {"fp": fp, "at": "2026-10-22 20:00", "msg": "Your project has been denied access"}
Path(os.environ["MAKE_SHORT_GEMINI_USAGE"]).write_text(json.dumps(u), encoding="utf-8")
APP.job_end_alerts({"id": "12", "kind": "pick", "ok": False, "title": "בחירה", "log": ["❌ Gemini חסם את המפתח"]}, wait=True)
r = view_ids().get("gemini", {})
ok(r.get("level") == "bad" and "403" in r.get("title", ""), "Gemini 403 → התראה מיד (מהמונה המקומי)")
ok(r.get("action", {}).get("id") == "gemini_settings", "…עם כפתור להגדרות Gemini")
# 429 יומי
u = APP.PICK._usage_read()
u["key_block"] = None
m = APP.SET.load()["gemini_model"]
u["models"][m] = {"used": 20, "limit": 20, "blocked_until": APP.PICK.next_reset(), "block_msg": "המכסה היומית של %s נגמרה (לפי Google)" % m}
Path(os.environ["MAKE_SHORT_GEMINI_USAGE"]).write_text(json.dumps(u), encoding="utf-8")
APP.recheck(["gemini"], wait=True)
ok("המכסה היומית" in view_ids()["gemini"]["title"], "429 יומי → \"המכסה היומית נגמרה — מתאפסת ב-...\"")

# 5. 🚨 שום בדיקה לא שלחה generateContent
APP.HEALTH.run_all(drive_enabled=False, online=True)
APP.recheck(["gemini", "cookies", "ytdlp", "disk"], wait=True)
APP.gemini_health()
APP.PICK.gemini_status()
ok(not [c for c in CALLS if "generativelanguage" in c or "generateContent" in c],
   "אף בקשה ל-Gemini בכל הבדיקות (%d בקשות רשת אחרות: %s)" % (len(CALLS), ", ".join(sorted({c.split('/')[2] for c in CALLS if '://' in c}))))

print("\n%s" % ("הכול עבר ✓" if not fails else "%d נכשלו" % fails))
import shutil  # noqa: E402
shutil.rmtree(T, ignore_errors=True)
sys.exit(1 if fails else 0)
