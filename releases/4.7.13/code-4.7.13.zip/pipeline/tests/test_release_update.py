# -*- coding: utf-8 -*-
"""בדיקות 4.3 — עדכונים חתומים: חתימה, זיופים, סדר, שחזור מהפסקה, כישלון באמצע, פרסום וביטול. בלי רשת (שרת מרוחק מזויף מקומי).

הרצה:  python3 test_release_update.py   — תיקיות זמניות בלבד; לא נוגע בהגדרות האמיתיות."""
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
REPO = HERE.parent.parent
T = Path(tempfile.mkdtemp(prefix="ys_rel_"))
os.environ.update({"SHORTS_CONFIG_DIR": str(T / "cfg"), "SHORTS_DATA_DIR": str(T / "data"), "HOME": str(T / "home"),
                   "MAKE_SHORT_TEST_GUARD": "1", "MAKE_SHORT_PUBLISH_SELFTEST": "[]"})
sys.path.insert(0, str(SCRIPTS))
import make_short_release as R  # noqa: E402
import make_short_publish as P  # noqa: E402

OUT = []
OWN_USER = "ita" + "i"
OWN_GH = "nihuly" + "betube"


def chk(c, w, d=""):
    OUT.append((bool(c), w, d))
    print(("✓ " if c else "✗ ") + w + ("" if c else "  — " + str(d)[:300]), flush=True)


def sh(cwd, *a):
    r = subprocess.run(list(a), cwd=str(cwd), capture_output=True, text=True, errors="replace")
    if r.returncode:
        raise RuntimeError("%s: %s" % (a, r.stderr[-300:]))
    return r.stdout.strip()


def commit(repo, msg, tag=None):
    sh(repo, "git", "add", "-A")
    sh(repo, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", msg)
    if tag:
        sh(repo, "git", "tag", tag)


def make_owner(path, bad=False, last="1.3.0"):
    """ריפו "בעלים" מזויף: 1.0.0 → 1.1.0 → 1.2.0 → 1.3.0 (או 1.0.0, 1.1.0, ואז גרסה שבורה)."""
    path.mkdir(parents=True)
    sh(path, "git", "init", "-q", "-b", "main")
    (path / "pipeline" / "scripts").mkdir(parents=True)
    (path / "assets").mkdir()
    (path / "docs").mkdir()

    def w(rel, txt, mode=None):
        f = path / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(txt, encoding="utf-8")
        if mode:
            os.chmod(f, mode)
    w("VERSION", "1.0.0\n")
    w("pipeline/scripts/a.py", "VALUE = 1\n")
    w("pipeline/scripts/old.py", "OLD = True\n")
    w("run.sh", "#!/bin/sh\necho hi\n", 0o755)
    w("assets/release_source.json", '{"base": "", "pubkey": ""}\n')
    w("docs/HANDOFF.md", "# doc\n## 10. people\nsecret-ish\n## 11. tools\nok\n")
    w("CHANGELOG.md", "# changes\n")
    commit(path, "1.0.0", "v1.0.0")
    steps = [("1.1.0", "VALUE = 2\n"), ("1.2.0", "VALUE = 3\n"), ("1.3.0", "VALUE = 4\n")]
    if bad:
        steps = [("1.1.0", "VALUE = 2\n"), ("1.2.0", "def broken(:\n")]
    for v, body in steps:
        w("VERSION", v + "\n")
        w("pipeline/scripts/a.py", body)
        if v == "1.2.0" and not bad:
            (path / "pipeline/scripts/old.py").unlink()
            w("pipeline/scripts/new.py", "NEW = 1\n")
        if v == "1.1.0":
            w("docs/extra.md", "extra\n")
        commit(path, v, "v" + v)
        if v == "1.1.0":
            pass
    return path


def checkout(owner, tagv):
    sh(owner, "git", "checkout", "-q", "v" + tagv)


def make_remote(path):
    path.mkdir(parents=True)
    sh(path, "git", "init", "-q", "-b", "main")
    sh(path, "git", "config", "receive.denyCurrentBranch", "updateInstead")
    (path / "README").write_text("public releases\n")
    commit(path, "init")
    return path


def make_install(owner, path, tagv="1.0.0"):
    sh(T, "git", "clone", "-q", str(owner), str(path))
    sh(path, "git", "checkout", "-q", "v" + tagv)
    sh(path, "git", "checkout", "-q", "-B", "main")
    sh(path, "git", "remote", "remove", "origin")
    (path / ".from_package").write_text(tagv)
    with open(path / ".git" / "info" / "exclude", "a") as f:
        f.write(".from_package\n")
    return path


def publish(pub, notes=("שיפור קטן",), must=False, baseline="1.0.0", pw="correct horse battery", cancel_at=None):
    pub.start(pw, list(notes), must, baseline)
    seen = set()
    t0 = time.time()
    while time.time() - t0 < 120:
        st = pub.state()
        w = st["waiting"]
        if w and w["kind"] not in seen:
            seen.add(w["kind"])
            if cancel_at == w["kind"]:
                pub.cancel()
            else:
                pub.answer(True)
        if not st["running"]:
            return pub.state()
        time.sleep(0.05)
    return pub.state()


def tree_hashes(repo, files=None):
    out = {}
    for p in sh(repo, "git", "ls-files").splitlines():
        out[p] = hashlib.sha256((repo / p).read_bytes()).hexdigest()
    return out


# ═════════ 1. Ed25519: האימות בפייתון טהור מול cryptography ═════════
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402
from cryptography.hazmat.primitives import serialization as S  # noqa: E402
ok_all, bad_forged = True, True
for i in range(12):
    k = Ed25519PrivateKey.generate()
    pub = k.public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)
    msg = os.urandom(i * 7)
    sig = k.sign(msg)
    ok_all &= R.ed25519_verify(pub, msg, sig)
    bad_forged &= not R.ed25519_verify(pub, msg + b"x", sig) and not R.ed25519_verify(pub, msg, sig[:-1] + bytes([sig[-1] ^ 1]))
    bad_forged &= not R.ed25519_verify(pub, msg, sig[:63]) and not R.ed25519_verify(pub[:31], msg, sig)
    k2 = Ed25519PrivateKey.generate().public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)
    bad_forged &= not R.ed25519_verify(k2, msg, sig)
chk(ok_all, "אימות Ed25519 בפייתון טהור מקבל חתימות של cryptography (12 מקרים)")
chk(bad_forged, "אימות Ed25519 דוחה הודעה אחרת / חתימה שונה / קצרה / מפתח אחר")
chk(not R.ed25519_verify(b"\x00" * 32, b"x", b"\x00" * 64) and not R.ed25519_verify(b"\xff" * 32, b"x", b"\xff" * 64), "מפתח/חתימה בזבל — נדחים בלי קריסה")

# ═════════ 2. מפתח מוצפן ═════════
chk(not P.have_key(), "בהתחלה אין מפתח")
try:
    P.keygen("short")
    chk(False, "סיסמה קצרה נדחית")
except R.UpdateError:
    chk(True, "סיסמה קצרה נדחית")
PW = "correct horse battery"
pubk = P.keygen(PW)
raw_key = P.KEY_FILE.read_text(encoding="utf-8")
kd = json.loads(raw_key)
chk(P.have_key() and "seed" not in kd and "private" not in kd and kd.get("kdf") == "scrypt", "קובץ המפתח מוצפן (אין גרעין גלוי)")
chk(oct(P.KEY_FILE.stat().st_mode & 0o777) == "0o600", "הרשאות 600 על קובץ המפתח")
try:
    P.load_key("wrong passphrase!!")
    chk(False, "סיסמה שגויה נדחית")
except R.UpdateError:
    chk(True, "סיסמה שגויה נדחית")
key = P.load_key(PW)
chk(P.sign(key, b"abc") and R.ed25519_verify(base64.b64decode(pubk), b"abc", base64.b64decode(P.sign(key, b"abc"))), "חתימה עם הסיסמה הנכונה מאומתת")
try:
    P.keygen(PW)
    chk(False, "לא יוצרים מפתח שני")
except R.UpdateError:
    chk(True, "לא יוצרים מפתח שני")

# ═════════ 3. פרסום לשרת מרוחק מזויף ═════════
owner = make_owner(T / "owner")
remote = make_remote(T / "remote")
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = pubk
P.save_cfg({"remote": str(remote)})
pub = P.Publisher(repo=owner)


def pub_state(repo):
    pub.repo = Path(repo)
    return pub


# 3a. בדיקות מקדימות
checkout(owner, "1.1.0")
(owner / "dirty.txt").write_text("x")
(owner / "VERSION").write_text("1.1.0\n")
(owner / "pipeline/scripts/a.py").write_text("VALUE = 99\n")
st = publish(pub)
chk(st["error"] and "לא נשמרו" in st["error"] and not (remote / "releases").exists(), "עץ מלוכלך — לא מפרסמים", st["error"])
sh(owner, "git", "checkout", "-q", "--", ".")
(owner / "dirty.txt").unlink()
st = publish(pub, pw="wrong passphrase!!")
chk("סיסמה שגויה" in st["error"] and not (remote / "releases").exists(), "סיסמה שגויה — לא מפרסמים", st["error"])
st = publish(pub, notes=("",))
chk("מה חדש" in st["error"], "בלי טקסט מה חדש — לא מפרסמים", st["error"])
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = base64.b64encode(Ed25519PrivateKey.generate().public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)).decode()
st = publish(pub)
chk("המפתח הציבורי" in st["error"], "המפתח הציבורי לא בקוד — לא מפרסמים", st["error"])
os.environ["MAKE_SHORT_RELEASE_PUBKEY"] = pubk
sh(owner, "git", "tag", "-d", "v1.1.0")
st = publish(pub)
chk("תגית" in st["error"], "בלי תגית גרסה — לא מפרסמים", st["error"])
sh(owner, "git", "tag", "v1.1.0")

# 3b. פרסום מוצלח של 1.1.0, 1.2.0 (must_not_skip), 1.3.0
st = publish(pub, notes=("שורה ראשונה", "שורה שנייה"))
chk(st["done"] and not st["error"], "פרסום ראשון הצליח", st["error"] + str(st["log"][-3:]))
idx = json.loads((remote / "latest.json").read_text())
chk(idx["latest"] == "1.1.0" and [r["version"] for r in idx["releases"]] == ["1.1.0"], "latest.json מציג את 1.1.0")
rd = remote / "releases" / "1.1.0"
chk({p.name for p in rd.iterdir()} == {"manifest.json", "manifest.sig", "code-1.1.0.zip"}, "בריפו רק ארכיון + מניפסט + חתימה")
m11 = json.loads((rd / "manifest.json").read_text())
chk(m11["previous"] == "1.0.0" and m11["archive"]["sha256"] == hashlib.sha256((rd / "code-1.1.0.zip").read_bytes()).hexdigest()
    and "CHANGELOG.md" not in m11["files"] and "VERSION" in m11["files"], "המניפסט: previous, sha256, בלי CHANGELOG")
import zipfile  # noqa: E402
with zipfile.ZipFile(rd / "code-1.1.0.zip") as z:
    handoff = z.read("docs/HANDOFF.md").decode()
chk("secret-ish" not in handoff, "HANDOFF בארכיון בלי §10 (אותה אריזה כמו חבילת השיתוף)")
st = publish(pub)           # שוב 1.1.0 — לא חדש
chk("אינה חדשה" in st["error"], "גרסה שכבר פורסמה — נדחית", st["error"])
checkout(owner, "1.2.0")
st = publish(pub, notes=("גרסה שדורשת עצירה",), must=True)
chk(st["done"], "פרסום 1.2.0 (must_not_skip)", st["error"])
checkout(owner, "1.3.0")
st = publish(pub, notes=("עוד שיפור",))
chk(st["done"], "פרסום 1.3.0", st["error"])
idx = json.loads((remote / "latest.json").read_text())
chk([r["version"] for r in idx["releases"]] == ["1.1.0", "1.2.0", "1.3.0"] and idx["releases"][1]["must_not_skip"], "latest.json: שלוש גרסאות לפי סדר + must_not_skip")
m13 = json.loads((remote / "releases/1.3.0/manifest.json").read_text())
chk(m13["previous"] == "1.2.0", "השרשרת: previous של 1.3.0 הוא 1.2.0")

# ═════════ 4. המקבל: בדיקה, סדר, חסימה, שמירת 3 ═════════
inst = make_install(owner, T / "install")
c = R.check(installed="1.0.0")
chk(c["available"] and c["version"] == "1.1.0" and c["latest"] == "1.3.0" and c["steps"] == ["1.1.0", "1.2.0", "1.3.0"]
    and c["notes"] == ["שורה ראשונה", "שורה שנייה"], "בדיקה: הגרסה הבאה היא 1.1.0 (לא קופצים ל-1.3.0), עם מה חדש", str(c)[:200])
chk(not R.check(installed="1.3.0")["available"], "מי שמעודכן — אין עדכון")
chk(R.update_mode(inst) == "receiver" and R.update_mode(owner) in ("receiver", "owner"), "זיהוי מקבל")
sh(owner, "git", "remote", "add", "origin", "git@example.invalid:x/y.git")
chk(R.update_mode(owner) == "owner", "עץ של הבעלים (origin בלי .from_package) — 'owner', לא מתעדכן מהאינטרנט")
sh(owner, "git", "remote", "remove", "origin")
outside = T / "outside_settings.json"
outside.write_text('{"keep": true}')
pre_hashes = tree_hashes(inst)
res = R.run_updates(repo=inst, log=lambda s: None)
chk([d["version"] for d in res["applied"]] == ["1.1.0", "1.2.0"] and res["needs_restart_to_continue"] and not res["error"],
    "הוחלו לפי הסדר 1.1.0 ואז 1.2.0 ונעצרו בגלל must_not_skip", str(res)[:200])
chk(R.installed_version(inst) == "1.2.0", "המותקן עכשיו 1.2.0")
res = R.run_updates(repo=inst, log=lambda s: None)
chk([d["version"] for d in res["applied"]] == ["1.3.0"] and not res["error"], "ההרצה הבאה מחילה את 1.3.0")
checkout(owner, "1.3.0")
exp = {p: h for p, h in tree_hashes(owner).items() if p not in ("CHANGELOG.md",)}
got = {p: h for p, h in tree_hashes(inst).items()}
chk(set(got) == set(exp) and all(got[p] == exp[p] for p in got if p != "docs/HANDOFF.md"),
    "אחרי העדכונים עץ הקוד = גרסת הבעלים (קבצים נמחקו/נוספו נכון)", [p for p in got if p not in exp][:3] + [p for p in exp if p not in got][:3])
chk(not (inst / "pipeline/scripts/old.py").exists() and (inst / "pipeline/scripts/new.py").exists(), "קובץ שהוסר בגרסה — נמחק; קובץ חדש — נוסף")
chk(R.rel_tags(inst) == ["rel-1.1.0", "rel-1.2.0", "rel-1.3.0"], "נשארו 3 גרסאות אחרונות (תגיות)", R.rel_tags(inst))
chk(outside.read_text() == '{"keep": true}' and (inst / ".from_package").exists(), "הגדרות/קבצים מחוץ לקוד לא נגעו")
chk(not (R.STATE_DIR / "pending.json").exists(), "אין יומן תלוי אחרי הצלחה")
chk(not R.check(installed=R.installed_version(inst))["available"], "אחרי הכול — אין עוד עדכון")

# חזרה ידנית
rb = R.rollback_previous(repo=inst)
chk(rb["version"] == "1.2.0" and R.installed_version(inst) == "1.2.0" and (inst / "pipeline/scripts/a.py").read_text() == "VALUE = 3\n",
    "↩ חזרה לגרסה הקודמת (1.2.0)", str(rb))
chk("1.3.0" in R.load_state().get("skip", []), "הגרסה שחזרנו ממנה לא מוצעת שוב אוטומטית")
c = R.check(installed="1.2.0", skip=R.load_state().get("skip", []))
chk(not c["available"], "אחרי חזרה — בדיקה אוטומטית לא מציעה שוב את אותה גרסה")

# ═════════ 5. זיופים ═════════
base, keys = R.source()
ents = R.fetch_index(base)
e11 = ents[0]
raw = (remote / "releases/1.1.0/manifest.json").read_bytes()
sig = (remote / "releases/1.1.0/manifest.sig").read_text()


def rejects(fn, w):
    try:
        fn()
        chk(False, w)
    except R.UpdateError as ex:
        chk(True, w, str(ex)[:80])


rejects(lambda: R.verify_manifest(raw + b" ", sig, keys), "מניפסט ששונה בבית אחד — נדחה")
rejects(lambda: R.verify_manifest(raw, sig, [base64.b64encode(Ed25519PrivateKey.generate().public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)).decode()]),
        "חתימה ממפתח אחר — נדחית")
rejects(lambda: R.verify_manifest(raw, "AAAA", keys), "חתימה פגומה — נדחית")
rejects(lambda: R.verify_manifest(raw, sig, []), "בלי מפתח בקוד — נדחה")
rogue = Ed25519PrivateKey.generate()
fake_m = json.loads(raw)
fake_m["files"]["../evil.py"] = {"sha256": "0" * 64, "size": 1, "mode": 420}
fraw = json.dumps(fake_m).encode()
rejects(lambda: R.verify_manifest(fraw, base64.b64encode(key.sign(fraw)).decode(), keys), "נתיב '..' במניפסט חתום — נדחה")
fake_m = json.loads(raw)
fake_m["files"]["config.env"] = {"sha256": "0" * 64, "size": 1, "mode": 420}
fraw = json.dumps(fake_m).encode()
rejects(lambda: R.verify_manifest(fraw, base64.b64encode(key.sign(fraw)).decode(), keys), "קובץ בשם של סוד (config.env) במניפסט — נדחה")
m = R.verify_manifest(raw, sig, keys)
data = (remote / "releases/1.1.0/code-1.1.0.zip").read_bytes()
rejects(lambda: R.unpack_verified(data[:-5] + b"xxxxx", m, T / "stg"), "ארכיון ששונה — נדחה")
# ארכיון עם קובץ ששונה אבל מניפסט ישן
zf = T / "forged.zip"
with zipfile.ZipFile(zf, "w") as zo, zipfile.ZipFile(remote / "releases/1.1.0/code-1.1.0.zip") as zi:
    for i in zi.infolist():
        zo.writestr(i, zi.read(i) if i.filename != "pipeline/scripts/a.py" else b"EVIL = 1\n")
fm = dict(m, archive={"name": "x", "size": zf.stat().st_size, "sha256": hashlib.sha256(zf.read_bytes()).hexdigest()})
rejects(lambda: R.unpack_verified(zf.read_bytes(), fm, T / "stg"), "קובץ בארכיון לא תואם לחתימה — נדחה (גם אם סכום הארכיון הותאם)")
rejects(lambda: R.check_chain(m, "1.1.0"), "אותה גרסה — לא מתקינים (לא לאחור)")
rejects(lambda: R.check_chain(m, "1.5.0"), "גרסה ישנה מהמותקן — נדחית (אין חזרה אחורה)")
m2 = dict(m, min_required="1.1.0")
rejects(lambda: R.check_chain(m2, "1.0.0"), "גרסה שדורשת מינימום — לא מדלגים")
# latest.json מזויף: מצביע לתיקייה של גרסה אחרת
rejects(lambda: R.fetch_release(base, {"version": "1.2.0", "path": "releases/1.1.0"}, keys), "רשימה שמצביעה למניפסט של גרסה אחרת — נדחית")
# בלי חתימה בכלל
shutil.move(str(remote / "releases/1.1.0/manifest.sig"), str(T / "sig.bak"))
rejects(lambda: R.fetch_release(base, e11, keys), "בלי קובץ חתימה — נדחה")
shutil.move(str(T / "sig.bak"), str(remote / "releases/1.1.0/manifest.sig"))
# שרת לא זמין
rejects(lambda: R.fetch("file:///nonexistent-dir-xyz", "latest.json", 100), "שרת לא זמין — שגיאה נעימה (לא קריסה)")
os.environ["MAKE_SHORT_RELEASES_BASE"] = "http://insecure.example/x"
rejects(lambda: R.fetch("http://insecure.example/x", "latest.json", 100), "כתובת בלי https — נדחית")
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)

# ═════════ 6. שינויים מקומיים אצל המקבל נשמרים כ-patch ═════════
inst2 = make_install(owner, T / "install2")
(inst2 / "pipeline/scripts/a.py").write_text("VALUE = 'my change'\n")
(inst2 / "pipeline/scripts/mine.py").write_text("MINE = 1\n")       # קובץ לא מנוהל — לא נדרס
res = R.run_updates(repo=inst2, log=lambda s: None, stage_root=T / "stg2")
chk(res["applied"] and res["local_patch"] and Path(res["local_patch"]).exists() and "my change" in Path(res["local_patch"]).read_text(),
    "שינוי מקומי נשמר כקובץ patch לפני הדריסה", str(res)[:200])
chk((inst2 / "pipeline/scripts/a.py").read_text() == "VALUE = 3\n" and (inst2 / "pipeline/scripts/mine.py").exists(),
    "הקוד הרשמי הוחל; קובץ לא מנוהל שלו נשאר", [(inst2 / "pipeline/scripts/a.py").read_text(), (inst2 / "pipeline/scripts/mine.py").exists(),
                                                str(res.get("personal"))[:300]])

# ═════════ 6ב. התקדמות אמיתית + ביטול בנקודות בטוחות (4.3.1) ═════════
got = []
data_b = R.fetch(base, "releases/1.1.0/code-1.1.0.zip", R.MAX_ARCHIVE, progress=lambda d, t: got.append((d, t)))
chk(len(got) >= 2 and got[0][0] == 0 and got[-1][0] == len(data_b) and all(a[0] <= b[0] for a, b in zip(got, got[1:])) and got[-1][1] == len(data_b),
    "הורדה: דיווח בתים מונוטוני עם סה\"כ", got[-2:])
inst_p = make_install(owner, T / "prog1")
ev = []
res = R.run_updates(repo=inst_p, log=lambda s: None, stage_root=T / "stg_p1", progress=ev.append)
stages = [e["stage"] for e in ev]
firsts = [s for i, s in enumerate(stages) if i == 0 or stages[i - 1] != s]
chk(firsts[:1] == ["checking"] and "downloading" in firsts and firsts.index("downloading") < firsts.index("verifying") < firsts.index("applying"),
    "סדר השלבים: בדיקה ← הורדה ← אימות ← התקנה", firsts)
chk(any(e.get("step") == 2 and e.get("steps", 0) >= 2 for e in ev) and any(e["stage"] == "downloading" and e.get("pct") == 100 for e in ev),
    "'גרסה 2 מתוך 3' והורדה עד 100%")
ap = [e["pct"] for e in ev if e["stage"] == "applying" and e.get("step") == 1]
chk(ap == sorted(ap) and ap and ap[-1] >= 90 and all(e["cancellable"] for e in ev if e["stage"] in ("downloading", "verifying"))
    and not any(e["cancellable"] for e in ev if e["stage"] == "applying"), "התקנה: אחוזים עולים; ביטול אפשרי רק בהורדה ובאימות", ap)
# ביטול באימות → שום דבר לא שונה
inst_c = make_install(owner, T / "prog2")
head_c = sh(inst_c, "git", "rev-parse", "HEAD")
flag = {"c": False}
res = R.run_updates(repo=inst_c, log=lambda s: None, stage_root=T / "stg_p2", cancel=lambda: flag["c"],
                    progress=lambda e: flag.update(c=True) if e["stage"] == "verifying" else None)
chk(res["error"].startswith("העדכון בוטל") and not res["applied"] and sh(inst_c, "git", "rev-parse", "HEAD") == head_c
    and R.installed_version(inst_c) == "1.0.0" and not (R.STATE_DIR / "pending.json").exists(), "ביטול באימות: לא שונה כלום", str(res)[:150])
# ביטול באמצע הורדה
inst_d = make_install(owner, T / "prog3")
cnt = {"n": 0}
res = R.run_updates(repo=inst_d, log=lambda s: None, stage_root=T / "stg_p3", cancel=lambda: cnt["n"] >= 2,
                    progress=lambda e: cnt.update(n=cnt["n"] + (e["stage"] == "downloading")))
chk(res["error"].startswith("העדכון בוטל") and R.installed_version(inst_d) == "1.0.0", "ביטול באמצע הורדה: לא שונה כלום")
# בקשת ביטול שמגיעה בזמן ההחלפה — לא עוצרת אותה
inst_e = make_install(owner, T / "prog4")
flag2 = {"c": False}
res = R.run_updates(repo=inst_e, log=lambda s: None, stage_root=T / "stg_p4", cancel=lambda: flag2["c"],
                    progress=lambda e: flag2.update(c=True) if e["stage"] == "applying" and e.get("step") == 1 else None)
chk(res["applied"] and R.installed_version(inst_e) in ("1.1.0", "1.2.0") and (not res["error"] or res["error"].startswith("העדכון בוטל")),
    "ביטול בזמן ההחלפה לא קוטע אותה (הגרסה שהתחילה מסתיימת)", str(res)[:150])

# ═════════ 7. הפסקת חשמל באמצע ═════════
for point in ("before_rename", "mid_rename", "before_commit", "after_commit"):
    inst3 = make_install(owner, T / ("crash_" + point))
    base_head = sh(inst3, "git", "rev-parse", "HEAD")
    before = tree_hashes(inst3)
    os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = point
    try:
        R.run_updates(repo=inst3, log=lambda s: None, stage_root=T / ("stg_" + point))
        chk(False, "הקריסה המדומה (%s) קרתה" % point)
    except R.SimulatedCrash:
        pass
    os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
    chk((R.STATE_DIR / "pending.json").exists() and (R.STATE_DIR / "pending.sha").exists(), "אחרי הפסקה (%s) נשאר יומן" % point)
    msg = R.recover(repo=inst3)
    chk(msg and sh(inst3, "git", "rev-parse", "HEAD") == base_head and tree_hashes(inst3) == before and R.installed_version(inst3) == "1.0.0"
        and not (R.STATE_DIR / "pending.json").exists() and "rel-1.1.0" not in R.rel_tags(inst3),
        "התאוששות אחרי הפסקה (%s): חזרה מלאה לגרסה התקינה" % point, msg)
    left = [p for p in inst3.rglob(".*.ysnew")]
    chk(not left and not (inst3 / "docs/extra.md").exists(), "אחרי התאוששות אין קבצי ביניים וקבצים חדשים (%s)" % point)
    res = R.run_updates(repo=inst3, log=lambda s: None, stage_root=T / ("stg_" + point))
    chk(res["applied"] and not res["error"], "אחרי התאוששות העדכון מצליח (%s)" % point)
    shutil.rmtree(inst3, ignore_errors=True)

# שחזור מה-bash (shorts.sh) — הקטע בין הסימונים
shs = (REPO / "shorts.sh").read_text(encoding="utf-8")
b, e = shs.find("# <UPDATE-RECOVER-BEGIN>"), shs.find("# <UPDATE-RECOVER-END>")
chk(b > 0 and e > b, "ב-shorts.sh יש קטע שחזור מהפסקה")
if b > 0 and e > b:
    inst4 = make_install(owner, T / "bashrec")
    head = sh(inst4, "git", "rev-parse", "HEAD")
    os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "before_commit"
    try:
        R.run_updates(repo=inst4, log=lambda s: None, stage_root=T / "stg_b")
    except R.SimulatedCrash:
        pass
    os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
    snippet = shs[b:e]
    sp = R.STATE_DIR / "pending.sha"
    lines = sp.read_text().split("\n")
    sp.write_text("\n".join(lines[:2]) + "\n" + str(os.getpid()) + "\n")        # התהליך חי (הבדיקה עצמה) → לא נוגעים
    script0 = 'SKILL_HOME="%s"; DATA_DIR="%s"\n%s\n' % (inst4, T / "data", snippet)
    r0 = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script0], capture_output=True, text=True)
    chk(r0.returncode == 0 and R.installed_version(inst4) == "1.1.0" and (R.STATE_DIR / "pending.sha").exists(),
        "עדכון שרץ עכשיו בתהליך חי — השחזור של shorts.sh לא נוגע בו")
    sp.write_text("\n".join(lines[:2]) + "\n999999\n")                              # תהליך מת → משחזרים
    script = 'SKILL_HOME="%s"; DATA_DIR="%s"\n%s\n' % (inst4, T / "data", snippet)
    r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script], capture_output=True, text=True)
    chk(r.returncode == 0 and sh(inst4, "git", "rev-parse", "HEAD") == head and R.installed_version(inst4) == "1.0.0"
        and sh(inst4, "git", "status", "--porcelain", "--untracked-files=no") == "", "השחזור של shorts.sh מחזיר את העץ לגרסה התקינה", r.stderr[-200:])
    # יומן של עץ אחר — לא נוגעים
    (R.STATE_DIR / "pending.sha").write_text(head + "\n/some/other/repo\n")
    r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script], capture_output=True, text=True)
    chk(r.returncode == 0, "יומן של עץ אחר — לא נוגעים ולא קורסים")
    R._clear_journal()

# עדכון שרץ עכשיו בתהליך אחר (שרת הבדיקה של הבדיקה העצמית) — ההתאוששות לא נוגעת בו (באג שנתפס בבדיקה מקצה לקצה)
inst7 = make_install(owner, T / "livepid")
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "before_commit"
try:
    R.run_updates(repo=inst7, log=lambda s: None, stage_root=T / "stg_l")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
jp = R.STATE_DIR / "pending.json"
jd = json.loads(jp.read_text())
jd["pid"] = os.getppid()
jd["ident"] = R.proc_ident(os.getppid())
jp.write_text(json.dumps(jd))
chk(R.recover(repo=inst7) == "" and jp.exists() and R.installed_version(inst7) == "1.1.0", "יומן של תהליך חי אחר — ההתאוששות מחכה ולא מחזירה אחורה")
jd["pid"] = 999999
jp.write_text(json.dumps(jd))
chk(R.recover(repo=inst7) and R.installed_version(inst7) == "1.0.0" and not jp.exists(), "יומן של תהליך שמת — מתאוששים")

# ═════════ 8. עדכון שני נכשל → חוזרים לראשון (לא להתקנה המקורית) ═════════
owner_b = make_owner(T / "owner_b", bad=True)
remote_b = make_remote(T / "remote_b")
P.save_cfg({"remote": str(remote_b)})
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote_b)
pub_b = P.Publisher(repo=owner_b)
checkout(owner_b, "1.1.0")
st = publish(pub_b, notes=("טוב",))
chk(st["done"], "פרסום 1.1.0 (טוב) לשרת השני", st["error"])
checkout(owner_b, "1.2.0")
st = publish(pub_b, notes=("שבור",))
chk(st["done"], "פרסום 1.2.0 (עם שגיאת תחביר) לשרת השני — הבדיקה העצמית של הפרסום כבויה בבדיקה", st["error"])
inst5 = make_install(owner_b, T / "install5")
res = R.run_updates(repo=inst5, log=lambda s: None, stage_root=T / "stg5")
chk([d["version"] for d in res["applied"]] == ["1.1.0"] and res["error"], "עדכון ראשון הצליח, שני נכשל בבדיקה העצמית", str(res)[:250])
chk(R.installed_version(inst5) == "1.1.0" and (inst5 / "pipeline/scripts/a.py").read_text() == "VALUE = 2\n",
    "חזרנו לגרסה התקינה האחרונה (1.1.0 — לא להתקנה המקורית 1.0.0)")
chk(sh(inst5, "git", "status", "--porcelain", "--untracked-files=no") == "" and "rel-1.2.0" not in R.rel_tags(inst5)
    and not (R.STATE_DIR / "pending.json").exists(), "העץ נקי, אין תגית של הגרסה השבורה, אין יומן")
res = R.run_updates(repo=inst5, log=lambda s: None, stage_root=T / "stg5")
chk(res["error"] and R.installed_version(inst5) == "1.1.0", "ניסיון חוזר באותה גרסה שבורה נכשל שוב ונשאר ב-1.1.0")

# check_fn נכשל → חזרה
inst6 = make_install(owner_b, T / "install6")
res = R.run_updates(repo=inst6, log=lambda s: None, stage_root=T / "stg6", check_fn=lambda: (False, "בדיקה מזויפת"))
chk(res["error"] and R.installed_version(inst6) == "1.0.0" and not res["applied"], "בדיקה עצמית של התוכנה נכשלה → חזרה לגרסה הקודמת", str(res)[:200])

# ═════════ 9. ביטול פרסום וניקוי ═════════
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)
P.save_cfg({"remote": str(remote)})
owner2 = make_owner(T / "owner2")
checkout(owner2, "1.3.0")
sh(owner2, "git", "tag", "v1.4.0-tmp")
(owner2 / "VERSION").write_text("1.4.0\n")
(owner2 / "pipeline/scripts/a.py").write_text("VALUE = 5\n")
commit(owner2, "1.4.0", "v1.4.0")
pubc = P.Publisher(repo=owner2)
sh_before = sh(remote, "git", "rev-parse", "HEAD")
st = publish(pubc, cancel_at="plan", notes=("x",))
chk("בוטל" in st["error"] and sh(remote, "git", "rev-parse", "HEAD") == sh_before, "ביטול באישור הראשון — שום דבר לא עלה")
st = publish(pubc, cancel_at="final", notes=("x",))
chk("בוטל" in st["error"], "ביטול לפני ההפעלה הסופית", st["error"])
chk(not (remote / "releases/1.4.0").exists() and json.loads((remote / "latest.json").read_text())["latest"] == "1.3.0",
    "ביטול: מה שהועלה הוסר, latest.json לא השתנה")
chk(P.cleanup_pending() is None, "אחרי ביטול אין סימון ניקוי")
log = sh(remote, "git", "log", "--oneline")
chk("הפעלת גרסה 1.4.0" not in log, "ביטול: לא הופעלה הגרסה")
# קריסה: סימון ניקוי שורד
wd = P.WORK / hashlib.sha256(str(remote).encode()).hexdigest()[:12]
(wd / "releases/1.4.0").mkdir(parents=True, exist_ok=True)
(wd / "releases/1.4.0/x.txt").write_text("half")
sh(wd, "git", "add", "-A")
sh(wd, "git", "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "half")
sh(wd, "git", "push", "-q", "origin", "HEAD:main")
mk = {"work": str(wd), "remote": str(remote), "version": "1.4.0", "commit": sh(wd, "git", "rev-parse", "HEAD"), "at": 1}
P.WORK.mkdir(parents=True, exist_ok=True)
P._marker().write_text(json.dumps(mk))
chk(P.cleanup_pending() and (remote / "releases/1.4.0/x.txt").exists(), "העלאה שנקטעה נראית כממתינה לניקוי")
P.undo_upload(P.cleanup_pending())
chk(not (remote / "releases/1.4.0").exists() and P.cleanup_pending() is None, "ניקוי אחרי קריסה מסיר את מה שהועלה")
# אחרי ההפעלה אי אפשר לבטל
st = publish(pubc, notes=("בסדר",))
chk(st["done"] and json.loads((remote / "latest.json").read_text())["latest"] == "1.4.0", "פרסום מלא של 1.4.0 אחרי ניקוי")
chk(not st["can_cancel"] and not pubc.cancel(), "אחרי ההפעלה אי אפשר לבטל")
# 4.3.1: התקדמות הפרסום נשמרת בדיסק (שורדת רענון חלון) ויש בה שלבים ואחוזים
sv = P.saved_state()
chk(sv and sv["done"] and sv["pct"] == 100 and sv["steps_total"] >= 8 and sv["step_no"] >= 8, "מצב הפרסום נשמר בדיסק עם מספר שלבים", str(sv)[:150])
seen_detail = []
pubd = P.Publisher(repo=owner2)
sh(owner2, "git", "checkout", "-q", "-B", "tmp2", "v1.4.0")
(owner2 / "VERSION").write_text("1.5.0\n")
(owner2 / "pipeline/scripts/a.py").write_text("VALUE = 6\n")
commit(owner2, "1.5.0", "v1.5.0")
pubd.start(PW, ["תיקון"], False, None)
t0 = time.time()
while time.time() - t0 < 120:
    s = pubd.state()
    if s["detail"]:
        seen_detail.append((s["step"], s["detail"]))
    if s["waiting"]:
        pubd.answer(True)
    if not s["running"]:
        break
    time.sleep(0.01)
chk(pubd.state()["done"] and any("%" in d for _, d in seen_detail),
    "בפרסום: טקסט התקדמות עם אחוזים בהורדה חזרה/העלאה", seen_detail[:4])
(P.WORK / "publish_state.json").write_text(json.dumps({"running": True, "pct": 40, "label": "x", "log": []}))
ss = P.saved_state()
chk(ss["running"] is False and "נקטע" in ss["error"], "מצב 'רץ' ישן בדיסק (התוכנה נסגרה) מוצג כנקטע")

# 4.3.1: שמות השורטס ב"שיעורים קודמים" — השם של השורט עצמו
import types  # noqa: E402
import make_short_clean as CL  # noqa: E402
fake = types.ModuleType("make_short")
fake.read_edit_raw = lambda p: {"title": "  שם מקובץ העריכה  "}
sys.modules["make_short"] = fake
chk(CL.clip_title(T, {"title": "שם מהמצב", "edit": "e.txt"}) == "שם מהמצב", "כותרת שורט: מהמצב אם יש")
chk(CL.clip_title(T, {"title": "", "edit": "e.txt"}) == "שם מקובץ העריכה", "כותרת שורט: מקובץ העריכה כשהמצב ריק")
chk(CL.clip_title(T, {"title": "", "edit": ""}) == "" and CL.clip_title(T, {"name": "clip1"}) == "", "בלי כותרת בכלל → ריק (הדף מציג 'קליף N')")
fake.read_edit_raw = lambda p: (_ for _ in ()).throw(OSError("אין קובץ"))
chk(CL.clip_title(T, {"title": "", "edit": "e.txt"}) == "", "קובץ עריכה חסר — לא קורס")
del sys.modules["make_short"]

# ═════════ 10. סריקת זהות וסודות באריזת העדכון ═════════
owner3 = make_owner(T / "owner3")
checkout(owner3, "1.1.0")
for label, rel, body in (("שם משתמש", "pipeline/scripts/z.py", "# /home/%s/x\n" % OWN_USER),   # מנוטרל באריזה — לא חוסם
                         ("זהות GitHub בכתובת", "assets/release_source.json", '{"base": "https://raw.githubusercontent.com/%s/r/main", "pubkey": ""}\n' % OWN_GH),
                         ("מפתח API", "pipeline/scripts/k.py", 'K = "AIza' + "Sy" + "A" * 33 + '"\n')):
    sh(owner3, "git", "checkout", "-q", "-B", "tmp", "v1.1.0")
    (owner3 / rel).write_text(body)
    commit(owner3, "x")
    try:
        d = P.build_release(owner3, "1.1.0", "1.0.0", ["x"], False, "1.0.0", T / ("b_" + label.replace(" ", "_")), key, lambda s: None, pubk)
        if label == "שם משתמש":
            z = zipfile.ZipFile(d / "code-1.1.0.zip")
            chk(OWN_USER.encode() not in z.read("pipeline/scripts/z.py").lower(), "שם המשתמש בהערה מנוטרל באריזה")
        else:
            chk(False, "אריזה עם %s נחסמת" % label)
    except R.UpdateError as ex:
        chk(label != "שם משתמש", "אריזה עם %s נחסמת" % label, str(ex)[:90])
    sh(owner3, "git", "reset", "-q", "--hard", "v1.1.0")

# הגדרת הריפו הציבורי: כתובת עם זהות שלו נדחית; ניטרלית נכתבת לקוד יחד עם המפתח הציבורי
rejects(lambda: P.setup("git@example.invalid:%s/r.git" % OWN_GH, "https://raw.githubusercontent.com/%s/r/main" % OWN_GH, repo=owner3), "setup: כתובת עם זהות הבעלים נדחית")
rejects(lambda: P.setup("git@example.invalid:o/r.git", "http://insecure/x", repo=owner3), "setup: כתובת בלי https נדחית")
fpath = P.setup("git@example.invalid:neutral-org/releases.git", "https://raw.githubusercontent.com/neutral-org/releases/main", repo=owner3)
sj = json.loads(Path(fpath).read_text())
chk(sj["pubkey"] == pubk and sj["base"].endswith("/releases/main") and P.load_cfg()["remote"].endswith("releases.git"), "setup: הכתובת והמפתח הציבורי נכתבו לקוד, הריפו נשמר בהגדרות")

# 4.7.8: הבעלים החליט שהריפו הציבורי יושב בחשבון GitHub שלו — מותר שם החשבון בכתובת, ורק בכתובת, ורק אחרי אישור מפורש
GH_REMOTE, GH_BASE = "git@github.com:%s/shorts-tool-releases.git" % OWN_GH, "https://raw.githubusercontent.com/%s/shorts-tool-releases/main" % OWN_GH
rejects(lambda: P.setup(GH_REMOTE, GH_BASE, repo=owner3, save=False), "4.7.8: חשבון הבעלים בלי אישור מפורש — נדחה")
rejects(lambda: P.setup("git@github.com:%s/other.git" % OWN_GH, GH_BASE, repo=owner3, allow_account=True, save=False), "4.7.8: אישור חשבון לא מתיר כתובת SSH שלא מתאימה לכתובת ההורדה")
rejects(lambda: P.setup("git@github.com:%s/%s-x.git" % (OWN_GH, OWN_USER), "https://raw.githubusercontent.com/%s/%s-x/main" % (OWN_GH, OWN_USER), repo=owner3, allow_account=True, save=False),
        "4.7.8: שם הריפו עצמו חייב להיות ניטרלי גם עם אישור")
cfg_before = P.load_cfg()
fpath = P.setup(GH_REMOTE, GH_BASE, repo=owner3, allow_account=True, save=False)
sj = json.loads(Path(fpath).read_text())
chk(sj["base"] == GH_BASE and sj["pubkey"] == pubk and sj["account_approved"] is True and P.load_cfg() == cfg_before, "4.7.8: setup עם אישור כותב את הכתובת + דגל אישור, בלי לגעת בהגדרות המקומיות")
chk(P.derived_remote(GH_BASE) == GH_REMOTE and P.derived_remote("file:///x") == "", "4.7.8: כתובת ה-SSH נגזרת מכתובת ההורדה")
_old_cfg = P.CFG_FILE.read_bytes() if P.CFG_FILE.exists() else None
P.CFG_FILE.unlink(missing_ok=True)
os.environ.pop("MAKE_SHORT_RELEASES_BASE", None)
_old_repo = R.REPO
R.REPO = owner3
chk(P.effective_remote() == GH_REMOTE, "4.7.8: בלי הגדרה מקומית — הכתובת לפרסום נגזרת מהקוד")
R.REPO = _old_repo
if _old_cfg is not None:
    P.CFG_FILE.write_bytes(_old_cfg)
os.environ["MAKE_SHORT_RELEASES_BASE"] = "file://" + str(remote)
sh(owner3, "git", "checkout", "-q", "-B", "tmp", "v1.1.0")
(owner3 / "assets/release_source.json").write_text(json.dumps(sj, indent=1) + "\n")
commit(owner3, "addr")
try:
    d_ok = P.build_release(owner3, "1.1.0", "1.0.0", ["x"], False, "1.0.0", T / "b_account_ok", key, lambda s: None, pubk)
    chk(d_ok.exists(), "4.7.8: אריזה עם כתובת מאושרת (שם החשבון רק שם) עוברת את סריקת הזהות")
except R.UpdateError as ex:
    chk(False, "4.7.8: אריזה עם כתובת מאושרת עוברת את סריקת הזהות", str(ex)[:120])
(owner3 / "assets/release_source.json").write_text(json.dumps(dict(sj, note="by " + OWN_GH), indent=1) + "\n")
commit(owner3, "leak")
try:
    P.build_release(owner3, "1.1.0", "1.0.0", ["x"], False, "1.0.0", T / "b_account_leak", key, lambda s: None, pubk)
    chk(False, "4.7.8: שם החשבון בקובץ אחר — נחסם גם כשהכתובת מאושרת")
except R.UpdateError as ex:
    chk(True, "4.7.8: שם החשבון בקובץ אחר — נחסם גם כשהכתובת מאושרת", str(ex)[:90])
sh(owner3, "git", "reset", "-q", "--hard", "v1.1.0")

# ═════════ 11. אימות הכוונה: מניפסט ריק בלי מפתח, ופורמט עתידי ═════════
fm = json.loads(raw)
fm["format"] = 99
fraw = json.dumps(fm).encode()
rejects(lambda: R.verify_manifest(fraw, base64.b64encode(key.sign(fraw)).decode(), keys), "פורמט עתידי — נעצרים (צריך עדכון ביניים)")

# ═════════ 12. 4.5.x — תיקוני הסקירה (B1–B8) ═════════
# B1: גרסה שחזרו ממנה מדולגת רק כל עוד היא האחרונה; גרסה חדשה בנויה עליה → מוצעת שוב (בלי זה: נתקעים לתמיד, בשקט)
ents = R.fetch_index(R.source()[0])
vers = [e["version"] for e in ents]
chk(R.effective_skip(ents, [vers[-1]]) == ([vers[-1]], []), "B1: דילוג על הגרסה האחרונה נשמר")
c = R.check(installed="1.2.0", skip=["1.3.0"])
chk("1.4.0" in vers and c["available"] and c["version"] == "1.3.0" and c["skip"] == [] and "1.3.0" in c["skip_note"],
    "B1: יצאה גרסה חדשה מזו שדילגנו עליה — היא מוצעת שוב (לא שגיאת 'צריך קודם 1.3.0')", str(c)[:200])
inst_s = make_install(owner, T / "skipfix", "1.2.0")
st0 = R.load_state()
st0["skip"] = ["1.3.0"]
R.save_state(st0)
res = R.run_updates(repo=inst_s, log=lambda s: None)
chk(res["applied"] and res["applied"][0]["version"] == "1.3.0" and not res["error"] and R.load_state().get("skip") == []
    and "1.3.0" in R.load_state().get("skip_note", ""), "B1: run_updates עובר דרך הגרסה שדילגנו עליה וממשיך, עם הסבר", str(res)[:200])
shutil.rmtree(inst_s, ignore_errors=True)
st0 = R.load_state()
st0.pop("skip_note", None)
R.save_state(st0)

# B2: כיבוי בתוך שלב ה-git משאיר index.lock של git שמת → ההתאוששות מסירה אותו וחוזרת
inst_g = make_install(owner, T / "midgit")
head_g, before_g = sh(inst_g, "git", "rev-parse", "HEAD"), tree_hashes(inst_g)
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "mid_git"
try:
    R.run_updates(repo=inst_g, log=lambda s: None, stage_root=T / "stg_mg")
    chk(False, "B2: הקריסה המדומה בתוך git קרתה")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
(inst_g / ".git" / "index.lock").write_text("")                 # git שמת באמצע ה-commit
try:
    msg = R.recover(repo=inst_g)
except R.UpdateError as ex:
    msg = ""
    chk(False, "B2: התאוששות עם index.lock ישן", str(ex))
chk(msg and sh(inst_g, "git", "rev-parse", "HEAD") == head_g and tree_hashes(inst_g) == before_g
    and not (inst_g / ".git/index.lock").exists() and not (R.STATE_DIR / "pending.json").exists(),
    "B2: index.lock שנשאר מכיבוי נמחק וחוזרים לגרסה התקינה")
# אינדקס פגום לגמרי — בונים אותו מחדש מה-commit התקין
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "mid_git"
try:
    R.run_updates(repo=inst_g, log=lambda s: None, stage_root=T / "stg_mg2")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
(inst_g / ".git" / "index").write_bytes(b"not an index at all")
try:
    msg = R.recover(repo=inst_g)
except R.UpdateError as ex:
    msg = ""
chk(msg and sh(inst_g, "git", "rev-parse", "HEAD") == head_g and tree_hashes(inst_g) == before_g
    and sh(inst_g, "git", "status", "--porcelain", "--untracked-files=no") == "", "B2: אינדקס פגום — נבנה מחדש מה-commit התקין")
chk(R.unlock_stale(inst_g) is False, "B2: אין נעילה — לא נוגעים")
# כשל אמיתי לא נבלע: commit בסיס שלא קיים → UpdateError (האפליקציה מציגה בדף) והיומן נשאר
R._write_journal(inst_g, {"base": "0" * 40, "target": "9.9.9", "added": [], "from": "1.0.0"})
jd = json.loads((R.STATE_DIR / "pending.json").read_text())
jd["pid"], jd["ident"] = 999999, "x:1"
(R.STATE_DIR / "pending.json").write_text(json.dumps(jd))
rejects(lambda: R.recover(repo=inst_g), "B2: התאוששות שנכשלה מחזירה שגיאה ברורה (לא נבלעת)")
chk((R.STATE_DIR / "pending.json").exists(), "B2: אחרי כשל היומן נשאר (ינוסה שוב בהפעלה הבאה)")
R._clear_journal()
# bash: אותו דבר עם index.lock
shs = (REPO / "shorts.sh").read_text(encoding="utf-8")
snippet = shs[shs.find("# <UPDATE-RECOVER-BEGIN>"):shs.find("# <UPDATE-RECOVER-END>")]
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "mid_git"
try:
    R.run_updates(repo=inst_g, log=lambda s: None, stage_root=T / "stg_mg3")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
(inst_g / ".git" / "index.lock").write_text("")
_sp = R.STATE_DIR / "pending.sha"
_sp.write_text("\n".join(_sp.read_text().split("\n")[:2]) + "\n999999\n")       # הכותב מת (כיבוי)
script = 'SKILL_HOME="%s"; DATA_DIR="%s"\n%s\n' % (inst_g, T / "data", snippet)
r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script], capture_output=True, text=True)
chk(r.returncode == 0 and sh(inst_g, "git", "rev-parse", "HEAD") == head_g and not (inst_g / ".git/index.lock").exists()
    and not (R.STATE_DIR / "pending.sha").exists(), "B2: גם shorts.sh מסיר index.lock ישן וחוזר", r.stderr[-200:])
R.recover(repo=inst_g)

# B4: זהות תהליך = boot_id + זמן התחלה; מספר תהליך שחזר (תהליך אחר) לא נחשב "חי"
chk(R.proc_ident() and R.proc_ident() == R.proc_ident(os.getpid()) and R.proc_ident(999999) == "", "B4: זהות תהליך נקראת מ-/proc")
chk(R.owner_alive(os.getppid(), R.proc_ident(os.getppid())) and not R.owner_alive(os.getppid(), "other-boot:1"),
    "B4: אותו מספר תהליך עם זהות אחרת (הפעלה מחדש של המחשב) — לא חי")
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "before_commit"
try:
    R.run_updates(repo=inst_g, log=lambda s: None, stage_root=T / "stg_b4")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
sp = R.STATE_DIR / "pending.sha"
ls4 = sp.read_text().split("\n")
sp.write_text("\n".join(ls4[:2]) + "\n%d\nother-boot:1\n" % os.getppid())       # מספר חי, אבל זהות של תהליך מהאתחול הקודם
r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script], capture_output=True, text=True)
chk(r.returncode == 0 and sh(inst_g, "git", "rev-parse", "HEAD") == head_g, "B4: shorts.sh — מספר תהליך שחזר אחרי אתחול לא עוצר את השחזור", r.stderr[-200:])
R.recover(repo=inst_g)
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "before_commit"
try:
    R.run_updates(repo=inst_g, log=lambda s: None, stage_root=T / "stg_b4b")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
sp.write_text("\n".join(ls4[:2]) + "\n%d\n%s\n" % (os.getppid(), R.proc_ident(os.getppid())))
r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script], capture_output=True, text=True)
chk(r.returncode == 0 and sp.exists() and R.installed_version(inst_g) == "1.1.0", "B4: shorts.sh — התהליך הכותב באמת חי → לא נוגעים")
jd = json.loads((R.STATE_DIR / "pending.json").read_text())
jd["pid"], jd["ident"] = os.getppid(), "other-boot:1"
(R.STATE_DIR / "pending.json").write_text(json.dumps(jd))
chk(R.recover(repo=inst_g) and R.installed_version(inst_g) == "1.0.0", "B4: פייתון — מספר תהליך שחזר אחרי אתחול לא עוצר את השחזור")

# B3: כיבוי באמצע "חזור לגרסה הקודמת" → ההתאוששות לא מוחקת את התגית של הגרסה הטובה הקודמת
inst_r = make_install(owner, T / "rbcrash", "1.2.0")
R.save_state({})
R.run_updates(repo=inst_r, log=lambda s: None, stage_root=T / "stg_rb", max_steps=1)
cur = R.installed_version(inst_r)
prev_tag = [t for t in R.rel_tags(inst_r) if R.ver_tuple(t[4:]) < R.ver_tuple(cur)][-1]
os.environ["MAKE_SHORT_UPDATE_CRASH_AT"] = "mid_rollback"
try:
    R.rollback_previous(repo=inst_r)
    chk(False, "B3: הקריסה המדומה בחזרה קרתה")
except R.SimulatedCrash:
    pass
os.environ.pop("MAKE_SHORT_UPDATE_CRASH_AT")
chk(R.recover(repo=inst_r) and R.installed_version(inst_r) == cur and prev_tag in R.rel_tags(inst_r) and R.has_previous(inst_r),
    "B3: אחרי כיבוי באמצע חזרה — חוזרים לגרסה שהייתה, והגרסה הקודמת (%s) עדיין שמורה" % prev_tag, R.rel_tags(inst_r))
rb = R.rollback_previous(repo=inst_r)
chk(rb["version"] == prev_tag[4:], "B3: אפשר לחזור לגרסה הקודמת אחרי ההתאוששות")

# B6: כשל רגיל (לא קריסה) באמצע ההחלפה לא משאיר קבצי ‎.ysnew
inst_n = make_install(owner, T / "ysnew")
_orig_replace, _cnt = os.replace, {"n": 0}


def _bad_replace(a, b):
    if str(a).endswith(".ysnew"):
        _cnt["n"] += 1
        if _cnt["n"] == 2:
            raise OSError("הדיסק מלא (מדומה)")
    return _orig_replace(a, b)


os.replace = _bad_replace
try:
    res = R.run_updates(repo=inst_n, log=lambda s: None, stage_root=T / "stg_n")
finally:
    os.replace = _orig_replace
chk(res["error"] and not res["applied"] and R.installed_version(inst_n) == "1.0.0" and not list(inst_n.rglob(".*.ysnew"))
    and _cnt["n"] == 2, "B6: אחרי כשל באמצע ההחלפה אין קבצי ‎.ysnew שנשארו", [str(p) for p in inst_n.rglob(".*.ysnew")][:2])

# B7: גרסה חדשה שלא עולה — הפעם הראשונה אחרי כישלון: --skip-update; הפעם השנייה: חזרה לבד לפני העדכון
inst_t = make_install(owner, T / "trial")
base_t = sh(inst_t, "git", "rev-parse", "HEAD")
res = R.run_updates(repo=inst_t, log=lambda s: None, stage_root=T / "stg_t", max_steps=1)
vt = res["applied"][-1]["version"]
R.trial_begin([vt], res["applied"][0]["base"], repo=inst_t)
script_t = 'SKILL_HOME="%s"; DATA_DIR="%s"\nset -- py make_short_app.py\n%s\necho "ARGS=$*"\n' % (inst_t, T / "data", snippet)
r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script_t], capture_output=True, text=True)
chk(r.returncode == 0 and "--skip-update" in r.stdout and R.installed_version(inst_t) == vt
    and (R.STATE_DIR / "trial").read_text().split("\n")[3] == "1", "B7: הפעלה אחרי כישלון ראשון — עם --skip-update, בלי לגעת בקוד", r.stdout + r.stderr[-200:])
notes = R.startup_notes(skip_update=True)
chk(notes and "חזור לגרסה הקודמת" in notes[0][0], "B7: בדף מוצע '↩ חזור לגרסה הקודמת'")
r = subprocess.run(["bash", "-c", "set -euo pipefail\n" + script_t], capture_output=True, text=True)
chk(r.returncode == 0 and sh(inst_t, "git", "rev-parse", "HEAD") == base_t and R.installed_version(inst_t) == "1.0.0"
    and "rel-" + vt not in R.rel_tags(inst_t) and not (R.STATE_DIR / "trial").exists(), "B7: כישלון שני — חזרה לבד לגרסה שלפני העדכון", r.stderr[-200:])
notes = R.startup_notes()
chk(notes and vt in notes[0][0] and vt in R.load_state().get("skip", []), "B7: הודעה בדף + הגרסה שנכשלה לא מוצעת שוב עד שתצא חדשה ממנה")
R.trial_begin([vt], base_t, repo=inst_t)
R.trial_ok()
chk(not (R.STATE_DIR / "trial").exists(), "B7: ריצה תקינה מוחקת את הסימון")
R.save_state({})

# B8: מניפסט עם פריט שאינו מילון — UpdateError (לא קריסה)
for bad_files in ({"VERSION": "abc"}, ["VERSION"], {}):
    bm = json.loads(raw)
    bm["files"] = bad_files
    braw = json.dumps(bm).encode()
    try:
        R.verify_manifest(braw, base64.b64encode(key.sign(braw)).decode(), keys)
        chk(False, "B8: מניפסט עם files=%r נדחה" % (bad_files,))
    except R.UpdateError:
        chk(True, "B8: מניפסט עם files=%r נדחה בהודעה ברורה" % (type(bad_files).__name__ + str(len(bad_files))))
    except Exception as ex:
        chk(False, "B8: מניפסט עם files=%r נדחה" % (bad_files,), repr(ex))

# B8: וקטורי RFC 8032 + S לא קנוני + נקודות מסדר קטן
RFC = [("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60", "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a", "",
        "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"),
       ("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb", "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c", "72",
        "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00"),
       ("c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7", "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025", "af82",
        "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a")]
for i, (sk, pk, m, sg) in enumerate(RFC, 1):
    sk, pk, m, sg = (bytes.fromhex(x) for x in (sk, pk, m, sg))
    kk = Ed25519PrivateKey.from_private_bytes(sk)
    chk(kk.public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw) == pk and kk.sign(m) == sg and R.ed25519_verify(pk, m, sg),
        "B8: וקטור RFC 8032 מס' %d מאומת" % i)
    s_big = int.from_bytes(sg[32:], "little") + R._Q                 # S + L: אותה חתימה מתמטית, קידוד לא קנוני
    chk(s_big < 2 ** 256 and not R.ed25519_verify(pk, m, sg[:32] + s_big.to_bytes(32, "little")), "B8: S לא קנוני (S+L) נדחה (%d)" % i)
ident_pt = b"\x01" + b"\x00" * 31                                      # נקודת האפס (סדר 1)
ord2_pt = (R._P - 1).to_bytes(32, "little")                           # (0,-1) — סדר 2
for nm, pt in (("סדר 1", ident_pt), ("סדר 2", ord2_pt)):
    chk(not R.ed25519_verify(pt, b"any message", ident_pt + b"\x00" * 32) and not R.ed25519_verify(pt, b"other", ident_pt + b"\x00" * 32),
        "B8: מפתח ציבורי מנקודה מסדר קטן (%s) — חתימה 'אוניברסלית' נדחית" % nm)

# B8: מפתח הפרסום — scrypt 2^17, מפתח ישן (2^15) עדיין נפתח, וקובץ סודי נוצר 0600 מההתחלה
chk(json.loads(P.KEY_FILE.read_text())["n"] == 2 ** 17 == P.KDF_N, "B8: מפתח חדש נוצר עם scrypt 2^17")
from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: E402
old_salt, old_nonce = os.urandom(16), os.urandom(12)
old_ct = AESGCM(P._derive(PW, old_salt, 2 ** 15)).encrypt(old_nonce, key.private_bytes(S.Encoding.Raw, S.PrivateFormat.Raw, S.NoEncryption()),
                                                         b"yeshiva-shorts-release-key-v1")
real_kf = P.KEY_FILE
P.KEY_FILE = T / "old_key.enc"
P.KEY_FILE.write_text(json.dumps({"v": 1, "kdf": "scrypt", "n": 2 ** 15, "r": 8, "p": 1, "salt": base64.b64encode(old_salt).decode(),
                                  "nonce": base64.b64encode(old_nonce).decode(), "ct": base64.b64encode(old_ct).decode(), "pub": pubk}))
try:
    chk(P.sign(P.load_key(PW), b"q") == P.sign(key, b"q"), "B8: מפתח ישן (scrypt 2^15) עדיין נפתח")
    d_bad = json.loads(P.KEY_FILE.read_text())
    d_bad["n"] = 2 ** 30
    P.KEY_FILE.write_text(json.dumps(d_bad))
    rejects(lambda: P.load_key(PW), "B8: קובץ מפתח עם פרמטר זיכרון ענק — נדחה (לא נתקעים)")
finally:
    P.KEY_FILE = real_kf
_modes, _orig_fsync, _old_umask = [], os.fsync, os.umask(0)
os.fsync = lambda fd: (_modes.append(os.fstat(fd).st_mode & 0o777), _orig_fsync(fd))[1]
try:
    P._write_private(T / "secret.key", "x")
finally:
    os.fsync, _ = _orig_fsync, os.umask(_old_umask)
chk(_modes == [0o600] and (T / "secret.key").stat().st_mode & 0o777 == 0o600, "B8: קובץ סודי 0600 כבר בזמן הכתיבה (גם עם umask 0)", _modes)

# B8: ביטול העלאה כשה-commit שלנו כבר לא האחרון — מוציאים אותו ב-revert; כשל → הסימון נשאר
rem3 = make_remote(T / "remote3")
wk = T / "work3"
sh(T, "git", "clone", "-q", str(rem3), str(wk))
(wk / "ours.txt").write_text("ours\n")
commit(wk, "ours")
c_ours = sh(wk, "git", "rev-parse", "HEAD")
sh(wk, "git", "push", "-q", "origin", "HEAD:main")
(wk / "theirs.txt").write_text("theirs\n")
commit(wk, "theirs")
sh(wk, "git", "push", "-q", "origin", "HEAD:main")
P.WORK.mkdir(parents=True, exist_ok=True)
mk3 = {"work": str(wk), "remote": str(rem3), "version": "9.9.9", "commit": c_ours, "at": 1}
P._marker().write_text(json.dumps(mk3))
P.undo_upload(mk3)
chk(not (rem3 / "ours.txt").exists() and (rem3 / "theirs.txt").exists() and P.cleanup_pending() is None,
    "B8: ביטול העלאה כשמישהו העלה אחריה — מה שלנו הוצא, של האחר נשאר")
(wk / "ours.txt").write_text("ours again\n")
commit(wk, "ours2")
c2 = sh(wk, "git", "rev-parse", "HEAD")
sh(wk, "git", "push", "-q", "origin", "HEAD:main")
(wk / "ours.txt").write_text("changed by someone else\n")
commit(wk, "conflicting")
sh(wk, "git", "push", "-q", "origin", "HEAD:main")
mk4 = dict(mk3, commit=c2)
P._marker().write_text(json.dumps(mk4))
rejects(lambda: P.undo_upload(mk4), "B8: revert שנכשל (התנגשות) — שגיאה ברורה")
chk(P.cleanup_pending() is not None, "B8: ...והסימון 'ממתין לניקוי' לא נמחק בשקט")
sh(wk, "git", "revert", "--abort") if (wk / ".git/REVERT_HEAD").exists() else None
P._marker().unlink()

# B8: ריצה של הצינור שהתחילה מחוץ לתוכנה נחשבת "לא פנוי" לעדכון
sys.argv = ["make_short_app.py"]
import make_short_app as APP  # noqa: E402
fr = T / "fakeroot"
(fr / "pipeline/scripts").mkdir(parents=True)
(fr / "pipeline/scripts/run_long.py").write_text("import time\ntime.sleep(20)\n")
chk(not APP.external_pipeline_running(fr), "B8: בלי ריצה חיצונית — פנוי")
pr = subprocess.Popen([sys.executable, str(fr / "pipeline/scripts/run_long.py")])
try:
    time.sleep(0.3)
    chk(APP.external_pipeline_running(fr, me=999999) and not APP.external_pipeline_running(fr),
        "B8: ריצה של הצינור מחוץ לתוכנה — לא פנוי; עבודה של התוכנה עצמה — לא נספרת פעמיים")
finally:
    pr.kill()

fails = [w for c, w, d in OUT if not c]
print("RESULT=" + json.dumps({"total": len(OUT), "failed": fails}, ensure_ascii=False))
shutil.rmtree(T, ignore_errors=True)
sys.exit(1 if fails else 0)
