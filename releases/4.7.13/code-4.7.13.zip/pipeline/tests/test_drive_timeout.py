# -*- coding: utf-8 -*-
"""בדיקה: גיבוי לדרייב לא יכול להיתקע לנצח (סקירה חיצונית, 29/10/2026).

  1. rclone שנתקע באמצע ההעלאה → drive_backup.sh עוצר אותו אחרי המגבלה, יוצא 124 ("TIMEOUT"), והנעילה משתחררת.
  2. נעילה ישנה של גיבוי מת (שרת שהתחלף באמצע, או גרסה מלפני התיקון) → הגיבוי הבא עוצר אותו וממשיך.
  3. נעילה של גיבוי חי (בתוך המגבלה שלו) → 5 ("גיבוי אחר רץ"), לא נוגעים בו.
  4. make_short._kill_group הורג את כל הקבוצה (גם נכד), לא רק את bash.

HOME זמני עם rclone מזויף ב-~/.local/bin — לא נוגע בדרייב שלו, ביומנים או בנעילה שלו."""
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
sys.path.insert(0, str(HERE.parent / "scripts"))

FAKE = """#!/bin/bash
for a in "$@"; do [ "$a" = "--dry-run" ] && exit 0; done
[ "$1" = "sync" ] && [ -n "${FAKE_HANG:-}" ] && exec sleep 300
exit 0
"""


def main():
    T = Path(tempfile.mkdtemp(prefix="ys_drivetest_"))
    fails = []

    def check(cond, msg):
        print(("  ✓ " if cond else "  ✗ ") + msg, flush=True)
        if not cond:
            fails.append(msg)
    try:
        (T / ".local/bin").mkdir(parents=True)
        (T / ".local/bin/rclone").write_text(FAKE)
        os.chmod(T / ".local/bin/rclone", 0o755)
        src = T / "src"
        src.mkdir()
        (src / "a.mp4").write_bytes(b"x" * 1000)
        logs = T / ".local/share/yeshiva-shorts/logs"
        env = dict(os.environ, HOME=str(T), DRIVE_SRC=str(src), DRIVE_DST=str(T / "dst"))
        sh = ["bash", str(REPO / "drive_backup.sh")]

        print("1. rclone תקוע → נעצר אחרי המגבלה")
        t0 = time.time()
        r = subprocess.run(sh, env=dict(env, FAKE_HANG="1", DRIVE_LIMIT_SEC="3"), capture_output=True, text=True, timeout=120)
        dt = time.time() - t0
        check(r.returncode == 124 and "TIMEOUT" in r.stderr, "יצא 124 עם TIMEOUT (%s)" % r.stderr.strip()[-80:])
        check(dt < 30, "נעצר תוך %.0f ש' (מגבלה 3)" % dt)
        r = subprocess.run(sh, env=env, capture_output=True, text=True, timeout=60)
        check(r.returncode == 0, "הגיבוי הבא רץ — הנעילה שוחררה (%d %s)" % (r.returncode, r.stderr.strip()[-80:]))

        print("2. נעילה ישנה של גיבוי מת")
        lock = logs / "drive_backup_test.lock"
        holder = subprocess.Popen(["flock", str(lock), "sleep", "300"])
        time.sleep(0.5)
        (logs / "drive_backup_test.pid").write_text("%d %d 60\n" % (holder.pid, time.time() - 7200))
        r = subprocess.run(sh, env=env, capture_output=True, text=True, timeout=60)
        check(r.returncode == 0, "הגיבוי עצר את התקוע והמשיך (%d %s)" % (r.returncode, r.stderr.strip()[-80:]))
        check(holder.poll() is not None, "התהליך התקוע נעצר")
        holder.kill()

        print("3. גיבוי חי — לא נוגעים")
        holder = subprocess.Popen(["flock", str(lock), "sleep", "300"])
        time.sleep(0.5)
        (logs / "drive_backup_test.pid").write_text("%d %d 3600\n" % (holder.pid, time.time() - 60))
        r = subprocess.run(sh, env=env, capture_output=True, text=True, timeout=60)
        check(r.returncode == 5, "יצא 5 — גיבוי אחר רץ (%d)" % r.returncode)
        check(holder.poll() is None, "הגיבוי החי ממשיך")
        holder.kill()
        holder.wait()

        print("4. _kill_group")
        import make_short as MS
        p = subprocess.Popen(["bash", "-c", "sleep 300 & echo $!; wait"], stdout=subprocess.PIPE, text=True,
                             start_new_session=True)
        child = int(p.stdout.readline())
        MS._kill_group(p)
        time.sleep(0.5)
        check(p.poll() is not None and not Path("/proc/%d" % child).exists(), "bash וה-sleep שלו נעצרו יחד")
        check(MS.drive_limit({"DRIVE_SRC": str(src)}) == 3600, "המגבלה לתיקייה קטנה = שעה")
    finally:
        shutil.rmtree(T, ignore_errors=True)
    print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d בדיקות" % len(fails)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
