# -*- coding: utf-8 -*-
"""
test_chat_update.py — "עבודה עם צ'אט (Claude)" (27/10/2026): הבלוק לצ'אט וקריאת התשובה.

בודק בלי לשנות כלום בקוד (רק קריאה, ו-check שלא מחיל):
  • הבלוק: הקבצים הנכונים נבחרים לבקשות לדוגמה, הגודל בתוך התקציב, קובץ גדול → קטעים עם מספרי שורות + מפה
  • "צריך קבצים: …" מזוהה, ובלוק ההמשך מכיל בדיוק את מה שביקשו (קובץ / טווח / פונקציה)
  • שום סוד: מפתח שנשתל ביומן העבודה מוסתר, והערכים האמיתיים שלו לא בשום בלוק
  • התשובה של claude.ai בכל עיצוב: גדרות קוד, סימוני כיוון, ‎\\r\\n, ‎**הדגשה**, מספרי שורות שהועתקו, הזחה שזזה
הרצה:  shorts.sh py pipeline/tests/test_chat_update.py
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
import make_short_chat as CHAT  # noqa: E402
import make_short_update as UPD  # noqa: E402

FAIL = []


def ok(cond, what, detail=""):
    print(("  ✓ " if cond else "  ✗ ") + what + ("" if cond else " — " + str(detail)[:300]))
    if not cond:
        FAIL.append(what)


PAGE = "pipeline/scripts/make_short_page.html"
APP = "pipeline/scripts/make_short_app.py"


def picked(r):
    return [f["path"] for f in r["files"] if f["chars"]]


print("▶ הבלוק לצ'אט — בחירת קבצים ותקציב")
for mode, what, want in [
    ("change", "שהתור יציג כמה זמן נשאר לכל עבודה", [APP, PAGE]),
    ("change", "כשאני שומר שורט התיקייה נוצרת עם שם לא נכון", ["pipeline/scripts/shorts_layout.py", "pipeline/scripts/make_short.py"]),
    ("change", "להוסיף בהגדרות אפשרות לבחור את גודל הכתוביות", ["pipeline/scripts/make_short_settings.py", "pipeline/scripts/karaoke_ass.py"]),
    ("change", "אני רוצה שהכפתור של החלפת המוזיקה יהיה ירוק", [PAGE, "pipeline/scripts/make_short_music.py"]),
]:
    r = CHAT.block(mode, what, {}, budget=150000)
    got = picked(r)
    ok(all(w in got for w in want), "«%s» → %s" % (what, ", ".join(Path(w).name for w in want)), got)
    ok(r["chars"] <= 150000, "  בתוך התקציב (%d תווים)" % r["chars"])
r = CHAT.block("change", "אני רוצה שהכפתור יהיה ירוק", {}, budget=150000)
ok(not any("מתאים למילה «תור»" in f["reason"] for f in r["files"]), "«כפתור» לא נתפס כ«תור»", [f["reason"] for f in r["files"]])
pg = next((f for f in r["files"] if f["path"] == PAGE), None)
ok(pg and pg["how"].startswith("קטעים"), "הדף (300 אלף תווים) נכנס בקטעים בלבד", pg)
ok("[שורות " in r["text"] and "מפת הקובץ" in r["text"], "קטעים עם מספרי שורות + מפת הקובץ")
ok("צריך קבצים:" in r["text"] and "=== החלפה:" in r["text"], "ההוראות: 'צריך קבצים' ופורמט החלפה")
small = CHAT.block("change", "שהתור יציג כמה זמן נשאר", {}, budget=40000)
ok(small["chars"] <= 40000, "תקציב קטן (40 אלף) — נשמר (%d)" % small["chars"])
t = CHAT.block("change", "שינוי קטן", {}, ticks=["make_short_progress.py"], budget=150000)
ok("pipeline/scripts/make_short_progress.py" in picked(t), "קובץ שסימן ברשימה נכנס")
u = CHAT.block("change", "שהתור יציג כמה זמן נשאר", {}, unticks=[APP], budget=150000)
ok(APP not in picked(u), "קובץ שהוריד מהרשימה לא נכנס")

print("\n▶ באג: traceback וסוג העבודה")
FAKE = "AIza" + "SyA1234567890" + "abcdefghijklmnopqrstuvw"     # מפתח מזויף, מורכב בזמן ריצה — שסורק החבילה לא יראה "מפתח" בקובץ
ctx = {"job": {"kind": "finish", "title": "t", "started": "10:00", "error": "KeyError: 'music'",
               "log": ["Traceback (most recent call last):",
                       '  File "/home/x/.local/share/yeshiva-shorts/snapshots/ab12/pipeline/scripts/mix_music.py", line 40, in main',
                       "KeyError: 'music'", "token=" + FAKE]},
       "health": ["[ok] ffmpeg"], "selftest": "2026-10-27 · quick · עברה"}
b = CHAT.block("bug", "השורט נכשל בסוף בלי מוזיקה", ctx, budget=150000)
ok("pipeline/scripts/mix_music.py" in picked(b), "הקובץ מה-traceback נכנס (גם כשרץ מצילום קוד)")
ok("pipeline/scripts/make_short.py" in picked(b), "וגם הקובץ שמריץ את סוג העבודה (finish)")
ok(FAKE not in b["text"] and FAKE[:12] not in b["text"] and b["redacted"] >= 1, "מפתח שנשתל ביומן — הוסתר")
ok("בדיקת האיכות האחרונה" in b["text"] and "KeyError" in b["text"], "השגיאה ובדיקת האיכות בבלוק")

print("\n▶ שום סוד אמיתי בשום בלוק")
vals, _ = CHAT._known()
blocks = [r["text"], b["text"], small["text"], CHAT.followup(["make_short_share.py", "make_short_health.py#scrub"])["text"]]
ok(not any(v in x for v in vals for x in blocks), "הערכים האמיתיים (%d) לא מופיעים באף בלוק" % len(vals))

print("\n▶ 'צריך קבצים: …' ובלוק ההמשך")
for ans in ["צריך קבצים: pipeline/scripts/make_short_progress.py, make_short_app.py:100-130, make_short_page.html#queueHTML",
            "**צריך קבצים:** `make_short_progress.py`, `make_short_app.py:100-130`, make_short_page.html#queueHTML",
            "‏צריך קבצים: make_short_progress.py make_short_app.py:100-130 make_short_page.html#queueHTML\r\n"]:
    c = UPD.check(ans)
    ok(len(c["needs"]) == 3 and not c["errors"] and not c["ok"], "מזוהה: %r" % ans[:40], c)
f = CHAT.followup(c["needs"])
ok([x["path"] for x in f["files"]] == ["pipeline/scripts/make_short_progress.py", APP, PAGE], "בלוק ההמשך — שלושת הקבצים", f["files"])
ok("· מלא ·" in f["text"] and "[שורות 100–130]" in f["text"] and "function queueHTML" in f["text"], "קובץ מלא, טווח, ופונקציה לפי שם")
f2 = CHAT.followup(["no_such_file.py", "make_short_page.html"])
ok(f2["unknown"] == ["no_such_file.py"] and f2["chars"] <= CHAT.DEFAULT_BUDGET, "קובץ לא קיים נאמר; קובץ ענק — ראש + מפה בתוך התקציב")

print("\n▶ קריאת התשובה — כל עיצוב של claude.ai")
P = "pipeline/scripts/make_short_progress.py"
src = (CHAT.REPO / P).read_text(encoding="utf-8")
first = next(l for l in src.split("\n") if l.startswith("def "))
new = first + "  # שונה"
base = "תיאור: בדיקה\nהסבר בעברית.\n\n=== החלפה: %s ===\n<<<<<<< לפני\n%s\n=======\n%s\n>>>>>>> אחרי\n=== סוף החלפה ===\n" % (P, first, new)
variants = {
    "רגיל": base,
    "CRLF": base.replace("\n", "\r\n"),
    "בתוך גדר ```": "תיאור: בדיקה\n```\n" + base.split("\n", 1)[1] + "```\n",
    "סימני כיוון והדגשה": base.replace("=== החלפה", "‏**=== החלפה").replace("=== סוף החלפה ===", "=== סוף החלפה ===**‎")
                                .replace("<<<<<<< לפני", "‏<<<<<<< לפני"),
    "גדר בתוך הלפני/אחרי": base.replace("<<<<<<< לפני\n", "<<<<<<< לפני\n```python\n").replace("\n=======", "\n```\n=======")
                                 .replace("=======\n", "=======\n```python\n").replace("\n>>>>>>>", "\n```\n>>>>>>>"),
    "בלי שורת סוף": base.replace("=== סוף החלפה ===\n", ""),
    "אנגלית": base.replace("=== החלפה:", "=== EDIT:").replace("<<<<<<< לפני", "<<<<<<< SEARCH")
                  .replace(">>>>>>> אחרי", ">>>>>>> REPLACE").replace("=== סוף החלפה ===", "=== END EDIT ==="),
    "מספרי שורות שהועתקו": base.replace("<<<<<<< לפני\n" + first, "<<<<<<< לפני\n 12| " + first),
    "רווחים בסוף שורה": base.replace("<<<<<<< לפני\n" + first, "<<<<<<< לפני\n" + first + "   "),
}
for name, txt in variants.items():
    c = UPD.plan(txt)
    good = c["ok"] and P in c["contents"] and (new in c["contents"][P]) and c["contents"][P].count("\n") == src.count("\n")
    ok(good, "חפש והחלף — %s" % name, c["errors"])
    ok(c["desc"] == "בדיקה", "  התיאור נקרא", c["desc"])
c = UPD.plan(base.replace(first, first.replace("def ", "def zz_not_there_"), 1))
ok(not c["ok"] and c["misses"] and c["misses"][0]["line"] > 0, "«לפני» שלא קיים → שגיאה + השורה הכי דומה", c["errors"])
rt = CHAT.retry(check_result=UPD.check(base.replace(first, first.replace("def ", "def zz_not_there_"), 1)))
ok("הקוד האמיתי" in rt["text"] and first in rt["text"], "בלוק 'מה לא התאים' כולל את הקוד האמיתי סביב")
dup = next(l for l in src.split("\n") if l.strip() and src.split("\n").count(l) >= 2)
c = UPD.plan(base.replace("<<<<<<< לפני\n" + first, "<<<<<<< לפני\n" + dup))
ok(not c["ok"] and "מופיע" in " ".join(c["errors"]), "«לפני» שמופיע כמה פעמים — נדחה עם בקשה להוסיף שורות", c["errors"])
c = UPD.plan("=== קובץ: pipeline/scripts/zz_new.py ===\nprint(1)\n")
ok(not c["ok"] and "נקטעה" in " ".join(c["errors"]), "קובץ שלם בלי שורת סוף (תשובה שנקטעה) — נדחה עם הסבר", c["errors"])
c = UPD.plan("```diff\n‏--- a/%s\n+++ b/%s\n@@ -1,1 +1,1 @@\n-%s\n+%s\n```\n" % (P, P, src.split("\n")[0], src.split("\n")[0] + " "))
ok(c["ok"], "diff עם סימן כיוון בתחילת שורה — נקרא", c["errors"])
c = UPD.plan("=== החלפה: config.env ===\n<<<<<<< לפני\na\n=======\nb\n>>>>>>> אחרי\n=== סוף החלפה ===")
ok(not c["ok"], "החלפה בקובץ הגדרות — נדחית")
k = "pipeline/scripts/karaoke_ass.py"
ks = (CHAT.REPO / k).read_text(encoding="utf-8")
line = next(l for l in ks.split("\n") if "‫" in l)
plain = line.replace("‫", "").replace("‬", "")
c = UPD.plan("=== החלפה: %s ===\n<<<<<<< לפני\n%s\n=======\n%s\n# x\n>>>>>>> אחרי\n=== סוף החלפה ===" % (k, plain, plain))
ok(c["ok"] and line in c["contents"][k], "שורה עם סימני כיוון אמיתיים בקוד (karaoke) — נמצאת גם כשהצ'אט איבד אותם, ונשמרת כמו שהיא",
   c["errors"])

print("\n%s %s" % ("✅" if not FAIL else "❌", "הכול עבר" if not FAIL else "%d נכשלו: %s" % (len(FAIL), "; ".join(FAIL))))
sys.exit(1 if FAIL else 0)
