# -*- coding: utf-8 -*-
"""בדיקה: "🔠 הגדלת מילים" (כרטיס 15, 22/10/2026). בלי רשת, בלי וידאו (רק רינדור כתובית אחת למדידה).
  1. clean_picks קורא כל צורה שמודל מחזיר (מילון, מחרוזת, "...*מילה*...").
  2. resolve: התאמה מלאה; מילה שתוקנה ("מלחמה" → "מלחמות") נשארת במקומה ולא קופצת ל"במלחמה" שבמשפט הבא;
     ההקשר מכריע בין שני מופעים; מילה שנעלמה → lost.
  3. מתג כבוי (emph_idx=None) וקבוצה ריקה → קובץ ass זהה בייט-בייט; הגדלה מפורשת → לכל היותר 2 בכתובית.
הרצה: ~/.local/share/yeshiva-shorts/venv/bin/python3 pipeline/tests/test_emph.py   (דרך shorts.sh py — צריך FFMPEG)"""
import filecmp
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import karaoke_ass as KA  # noqa: E402
import make_short_emph as EM  # noqa: E402

fails = []


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg)
    if not cond:
        fails.append(msg)


print("1. clean_picks")
got = EM.clean_picks([{"word": "לשאוף", "quote": "צריך לשאוף להיות"}, "הוא נמצא *במלחמה* תמיד", "תמיד",
                      {"w": "  "}, 7])
check([p["w"] for p in got] == ["לשאוף", "במלחמה", "תמיד"], "שלוש צורות נקראו, ריקות/מספרים ירדו")
check(got[1]["q"] == "הוא נמצא במלחמה תמיד", "הכוכביות יורדות מהציטוט")

print("2. resolve")
text = "אבל יש לו מלחמה. הוא נמצא במלחמה תמיד, אבל הוא תמיד מנצח. אף פעם לא חוטא, אף פעם לא נכשל"
toks = [EM.norm(w) for w in text.split()]
pick = EM.make_pick(text.split(), 3)                     # "מלחמה." שסימן בעצמו
idx, lost = EM.resolve([pick], toks)
check(idx == [3], "מילה שסומנה נמצאת במקומה")
toks2 = [EM.norm(w) for w in text.replace("לו מלחמה.", "לו מלחמות.").split()]
idx, lost = EM.resolve([pick], toks2)
check(idx == [3], "אחרי תיקון ל'מלחמות' — נשארת במקום (לא קופצת ל'במלחמה')")
idx, _ = EM.resolve([{"w": "לא", "q": "פעם לא נכשל", "at": None}], toks)
check(idx == [text.split().index("נכשל") - 1], "ההקשר מכריע בין שני מופעים של 'לא'")
idx, lost = EM.resolve([{"w": "קיימת", "q": "לא קיימת", "at": None}], toks)
check(idx == [None] and len(lost) == 1, "מילה שלא בטקסט → lost")
idx, _ = EM.resolve([{"w": "תמיד", "q": "", "at": None}, {"w": "תמיד", "q": "", "at": None}], toks)
check(len(set(idx)) == 2, "שני picks לא נופלים על אותה מילה")

print("3. karaoke_ass")
with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    ws, t = [], 0.0
    for w in "כל אדם צריך לשאוף להיות בינוני. מה זה בינוני? זה אדם שאף פעם לא חוטא מרצון.".split():
        ws.append({"word": " " + w, "start": round(t, 2), "end": round(t + 0.32, 2)})
        t += 0.4
    wj = td / "w.json"
    json.dump({"words": ws}, open(wj, "w", encoding="utf-8"), ensure_ascii=False)
    KA.HIGHLIGHT_RGB["custom"] = "FFE600"
    KA.build(str(wj), str(td / "a.ass"), t + 1, "teal", color="custom")
    KA.build(str(wj), str(td / "b.ass"), t + 1, "teal", color="custom", emph_idx=set())
    check(filecmp.cmp(td / "a.ass", td / "b.ass", shallow=False), "מתג כבוי / בלי מילים — ass זהה בייט-בייט")
    KA.build(str(wj), str(td / "c.ass"), t + 1, "teal", color="custom", emph_idx={0, 1, 2, 3})
    big = open(td / "c.ass", encoding="utf-8-sig").read().count("\\fs159")
    check(0 < big <= 2 * 2, "ארבע מילים מבוקשות באותה כתובית → הוגדלו לכל היותר שתיים (%d אירועים)" % big)

print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו: %d" % len(fails)))
sys.exit(1 if fails else 0)
