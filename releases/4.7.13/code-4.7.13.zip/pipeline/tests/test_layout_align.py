# -*- coding: utf-8 -*-
"""בדיקה: "📐 פריסת שורות" ותזמון מילה שהוחלפה (כרטיס 12, 21/10/2026). בלי רשת, בלי וידאו.
  1. פריסה שנשמרה חלה בצריבה (כתובית ושורות כמו שנקבע).
  2. אחרי תיקון מילה בכתובית אחת — שאר הכתוביות נשארות כמו שקבע; רק זו חוזרת לחלוקה האוטומטית.
  3. align_clean_text: מילה שהוחלפה ("[א / ב]" שהוכרע לב', או "משהו אחר") מקבלת את הזמן של המילה שהחליפה.
הרצה: ~/.local/share/yeshiva-shorts/venv/bin/python3 pipeline/tests/test_layout_align.py"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import align_clean_text as ACT  # noqa: E402
import karaoke_ass as KA  # noqa: E402
import make_short_layout as LAY  # noqa: E402

fails = []


def check(cond, msg):
    print(("  ✓ " if cond else "  ✗ ") + msg)
    if not cond:
        fails.append(msg)


def words_of(text, gap_after=()):
    out, t = [], 0.0
    for k, w in enumerate(text.split()):
        out.append({"word": " " + w, "start": round(t, 2), "end": round(t + 0.3, 2)})
        t += 0.35 + (0.6 if k in gap_after else 0)
    return out


root = Path(tempfile.mkdtemp(prefix="ys_lay_"))
try:
    text = "אחת שתיים שלוש. ארבע חמש שש שבע, שמונה תשע עשר אחת-עשרה שתים-עשרה."
    W = words_of(text)
    auto = LAY.auto_chunks(W)
    print("1. פריסה שנשמרה")
    # כתובית 1 בשתי שורות, 2 ו-3 מחוברות לאחת
    mine = [[[0, 1], [2]], [[3, 4, 5, 6, 7, 8]], [[9, 10, 11]]]
    LAY.save(root, "clip1", W, mine)
    ch, has, lost = LAY.chunks_for(root, "clip1", W)
    check(has and ch == mine and lost == 0, "נטענה בדיוק כמו שנשמרה")
    wj = root / "w.json"
    json.dump({"words": W}, open(wj, "w", encoding="utf-8"), ensure_ascii=False)
    KA.build(str(wj), str(root / "a.ass"), 6.0, "teal", color="teal", rows_layout=ch)
    base = [l.split(",,", 1)[1].strip() for l in open(root / "a.ass", encoding="utf-8-sig") if l.startswith("Dialogue: 1")]
    check(len(base) == 3 and "\\N" in base[0] and "\\N" not in base[1], "בצריבה: 3 כתוביות, הראשונה בשתי שורות")
    KA.build(str(wj), str(root / "b.ass"), 6.0, "teal", color="teal")
    auto_n = sum(1 for l in open(root / "b.ass", encoding="utf-8-sig") if l.startswith("Dialogue: 1"))
    check(auto_n == len(auto), "בלי פריסה — החלוקה הרגילה (%d כתוביות)" % auto_n)

    print("2. תיקון מילה ויישור מחדש")
    W2 = words_of(text.replace("חמש", "חמישה"))
    ch2, _, lost2 = LAY.chunks_for(root, "clip1", W2)
    check(ch2[0] == mine[0] and ch2[-1] == mine[2], "הכתוביות שלא נגעו בהן נשמרו")
    check(lost2 == 1 and [i for r in ch2 for c in [r] for x in c for i in x] == list(range(len(W2))),
          "רק הכתובית עם המילה המתוקנת חזרה לאוטומטית, וכל המילים מכוסות")
    LAY.save(root, "clip1", W, None)
    check(LAY.load(root, "clip1") is None, "↺ חלוקה אוטומטית מוחקת את הפריסה")

    print("3. תזמון מילה שהוחלפה")
    asr = [{"word": " א", "start": 0.0, "end": 0.3}, {"word": " ב", "start": 0.4, "end": 0.7},
           {"word": " ג", "start": 2.0, "end": 2.4}, {"word": " ד", "start": 2.5, "end": 2.8}]
    al = ACT.align(asr, "א ב זזז ד")
    check(al[2]["start"] == 2.0 and al[2]["end"] == 2.4, "מילה אחת במקום מילה אחת — אותו זמן (%.2f–%.2f)" % (al[2]["start"], al[2]["end"]))
    al = ACT.align(asr, "א ב זזז ווו ד")
    check(al[2]["start"] == 2.0 and abs(al[3]["end"] - 2.4) < 1e-6, "שתי מילים במקום אחת — מתחלקות על הטווח שלה")
finally:
    shutil.rmtree(root, ignore_errors=True)
print("\n%s" % ("✅ הכול עבר" if not fails else "❌ נכשלו %d" % len(fails)))
sys.exit(1 if fails else 0)
