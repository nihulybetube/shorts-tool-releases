# -*- coding: utf-8 -*-
"""שרת ntfy מזויף לבדיקות (4.4): POST JSON לשורש / POST לנושא → שומר; GET /<t1,t2>/json?poll=1&since=… → NDJSON.
מדמה גם: גוף הודעה עד 4096 בתים (413), מגבלת קצב (429), ניתוק (drop), ושמירה מוגבלת בזמן (cache_secs). רק 127.0.0.1."""
import json
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Fake:
    def __init__(self, cache_secs=12 * 3600):
        self.msgs, self.lock, self.n, self.cache_secs = [], threading.Lock(), 0, cache_secs
        self.down, self.limit_after, self.log, self.fail_topics = False, None, [], set()
        self.redirect_to = None          # 4.5.x: GET עונה 302 לכתובת הזאת (בדיקת "לא הולכים אחרי הפניה")
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, body=b"", ctype="application/json"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                if outer.down:
                    return self._send(503, b'{"error":"down"}')
                data = self.rfile.read(int(self.headers.get("Content-Length") or 0))
                outer.log.append(("POST", self.path, len(data)))
                if outer.limit_after is not None and len(outer.msgs) >= outer.limit_after:
                    return self._send(429, b'{"code":42908}')
                try:
                    if self.path.strip("/") == "":
                        o = json.loads(data.decode("utf-8"))
                        topic, msg = o["topic"], o.get("message", "")
                        title, prio, tags = o.get("title"), o.get("priority", 3), o.get("tags", [])
                    else:
                        topic, msg, title, prio, tags = self.path.strip("/"), data.decode("utf-8"), None, 3, []
                except Exception:
                    return self._send(400, b'{"error":"bad"}')
                if len(msg.encode("utf-8")) > 4096:
                    return self._send(413, b'{"code":41303}')
                if topic in outer.fail_topics:
                    return self._send(500, b"{}")
                with outer.lock:
                    outer.n += 1
                    outer.msgs.append({"id": "m%06d" % outer.n, "time": int(time.time()), "event": "message", "topic": topic,
                                       "message": msg, "title": title, "priority": prio, "tags": tags})
                self._send(200, json.dumps({"id": "m%06d" % outer.n}).encode())

            def do_GET(self):
                if outer.down:
                    return self._send(503, b"{}")
                if outer.redirect_to:
                    outer.log.append(("REDIRECT", self.path, 0))
                    self.send_response(302)
                    self.send_header("Location", outer.redirect_to)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                u = urllib.parse.urlparse(self.path)
                parts = u.path.strip("/").split("/")
                if len(parts) != 2 or parts[1] != "json":
                    return self._send(404, b"{}")
                topics = set(parts[0].split(","))
                q = urllib.parse.parse_qs(u.query)
                since = (q.get("since") or ["all"])[0]
                now = time.time()
                with outer.lock:
                    ms = [m for m in outer.msgs if m["topic"] in topics and now - m["time"] <= outer.cache_secs]
                if since.isdigit():
                    ms = [m for m in ms if m["time"] >= int(since)]
                elif since != "all":                    # since=<id>: רק מה שאחרי ההודעה הזאת (id לא מוכר → הכול, כמו שפג תוקף)
                    ids = [m["id"] for m in ms]
                    if since in ids:
                        ms = ms[ids.index(since) + 1:]
                outer.log.append(("GET", self.path, len(ms)))
                self._send(200, ("\n".join(json.dumps(m) for m in ms) + "\n").encode(), "application/x-ndjson")

        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def on(self, topic):
        return [m for m in self.msgs if m["topic"] == topic]

    def stop(self):
        self.srv.shutdown()


if __name__ == "__main__":
    f = Fake()
    print(f.url, flush=True)
    time.sleep(3600)