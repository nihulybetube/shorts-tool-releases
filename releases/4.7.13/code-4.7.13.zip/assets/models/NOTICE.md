# YuNet — מודל זיהוי פנים

`face_detection_yunet_2023mar.onnx` (~230KB) מגיע מ-
[OpenCV Zoo](https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet),
פותח על ידי Shiqi Yu ואחרים, ומופץ תחת **רישיון MIT**.

הוא זה שממרכז את הדובר בקרופ ל-9:16. בלעדיו `build_clean` נופל למעקב
תנועה (`center_track.py`), שמודד מרכז-מסה של **הגוף** — ואצל דובר שמדבר
עם הידיים זה הידיים ולא הראש.

🚨 **הכשל הזה שקט**: אין שגיאה, רק קליפים שהדובר בהם בצד. `shorts.sh doctor`
בודק שהמודל קיים ונטען.
