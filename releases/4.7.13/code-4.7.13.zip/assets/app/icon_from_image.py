# -*- coding: utf-8 -*-
"""
icon_from_image.py — the app icon from his own picture (source.jpg), replacing the drawn one (21/10/2026).

He sent a 1408x768 image: the mark (film reel + play arrow + scissors, teal/orange) in the middle of an
off-white background. This crops the mark to a square, turns the background transparent (with a soft
edge, so small sizes don't get a halo) and writes icon.ico (16–256), icon-192.png, icon-512.png.

    shorts.sh py assets/app/icon_from_image.py [source.jpg]
"""
import struct
import sys
from pathlib import Path

import cv2            # opencv is already in the venv (face tracking); PIL is not
import numpy as np

HERE = Path(__file__).resolve().parent
src = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "source.jpg"
a = cv2.imread(str(src), cv2.IMREAD_COLOR).astype(float)        # BGR

# background = median of the border; "ink" = pixels clearly darker/more saturated than it
border = np.concatenate([a[:8].reshape(-1, 3), a[-8:].reshape(-1, 3), a[:, :8].reshape(-1, 3), a[:, -8:].reshape(-1, 3)])
bg = np.median(border, axis=0)
dist = np.sqrt(((a - bg) ** 2).sum(axis=2))
ys, xs = np.where(dist > 40)
x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
side = int(max(x1 - x0, y1 - y0) * 1.08)           # a little breathing room around the mark
box = (int(cx - side / 2), int(cy - side / 2), int(cx - side / 2) + side, int(cy - side / 2) + side)

H, W = a.shape[:2]
pad = np.full((side, side, 3), bg)                  # the square may reach past the picture's edge
sx0, sy0 = max(box[0], 0), max(box[1], 0)
sx1, sy1 = min(box[2], W), min(box[3], H)
pad[sy0 - box[1]:sy1 - box[1], sx0 - box[0]:sx1 - box[0]] = a[sy0:sy1, sx0:sx1]
d = np.sqrt(((pad - bg) ** 2).sum(axis=2))
alpha = np.clip((d - 18) / (60 - 18), 0, 1)        # soft ramp: 18 = background, 60 = full ink
mark = np.dstack([pad, alpha * 255]).astype(np.uint8)   # BGRA


def sized(s):
    # INTER_AREA = area averaging: small sizes stay smooth instead of jagged
    return cv2.resize(mark, (s, s), interpolation=cv2.INTER_AREA if s < side else cv2.INTER_CUBIC)


def png(img):
    return cv2.imencode(".png", img)[1].tobytes()


(HERE / "icon-512.png").write_bytes(png(sized(512)))
(HERE / "icon-192.png").write_bytes(png(sized(192)))

sizes = [16, 24, 32, 48, 64, 128, 256]
pngs = [(s, png(sized(s))) for s in sizes]
head = struct.pack("<HHH", 0, 1, len(pngs))
offset = 6 + 16 * len(pngs)
dirs, data = b"", b""
for s, p in pngs:
    dirs += struct.pack("<BBBBHHII", s % 256, s % 256, 0, 0, 1, 32, len(p), offset + len(data))
    data += p
(HERE / "icon.ico").write_bytes(head + dirs + data)
print("crop", box, "→ icon.ico, icon-192.png, icon-512.png")
