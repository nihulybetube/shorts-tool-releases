# -*- coding: utf-8 -*-
"""הסמל של התוכנה "יצירת שורטס" (21/10/2026): מסגרת וידאו אנכית לבנה עם כפתור ניגון טורקיז,
על ריבוע מעוגל כהה. לא הלוגו של הישיבה ולא סמל של מותג — משהו נקי שמזהים בשורת המשימות.

מצייר בלי ספריות גרפיקה (רק numpy): כל צורה היא מבחן "בפנים/בחוץ", מרנדרים בגודל 1024 ומקטינים
בממוצע אזורי — כך גם 16 פיקסלים יוצאים חלקים. מייצר: icon.ico (16–256), icon-192.png, icon-512.png.
שימוש: shorts.sh py ../../assets/app/make_icon.py   (או python3 עם numpy)"""
import struct
import zlib
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BG_TOP, BG_BOT = (0x22, 0x2B, 0x2E), (0x14, 0x1A, 0x1C)
WHITE = (0xFF, 0xFF, 0xFF)
TEAL = (0x1A, 0xC8, 0xA8)          # צבע הכתוביות המקורי שלו


def rrect(x, y, cx, cy, hw, hh, r):
    qx, qy = np.abs(x - cx) - (hw - r), np.abs(y - cy) - (hh - r)
    out = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0)
    return out <= r


def triangle(x, y, pts):
    (x1, y1), (x2, y2), (x3, y3) = pts
    d1 = (x - x2) * (y1 - y2) - (x1 - x2) * (y - y2)
    d2 = (x - x3) * (y2 - y3) - (x2 - x3) * (y - y3)
    d3 = (x - x1) * (y3 - y1) - (x3 - x1) * (y - y1)
    neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
    pos = (d1 > 0) | (d2 > 0) | (d3 > 0)
    return ~(neg & pos)


def master(n=1024):
    """RGBA float בגודל n, בקואורדינטות של 256."""
    s = 256.0 / n
    y, x = np.mgrid[0:n, 0:n].astype(np.float64)
    x, y = (x + 0.5) * s, (y + 0.5) * s
    img = np.zeros((n, n, 4))
    bg = rrect(x, y, 128, 128, 128, 128, 52)
    k = (y / 256.0)[..., None]
    img[..., :3] = np.array(BG_TOP) * (1 - k) + np.array(BG_BOT) * k
    img[..., 3] = bg
    # מסגרת הווידאו האנכית (9:16)
    frame = rrect(x, y, 128, 128, 62, 104, 24) & ~rrect(x, y, 128, 128, 46, 88, 12)
    img[frame, :3] = WHITE
    # כפתור ניגון
    play = triangle(x, y, [(108, 92), (108, 164), (166, 128)])
    img[play, :3] = TEAL
    return img


def shrink(img, size):
    f = img.shape[0] // size
    a = img[..., 3:4]
    rgb = (img[..., :3] * a).reshape(size, f, size, f, 3).mean((1, 3))
    al = a.reshape(size, f, size, f, 1).mean((1, 3))
    rgb = np.where(al > 0, rgb / np.maximum(al, 1e-9), 0)
    return np.clip(np.concatenate([rgb, al * 255], -1) + 0.5, 0, 255).astype(np.uint8)


def png(arr):
    h, w = arr.shape[:2]
    raw = b"".join(b"\x00" + arr[r].tobytes() for r in range(h))
    chunk = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def ico(pngs):
    """ICO עם PNG בכל גודל (נתמך מאז Vista)."""
    head = struct.pack("<HHH", 0, 1, len(pngs))
    off, dirs, data = 6 + 16 * len(pngs), b"", b""
    for size, p in pngs:
        b = size if size < 256 else 0
        dirs += struct.pack("<BBBBHHII", b, b, 0, 0, 1, 32, len(p), off + len(data))
        data += p
    return head + dirs + data


if __name__ == "__main__":
    m = master(1024)
    m512 = master(512)
    sizes = [16, 20, 24, 32, 40, 48, 64, 128, 256]
    pngs = [(s, png(shrink(m if 1024 % s == 0 else m512 if 512 % s == 0 else master(s * 8), s))) for s in sizes]
    (HERE / "icon.ico").write_bytes(ico(pngs))
    (HERE / "icon-192.png").write_bytes(png(shrink(master(192 * 4), 192)))
    (HERE / "icon-512.png").write_bytes(png(shrink(m, 512)))
    print("icon.ico, icon-192.png, icon-512.png →", HERE)
