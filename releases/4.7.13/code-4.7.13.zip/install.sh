#!/usr/bin/env bash
# install.sh — התקנה מקומית, בלי sudo ובלי לגעת במערכת.
#
# מה זה עושה:
#   1. יוצר סביבת פייתון פרטית ב-~/.local/share/yeshiva-shorts/venv
#   2. מתקין את הספריות שהפייפליין צריך
#   3. מוודא ffmpeg — משתמש בקיים, ואם אין מוריד בנייה סטטית לתיקייה פרטית
#   4. מחבר את הסקיל ל-~/.claude/skills כדי שקלוד ימצא אותו
#   5. מריץ את אשף ההגדרה הראשונה
#
# הכל נשאר תחת ה-home של המשתמש. אין apt, אין brew, אין הרשאות root.
set -euo pipefail

SKILL_HOME="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SKILL_HOME
DATA_DIR="${SHORTS_DATA_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/yeshiva-shorts}"
VENV="$DATA_DIR/venv"
PRIVBIN="$DATA_DIR/bin"
SKIP_SETUP=0
ASR_CHOICE=""

for arg in "$@"; do
  case "$arg" in
    --no-setup) SKIP_SETUP=1 ;;
    --asr=*)    ASR_CHOICE="${arg#*=}" ;;
    -h|--help)  sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
  esac
done

say()  { printf '\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '  \033[31m✗\033[0m %s\n' "$*" >&2; exit 1; }

mkdir -p "$DATA_DIR" "$PRIVBIN" "$DATA_DIR/projects" "$DATA_DIR/logs"
# 4.0.4: ב-WSL אין פותח-דפדפן — rclone / Modal רק הדפיסו קישור. מתקינים xdg-open שפותח בדפדפן של ווינדוס
if [ -x /mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe ]; then
  install -m 755 "$SKILL_HOME/setup/wsl_open.sh" "$PRIVBIN/xdg-open" && ok "פותח-דפדפן (לחיבור דרייב / Modal) הותקן"
fi

say "1/5  פייתון"
PYBIN=""
for c in python3.14 python3.13 python3.12 python3.11 python3.10 python3; do
  command -v "$c" >/dev/null 2>&1 || continue
  v="$("$c" -c 'import sys;print("%d%02d"%sys.version_info[:2])' 2>/dev/null || echo 0)"
  [ "$v" -ge 309 ] 2>/dev/null && { PYBIN="$c"; break; }
done
[ -n "$PYBIN" ] || die "צריך פייתון 3.9 ומעלה. התקן פייתון ונסה שוב."
ok "$($PYBIN -V)"

if [ ! -x "$VENV/bin/python" ]; then
  "$PYBIN" -m venv "$VENV" || die "יצירת סביבת הפייתון נכשלה (חסר python3-venv?)"
fi
"$VENV/bin/python" -m pip install --quiet --upgrade pip >/dev/null
ok "סביבה פרטית: $VENV"

say "2/5  ספריות"
# 29/10: הגרסאות הטובות של הספריות הקריטיות — במקום אחד, requirements-pinned.txt (מגבלות של pip:
# קובע גרסה לספרייה ולתלויות שלה, לא מתקין כלום בעצמו). פייתון אחר במחשב חדש שאין לו את הגרסה הזאת —
# מתקינים בלי הצמדה ומזהירים, כדי שההתקנה לא תיפול.
PINS="$SKILL_HOME/requirements-pinned.txt"
pinstall() {
  if [ -f "$PINS" ] && "$VENV/bin/pip" install --quiet -c "$PINS" "$@"; then return 0; fi
  [ -f "$PINS" ] && warn "הגרסאות המוצמדות לא מתאימות לפייתון כאן — מתקין את העדכניות"
  "$VENV/bin/pip" install --quiet "$@"
}
# yt-dlp מתעדכן תכופות (יוטיוב משנה את הנגן) — בלי הצמדת גרסה בכוונה (הוא לא בקובץ, ולכן --upgrade).
# [default] מביא את yt-dlp-ejs — פותר האתגרים של יוטיוב. בלעדיו סרטון פרטי/מתוזמן
# (עם עוגיות) מחזיר רק storyboards ו-"Only images are available" (נמדד 22/9/2026).
pinstall "numpy<3" opencv-python-headless requests || die "התקנת הספריות נכשלה"
"$VENV/bin/pip" install --quiet --upgrade -c "$PINS" "yt-dlp[default]" \
  || "$VENV/bin/pip" install --quiet --upgrade "yt-dlp[default]" || die "התקנת yt-dlp נכשלה"
ok "yt-dlp · opencv · numpy"

# הכלי ("יצירת שורטס") צריך את כולם: faster-whisper (גם כשהתמלול בענן — ה-VAD שלו מחתך שקטים
# ומשמש כתמלול גיבוי), modal (תמלול בענן), tzdata (יום הפסיפיק של מכסת Gemini).
# לכן מתקינים הכול תמיד, בלי לשאול.
pinstall tzdata modal || die "התקנת modal נכשלה"
ok "modal (תמלול בענן) · tzdata"
say "      מתקין faster-whisper — כמה דקות, ~200MB"
pinstall faster-whisper || die "התקנת faster-whisper נכשלה"
ok "faster-whisper (תמלול מקומי + זיהוי דיבור)"
if [ -z "$ASR_CHOICE" ]; then
  # ברירת המחדל: ענן אם יש טוקן של Modal, אחרת מקומי. אפשר לשנות אחר כך ב-shorts.sh setup --redo asr
  ASR_CHOICE="local"
  if [ -t 0 ]; then
    echo
    echo "  איך לתמלל?  1) מקומי — חינם, איטי בלי כרטיס מסך   2) ענן (Modal) — מהיר, אגורות לריצה"
    read -r -p "  בחר 1 או 2 [1]: " a || a=1
    ASR_CHOICE="$( [ "${a:-1}" = "2" ] && echo modal || echo local )"
  fi
fi
pinstall google-api-python-client google-auth-oauthlib \
    >/dev/null 2>&1 && ok "ספריות יוטיוב (להעלאה אוטומטית, לא חובה)" \
    || warn "ספריות יוטיוב לא הותקנו — העלאה תהיה ידנית, כל השאר עובד"

# rclone — הגיבוי ל-Google Drive. הורדה ישירה לתיקייה פרטית (בלי sudo ובלי unzip).
if ! command -v rclone >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/rclone" ]; then
  say "      מוריד rclone (גיבוי ל-Drive)"
  mkdir -p "$HOME/.local/bin"
  case "$(uname -m)" in x86_64) RA=amd64 ;; aarch64|arm64) RA=arm64 ;; *) RA="" ;; esac
  if [ -n "$RA" ] && curl -fsSL "https://downloads.rclone.org/rclone-current-linux-$RA.zip" -o /tmp/rclone.zip \
     && "$VENV/bin/python" - /tmp/rclone.zip "$HOME/.local/bin/rclone" <<'PYEOF'
import sys, zipfile, shutil
z = zipfile.ZipFile(sys.argv[1])
n = [x for x in z.namelist() if x.endswith("/rclone")][0]
with z.open(n) as s, open(sys.argv[2], "wb") as d:
    shutil.copyfileobj(s, d)
PYEOF
  then chmod +x "$HOME/.local/bin/rclone" && ok "rclone הותקן ב-~/.local/bin"
  else warn "rclone לא הותקן — הגיבוי ל-Drive לא יעבוד עד שיותקן (https://rclone.org/install/)"; fi
  rm -f /tmp/rclone.zip
else
  ok "rclone כבר קיים"
fi
say "3/5  ffmpeg"
# "Usable" = has vidstab AND libass (the filtergraph fails without either — Debian's apt
# ffmpeg 5.1 is the classic case). Anything already installed that passes is reused:
# no second copy is downloaded, and nothing of the user's is replaced.
have_vidstab() { "$1" -hide_banner -filters 2>/dev/null | grep -qE ' vidstabtransform ' \
                 && "$1" -hide_banner -filters 2>/dev/null | grep -qE ' ass '; }
FF=""
for c in "$PRIVBIN/ffmpeg" "${FFMPEG:-}" ffmpeg /usr/bin/ffmpeg /usr/local/bin/ffmpeg /opt/homebrew/bin/ffmpeg; do
  [ -n "$c" ] && command -v "$c" >/dev/null 2>&1 || continue
  # take the first one that is actually usable; remember a merely-present one as a fallback
  if have_vidstab "$(command -v "$c")"; then FF="$(command -v "$c")"; break; fi
  [ -n "$FF" ] || FF="$(command -v "$c")"
done
if [ -n "$FF" ] && have_vidstab "$FF"; then
  ok "$("$FF" -version | head -1 | cut -c1-60) · כולל ייצוב"
else
  OS="$(uname -s)"; ARCH="$(uname -m)"
  URL=""
  case "$OS/$ARCH" in
    Linux/x86_64)  URL="https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz" ;;
    Linux/aarch64) URL="https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linuxarm64-gpl.tar.xz" ;;
  esac
  if [ -n "$URL" ]; then
    say "      מוריד ffmpeg סטטי (כולל ייצוב תמונה) — ~80MB"
    tmp="$(mktemp -d)"
    if curl -fsSL "$URL" -o "$tmp/ff.tar.xz" && tar -xJf "$tmp/ff.tar.xz" -C "$tmp"; then
      find "$tmp" -type f -name ffmpeg -exec cp {} "$PRIVBIN/ffmpeg" \;
      find "$tmp" -type f -name ffprobe -exec cp {} "$PRIVBIN/ffprobe" \;
      chmod +x "$PRIVBIN/ffmpeg" "$PRIVBIN/ffprobe" 2>/dev/null || true
      ok "הותקן ב-$PRIVBIN"
    else
      warn "ההורדה נכשלה. התקן ידנית: apt install ffmpeg / brew install ffmpeg"
    fi
    rm -rf "$tmp"
  elif [ -n "$FF" ]; then
    warn "יש ffmpeg אבל בלי ייצוב תמונה (vidstab). הכל יעבוד — הקליפים פשוט לא יְיוצבו."
    [ "$OS" = "Darwin" ] && warn "למק עם ייצוב:  brew tap homebrew-ffmpeg/ffmpeg && brew install homebrew-ffmpeg/ffmpeg/ffmpeg --with-libvidstab"
  else
    die "אין ffmpeg ואין בנייה מוכנה ל-$OS/$ARCH. התקן ffmpeg ונסה שוב."
  fi
fi

# Deno — בלעדיו yt-dlp נכשל **בשקט**: הוא פותר את אתגר ה-"n" של יוטיוב
# במנוע JS חיצוני, ובלעדיו `-F` מחזיר רק storyboards ושורת WARNING בודדת.
# An existing Deno (PATH, ~/.deno, or ours) is reused. Node alone is not enough: yt-dlp
# only enables Deno by default.
if ! command -v deno >/dev/null 2>&1 && [ ! -x "$DATA_DIR/deno/bin/deno" ] && [ ! -x "$HOME/.deno/bin/deno" ]; then
  say "      מוריד Deno (נדרש להורדות מיוטיוב)"
  DENO_INSTALL="$DATA_DIR/deno" sh -c "$(curl -fsSL https://deno.land/install.sh)" -- -y \
      >/dev/null 2>&1 && ok "Deno הותקן" || warn "Deno לא הותקן — הורדות מיוטיוב עלולות להיכשל"
fi

# בדיקה: כל מה שהכלי מייבא באמת נטען (מונע הפתעה באמצע שיעור)
if "$VENV/bin/python" - <<'PYEOF'
import importlib, sys
bad = []
for m in ("numpy", "cv2", "requests", "yt_dlp", "faster_whisper", "faster_whisper.vad", "modal", "zoneinfo"):
    try:
        importlib.import_module(m)
    except Exception as e:
        bad.append("%s (%s)" % (m, str(e)[:60]))
if bad:
    print("חסר:", ", ".join(bad)); sys.exit(1)
PYEOF
then ok "כל הספריות של הכלי נטענות"; else die "ספרייה חסרה — ראה למעלה"; fi
say "4/5  חיבור לקלוד"
CLAUDE_SKILLS="$HOME/.claude/skills"
mkdir -p "$CLAUDE_SKILLS"
LINK="$CLAUDE_SKILLS/yeshiva-shorts"
if [ -e "$LINK" ] && [ ! -L "$LINK" ]; then
  warn "כבר קיים $LINK ואינו קישור — לא נוגע בו."
elif [ "$(readlink "$LINK" 2>/dev/null)" = "$SKILL_HOME" ]; then
  ok "מחובר כבר"
else
  ln -sfn "$SKILL_HOME" "$LINK" && ok "$LINK → $SKILL_HOME"
fi

chmod +x "$SKILL_HOME/shorts.sh" 2>/dev/null || true
mkdir -p "$HOME/.local/bin"
ln -sfn "$SKILL_HOME/shorts.sh" "$HOME/.local/bin/shorts" 2>/dev/null \
  && ok "פקודה קצרה: shorts   (אם ~/.local/bin ב-PATH)"

say "5/5  הגדרה ראשונה"
[ -n "$ASR_CHOICE" ] && SHORTS_CONFIG_DIR="${SHORTS_CONFIG_DIR:-${XDG_CONFIG_HOME:-$HOME/.config}/yeshiva-shorts}" \
  "$VENV/bin/python" - "$ASR_CHOICE" <<'EOF' || true
import sys, os
sys.path.insert(0, os.path.join(os.environ["SKILL_HOME"], "setup"))
import state
state.write_env({"SHORTS_ASR": sys.argv[1]})
state.mark("asr", "done", "נבחר בהתקנה")
EOF

if [ "$SKIP_SETUP" = "1" ]; then
  echo; ok "ההתקנה הסתיימה. להשלמת ההגדרה:  $SKILL_HOME/shorts.sh setup"
else
  echo
  exec "$SKILL_HOME/shorts.sh" setup
fi
