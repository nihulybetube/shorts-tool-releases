#!/bin/bash
# Mirror the finished-shorts folder to the user's Google Drive (his request, 2026-10-12):
# so he can keep uploading from another computer, and so a dead disk doesn't take the clips.
# A mirror, not an archive: a clip deleted here is deleted there too — he asked for that.
# Drive deletions go to Drive's trash (30 days), and a run that would delete more than
# MAX_DELETE files stops before touching anything: an emptied or unmounted local folder
# must never be able to wipe the backup.
#
#   drive_backup.sh                 # sync
#   drive_backup.sh --dry-run       # show what would change
#   drive_backup.sh --allow-delete N   # raise the delete cap for a deliberate big delete
set -uo pipefail
export PATH="$HOME/.local/bin:$PATH"

# DRIVE_SRC / DRIVE_DST: only for the tool's test mode (a local folder stands in for Drive).
# 16/11 (3.4): the source follows the export folder the setup wizard chose (SHORTS_EXPORT_DIR) —
# before, a user who picked another folder got "does not exist" from every backup, forever.
# Order: DRIVE_SRC → SHORTS_EXPORT_DIR (env, or that one line of config.env when run without shorts.sh) → ~/Videos/Shorts.
if [ -z "${SHORTS_EXPORT_DIR:-}" ] && [ -f "$HOME/.config/yeshiva-shorts/config.env" ]; then
  SHORTS_EXPORT_DIR="$(grep -m1 -E '^(export +)?SHORTS_EXPORT_DIR=' "$HOME/.config/yeshiva-shorts/config.env" | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//')"
fi
EXP_DIR="${SHORTS_EXPORT_DIR:-}"; EXP_DIR="${EXP_DIR/#\~/$HOME}"
SRC="${DRIVE_SRC:-${EXP_DIR:-$HOME/Videos/Shorts}}"
DST="${DRIVE_DST:-gdrive:שורטסים מוכנים}"
TAG=""; [ -n "${DRIVE_DST:-}" ] && TAG="_test"
MAX_DELETE=10
DRY=""
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY=1 ;;
    --allow-delete) shift; MAX_DELETE="$1" ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

LOG_DIR="$HOME/.local/share/yeshiva-shorts/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/drive_backup$TAG.log"
# One backup at a time (22/10): the tool's background worker and a manual run must never
# mirror over each other. Exit 5 = "another backup is running" — not a failure.
LOCK="$LOG_DIR/drive_backup$TAG.lock"
PIDF="$LOG_DIR/drive_backup$TAG.pid"

# Time limit (29/10, external review: a hung rclone held the lock forever, so every later backup
# exited 5 and the tool showed "running" for days). Every rclone call runs under `timeout`, so a
# backup always ends — even one orphaned by a server restart. The limit is derived from the folder
# size, not a fixed 30 min: the slowest real run (2.7 GB folder, 161 uploads) took ~1.8 h, i.e.
# ~0.4 MB/s worst case. 1 h + size at 0.3 MB/s covers a full first sync with room to spare.
# make_short.py:drive_limit() uses the same formula as its own backstop — change both together.
src_bytes=$(du -sb "$SRC" 2>/dev/null | cut -f1)
LIMIT=$(( 3600 + ${src_bytes:-0} / 300000 ))
[ -n "${DRIVE_LIMIT_SEC:-}" ] && LIMIT="$DRIVE_LIMIT_SEC"
# rclone's own network limits: give up on a dead connection instead of waiting on it.
NET=(--contimeout 60s --timeout 5m --retries 3 --low-level-retries 10)

holders() {   # PIDs that hold the lock file open (bash, timeout, rclone of a previous run)
  local l
  for l in /proc/[0-9]*/fd/*; do
    [ "$(readlink "$l" 2>/dev/null)" = "$LOCK" ] && { l=${l#/proc/}; echo "${l%%/*}"; }
  done | sort -u
}

exec 9>"$LOCK"
if ! flock -n 9; then
  # Stale lock: the holder started longer ago than its own limit + 10 min (e.g. from before this fix,
  # or a run whose server died). Kill exactly the processes holding this lock, then take it.
  read -r opid ostart olimit 2>/dev/null <"$PIDF"
  if [ -n "${ostart:-}" ] && [ $(( $(date +%s) - ostart )) -gt $(( ${olimit:-$LIMIT} + 600 )) ]; then
    hs=$(holders | grep -vx "$$")
    if [ -n "$hs" ]; then
      echo "=== $(date '+%F %T') stale backup (pid ${opid:-?}, started $(date -d "@$ostart" '+%F %T')) — stopping: $hs" >>"$LOG"
      kill -TERM $hs 2>/dev/null; sleep 5; kill -KILL $hs 2>/dev/null; sleep 1
    fi
  fi
  flock -n 9 || { echo "BUSY: another backup is running" >&2; exit 5; }
fi
echo "$$ $(date +%s) $LIMIT" >"$PIDF"
# rclone writes a line per file; keep the log bounded (29/10). One previous generation is kept.
[ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 5000000 ] && mv -f "$LOG" "$LOG.1"

command -v rclone >/dev/null || { echo "rclone missing (~/.local/bin/rclone)" >&2; exit 1; }
[ -d "$SRC" ] || { echo "ABORT: $SRC does not exist" >&2; exit 1; }
n_mp4=$(find "$SRC" -name '*.mp4' | wc -l)
[ "$n_mp4" -gt 0 ] || { echo "ABORT: no clips in $SRC — refusing to mirror an empty folder" >&2; exit 1; }

# Leftover music-mix temp audio is junk; secrets must never leave the machine.
FILTERS=(--exclude '*.wav' --exclude '*.raw'
         --exclude '*cookie*' --exclude '*.env' --exclude '*token*' --exclude '*secret*'
         --exclude '*credential*')

plan=$(timeout -k 30 1800 rclone sync "$SRC" "$DST" "${FILTERS[@]}" "${NET[@]}" --dry-run 2>&1)
rc=$?
if [ $rc -eq 124 ] || [ $rc -eq 137 ]; then echo "TIMEOUT: listing Drive took over 30 min — will retry" >&2; exit 124; fi
n_del=$(grep -c 'Skipped delete' <<<"$plan")
n_up=$(grep -c 'Skipped copy' <<<"$plan")
echo "clips here: $n_mp4 | to upload: $n_up | to delete in Drive: $n_del"

if [ -n "$DRY" ]; then
  grep -E 'Skipped (copy|delete)' <<<"$plan" | sed -E 's/^.*NOTICE: //; s/: Skipped (copy|delete).*$/  [\1]/'
  exit 0
fi
if [ "$n_del" -gt "$MAX_DELETE" ]; then
  echo "ABORT: would delete $n_del files in Drive (cap $MAX_DELETE). Nothing changed." >&2
  grep 'Skipped delete' <<<"$plan" | sed -E 's/^.*NOTICE: //; s/: Skipped.*$//' >&2
  exit 3
fi

echo "=== $(date '+%F %T') sync: up $n_up, del $n_del (limit ${LIMIT}s)" >>"$LOG"
timeout -k 60 "$LIMIT" rclone sync "$SRC" "$DST" "${FILTERS[@]}" "${NET[@]}" --drive-use-trash --transfers 4 \
  --log-file "$LOG" --log-level INFO --stats 0
rc=$?
if [ $rc -eq 124 ] || [ $rc -eq 137 ]; then
  echo "=== $(date '+%F %T') TIMEOUT after ${LIMIT}s — stopped, will retry" >>"$LOG"
  echo "TIMEOUT: the upload took over $((LIMIT / 60)) min — stopped, will retry" >&2; exit 124
fi
if [ $rc -ne 0 ]; then echo "FAILED (rclone exit $rc) — see $LOG" >&2; exit $rc; fi
# Verify: sizes in Drive must match the local files.
timeout -k 30 1800 rclone check "$SRC" "$DST" "${FILTERS[@]}" "${NET[@]}" --size-only --one-way >>"$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then
  echo "OK — Drive matches the local folder"
elif [ $rc -eq 124 ] || [ $rc -eq 137 ]; then
  echo "TIMEOUT: checking Drive took over 30 min — will retry" >&2; exit 124
else
  echo "MISMATCH after sync — see $LOG" >&2; exit 4
fi
